#!/usr/bin/env python3
"""
Investigates the recurring "early half loses, late half wins (or vice
versa)" pattern that has now shown up independently in THREE unrelated
signals tested in this project -- parad_wt/parad_rsi (early -0.09 gross
-> late +0.10..+0.11, split ~2026-05-12), mopeda_zscore_divergence
(early +0.17 -> late -0.04, split ~2026-05-19), and next_gen_combo's
`+session` variant on ETH (early -0.31 net@m+m -> late +0.31, split
~2026-06-23). Three different mechanisms (WaveTrend/RSI mean-reversion,
composite z-score divergence, session-filtered volatility breakout) all
flip sign at roughly the same calendar point -- consistent with a single
shared MARKET REGIME change around mid-2026, not coincidence specific to
any one indicator.

This is the "regime-shift investigation" flagged as the next-most-useful
lever in smc-bot-backtest-2026-08-17.md's final recommendation (item 7)
once the SMC bot's own filter-search and exit-rule search were both
closed out (Runs 5-10) -- rather than hunting for yet another isolated
entry signal (5 next-gen categories + 50 ported indicators have all
failed independently), this asks a different question: is there a
regime FEATURE, computable from price/volume alone with no lookahead,
that actually explains these flips? If so it's a candidate FILTER
(gate any existing signal by regime) rather than a new standalone signal
-- the same "confluence/filter" pattern that has been this project's only
source of (still-losing, but real) improvement so far (SMC bot's
OB+FVG+exclude-BOS, Run 10).

Two regime dimensions computed, both standard/well-known, no lookahead:
  - TREND STRENGTH: ADX(14,14). >25 = "trending", <=25 = "ranging"
    (textbook Wilder threshold, not fit to this data).
  - VOLATILITY: ATR(14) / close, expressed as a rolling PERCENTILE RANK
    against its own trailing 30-day history (2880 bars @ 15m) so it's
    comparable across symbols with very different price scales. >=50th
    percentile = "high_vol", <50th = "low_vol".

Two outputs:
  1. A descriptive weekly table per symbol (avg ADX, avg vol percentile,
     net price change) -- LOOK AT THIS FIRST. It's meant to make any
     regime shift visually obvious before any indicator-specific claim is
     made, avoiding the trap of picking a regime definition that happens
     to match a known split date after the fact.
  2. For each indicator named in --compare-indicators (default: parad_wt,
     parad_rsi -- the two indicators with full 2-year real trade CSVs
     already on disk from Run 8/9, no new signal-generation needed), each
     trade's entry time is joined (merge_asof, backward, no lookahead) to
     the regime label AT THAT BAR, and win-rate/net R is reported split by
     regime bucket INSTEAD of by calendar half. If the regime split is
     just as sharp as the calendar split, that's evidence the flip is
     regime-driven (a real, potentially exploitable-as-a-filter pattern).
     If the regime split is muddy/inconsistent, the calendar-half pattern
     is more likely to be a one-off historical coincidence, not something
     a regime filter could have caught in advance.

This script does NOT build a new tradeable signal -- it's diagnostic. If
the regime split turns out clean, the next step (a separate follow-up)
would be to test a regime-gated variant on already-open questions (e.g.
next_gen_combo's `+session` filtered to trending-regime bars only) as a
proper walk-forward backtest, not just this post-hoc attribution.

Needs Bybit network access -- run on your own machine:

    python regime_shift_investigation.py --bars 17520
    python regime_shift_investigation.py --bars 17520 --compare-indicators parad_wt parad_rsi
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np
import pandas as pd

from app.config import Settings
from app.data import DataError
from app.indicators.common import atr, dmi_adx
from generic_backtest import fetch_history, net_r, FEE_SCENARIOS

ADX_LENGTH = 14
ADX_SMOOTHING = 14
ADX_TREND_THRESH = 25.0
VOL_LOOKBACK_BARS = 2880   # ~30 days at 15m
VOL_PCTILE_THRESH = 50.0


def compute_regime(df: pd.DataFrame) -> pd.DataFrame:
    adx = dmi_adx(df, ADX_LENGTH, ADX_SMOOTHING)
    vol = atr(df, 14) / df["close"]
    vol_pctile = vol.rolling(VOL_LOOKBACK_BARS, min_periods=200).apply(
        lambda w: (w <= w[-1]).mean() * 100.0, raw=True
    )
    trend_regime = np.where(adx > ADX_TREND_THRESH, "trending", "ranging")
    vol_regime = np.where(vol_pctile >= VOL_PCTILE_THRESH, "high_vol", "low_vol")
    return pd.DataFrame({
        "open_time": df["open_time"], "close": df["close"],
        "adx": adx, "vol_pctile": vol_pctile,
        "trend_regime": trend_regime, "vol_regime": vol_regime,
    })


def print_weekly_table(regime_df: pd.DataFrame, symbol: str) -> None:
    df = regime_df.copy()
    df["week"] = df["open_time"].dt.tz_convert("UTC").dt.tz_localize(None).dt.to_period("W").apply(lambda p: p.start_time.date())
    grouped = df.groupby("week").agg(
        avg_adx=("adx", "mean"),
        avg_vol_pctile=("vol_pctile", "mean"),
        pct_trending=("trend_regime", lambda s: (s == "trending").mean() * 100),
        start_close=("close", "first"),
        end_close=("close", "last"),
    )
    grouped["week_chg_pct"] = (grouped["end_close"] / grouped["start_close"] - 1) * 100
    print(f"\n--- {symbol}: weekly regime summary ---")
    print(f"{'week':12s} {'avg_ADX':>8s} {'avg_vol_pctile':>15s} {'%trending':>10s} {'wk_chg%':>9s}")
    for week, row in grouped.iterrows():
        print(f"{str(week):12s} {row['avg_adx']:8.1f} {row['avg_vol_pctile']:15.1f} "
              f"{row['pct_trending']:10.1f} {row['week_chg_pct']:+9.2f}")


def load_indicator_trades(indicator: str, symbol: str, out_dir: Path) -> pd.DataFrame | None:
    # Two save conventions exist in this repo: generic_backtest.py/
    # next_gen_combo.py write per-symbol files (<indicator>/<SYMBOL>_trades.csv),
    # compare_indicators.py writes one combined file (<indicator>/ALL_SYMBOLS_trades.csv).
    # Try both, prefer per-symbol if present.
    per_symbol = out_dir / indicator / f"{symbol}_trades.csv"
    if per_symbol.exists():
        df = pd.read_csv(per_symbol, parse_dates=["time"])
        return df
    combined = out_dir / indicator / "ALL_SYMBOLS_trades.csv"
    if combined.exists():
        df = pd.read_csv(combined, parse_dates=["time"])
        if "symbol" in df.columns:
            df = df[df["symbol"] == symbol]
        return df if len(df) else None
    return None


def summarize_regime_buckets(df: pd.DataFrame, regime_col: str, label: str) -> None:
    """`df` must already carry the regime column (assigned via a prior
    PER-SYMBOL merge_asof -- see main()). Deliberately does NOT re-merge
    here: all 5 watchlist symbols share the same 15m UTC bar grid, so a
    combined multi-symbol frame keyed only by timestamp has duplicate
    `time` values across symbols -- re-doing merge_asof on a time-only key
    at this point would risk matching a trade to a DIFFERENT symbol's
    regime label that happens to share the same bar time."""
    print(f"\n  -- split by {label} --")
    for bucket in sorted(df[regime_col].dropna().unique()):
        sub = df[df[regime_col] == bucket]
        resolved = sub[sub["r"].notna()]
        if len(resolved) == 0:
            print(f"    {bucket:12s}: 0 resolved trades")
            continue
        win_rate = (resolved["r"] > 0).mean() * 100
        gross = resolved["r"].mean()
        net_m = resolved.apply(lambda row: net_r(row.to_dict(), FEE_SCENARIOS["maker+maker"]), axis=1).dropna()
        net_m_avg = net_m.mean() if len(net_m) else float("nan")
        print(f"    {bucket:12s}: n={len(resolved):5d}  win%={win_rate:5.1f}  "
              f"gross avgR={gross:+.3f}  net@m+m avgR={net_m_avg:+.3f}")


def main() -> None:
    settings = Settings.load()
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--symbol", nargs="+", default=settings.watchlist)
    parser.add_argument("--timeframe", default=settings.timeframe)
    parser.add_argument("--bars", type=int, default=17520)
    parser.add_argument("--compare-indicators", nargs="+", default=["parad_wt", "parad_rsi"],
                         help="Indicator modules with existing real trade CSVs in --out to cross-reference against regime")
    parser.add_argument("--out", default="generic_backtest_out")
    args = parser.parse_args()

    print(f"Regime definition: ADX({ADX_LENGTH},{ADX_SMOOTHING}) > {ADX_TREND_THRESH} = trending; "
          f"ATR14/close rolling {VOL_LOOKBACK_BARS}-bar percentile >= {VOL_PCTILE_THRESH} = high_vol\n")

    out_dir = Path(args.out)
    all_regime: dict[str, pd.DataFrame] = {}

    for symbol in [s.upper() for s in args.symbol]:
        print(f"Fetching {symbol} ({args.bars} bars of {args.timeframe})...")
        try:
            df = fetch_history(symbol, args.timeframe, args.bars)
        except DataError as exc:
            print(f"  [SKIP] {symbol}: {exc}")
            continue
        regime_df = compute_regime(df)
        all_regime[symbol] = regime_df
        print_weekly_table(regime_df, symbol)

    print("\n" + "=" * 78)
    print("REGIME-SPLIT ATTRIBUTION (existing real trades, joined to regime at entry time)")
    print("=" * 78)
    for indicator in args.compare_indicators:
        print(f"\n### {indicator} ###")
        # Join each symbol's trades to THAT SAME symbol's regime series
        # individually, then concat -- do NOT concat trades across symbols
        # first and merge_asof once, because all 5 watchlist symbols share
        # the same 15m UTC bar grid: a combined frame would have duplicate
        # `time` values across symbols and merge_asof could pair a trade
        # with a different symbol's regime label at that same timestamp.
        joined_parts = []
        for symbol, regime_df in all_regime.items():
            trades = load_indicator_trades(indicator, symbol, out_dir)
            if trades is None or len(trades) == 0:
                print(f"  {symbol}: no existing trade CSV found under {out_dir / indicator} -- skipping "
                      f"(run generic_backtest.py/compare_indicators.py for this indicator first).")
                continue
            if "symbol" in trades.columns:
                trades = trades[trades["symbol"] == symbol]
            if len(trades) == 0:
                continue
            m = pd.merge_asof(
                trades.sort_values("time"),
                regime_df[["open_time", "trend_regime", "vol_regime"]].sort_values("open_time"),
                left_on="time", right_on="open_time", direction="backward",
            )
            joined_parts.append(m)
        if not joined_parts:
            continue
        joined_all = pd.concat(joined_parts, ignore_index=True)
        resolved_all = joined_all[joined_all["r"].notna()]
        print(f"  Total: n={len(joined_all)} resolved={len(resolved_all)}")
        summarize_regime_buckets(joined_all, "trend_regime", "trend regime (ADX)")
        summarize_regime_buckets(joined_all, "vol_regime", "volatility regime (ATR percentile)")

    print(
        "\nReading this: compare the weekly table's %trending / avg_vol_pctile columns against where each "
        "indicator's known calendar split falls (parad_wt/parad_rsi ~2026-05-12, mopeda_zscore_divergence "
        "~2026-05-19, next_gen_combo +session ~2026-06-23). If the regime-split win%/net-R gap is roughly as "
        "sharp as the calendar-split gap already documented, that's real evidence of a shared regime driver -- "
        "worth designing an actual regime-gated filter next. If it's muddy (both regime buckets look similar, "
        "or the regime doesn't track the known split dates), the calendar-half flips are more likely "
        "coincidental non-stationarity, not something a regime filter could have caught."
    )


if __name__ == "__main__":
    main()
