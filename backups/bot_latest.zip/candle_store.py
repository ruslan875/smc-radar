"""Локальный склад минуток Bybit USDT-perp для бэктестов. 2026-09-26.

Храним ТОЛЬКО 1m: любой другой ТФ (5m…1D) собирается из них за доли секунды
(resample), а своих свечей 15m/1h/4h Bybit не даёт точнее минуток — так
все ТФ гарантированно согласованы между собой.

Формат: market_cache/1m/<SYM>.parquet (если есть pyarrow) иначе <SYM>.pkl —
читается в 10–30 раз быстрее CSV. Старый CSV (bybit_swap_<SYM>USDT_1m.csv)
подхватывается автоматически при первом обращении.

    from candle_store import load, update
    df = update("BTC")            # докачать до текущей минуты и вернуть
    df = load("BTC")              # только с диска, без сети
"""
from __future__ import annotations

import time
from pathlib import Path

import pandas as pd

BASE = Path(__file__).resolve().parent
DIR = BASE / "market_cache" / "1m"
EARLIEST = "2020-01-01"          # раньше у Bybit USDT-perp почти ничего нет
COLS = ["t", "open", "high", "low", "close", "volume"]

try:
    import pyarrow  # noqa: F401
    _EXT = ".parquet"
except ImportError:
    _EXT = ".pkl"


def _path(sym: str) -> Path:
    return DIR / f"{sym.upper()}{_EXT}"


def _read(p: Path) -> pd.DataFrame:
    return pd.read_parquet(p) if p.suffix == ".parquet" else pd.read_pickle(p)


def _write(df: pd.DataFrame, p: Path) -> None:
    DIR.mkdir(parents=True, exist_ok=True)
    import os
    tmp = p.with_suffix(p.suffix + f".{os.getpid()}.tmp")   # у каждого процесса свой временный файл
    if p.suffix == ".parquet":
        df.to_parquet(tmp, index=False)
    else:
        df.to_pickle(tmp)
    # 2026-09-27: на Windows файл склада могут в этот момент читать другие процессы
    # (paper-боты, бэктест, предрасчёт) -> WinError 32. Пробуем несколько раз; не вышло —
    # не беда: свежие свечи уже в памяти, запишет следующий вызов.
    for attempt in range(8):
        try:
            tmp.replace(p)             # атомарно: оборванная запись не портит склад
            return
        except PermissionError:
            time.sleep(0.4 + attempt * 0.4)
    try:
        tmp.unlink()
    except OSError:
        pass


def load(sym: str) -> pd.DataFrame | None:
    sym = sym.upper().replace("USDT", "")
    p = _path(sym)
    for cand in (p, DIR / f"{sym}.parquet", DIR / f"{sym}.pkl"):
        if cand.exists():
            try:
                return _read(cand)
            except ImportError as exc:
                raise RuntimeError(f"{cand.name}: для чтения .parquet нужен pyarrow в этом python "
                                   f"(venv\\Scripts\\python.exe -m pip install pyarrow)") from exc
            except Exception:  # noqa: BLE001 -- битый файл: перечитаем из CSV/сети
                pass
    old = BASE / "market_cache" / f"bybit_swap_{sym}USDT_1m.csv"
    if old.exists():
        df = pd.read_csv(old)[COLS]
        df = _clean(df)
        _write(df, p)
        return df
    return None


def load_since(sym: str, start_ms: int) -> pd.DataFrame | None:
    """Только минутки начиная с start_ms — без чтения всей истории в память (для paper-ботов:
    у ETH на складе ~3 млн строк, а боту нужно 90 дней)."""
    sym = sym.upper().replace("USDT", "")
    for cand in (DIR / f"{sym}.parquet", DIR / f"{sym}.pkl"):
        if not cand.exists():
            continue
        try:
            if cand.suffix == ".parquet":
                return pd.read_parquet(cand, filters=[("t", ">=", int(start_ms))])
            df = pd.read_pickle(cand)
            return df[df.t >= start_ms].reset_index(drop=True)
        except Exception:  # noqa: BLE001
            continue
    return None


def _clean(df: pd.DataFrame) -> pd.DataFrame:
    df = df.astype({"t": "int64"}).drop_duplicates("t", keep="last").sort_values("t")
    now_min = int(time.time() * 1000) // 60_000 * 60_000
    return df[df.t < now_min].reset_index(drop=True)      # незакрытую минутку не храним


def _exchange():
    import ccxt
    return ccxt.bybit({"enableRateLimit": True, "timeout": 30_000, "options": {"defaultType": "swap"}})


def _fetch_range(ex, sym, since, until, log):
    """Минутки [since, until). Если монеты ещё не было — прыгаем вперёд до листинга."""
    rows, empty_jumps = [], 0
    while since < until - 60_000:
        raw = None
        for attempt in range(6):
            try:
                raw = ex.fetch_ohlcv(f"{sym}/USDT:USDT", "1m", since=since, limit=1000)
                break
            except Exception as exc:  # noqa: BLE001
                msg = str(exc)
                if "symbol" in msg.lower() and "not" in msg.lower():
                    raise RuntimeError(f"{sym}: нет такой монеты на Bybit USDT-perp") from exc
                time.sleep(2 + attempt * 3)
        if raw is None:
            raise RuntimeError(f"{sym}: Bybit не отвечает")
        raw = [r for r in raw if since <= r[0] < until]
        if not raw:
            empty_jumps += 1
            if empty_jumps > 80:            # ~6.5 лет пусто — дальше нечего ждать
                break
            since += 30 * 86_400_000        # до листинга: шаг в 30 дней
            continue
        empty_jumps = 0
        rows += raw
        since = raw[-1][0] + 60_000
        if len(rows) % 50_000 < 1000:
            log(sym, since)
    return pd.DataFrame(rows, columns=COLS)


def update(sym: str, start: str = EARLIEST, log=None, min_save: int = 1) -> pd.DataFrame:
    """Докачать недостающее (в начало — до start, в конец — до текущей минуты)."""
    sym = sym.upper().replace("USDT", "")
    log = log or (lambda s, t: print(f"  {s}: {pd.to_datetime(t, unit='ms'):%Y-%m-%d}", flush=True))
    have = load(sym)
    start_ms = int(pd.Timestamp(start, tz="UTC").timestamp() * 1000)
    now = int(time.time() * 1000)
    try:
        ex = _exchange()
    except ImportError:
        if have is None:
            raise
        return have
    parts = [] if have is None else [have]
    try:
        if have is None or have.empty:
            parts.append(_fetch_range(ex, sym, start_ms, now, log))
        else:
            first, last = int(have.t.iloc[0]), int(have.t.iloc[-1])
            # голову докачиваем, только если там могут быть данные (не упёрлись в листинг)
            meta = DIR / f"{sym}.listing"
            listed = int(meta.read_text()) if meta.exists() else None
            if start_ms < first - 60_000 and (listed is None or first > listed):
                head = _fetch_range(ex, sym, start_ms, first, log)
                parts.insert(0, head)
                DIR.mkdir(parents=True, exist_ok=True)
                meta.write_text(str(int(head.t.iloc[0]) if len(head) else first))
            parts.append(_fetch_range(ex, sym, last + 60_000, now, log))
    except RuntimeError as exc:
        if have is None:
            raise
        print(f"  {sym}: {exc} — оставляю то, что уже есть")
    df = _clean(pd.concat([p for p in parts if len(p)], ignore_index=True))
    # paper-боты зовут update() раз в минуту: переписывать 50-МБ файл каждую минуту незачем
    if have is None or len(df) - len(have) >= min_save or len(df) < len(have):
        _write(df, _path(sym))
    return df
