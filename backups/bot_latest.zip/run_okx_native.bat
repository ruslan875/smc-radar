@echo off
chcp 65001 >nul
cd /d D:\VANTORIX\bot
if exist venv\Scripts\python.exe (venv\Scripts\python.exe okx_native_run.py) else (python okx_native_run.py)
echo Готово. Пришлите файл okx_native_report.txt
pause
