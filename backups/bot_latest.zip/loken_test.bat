@echo off
cd /d %~dp0
python loken_test.py
pause
