@echo off
cd /d %~dp0
python combo_exchanges.py
pause
