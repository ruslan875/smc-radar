# -*- coding: utf-8 -*-
"""combo71_new_test.py — 2026-11-02. Новые сборки Combo OTM 7.1 (ENA, FARTCOIN, ZEC TVA FIXED) на данных OKX 1H.
Использует движок и отчёт combo71_okx_test.py (тот же честный тест: 50% equity, комиссия OKX 0.05%, до 3 лет,
половины истории, «до 2025 / 2025–26», робастность на всех монетах; ✅ = своя монета плюс в обеих половинах
И плюс на ≥60% других монет). Сетка DGL здесь не гоняется.
Сборки: combo_okx/new_2026-11-02/{ENA,FARTCOIN,ZEC}.csv · Отчёт: bt_lab_bots/combo71_new_test.txt
"""
from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

H = Path(__file__).resolve().parent
sys.path.insert(0, str(H))
import combo71_okx_test as T  # noqa: E402

T.FILES = H / "combo_okx" / "new_2026-11-02"
T.OUT = H / "bt_lab_bots" / "combo71_new_test.txt"
T.BUILDS = {
    "ENA (29.10)": ("ENA.csv", "ENA"),
    "FARTCOIN (API final)": ("FARTCOIN.csv", "FARTCOIN"),
    "ZEC (TVA fixed)": ("ZEC.csv", "ZEC"),
}
T.ROBUST = list(T.BUILDS)
T.COINS = ["BTC", "ETH", "SOL", "XRP", "DOGE", "ADA", "SUI", "LINK", "AVAX", "BNB", "NEAR", "HYPE", "ZEC",
           "ENA", "FARTCOIN", "TAO", "PEPE", "WIF", "ONDO"]
T.dgl_run = lambda d, *a, **k: (pd.DataFrame(columns=["profit"]), 0.0, T.INIT, T.INIT)   # сетку не гоняем

if __name__ == "__main__":
    T.main()
