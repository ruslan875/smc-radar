# -*- coding: utf-8 -*-
"""
Честный бэктест Combo OTM 7.1 + сборок с OKX и «Статистической сетки» на данных OKX.
=====================================================================================
Запуск (Windows): положить combo71_okx_test.py, combo71.py и .bat в D:\\VANTORIX\\bot
(рядом combo_full.py, папка combo_okx\\ChatExport_2026-10-17\\files\\ с CSV и Pine) → combo71_okx_test.bat.
Первый запуск качает свечи OKX (13 монет × до 3 лет 1H ≈ 10–25 минут), дальше кэш market_cache\\okx71
(обновляется, если старше 12 ч). Отчёт: bt_lab_bots\\combo71_okx_test.txt + вывод в консоль.

ЧТО ИЗМЕНИЛОСЬ В 7.1 ОТНОСИТЕЛЬНО 3.2 (diff Pine):
  * Новый фильтр «Premium Discount» (см. combo71.py): канал из последних 15 подтверждённых
    pivot high/low (3/3 бара), позиция close в канале −100..+100%; Long разрешён в [−50; 150],
    Short в [−150; 50]; можно включить в Shadow Lock. ПО УМОЛЧАНИЮ ВЫКЛЮЧЕН (Use ... = false).
  * Вход требует barstate.isconfirmed, в strategy() добавлено calc_on_every_tick=true —
    на бэктесте по закрытым барам НЕ влияет (в реальном времени TV тоже входит по закрытию бара).
  * Всё остальное (23 фильтра, Shadow Lock, выходы, дефолты) не менялось.

CSV-СБОРКИ (combo_okx\\ChatExport_2026-10-17\\files):
  * все четыре "Combo OTM_*.csv" содержат 289 настроек = набор v3.2: настроек Premium Discount
    в них НЕТ (в т.ч. в новой ZEC-сборке от 15.10) → для 7.1 берутся дефолты 7.1 (фильтр выключен),
    т.е. 7.1 c этими сборками торгует ТАК ЖЕ, как 3.2. Поэтому дополнительно гоняется вариант
    «7.1 + PD вкл.» (дефолтные границы фильтра), чтобы увидеть, помогает ли сам новый фильтр.
  * DOGEUSDT.P_1H_OKX.csv — это НЕ Combo, а настройки другой стратегии "Third eye • Strategy"
    (Ichimoku + CCI + ADX/RSI/NATR/BBWidth, TP 6.9%, SL 1.2%, BE 1.7%). Pine-кода этой стратегии
    в папке нет → не тестируется, только перечисляется.

ДАННЫЕ: OKX USDT-SWAP 1H, /api/v5/market/history-candles (limit=100, пагинация after, только
  подтверждённые свечи), до 3 лет. Открытый интерес для фильтра nOI: /api/v5/rubik/stat/contracts/
  open-interest-history (OKX отдаёт ограниченную глубину), где OI нет — NaN → фильтр nOI ПРОПУСКАЕТ
  (так же делает Pine при na). Z-Score эталон COINBASE:BTCUSD заменён на OKX BTC-USDT-SWAP.

ДЕНЬГИ: капитал 10 000, позиция 50% equity (как strategy() в Pine), комиссия 0.05% (OKX taker)
  на каждое исполнение — в движке combo_full одна ставка на все сделки; тейки на TV — лимитки
  (на OKX maker 0.02%), т.е. реальность чуть лучше. У автора на TV 0.055% (одна контрольная строка).
  Проскальзывание не моделируется.

ОТЧЁТ ПО КАЖДОМУ ПРОГОНУ: итог % счёта стратегии, сделки, PF, winrate, макс. просадка (внутрибаровая,
  по движку) за весь период; по годам, по половинам периода и «до 2025 / 2025–2026» — из той же
  последовательности сделок (доходность периода = рост equity между сделками периода; просадка
  периода — по закрытым сделкам, приближение).

ВЕРДИКТ (✅/❌) по сборке: ✅ только если на «своей» монете плюс в обеих половинах И плюс на ≥60%
  остальных монет (тест робастности на 13 монетах).

СТАТИСТИЧ_СЕТКА: это "Distribution-Gated Ladder Grid (DGL)" (strategy.*, есть вход/выход) →
  портирована (dgl_run ниже) с дефолтами Pine: окно 10, история 1500, вход в хвосте 10%,
  глубина 3%, profitK 0.8, N=3,6,9,12, step 0.25, рост профита 0.5, minGap 0.15, экспозиция 20%,
  стоп за последним уровнем +1×ATR14, закрытие по истечении окна, фильтр ATR14/ATR100>2.
  Приближения: рыночный L0 — по открытию следующего бара (taker 0.05%), лимитные уровни — maker
  0.02% по цене уровня (или по открытию при гэпе), выход корзины (TP-лимит/стоп) пересчитывается
  на закрытии бара и действует со следующего бара, после TP/SL остаток лимиток снимается сразу,
  проскальзывание 2 тика не моделируется. Разорение = equity падала ниже 50% стартовой.

Робастность гоняется для всех 4 сборок. Монеты: BTC ETH SOL XRP DOGE ADA SUI LINK AVAX BNB NEAR HYPE + ZEC.
"""
from __future__ import annotations

import json
import math
import os
import sys
import time
import urllib.request
from pathlib import Path

import numpy as np
import pandas as pd

try:
    sys.stdout.reconfigure(encoding="utf-8")
except Exception:
    pass

H = Path(__file__).resolve().parent
sys.path.insert(0, str(H))
import combo71 as c71  # noqa: E402
import combo_full as cf  # noqa: E402

FILES = H / "combo_okx" / "ChatExport_2026-10-17" / "files"
CACHE = H / "market_cache" / "okx71"
OUT = H / "bt_lab_bots" / "combo71_okx_test.txt"
COINS = ["BTC", "ETH", "SOL", "XRP", "DOGE", "ADA", "SUI", "LINK", "AVAX", "BNB", "NEAR", "HYPE", "ZEC"]
YEARS_CAP = 3
TAKER, MAKER, TV_COMM = 0.05, 0.02, 0.055
INIT, PCT = 10000.0, 50.0
BUILDS = {
    "ZEC (автор 15.10)": ("Combo OTM_ZEC-1H_OKX .csv", "ZEC"),
    "XRP автор 04.09": ("Combo OTM_XRP-1H_OKX.csv", "XRP"),
    "XRP подписчик": ("Combo OTM_XRP-1H_OKX(моя).csv", "XRP"),
    "XRP подписчик v2": ("Combo OTM_XRP-1H_OKX(моя 2 версия).csv", "XRP"),
}
ROBUST = list(BUILDS)  # ZEC и XRP-автор по заданию + обе сборки подписчика (для вердикта)

# ============================================================================
# ДАННЫЕ OKX
# ============================================================================

def _get(url):
    for k in range(6):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            return json.loads(urllib.request.urlopen(req, timeout=25).read())
        except Exception as e:  # noqa: BLE001
            print("   повтор:", str(e)[:70], flush=True)
            time.sleep(2 + 2 * k)
    return None


def okx_candles(coin):
    inst = f"{coin}-USDT-SWAP"
    start_ms = int((pd.Timestamp.utcnow() - pd.Timedelta(days=365 * YEARS_CAP)).timestamp() * 1000)
    rows, after = [], ""
    while True:
        j = _get(f"https://www.okx.com/api/v5/market/history-candles?instId={inst}&bar=1H&limit=100"
                 + (f"&after={after}" if after else ""))
        d = (j or {}).get("data") or []
        if not d:
            break
        for r in d:
            if len(r) > 8 and str(r[8]) != "1":
                continue  # неподтверждённая свеча
            rows.append([int(r[0]), float(r[1]), float(r[2]), float(r[3]), float(r[4]), float(r[5])])
        after = d[-1][0]
        if int(after) < start_ms:
            break
        time.sleep(0.11)
    return [r for r in rows if r[0] >= start_ms]


def okx_oi(coin):
    inst = f"{coin}-USDT-SWAP"
    rows, end = [], ""
    for _ in range(400):
        j = _get(f"https://www.okx.com/api/v5/rubik/stat/contracts/open-interest-history?instId={inst}&period=1H&limit=100"
                 + (f"&end={end}" if end else ""))
        d = (j or {}).get("data") or []
        if not d:
            break
        rows += [[int(r[0]), float(r[1])] for r in d]
        nxt = str(int(d[-1][0]) - 1)
        if nxt == end or len(d) < 2:
            break
        end = nxt
        time.sleep(0.11)
    return rows


def load_okx(coin):
    CACHE.mkdir(parents=True, exist_ok=True)
    f = CACHE / f"{coin}_1h.csv"
    if f.exists() and time.time() - f.stat().st_mtime < 12 * 3600:
        return pd.read_csv(f, index_col=0, parse_dates=True)
    print(f"скачиваю OKX {coin}-USDT-SWAP 1H ...", flush=True)
    cand = okx_candles(coin)
    if len(cand) < 500:
        return None
    d = pd.DataFrame(cand, columns=["t", "open", "high", "low", "close", "volume"]).drop_duplicates("t").sort_values("t")
    d.index = pd.to_datetime(d.t, unit="ms")
    d = d.drop(columns="t")
    try:
        oi = okx_oi(coin)
    except Exception:  # noqa: BLE001
        oi = []
    d["oi"] = np.nan
    if oi:
        o = pd.DataFrame(oi, columns=["t", "oi"]).drop_duplicates("t")
        o.index = pd.to_datetime(o.t, unit="ms")
        d["oi"] = o["oi"].reindex(d.index)
    d.to_csv(f)
    return d

# ============================================================================
# СТАТИСТИКА ПО ПЕРИОДАМ (из последовательности сделок)
# ============================================================================

def period_stats(tr, init, t0, t1):
    if tr is None or len(tr) == 0:
        return None
    eq = init + tr["profit"].cumsum().to_numpy()
    before = np.concatenate([[init], eq[:-1]])
    m = ((tr["exit_time"] >= t0) & (tr["exit_time"] < t1)).to_numpy()
    if not m.any():
        return dict(net=0.0, n=0, pf=float("nan"), win=0.0, dd=0.0)
    p = tr["profit"].to_numpy()[m]
    e0 = before[m][0]
    curve = np.concatenate([[e0], eq[m]])
    pk = np.maximum.accumulate(curve)
    gw, gl = p[p > 0].sum(), -p[p < 0].sum()
    return dict(net=(curve[-1] / e0 - 1) * 100, n=int(m.sum()), pf=gw / gl if gl > 0 else float("inf"),
                win=(p > 0).mean() * 100, dd=((pk - curve) / pk).max() * 100)


def fmt_s(s):
    if s is None:
        return "нет сделок"
    return f"{s['net']:+7.1f}%  сд {s['n']:4d}  PF {s['pf']:5.2f}  win {s['win']:4.1f}%  DD {s['dd']:5.1f}%"


def full_report(label, tr, dd, fin, t_start, t_end, lines):
    r = cf.summarize(tr, dd, fin, INIT)
    lines.append(f"{label}: ИТОГ {r['net']:+.1f}%  сделок {r['trades']}  PF {r['pf']:.2f}  win {r['win']:.1f}%  макс.DD {r['dd']:.1f}%"
                 f"   [{t_start:%Y-%m-%d}..{t_end:%Y-%m-%d}]")
    per = {}
    mid = t_start + (t_end - t_start) / 2
    for y in range(t_start.year, t_end.year + 1):
        s = period_stats(tr, INIT, pd.Timestamp(f"{y}-01-01"), pd.Timestamp(f"{y + 1}-01-01"))
        lines.append(f"      {y}:          {fmt_s(s)}")
    for nm, a, b in (("1-я половина", t_start, mid), ("2-я половина", mid, t_end + pd.Timedelta(days=1)),
                     ("до 2025     ", t_start, pd.Timestamp("2025-01-01")), ("2025–2026   ", pd.Timestamp("2025-01-01"), t_end + pd.Timedelta(days=1))):
        s = period_stats(tr, INIT, a, b)
        per[nm.strip()] = s
        lines.append(f"      {nm}:  {fmt_s(s)}")
    return r, per

# ============================================================================
# DGL — «Статистич_сетка»
# ============================================================================

def _rolling_windows(x, n, fn, chunk=2000):
    out = np.full(len(x), np.nan)
    if len(x) < n:
        return out
    from numpy.lib.stride_tricks import sliding_window_view
    W = sliding_window_view(x, n)  # W[i] = x[i : i+n] → бар i+n-1
    for s in range(0, len(W), chunk):
        out[s + n - 1: s + n - 1 + len(W[s:s + chunk])] = fn(W[s:s + chunk], s)
    return out


def _pnr(x, n, p):
    """ta.percentile_nearest_rank(x, n, p) (NaN в окне → NaN)."""
    k = max(int(math.ceil(p / 100.0 * n)), 1) - 1

    def f(w, s):
        r = np.partition(w, k, axis=1)[:, k]
        r[np.isnan(w).any(axis=1)] = np.nan
        return r
    return _rolling_windows(x, n, f)


def _prank(x, n):
    """ta.percentrank(x, n): % из n ПРЕДЫДУЩИХ значений, которые <= текущего."""
    def f(w, s):
        cur = w[:, -1:]
        prev = w[:, :-1]
        r = (prev <= cur).sum(axis=1) / (n) * 100.0
        r[np.isnan(w).any(axis=1)] = np.nan
        return r
    return _rolling_windows(x, n + 1, f)


DGL = dict(windowBars=10, historyBars=1500, entryPct=10.0, tailPct=3.0, profitK=0.8, useTrend=False, emaLen=200,
           nList=[3, 6, 9, 12], stepRatio=0.25, profitGrowth=0.5, minGapK=0.15, exposurePct=20.0,
           slAtrMult=1.0, closeOnExp=True, volSpike=2.0)


def dgl_run(df, P=DGL, init=INIT, start=None):
    o, h, l, c = (df[k].to_numpy(float) for k in ("open", "high", "low", "close"))
    idx = df.index
    n = len(c)
    W, HB = P["windowBars"], P["historyBars"]
    ret = c / cf.shift(c, W) - 1.0
    rank = _prank(ret, HB)
    medAbs = _pnr(np.abs(ret), HB, 50)
    qLow, qHigh = _pnr(ret, HB, P["tailPct"]), _pnr(ret, HB, 100 - P["tailPct"])
    a14, a100 = cf.atr(h, l, c, 14), cf.atr(h, l, c, 100)
    emaV = cf.ema(c, P["emaLen"])
    t0 = pd.Timestamp(start) if start is not None else idx[0]
    cash = init  # realized equity
    pos_q = 0.0; pos_avg = 0.0; d = 0; fills = 0
    orders = []  # [(price, qty)] лимитки
    stageTp = []; gridBar = None; stopPx = np.nan
    pend_mkt = None; pend_close = False
    ex_tp = ex_sl = None  # действующий выход
    trades = []; peak = init; maxdd = 0.0; min_eq = init; cyc_pnl = 0.0; cyc_start = None

    def fill(px, q, fee_pct):
        nonlocal pos_q, pos_avg, cash, fills, cyc_pnl
        cash -= q * px * fee_pct / 100; cyc_pnl -= q * px * fee_pct / 100
        pos_avg = (pos_avg * pos_q + px * q) / (pos_q + q); pos_q += q; fills += 1

    def close_all(px, fee_pct, why, t):
        nonlocal pos_q, pos_avg, cash, fills, cyc_pnl, d, orders
        g = (px - pos_avg) * pos_q * d - pos_q * px * fee_pct / 100
        cash += g; cyc_pnl += g
        trades.append({"entry_time": cyc_start, "exit_time": idx[t], "profit": cyc_pnl, "reason": why, "fills": fills})
        pos_q = 0.0; pos_avg = 0.0; fills = 0; orders = []; cyc_pnl = 0.0

    for t in range(n):
        closed_now = False
        # --- брокер ---
        if pend_close and pos_q > 0:
            close_all(o[t], TAKER, "EXPIRY", t); closed_now = True; ex_tp = ex_sl = None
        pend_close = False
        if pend_mkt is not None:
            d, q = pend_mkt; pend_mkt = None
            cyc_start = idx[t]; cyc_pnl = 0.0
            fill(o[t], q, TAKER)
        if pos_q > 0 or orders:
            path = [o[t], h[t], l[t], c[t]] if abs(o[t] - h[t]) <= abs(o[t] - l[t]) else [o[t], l[t], h[t], c[t]]
            prev = path[0]
            for si, b in enumerate(path):
                a = prev if si else b
                lo_, hi_ = min(a, b), max(a, b)
                adverse = (b < a) if d == 1 else (b > a)
                if si == 0 or adverse:
                    for od in list(orders):
                        lp, q = od
                        hit = (b <= lp) if d == 1 else (b >= lp)
                        if si == 0 and hit or si > 0 and lo_ <= lp <= hi_:
                            fill(b if si == 0 else lp, q, MAKER if si else TAKER); orders.remove(od)
                    if pos_q > 0 and ex_sl is not None:
                        hit = (b <= ex_sl) if d == 1 else (b >= ex_sl)
                        if si == 0 and hit or si > 0 and lo_ <= ex_sl <= hi_:
                            close_all(b if si == 0 else ex_sl, TAKER, "SL", t); closed_now = True; ex_tp = ex_sl = None; break
                if pos_q > 0 and ex_tp is not None and (si == 0 or not adverse):
                    hit = (b >= ex_tp) if d == 1 else (b <= ex_tp)
                    if si == 0 and hit or si > 0 and lo_ <= ex_tp <= hi_:
                        close_all(b if si == 0 else ex_tp, MAKER, "TP", t); closed_now = True; ex_tp = ex_sl = None; break
                prev = b
        eq_c = cash + ((c[t] - pos_avg) * pos_q * d if pos_q > 0 else 0.0)
        eq_w = cash + (((l[t] if d == 1 else h[t]) - pos_avg) * pos_q * d if pos_q > 0 else 0.0)
        if idx[t] >= t0:
            maxdd = max(maxdd, (peak - eq_w) / peak); peak = max(peak, eq_c); min_eq = min(min_eq, eq_w)
        # --- скрипт ---
        if closed_now and pos_q == 0:
            orders = []; stageTp = []; gridBar = None
        if gridBar is not None and t - gridBar >= W:
            orders = []; gridBar = None
            if P["closeOnExp"] and pos_q > 0:
                pend_close = True
        sig = 0
        if not np.isnan(rank[t]) and ret[t] < 0 and rank[t] <= P["entryPct"] and (not P["useTrend"] or c[t] > emaV[t]):
            sig = 1
        elif not np.isnan(rank[t]) and ret[t] > 0 and rank[t] >= 100 - P["entryPct"] and (not P["useTrend"] or c[t] < emaV[t]):
            sig = -1
        warm = t >= HB + W + 1
        spike = (a14[t] / a100[t] > P["volSpike"]) if a100[t] > 0 else False
        if pos_q == 0 and gridBar is None and warm and not spike and sig != 0 and idx[t] >= t0 and pend_mkt is None \
                and not np.isnan(medAbs[t]):
            dd_ = sig
            p0 = max(P["profitK"] * c[t] * medAbs[t], 1e-12)
            reach = abs(qLow[t] if dd_ == 1 else qHigh[t]) * c[t]
            minGap = P["minGapK"] * p0
            units = 1.0 + sum(1.0 + k * P["stepRatio"] for k in P["nList"])
            lot0 = cash * P["exposurePct"] / 100.0 / c[t] / units
            sumLot, acc, prevD = lot0, 0.0, 0.0
            orders = []; stageTp = [p0]
            pend_mkt = (dd_, lot0)
            for k_, Nk in enumerate(P["nList"], start=1):
                ln = lot0 * (1.0 + Nk * P["stepRatio"]); s2 = sumLot + ln
                pn = p0 * (1.0 + P["profitGrowth"] * k_)
                dn = (pn * s2 - acc) / (2.0 * ln)
                if dn < prevD + minGap:
                    dn = prevD + minGap; pn = (acc + 2.0 * ln * dn) / s2
                if dn > reach:
                    break
                sumLot = s2; acc += ln * dn; prevD = dn
                orders.append((c[t] - dd_ * dn, ln)); stageTp.append(pn)
            gridBar = t
            stopPx = c[t] - dd_ * (prevD + P["slAtrMult"] * a14[t])
            d = dd_
        if pos_q > 0 and stageTp:
            k = max(fills - 1, 0)
            tp = stageTp[min(k, len(stageTp) - 1)]
            ex_tp = pos_avg + d * tp; ex_sl = stopPx
        if t == n - 1 and pos_q > 0:
            close_all(c[t], TAKER, "END", t)
    return pd.DataFrame(trades), maxdd, cash, min_eq

# ============================================================================
# MAIN
# ============================================================================

def main():
    lines = []
    P = lambda s="": (print(s, flush=True), lines.append(s))  # noqa: E731
    T0 = time.time()
    P("Combo OTM 7.1 / 3.2 + сборки с OKX, данные OKX USDT-SWAP 1H — честный тест "
      f"(капитал {INIT:.0f}, {PCT:.0f}% equity, комиссия {TAKER}% taker)")
    P(f"Новые input 7.1: {', '.join(c71.NEW_KEYS)}")
    P("calc_on_every_tick / barstate.isconfirmed: на закрытых барах не влияет — не моделируется.")
    P()
    builds71, builds32 = {}, {}
    for nm, (fn, coin) in BUILDS.items():
        f = FILES / fn
        if not f.exists():
            P(f"!! нет файла {f}"); continue
        builds71[nm], a, um = c71.load_settings_csv(f)
        builds32[nm], a2, um2 = c71.load_settings_csv32(f)
        has_pd = any(k in open(f, encoding="utf-8").read() for k in ("Premium Discount",))
        P(f"Сборка {nm:18} {fn}: применено {a} настроек, не сопоставлено {um}; "
          f"настройки Premium Discount в CSV: {'есть' if has_pd else 'НЕТ → дефолты 7.1 (фильтр выкл.)'}")
    dg = FILES / "DOGEUSDT.P_1H_OKX.csv"
    if dg.exists():
        first = open(dg, encoding="utf-8").read().splitlines()[1:2]
        P(f"DOGEUSDT.P_1H_OKX.csv: {first} — настройки другой стратегии (Pine нет) → не тестируется.")
    P()

    data = {}
    for coin in COINS:
        try:
            d = load_okx(coin)
        except Exception as e:  # noqa: BLE001
            print(f"{coin}: ошибка загрузки {e}"); d = None
        if d is None or len(d) < 1500:
            P(f"{coin}: мало данных/нет инструмента — пропуск"); continue
        data[coin] = d
        oi_n = int(d["oi"].notna().sum()) if "oi" in d else 0
        P(f"{coin}: {len(d)} баров {d.index[0]:%Y-%m-%d}..{d.index[-1]:%Y-%m-%d}, OI баров: {oi_n}"
          + (" (nOI фильтр работает только там, где OI есть; иначе пропускает)" if oi_n else " (OI нет → nOI пропускает)"))
    ref = data.get("BTC")
    P()
    cache = {}

    def go(engine, nm, cfg, coin, comm=TAKER, tag=""):
        d = data[coin]
        t_start = d.index[0] + pd.Timedelta(days=30)   # прогрев индикаторов (CVD 300, nOI 350 баров)
        t_end = d.index[-1]
        runner = c71.run if engine == "7.1" else cf.run
        tr, dd, fin, st = runner(d, cfg, ref, t_start, t_end + pd.Timedelta(hours=1),
                                 initial_capital=INIT, pct_equity=PCT, commission_pct=comm)
        lines_tmp = []
        r, per = full_report(f"[{engine}{tag}] {nm} на {coin}", tr, dd, fin, t_start, t_end, lines_tmp)
        for s in lines_tmp:
            P(s)
        cache[(engine + tag, nm, coin)] = (r, per)
        return r, per

    # a) + b) 7.1 на своих монетах
    P("=" * 100); P("a/b) 7.1 + сборки на своих монетах"); P("=" * 100)
    for nm, (fn, coin) in BUILDS.items():
        if nm in builds71 and coin in data:
            go("7.1", nm, builds71[nm], coin)
            cpd = dict(builds71[nm]); cpd["pivotMatrixActiveLong"] = cpd["pivotMatrixActiveShort"] = True
            go("7.1", nm, cpd, coin, tag=" +PD вкл.")
    if "ZEC (автор 15.10)" in builds71 and "ZEC" in data:
        go("7.1", "ZEC (автор 15.10)", builds71["ZEC (автор 15.10)"], "ZEC", comm=TV_COMM, tag=" комиссия TV 0.055%")
    P()
    # c) 3.2
    P("=" * 100); P("c) движок 3.2 (combo_full) + те же сборки — помогает ли 7.1?"); P("=" * 100)
    for nm, (fn, coin) in BUILDS.items():
        if nm in builds32 and coin in data:
            r32, _ = go("3.2", nm, builds32[nm], coin)
            r71 = cache[("7.1", nm, coin)][0]; rpd = cache[("7.1 +PD вкл.", nm, coin)][0]
            same = abs(r32["net"] - r71["net"]) < 1e-9 and r32["trades"] == r71["trades"]
            P(f"   → 3.2 {r32['net']:+.1f}% / 7.1 {r71['net']:+.1f}% ({'идентично' if same else 'отличается'}) / "
              f"7.1+PD {rpd['net']:+.1f}% ({rpd['trades']} сд.)")
    P()
    # d) робастность
    P("=" * 100); P("d) робастность: 7.1 + сборка на всех монетах"); P("=" * 100)
    robust = {}
    for nm in ROBUST:
        if nm not in builds71:
            continue
        res = {}
        for coin in data:
            r, per = cache.get(("7.1", nm, coin)) or go("7.1", nm, builds71[nm], coin)
            res[coin] = (r, per)
        robust[nm] = res
        P(); P(f"Сводка {nm}:")
        for coin, (r, per) in res.items():
            a_, b_ = per.get("до 2025"), per.get("2025–2026")
            P(f"   {coin:5} {r['net']:+8.1f}%  сд {r['trades']:4d}  PF {r['pf']:5.2f}  DD {r['dd']:5.1f}%   "
              f"до2025 {('%+.1f%%' % a_['net']) if a_ else '—':>8}  2025-26 {('%+.1f%%' % b_['net']) if b_ else '—':>8}")
        pos = sum(1 for r, _ in res.values() if r["net"] > 0)
        P(f"   в плюсе {pos} из {len(res)} монет")
    P()
    # e) вне периода подгонки
    P("=" * 100); P("e) «вне периода подгонки»: до 2025 против 2025–2026 (7.1, свои монеты)"); P("=" * 100)
    for nm, (fn, coin) in BUILDS.items():
        k = ("7.1", nm, coin)
        if k in cache:
            per = cache[k][1]
            P(f"   {nm:18} {coin}: до 2025 {fmt_s(per.get('до 2025'))}")
            P(f"   {'':18} {coin}: 2025–26 {fmt_s(per.get('2025–2026'))}")
    P()
    # f) DGL
    P("=" * 100); P("f) Статистич_сетка = DGL (Distribution-Gated Ladder Grid), дефолты Pine, 1H"); P("=" * 100)
    dpos = 0; dn_ = 0
    for coin, d in data.items():
        tr, dd, fin, mn = dgl_run(d)
        dn_ += 1
        net = (fin / INIT - 1) * 100
        dpos += net > 0
        ruin = mn < INIT * 0.5
        if len(tr):
            w = tr[tr.profit > 0].profit.sum(); ls = -tr[tr.profit < 0].profit.sum()
            pf = w / ls if ls > 0 else float("inf"); win = (tr.profit > 0).mean() * 100
            mid = d.index[0] + (d.index[-1] - d.index[0]) / 2
            h1 = period_stats(tr, INIT, d.index[0], mid); h2 = period_stats(tr, INIT, mid, d.index[-1] + pd.Timedelta(days=1))
            halves = f"1-я пол. {h1['net']:+.1f}%  2-я пол. {h2['net']:+.1f}%"
        else:
            pf = float("nan"); win = 0.0; halves = ""
        P(f"   {coin:5} счёт {net:+8.1f}%  циклов {len(tr):4d}  PF {pf:5.2f}  win {win:4.1f}%  макс.DD {dd * 100:5.1f}%  "
          f"разорение: {'ДА' if ruin else 'нет'}   {halves}")
    P(f"   DGL в плюсе {dpos} из {dn_} монет")
    P()
    # 5) вердикты
    P("=" * 100); P("ВЕРДИКТЫ"); P("=" * 100)
    for nm, (fn, coin) in BUILDS.items():
        k = ("7.1", nm, coin)
        if k not in cache:
            P(f"❓ {nm}: нет данных"); continue
        r, per = cache[k]
        h1, h2 = per.get("1-я половина"), per.get("2-я половина")
        both = bool(h1 and h2 and h1["net"] > 0 and h2["net"] > 0)
        if nm in robust:
            others = {c: v for c, v in robust[nm].items() if c != coin}
            share = sum(1 for v in others.values() if v[0]["net"] > 0) / max(len(others), 1)
            rob = f"плюс на {share * 100:.0f}% других монет"
        else:
            share = None; rob = "робастность не гонялась (сборка-вариант XRP)"
        ok = both and share is not None and share >= 0.6
        if ok:
            P(f"✅ {nm}: {coin} {r['net']:+.1f}%, обе половины в плюсе, {rob}")
        else:
            why = []
            if r["net"] <= 0:
                why.append(f"на своей монете {coin} минус ({r['net']:+.1f}%)")
            elif not both:
                why.append(f"на {coin} не обе половины в плюсе ({h1['net'] if h1 else 0:+.1f}% / {h2['net'] if h2 else 0:+.1f}%) — подгонка под период")
            if share is not None and share < 0.6:
                why.append(f"{rob} (<60%) — подгонка под {coin}")
            elif share is None:
                why.append(rob)
            P(f"❌ {nm}: " + "; ".join(why))
    P(f"Статистич_сетка (DGL): {'✅' if dn_ and dpos / dn_ >= 0.6 else '❌'} в плюсе {dpos}/{dn_} монет (дефолты, 1H)")
    P()
    P(f"Время выполнения: {time.time() - T0:.0f} c")
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text("\n".join(lines), encoding="utf-8")
    print(f"\nОтчёт: {OUT}")


if __name__ == "__main__":
    main()
