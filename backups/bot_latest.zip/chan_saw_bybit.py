"""chan_saw_bybit.py — 2026-10-20. «Пила» ТФ 1h…12h для пробоя канала 100 (тейк 2R, стоп у центра) на свечах BYBIT
(откуда бот берёт сигналы) с комиссией Bybit. Две комиссии: 0.09% на сторону (тейкер, как у пользователя) и
0.055% (стандартный тейкер) — чтобы видеть, сколько съедает комиссия. 12 монет, ~3 года 1h-свечей Bybit.
✅ = итог > 0, ≥ 8/12 монет, обе половины > 0. Ничего не торгует.
Запуск: chan_saw_bybit.bat → bt_lab_bots/chan_saw_bybit.txt (кеш свечей: market_cache/bybit_1h_3y_12coins.pkl)
"""
from __future__ import annotations
import pickle, sys, time
from pathlib import Path
import numpy as np
import requests
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import chan_speed_test as CS  # noqa: E402  (быстрый расчёт канала, тот же алгоритм)
OUT = BASE / "bt_lab_bots" / "chan_saw_bybit.txt"
CACHE = BASE / "market_cache" / "bybit_1h_3y_12coins.pkl"
COINS = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT", "DOGEUSDT", "ADAUSDT", "SUIUSDT", "LINKUSDT", "AVAXUSDT",
         "BNBUSDT", "NEARUSDT", "HYPEUSDT"]
FEES = [(0.0009, "Bybit тейкер 0.09%"), (0.00055, "Bybit 0.055%")]
LINES = []
def say(s=""):
    print(s, flush=True); LINES.append(s)

def bybit_1h(sym, total=3 * 365 * 24):
    rows, end = [], None
    while len(rows) < total:
        p = {"category": "linear", "symbol": sym, "interval": "60", "limit": 1000}
        if end:
            p["end"] = end
        j = None
        for k in range(5):
            try:
                j = requests.get("https://api.bybit.com/v5/market/kline", params=p, timeout=20).json(); break
            except requests.RequestException:
                time.sleep(2 * (k + 1))
        lst = (j or {}).get("result", {}).get("list") or []
        if not lst:
            break
        rows += lst; end = int(lst[-1][0]) - 1
        if len(lst) < 1000:
            break
        time.sleep(0.12)
    rows = sorted({int(r[0]): r for r in rows}.values(), key=lambda r: int(r[0]))
    now = int(time.time() * 1000)
    rows = [r for r in rows if int(r[0]) + 3600_000 <= now]      # только закрытые
    a = np.array([[float(x) for x in r[:5]] for r in rows])
    return {"t": a[:, 0].astype(np.int64), "h": a[:, 2], "l": a[:, 3], "c": a[:, 4]}

def main():
    say(f"«Пила» ТФ 1h…12h · пробой канала 100 (2R, стоп центр) · свечи BYBIT · {time.strftime('%Y-%m-%d %H:%M')}")
    if CACHE.exists() and time.time() - CACHE.stat().st_mtime < 5 * 86400:
        raw = pickle.loads(CACHE.read_bytes())
    else:
        raw = {}
        for s in COINS:
            print(f"  качаю {s} 1h с Bybit…", flush=True)
            try:
                raw[s] = bybit_1h(s)
            except Exception as exc:  # noqa: BLE001
                print(f"  {s}: {exc}", flush=True)
        CACHE.parent.mkdir(exist_ok=True); CACHE.write_bytes(pickle.dumps(raw))
    raw = {s: d for s, d in raw.items() if len(d["c"]) >= 3000}
    months = np.median([(d["t"][-1] - d["t"][0]) / (30.4 * 864e5) for d in raw.values()])
    say(f"Монет {len(raw)} · истории ~{months * 30.4:.0f} дней")
    for fee, fname in FEES:
        CS.FEE = fee
        say(""); say(f"=== комиссия {fname} на сторону ===")
        say(f"{'ТФ':<5}{'итог R':>9}{'R/мес':>8}{'монет +':>9}{'1-я':>9}{'2-я':>9}{'сделок':>8}")
        per_tf = {}
        for k in range(1, 13):
            tot, h1, h2, plus, n, per = 0.0, 0.0, 0.0, 0, 0, {}
            for s, d0 in raw.items():
                d = CS.rs(d0, k * 3600_000) if k > 1 else d0
                tr = CS.chan_trades(d, 2.0, 1.0)
                if not tr:
                    continue
                mid = d["t"][len(d["t"]) // 2]
                r = sum(x[1] for x in tr); per[s] = r
                tot += r; n += len(tr); plus += r > 0
                h1 += sum(x[1] for x in tr if x[0] < mid); h2 += sum(x[1] for x in tr if x[0] >= mid)
            ok = tot > 0 and plus >= 8 and h1 > 0 and h2 > 0
            per_tf[k] = per
            say(f"{str(k) + 'h':<5}{tot:>+9.1f}{tot / months:>+8.2f}{f'{plus}/{len(raw)}':>9}{h1:>+9.1f}{h2:>+9.1f}{n:>8}  {'✅' if ok else '❌'}")
        if fee == FEES[0][0]:
            say(""); say("По монетам (R), комиссия 0.09%:")
            say(f"{'монета':<9}" + "".join(f"{str(k) + 'h':>7}" for k in range(1, 13)))
            for s in raw:
                say(f"{s.replace('USDT', ''):<9}" + "".join(f"{per_tf[k].get(s, 0):>+7.1f}" for k in range(1, 13)))
    say(""); say("Сравни с OKX (chan_saw_test.txt): 1h +229R, 2h +204R, 4h +135R при 0.05%.")
    OUT.parent.mkdir(exist_ok=True); OUT.write_text("\n".join(LINES), encoding="utf-8"); print(f"\nОтчёт: {OUT}")

if __name__ == "__main__":
    main()
