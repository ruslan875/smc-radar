@echo off
REM Double-click this file to start the SMC signal bot.
REM It assumes this .bat sits in the project root, next to main.py and venv\.

cd /d "%~dp0"

if not exist "venv\Scripts\activate.bat" (
    echo venv not found next to this file. Run the setup steps from the
    echo instructions first ^(python -m venv venv, pip install -r requirements.txt^).
    pause
    exit /b 1
)

call venv\Scripts\activate.bat
python main.py

echo.
echo Bot stopped ^(Ctrl+C or error above^). Press any key to close this window.
pause >nul