@echo off
REM Double-click this file to RESTART the kc_roc_cci_wt_grid live grid bot:
REM it stops any already-running copy (however it was started -- a
REM PowerShell window, this same .bat before, doesn't matter), waits a
REM moment for Bybit's connection to release, then starts a fresh one in
REM its own new window with the flags below.
REM
REM If you ever change how you run the bot (different --capital-per-deal,
REM --max-concurrent-deals, --symbol list, etc.), edit the ARGS line below
REM to match -- this always launches with exactly these flags.

cd /d "%~dp0"

REM 2026-09-13: --capital-per-deal podnyat s umolchaniya 20 do 30.
REM PRICHINA: minimalnyy lot ETH na Bybit -- 0.01 ETH (~25 USDT pri cene
REM ~2500). Pri capital-per-deal 20 obe nogi setki okruglyalis vverh do
REM etogo minimuma: bazovyy order ~25 USDT vmesto 13, noga -3% ~24 USDT
REM vmesto 7. Realnaya sdelka po ETH -- okolo 49 USDT vmesto 20.
REM VAZHNO: podnyatie NE uvelichivaet risk po ETH. ETH uperlsya v
REM minimalnyy lot i ostayotsya ~49 USDT pri lyubom znachenii vplot do 70.
REM Rastut ostalnye pyat monet -- oni dogonyayut ETH, i portfel
REM perestayot byt perekoshennym v odnu monetu.
REM Hudshiy sluchay pri limite 3 sdelok: bylo ~89 USDT, stalo ~109 USDT.
REM Chtoby ETH sovpal s zadaniem tochno, nuzhno 50 -- togda hudshiy
REM sluchay ~149 USDT. Vybrano 30 po pryamoy prosbe vladeltsa:
REM "podnyat ne namnogo".
set ARGS=--live --max-concurrent-deals 3 --capital-per-deal 30

if not exist "venv\Scripts\python.exe" (
    echo venv not found next to this file. Run the setup steps from the
    echo instructions first ^(python -m venv venv, pip install -r requirements.txt^).
    pause
    exit /b 1
)

echo Stopping any running kc_roc_cci_wt_grid_live.py ...
REM 2026-09-13: to zhe ispravlenie, chto i v restart_all.bat -- taskkill
REM derevom vmesto Stop-Process po odnomu processu, povtornye prohody i
REM proverka rezultata. Staryy variant molcha shel dalshe pri lyuboy
REM oshibke i zapuskal vtoruyu kopiyu poverh vyzhivshey.
powershell -NoProfile -Command "$ErrorActionPreference='Continue'; $pat='kc_roc_cci_wt_grid_live\.py'; for($n=1;$n -le 5;$n++){ $ps=@(Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match $pat }); if($ps.Count -eq 0){ break }; Write-Host ('  prohod ' + $n + ': processov ' + $ps.Count); foreach($p in $ps){ & taskkill /PID $p.ProcessId /T /F *>$null }; Start-Sleep -Seconds 2 }; $left=@(Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match $pat }); if($left.Count -gt 0){ Write-Host ('  VYZHILO PROCESSOV: ' + $left.Count); exit 1 } else { Write-Host '  vse ostanovleny' }"

if errorlevel 1 (
    echo.
    echo Ostanovka ne udalas -- novuyu kopiyu NE zapuskayu.
    echo Zakroy okno bota vruchnuyu i zapusti etot fail snova.
    pause
    exit /b 1
)

REM give Bybit / the OS a moment to release the old connection before the new one opens
timeout /t 2 /nobreak >nul

echo Starting: python kc_roc_cci_wt_grid_live.py %ARGS%
.\venv\Scripts\python.exe launch_hidden.py kc_roc_grid_live kc_roc_cci_wt_grid_live.py %ARGS%

echo.
echo Done -- the bot is now running in its own new window titled "kc_roc_cci_wt_grid_live".
echo This window will close itself in a few seconds.
timeout /t 3 >nul
