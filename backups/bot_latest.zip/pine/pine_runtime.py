"""
Рантайм для Pine-скриптов, переведённых в Python.

Каждая pine-серия здесь -- pandas.Series, выровненная по индексу исходного
DataFrame. Функции повторяют семантику Pine v5/v6, включая сглаживание RMA
(Wilder) там, где его использует TradingView: ta.rsi, ta.atr, ta.dmi.
"""
from __future__ import annotations

import re
import numpy as np
import pandas as pd

# ---------------------------------------------------------------- базовое --

def _s(x, like=None):
    """Приводит скаляр к Series, если нужно выровнять с другой серией."""
    if isinstance(x, pd.Series):
        return x
    if like is None:
        return x
    return pd.Series(x, index=like.index, dtype=float)


def _bool(x):
    """Приводит к булевой серии: na в Pine ложно, а не ошибка."""
    if isinstance(x, pd.Series):
        if x.dtype == bool:
            return x
        # через numpy, иначе pandas ругается на приведение object-колонок
        return pd.Series(np.where(x.isna().to_numpy(), False, x.to_numpy()),
                         index=x.index).astype(bool)
    return bool(x) if x is not None and x == x else False


def na(x):
    """Pine na(x) -- проверка на отсутствие значения."""
    if isinstance(x, pd.Series):
        return x.isna()
    return x is None or (isinstance(x, float) and np.isnan(x))


def nz(x, replacement=0.0):
    if isinstance(x, pd.Series):
        return x.fillna(replacement)
    return replacement if (x is None or (isinstance(x, float) and np.isnan(x))) else x


def iff(cond, a, b):
    """Тернарный оператор Pine: cond ? a : b (векторизованный)."""
    if isinstance(cond, pd.Series):
        a = _s(a, cond)
        b = _s(b, cond)
        return pd.Series(np.where(_bool(cond), a, b), index=cond.index)
    return a if cond else b


def and_(a, b):
    if isinstance(a, pd.Series) or isinstance(b, pd.Series):
        return _bool(a) & _bool(b)
    return _bool(a) and _bool(b)


def or_(a, b):
    if isinstance(a, pd.Series) or isinstance(b, pd.Series):
        return _bool(a) | _bool(b)
    return _bool(a) or _bool(b)


def not_(a):
    if isinstance(a, pd.Series):
        return ~_bool(a)
    return not _bool(a)


def shift(x, n=1):
    """Pine x[n]."""
    if isinstance(x, pd.Series):
        return x.shift(n)
    return x


# ------------------------------------------------------------ сглаживания --

def rma(src: pd.Series, length: int) -> pd.Series:
    """Wilder's smoothing -- основа rsi/atr/dmi в Pine."""
    return src.ewm(alpha=1.0 / length, adjust=False, min_periods=length).mean()


def sma(src: pd.Series, length: int) -> pd.Series:
    return src.rolling(length).mean()


def ema(src: pd.Series, length: int) -> pd.Series:
    return src.ewm(span=length, adjust=False, min_periods=length).mean()


def wma(src: pd.Series, length: int) -> pd.Series:
    w = np.arange(1, length + 1, dtype=float)
    return src.rolling(length).apply(lambda v: np.dot(v, w) / w.sum(), raw=True)


def stdev(src: pd.Series, length: int) -> pd.Series:
    # Pine использует популяционное отклонение (ddof=0)
    return src.rolling(length).std(ddof=0)


def variance(src: pd.Series, length: int) -> pd.Series:
    return src.rolling(length).var(ddof=0)


# ------------------------------------------------------------ индикаторы --

def change(src: pd.Series, length: int = 1) -> pd.Series:
    return src.diff(length)


def roc(src: pd.Series, length: int) -> pd.Series:
    return (src - src.shift(length)) / src.shift(length) * 100.0


def highest(src: pd.Series, length: int) -> pd.Series:
    return src.rolling(length).max()


def lowest(src: pd.Series, length: int) -> pd.Series:
    return src.rolling(length).min()


def rsi(src: pd.Series, length: int) -> pd.Series:
    d = src.diff()
    up = rma(d.clip(lower=0), length)
    down = rma((-d).clip(lower=0), length)
    return 100.0 - 100.0 / (1.0 + up / down.replace(0, np.nan))


def true_range(df: pd.DataFrame) -> pd.Series:
    pc = df["close"].shift(1)
    return pd.concat([
        df["high"] - df["low"],
        (df["high"] - pc).abs(),
        (df["low"] - pc).abs(),
    ], axis=1).max(axis=1)


def atr(df: pd.DataFrame, length: int) -> pd.Series:
    return rma(true_range(df), length)


def cci(src: pd.Series, length: int) -> pd.Series:
    ma = src.rolling(length).mean()
    md = src.rolling(length).apply(lambda v: np.abs(v - v.mean()).mean(), raw=True)
    return (src - ma) / (0.015 * md)


def wpr(df: pd.DataFrame, length: int) -> pd.Series:
    hh = df["high"].rolling(length).max()
    ll = df["low"].rolling(length).min()
    return (hh - df["close"]) / (hh - ll) * -100.0


def dmi(df: pd.DataFrame, di_len: int, adx_len: int):
    """Возвращает (+DI, -DI, ADX) -- как ta.dmi в Pine."""
    up = df["high"].diff()
    dn = -df["low"].diff()
    plus_dm = pd.Series(np.where((up > dn) & (up > 0), up, 0.0), index=df.index)
    minus_dm = pd.Series(np.where((dn > up) & (dn > 0), dn, 0.0), index=df.index)
    tr = rma(true_range(df), di_len)
    plus_di = 100.0 * rma(plus_dm, di_len) / tr
    minus_di = 100.0 * rma(minus_dm, di_len) / tr
    dx = 100.0 * (plus_di - minus_di).abs() / (plus_di + minus_di)
    return plus_di, minus_di, rma(dx, adx_len)


def sar(df: pd.DataFrame, start=0.02, inc=0.02, maximum=0.2) -> pd.Series:
    """Параболик SAR. Итеративно -- векторизовать нечем, состояние по барам."""
    high, low = df["high"].to_numpy(), df["low"].to_numpy()
    n = len(df)
    out = np.full(n, np.nan)
    if n < 2:
        return pd.Series(out, index=df.index)

    long = True
    af = start
    ep = high[0]
    sar_v = low[0]

    for i in range(1, n):
        sar_v = sar_v + af * (ep - sar_v)
        if long:
            sar_v = min(sar_v, low[i - 1], low[max(0, i - 2)])
            if low[i] < sar_v:
                long, sar_v, ep, af = False, ep, low[i], start
            elif high[i] > ep:
                ep, af = high[i], min(af + inc, maximum)
        else:
            sar_v = max(sar_v, high[i - 1], high[max(0, i - 2)])
            if high[i] > sar_v:
                long, sar_v, ep, af = True, ep, high[i], start
            elif low[i] < ep:
                ep, af = low[i], min(af + inc, maximum)
        out[i] = sar_v

    return pd.Series(out, index=df.index)


def crossover(a, b) -> pd.Series:
    a, b = _s(a, b if isinstance(b, pd.Series) else None), _s(b, a if isinstance(a, pd.Series) else None)
    return (a > b) & (a.shift(1) <= b.shift(1))


def crossunder(a, b) -> pd.Series:
    a, b = _s(a, b if isinstance(b, pd.Series) else None), _s(b, a if isinstance(a, pd.Series) else None)
    return (a < b) & (a.shift(1) >= b.shift(1))


def cross(a, b) -> pd.Series:
    return crossover(a, b) | crossunder(a, b)


def barssince(cond: pd.Series) -> pd.Series:
    idx = np.arange(len(cond))
    last = np.where(_bool(cond).to_numpy(), idx, np.nan)
    last = pd.Series(last, index=cond.index).ffill()
    return pd.Series(idx, index=cond.index) - last


def valuewhen(cond: pd.Series, src: pd.Series, occurrence: int = 0) -> pd.Series:
    masked = src.where(_bool(cond))
    out = masked.ffill()
    for _ in range(occurrence):
        masked = masked.where(_bool(cond)).shift(1)
        out = masked.ffill()
    return out


def math_sum(src: pd.Series, length: int) -> pd.Series:
    return src.rolling(length).sum()


# ------------------------------------------------- мультитаймфрейм (MTF) --

_TF_MINUTES = {"D": 1440, "W": 10080, "M": 43200}


def tf_to_minutes(tf: str) -> int:
    """'30' -> 30, '1D' -> 1440, '4H' -> 240."""
    tf = str(tf).strip().upper()
    if tf.isdigit():
        return int(tf)
    m = re.fullmatch(r"(\d*)([SDWMH])", tf)
    if not m:
        raise ValueError(f"не разобран таймфрейм: {tf!r}")
    mult = int(m.group(1) or 1)
    unit = m.group(2)
    if unit == "H":
        return mult * 60
    if unit == "S":
        return max(1, mult // 60)
    return mult * _TF_MINUTES[unit]


def security(df: pd.DataFrame, tf, fn, time_col: str = "open_time") -> pd.Series:
    """
    request.security(..., tf, expr) с lookahead_off.

    Ресемплит df на старший таймфрейм, считает выражение на нём и
    возвращает значение ПОСЛЕДНЕГО ЗАКРЫТОГО бара -- без заглядывания
    вперёд, как это делает TradingView по умолчанию.
    """
    minutes = tf_to_minutes(tf)
    base = df.copy()

    if time_col in base.columns:
        t = pd.to_datetime(base[time_col], utc=True)
    else:
        t = pd.to_datetime(base.index, utc=True)

    htf = (base.assign(_t=t)
               .set_index("_t")
               .resample(f"{minutes}min", label="left", closed="left")
               .agg({"open": "first", "high": "max", "low": "min",
                     "close": "last", "volume": "sum"})
               .dropna(how="all"))

    keys = t.dt.floor(f"{minutes}min").to_numpy()

    def _map(value):
        if not isinstance(value, pd.Series):
            value = pd.Series(value, index=htf.index, dtype=float)
        # сдвиг на один HTF-бар: значение доступно только после закрытия
        mapped = value.shift(1).reindex(keys, method="ffill")
        return pd.Series(mapped.to_numpy(), index=df.index)

    result = fn(htf)
    # ta.dmi и подобные возвращают кортеж -- разворачиваем поэлементно
    if isinstance(result, tuple):
        return tuple(_map(v) for v in result)
    return _map(result)