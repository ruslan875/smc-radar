# Pine Script → Python

Транспайлер подмножества Pine Script v5/v6 в Python поверх pandas. Пишете
стратегию на Pine, запускаете её локально на данных Bybit — без TradingView.

## Запуск

Из `D:\VANTORIX\bot`:

```powershell
# сигналы + диагностика переменных
python pine\run_pine.py --file cci_rsi_entries.pine --symbol ARBUSDT --bars 30000 --diagnose

# сигналы + сделки + график
python pine\run_pine.py --file cci_rsi_entries.pine --symbol ARBUSDT --bars 30000 --backtest --tp 1.0 --sl 2.0

# посмотреть сгенерированный Python, не запуская
python pine\run_pine.py --file my.pine --no-run --emit my_generated.py

# переопределить input по его заголовку
python pine\run_pine.py --file etnar_entries.pine --symbol ARBUSDT --bars 30000 --set "Порог ADX (15m) — CONFIRMED с площадки=20"
```

Данные грузятся тем же `fetch_history` из `kc_roc_cci_wt_grid_backtest.py`,
поэтому результаты сопоставимы с остальными бэктестами проекта.

## Что переводится

| Pine | Python |
|---|---|
| `ta.sma/ema/wma/rma/stdev/rsi/cci/roc/atr/wpr/dmi/sar/change/highest/lowest` | функции `pine_runtime` |
| `ta.crossover/crossunder/cross/barssince/valuewhen` | то же |
| `math.sum/min/max/abs/round/sqrt/pow/log` | numpy |
| `request.security(tickerid, "30", expr)` | ресемпл на 30m, расчёт, сдвиг на закрытый бар |
| `input.int/float/bool/string` | значение по умолчанию, переопределяется `--set` |
| `x[1]`, `cond ? a : b`, `and/or/not` | сдвиг серии, векторный выбор, булева логика |
| `f(src, len) => ...` | вложенная функция, последнее выражение — возврат |
| `[a, b, c] = ta.dmi(...)` | распаковка кортежа |

`request.security` работает без заглядывания вперёд: значение старшего
таймфрейма становится доступным только после закрытия его бара — как в
TradingView по умолчанию.

## Что игнорируется

Оформление графика логики не несёт и отбрасывается: `plot`, `hline`, `fill`,
`bgcolor`, `barcolor`, `label.*`, `line.*`, `box.*`, `table.*`, `color.*`,
`str.*`, а также блоки `if barstate.islast` целиком.

**Сигналы берутся из `plotshape(...)` и `alertcondition(...)`** — их условия и
есть результат работы скрипта. Заголовок (`title=`) становится именем сигнала.

## Чего пока нет

- `strategy.*` (entry/exit/close) — ордера не исполняются; скрипт даёт сигналы,
  а исполнение берёт на себя `--backtest` или профильный бэктест проекта
- циклы `for`/`while`, массивы, матрицы
- накопительное состояние `var` между барами (объявление не ломает разбор,
  но переменная считается обычной)
- `request.security` с `lookahead=barmerge.lookahead_on`
- многострочные `if/else` внутри логики (блок пропускается)

Для грид-стратегий с усреднением и лестницей тейков используйте
`kc_roc_cci_wt_grid_backtest.py` — встроенный `--backtest` здесь намеренно
простой: один вход, выход по TP/SL, сигналу или таймауту.

## Файлы

| Файл | Назначение |
|---|---|
| `pine_runtime.py` | индикаторы и MTF на pandas |
| `pine_transpiler.py` | лексер, парсер выражений, кодогенератор |
| `run_pine.py` | CLI: данные, расчёт, бэктест, график |

Проверено на `etnar_entries.pine`, `bb_roc_entries.pine`,
`cci_rsi_entries.pine`, `latuserge_entries.pine` — все транспилируются,
исполняются и дают сигналы.

## Диагностика

`--diagnose` печатает каждую переменную скрипта: для булевых — долю истинных
баров, для числовых — min/med/max. Если сигналов ноль, сразу видно, какое
условие не срабатывает, и в каком диапазоне реально живёт индикатор.
