"""
Транспайлер подмножества Pine Script v5/v6 в Python поверх pine_runtime.

Что переводится:
  - переменные, := , var, деструктуризация [a, b, c] = ta.dmi(...)
  - выражения: and/or/not, сравнения, арифметика, тернарник ?: , серии x[n]
  - ta.* / math.* -- в функции рантайма
  - input.* -- в параметры со значением по умолчанию (переопределяются извне)
  - request.security(tickerid, tf, expr) -- выражение считается на старшем
    таймфрейме без заглядывания вперёд

Что осознанно игнорируется (это оформление графика, а не логика):
  indicator/strategy, plot/plotshape/plotchar, hline, fill, bgcolor,
  label.*, line.*, table.*, color.*, str.*, if barstate.islast -- блок целиком.

Условия из plotshape(...) и alertcondition(...) собираются как СИГНАЛЫ:
именно они -- результат работы скрипта.
"""
from __future__ import annotations

import re

# ------------------------------------------------------------------ лексер --

TOKEN_RE = re.compile(r"""
    (?P<NUMBER>\d+\.\d*|\.\d+|\d+)
  | (?P<STRING>"(?:[^"\\]|\\.)*"|'(?:[^'\\]|\\.)*')
  | (?P<NAME>[A-Za-z_][A-Za-z_0-9]*(?:\.[A-Za-z_][A-Za-z_0-9]*)*)
  | (?P<OP>:=|==|!=|>=|<=|\?|:|\[|\]|\(|\)|,|\+|-|\*|/|%|>|<|=)
  | (?P<WS>\s+)
""", re.VERBOSE)

KEYWORDS = {"and", "or", "not", "true", "false", "na", "var", "varip", "if", "else", "for", "while"}


def tokenize(src: str) -> list[tuple[str, str]]:
    out, i = [], 0
    while i < len(src):
        m = TOKEN_RE.match(src, i)
        if not m:
            raise SyntaxError(f"неразобранный символ {src[i]!r} в {src[max(0,i-25):i+25]!r}")
        i = m.end()
        kind = m.lastgroup
        if kind == "WS":
            continue
        out.append((kind, m.group()))
    return out


# --------------------------------------------------------- карта функций --

# ta.*-функции, которым нужен весь датафрейм (в Pine источник неявный)
DF_FUNCS = {
    "ta.atr": ("atr", 1), "ta.tr": ("true_range", 0),
    "ta.dmi": ("dmi", 2), "ta.wpr": ("wpr", 1), "ta.sar": ("sar", 3),
}

SIMPLE_FUNCS = {
    "ta.sma": "sma", "ta.ema": "ema", "ta.wma": "wma", "ta.rma": "rma",
    "ta.stdev": "stdev", "ta.variance": "variance", "ta.rsi": "rsi",
    "ta.cci": "cci", "ta.roc": "roc", "ta.change": "change",
    "ta.highest": "highest", "ta.lowest": "lowest",
    "ta.crossover": "crossover", "ta.crossunder": "crossunder", "ta.cross": "cross",
    "ta.barssince": "barssince", "ta.valuewhen": "valuewhen",
    "math.sum": "math_sum",
    "nz": "nz", "na": "na",
}

MATH_INLINE = {
    "math.abs": "abs", "math.max": "_np.maximum", "math.min": "_np.minimum",
    "math.round": "_np.round", "math.floor": "_np.floor", "math.ceil": "_np.ceil",
    "math.sqrt": "_np.sqrt", "math.pow": "_np.power", "math.log": "_np.log",
    "math.exp": "_np.exp", "math.sign": "_np.sign",
}

SERIES_VARS = {"open", "high", "low", "close", "volume"}
DERIVED = {
    "hl2": '(({d}["high"] + {d}["low"]) / 2)',
    "hlc3": '(({d}["high"] + {d}["low"] + {d}["close"]) / 3)',
    "ohlc4": '(({d}["open"] + {d}["high"] + {d}["low"] + {d}["close"]) / 4)',
}

# вызовы, которые ничего не делают с логикой -- отбрасываем
IGNORED_CALLS = re.compile(
    r"^(indicator|strategy|plot|plotshape|plotchar|plotarrow|plotcandle|hline|fill|"
    r"bgcolor|barcolor|alertcondition|label\.|line\.|box\.|table\.|log\.|"
    r"strategy\.(entry|close|exit|order|cancel))"
)

SIGNAL_CALLS = ("plotshape", "plotchar", "plotarrow", "alertcondition")


# ------------------------------------------------------------- парсер выр. --

class ExprParser:
    """Рекурсивный спуск по выражению Pine -> строка Python."""

    def __init__(self, tokens, ctx_df="_df"):
        self.t = tokens
        self.i = 0
        self.df = ctx_df  # "_df" обычно, "_d" внутри request.security

    def peek(self):
        return self.t[self.i] if self.i < len(self.t) else (None, None)

    def next(self):
        tok = self.peek()
        self.i += 1
        return tok

    def accept(self, val):
        if self.peek()[1] == val:
            self.i += 1
            return True
        return False

    def expect(self, val):
        if not self.accept(val):
            raise SyntaxError(f"ожидалось {val!r}, встречено {self.peek()[1]!r}")

    # приоритеты: ?: < or < and < not < сравнения < +- < */ < унарный < постфикс
    def parse(self):
        return self.ternary()

    def ternary(self):
        cond = self.or_()
        if self.accept("?"):
            a = self.ternary()
            self.expect(":")
            b = self.ternary()
            return f"_rt.iff({cond}, {a}, {b})"
        return cond

    def or_(self):
        left = self.and_()
        while self.peek()[1] == "or":
            self.next()
            left = f"_rt.or_({left}, {self.and_()})"
        return left

    def and_(self):
        left = self.not_()
        while self.peek()[1] == "and":
            self.next()
            left = f"_rt.and_({left}, {self.not_()})"
        return left

    def not_(self):
        if self.peek()[1] == "not":
            self.next()
            return f"_rt.not_({self.not_()})"
        return self.comparison()

    def comparison(self):
        left = self.additive()
        while self.peek()[1] in ("==", "!=", ">", "<", ">=", "<="):
            op = self.next()[1]
            left = f"({left} {op} {self.additive()})"
        return left

    def additive(self):
        left = self.multiplicative()
        while self.peek()[1] in ("+", "-"):
            op = self.next()[1]
            left = f"({left} {op} {self.multiplicative()})"
        return left

    def multiplicative(self):
        left = self.unary()
        while self.peek()[1] in ("*", "/", "%"):
            op = self.next()[1]
            left = f"({left} {op} {self.unary()})"
        return left

    def unary(self):
        if self.accept("-"):
            return f"(-{self.unary()})"
        if self.accept("+"):
            return self.unary()
        return self.postfix()

    def postfix(self):
        node = self.primary()
        while self.peek()[1] == "[":
            self.next()
            idx = self.parse()
            self.expect("]")
            node = f"_rt.shift({node}, {idx})"
        return node

    def primary(self):
        kind, val = self.next()

        if kind == "NUMBER":
            return val if "." in val else f"{val}"
        if kind == "STRING":
            return val
        if val == "(":
            inner = self.parse()
            self.expect(")")
            return f"({inner})"

        if kind == "NAME":
            if self.peek()[1] == "(":
                return self.call(val)
            return self.name(val)

        raise SyntaxError(f"неожиданный токен {val!r}")

    def name(self, val):
        if val == "true":
            return "True"
        if val == "false":
            return "False"
        if val == "na":
            return "_np.nan"
        if val in SERIES_VARS:
            return f'{self.df}["{val}"]'
        if val in DERIVED:
            return DERIVED[val].format(d=self.df)
        if val.startswith(("color.", "shape.", "location.", "size.", "position.",
                           "display.", "format.", "scale.", "syminfo.", "timeframe.",
                           "barstate.", "strategy.")):
            return "None"
        return val.replace(".", "_")

    def args(self):
        """Разбирает список аргументов; именованные возвращает отдельно."""
        self.expect("(")
        pos, named = [], {}
        if self.accept(")"):
            return pos, named
        while True:
            start = self.i
            if (self.peek()[0] == "NAME" and self.i + 1 < len(self.t)
                    and self.t[self.i + 1][1] == "=" ):
                key = self.next()[1]
                self.next()  # '='
                named[key] = self.parse()
            else:
                self.i = start
                pos.append(self.parse())
            if self.accept(","):
                continue
            self.expect(")")
            return pos, named

    def call(self, fname):
        # request.security(tickerid, tf, expr) -- выражение уходит на другой ТФ
        if fname == "request.security":
            self.expect("(")
            self.parse()           # tickerid -- не используем
            self.expect(",")
            tf = self.parse()
            self.expect(",")
            sub_start = self.i
            depth = 0
            while self.i < len(self.t):
                v = self.t[self.i][1]
                if v == "(":
                    depth += 1
                elif v == ")":
                    if depth == 0:
                        break
                    depth -= 1
                elif v == "," and depth == 0:
                    break
                self.i += 1
            sub_tokens = self.t[sub_start:self.i]
            while self.accept(","):     # lookahead/gaps -- игнорируем
                self.parse()
            self.expect(")")
            inner = ExprParser(sub_tokens, ctx_df="_d").parse()
            return f"_rt.security({self.df}, {tf}, lambda _d: {inner})"

        pos, named = self.args()

        if fname.startswith("input"):
            default = pos[0] if pos else named.get("defval", "0")
            title = pos[1] if len(pos) > 1 else named.get("title", '""')
            return f"_input({title}, {default})"

        if fname in DF_FUNCS:
            rt_name, _ = DF_FUNCS[fname]
            all_args = ", ".join([self.df] + pos)
            return f"_rt.{rt_name}({all_args})"

        if fname in SIMPLE_FUNCS:
            # ta.lowest(len) без источника -> low, ta.highest(len) -> high
            if fname in ("ta.lowest", "ta.highest") and len(pos) == 1:
                src = "low" if fname.endswith("lowest") else "high"
                pos = [f'{self.df}["{src}"]'] + pos
            return f"_rt.{SIMPLE_FUNCS[fname]}({', '.join(pos)})"

        if fname in MATH_INLINE:
            return f"{MATH_INLINE[fname]}({', '.join(pos)})"

        if fname.startswith("str.") or fname.startswith("color."):
            return "None"

        return f"{fname.replace('.', '_')}({', '.join(pos)})"


# ------------------------------------------------------ разбор построчно --

def strip_comments(line: str) -> str:
    out, in_str, quote = [], False, ""
    i = 0
    while i < len(line):
        ch = line[i]
        if in_str:
            out.append(ch)
            if ch == "\\":
                if i + 1 < len(line):
                    out.append(line[i + 1])
                    i += 1
            elif ch == quote:
                in_str = False
        elif ch in "\"'":
            in_str, quote = True, ch
            out.append(ch)
        elif ch == "/" and i + 1 < len(line) and line[i + 1] == "/":
            break
        else:
            out.append(ch)
        i += 1
    return "".join(out)


def logical_lines(src: str):
    """Склеивает переносы внутри скобок и строки-продолжения с отступом."""
    raw = [strip_comments(l).rstrip() for l in src.splitlines()]
    out, buf, depth = [], "", 0
    for line in raw:
        if not line.strip():
            continue
        indent = len(line) - len(line.lstrip())
        if buf and depth == 0 and indent > 0 and not re.match(r"^\s*(if|else|for|while)\b", line):
            # продолжение выражения с отступом
            buf += " " + line.strip()
        elif buf and depth > 0:
            buf += " " + line.strip()
        else:
            if buf:
                out.append(buf)
            buf = line
        depth = buf.count("(") - buf.count(")") + buf.count("[") - buf.count("]")
    if buf:
        out.append(buf)
    return out


ASSIGN_RE = re.compile(r"^\s*(?:(var|varip)\s+)?(?:(?:float|int|bool|string|color|line|label|table|array)\s+)?"
                       r"([A-Za-z_][A-Za-z_0-9]*)\s*(:?=)(?!=)\s*(.+)$")
DESTRUCT_RE = re.compile(r"^\s*\[([^\]]+)\]\s*=\s*(.+)$")


FUNC_DEF_RE = re.compile(r"^([A-Za-z_][A-Za-z_0-9]*)\s*\(([^)]*)\)\s*=>\s*(.*)$")


def extract_functions(src: str):
    """
    Вырезает объявления Pine-функций `f(a, b) =>` вместе с телом (по отступу).

    Тело -- цепочка присваиваний, последнее выражение является возвращаемым
    значением, как и в Pine.
    """
    lines = src.splitlines()
    kept, funcs = [], []
    i = 0
    while i < len(lines):
        raw = strip_comments(lines[i]).rstrip()
        m = FUNC_DEF_RE.match(raw.strip()) if raw.strip() else None
        if m and not raw.startswith(" "):
            name, args, inline = m.group(1), m.group(2), m.group(3).strip()
            body = []
            if inline:
                body.append(inline)
            i += 1
            while i < len(lines):
                nxt = strip_comments(lines[i]).rstrip()
                if nxt.strip() and not nxt.startswith((" ", "\t")):
                    break
                if nxt.strip():
                    body.append(nxt.strip())
                i += 1
            funcs.append((name, [a.strip() for a in args.split(",") if a.strip()], body))
            continue
        kept.append(lines[i])
        i += 1
    return "\n".join(kept), funcs


def compile_function(name, args, body) -> list[str]:
    out = [f"def {name}({', '.join(args)}):"]
    stmts = []
    for line in body:
        m = ASSIGN_RE.match(line)
        if m and m.group(3) in ("=", ":="):
            stmts.append((m.group(2), ExprParser(tokenize(m.group(4))).parse()))
        else:
            stmts.append((None, ExprParser(tokenize(line)).parse()))
    for var_name, expr in stmts[:-1]:
        out.append(f"    {var_name} = {expr}" if var_name else f"    {expr}")
    last_name, last_expr = stmts[-1]
    out.append(f"    {last_name} = {last_expr}" if last_name else "")
    out.append(f"    return {last_name or last_expr}")
    return [l for l in out if l != ""]


def transpile(src: str) -> str:
    body, signals = [], []
    src, funcs = extract_functions(src)
    for fname, fargs, fbody in funcs:
        body.extend(compile_function(fname, fargs, fbody))
        body.append("")
    lines = logical_lines(src)
    skip_indent = None

    for line in lines:
        indent = len(line) - len(line.lstrip())
        stripped = line.strip()

        # пропуск блока if ... (визуальные таблицы и т.п.)
        if skip_indent is not None:
            if indent > skip_indent:
                continue
            skip_indent = None

        if stripped.startswith("//") or stripped.startswith("@"):
            continue
        if re.match(r"^(if|for|while)\b", stripped):
            skip_indent = indent
            continue

        # сигналы: plotshape / alertcondition
        m_sig = re.match(r"^(" + "|".join(SIGNAL_CALLS) + r")\s*\((.*)\)\s*$", stripped)
        if m_sig:
            try:
                p = ExprParser(tokenize("(" + m_sig.group(2) + ")"))
                p.expect("(")
                pos, named = [], {}
                while True:
                    start = p.i
                    if (p.peek()[0] == "NAME" and p.i + 1 < len(p.t) and p.t[p.i + 1][1] == "="):
                        k = p.next()[1]; p.next()
                        named[k] = p.parse()
                    else:
                        p.i = start
                        pos.append(p.parse())
                    if p.accept(","):
                        continue
                    break
                cond = pos[0] if pos else None
                title = named.get("title") or (pos[1] if len(pos) > 1 else '"signal"')
                if cond and cond != "None":
                    signals.append((title, cond))
            except SyntaxError:
                pass
            continue

        if IGNORED_CALLS.match(stripped):
            continue

        m = DESTRUCT_RE.match(stripped)
        if m:
            names = [n.strip().replace(".", "_") for n in m.group(1).split(",")]
            expr = ExprParser(tokenize(m.group(2))).parse()
            body.append(f"{', '.join(names)} = {expr}")
            continue

        m = ASSIGN_RE.match(stripped)
        if m:
            # var table t = table.new(...) -- объект оформления, не логика
            if re.match(r"^(table|label|line|box|array|matrix|color)\.", m.group(4).strip()):
                continue
            name = m.group(2)
            expr = ExprParser(tokenize(m.group(4))).parse()
            body.append(f"{name} = {expr}")
            continue

        # выражение-строка без присваивания -- логики не несёт
        continue

    sig_items = ",\n        ".join(f"({t}): {c}" for t, c in signals) or ""
    code = [
        "import numpy as _np",
        "import pandas as _pd",
        "import pine_runtime as _rt",
        "",
        "",
        "def run(_df, _params=None):",
        "    _params = _params or {}",
        "    _used = {}",
        "    def _input(_title, _default):",
        "        _key = str(_title)",
        "        _val = _params.get(_key, _default)",
        "        _used[_key] = _val",
        "        return _val",
        "",
    ]
    code += [f"    {l}" for l in body]
    code += [
        "",
        f"    _signals = {{\n        {sig_items}\n    }}",
        "    _vars = {k: v for k, v in list(locals().items())",
        "             if isinstance(v, _pd.Series) and not k.startswith('_')}",
        "    return {'signals': _signals, 'inputs': _used, 'vars': _vars}",
        "",
    ]
    return "\n".join(code)
