#!/usr/bin/env python3
"""
Запуск Pine-скрипта на исторических данных: транспиляция в Python,
расчёт сигналов, опциональный бэктест и график.

Примеры:
    python pine\\run_pine.py --file etnar_entries.pine --symbol ARBUSDT --bars 30000 --diagnose
    python pine\\run_pine.py --file cci_rsi_entries.pine --symbol ARBUSDT --bars 30000 --backtest
    python pine\\run_pine.py --file my.pine --emit my_generated.py --no-run

Скрипт не исполняет оформление графика (plot, table, label) -- только логику.
Условия из plotshape() и alertcondition() становятся сигналами.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(PARENT))

import pandas as pd

import pine_transpiler
import pine_runtime  # noqa: F401  -- нужен в namespace сгенерированного кода


def load_history(symbol: str, timeframe: str, bars: int) -> pd.DataFrame:
    """Берёт загрузчик из основного бэктеста, чтобы данные были те же."""
    from kc_roc_cci_wt_grid_backtest import fetch_history
    return fetch_history(symbol, timeframe, bars)


def run_script(path: Path, df: pd.DataFrame, params: dict | None = None,
               emit: Path | None = None) -> dict:
    code = pine_transpiler.transpile(path.read_text(encoding="utf-8"))
    if emit:
        emit.write_text(code, encoding="utf-8")
        print(f"   сгенерированный Python: {emit.resolve()}")
    ns: dict = {}
    exec(compile(code, str(path), "exec"), ns)
    return ns["run"](df, params or {})


def print_diagnostics(result: dict) -> None:
    print("\n   Входные параметры скрипта:")
    for k, v in result["inputs"].items():
        print(f"     {v!r:>12}  {k}")

    print("\n   Переменные (булевы -- доля истинных баров):")
    for k, v in result["vars"].items():
        if v.dtype == bool:
            print(f"     {v.mean() * 100:6.2f}%  {k}")
    for k, v in result["vars"].items():
        if v.dtype != bool:
            s = v.dropna()
            if len(s):
                print(f"     {k:18s} min={s.min():12.4f} med={s.median():12.4f} max={s.max():12.4f}")


def simple_backtest(df: pd.DataFrame, entry: pd.Series, exit_sig: pd.Series | None,
                    tp_pct: float, sl_pct: float, max_bars: int) -> list[dict]:
    """
    Прямолинейный движок: один вход по сигналу, выход по TP/SL, по сигналу
    выхода или по таймауту. Нужен, чтобы увидеть сигналы на графике, --
    для гридов и усреднений используйте профильный бэктест.
    """
    e = entry.fillna(False).to_numpy(dtype=bool)
    x = exit_sig.fillna(False).to_numpy(dtype=bool) if exit_sig is not None else None
    high, low, close = df["high"].to_numpy(), df["low"].to_numpy(), df["close"].to_numpy()

    trades, i, n = [], 0, len(df)
    while i < n - 1:
        if not e[i]:
            i += 1
            continue

        entry_price = close[i]
        tp = entry_price * (1 + tp_pct / 100.0)
        sl = entry_price * (1 - sl_pct / 100.0)

        j = i + 1
        while j < n:
            if low[j] <= sl:
                out, reason = sl, "SL"
                break
            if high[j] >= tp:
                out, reason = tp, "TP"
                break
            if x is not None and x[j]:
                out, reason = close[j], "signal"
                break
            if j - i >= max_bars:
                out, reason = close[j], "timeout"
                break
            j += 1
        else:
            break

        pnl_pct = (out - entry_price) / entry_price * 100.0
        trades.append({
            "entry_index": i, "exit_index": j,
            "entry_price": float(entry_price), "exit_price": float(out),
            "stop_loss": float(sl), "take_profit_2": float(tp),
            "direction": "LONG", "pnl": float(pnl_pct),
            "pnl_percent": float(pnl_pct), "exit_reason": reason,
        })
        i = j + 1

    return trades


def main() -> None:
    ap = argparse.ArgumentParser(description="Pine Script -> Python: расчёт и бэктест")
    ap.add_argument("--file", required=True, help="путь к .pine")
    ap.add_argument("--symbol", default="BTCUSDT")
    ap.add_argument("--timeframe", default="1m")
    ap.add_argument("--bars", type=int, default=20000)
    ap.add_argument("--emit", help="сохранить сгенерированный Python в файл")
    ap.add_argument("--no-run", action="store_true", help="только транспиляция")
    ap.add_argument("--diagnose", action="store_true", help="показать переменные скрипта")
    ap.add_argument("--set", action="append", default=[], metavar="ИМЯ=ЗНАЧЕНИЕ",
                    help="переопределить input по его заголовку")

    ap.add_argument("--backtest", action="store_true", help="прогнать сделки и построить график")
    ap.add_argument("--entry-signal", default=None, help="заголовок сигнала входа")
    ap.add_argument("--exit-signal", default=None, help="заголовок сигнала выхода")
    ap.add_argument("--tp", type=float, default=1.0, help="тейк, %%")
    ap.add_argument("--sl", type=float, default=2.0, help="стоп, %%")
    ap.add_argument("--max-bars-in-trade", type=int, default=500)
    ap.add_argument("--out", default="pine_out")

    args = ap.parse_args()
    path = Path(args.file)
    if not path.is_absolute() and not path.exists():
        path = PARENT / args.file

    params = {}
    for item in args.set:
        k, _, v = item.partition("=")
        try:
            params[k] = float(v) if "." in v else int(v)
        except ValueError:
            params[k] = v

    print("\n" + "=" * 70)
    print(f"PINE -> PYTHON: {path.name}")
    print("=" * 70)

    if args.no_run:
        code = pine_transpiler.transpile(path.read_text(encoding="utf-8"))
        target = Path(args.emit) if args.emit else HERE / (path.stem + "_generated.py")
        target.write_text(code, encoding="utf-8")
        print(f"Готово: {target.resolve()}")
        return

    print(f"Данные: {args.symbol} {args.bars}×{args.timeframe}")
    df = load_history(args.symbol, args.timeframe, args.bars)

    result = run_script(path, df, params, Path(args.emit) if args.emit else None)

    print("\n   Сигналы:")
    for title, series in result["signals"].items():
        if isinstance(series, pd.Series):
            b = series.fillna(False).astype(bool)
            print(f"     {int(b.sum()):6d}  {title}")
        else:
            print(f"     {'—':>6}  {title} (не серия)")

    if args.diagnose:
        print_diagnostics(result)

    if not args.backtest:
        return

    sigs = {str(k): v for k, v in result["signals"].items() if isinstance(v, pd.Series)}
    if not sigs:
        print("\n   Сигналов нет -- бэктест пропущен")
        return

    entry_key = args.entry_signal or next(
        (k for k in sigs if "ВХОД" in k.upper() or "ENTRY" in k.upper()), list(sigs)[0])
    exit_key = args.exit_signal
    if exit_key is None:
        exit_key = next((k for k in sigs if k != entry_key and
                         ("ВЫХОД" in k.upper() or "EXIT" in k.upper())), None)

    print(f"\n   Вход:  {entry_key}")
    print(f"   Выход: {exit_key or f'только TP {args.tp}% / SL {args.sl}%'}")

    trades = simple_backtest(df, sigs[entry_key], sigs.get(exit_key) if exit_key else None,
                             args.tp, args.sl, args.max_bars_in_trade)
    print(f"   Сделок: {len(trades)}")
    if not trades:
        return

    wins = sum(1 for t in trades if t["pnl"] > 0)
    avg = sum(t["pnl"] for t in trades) / len(trades)
    reasons: dict[str, int] = {}
    for t in trades:
        reasons[t["exit_reason"]] = reasons.get(t["exit_reason"], 0) + 1
    print(f"   Win rate: {wins / len(trades) * 100:.1f}%   средний P&L: {avg:+.3f}%")
    print(f"   Выходы: {reasons}")

    from backtest_visualizer import BacktestVisualizer
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    lo = max(0, trades[0]["entry_index"] - 80)
    hi = min(len(df) - 1, trades[min(len(trades), 12) - 1]["exit_index"] + 80)
    win_df = df.iloc[lo:hi + 1].reset_index(drop=True)
    win_trades = [dict(t, entry_index=t["entry_index"] - lo, exit_index=t["exit_index"] - lo)
                  for t in trades if lo <= t["entry_index"] and t["exit_index"] <= hi]

    if win_trades:
        viz = BacktestVisualizer(win_df, win_trades, symbol=args.symbol, timeframe=args.timeframe)
        fig, _ = viz.plot_trades(figsize=(18, 10), bars_visible=len(win_df))
        png = out_dir / f"{path.stem}_{args.symbol}_{args.timeframe}.png"
        fig.savefig(png, dpi=150, bbox_inches="tight")
        print(f"   График: {png.resolve()}  (сделок на нём: {len(win_trades)})")

    csv = out_dir / f"{path.stem}_{args.symbol}_trades.csv"
    pd.DataFrame(trades).to_csv(csv, index=False)
    print(f"   CSV: {csv.resolve()}")


if __name__ == "__main__":
    main()
