"""
Адаптер визуализации для kc_roc_cci_wt_grid_backtest.py

Конвертирует Deal (grid-сделка: база + усреднения, выход по WT-сигналу)
в формат BacktestVisualizer и рисует график.

Особенности grid-стратегии, учтённые здесь:
  - фиксированного take-profit нет: выход идёт по сигналу WaveTrend,
    поэтому TP-линия рисуется по фактической цене выхода;
  - stop_loss считается от СРЕДНЕЙ цены входа (avg_entry_price),
    процент берётся из параметров запуска, а не хардкодится;
  - P&L в USDT считается от капитала на сделку (--capital-per-deal).
"""
from __future__ import annotations

from pathlib import Path

import pandas as pd
import matplotlib.pyplot as plt

from backtest_visualizer import BacktestVisualizer


# ------------------------------------------------------------ адаптация --

def _bar_index(df: pd.DataFrame, ts) -> int | None:
    """Позиция бара по времени открытия (df уже с RangeIndex)."""
    if ts is None:
        return None
    mask = df["open_time"] >= ts
    if not mask.any():
        return None
    return int(mask.idxmax())


def adapt_deals_to_trades(
    deals: list,
    df: pd.DataFrame,
    stop_loss_pct: float = 4.0,
    capital_per_deal: float = 20.0,
) -> list[dict]:
    """Deal[] -> trades[] в формате BacktestVisualizer."""
    trades: list[dict] = []

    for d in deals:
        entry_idx = _bar_index(df, d.entry_time)
        exit_idx = _bar_index(df, d.exit_time)

        if entry_idx is None:
            continue
        if exit_idx is None or exit_idx < entry_idx:
            exit_idx = len(df) - 1

        avg_entry = float(d.avg_entry_price)
        exit_price = float(d.exit_price) if d.exit_price is not None else avg_entry

        # Стоп от средней цены входа, long-only
        stop_loss = avg_entry * (1 - stop_loss_pct / 100.0)

        pnl_percent = float(d.gross_pnl_pct) if d.gross_pnl_pct is not None else 0.0
        pnl = pnl_percent / 100.0 * capital_per_deal

        trades.append({
            "entry_index": entry_idx,
            "exit_index": exit_idx,
            "entry_price": avg_entry,
            "exit_price": exit_price,
            "stop_loss": stop_loss,
            # фиксированного TP у стратегии нет -- линия по факту выхода
            "take_profit_2": exit_price,
            "direction": "LONG",
            "pnl": pnl,
            "pnl_percent": pnl_percent,
            "exit_reason": d.reason,
            "orders_filled": d.orders_filled,
            "bars_held": d.bars_held,
        })

    return trades


def _crop_to_trades(df: pd.DataFrame, trades: list[dict], pad: int = 80,
                    max_bars: int = 1500) -> tuple[pd.DataFrame, list[dict]]:
    """
    Обрезает данные до окна вокруг сделок.

    Без этого на 20000 баров с редкими сделками видно последние N свечей,
    где сделок обычно нет -- график выходит пустым.
    """
    if not trades:
        return df.tail(min(len(df), max_bars)).reset_index(drop=True), []

    lo = max(0, min(t["entry_index"] for t in trades) - pad)
    hi = min(len(df) - 1, max(t["exit_index"] for t in trades) + pad)

    if hi - lo + 1 > max_bars:
        # Все сделки в окно не влезают -- выбираем позицию окна, в которую
        # попадает больше всего целых сделок, а не просто первые по времени.
        best_lo, best_count = lo, -1
        for t in sorted(trades, key=lambda x: x["entry_index"]):
            cand = max(0, t["entry_index"] - pad)
            cand = min(cand, max(0, len(df) - max_bars))
            cand_hi = cand + max_bars - 1
            count = sum(1 for x in trades
                        if x["entry_index"] >= cand and x["exit_index"] <= cand_hi)
            if count > best_count:
                best_lo, best_count = cand, count
        lo = best_lo
        hi = min(len(df) - 1, lo + max_bars - 1)

    df_win = df.iloc[lo:hi + 1].reset_index(drop=True)

    shifted = []
    for t in trades:
        if t["exit_index"] < lo or t["entry_index"] > hi:
            continue
        t2 = dict(t)
        t2["entry_index"] = max(0, t["entry_index"] - lo)
        t2["exit_index"] = min(len(df_win) - 1, t["exit_index"] - lo)
        shifted.append(t2)

    return df_win, shifted


# --------------------------------------------------------- визуализация --

def visualize_grid_backtest(
    df: pd.DataFrame,
    deals: list,
    symbol: str = "UNKNOWN",
    timeframe: str = "1m",
    output_path: str | None = None,
    stop_loss_pct: float = 4.0,
    capital_per_deal: float = 20.0,
    max_bars: int = 1500,
):
    """
    Рисует результаты grid-бэктеста.

    Returns:
        (fig, axes) или (None, None) если сделок нет.
    """
    trades = adapt_deals_to_trades(deals, df, stop_loss_pct, capital_per_deal)

    if not trades:
        print(f"   [viz] {symbol}: сделок нет -- график не строится")
        return None, None

    df_win, trades_win = _crop_to_trades(df, trades, max_bars=max_bars)

    if not trades_win:
        print(f"   [viz] {symbol}: сделки вне окна отрисовки -- график не строится")
        return None, None

    viz = BacktestVisualizer(df_win, trades_win, symbol=symbol, timeframe=timeframe)
    fig, axes = viz.plot_trades(figsize=(18, 10), bars_visible=len(df_win))

    # Статистику по всем сделкам уже печатает summarize() из бэктеста --
    # здесь говорим только про то, что реально попало на картинку.
    hidden = len(trades) - len(trades_win)
    note = f", вне окна: {hidden}" if hidden else ""
    print(f"   [viz] окно {len(df_win)} баров, сделок на графике: {len(trades_win)}{note}")
    if hidden:
        print(f"   [viz] увеличьте --viz-max-bars, чтобы вместить остальные")

    if output_path:
        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(out, dpi=150, bbox_inches="tight")
        plt.close(fig)
        print(f"   [viz] график: {out.resolve()}")

    return fig, axes


# ------------------------------------------------------- крупный план --

def _base_price_from_avg(avg_entry: float, orders_filled: int,
                         grid: list[tuple[float, float]]) -> float:
    """
    Восстанавливает цену базового ордера из средней цены входа.

    avg = base * sum(v_i * (1 - o_i/100)) / sum(v_i) по исполненным ногам,
    значит base выражается обратно. Нужно, чтобы нарисовать уровни лимиток
    сетки: по ним видно, сработало усреднение или нет.
    """
    legs = grid[:max(1, orders_filled)]
    num = sum(v for _, v in legs)
    den = sum(v * (1 - o / 100.0) for o, v in legs)
    return avg_entry * num / den if den else avg_entry


def plot_deals_closeup(
    df: pd.DataFrame,
    deals: list,
    grid: list[tuple[float, float]],
    symbol: str = "UNKNOWN",
    timeframe: str = "1m",
    output_path: str | None = None,
    stop_loss_pct: float = 4.0,
    max_deals: int = 12,
):
    """
    Рисует каждую сделку отдельной панелью: свечи вокруг сделки, вход,
    выход, стоп и уровни лимитных ордеров сетки.

    Общий график на тысячи баров показывает редкие сделки точками; здесь
    видно, что происходило внутри каждой.
    """
    from matplotlib.patches import Rectangle

    shown = deals[:max_deals]
    if not shown:
        return None

    ncols = 2 if len(shown) > 1 else 1
    nrows = (len(shown) + ncols - 1) // ncols
    fig, axes = plt.subplots(nrows, ncols, figsize=(9 * ncols, 4.2 * nrows),
                             squeeze=False)

    for ax, d in zip([a for row in axes for a in row], shown):
        e = _bar_index(df, d.entry_time)
        x = _bar_index(df, d.exit_time)
        if e is None:
            continue
        if x is None or x < e:
            x = len(df) - 1

        pad = max(20, int((x - e) * 0.25))
        lo, hi = max(0, e - pad), min(len(df) - 1, x + pad)
        win = df.iloc[lo:hi + 1].reset_index(drop=True)
        e_x, x_x = e - lo, x - lo

        for i, row in win.iterrows():
            up = row["close"] >= row["open"]
            col = "#26a69a" if up else "#ef5350"
            ax.plot([i, i], [row["low"], row["high"]], color=col, linewidth=0.6)
            body = abs(row["close"] - row["open"]) or (row["high"] - row["low"]) * 0.01
            ax.add_patch(Rectangle((i - 0.3, min(row["open"], row["close"])),
                                   0.6, body, facecolor=col, edgecolor=col))

        avg = float(d.avg_entry_price)
        base = _base_price_from_avg(avg, d.orders_filled, grid)
        stop = avg * (1 - stop_loss_pct / 100.0)

        # Шкалу задаём по цене сделки, а не по стопу: при -4% на минутках
        # стоп уводит границу так далеко, что свечи схлопываются в полоску.
        prices = [win["low"].min(), win["high"].max(), avg, float(d.exit_price)]
        span = (max(prices) - min(prices)) or max(prices) * 0.001
        y_lo, y_hi = min(prices) - span * 0.12, max(prices) + span * 0.12
        ax.set_ylim(y_lo, y_hi)
        ax.set_xlim(-1, len(win))

        def level(price, text, color, style, lw, x_text, ha):
            """Уровень с подписью; вне видимой шкалы ничего не рисуем --
            иначе подпись уезжает за пределы панели."""
            if not (y_lo < price < y_hi):
                return
            ax.axhline(price, color=color, linestyle=style, linewidth=lw, alpha=0.85)
            ax.text(x_text, price, text, fontsize=7, va="bottom", ha=ha,
                    color=color, clip_on=True)

        # уровни сетки -- справа, чтобы не сталкивались с подписью средней
        for n, (off, _vol) in enumerate(grid):
            filled = n < d.orders_filled
            lvl = base * (1 - off / 100.0)
            if abs(lvl - avg) < span * 0.005:
                continue  # одна нога -- уровень совпал со средней, не дублируем
            level(lvl,
                  f"ордер {n + 1} (-{off}%) ",
                  "#1f77b4" if filled else "#9aa5b1",
                  "-" if filled else ":", 1.1,
                  len(win) - 1, "right")

        level(avg, " средняя", "darkgreen", "-", 1.4, 0, "left")
        level(stop, f" стоп -{stop_loss_pct}%", "red", "--", 1.2, 0, "left")

        ax.scatter(e_x, avg, marker="^", s=130, color="green",
                   edgecolors="black", zorder=5)
        ax.scatter(x_x, float(d.exit_price), marker="o", s=130,
                   color="lime" if (d.gross_pnl_pct or 0) >= 0 else "crimson",
                   edgecolors="black", zorder=5)

        ts = pd.Timestamp(d.entry_time).strftime("%d.%m %H:%M")
        ax.set_title(f"{ts} · {d.reason} · {d.gross_pnl_pct:+.2f}% · "
                     f"ордеров: {d.orders_filled} · баров: {d.bars_held}",
                     fontsize=10, fontweight="bold")
        ax.set_facecolor("#f8f9fa")
        ax.grid(True, alpha=0.25)
        for s in ("top", "right"):
            ax.spines[s].set_visible(False)

    for ax in [a for row in axes for a in row][len(shown):]:
        ax.set_visible(False)

    fig.suptitle(f"{symbol} {timeframe} — сделки крупным планом",
                 fontsize=13, fontweight="bold")
    fig.tight_layout()

    if output_path:
        out = Path(output_path)
        out.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(out, dpi=140, bbox_inches="tight")
        plt.close(fig)
        print(f"   [viz] крупный план: {out.resolve()}")
        if len(deals) > max_deals:
            print(f"   [viz] показаны первые {max_deals} из {len(deals)} сделок")

    return fig


if __name__ == "__main__":
    print("Модуль импортируется из run_grid_backtest_viz.py")
    print("Использование: from kc_roc_grid_visualizer import visualize_grid_backtest")
