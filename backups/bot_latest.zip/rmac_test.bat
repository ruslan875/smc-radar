@echo off
cd /d %~dp0
if exist venv\Scripts\python.exe (venv\Scripts\python.exe rmac_test.py) else (python rmac_test.py)
