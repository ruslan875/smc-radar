"""recheck_recent.py — 2026-10-29. Перепроверка стратегий, которые сейчас дают сигналы: работают ли они В ПОСЛЕДНИЕ МЕСЯЦЫ.

Для каждой стратегии и ТФ — та же логика, что у бумажного бота, на 12 монетах (свечи Binance Futures, кэш kvoo_longtest):
вся история · последние 180 дней · последние 90 дней · последние 30 дней. Комиссия+проскальзывание 0.11% за круг.
  Пробой канала (регрессия 100 ±2σ, стоп центр, тейк 2R, ≤100 свечей) — 1h, 2h, 4h
  Donchian 20 по тренду EMA200 (стоп середина, тейк 3R) — 4h
  HA ×18 переворот (LE VAN DO, честно) — 1h, 2h, 4h
Статус: «работает» — плюс за всю историю И за 90 дней; «слабый период» — история в плюсе, а 90 дней в минусе; «не работает» — иначе.
Пишет bt_lab_bots/recent_check.json (его читают сигналы/терминал/Mini App) и recent_check.txt.
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
FEE = 0.0011
OUT = BASE / "bt_lab_bots" / "recent_check.json"


def load(sym, tf):
    import kvoo_longtest as K  # noqa: PLC0415
    if tf == "2h":
        d = K.load(sym, "1h")
        if d is None:
            return None
        g = d.assign(b=d.t // 7_200_000 * 7_200_000).groupby("b")
        return pd.DataFrame({"t": g.t.first(), "o": g.o.first(), "h": g.h.max(), "l": g.l.min(), "c": g.c.last(), "v": g.v.sum()}).reset_index(drop=True)
    d = K.load(sym, tf)
    return None if d is None else d.reset_index(drop=True)


def rolling_reg(c, n=100):
    """mid и sd линейной регрессии по последним n закрытиям (на свече i, включая её) — как _signals в chan_paper."""
    m = len(c); mid = np.full(m, np.nan); sd = np.full(m, np.nan)
    x = np.arange(n); xm = (n - 1) / 2; sxx = ((x - xm) ** 2).sum()
    from numpy.lib.stride_tricks import sliding_window_view as swv
    if m < n:
        return mid, sd
    W = swv(c, n)
    ym = W.mean(1); b = ((x - xm) * (W - ym[:, None])).sum(1) / sxx; a = ym - b * xm
    fit = a[:, None] + b[:, None] * x
    mid[n - 1:] = a + b * (n - 1); sd[n - 1:] = np.sqrt(((W - fit) ** 2).mean(1))
    return mid, sd


def sim_fixed(d, sigs, rr, hold):
    """sigs: [(i, side, stop)] → [(t_close, R)] без перекрытия."""
    h, l, c, t = d.h.values, d.l.values, d.c.values, d.t.values
    out = []; nxt = 0
    for i, sd_, stp in sigs:
        if i < nxt or i >= len(c) - 1:
            continue
        e = c[i]; risk = abs(e - stp)
        if risk <= 0:
            continue
        tp = e + sd_ * rr * risk; res = None
        for j in range(i + 1, min(len(c), i + hold + 1)):
            if (l[j] <= stp) if sd_ > 0 else (h[j] >= stp):
                res = (j, -1.0); break
            if (h[j] >= tp) if sd_ > 0 else (l[j] <= tp):
                res = (j, rr); break
        if res is None:
            j = min(len(c) - 1, i + hold); res = (j, sd_ * (c[j] - e) / risk)
        out.append((int(t[res[0]]), res[1] - FEE * e / risk)); nxt = res[0] + 1
    return out


def chan(d):
    c = d.c.values; mid, sd = rolling_reg(c)
    up, lo = mid + 2 * sd, mid - 2 * sd
    sigs = []
    for i in range(101, len(c)):
        if c[i] > up[i] and c[i - 1] <= up[i - 1]:
            sigs.append((i, 1, mid[i]))
        elif c[i] < lo[i] and c[i - 1] >= lo[i - 1]:
            sigs.append((i, -1, mid[i]))
    return sim_fixed(d, sigs, 2.0, 100)


def donch(d):
    h, l, c = d.h.values, d.l.values, d.c.values
    e = pd.Series(c).ewm(span=200, adjust=False).mean().values
    hh = pd.Series(h).rolling(20).max().shift(1).values; ll = pd.Series(l).rolling(20).min().shift(1).values
    sigs = []
    for i in range(201, len(c)):
        mid = (hh[i] + ll[i]) / 2
        if c[i] > hh[i] and c[i] > e[i]:
            sigs.append((i, 1, mid))
        elif c[i] < ll[i] and c[i] < e[i]:
            sigs.append((i, -1, mid))
    return sim_fixed(d, sigs, 3.0, 300)


def ha18(d, ms):
    import levando_test as L  # noqa: PLC0415
    (_a, _b), (ho, hc) = L.ha_htf(d, ms)
    up, dn = L.sig(ho, hc)
    # R не определён (стопа нет) — считаем в % цены, как в тесте LE VAN DO
    return [(t, r * 100) for t, r in L.run_reverse(d, up, dn)]


STRATS = [("Пробой канала", "1h", chan, "R"), ("Пробой канала", "2h", chan, "R"), ("Пробой канала", "4h", chan, "R"),
          ("Donchian 20", "4h", donch, "R"),
          ("HA ×18 переворот", "1h", None, "%"), ("HA ×18 переворот", "2h", None, "%"), ("HA ×18 переворот", "4h", None, "%")]
MS = {"1h": 3_600_000, "2h": 7_200_000, "4h": 14_400_000}


def main():
    import kvoo_longtest as K  # noqa: PLC0415
    now = int(time.time() * 1000)
    res, lines = {}, []
    cache = {}
    for name, tf, fn, unit in STRATS:
        allt = []; pos = 0; n = 0
        for s in K.COINS:
            key = (s, tf)
            if key not in cache:
                try:
                    cache[key] = load(s, tf)
                except Exception:  # noqa: BLE001
                    cache[key] = None
            d = cache[key]
            if d is None or len(d) < 400:
                continue
            tr = fn(d) if fn else ha18(d, MS[tf])
            allt += tr; n += 1; pos += sum(r for _t, r in tr) > 0
        win = {}
        for lab, days in (("all", 99999), ("d180", 180), ("d90", 90), ("d30", 30)):
            x = [r for t, r in allt if t >= now - days * 86400_000]
            win[lab] = {"n": len(x), "sum": round(float(sum(x)), 1)}
        ok_all = win["all"]["sum"] > 0; ok90 = win["d90"]["sum"] > 0
        status = "работает" if ok_all and ok90 else ("слабый период" if ok_all else "не работает")
        k = f"{name}|{tf}"
        res[k] = {"name": name, "tf": tf, "unit": unit, "coins_pos": int(pos), "coins": int(n), **win, "status": status}
        u = unit
        line = (f"{'✅' if status == 'работает' else '⚠️' if status == 'слабый период' else '❌'} {name} {tf}: "
                f"вся история {win['all']['sum']:+.0f}{u} ({win['all']['n']} сд, {pos}/{n} монет) · 180 дн {win['d180']['sum']:+.1f}{u} · "
                f"90 дн {win['d90']['sum']:+.1f}{u} ({win['d90']['n']} сд) · 30 дн {win['d30']['sum']:+.1f}{u} → {status}")
        print(line, flush=True); lines.append(line)
    OUT.parent.mkdir(exist_ok=True)
    OUT.write_text(json.dumps({"checked": now, "items": res}, ensure_ascii=False, indent=1, default=float), encoding="utf-8")
    (BASE / "bt_lab_bots" / "recent_check.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("готово")


if __name__ == "__main__":
    main()
