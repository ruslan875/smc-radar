import sys
from pathlib import Path
B = Path(__file__).resolve().parent; sys.path.insert(0, str(B))
from app.trade_server import _ngrok_conf
t, d = _ngrok_conf()
print("TOKEN_SET", bool(t), "LEN", len(t), "DOMAIN", d)
