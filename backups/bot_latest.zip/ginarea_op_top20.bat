@echo off
cd /d D:\VANTORIX\bot
venv\Scripts\python.exe ginarea_op_top20.py 90
pause
