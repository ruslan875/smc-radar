@echo off
cd /d %~dp0
python davinchi_ema_test.py
pause
