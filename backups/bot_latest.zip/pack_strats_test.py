"""pack_strats_test.py — 2026-10-14. Стратегии из Telegram-сборника «Сборники TradingView» (Crypto-Scalping).
Сюда добавляются стратегии по мере того, как пользователь присылает код. Ничего не торгует.

1) Strategy SQZMOM & Trendilo — как в Pine:
   val = linreg(close − avg(avg(highest(high,20), lowest(low,20)), sma(close,20)), 20, 0)
   Long при пересечении val вверх через 0, Short — вниз через 0; strategy.entry разворачивает позицию
   (всегда в рынке). Выход profit/loss = 5000 тиков — на крипте это очень далеко, почти не срабатывает,
   поэтому моделируем как чистый разворот.
   Вариант «+Trendilo»: автор рисует линию Trendilo (avg(LSMA25, HMA50) от EMA5(hl2)), но в сделках её не
   использует. Пробуем фильтр: лонг только если Trendilo растёт, шорт — если падает (иначе позиция закрывается).
   Вариант «+стоп/тейк ATR»: стоп 2 ATR, тейк 3 ATR, вместо вечного разворота.

Пакет indicators_pack (2026-10-14), порт без заглядывания вперёд (пивоты — только после подтверждения):
2) Nadaraya-Watson Envelope (LuxAlgo) h=8, mult=3 — ТОЛЬКО endpoint-версия: out = Σ_{i=0..499} close[i]·gauss(i)/Σgauss
   (прошлые бары), mae = sma(|close−out|,499)·3. ▲ лонг: close пересёк нижнюю вниз; ▼ шорт: верхнюю вверх.
   Режим repaint=true (дефолт в Pine) рисует по будущим барам — не портирован. Те же стрелки NWE 8/3 и в
   «Better RSI & NWE», «Dynamic Price & NWE», «BB RSI CCI NW», «Trading Toolkit & NWE», «Swings…», «Golden…»,
   «NWE & K's» — тестируются один раз. Варианты: разворот; +стоп 2/тейк 3 ATR.
3) 2x NWE: огибающие 2/6 и 8/3 (обе endpoint; в Pine первая по умолчанию в repaint-режиме и стрелок не даёт),
   сигнал от любой. Разворот / +ATR.
4) K's Reversal (из «NWE & K's Reversal»): лонг — тело бара[1] касается нижней BB(100,2) и ниже средней,
   MACD(12,26,9) пересёк сигнальную вверх на баре[1]; шорт — зеркально. Разворот / +ATR.
5) Swings High&Low RSI NW (и Golden Swings): метки RSI(7) ≤13 → лонг, ≥87 → шорт. Свинг-метки 20/20 — только
   визуал (подтверждаются через 20 баров), не торгуются. Разворот / +ATR.
6) Golden Swings — CMS Gold Buy: бычья дивергенция WaveTrend(9,12,3) по фракталам (wt2 ≤ −65), прошлый фрактал
   wt ≤ −75, RSI14 на нём < 30. Только лонг: стоп 2/тейк 3 ATR, либо выход по ▼ NWE 8/3.
7) Trading Toolkit: регулярные дивергенции RSI(24), pivot 10/10, расстояние 5..60 баров; сигнал на баре
   подтверждения (через 10 баров после экстремума). Разворот / +ATR. S/R-боксы и коррекции — визуал.
8) Fusion Strategy: супер-осциллятор avg(RSI,MFI,MACD,CCI,TSI,RVI) пересёк −1.25 вверх (+ненаправленный ≥ −0.25)
   → «взвод», затем бычий FVG (low > high[2], объём[1] > sma10 или размер > 1.5×среднего) и close>close[1] при
   EMA100>EMA200 → лонг; шорт зеркально. strategy.entry разворачивает; выход 5000 тиков ≈ не срабатывает.
   Оригинал / +ATR.
9) Liquidity Range MACD: Range Filter(50,3) смена направления + гистограмма MACD ≥0 (<0) + EMA80>EMA200 от цены
   на «ликвидных» барах (volume/|close−open| пробил ema10+stdev10). Разворот (стоп в Pine выкл.) / +ATR.
10) Trend Cycle Suite Volume: STC(23,50,10) пересёк 75 вверх + Volume Osc(5,10) > 5 + HMA(180) растёт и ниже
   цены → лонг; STC пересёк 25 вниз + osc>5 + HMA падает и выше цены → шорт. Выходы как в Pine: тейк 3%, стоп 1%
   от close сигнальной свечи; встречный сигнал — разворот. Оригинал / стоп 2/тейк 3 ATR.
11) Schaff Trend Cycle (80/27/50, 0.5): «b» — STC начал расти, «s» — начал падать (смена цвета). Разворот / +ATR.
12) Stochastic OTT RSI Scalping: B/S символы DMI-Stochastic (DMI 20, сток 5): выход вверх из <10 → лонг,
   вниз из >90 → шорт. (OTT-кроссы по умолчанию скрыты — не тестировались.) Разворот / +ATR.
13) 3 Swing Failure Pattern: три копии с одинаковыми настройками → один тест. Свинг pivot(5,1); SFP = фитиль за
   свинг-хай и закрытие обратно; ▼ подтверждение — close ниже минимума между свингом и SFP (▲ зеркально).
   Сигнал по подтверждению. Разворот / +ATR.
14) Boom Hunter Divergence / Boom Hunter Divergence + / MultiZ Boom Harmonic Hunter (блок Boom Hunter) — логика
   сигналов идентична → один тест. Long = любая из меток enter3/enter5/enter6(q1≤60)/enter7 (кросс q1 и
   триггера в зоне перепроданности EOT-осциллятора Элерса), Short = senter3. Разворот / +ATR.
15) ML Lorentzian Classification: k-NN (k=8) по признакам RSI14, WT10/11, CCI20, ADX20, RSI9, лоренцево
   расстояние, отбор соседей как в Pine (каждый 4-й пропуск, порог lastDistance). Метка как в оригинале:
   знак движения close за прошлые 4 бара (рост → −1) — только известные данные. Фильтры волатильности и режима
   вкл., вход только при совпадении с наклоном ядра rationalQuadratic(8,8,25) (по прошлым барам).
   Выход: через 4 бара (дефолт) / разворот по сигналам. Отличие: соседи — скользящее окно 2000 прошлых баров
   (в Pine — первые 2000 баров графика, прогноз только на последних 2000).
Пропущены (нет сигналов): Dynamic Price Oscillator (часть «Dynamic Price & NWE»), BB/RSI/CCI в «BB RSI CCI NW»
   (дивергенции там выключены по умолчанию), Better RSI cycler, MultiZ — гармонические паттерны ZigZag (последний
   пивот зигзага перерисовывается, направление только в подписи) и MTF Key Levels (уровни-визуал),
   LazyScalp Board в Lorentzian (таблица), Hull/Donchian-визуал.
Приближения: в Boom Hunter старт фильтра Элерса без nz(close[1])=0 (иначе гигантский выброс в начале истории);
   request.security в пакете нигде не нужен для сигналов (timeframe='' = текущий ТФ).
Исполнение: сигнал на закрытии → вход по открытию следующей свечи. Комиссия рынок 0.09% на сторону.
12 монет, 5m / 15m / 1h / 4h, половины истории отдельно. ✅ — в плюсе, ≥8/12 монет, обе половины > 0.
Запуск: pack_strats_test.bat → bt_lab_bots/pack_strats_test.txt
"""
from __future__ import annotations

import time
from pathlib import Path

import numpy as np

import tg_strats_test as T

OUT = Path(__file__).resolve().parent / "bt_lab_bots" / "pack_strats_test.txt"
TK = 0.0009
TFS = [("5", "5m", 30000), ("15", "15m", 25000), ("60", "1h", 15000), ("240", "4h", 6000)]
LINES = []


def say(s=""):
    print(s, flush=True)
    LINES.append(s)


# ---------------- индикаторы (как в Pine) ----------------
def sma(x, n):
    cs = np.cumsum(np.r_[0.0, x]); out = np.full(len(x), np.nan); out[n - 1:] = (cs[n:] - cs[:-n]) / n; return out


def wma(x, n):
    w = np.arange(1, n + 1, dtype=float); out = np.full(len(x), np.nan)
    from numpy.lib.stride_tricks import sliding_window_view as sw  # noqa: PLC0415
    if len(x) >= n:
        out[n - 1:] = sw(x, n) @ w / w.sum()
    return out


def hma(x, n):
    a = 2 * wma(x, n // 2) - wma(x, n)
    a = np.where(np.isnan(a), x, a)
    return wma(a, int(np.sqrt(n)))


def ema(x, n):
    out = np.empty_like(x); k = 2 / (n + 1); out[0] = x[0]
    for i in range(1, len(x)):
        out[i] = out[i - 1] + k * (x[i] - out[i - 1])
    return out


def linreg(y, n):
    """ta.linreg(y, n, 0): значение линии регрессии на последней точке окна."""
    from numpy.lib.stride_tricks import sliding_window_view as sw  # noqa: PLC0415
    out = np.full(len(y), np.nan)
    if len(y) < n:
        return out
    x = np.arange(n, dtype=float); xm = x.mean(); den = ((x - xm) ** 2).sum()
    W = sw(np.nan_to_num(y), n); ym = W.mean(axis=1)
    slope = (W - ym[:, None]) @ (x - xm) / den
    out[n - 1:] = ym + slope * (n - 1 - xm)
    bad = np.r_[np.full(n - 1, True), sw(np.isnan(y), n).any(axis=1)]
    out[bad] = np.nan
    return out


def rmax(x, n):
    from numpy.lib.stride_tricks import sliding_window_view as sw  # noqa: PLC0415
    out = np.full(len(x), np.nan); out[n - 1:] = sw(x, n).max(axis=1); return out


def rmin(x, n):
    from numpy.lib.stride_tricks import sliding_window_view as sw  # noqa: PLC0415
    out = np.full(len(x), np.nan); out[n - 1:] = sw(x, n).min(axis=1); return out


def atr(d, n=14):
    pc = np.r_[d["c"][0], d["c"][:-1]]
    tr = np.maximum(d["h"] - d["l"], np.maximum(abs(d["h"] - pc), abs(d["l"] - pc)))
    out = np.empty_like(tr); out[0] = tr[0]
    for i in range(1, len(tr)):
        out[i] = out[i - 1] + (tr[i] - out[i - 1]) / n
    return out


# ---------------- общий симулятор: сигналы ±1 на закрытии ----------------
def run_reverse(d, sig, allow=None, sl_tp=None):
    """sig[i] = +1/−1/0. Всегда в рынке (разворот), либо со стопом/тейком ATR.
    allow[i] (опц.) = +1 разрешён только лонг, −1 только шорт, 0 — ничего; если позиция против allow — закрываем."""
    o, h, l, c = d["o"], d["h"], d["l"], d["c"]
    a = atr(d) if sl_tp else None
    pos, e, s, t = 0, 0.0, 0.0, 0.0
    tot, n = 0.0, 0
    for i in range(60, len(c) - 1):
        if pos and sl_tp:
            if (l[i] <= s) if pos > 0 else (h[i] >= s):
                tot += pos * (s / e - 1) - 2 * TK; n += 1; pos = 0
            elif (h[i] >= t) if pos > 0 else (l[i] <= t):
                tot += pos * (t / e - 1) - 2 * TK; n += 1; pos = 0
        want = sig[i]
        if allow is not None:
            if pos and allow[i] != pos:
                tot += pos * (o[i + 1] / e - 1) - 2 * TK; n += 1; pos = 0
            if want and allow[i] != want:
                want = 0
        if want and want != pos:
            px = o[i + 1]
            if pos:
                tot += pos * (px / e - 1) - 2 * TK; n += 1
            pos, e = want, px
            if sl_tp:
                k, r = sl_tp; s = e - pos * k * a[i]; t = e + pos * r * a[i]
    if pos:
        tot += pos * (c[-1] / e - 1) - 2 * TK; n += 1
    return tot, n


# ---------------- 1) SQZMOM & Trendilo ----------------
def sqz_val(d, n=20):
    h, l, c = d["h"], d["l"], d["c"]
    x = c - ((rmax(h, n) + rmin(l, n)) / 2 + sma(c, n)) / 2
    return linreg(x, n)


def sqz_signals(d):
    v = sqz_val(d)
    sig = np.zeros(len(v), dtype=int)
    prev = np.r_[np.nan, v[:-1]]
    sig[(prev <= 0) & (v > 0)] = 1
    sig[(prev >= 0) & (v < 0)] = -1
    return sig


def trendilo(d):
    src = ema((d["h"] + d["l"]) / 2, 5)
    comb = (linreg(src, 25) + hma(src, 50)) / 2
    sl = np.r_[0.0, np.diff(comb)]
    return np.where(sl > 0, 1, np.where(sl < 0, -1, 0))


TESTS = {
    "SQZMOM&Trendilo — как в оригинале":  lambda d: run_reverse(d, sqz_signals(d)),
    "SQZMOM&Trendilo + фильтр Trendilo":  lambda d: run_reverse(d, sqz_signals(d), allow=trendilo(d)),
    "SQZMOM&Trendilo + стоп 2/тейк 3 ATR": lambda d: run_reverse(d, sqz_signals(d), sl_tp=(2.0, 3.0)),
}



# =====================================================================================
# ---------------- доп. индикаторы (Pine-совместимые, без заглядывания вперёд) --------
# =====================================================================================
from numpy.lib.stride_tricks import sliding_window_view as _sw  # noqa: E402


def _f(x):
    return np.asarray(x, dtype=float)


def shift(x, k=1):
    """x[k] в терминах Pine (значение k баров назад)."""
    x = _f(x); out = np.full(len(x), np.nan)
    if k < len(x):
        out[k:] = x[:len(x) - k]
    return out


def smaN(x, n):
    """sma, устойчивая к NaN в начале ряда (как ta.sma после прогрева)."""
    x = _f(x); out = np.full(len(x), np.nan)
    ok = np.flatnonzero(~np.isnan(x))
    if not len(ok):
        return out
    s = ok[0]
    y = np.nan_to_num(x[s:])
    if len(y) >= n:
        cs = np.cumsum(np.r_[0.0, y]); out[s + n - 1:] = (cs[n:] - cs[:-n]) / n
        bad = _sw(np.isnan(x[s:]), n).any(axis=1)
        out[s + n - 1:][bad] = np.nan
    return out


def emaN(x, n=None, alpha=None):
    """ta.ema / сглаживание: стартует с первого не-NaN значения, NaN — держит прошлое."""
    x = _f(x); a = alpha if alpha is not None else 2.0 / (n + 1)
    out = np.full(len(x), np.nan); prev = np.nan
    for i in range(len(x)):
        v = x[i]
        if v == v:
            prev = v if prev != prev else prev + a * (v - prev)
        out[i] = prev
    return out


def rma(x, n):
    """ta.rma: затравка = sma первых n значений, далее alpha = 1/n."""
    x = _f(x); out = np.full(len(x), np.nan)
    ok = np.flatnonzero(~np.isnan(x))
    if len(ok) == 0 or ok[0] + n > len(x):
        return out
    s = ok[0] + n - 1; prev = np.nanmean(x[ok[0]:s + 1]); out[s] = prev; a = 1.0 / n
    for i in range(s + 1, len(x)):
        v = x[i]
        if v == v:
            prev += a * (v - prev)
        out[i] = prev
    return out


def stdevN(x, n):
    x = _f(x); out = np.full(len(x), np.nan)
    if len(x) >= n:
        out[n - 1:] = _sw(x, n).std(axis=1)
    return out


def rmaxN(x, n):
    x = _f(x); out = np.full(len(x), np.nan)
    if len(x) >= n:
        out[n - 1:] = _sw(x, n).max(axis=1)
    return out


def rminN(x, n):
    x = _f(x); out = np.full(len(x), np.nan)
    if len(x) >= n:
        out[n - 1:] = _sw(x, n).min(axis=1)
    return out


def rsumN(x, n):
    x = _f(x); out = np.full(len(x), np.nan)
    if len(x) >= n:
        out[n - 1:] = _sw(x, n).sum(axis=1)
    return out


def change(x, k=1):
    return _f(x) - shift(x, k)


def tr_(d):
    pc = shift(d["c"]); h, l = d["h"], d["l"]
    tr = np.fmax(h - l, np.fmax(np.abs(h - pc), np.abs(l - pc)))
    tr[0] = h[0] - l[0]
    return tr


def rsi(x, n):
    ch = change(x)
    up = rma(np.where(np.isnan(ch), np.nan, np.maximum(ch, 0)), n)
    dn = rma(np.where(np.isnan(ch), np.nan, -np.minimum(ch, 0)), n)
    with np.errstate(divide="ignore", invalid="ignore"):
        r = 100 - 100 / (1 + up / dn)
    r = np.where(dn == 0, 100.0, np.where(up == 0, 0.0, r))
    r[np.isnan(up) | np.isnan(dn)] = np.nan
    return r


def cci(x, n):
    x = _f(x); out = np.full(len(x), np.nan)
    if len(x) >= n:
        W = _sw(x, n); m = W.mean(axis=1); dev = np.abs(W - m[:, None]).mean(axis=1)
        with np.errstate(divide="ignore", invalid="ignore"):
            out[n - 1:] = (x[n - 1:] - m) / (0.015 * dev)
    return out


def xover(a, b):
    a, b = _f(a), np.broadcast_to(_f(b), np.shape(a))
    pa, pb = shift(a), shift(b)
    return (a > b) & (pa <= pb)


def xunder(a, b):
    a, b = _f(a), np.broadcast_to(_f(b), np.shape(a))
    pa, pb = shift(a), shift(b)
    return (a < b) & (pa >= pb)


def barssince(cond):
    """ta.barssince: баров с последнего True (NaN если не было)."""
    cond = np.asarray(cond, bool); idx = np.arange(len(cond), dtype=float)
    last = np.where(cond, idx, np.nan)
    last = ffill(last)
    return idx - last


def ffill(x):
    x = _f(x).copy(); ok = ~np.isnan(x)
    ix = np.where(ok, np.arange(len(x)), 0); np.maximum.accumulate(ix, out=ix)
    out = x[ix]; out[~ok & (np.cumsum(ok) == 0)] = np.nan
    return out


def valuewhen0(cond, val):
    """ta.valuewhen(cond, val, 0)."""
    return ffill(np.where(np.asarray(cond, bool), _f(val), np.nan))


def lt(a, b):
    """a < b, NaN → False (как сравнение с na в Pine)."""
    with np.errstate(invalid="ignore"):
        return np.nan_to_num(_f(a), nan=np.inf) < np.nan_to_num(_f(b), nan=-np.inf)


def gt(a, b):
    return lt(b, a)


def le(a, b):
    a, b = np.broadcast_arrays(_f(a), _f(b))
    with np.errstate(invalid="ignore"):
        r = a <= b
    return r & ~np.isnan(a) & ~np.isnan(b)


def ge(a, b):
    return le(b, a)


def to_sig(buy, sell):
    s = np.zeros(len(buy), dtype=int); s[np.asarray(buy, bool)] = 1; s[np.asarray(sell, bool)] = -1
    s[np.asarray(buy, bool) & np.asarray(sell, bool)] = 0
    return s


# ---------------- симулятор с собственными выходами ----------------
def run_exit(d, sig, xsig=None, hold=None, atr_sl_tp=None, pct_sl_tp=None, refresh=True):
    """sig[i] = +1/−1 вход на закрытии i → open i+1; противоположный сигнал = разворот.
    xsig[i] = +1 закрыть лонг, −1 закрыть шорт (на open i+1). hold = выйти через N баров после сигнала
    входа (выход на open бара сигнал+N+1). atr_sl_tp=(k,r) — стоп/тейк в ATR; pct_sl_tp=(sl,tp) — в долях от
    close сигнального бара (как strategy.exit(limit=close*1.03, stop=close*0.99)). Стоп/тейк проверяются по
    high/low внутри бара, стоп первым (консервативно), гэп через уровень — исполнение по open.
    refresh: повторный сигнал в ту же сторону пересчитывает уровни/таймер (как переподача strategy.exit)."""
    o, h, l, c = d["o"], d["h"], d["l"], d["c"]
    a = atr(d) if atr_sl_tp else None
    pos, e, s, t, eb = 0, 0.0, np.nan, np.nan, 0
    tot, n = 0.0, 0
    for i in range(60, len(c) - 1):
        if pos and s == s:
            if pos > 0:
                if l[i] <= s:
                    px = min(o[i], s); tot += px / e - 1 - 2 * TK; n += 1; pos = 0
                elif h[i] >= t:
                    px = max(o[i], t); tot += px / e - 1 - 2 * TK; n += 1; pos = 0
            else:
                if h[i] >= s:
                    px = max(o[i], s); tot += -(px / e - 1) - 2 * TK; n += 1; pos = 0
                elif l[i] <= t:
                    px = min(o[i], t); tot += -(px / e - 1) - 2 * TK; n += 1; pos = 0
        if pos and ((hold and i - eb >= hold) or (xsig is not None and xsig[i] == pos)):
            tot += pos * (o[i + 1] / e - 1) - 2 * TK; n += 1; pos = 0
        want = sig[i]
        if want and (want != pos or refresh):
            if want != pos:
                px = o[i + 1]
                if pos:
                    tot += pos * (px / e - 1) - 2 * TK; n += 1
                pos, e = want, px
            eb = i
            s = t = np.nan
            if atr_sl_tp:
                k, r = atr_sl_tp; s = e - pos * k * a[i]; t = e + pos * r * a[i]
            elif pct_sl_tp:
                k, r = pct_sl_tp; s = c[i] * (1 - pos * k); t = c[i] * (1 + pos * r)
    if pos:
        tot += pos * (c[-1] / e - 1) - 2 * TK; n += 1
    return tot, n


# ---------------- 2) Nadaraya-Watson Envelope (LuxAlgo), только endpoint-версия ----------------
def nwe(d, h=8.0, mult=3.0, L=500):
    """Не перерисовывающийся вариант: out = Σ_{i=0..499} close[i]·gauss(i,h) / Σ gauss — только прошлые бары;
    mae = sma(|close − out|, 499)·mult. Режим repaint=true (по умолчанию в Pine) смотрит в будущее — не портирован."""
    c = d["c"]; w = np.exp(-(np.arange(L) ** 2) / (h * h * 2)); w /= w.sum()
    out = np.convolve(c, w)[:len(c)]; out[:L - 1] = np.nan
    mae = smaN(np.abs(c - out), 499) * mult
    return out + mae, out - mae


def nwe_signals(d, h=8.0, mult=3.0):
    up, lo = nwe(d, h, mult); c = d["c"]
    return to_sig(xunder(c, lo), xover(c, up))   # ▲ = close пересёк нижнюю вниз; ▼ = верхнюю вверх


def nwe2x_signals(d):
    a, b = nwe_signals(d, 2.0, 6.0), nwe_signals(d, 8.0, 3.0)
    s = np.where(a != 0, a, b); s[(a * b) < 0] = 0
    return s


# ---------------- 3) K's Reversal Indicator I ----------------
def ks_signals(d):
    o, c = d["o"], d["c"]
    m = ema(c, 12) - ema(c, 26); sg = ema(m, 9)
    mid = sma(c, 100); sd = stdevN(c, 100); lob, upb = mid - 2 * sd, mid + 2 * sd
    mn1, mx1 = shift(np.minimum(o, c)), shift(np.maximum(o, c))
    m1, s1, m2, s2 = shift(m), shift(sg), shift(m, 2), shift(sg, 2)
    buy = le(mn1, shift(lob)) & le(mx1, mid) & gt(m1, s1) & lt(m2, s2)
    sell = ge(mx1, shift(upb)) & ge(mn1, mid) & lt(m1, s1) & gt(m2, s2)
    return to_sig(buy, sell)


# ---------------- 4) Swings High&Low RSI: метки RSI(7) ≤13 / ≥87 ----------------
def rsi_ext_signals(d):
    r = rsi(d["c"], 7)
    return to_sig(le(r, 13), ge(r, 87))


# ---------------- 5) Golden Swings: CMS Gold Buy (WaveTrend-дивергенция) ----------------
def gold_buy(d):
    c, l = d["c"], d["l"]; src = (d["h"] + d["l"] + c) / 3
    esa = emaN(src, 9); de = emaN(np.abs(src - esa), 9)
    with np.errstate(divide="ignore", invalid="ignore"):
        ci = (src - esa) / (0.015 * de)
    wt1 = emaN(ci, 12); wt2 = smaN(wt1, 3)
    s0, s1, s2, s3, s4 = wt2, shift(wt2), shift(wt2, 2), shift(wt2, 3), shift(wt2, 4)
    bot = gt(s4, s2) & gt(s3, s2) & lt(s2, s1) & lt(s2, s0) & le(s2, -65)   # fractalBot с лимитом −65
    lowPrev = shift(valuewhen0(bot, s2), 2)
    lowPrice = shift(valuewhen0(bot, shift(l, 2)), 2)
    lastRsi = shift(valuewhen0(bot, shift(rsi(c, 14), 2)), 2)
    bull = bot & lt(shift(l, 2), lowPrice) & gt(s2, lowPrev)
    g = bull & le(lowPrev, -75) & gt(wt2, -75) & le(lowPrev - wt2, -5) & lt(lastRsi, 30)
    return to_sig(g, np.zeros(len(c), bool))


# ---------------- 6) Trading Toolkit: регулярные RSI-дивергенции (pivot, подтверждение через lbR) ----------------
def pivot_div(osc, lo, hi, lbL, lbR, rmin_=5, rmax_=60):
    """Классика TradingView: pivotlow(osc,lbL,lbR) подтверждается на баре i (центр i−lbR).
    Бычья: osc[lbR] > osc на прошлом пивоте, low[lbR] < low на прошлом пивоте, баров между 5..60."""
    osc = _f(osc); n = len(osc); W = lbL + lbR + 1
    bull = np.zeros(n, bool); bear = np.zeros(n, bool)
    if n < W + 2:
        return bull, bear
    win = _sw(osc, W)
    cen = osc[lbL:n - lbR]
    isL = cen == win.min(axis=1)          # NaN в окне → False
    isH = cen == win.max(axis=1)
    for isP, out, price, sgn in ((isL, bull, lo, 1), (isH, bear, hi, -1)):
        bars = np.flatnonzero(isP) + W - 1           # бар подтверждения
        for k in range(1, len(bars)):
            i, p = bars[k], bars[k - 1]
            bs = i - p - 1
            if not (rmin_ <= bs <= rmax_):
                continue
            oc, op = osc[i - lbR], osc[p - lbR]; pc, pp = price[i - lbR], price[p - lbR]
            if sgn > 0 and oc > op and pc < pp:
                out[i] = True
            if sgn < 0 and oc < op and pc > pp:
                out[i] = True
    return bull, bear


def toolkit_signals(d):
    r = rsi(d["c"], 24)
    b, s = pivot_div(r, d["l"], d["h"], 10, 10)
    return to_sig(b, s)


# ---------------- 7) Fusion Strategy (FVG + супер-осциллятор) ----------------
def tsi(x, s, l_):
    pc = change(x)
    with np.errstate(divide="ignore", invalid="ignore"):
        return emaN(emaN(pc, l_), s) / emaN(emaN(np.abs(pc), l_), s)


def dmi_adx(d, di_len, adx_len):
    h, l = d["h"], d["l"]; up = change(h); dn = -change(l)
    pdm = np.where((up > dn) & (up > 0), up, 0.0); mdm = np.where((dn > up) & (dn > 0), dn, 0.0)
    trur = rma(tr_(d), di_len)
    with np.errstate(divide="ignore", invalid="ignore"):
        p = 100 * rma(pdm, di_len) / trur; m = 100 * rma(mdm, di_len) / trur
        s = p + m
        return 100 * rma(np.abs(p - m) / np.where(s == 0, 1, s), adx_len)


def _norm_hl(x, n):
    hi, lo = rmaxN(x, n), rminN(x, n)
    with np.errstate(divide="ignore", invalid="ignore"):
        return np.where(x > 0, x / hi, np.where(x < 0, x / np.abs(lo), 0.0))


def fusion_signals(d):
    o, h, l, c, v = d["o"], d["h"], d["l"], d["c"], d["v"]; n = len(c); lnt = 30
    h2, l2 = shift(h, 2), shift(l, 2)
    bfvg = gt(l, h2); sfvg = lt(h, l2)
    vol = gt(v, sma(v, 10))
    batr = gt(l - h2, smaN(l - h2, lnt) * 1.5); satr = gt(h - l2, smaN(h - l2, lnt) * 1.5)
    vol1 = shift(vol.astype(float)) == 1
    verifyb = bfvg & (vol1 | batr); verifys = sfvg & (vol1 | satr)
    ov = 3
    r_ = (rsi(c, 14) - 50) / 20
    # ta.mfi(close, 14)
    ch = change(c)
    up = rsumN(v * np.where(ch <= 0, 0, c), 14); dn = rsumN(v * np.where(ch >= 0, 0, c), 14)
    with np.errstate(divide="ignore", invalid="ignore"):
        mfi = 100 - 100 / (1 + up / dn)
    mfi = (mfi - 50) / 20
    macdRaw = ema(c, 12 * ov) - ema(c, 24 * ov)
    macd = _norm_hl(macdRaw, 12 * ov)
    cc = cci(c, 20 * ov) / 100
    ts = _norm_hl(tsi(c, 13 * ov, 26 * ov), 13 * ov)
    sd = stdevN(c, 10 * ov)
    upr = emaN(np.where(ch <= 0, 0, sd), 14); lwr = emaN(np.where(ch > 0, 0, sd), 14)
    with np.errstate(divide="ignore", invalid="ignore"):
        rvi = ((upr / (upr + lwr) * 100) - 50) / 20
    super_dir = (r_ + mfi + macd + cc + ts + rvi) / 6
    atrRaw = rma(tr_(d), 14)
    atrv = ((atrRaw / emaN(atrRaw, 14)) - 1) * (1 + stdevN(atrRaw, 14)) - 1
    adxRaw = dmi_adx(d, 17, 14)
    adxv = ((adxRaw / emaN(adxRaw, 14)) - 1) * (1 + stdevN(adxRaw, 14))
    rough = (atrv + adxv) / 2
    nondir = _norm_hl(rough, 200)
    buyS = xover(super_dir, -1.25) & ge(nondir, -0.25)
    sellS = xunder(super_dir, 1.25) & ge(nondir, -0.25)
    longE = gt(ema(c, 100), ema(c, 200)); shortE = lt(ema(c, 100), ema(c, 200))
    cb = cs = False; sig = np.zeros(n, dtype=int)
    for i in range(2, n):
        if buyS[i] and not cb:
            cb = True
        if sellS[i] and not cs:
            cs = True
        if verifyb[i] and cb and c[i] > c[i - 1]:
            if longE[i]:
                sig[i] = 1
            cb = False
        if verifys[i] and cs and c[i] < c[i - 1]:
            if shortE[i]:
                sig[i] = -1
                cs = False
    return sig


# ---------------- 8) Liquidity Range MACD - Strategy ----------------
def lrm_signals(d):
    o, c, v = d["o"], d["c"], d["v"]; n = len(c)
    m = ema(c, 12) - ema(c, 26); hist = m - ema(m, 9)
    with np.errstate(divide="ignore", invalid="ignore"):
        pml = v / np.abs(c - o)
    pml[~np.isfinite(pml)] = np.nan
    bound = emaN(pml, 10) + stdevN(pml, 10)
    liq = valuewhen0(xover(pml, bound), c)
    fe, se = emaN(liq, 80), emaN(liq, 200)
    # Range Filter (per=50, mult=3)
    smr = emaN(emaN(np.abs(change(c)), 50), 99) * 3.0
    filt = np.zeros(n); up = np.zeros(n); dn = np.zeros(n)
    for i in range(n):
        x, r, p = c[i], smr[i], (filt[i - 1] if i else 0.0)
        if r != r:
            filt[i] = x; continue
        filt[i] = (p if x - r < p else x - r) if x > p else (p if x + r > p else x + r)
        if i:
            up[i] = up[i - 1] + 1 if filt[i] > filt[i - 1] else (0 if filt[i] < filt[i - 1] else up[i - 1])
            dn[i] = dn[i - 1] + 1 if filt[i] < filt[i - 1] else (0 if filt[i] > filt[i - 1] else dn[i - 1])
    c1 = shift(c)
    lc = (c > filt) & (c != c1) & (up > 0)
    sc = (c < filt) & (c != c1) & (dn > 0)
    ci = np.zeros(n)
    for i in range(1, n):
        ci[i] = 1 if lc[i] else (-1 if sc[i] else ci[i - 1])
    ci1 = shift(ci)
    buy = lc & (ci1 == -1) & ge(hist, 0) & gt(fe, se)
    sell = sc & (ci1 == 1) & lt(hist, 0) & lt(fe, se)
    return to_sig(buy, sell)


# ---------------- 9) Trend Cycle Suite Volume - Strategy ----------------
def stoch_self(x, n):
    hi, lo = rmaxN(x, n), rminN(x, n)
    with np.errstate(divide="ignore", invalid="ignore"):
        k = 100 * (x - lo) / (hi - lo)
    k[~np.isfinite(k)] = np.nan
    return np.nan_to_num(ffill(k))          # nz(fixnan(...))


def tcs_signals(d):
    c, v = d["c"], d["v"]
    m = ema(c, 23) - ema(c, 50)
    k = stoch_self(m, 10); dd = ema(k, 3); kd = stoch_self(dd, 10)
    stc = np.clip(ema(kd, 3), 0, 100)
    es, el = ema(v, 5), ema(v, 10)
    with np.errstate(divide="ignore", invalid="ignore"):
        osc = 100 * (es - el) / el
    hu = hma(c, 180); hu2 = shift(hu, 2)
    buy = xover(stc, 75) & gt(osc, 5) & gt(hu, hu2) & lt(hu, c)
    sell = xunder(stc, 25) & gt(osc, 5) & lt(hu, hu2) & gt(hu, c)
    return to_sig(buy, sell)


# ---------------- 10) Schaff Trend Cycle (80/27/50, factor 0.5) ----------------
def stc_signals(d):
    c = d["c"]; L = 80; f = 0.5
    x = ema(c, 27) - ema(c, 50)
    lo, rg = rminN(x, L), rmaxN(x, L) - rminN(x, L)
    n = len(c); C5 = np.zeros(n); D = np.full(n, np.nan)
    for i in range(n):
        C5[i] = (x[i] - lo[i]) / rg[i] * 100 if rg[i] > 0 else (C5[i - 1] if i else 0.0)
        D[i] = C5[i] if (i == 0 or D[i - 1] != D[i - 1]) else D[i - 1] + f * (C5[i] - D[i - 1])
    lo2, rg2 = rminN(D, L), rmaxN(D, L) - rminN(D, L)
    D6 = np.zeros(n); E = np.zeros(n)
    for i in range(n):
        D6[i] = (D[i] - lo2[i]) / rg2[i] * 100 if rg2[i] > 0 else (D6[i - 1] if i else 0.0)
        E[i] = D6[i] if i == 0 else E[i - 1] + f * (D6[i] - E[i - 1])
    g = E > shift(E); g1 = shift(g.astype(float)) == 1
    red = ~g & (shift(E) == shift(E)); red1 = (shift(red.astype(float)) == 1)
    return to_sig(g & ~g1, red & ~red1)


# ---------------- 11) Stochastic OTT RSI Scalping: DMI-Stochastic B/S ----------------
def dmistoch_signals(d):
    h, l = d["h"], d["l"]; n = len(h)
    hd = change(h); ld = -change(l)
    pdm = np.where((hd > ld) & (hd > 0), hd, 0.0); mdm = np.where((ld > hd) & (ld > 0), ld, 0.0)
    tr = tr_(d); L = 20

    def ww(p):
        out = np.zeros(n); prev = 0.0
        for i in range(n):
            prev = (prev * (L - 1) + p[i]) / L; out[i] = prev
        return out
    A = ww(tr)
    with np.errstate(divide="ignore", invalid="ignore"):
        osc = 100 * ww(pdm) / A - 100 * ww(mdm) / A
        hi, lo = rmaxN(osc, 5), rminN(osc, 5)
        st = rsumN(osc - lo, 5) / rsumN(hi - lo, 5) * 100
    s1 = shift(st)
    return to_sig(lt(s1, 10) & gt(st, 10), gt(s1, 90) & lt(st, 90))


# ---------------- 12) 3 Swing Failure Pattern (3 копии с одинаковыми настройками → один) ----------------
def sfp_signals(d, ln=5):
    o, h, l, c = d["o"], d["h"], d["l"], d["c"]; n = len(c)
    W = ln + 2
    ph = np.zeros(n, bool); pl = np.zeros(n, bool)
    if n > W:   # pivothigh(5,1): центр i−1 подтверждается на баре i
        wh, wl = _sw(h, W), _sw(l, W)
        ph[W - 1:] = h[W - 2:n - 1] == wh.max(axis=1)
        pl[W - 1:] = l[W - 2:n - 1] == wl.min(axis=1)
    sig = np.zeros(n, dtype=int)
    sH = sL = np.nan; bH = bL = 0
    pH = dict(act=False, conf=True, sw=np.nan, bx=0, op=np.nan)
    pL = dict(act=False, conf=True, sw=np.nan, bx=0, op=np.nan)
    for i in range(n):
        # --- медвежий SFP
        if ph[i]:
            bH, sH = i - 1, h[i - 1]
        if h[i] > sH and o[i] < sH and c[i] < sH:
            op = min(sH, l[bH + 1:i].min()) if i - bH - 1 >= 1 else sH
            pH = dict(act=True, conf=False, sw=sH, bx=bH, op=op)
        if pH["act"] and not pH["conf"] and c[i] < pH["op"]:
            pH["conf"] = True; sig[i] = -1
        if pH["act"] and (i - pH["bx"] > 500 or c[i] > pH["sw"]):
            pH["act"] = False
        # --- бычий SFP
        if pl[i]:
            bL, sL = i - 1, l[i - 1]
        if l[i] < sL and o[i] > sL and c[i] > sL:
            op = max(sL, h[bL + 1:i].max()) if i - bL - 1 >= 1 else sL
            pL = dict(act=True, conf=False, sw=sL, bx=bL, op=op)
        if pL["act"] and not pL["conf"] and c[i] > pL["op"]:
            pL["conf"] = True; sig[i] = 1 if sig[i] == 0 else 0
        if pL["act"] and (i - pL["bx"] > 500 or c[i] < pL["sw"]):
            pL["act"] = False
    return sig


# ---------------- 13) Boom Hunter (Divergence / Divergence + / MultiZ — логика одна) ----------------
def _boom_x(c, lp):
    n = len(c); pi = np.pi
    a1_ = (np.cos(.707 * 2 * pi / 100) + np.sin(.707 * 2 * pi / 100) - 1) / np.cos(.707 * 2 * pi / 100)
    k0 = (1 - a1_ / 2) ** 2; k1 = 2 * (1 - a1_); k2 = (1 - a1_) ** 2
    a1 = np.exp(-1.414 * pi / lp); c2 = 2 * a1 * np.cos(1.414 * pi / lp); c3 = -a1 * a1; c1 = 1 - c2 - c3
    HP = np.zeros(n); F = np.zeros(n); X = np.zeros(n); peak = 0.0
    cc = np.r_[c[0], c[0], c]            # nz(close[1]) на старте заменён на close[0] (без скачка)
    for i in range(n):
        HP[i] = k0 * (cc[i + 2] - 2 * cc[i + 1] + cc[i]) + k1 * (HP[i - 1] if i else 0) - k2 * (HP[i - 2] if i > 1 else 0)
        F[i] = c1 * (HP[i] + (HP[i - 1] if i else 0)) / 2 + c2 * (F[i - 1] if i else 0) + c3 * (F[i - 2] if i > 1 else 0)
        peak *= .991
        if abs(F[i]) > peak:
            peak = abs(F[i])
        X[i] = F[i] / peak if peak != 0 else (X[i - 1] if i else 0)
    return X


def boom_signals(d):
    c = d["c"]
    Q1 = _boom_x(c, 6)                         # K1 = 0 → Quotient1 = X
    X2 = _boom_x(c, 27); Q3 = (X2 + 0.8) / (0.8 * X2 + 1)
    q1 = Q1 * 60 + 50; trig = sma(q1, 2)
    co, cu = xover(q1, trig), xunder(q1, trig)
    bs = lambda x: barssince(x)  # noqa: E731
    warn2, warn3 = xover(Q1, -0.9), xunder(Q1, 0.9)
    enter3 = (Q3 <= -0.9) & co & le(bs(warn2), 7) & (q1 <= 20) & le(bs(xover(q1, 20)), 21)
    enter5 = le(bs((q1 <= 0) & cu), 5) & co
    enter6 = le(bs((q1 <= 20) & cu), 11) & co & (q1 <= 60)
    enter7 = (Q3 <= -0.9) & co
    senter3 = (Q3 >= -0.9) & cu & le(bs(warn3), 7) & (q1 >= 99) & le(bs(xover(q1, 80)), 21)
    return to_sig(enter3 | enter5 | enter6 | enter7, senter3)


# ---------------- 14) Machine Learning: Lorentzian Classification ----------------
def _normalize_exp(x):
    """ml.normalize: по историческим (накопленным) min/max — без будущего."""
    x = _f(x); mn = np.fmin.accumulate(np.where(np.isnan(x), np.inf, x))
    mx = np.fmax.accumulate(np.where(np.isnan(x), -np.inf, x))
    with np.errstate(invalid="ignore"):
        return (x - mn) / np.maximum(mx - mn, 1e-9)


def _n_adx(d, L=20):
    h, l, c = d["h"], d["l"], d["c"]; n = len(c)
    pc, ph_, pl_ = np.r_[0.0, c[:-1]], np.r_[0.0, h[:-1]], np.r_[0.0, l[:-1]]
    tr = np.maximum(np.maximum(h - l, np.abs(h - pc)), np.abs(l - pc))
    dp = np.where(h - ph_ > pl_ - l, np.maximum(h - ph_, 0), 0.0)
    dm = np.where(pl_ - l > h - ph_, np.maximum(pl_ - l, 0), 0.0)
    T = np.zeros(n); P = np.zeros(n); M = np.zeros(n)
    for i in range(n):
        T[i] = (T[i - 1] - T[i - 1] / L if i else 0) + tr[i]
        P[i] = (P[i - 1] - P[i - 1] / L if i else 0) + dp[i]
        M[i] = (M[i - 1] - M[i - 1] / L if i else 0) + dm[i]
    with np.errstate(divide="ignore", invalid="ignore"):
        dip, dim = P / T * 100, M / T * 100
        dx = np.abs(dip - dim) / (dip + dim) * 100
    return rma(dx, L) / 100


_LC_CACHE = {}


def lorentzian(d, W=2000, k=8):
    """Возвращает (startLong, startShort). Признаки по умолчанию: RSI14, WT10/11, CCI20, ADX20, RSI9.
    Метка обучения как в оригинале: y[j] = −1 если close[j−4] < close[j], +1 если >, 0 иначе (только прошлое).
    Соседи: скользящее окно последних W баров (в оригинале — первые 2000 баров графика, а прогноз считается
    только на последних 2000 барах — для бэктеста это неприменимо). Отбор соседей — точная копия цикла
    Pine (i%4, lastDistance, сдвиг при >k)."""
    key = (len(d["c"]), float(d["t"][0]), float(d["c"][0]), float(d["c"][-1]))
    if key in _LC_CACHE:
        return _LC_CACHE[key]
    h, l, c = d["h"], d["l"], d["c"]; n = len(c); hlc3 = (h + l + c) / 3
    f1 = rsi(c, 14) / 100
    e1 = emaN(hlc3, 10); e2 = emaN(np.abs(hlc3 - e1), 10)
    with np.errstate(divide="ignore", invalid="ignore"):
        w1 = emaN((hlc3 - e1) / (0.015 * e2), 11)
    f2 = _normalize_exp(w1 - smaN(w1, 4))
    f3 = _normalize_exp(cci(c, 20))
    f4 = _n_adx(d, 20)
    f5 = rsi(c, 9) / 100
    F = np.column_stack([f1, f2, f3, f4, f5])
    valid = ~np.isnan(F).any(axis=1)
    c4 = shift(c, 4)
    y = np.where(c4 < c, -1, np.where(c4 > c, 1, 0))
    start = int(np.argmax(valid)) + 4 if valid.any() else n
    pred = np.zeros(n)
    kk = int(round(k * 3 / 4))
    for i in range(start, n):
        j0 = max(start, i - W + 1)
        idx = np.arange(j0, i + 1)
        idx = idx[(np.arange(len(idx)) % 4) != 0]          # `i%4` в цикле оригинала
        if not len(idx):
            continue
        dist = np.log1p(np.abs(F[idx] - F[i])).sum(axis=1)
        last = -1.0; ds = []; ps = []; pos = 0; m = len(dist)
        while pos < m:
            msk = dist[pos:] >= last
            j = int(msk.argmax())
            if not msk[j]:
                break
            pos += j
            last = dist[pos]; ds.append(last); ps.append(y[idx[pos]])
            if len(ps) > k:
                last = ds[kk]; ds.pop(0); ps.pop(0)
            pos += 1
        pred[i] = sum(ps)
    # фильтры: волатильность (atr1 > atr10) и режим (KLMF, порог −0.1); ADX-фильтр выкл.
    tr = tr_(d)
    fvol = gt(tr, rma(tr, 10))
    src = (d["o"] + h + l + c) / 4
    v1 = np.zeros(n); v2 = np.zeros(n); kl = np.zeros(n)
    for i in range(n):
        v1[i] = 0.2 * (src[i] - (src[i - 1] if i else src[i])) + 0.8 * (v1[i - 1] if i else 0)
        v2[i] = 0.1 * (h[i] - l[i]) + 0.8 * (v2[i - 1] if i else 0)
        om = abs(v1[i] / v2[i]) if v2[i] else 0.0
        al = (-om * om + np.sqrt(om ** 4 + 16 * om ** 2)) / 8
        kl[i] = al * src[i] + (1 - al) * (kl[i - 1] if i else src[i])
    acs = np.abs(change(kl)); ea = emaN(acs, 200)
    with np.errstate(divide="ignore", invalid="ignore"):
        freg = ge((acs - ea) / ea, -0.1)
    fall = fvol & freg
    sig = np.zeros(n)
    for i in range(1, n):
        sig[i] = 1 if (pred[i] > 0 and fall[i]) else (-1 if (pred[i] < 0 and fall[i]) else sig[i - 1])
    chg = sig != shift(sig)
    # ядро: rationalQuadratic(close, h=8, r=8, x=25) — только прошлые бары (i = 0..26)
    ii = np.arange(27); wq = (1 + ii ** 2 / (8 ** 2 * 2 * 8.0)) ** -8.0; wq /= wq.sum()
    yh = np.convolve(c, wq)[:n]; yh[:26] = np.nan
    bullR = lt(shift(yh), yh); bearR = gt(shift(yh), yh)
    sl_ = (sig == 1) & chg & bullR
    ss_ = (sig == -1) & chg & bearR
    if len(_LC_CACHE) > 200:
        _LC_CACHE.clear()
    _LC_CACHE[key] = (sl_, ss_)
    return sl_, ss_


def lorentzian_sig(d):
    a, b = lorentzian(d)
    return to_sig(a, b)


A23 = (2.0, 3.0)
TESTS.update({
    "NWE 8/3 — разворот": lambda d: run_reverse(d, nwe_signals(d)),
    "NWE 8/3 + стоп 2/тейк 3 ATR":            lambda d: run_reverse(d, nwe_signals(d), sl_tp=A23),
    "2x NWE (2/6 + 8/3) — разворот":          lambda d: run_reverse(d, nwe2x_signals(d)),
    "2x NWE + стоп 2/тейк 3 ATR":             lambda d: run_reverse(d, nwe2x_signals(d), sl_tp=A23),
    "K's Reversal — разворот":                lambda d: run_reverse(d, ks_signals(d)),
    "K's Reversal + стоп 2/тейк 3 ATR":       lambda d: run_reverse(d, ks_signals(d), sl_tp=A23),
    "Swings RSI7 13/87 — разворот":           lambda d: run_reverse(d, rsi_ext_signals(d)),
    "Swings RSI7 13/87 + стоп 2/тейк 3 ATR":  lambda d: run_reverse(d, rsi_ext_signals(d), sl_tp=A23),
    "Golden Gold Buy + стоп 2/тейк 3 ATR":    lambda d: run_exit(d, gold_buy(d), atr_sl_tp=A23, refresh=False),
    "Golden Gold Buy → выход по ▼NWE":        lambda d: run_exit(d, gold_buy(d), xsig=np.where(nwe_signals(d) < 0, 1, 0)),
    "Toolkit RSI24-дивергенции — разворот":   lambda d: run_reverse(d, toolkit_signals(d)),
    "Toolkit RSI24-див. + стоп 2/тейк 3 ATR": lambda d: run_reverse(d, toolkit_signals(d), sl_tp=A23),
    "Fusion Strategy — оригинал":             lambda d: run_reverse(d, fusion_signals(d)),
    "Fusion Strategy + стоп 2/тейк 3 ATR":    lambda d: run_reverse(d, fusion_signals(d), sl_tp=A23),
    "Liquidity Range MACD — оригинал":        lambda d: run_reverse(d, lrm_signals(d)),
    "Liquidity Range MACD + стоп 2/тейк 3 ATR": lambda d: run_reverse(d, lrm_signals(d), sl_tp=A23),
    "Trend Cycle Suite — оригинал TP3%/SL1%": lambda d: run_exit(d, tcs_signals(d), pct_sl_tp=(0.01, 0.03)),
    "Trend Cycle Suite + стоп 2/тейк 3 ATR":  lambda d: run_exit(d, tcs_signals(d), atr_sl_tp=A23, refresh=False),
    "STC 80/27/50 — разворот":                lambda d: run_reverse(d, stc_signals(d)),
    "STC 80/27/50 + стоп 2/тейк 3 ATR":       lambda d: run_reverse(d, stc_signals(d), sl_tp=A23),
    "Stoch OTT: DMI-Stoch B/S — разворот":    lambda d: run_reverse(d, dmistoch_signals(d)),
    "Stoch OTT: DMI-Stoch + стоп 2/тейк 3 ATR": lambda d: run_reverse(d, dmistoch_signals(d), sl_tp=A23),
    "3 SFP ▲▼ — разворот":                    lambda d: run_reverse(d, sfp_signals(d)),
    "3 SFP ▲▼ + стоп 2/тейк 3 ATR":           lambda d: run_reverse(d, sfp_signals(d), sl_tp=A23),
    "Boom Hunter Long/Short — разворот":      lambda d: run_reverse(d, boom_signals(d)),
    "Boom Hunter + стоп 2/тейк 3 ATR":        lambda d: run_reverse(d, boom_signals(d), sl_tp=A23),
    "Lorentzian — выход через 4 бара":        lambda d: run_exit(d, lorentzian_sig(d), hold=4),
    "Lorentzian — разворот":                  lambda d: run_reverse(d, lorentzian_sig(d)),
})


def half(d, w):
    n = len(d["c"]); m = n // 2; sl = slice(0, m) if w == 0 else slice(m, n)
    return {k: v[sl] for k, v in d.items()}


def main():
    say(f"Стратегии из сборника Crypto-Scalping · {time.strftime('%Y-%m-%d %H:%M')}")
    say("Средний % на монету (сумма сделок), комиссия рынок 0.09%×2, вход по открытию следующей свечи")
    passed = {}
    global TFS, TESTS, OUT
    import sys  # noqa: PLC0415
    if len(sys.argv) > 1 and sys.argv[1] == "neighbors":
        return saw()
    for code, tf, nb in TFS:
        data = {s: T.klines(s, code, nb) for s in T.COINS}
        data = {s: d for s, d in data.items() if len(d["c"]) >= 1000}
        if not data:
            continue
        days = np.median([(d["t"][-1] - d["t"][0]) / 86400000 for d in data.values()])
        say(""); say(f"=== {tf} · ~{days:.0f} дней · монет {len(data)} ===")
        for name, fn in TESTS.items():
            full, h1, h2, nn = [], [], [], 0
            for d in data.values():
                a = fn(d); full.append(a[0]); nn += a[1]
                h1.append(fn(half(d, 0))[0]); h2.append(fn(half(d, 1))[0])
            avg, a1, a2 = np.mean(full) * 100, np.mean(h1) * 100, np.mean(h2) * 100
            plus = sum(x > 0 for x in full)
            ok = avg > 0 and plus >= 8 and a1 > 0 and a2 > 0
            if ok:
                passed.setdefault(name, []).append(tf)
            say(f"  {name:<38} {avg:+8.1f}% · в плюсе {plus:>2}/{len(full)} · 1-я {a1:+7.1f}% · 2-я {a2:+7.1f}%"
                f" · сделок {nn} (~{nn / len(full):.0f} на монету)  {'✅' if ok else '❌'}")
    say(""); say("ИТОГ:")
    if not passed:
        say("  ни одна не прошла")
    for k, v in passed.items():
        say(f"  {'★ ' if len(v) >= 2 else '  '}{k}: {', '.join(v)}")
    say("★ — прошла на 2+ ТФ: кандидат на бумажного бота.")
    OUT.parent.mkdir(exist_ok=True)
    OUT.write_text("\n".join(LINES), encoding="utf-8")
    print(f"\nОтчёт: {OUT}")


def resample(d, k):
    """Свечи k часов из часовых (корзины от 00:00 UTC), последняя неполная отбрасывается."""
    ms = k * 3600_000
    b = (d["t"] // ms).astype(np.int64)
    cut = np.r_[0, np.flatnonzero(np.diff(b)) + 1]
    out = {"t": d["t"][cut], "o": d["o"][cut], "h": np.maximum.reduceat(d["h"], cut),
           "l": np.minimum.reduceat(d["l"], cut), "c": d["c"][np.r_[cut[1:] - 1, len(b) - 1]],
           "v": np.add.reduceat(d["v"], cut)}
    sizes = np.diff(np.r_[cut, len(b)])
    keep = np.ones(len(cut), bool)
    keep[0] = sizes[0] == k; keep[-1] = sizes[-1] == k
    return {kk: v[keep] for kk, v in out.items()}


def saw():
    """2026-10-15: «пила» таймфреймов 1h…12h с шагом 1 ч для кандидатов. Настоящий эффект держится плавно на
    соседних ТФ, случайность торчит одним пиком."""
    global OUT
    import smc_fvg_pack_test as SM  # noqa: PLC0415
    OUT = OUT.with_name("pack_strats_saw.txt")
    tests = {k: TESTS[k] for k in ["Liquidity Range MACD — оригинал", "Fusion Strategy + стоп 2/тейк 3 ATR",
                                    "Golden Gold Buy + стоп 2/тейк 3 ATR", "3 SFP ▲▼ + стоп 2/тейк 3 ATR",
                                    "SQZMOM&Trendilo — как в оригинале"]}
    tests["ChoCh разворот (10/10)"] = lambda d: SM.choch(d, 10)[:2]
    tests["RSI+BB лонг + стоп −15%"] = lambda d: SM.rsi_bb(d, 1, 0.15)[:2]
    say(f"«Пила» таймфреймов 1h…12h · {time.strftime('%Y-%m-%d %H:%M')} · свечи собраны из часовых Bybit")
    say("В клетке: средний % на монету · ✅ = в плюсе, ≥8/12 монет и обе половины > 0")
    raw = {s: T.klines(s, "60", 30000) for s in T.COINS}
    raw = {s: d for s, d in raw.items() if len(d["c"]) >= 3000}
    days = np.median([(d["t"][-1] - d["t"][0]) / 86400000 for d in raw.values()])
    say(f"Монет {len(raw)} · часовой истории ~{days:.0f} дней")
    KS = list(range(1, 13))
    res = {n: {} for n in tests}
    for k in KS:
        data = {s: resample(d, k) for s, d in raw.items()}
        data = {s: d for s, d in data.items() if len(d["c"]) >= 300}
        for name, fn in tests.items():
            full, h1, h2 = [], [], []
            for d in data.values():
                try:
                    full.append(fn(d)[0]); h1.append(fn(half(d, 0))[0]); h2.append(fn(half(d, 1))[0])
                except Exception:  # noqa: BLE001
                    continue
            if len(full) < 6:
                continue
            avg = np.mean(full) * 100; plus = sum(x > 0 for x in full)
            ok = avg > 0 and plus >= 8 and np.mean(h1) > 0 and np.mean(h2) > 0
            res[name][k] = (avg, plus, ok)
        print(f"  {k}h готово", flush=True)
    say("")
    say(f"  {'стратегия':<34}" + "".join(f"{str(k) + 'h':>9}" for k in KS) + "   ✅ из 12")
    for name, row in res.items():
        cells = "".join(f"{row[k][0]:+7.0f}{'✅' if row[k][2] else ' '} " if k in row else f"{'—':>9}" for k in KS)
        say(f"  {name[:34]:<34}{cells}   {sum(1 for v in row.values() if v[2])}")
    say("")
    say("Как читать: устойчивая стратегия — ✅ подряд на нескольких соседних ТФ (например 3h–6h).")
    say("Один ✅ среди минусов вокруг = случайность. Подряд 3+ ✅ — кандидат на бумажного бота на центральном ТФ.")
    OUT.parent.mkdir(exist_ok=True)
    OUT.write_text("\n".join(LINES), encoding="utf-8")
    print(f"\nОтчёт: {OUT}")


if __name__ == "__main__":
    main()
