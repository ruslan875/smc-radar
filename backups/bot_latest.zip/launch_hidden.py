"""launch_hidden.py — 2026-10-05. Запуск бота БЕЗ окна консоли (вместо `start "..." cmd /k ...`).
  python launch_hidden.py ИМЯ скрипт.py [аргументы...]
Вывод пишется в logs/ИМЯ.log (смотреть: «Мои боты» / log, или открыть файл). Процесс живёт отдельно от окна,
которое его запустило. Если такой скрипт уже запущен — второй раз не запускается.
"""
import os, subprocess, sys
from pathlib import Path

BASE = Path(__file__).resolve().parent
name, script, args = sys.argv[1], sys.argv[2], sys.argv[3:]
py = BASE / "venv" / "Scripts" / "python.exe"
py = str(py if py.exists() else sys.executable)
(BASE / "logs").mkdir(exist_ok=True)
log = open(BASE / "logs" / f"{name}.log", "a", encoding="utf-8", errors="replace")
log.write(f"\n===== старт {name}: {script} {' '.join(args)} =====\n"); log.flush()
flags = 0
if os.name == "nt":
    flags = 0x08000000 | 0x00000008 | 0x00000200   # CREATE_NO_WINDOW | DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
    flags &= ~0x00000008                            # DETACHED и NO_WINDOW вместе не нужны — оставляем NO_WINDOW
env = dict(os.environ, PYTHONUTF8="1", PYTHONIOENCODING="utf-8", PYTHONUNBUFFERED="1")
subprocess.Popen([py, "-u", script, *args], cwd=str(BASE), stdout=log, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                 creationflags=flags, env=env, close_fds=True)
print(f"  {name}: запущен без окна, лог logs\\{name}.log")
