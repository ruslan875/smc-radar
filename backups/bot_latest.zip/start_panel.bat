@echo off
rem 2026-09-06: double-click launcher for windows_app's local admin panel.
rem Changes into this .bat file's own folder first, so it works correctly
rem no matter where the shortcut/double-click happens from -- app/config.py
rem and the trade/param stores resolve paths relative to the repo, so the
rem working directory matters (also where .env gets picked up from).
cd /d "%~dp0"
python windows_app\run.py
pause
