# SMC Signal Bot → Telegram

Watches a list of Bybit perpetual futures and posts a signal card (chart
image + entry/SL/TP/stats) to your Telegram bot/channel, in the layout
of the "Адаптивная стратегия" example — but wired to your actual entry
rule, not a generic approximation:

    слом структуры (BOS/CHoCH) + ордерблок (± FVG) + РЕАКЦИЯ от зоны,
    в согласии со старшим таймфреймом (1H/4H) для тренда.
    Плюс отдельно: снятие ликвидности (sweep) как самостоятельный сетап.
    Без сетапа — без сделки.

Concretely, this runs as a **two-stage state machine**, not a
single-pass check:

1. **Stage 1 — arm.** A structure break (BOS or CHoCH) just confirmed on
   a closed candle → the bot finds the order block behind the impulse
   (extended with any FVG inside the same leg → tagged `OB+FVG` when
   present) and *remembers it*. Nothing is sent yet.
2. **Stage 2 — wait for reaction.** On every later poll, the bot checks
   whether price has come back and tapped that zone, and whether the
   candle that tapped it *closed back in the trade direction* (a
   reaction, not just a wick through it). Only then does it fire a
   signal — this is the "умение ждать" part, enforced in code instead
   of by willpower.
3. **Liquidity sweeps fire immediately**, separately from the above:
   a wick that pierces a recent swing high/low and closes back inside
   on the *same* bar already *is* the reaction, so there's no separate
   wait stage for that setup.
4. **Higher-timeframe filter.** Before arming or firing anything, the
   bot reads the same structure logic one timeframe up (15m → 4h, 5m →
   1h) and only acts when the entry-timeframe direction agrees with it
   — mirroring "1H/4H для тренда, 5m/15m для входов". Set
   `USE_HTF_FILTER=false` in `.env` to disable this if you want every
   raw signal regardless of higher-TF context.

Armed-but-unreacted zones are persisted in `state.json` between polls,
so a break that happens now and gets tapped six hours later still fires
correctly.

This is a self-built, independent detector (fractal swing highs/lows →
market structure → break → order block/FVG → reaction). It is **not** a
copy of any paid indicator's source code — it reproduces the same *kind*
of read, tuned in `app/smc.py`. Treat its output as a second, transparent
opinion to check against your own chart reading, not a black-box signal
to blindly follow — see the disclaimer baked into every card.

## What you get

- `app/data.py` — pulls public OHLCV klines from Bybit (no API key needed)
- `app/smc.py` — swings, structure, BOS/CHoCH, order block + FVG, liquidity sweep, the two-stage zone state machine
- `app/state.py` — persists pending zones + sent-signal dedupe across polls
- `app/stats.py` — daily/average volume, volatility (ATR%), BTC correlation
- `app/chart.py` — renders the dark-theme candlestick card with SL/TP lines (RSI panel off by default — see below)
- `app/format.py` — builds the Telegram caption text
- `app/telegram_client.py` — thin Telegram Bot API wrapper (sendPhoto)
- `main.py` — orchestrator / CLI entry point

### About the RSI panel

Off by default (`SHOW_RSI=false` in `.env.example`) because the reaction
logic never reads it — it played no role in any signal you saw. Turn it
on only if you personally want it as a visual reference; it stays purely
decorative either way.

## 1. Create your Telegram bot (you do this step — I can't act as you in Telegram)

1. In Telegram, open a chat with **@BotFather**.
2. Send `/newbot`, give it a name and a username (must end in `bot`).
3. BotFather replies with a token like `123456789:AAExample...` — save it.
4. Create the channel/group where you want signals to appear (or use an
   existing one), then add your new bot to it **as admin** (needs
   permission to post messages).
5. Get the chat id:
   - Easiest: send any message in the channel, then open
     `https://api.telegram.org/bot<TOKEN>/getUpdates` in a browser and
     look for `"chat":{"id": ...}` in the response. Channel ids are
     usually negative, like `-1001234567890`.
   - Alternative: forward a message from the channel to
     [@userinfobot](https://t.me/userinfobot) or
     [@getidsbot](https://t.me/getidsbot).

## 2. Install

Requires Python 3.10+.

```bash
cd smc-signal-bot
python3 -m venv venv
source venv/bin/activate       # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
# edit .env: paste your TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID
```

Edit `watchlist.json` (or set `WATCHLIST=BTCUSDT,ETHUSDT,...` in `.env`)
to the Bybit perpetual symbols you want watched (must exist on Bybit
linear futures, e.g. `BTCUSDT`, `ZECUSDT`, `HYPEUSDT`).

2026-08-22: instead of (or in addition to) a fixed watchlist, you can have
the bot scan the top 25/50/100 USDT perpetuals by 24h volume instead --
message the bot from your own chat with `/scan` (or "настройки") and pick
from the button menu. This is a runtime setting (`scan_settings.json`,
owner-only), not a `.env` value, and can be changed anytime without
restarting the bot -- see `app/scan_settings.py`.

## 3. Try it

```bash
# One pass over the watchlist without touching Telegram: arms/checks zones
# for real, prints [ARMED]/[SENT] lines, saves any fired card's PNG to /tmp
python main.py --dry-run --once

# Force whatever's currently true for one symbol (an active reaction, or
# a fresh break arming) straight to Telegram, ignoring dedupe -- the
# fastest way to confirm delivery + formatting actually work end to end
python main.py --test ZECUSDT

# One full pass over the whole watchlist, only posting genuinely fresh reactions/sweeps
python main.py --once

# Run forever, checking the watchlist every POLL_SECONDS (default 60s)
python main.py
```

`state.json` (created automatically) remembers both pending zones
(Stage 1 → Stage 2) and already-sent signals, so a fresh BOS/CHoCH only
ever gets *posted* once it reacts, and only once.

Expect `--test SYMBOL` to sometimes print "No reaction/sweep to send"
if the current situation is only an armed zone still waiting — that's
correct behavior (no setup, no trade), not a bug; re-run `--once` later
or watch the `[ARMED]` log line to see what it's tracking.

> Note: this bot was built and logic-tested inside a sandboxed
> environment that has no outbound access to Bybit or Telegram, so the
> live network calls could only be verified with synthetic data on my
> end (see the sample chart you were sent). Run the smoke test above
> (`--test SYMBOL`) first thing after setup to confirm real data +
> real Telegram delivery both work end to end.

## 4. Keep it running 24/7

Pick whichever fits you:

**A. Your own PC** — simplest, but only posts while your machine is on
and the script is running:
```bash
python main.py
```

**B. A small VPS ($4-6/mo, e.g. Hetzner/DigitalOcean/Timeweb) with systemd**
so it survives reboots and keeps running in the background:
```ini
# /etc/systemd/system/smc-bot.service
[Unit]
Description=SMC signal bot
After=network.target

[Service]
WorkingDirectory=/opt/smc-signal-bot
ExecStart=/opt/smc-signal-bot/venv/bin/python main.py
Restart=always
RestartSec=10
EnvironmentFile=/opt/smc-signal-bot/.env

[Install]
WantedBy=multi-user.target
```
```bash
sudo systemctl enable --now smc-bot
journalctl -u smc-bot -f     # watch logs
```

**C. Docker**, if you'd rather containerize:
```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
CMD ["python", "main.py"]
```

## Tuning

- `TIMEFRAME` in `.env` — your entry timeframe (5m/15m). The HTF filter
  auto-picks the trend timeframe (15m→4h, 5m→1h) to match "1H/4H для
  тренда, 5m/15m для входов".
- `USE_HTF_FILTER` — `true` (default) requires the entry-TF direction to
  agree with the higher-TF structure; `false` fires on the entry
  timeframe alone.
- `SWING_LEFT` / `SWING_RIGHT` — how many bars on each side confirm a
  swing point. Smaller = more (and noisier) signals, larger = fewer,
  more significant ones. Also controls how far back the bot will search
  for the zone-expiry window (`expires_after_bars` in `app/smc.py`,
  default 60 bars — a zone nobody's come back to after that long is
  dropped rather than kept live forever).
- `SHOW_RSI` — `false` by default, see above.
- Risk multiples for the three take-profits are fixed at 1R/2R/3R in
  `main.py` (`RISK_MULTIPLES`), matching the reference card's "1/1, 1/2
  и 1/3". R is measured from the *reaction* entry to the zone-based stop,
  not from the original break candle.

## Honest limitations

- The structure/OB/FVG/sweep detection is a reasonable, transparent SMC
  implementation — it will **not** match your TradingView "AlphaX"
  indicator signal-for-signal (that's a closed-source paid script we
  don't have access to). Use this as a second, independent screener that
  actually enforces "wait for reaction" the way you do, not a
  replacement for your own TradingView analysis.
- The "reaction" check is deliberately simple (close back in the trade
  direction, not a wick) — it doesn't require a specific candle pattern
  (engulfing, pin bar, etc.). If you want that stricter, `check_zone_reaction`
  in `app/smc.py` is the one function to edit.
- Correlation-with-BTC and volatility numbers are computed with plain,
  documented formulas (Pearson correlation of returns; ATR% of price) —
  they may differ from whatever proprietary formula the reference
  channel uses.
- No backtest is bundled. Before trusting it with real size, run it in
  `--dry-run` for a while, read the `[ARMED]` / `[SENT]` log lines
  against your own chart, and sanity-check that the zones it's tracking
  are ones you'd have drawn yourself.
