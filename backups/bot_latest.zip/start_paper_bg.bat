@echo off
chcp 65001 >nul
cd /d "%~dp0"

if exist "venv\Scripts\pythonw.exe" (
    set PYW=venv\Scripts\pythonw.exe
) else (
    set PYW=pythonw
)

echo.
echo  Запускаю paper-трейдинг в ФОНЕ (окно можно закрыть).
echo  Вывод пишется в paper_live.log, состояние - в paper_live_state.json
echo.
echo  Посмотреть таблицу в любой момент:  .\paper_status.bat
echo  Остановить:                         .\stop_paper.bat
echo.

start "" %PYW% paper_live.py --no-dashboard --telegram --log-file paper_live.log %*

echo  Запущено.
timeout /t 3 >nul
