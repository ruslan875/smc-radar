@echo off
REM 2026-11-21: ночной бэкап кода/конфигов/state бота в GitHub (backups/bot_latest.zip).
REM Запускается Планировщиком задач ежедневно в 04:00. Лог: logs\backup_to_cloud.log
cd /d "%~dp0"
if not exist logs mkdir logs
venv\Scripts\python.exe backup_to_cloud.py >> logs\backup_to_cloud.log 2>&1
