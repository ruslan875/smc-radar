"""ginarea_ind_test.py — 2026-10-18. Приближённый бэктест бота GinArea «Btc long» (Indicator grid, BTC, OKX, LONG).

Настройки со скриншотов: RSI(14) на 5m < 35, «разовая проверка» ВКЛ (условие проверяется только для старта цикла),
60 ордеров, шаг 0.1% (% режим), размер 0.0001 BTC × мультипликатор 1.01, цель 0.25% от средней,
мин. стоп 0.05%, макс. стоп 0.5%, «не ухудшать цену входа» и «выход по средней» ВКЛ,
тейк бота +6 $ (после тейка перезапуск, тейк +3 $), СТОП-ЛОССА НЕТ.

Модель (алгоритм GinArea закрыт — приближение):
  * Цикл стартует, когда закрытая 5m-свеча дала RSI14 < 35: IN по открытию следующей минуты.
  * Доборы каждые 0.1% ниже последнего, размер растёт ×1.01, максимум 60 (покрывают ≈ −6% от старта).
  * Выход по средней: цена ≥ средняя × (1 + 0.25%) → стоп-профит = max(пик × (1 − 0.5%), триггер × (1 − 0.05%)),
    подтягивается за ценой → закрытие всей позиции. Новый цикл — снова только по RSI < 35.
  * Тейк бота: PnL с (пере)запуска ≥ TP → закрыть всё, TP += 3.
  * Стопа нет: показываем худшую просадку открытой позиции и на сколько дней она «зависала».
  * Комиссия: taker 0.05% и maker 0.02%. Остановка «30 мин / 50 $» не моделируется.
Ничего не торгует. Запуск: ginarea_ind_test.bat [дней, по умолч. 120] → bt_lab_bots/ginarea_ind_test.txt
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
from ginarea_dyn_test import okx_1m  # noqa: E402  тот же загрузчик и кеш свечей OKX BTC 1m

OUT = BASE / "bt_lab_bots" / "ginarea_ind_test.txt"
P = dict(rsi_len=14, rsi_tf="5min", rsi_lvl=35, n_orders=60, step=0.001, qty=0.0001, mult=1.01, target=0.0025,
         min_stop=0.0005, max_stop=0.005, tp0=6.0, tp_inc=3.0)
LINES = []


def say(s=""):
    print(s, flush=True)
    LINES.append(s)


def rsi_gate(d):
    """True на минуте i, если последняя ЗАКРЫТАЯ 5m-свеча имеет RSI14 < уровня."""
    ix = pd.to_datetime(d.t, unit="ms")
    c5 = pd.Series(d.c.to_numpy(), index=ix).resample(P["rsi_tf"]).last().dropna()
    dl = c5.diff()
    up = dl.clip(lower=0).ewm(alpha=1 / P["rsi_len"], adjust=False).mean()
    dn = (-dl.clip(upper=0)).ewm(alpha=1 / P["rsi_len"], adjust=False).mean()
    r = 100 - 100 / (1 + up / dn.replace(0, 1e-12))
    key = ix.dt.floor(P["rsi_tf"]) - pd.Timedelta(P["rsi_tf"])
    return (r.reindex(key).to_numpy() < P["rsi_lvl"])


def run(d, fee, gate):
    t, o, h, l, c = (d[k].to_numpy() for k in ("t", "o", "h", "l", "c"))
    res = {"cycles": 0, "bot_tp": 0, "fees": 0.0, "max_orders": 0, "max_notional": 0.0, "worst_unreal": 0.0,
           "worst_t": None, "longest_h": 0.0}
    monthly, total, sess, tp = {}, 0.0, 0.0, P["tp0"]
    pos = None

    def book(x, ts):
        nonlocal total, sess
        total += x; sess += x
        m = pd.to_datetime(ts, unit="ms").strftime("%Y-%m")
        monthly[m] = monthly.get(m, 0.0) + x

    def fill(px, q, ts):
        res["fees"] += px * q * fee
        book(-px * q * fee, ts)

    def close(px, ts):
        nonlocal pos
        fill(px, pos["qty"], ts)
        book((px - pos["avg"]) * pos["qty"], ts)
        res["longest_h"] = max(res["longest_h"], (ts - pos["t0"]) / 3_600_000)
        pos = None

    for i in range(1, len(c)):
        if pos is None:
            if not gate[i]:
                continue
            q = P["qty"]
            fill(o[i], q, t[i])
            pos = {"qty": q, "avg": o[i], "last": o[i], "n": 1, "q": q, "stop": None, "t0": t[i]}
            res["cycles"] += 1
        while pos["n"] < P["n_orders"] and l[i] <= pos["last"] * (1 - P["step"]):
            px = pos["last"] * (1 - P["step"])
            q = pos["q"] * P["mult"]
            pos["avg"] = (pos["avg"] * pos["qty"] + px * q) / (pos["qty"] + q)
            pos["qty"] += q; pos["q"] = q; pos["last"] = px; pos["n"] += 1
            fill(px, q, t[i])
        res["max_orders"] = max(res["max_orders"], pos["n"])
        res["max_notional"] = max(res["max_notional"], pos["qty"] * c[i])
        un_w = (l[i] - pos["avg"]) * pos["qty"]
        if un_w < res["worst_unreal"]:
            res["worst_unreal"], res["worst_t"] = un_w, t[i]
        if P.get("sl") and sess + un_w - l[i] * pos["qty"] * fee <= P["sl"]:   # опц. стоп-лосс бота
            close(l[i], t[i])
            res["bot_sl"] = res.get("bot_sl", 0) + 1
            sess, tp = 0.0, P["tp0"]
            continue
        trig = pos["avg"] * (1 + P["target"])
        if pos["stop"] is None and h[i] >= trig:
            pos["stop"] = trig * (1 - P["min_stop"])
        if pos["stop"] is not None:
            pos["stop"] = max(pos["stop"], h[i] * (1 - P["max_stop"]))
            if c[i] <= pos["stop"] or l[i] <= pos["stop"]:
                close(pos["stop"], t[i])
        un = 0.0 if pos is None else (c[i] - pos["avg"]) * pos["qty"] - c[i] * pos["qty"] * fee
        if sess + un >= tp:
            if pos is not None:
                close(c[i], t[i])
            res["bot_tp"] += 1
            sess, tp = 0.0, tp + P["tp_inc"]
    open_un = 0.0
    if pos is not None:
        open_un = (c[-1] - pos["avg"]) * pos["qty"]
        res["open"] = f"открыта: {pos['n']} орд., средняя {pos['avg']:.0f}, PnL {open_un:+.2f} $"
    res["total"], res["monthly"], res["open_un"] = total, monthly, open_un
    return res


def main():
    days = int(sys.argv[1]) if len(sys.argv) > 1 else 120
    say(f"GinArea Indicator grid «Btc long» — приближённый бэктест · OKX BTC 1m · {days} дн. · {time.strftime('%Y-%m-%d %H:%M')}")
    say(f"Настройки: {P}")
    d = okx_1m(days)
    if len(d) < 10000:
        say("мало свечей — OKX не отдал историю"); return
    say(f"Свечей: {len(d)} · {pd.to_datetime(d.t.iloc[0], unit='ms'):%Y-%m-%d} → "
        f"{pd.to_datetime(d.t.iloc[-1], unit='ms'):%Y-%m-%d} · BTC {d.c.iloc[0]:.0f} → {d.c.iloc[-1]:.0f}")
    full = sum(P["qty"] * P["mult"] ** k for k in range(P["n_orders"]))
    say(f"Полная сетка: {full:.5f} BTC ≈ {full * d.c.iloc[-1]:.0f} $, покрывает падение ≈ "
        f"{(1 - (1 - P['step']) ** (P['n_orders'] - 1)) * 100:.1f}% от старта")
    gate = rsi_gate(d)
    for fee, fname in ((0.0005, "taker 0.05%"), (0.0002, "maker 0.02%")):
        r = run(d, fee, gate)
        say(""); say(f"=== комиссия {fname} ===")
        say(f"  итог закрытых {r['total']:+.2f} $ · открытая {r['open_un']:+.2f} $ · тейков бота {r['bot_tp']} · циклов {r['cycles']} · "
            f"комиссии {r['fees']:.2f} $")
        say(f"  макс. ордеров {r['max_orders']} (позиция до {r['max_notional']:.0f} $) · худшая просадка позиции "
            f"{r['worst_unreal']:.2f} $" + (f" ({pd.to_datetime(r['worst_t'], unit='ms'):%Y-%m-%d})" if r["worst_t"] else "")
            + f" · самый долгий цикл {r['longest_h']:.0f} ч")
        if r.get("open"):
            say("  " + r["open"])
        say("  по месяцам: " + "  ".join(f"{m} {v:+.2f}" for m, v in sorted(r["monthly"].items())))
    say("")
    say("Стопа у бота нет: при падении BTC больше ~6% сетка кончается и позиция висит в минусе до возврата цены.")
    say("Это приближение: сверяй с историей бота в GinArea.")
    OUT.parent.mkdir(exist_ok=True)
    OUT.write_text("\n".join(LINES), encoding="utf-8")
    print(f"\nОтчёт: {OUT}")


if __name__ == "__main__":
    main()
