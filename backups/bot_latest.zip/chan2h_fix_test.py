"""chan2h_fix_test.py — 2026-10-31. Можно ли починить «Пробой канала 2h»: проверка идей на ВСЕЙ истории и на 180/90/30 днях.
12 монет (кэш kvoo_longtest), логика recheck_recent.chan (стоп центр, тейк 2R, ≤100 свечей), комиссия 0.11%.
Идеи: лимит одновременных сделок в одну сторону (монеты ходят вместе) · волатильность растёт (ATR14>ATR100)
· лимит + волатильность · только по тренду BTC (EMA200) · пропуск сигнала, если за 24 ч уже был стоп в ту же сторону."""
from __future__ import annotations

import sys
import time
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import recheck_recent as RR  # noqa: E402

FEE = 0.0011


def trades_for(d):
    """Все сделки монеты как (t_in, t_out, side, R, atr_ok)."""
    h, l, c, t = d.h.values, d.l.values, d.c.values, d.t.values
    mid, sd = RR.rolling_reg(c); up, lo = mid + 2 * sd, mid - 2 * sd
    pc = np.r_[c[0], c[:-1]]
    tr = pd.Series(np.maximum(h - l, np.maximum(abs(h - pc), abs(l - pc))))
    a14 = tr.ewm(alpha=1 / 14, adjust=False).mean().values; a100 = tr.rolling(100).mean().values
    out = []; nxt = 0
    for i in range(101, len(c) - 1):
        s = 1 if (c[i] > up[i] and c[i - 1] <= up[i - 1]) else -1 if (c[i] < lo[i] and c[i - 1] >= lo[i - 1]) else 0
        if not s or i < nxt:
            continue
        e = c[i]; stp = mid[i]; risk = abs(e - stp)
        if risk <= 0:
            continue
        tp = e + s * 2 * risk; res = None
        for j in range(i + 1, min(len(c), i + 101)):
            if (l[j] <= stp) if s > 0 else (h[j] >= stp):
                res = (j, -1.0); break
            if (h[j] >= tp) if s > 0 else (l[j] <= tp):
                res = (j, 2.0); break
        if res is None:
            j = min(len(c) - 1, i + 100); res = (j, s * (c[j] - e) / risk)
        out.append((int(t[i]), int(t[res[0]]), s, res[1] - FEE * e / risk, bool(a14[i] > a100[i])))
        nxt = res[0] + 1
    return out


def run(all_tr, btc_tr, cap=None, vol=False, btc=False, cool=0):
    """По времени ВХОДА; о стопе знаем, только если он уже закрылся к моменту входа (без заглядывания вперёд)."""
    ev = sorted(all_tr, key=lambda x: x[0])
    taken = []; book = []          # book: (t_in, t_out, side, R) принятых сделок
    for tin, tout, s, r, vok, sym in ev:
        if vol and not vok:
            continue
        if btc and btc_tr(tin) != s:
            continue
        if cool:
            ls = max((b[1] for b in book if b[2] == s and b[3] < 0 and b[1] <= tin), default=-10**15)
            if tin - ls < cool * 3600_000:
                continue
        if cap and sum(1 for b in book if b[2] == s and b[0] <= tin < b[1]) >= cap:
            continue
        book.append((tin, tout, s, r)); taken.append((tout, r))
    return taken


def main():
    import kvoo_longtest as K  # noqa: PLC0415
    now = int(time.time() * 1000); allt = []
    for s in K.COINS:
        d = RR.load(s, "2h")
        if d is None or len(d) < 400:
            continue
        allt += [(a, b, c, r, v, s) for a, b, c, r, v in trades_for(d)]
    allt.sort(key=lambda x: x[0])
    b = RR.load("BTCUSDT", "2h"); e = b.c.ewm(span=200, adjust=False).mean()
    bs = pd.Series(np.sign(b.c.values - e.values), index=b.t.values)
    btc_tr = lambda ts: int(bs.asof(ts) or 0)  # noqa: E731
    t0 = min(x[0] for x in allt); mid = (t0 + now) // 2
    lines = ["Пробой канала 2h · 12 монет · R (вся · 1-я пол · 2-я пол · 180д · 90д · 30д · сделок)"]
    VARS = [("как сейчас", {}), ("≤1 сделка в одну сторону", {"cap": 1}), ("≤2 в одну сторону", {"cap": 2}), ("≤3 в одну сторону", {"cap": 3}),
            ("волатильность растёт", {"vol": True}), ("≤2 + волатильность", {"cap": 2, "vol": True}), ("по тренду BTC", {"btc": True}),
            ("пауза 24 ч после стопа в ту же сторону", {"cool": 24}), ("≤2 + пауза 24 ч", {"cap": 2, "cool": 24}),
            ("пауза 6 ч", {"cool": 6}), ("пауза 12 ч", {"cool": 12}), ("пауза 36 ч", {"cool": 36}), ("пауза 48 ч", {"cool": 48}),
            ("пауза 72 ч", {"cool": 72}), ("пауза 24 ч + волатильность", {"cool": 24, "vol": True})]
    for name, kw in VARS:
        tk = run(allt, btc_tr, **kw)
        w = lambda days: sum(r for t, r in tk if t >= now - days * 86400_000)  # noqa: E731
        h1 = sum(r for t, r in tk if t < mid); h2 = sum(r for t, r in tk if t >= mid)
        lines.append(f"{name:<40} {w(99999):+7.1f} · {h1:+7.1f} · {h2:+7.1f} · {w(180):+6.1f} · {w(90):+6.1f} · {w(30):+6.1f} · {len(tk)}")
        print(lines[-1], flush=True)
    (BASE / "bt_lab_bots" / "chan2h_fix_test.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("готово")


if __name__ == "__main__":
    main()
