"""pine_triage.py — 2026-11-02. Короткая сводка по каждому скрипту tg_candidates (для ручного переноса лучших):
строк, сигналы (заголовки plotshape/alertcondition/strategy.entry), признаки перерисовки (lookahead_on, request.security,
barstate.isrealtime, calc_on_every_tick, offset=-, zigzag/pivot c offset), библиотеки (import). Пишет bt_lab_bots/pine_triage.tsv"""
import re
from pathlib import Path
BASE = Path(__file__).resolve().parent
rows = ["file\tlines\tkind\tsignals\tflags\tlibs"]
for f in sorted((BASE / "tg_candidates").rglob("*.txt")):
    s = f.read_text(encoding="utf-8", errors="replace")
    kind = "strategy" if re.search(r"^\s*strategy\s*\(", s, re.M) else "indicator"
    sig = re.findall(r"(?:plotshape|alertcondition|plotchar)\s*\([^\n]*?title\s*=\s*['\"]([^'\"]{1,30})", s)
    sig += re.findall(r"strategy\.entry\s*\(\s*['\"]([^'\"]{1,20})", s)
    fl = []
    for k, rx in (("lookahead_on", r"lookahead\s*=\s*barmerge\.lookahead_on"), ("security", r"request\.security"), ("realtime", r"barstate\.isrealtime|calc_on_every_tick"),
                  ("neg_offset", r"offset\s*=\s*-"), ("pivot", r"ta\.pivot(high|low)"), ("zigzag", r"(?i)zigzag"), ("array", r"array\.|matrix\."),
                  ("ml", r"(?i)lorentz|knn|kernel"), ("trail", r"trail_"), ("fixed_date", r"timestamp\s*\(")):
        if re.search(rx, s):
            fl.append(k)
    libs = ",".join(re.findall(r"^\s*import\s+(\S+)", s, re.M))[:60]
    rows.append(f"{f.parent.name}/{f.name}\t{s.count(chr(10))}\t{kind}\t{'|'.join(dict.fromkeys(sig))[:120]}\t{','.join(fl)}\t{libs}")
(BASE / "bt_lab_bots" / "pine_triage.tsv").write_text("\n".join(rows), encoding="utf-8")
print("готово", len(rows) - 1)
