"""ginarea_tune.py — 2026-10-18. Честный подбор настроек двух ботов GinArea (OKX BTC 1m, 300 дн., комиссия taker 0.05%).

Метод: история делится пополам. Варианты ранжируются по 1-й половине, а годным считается только тот,
что в плюсе И в 1-й, И во 2-й половине (2-я — «будущее», которого при подборе не видно).
1) Dynamic (авто, обе стороны): шаг=цель 390/600/900/1300 $, ордеров 20/40, стоп бота −41/−80 $, трейл = 11% цели.
2) Indicator «Btc long»: как сейчас / + стоп бота −20/−40 $ / + старт только при BTC выше EMA200 4h / оба.
Ничего не торгует. Запуск: ginarea_tune.bat → bt_lab_bots/ginarea_tune.txt
"""
from __future__ import annotations
import sys, time
from pathlib import Path
import numpy as np
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import ginarea_dyn_test as D  # noqa: E402
import ginarea_ind_test as I  # noqa: E402
OUT = BASE / "bt_lab_bots" / "ginarea_tune.txt"
FEE = 0.0005
LINES = []
def say(s=""):
    print(s, flush=True); LINES.append(s)
def halves(d):
    m = len(d) // 2
    return d.iloc[:m].reset_index(drop=True), d.iloc[m:].reset_index(drop=True)

def main():
    days = int(sys.argv[1]) if len(sys.argv) > 1 else 300
    say(f"Подбор настроек GinArea · OKX BTC 1m · {days} дн. · taker 0.05% · {time.strftime('%Y-%m-%d %H:%M')}")
    d = D.okx_1m(days)
    a, b = halves(d)
    say(f"1-я половина: BTC {a.c.iloc[0]:.0f} → {a.c.iloc[-1]:.0f} · 2-я: {b.c.iloc[0]:.0f} → {b.c.iloc[-1]:.0f}")
    base_d = dict(D.P)
    # ---- Dynamic
    say(""); say("=== Dynamic авто: шаг=цель · ордеров · стоп → 1-я пол. / 2-я пол. / весь период (стопов) ===")
    rows = []
    for step in (390.4, 600, 900, 1300):
        for n in (20, 40):
            for sl in (-41.33, -80):
                D.P.update(base_d, step=step, target=step, trail=round(step * 0.111, 1), n_orders=n, sl=sl)
                r1, r2, rf = (D.run(x, "auto", FEE) for x in (a, b, d))
                ok = r1["total"] > 0 and r2["total"] > 0
                rows.append((r1["total"], step, n, sl, r2["total"], rf["total"], rf["bot_sl"], ok))
                print(f"  {step} {n} {sl}: {r1['total']:+.0f} / {r2['total']:+.0f}", flush=True)
    D.P.update(base_d)
    for r1, step, n, sl, r2, rf, ns, ok in sorted(rows, reverse=True):
        mark = "  ← сейчас" if (step, n, sl) == (390.4, 40, -41.33) else ""
        say(f"  шаг {step:>6} · {n} орд. · стоп {sl:>6} → {r1:+8.1f} / {r2:+8.1f} / {rf:+8.1f} $ ({ns} стоп.) {'✅' if ok else '❌'}{mark}")
    # ---- Indicator
    say(""); say("=== Indicator «Btc long»: защита → 1-я / 2-я / весь (стопов, худшая просадка, открыто в конце) ===")
    base_i = dict(I.P)
    trend = {}
    for name, x in (("a", a), ("b", b), ("d", d)):
        trend[name] = D.regimes(x)["EMA200 4h"] > 0
    for label, sl, use_tr in (("как сейчас", None, False), ("стоп −20 $", -20, False), ("стоп −40 $", -40, False),
                              ("только выше EMA200 4h", None, True), ("EMA200 4h + стоп −20 $", -20, True),
                              ("EMA200 4h + стоп −40 $", -40, True)):
        I.P.update(base_i, sl=sl)
        out = []
        for name, x in (("a", a), ("b", b), ("d", d)):
            g = I.rsi_gate(x)
            if use_tr:
                g = g & trend[name]
            r = I.run(x, FEE, g)
            out.append(r)
        tot = [r["total"] + r["open_un"] for r in out]
        ok = tot[0] > 0 and tot[1] > 0
        say(f"  {label:<24} {tot[0]:+7.1f} / {tot[1]:+7.1f} / {tot[2]:+7.1f} $ · стопов {out[2].get('bot_sl', 0)} · "
            f"худшая {out[2]['worst_unreal']:.0f} $ · открыто {out[2]['open_un']:+.0f} $ {'✅' if ok else '❌'}")
    I.P.update(base_i)
    say("")
    say("✅ = в плюсе в обеих половинах. Итог индикаторного включает открытую позицию на конец периода.")
    say("Брать только ✅, и лучше тот, у которого соседние настройки тоже ✅ (не одиночная удача).")
    OUT.parent.mkdir(exist_ok=True); OUT.write_text("\n".join(LINES), encoding="utf-8"); print(f"\nОтчёт: {OUT}")

if __name__ == "__main__":
    main()
