"""strategy_gen.py — 2026-10-04. Честный генератор стратегий (как SrgArt, но без самообмана).

Поиск идёт по небольшому семейству понятных правил: триггер × фильтр × выход.
1. ПОДБОР — только на первых 60% истории выбранной монеты.
2. ПРОВЕРКА ВПЕРЁД — лучшие варианты прогоняются на последних 40%, которых подбор не видел.
3. ДРУГИЕ МОНЕТЫ — тот же вариант на 6 ликвидных монетах за тот же проверочный период.
Вердикт ставится по проверке, а не по подбору. В библиотеку сохраняются только прошедшие.
Риск в карточке считается на 1% депозита на сделку (без плеча ×40), серия стопов показывается отдельно.
"""
from __future__ import annotations

import json
import threading
import time
import uuid
from pathlib import Path

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parent
LIB = BASE / "strategy_library.json"
COST = 0.0011                      # комиссия+проскальзывание на сделку (taker туда-обратно)
OTHER = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT", "DOGEUSDT", "LINKUSDT", "ADAUSDT", "TAOUSDT", "HYPEUSDT", "AVAXUSDT",
         "SUIUSDT", "BNBUSDT", "LTCUSDT", "DOTUSDT", "NEARUSDT", "ARBUSDT", "OPUSDT", "APTUSDT", "INJUSDT", "TIAUSDT",
         "SEIUSDT", "ENAUSDT", "WIFUSDT", "1000PEPEUSDT", "UNIUSDT", "FILUSDT", "XLMUSDT", "TRXUSDT", "ONDOUSDT", "WLDUSDT"]
TF_MIN = {"15m": 15, "1h": 60, "2h": 120, "4h": 240}
JOBS: dict = {}
OUT = BASE / "bt_lab_out"


class _FileJob(dict):
    """Состояние задачи пишется в файл: генерация идёт отдельным процессом venv-питона."""
    def __init__(self, job):
        super().__init__(); self.f = OUT / f"gen_{job}.json"

    def update(self, *a, **k):
        super().update(*a, **k)
        OUT.mkdir(exist_ok=True)
        tmp = self.f.with_suffix(".tmp"); tmp.write_text(json.dumps(dict(self), ensure_ascii=False), encoding="utf-8"); tmp.replace(self.f)



# ---------------- данные ----------------
def _load(sym: str, tf: str, years: float = 4.0) -> pd.DataFrame | None:
    import candle_store as CS  # noqa: PLC0415
    d = CS.load(sym)
    if d is None or len(d) < 1000:
        return None
    d = d[d.t >= d.t.iloc[-1] - int(years * 365 * 86400_000)]
    ms = TF_MIN[tf] * 60_000
    g = d.assign(b=d.t // ms * ms).groupby("b")
    return pd.DataFrame({"t": g.t.first(), "o": g.open.first(), "h": g.high.max(), "l": g.low.min(),
                         "c": g.close.last(), "v": g.volume.sum()}).reset_index(drop=True)


# ---------------- индикаторы и правила ----------------
def _feats(d: pd.DataFrame) -> dict:
    h, l, c, v = d.h, d.l, d.c, d.v
    pc = c.shift()
    tr = pd.concat([h - l, (h - pc).abs(), (l - pc).abs()], axis=1).max(axis=1)
    atr = tr.ewm(alpha=1 / 14, adjust=False).mean()
    dc = c.diff()
    up = dc.clip(lower=0).ewm(alpha=1 / 14, adjust=False).mean(); dn = (-dc).clip(lower=0).ewm(alpha=1 / 14, adjust=False).mean()
    rsi = 100 - 100 / (1 + up / dn.replace(0, 1e-12))
    tp = (h + l + c) / 3
    esa = tp.ewm(span=10, adjust=False).mean(); dd = (tp - esa).abs().ewm(span=10, adjust=False).mean()
    wt1 = ((tp - esa) / (0.015 * dd.replace(0, 1e-12))).ewm(span=21, adjust=False).mean(); wt2 = wt1.rolling(4).mean()
    return {"h": h.values, "l": l.values, "c": c.values, "atr": atr.values, "rsi": rsi, "wt1": wt1, "wt2": wt2,
            "ema200": c.ewm(span=200, adjust=False).mean().values, "volr": (v / v.rolling(50).mean()).values, "s": d}


TRIGGERS = {
    # имя: (описание, функция(F, side, p) -> bool array, список параметров, pine-шаблон)
    "breakout": ("пробой {p}-свечного {ext}", lambda F, sd, p: (
        (F["s"].c > F["s"].h.rolling(p).max().shift(1)) if sd > 0 else (F["s"].c < F["s"].l.rolling(p).min().shift(1))).values,
        [10, 20, 40, 55, 70, 100],
        "close > ta.highest(high, {p})[1]", "close < ta.lowest(low, {p})[1]"),
    "pullback": ("откат к EMA{p} по тренду EMA200", lambda F, sd, p: (
        ((F["s"].l <= F["s"].c.ewm(span=p, adjust=False).mean()) & (F["s"].c > F["s"].c.ewm(span=p, adjust=False).mean()) & (F["s"].c > F["ema200"]))
        if sd > 0 else ((F["s"].h >= F["s"].c.ewm(span=p, adjust=False).mean()) & (F["s"].c < F["s"].c.ewm(span=p, adjust=False).mean()) & (F["s"].c < F["ema200"]))).values,
        [20, 50],
        "low <= ta.ema(close, {p}) and close > ta.ema(close, {p}) and close > ta.ema(close, 200)",
        "high >= ta.ema(close, {p}) and close < ta.ema(close, {p}) and close < ta.ema(close, 200)"),
    "rsi": ("RSI выходит из зоны {p}", lambda F, sd, p: (
        ((F["rsi"] > p) & (F["rsi"].shift(1) <= p)) if sd > 0 else ((F["rsi"] < 100 - p) & (F["rsi"].shift(1) >= 100 - p))).values,
        [25, 30, 35],
        "ta.crossover(ta.rsi(close, 14), {p})", "ta.crossunder(ta.rsi(close, 14), 100 - {p})"),
    "wavetrend": ("разворот WaveTrend из зоны ±{p}", lambda F, sd, p: (
        ((F["wt1"] > F["wt2"]) & (F["wt1"].shift(1) <= F["wt2"].shift(1)) & (F["wt2"] < -p)) if sd > 0
        else ((F["wt1"] < F["wt2"]) & (F["wt1"].shift(1) >= F["wt2"].shift(1)) & (F["wt2"] > p))).values,
        [40, 60],
        "ta.crossover(wt1, wt2) and wt2 < -{p}", "ta.crossunder(wt1, wt2) and wt2 > {p}"),
}
def _ha_cross(F, sd, k):
    """Хейкен-Аши на ТФ ×k (честно — по закрытой старшей свече), пересечение HA close / HA open."""
    d = F["s"]; ms = int(d.t.diff().median()); H = ms * k
    g = d.assign(b=d.t // H * H).groupby("b")
    hb = pd.DataFrame({"o": g.o.first(), "h": g.h.max(), "l": g.l.min(), "c": g.c.last()})
    hc = ((hb.o + hb.h + hb.l + hb.c) / 4).values; ho = np.empty(len(hb)); ho[0] = (hb.o.iloc[0] + hb.c.iloc[0]) / 2
    for i in range(1, len(hb)):
        ho[i] = (ho[i - 1] + hc[i - 1]) / 2
    bucket = (d.t // H * H).values; pos = np.searchsorted(hb.index.values, bucket)
    cl = np.where(d.t.values + ms >= bucket + H, pos, pos - 1); ok = cl >= 0; cl = np.clip(cl, 0, None)
    o = np.where(ok, ho[cl], np.nan); c = np.where(ok, hc[cl], np.nan)
    return ((c > o) & np.r_[False, (c <= o)[:-1]]) if sd > 0 else ((c < o) & np.r_[False, (c >= o)[:-1]])


def _supertrend(F, sd, f):
    d = F["s"]; atr = pd.Series(F["atr"]).values; hl = ((d.h + d.l) / 2).values; cc = d.c.values
    up = hl - f * atr; dn = hl + f * atr; dr = np.ones(len(cc))
    for i in range(1, len(cc)):
        if not np.isnan(up[i - 1]):
            up[i] = max(up[i], up[i - 1]) if cc[i - 1] > up[i - 1] else up[i]
            dn[i] = min(dn[i], dn[i - 1]) if cc[i - 1] < dn[i - 1] else dn[i]
        dr[i] = 1 if (dr[i - 1] == -1 and cc[i] > dn[i - 1]) else (-1 if (dr[i - 1] == 1 and cc[i] < up[i - 1]) else dr[i - 1])
    return ((dr == 1) & np.r_[False, dr[:-1] == -1]) if sd > 0 else ((dr == -1) & np.r_[False, dr[:-1] == 1])


TRIGGERS.update({
    # 2026-10-28: семейства, которые у нас уже прошли проверку вживую — генератор ищет настройки рядом с ними
    "channel": ("пробой канала {p} свечей", lambda F, sd, p: (
        (F["s"].c > F["s"].h.rolling(p).max().shift(1)) if sd > 0 else (F["s"].c < F["s"].l.rolling(p).min().shift(1))).values,
        [100, 150], "close > ta.highest(high, {p})[1]", "close < ta.lowest(low, {p})[1]"),
    "ha": ("Хейкен-Аши старшего ТФ ×{p}", lambda F, sd, p: _ha_cross(F, sd, p), [6, 12, 18],
           "// HA старшего ТФ ×{p}: request.security(ticker.heikinashi(syminfo.tickerid), tf×{p}, close) пересекает open (по закрытой свече)",
           "// HA старшего ТФ ×{p}: пересечение вниз"),
    "supertrend": ("разворот Supertrend ×{p}", lambda F, sd, p: _supertrend(F, sd, p), [2, 3, 4],
                   "ta.change(ta.supertrend({p}, 10)[1]) < 0", "ta.change(ta.supertrend({p}, 10)[1]) > 0"),
})
FILTERS = {"нет": None, "по тренду EMA200": "trend", "объём ×1.5": "vol"}
EXITS = [(sl, rr) for sl in (1.0, 1.5, 2.5) for rr in (1.0, 2.0, 3.0, 0.0)]   # rr=0 — трейлинг-стоп sl·ATR без тейка
# 2026-10-31: выход «Черепах» — закрытие за обратный пробой M свечей (rr = −M), стоп sl·ATR, без тейка.
# Это единственное семейство, прошедшее strat_batch6 на 36/36 соседних настройках — без него генератор почти ничего не находил.
EXITS += [(sl, -m) for sl in (1.5, 2.0, 3.0) for m in (15, 20, 30)]
HOLD = {"15m": 192, "1h": 96, "2h": 72, "4h": 60}


def _entries(F, trig, side, p, flt):
    if trig == "pine":   # 2026-10-28: стратегия, импортированная из TradingView (pine_lab.py); p — JSON программы
        import pine_lab  # noqa: PLC0415
        sig = pine_lab.signal(F["s"], p, side).copy()
    else:
        sig = np.nan_to_num(TRIGGERS[trig][1](F, side, p).astype(float)).astype(bool)
    if flt == "trend":
        sig &= (F["c"] > F["ema200"]) if side > 0 else (F["c"] < F["ema200"])
    elif flt == "vol":
        sig &= np.nan_to_num(F["volr"]) > 1.5
    sig[:210] = False
    return np.where(sig)[0]


def _chex(F, m):
    """Минимум/максимум M прошлых свечей (без текущей) — для выхода «Черепах»."""
    k = f"chex{m}"
    if k not in F:
        F[k] = (F["s"].l.rolling(m).min().shift(1).values, F["s"].h.rolling(m).max().shift(1).values)
    return F[k]


def _sim(F, idx, side, sl_k, rr, hold, lo=0, hi=None, cost=None, delay=0):
    """Сделки без перекрытия: вход по закрытию сигнальной свечи, стоп sl_k·ATR, тейк rr·стоп. rr=0 — трейлинг-стоп по закрытиям. Возврат в R."""
    h, l, c, atr = F["h"], F["l"], F["c"], F["atr"]
    n = len(c) if hi is None else hi
    out = []; nxt = lo
    if rr == 0:
        hold = hold * 3                                   # трейлинг держит тренд дольше
    if rr < 0:
        hold = hold * 5; llm, hhm = _chex(F, int(-rr))    # «Черепахи»: тренд держим до обратного пробоя
    for i in idx:
        if i < nxt or i < lo or i >= n - 1:
            continue
        e = c[i] if not delay else F["s"].o.values[min(n - 1, i + 1)]; risk = sl_k * atr[i]
        if not risk > 0:
            continue
        s = e - side * risk; t = e + side * rr * risk; res = None
        for j in range(i + 1, min(n, i + hold)):
            if (l[j] <= s) if side > 0 else (h[j] >= s):
                res = (j, side * (s - e) / risk); break
            if rr > 0 and ((h[j] >= t) if side > 0 else (l[j] <= t)):
                res = (j, rr); break
            if rr < 0 and ((c[j] < llm[j]) if side > 0 else (c[j] > hhm[j])):
                res = (j, side * (c[j] - e) / risk); break
            if rr == 0 and atr[j] > 0:
                s = max(s, c[j] - sl_k * atr[j]) if side > 0 else min(s, c[j] + sl_k * atr[j])
        if res is None:
            j = min(n - 1, i + hold); res = (j, side * (c[j] - e) / risk)
        out.append((i, res[0], res[1] - (COST if cost is None else cost) * e / risk))
        nxt = res[0] + 1
    return out


def _neighbors(F, c, side, hold, cut, n):
    """2026-11-01: проверка «соседних настроек» (как у Черепах 36/36): меняем по одному параметру на соседнее
    значение и смотрим, в плюсе ли проверка вперёд. Если правило работает только на одной точной настройке — это подгонка."""
    plist = TRIGGERS[c["trig"]][2] if c["trig"] in TRIGGERS else [c["p"]]
    var = []
    if c["p"] in plist:
        k = plist.index(c["p"])
        var += [(plist[j], c["sl"], c["rr"]) for j in (k - 1, k + 1) if 0 <= j < len(plist)]
    sls = sorted({x for x, _ in EXITS}); ks = sls.index(c["sl"]) if c["sl"] in sls else -1
    if ks >= 0:
        var += [(c["p"], sls[j], c["rr"]) for j in (ks - 1, ks + 1) if 0 <= j < len(sls)]
    grp = sorted({rr for _, rr in EXITS if (rr < 0) == (c["rr"] < 0) and (rr == 0) == (c["rr"] == 0)})
    if c["rr"] in grp and len(grp) > 1:
        kr = grp.index(c["rr"])
        var += [(c["p"], c["sl"], grp[j]) for j in (kr - 1, kr + 1) if 0 <= j < len(grp)]
    pos = 0; tot = 0
    for p, sl, rr in var:
        try:
            idx = _entries(F, c["trig"], side, p, FILTERS[c["flt"]])
            r = sum(x[2] for x in _sim(F, idx, side, sl, rr, hold, cut, n))
        except Exception:  # noqa: BLE001
            continue
        tot += 1; pos += r > 0
    return pos, tot


def _score(tr):
    if len(tr) < 15:
        return None
    r = np.array([x[2] for x in tr]); g, b = r[r > 0].sum(), -r[r < 0].sum()
    run = mx = 0
    for x in r:
        run = run + 1 if x < 0 else 0; mx = max(mx, run)
    eq = np.cumsum(r); dd = (eq - np.maximum.accumulate(np.r_[0, eq])[1:]).min()
    return {"n": len(r), "wr": round(float((r > 0).mean() * 100), 1), "pf": round(float(g / b), 2) if b > 0 else 9.99,
            "r": round(float(r.sum()), 1), "avg": round(float(r.mean()), 3), "streak": int(mx), "dd_r": round(float(dd), 1)}


# ---------------- 2026-11-07: строгая проверка (советы ChatGPT / Grok / DeepSeek) ----------------
EXP_LOG = OUT / "experiments.jsonl"


def _rand_baseline(F, side, flt, sl_k, rr, hold, lo, hi, n_tr, sims=200, seed=1):
    """Случайные входы с той же частотой, тем же фильтром, стопом и выходом. Возврат: 95-й перцентиль суммы R.
    Тест BOS 4h показал: со «следованием за трендом» случайные входы дают +1.6R/сд, старый фильтр пропускал 86 из 100."""
    rg = np.random.default_rng(seed)
    ok = np.ones(len(F["c"]), bool)
    if flt == "trend":
        ok &= (F["c"] > F["ema200"]) if side > 0 else (F["c"] < F["ema200"])
    elif flt == "vol":
        ok &= np.nan_to_num(F["volr"]) > 1.5
    pool = np.where(ok[lo:hi])[0] + lo
    pool = pool[pool >= 210]
    if len(pool) < 10 or n_tr < 5:
        return 0.0
    k = min(len(pool), int(n_tr * 1.6))          # с запасом: часть входов отсекается перекрытием сделок
    res = [sum(x[2] for x in _sim(F, np.sort(rg.choice(pool, k, replace=False)), side, sl_k, rr, hold, lo, hi)) for _ in range(sims)]
    return float(np.percentile(res, 95))


def _wfa(tr, lo, hi, parts=6):
    """Скользящая проверка вперёд по окнам: результат сделок по 6 равным отрезкам истории (правила не подстраиваются)."""
    edges = np.linspace(lo, hi, parts + 1)
    return [round(float(sum(x[2] for x in tr if edges[k] <= x[0] < edges[k + 1])), 1) for k in range(parts)]


def _mc(tr, sims=500, seed=2):
    """Бутстрап сделок: доля сценариев со средним R > 0 и 95% просадки (R)."""
    r = np.array([x[2] for x in tr])
    if len(r) < 10:
        return 0.0, 0.0
    rg = np.random.default_rng(seed); pos = 0; dds = []
    for _ in range(sims):
        x = rg.choice(r, len(r), replace=True); pos += x.mean() > 0
        eq = np.cumsum(x); dds.append((eq - np.maximum.accumulate(eq)).min())
    return pos / sims, float(np.percentile(dds, 5))


def _log_exp(rec: dict) -> None:
    try:
        OUT.mkdir(exist_ok=True)
        with EXP_LOG.open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    except Exception:  # noqa: BLE001
        pass


# ---------------- порог случайности ----------------
def _noise_frame(d: pd.DataFrame, seed: int) -> pd.DataFrame:
    """Та же монета, но приращения цены перемешаны: волатильность та же, закономерностей нет."""
    rg = np.random.default_rng(seed)
    lr = np.diff(np.log(d.c.values)); rg.shuffle(lr)
    c = d.c.values[0] * np.exp(np.r_[0, np.cumsum(lr)])
    k = c / d.c.values
    return pd.DataFrame({"t": d.t.values, "o": d.o.values * k, "h": d.h.values * k, "l": d.l.values * k, "c": c, "v": d.v.values})


def _best_forward(d: pd.DataFrame, tf: str, side: int, combos) -> float:
    """Лучший результат «вперёд», который тот же перебор находит на СЛУЧАЙНЫХ данных."""
    F = _feats(d); n = len(d); cut = int(n * 0.6); hold = HOLD[tf]; cands = []
    for tg, p, fl in combos:
        try:
            idx = _entries(F, tg, side, p, FILTERS[fl])
        except Exception:  # noqa: BLE001
            continue
        for sl_k, rr in EXITS:
            sc = _score(_sim(F, idx, side, sl_k, rr, hold, 0, cut))
            if sc and sc["n"] >= 30:
                cands.append((sc["r"], tg, p, fl, sl_k, rr))
    cands.sort(key=lambda x: -x[0]); best = 0.0
    for _r, tg, p, fl, sl_k, rr in cands[:16]:
        idx = _entries(F, tg, side, p, FILTERS[fl])
        vt = _sim(F, idx, side, sl_k, rr, hold, cut, n); sc = _score(vt)
        if not sc or sc["n"] < 20 or sc["pf"] < 1.2:
            continue
        midv = cut + (n - cut) // 2
        if sum(x[2] for x in vt if x[0] < midv) > 0 and sum(x[2] for x in vt if x[0] >= midv) > 0:
            best = max(best, sc["r"])
    return best


# ---------------- генерация ----------------
def generate(job: str, symbol: str, tf: str, side: int) -> None:
    J = JOBS.get(job) or _FileJob(job)
    try:
        J.update(pct=2, text=f"{symbol}: свечи…")
        d = _load(symbol, tf)
        if d is None or len(d) < 2000:
            raise RuntimeError("мало истории на складе — скачай свечи (download_all_candles.bat)")
        F = _feats(d); n = len(d); cut = int(n * 0.6); hold = HOLD[tf]
        cands = []
        combos = [(tg, p, fl) for tg, spec in TRIGGERS.items() for p in spec[2] for fl in FILTERS]
        for k, (tg, p, fl) in enumerate(combos):
            J.update(pct=5 + 60 * k / len(combos), text=f"подбор на первых 60%: {k + 1}/{len(combos)} правил")
            idx = _entries(F, tg, side, p, FILTERS[fl])
            for sl_k, rr in EXITS:
                tr = _sim(F, idx, side, sl_k, rr, hold, 0, cut)
                sc = _score(tr)
                if sc and sc["n"] >= 30:
                    cands.append({"trig": tg, "p": p, "flt": fl, "sl": sl_k, "rr": rr, "train": sc})
        cands.sort(key=lambda x: -x["train"]["r"])
        # порог случайности: тот же перебор на 5 перемешанных копиях монеты — что «находится» без всякой закономерности
        noise = []
        for k in range(8):
            J.update(pct=58 + k, text=f"порог случайности: перебор на перемешанных данных {k + 1}/8")
            noise.append(_best_forward(_noise_frame(d, 1000 + k), tf, side, combos))
        luck = max(noise)
        top = cands[:16]
        others = {}
        for k, c in enumerate(top):
            J.update(pct=65 + 30 * k / max(1, len(top)), text=f"проверка вперёд и другие монеты: {k + 1}/{len(top)}")
            idx = _entries(F, c["trig"], side, c["p"], FILTERS[c["flt"]])
            vt = _sim(F, idx, side, c["sl"], c["rr"], hold, cut, n)
            c["valid"] = _score(vt) or {"n": len(vt), "wr": 0, "pf": 0, "r": round(sum(x[2] for x in vt), 1), "avg": 0, "streak": 0, "dd_r": 0}
            full = _sim(F, idx, side, c["sl"], c["rr"], hold, 0, n)
            c["curve"] = [[int(d.t.iloc[x[1]]), round(float(v), 2)] for x, v in zip(full, np.cumsum([x[2] for x in full]))]
            c["cut_t"] = int(d.t.iloc[cut])
            c["trades"] = [{"t": int(d.t.iloc[x[0]]), "dur": int((d.t.iloc[x[1]] - d.t.iloc[x[0]]) / 60000), "r": round(float(x[2]), 2)} for x in full[-60:]][::-1]
            res = []
            for sym in OTHER[:12]:                      # справка: те же правила на 12 ликвидных монетах
                if sym == symbol:
                    continue
                if (sym, tf) not in others:
                    try:
                        od = _load(sym, tf)
                    except Exception:  # noqa: BLE001
                        od = None
                    others[(sym, tf)] = (_feats(od), int(len(od) * 0.6)) if od is not None and len(od) > 2000 else None
                o = others[(sym, tf)]
                if not o:
                    continue
                oi = _entries(o[0], c["trig"], side, c["p"], FILTERS[c["flt"]])
                sc = _score(_sim(o[0], oi, side, c["sl"], c["rr"], hold, o[1], len(o[0]["c"])))
                if sc:
                    res.append({"sym": sym.replace("USDT", ""), **sc})
            c["coins"] = res
            pos = sum(1 for x in res if x["r"] > 0)
            v = c["valid"]
            # 2026-10-28: вердикт — по ВЫБРАННОЙ монете (бот торгует только её). Другие монеты — справка.
            # Защита от подгонки на одной монете: проверка вперёд в плюсе в ОБЕИХ своих половинах, PF ≥ 1.2, ≥ 20 сделок.
            midv = cut + (n - cut) // 2
            h1 = sum(x[2] for x in vt if x[0] < midv); h2 = sum(x[2] for x in vt if x[0] >= midv)
            c["fwd_halves"] = [round(float(h1), 1), round(float(h2), 1)]
            c["luck_r"] = round(float(luck), 1)
            ok = v["n"] >= (20 if tf == "4h" else 30) and v["pf"] >= 1.25 and v["r"] > luck * 1.25 and h1 > 0 and h2 > 0 and c["train"]["r"] > 0
            # 2026-10-31: второй путь — то же правило подтверждено на других монетах вперёд (≥ 90% в плюсе, ≥ 8 монет, ≥ 0.25R/сделку в среднем).
            # На случайных данных другие монеты в плюсе ~50%, поэтому так подгонка не проходит; а порог случайности
            # для одной монеты на 4h (мало сделок) почти недостижим — реальные трендовые правила отсеивались.
            cross = (v["n"] >= 20 and v["pf"] >= 1.3 and h1 > 0 and h2 > 0 and c["train"]["r"] > 0
                     and len(res) >= 8 and pos >= 0.9 * len(res)
                     and sum(x["r"] for x in res) / max(1, sum(x["n"] for x in res)) >= 0.25)   # в среднем ≥ 0.25R на сделку по всем монетам
            # 2026-10-31: проверка на шумовых данных показала ложные «прошла» (правило работало на одной монете случайно) —
            # теперь и первый путь требует, чтобы правило не проигрывало на большинстве других монет (≥ 60% в плюсе)
            ok = ok and len(res) >= 6 and pos >= 0.6 * len(res)
            npos, ntot = _neighbors(F, c, side, hold, cut, n)
            c["neighbors"] = f"{npos}/{ntot}"
            robust = ntot == 0 or npos >= 0.6 * ntot
            if not robust:
                ok = False; cross = False        # 2026-11-01: работает только на одной точной настройке — подгонка
            c["pass_by"] = "монета + порог случайности" if ok else ("монета + другие монеты" if cross else None)
            ok = ok or cross
            # 2026-11-07: строгие проверки — случайные входы, окна, бутстрап, худшее исполнение
            try:
                rb = _rand_baseline(F, side, FILTERS[c["flt"]], c["sl"], c["rr"], hold, cut, n, v["n"])
                wf = _wfa(full, 210, n); wpos = sum(1 for x in wf if x > 0)
                mcp, mcdd = _mc(full)
                real = _sim(F, idx, side, c["sl"], c["rr"], hold, cut, n, cost=COST + 0.001, delay=1)
                rr_real = sum(x[2] for x in real)
                c["strict"] = {"rand95": round(rb, 1), "wfa": wf, "wfa_pos": f"{wpos}/{len(wf)}", "mc_pos": round(mcp, 2), "mc_dd95": round(mcdd, 1),
                               "real_r": round(float(rr_real), 1)}
                strict_ok = v["r"] > rb and wpos >= 4 and mcp >= 0.95 and rr_real > 0
                c["strict"]["ok"] = bool(strict_ok)
                if ok and not strict_ok:
                    ok = False
                    c["pass_by"] = None
                    c["strict_fail"] = ("не лучше случайных входов" if v["r"] <= rb else "мало окон в плюсе" if wpos < 4
                                        else "бутстрап < 95%" if mcp < 0.95 else "минус при худшем исполнении")
            except Exception as exc:  # noqa: BLE001
                c["strict"] = {"error": str(exc)[:120]}; ok = False
            _log_exp({"t": int(time.time() * 1000), "job": job, "symbol": symbol, "tf": tf, "side": side, "trig": c["trig"], "p": c["p"], "flt": c["flt"],
                      "sl": c["sl"], "rr": c["rr"], "train_r": c["train"]["r"], "valid": v, "luck": round(float(luck), 1), "strict": c.get("strict"),
                      "tried": len(combos) * len(EXITS), "pass": bool(ok)})
            weak = v["r"] > 0 and v["pf"] >= 1.0
            c["verdict"] = "прошла" if ok else ("слабо" if weak else "не прошла")
            c["why"] = (f"{symbol.replace('USDT', '')} вперёд: {v['n']} сделок, PF {v['pf']}, {v['r']:+}R "
                        f"(половины {c['fwd_halves'][0]:+}/{c['fwd_halves'][1]:+}R); на случайных данных перебор «находит» до {luck:+.1f}R; справка: "
                        f"другие монеты в плюсе {pos} из {len(res)}; соседние настройки в плюсе {c.get('neighbors', '—')}"
                        + (f"; случайные входы (95%) {c['strict'].get('rand95')}R, окна в плюсе {c['strict'].get('wfa_pos')}, бутстрап {c['strict'].get('mc_pos')}, худшее исполнение {c['strict'].get('real_r')}R" if c.get("strict") and "rand95" in c["strict"] else "")
                        + (f" · НЕ прошла строгую проверку: {c['strict_fail']}" if c.get("strict_fail") else "")
                        + (f" · прошла: {c['pass_by']}" if c.get("pass_by") else ""))
            c["name"] = TRIGGERS[c["trig"]][0].format(p=c["p"], ext="максимума" if side > 0 else "минимума") + \
                (f" · {c['flt']}" if c["flt"] != "нет" else "") + (f" · стоп {c['sl']} ATR · тейк {c['rr']}R" if c['rr'] > 0 else f" · трейлинг {c['sl']} ATR без тейка" if c['rr'] == 0
                 else f" · стоп {c['sl']} ATR · выход по обратному пробою {int(-c['rr'])} свечей")
            c["pine"] = pine(symbol, tf, side, c)
            # месячная доходность при риске 1% на сделку
            days = max(1, (d.t.iloc[-1] - d.t.iloc[cut]) / 86400_000)
            c["month_pct_1r"] = round(v["r"] / days * 30, 1)
        order = {"прошла": 0, "слабо": 1, "не прошла": 2}
        top.sort(key=lambda x: (order[x["verdict"]], -x["valid"]["r"]))
        J.update(pct=100, text="готово", done=True, result={"symbol": symbol, "tf": tf, "side": side, "tried": len(combos) * len(EXITS),
                                                            "passed": sum(1 for x in top if x["verdict"] == "прошла"), "rows": top,
                                                            "luck_r": round(float(luck), 1)})
    except Exception as exc:  # noqa: BLE001
        J.update(done=True, error=str(exc)[:300])


def start(symbol: str, tf: str, side: int) -> str:
    import subprocess, sys  # noqa: PLC0415, E401
    job = uuid.uuid4().hex[:10]
    tf = tf if tf in TF_MIN else "1h"; side = 1 if side > 0 else -1
    J = _FileJob(job); J.update(pct=0, text="старт", done=False)
    venv = BASE / "venv" / "Scripts" / "python.exe"
    py = str(venv) if venv.exists() else sys.executable
    subprocess.Popen([py, str(BASE / "strategy_gen.py"), job, symbol.upper(), tf, str(side)], cwd=str(BASE),
                     creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    return job


def status(job: str) -> dict:
    try:
        return json.loads((OUT / f"gen_{job}.json").read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {"done": False, "pct": 1, "text": "запуск…"}


# ---------------- Pine ----------------
def _pine_exit(c, side) -> str:
    if c["rr"] >= 0:
        return ""
    m = int(-c["rr"])
    cond = f"close < ta.lowest(low, {m})[1]" if side > 0 else f"close > ta.highest(high, {m})[1]"
    return f"if strategy.position_size != 0 and {cond}\n    strategy.close(\"E\", comment=\"обратный пробой {m}\")\n"


def pine(symbol, tf, side, c) -> str:
    long_c, short_c = TRIGGERS[c["trig"]][3], TRIGGERS[c["trig"]][4]
    cond = (long_c if side > 0 else short_c).format(p=c["p"])
    if c["flt"] == "по тренду EMA200":
        cond += " and close " + (">" if side > 0 else "<") + " ta.ema(close, 200)"
    elif c["flt"] == "объём ×1.5":
        cond += " and volume > ta.sma(volume, 50) * 1.5"
    d = "strategy.long" if side > 0 else "strategy.short"
    sgn = "-" if side > 0 else "+"; tsg = "+" if side > 0 else "-"
    return f"""//@version=6
// TRADEOS · честный генератор · {symbol} {tf}
// Подбор на 60% истории, проверка на 40%: {c['why']}
strategy("TRADEOS {symbol} {tf}", overlay=true, initial_capital=1000, commission_type=strategy.commission.percent, commission_value=0.055)
tp = (high + low + close) / 3
esa = ta.ema(tp, 10)
dd = ta.ema(math.abs(tp - esa), 10)
wt1 = ta.ema((tp - esa) / (0.015 * dd), 21)
wt2 = ta.sma(wt1, 4)
atr = ta.atr(14)
sig = {cond}
riskPct = input.float(1.0, "Риск на сделку, % депозита")
if sig and strategy.position_size == 0
    stopDist = {c['sl']} * atr
    qty = strategy.equity * riskPct / 100 / stopDist
    strategy.entry("E", {d}, qty=qty)
    strategy.exit("X", "E", stop=close {sgn} stopDist{f", limit=close {tsg} {c['rr']} * stopDist" if c['rr'] > 0 else ""})
{_pine_exit(c, side)}plotshape(sig, style={'shape.triangleup' if side > 0 else 'shape.triangledown'}, location={'location.belowbar' if side > 0 else 'location.abovebar'}, color={'color.green' if side > 0 else 'color.red'})
"""


# ---------------- библиотека ----------------
def lib_list() -> list:
    try:
        return json.loads(LIB.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return []


def lib_save(item: dict) -> list:
    if item.get("verdict") != "прошла":
        raise ValueError("в библиотеку сохраняются только стратегии, прошедшие проверку вперёд")
    lst = [x for x in lib_list() if x.get("id") != item.get("id")]
    if not (item.get("strict") or {}).get("ok"):   # 2026-11-07: в библиотеку — только прошедшие строгую проверку
        raise ValueError("стратегия не прошла строгую проверку (случайные входы / окна / бутстрап / худшее исполнение)")
    item = {k: item[k] for k in ("symbol", "tf", "side", "name", "trig", "p", "flt", "sl", "rr", "train", "valid", "coins", "verdict", "why", "pine", "month_pct_1r", "strict") if k in item}
    item.update(id=uuid.uuid4().hex[:8], saved=int(time.time() * 1000))
    lst.insert(0, item)
    LIB.write_text(json.dumps(lst[:200], ensure_ascii=False, indent=1), encoding="utf-8")
    return lst


def lib_delete(item_id: str) -> list:
    lst = [x for x in lib_list() if x.get("id") != item_id]
    LIB.write_text(json.dumps(lst, ensure_ascii=False, indent=1), encoding="utf-8")
    return lst


TOP20 = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT", "DOGEUSDT", "BNBUSDT", "ADAUSDT", "LINKUSDT", "AVAXUSDT", "SUIUSDT",
         "HYPEUSDT", "TAOUSDT", "LTCUSDT", "DOTUSDT", "NEARUSDT", "APTUSDT", "ARBUSDT", "OPUSDT", "INJUSDT", "TIAUSDT"]


def scan(job: str, coins: list, tfs: list, sides: list) -> None:
    """2026-10-28: «Проверить всё» — генератор по очереди на каждой монете × ТФ × направлении. Показывает только прошедшие.
    Честно: при ~6% ложных «прошла» на один прогон, на 80 прогонах случайно пройдут ~5 — поэтому список отсортирован по запасу
    над порогом случайности, и каждый найденный вариант — только на бумагу."""
    J = _FileJob(job); runs = [(c, t, s) for c in coins for t in tfs for s in sides]
    rows, table = [], []
    t0 = time.time()
    for k, (sym, tf, sd) in enumerate(runs):
        left = (time.time() - t0) / max(1, k) * (len(runs) - k) if k else 0
        J.update(pct=100 * k / len(runs), done=False,
                 text=f"{k + 1}/{len(runs)}: {sym.replace('USDT', '')} {tf} {'лонг' if sd > 0 else 'шорт'}"
                      + (f" · осталось ~{int(left // 60)} мин" if k else ""))
        sub = f"{job}_{k}"
        try:
            generate(sub, sym, tf, sd)
            r = json.loads((OUT / f"gen_{sub}.json").read_text(encoding="utf-8"))
            res = r.get("result") or {}
            best = max((x["valid"]["r"] for x in res.get("rows") or []), default=0)
            table.append({"sym": sym.replace("USDT", ""), "tf": tf, "side": sd, "passed": res.get("passed", 0),
                          "best_r": round(float(best), 1), "luck_r": res.get("luck_r"), "error": r.get("error")})
            for x in res.get("rows") or []:
                if x["verdict"] == "прошла":
                    x.update(symbol=sym, tf=tf, side=sd, margin=round(x["valid"]["r"] / max(1.0, res.get("luck_r") or 1), 2))
                    x.pop("curve", None) if len(rows) > 40 else None
                    rows.append(x)
            (OUT / f"gen_{sub}.json").unlink(missing_ok=True)
        except Exception as exc:  # noqa: BLE001
            table.append({"sym": sym.replace("USDT", ""), "tf": tf, "side": sd, "passed": 0, "best_r": 0, "luck_r": None, "error": str(exc)[:120]})
    rows.sort(key=lambda x: -x.get("margin", 0))
    J.update(pct=100, text="готово", done=True,
             result={"symbol": "ТОП-20", "tf": "", "side": 1, "tried": len(runs), "passed": len(rows), "rows": rows[:40],
                     "scan": table, "expected_false": round(len(runs) * 0.06, 1)})


def scan_start(coins=None, tfs=None, sides=None) -> str:
    import subprocess, sys  # noqa: PLC0415, E401
    job = "scan" + uuid.uuid4().hex[:8]
    cfg = {"coins": coins or TOP20, "tfs": [t for t in (tfs or ["4h", "1h"]) if t in TF_MIN], "sides": sides or [1, -1]}
    _FileJob(job).update(pct=0, text="старт", done=False)
    (OUT / f"{job}.cfg.json").write_text(json.dumps(cfg), encoding="utf-8")
    venv = BASE / "venv" / "Scripts" / "python.exe"
    py = str(venv) if venv.exists() else sys.executable
    subprocess.Popen([py, str(BASE / "strategy_gen.py"), "scan", job], cwd=str(BASE),
                     creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    return job


if __name__ == "__main__":
    import sys  # noqa: PLC0415
    if str(BASE) not in sys.path:
        sys.path.insert(0, str(BASE))
    if sys.argv[1] == "scan":
        c = json.loads((OUT / f"{sys.argv[2]}.cfg.json").read_text(encoding="utf-8"))
        scan(sys.argv[2], c["coins"], c["tfs"], c["sides"])
    else:
        generate(sys.argv[1], sys.argv[2], sys.argv[3], int(sys.argv[4]))


def lib_paper(item_id: str, coins: list, stop: bool = False) -> list:
    """Включить/выключить бумажного бота для стратегии из библиотеки (ведёт windows_app/gen_paper.py)."""
    lst = lib_list()
    for x in lst:
        if x.get("id") == item_id:
            if stop:
                x["paper_stopped"] = True
            else:
                x["paper_coins"] = [c.upper() if c.upper().endswith("USDT") else c.upper() + "USDT" for c in coins][:10]
                x["paper_stopped"] = False
                x["paper_started"] = int(time.time() * 1000)
    LIB.write_text(json.dumps(lst, ensure_ascii=False, indent=1), encoding="utf-8")
    return lst
