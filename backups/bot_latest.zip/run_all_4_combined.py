#!/usr/bin/env python3
"""
Единый прогон всех 4 DCA/сигнальных стратегий (bb_roc, cci_rsi, latuserge,
etnar) с ОДНИМ скачиванием данных на символ вместо четырёх.

Зачем этот файл появился (2026-09-05): все 4 отдельных скрипта, запущенные
одновременно в 4 терминалах на --bars 500000, зависли -- за 4+ часа ни один
не продвинулся дальше первого символа (bb_roc и cci_rsi застряли на
SOLUSDT, latuserge на ETHUSDT, etnar не стартовал вообще), при этом живой
грид-бот на ТОМ ЖЕ API-ключе продолжал нормально писать состояние каждую
минуту. Значит дело не в сети/машине целиком, а в том, что 4 параллельных
процесса плюс живой бот толкались за один и тот же rate limit Bybit --
и чем больше --bars, тем больше страниц пагинации, тем больше шансов
поймать "Too many visits" и уйти в долгие ретраи одновременно у всех.

Что делает этот скрипт: НЕ трогает 4 исходных файла на диске. Импортирует
их как модули, подменяет их идентичную функцию fetch_history() на одну
общую версию с кэшем по (symbol, timeframe, bars) -- так что данные
каждого символа скачиваются РОВНО ОДИН РАЗ и просто переиспользуются
всеми 4 стратегиями -- и вызывает по очереди их родной main() (та же
логика Params/индикаторов/симуляции/CSV/сплит-сэмпла, без изменений).
Итог: вместо 20 скачиваний (4 стратегии x 5 символов) будет 5, и
конкуренции между процессами вообще не будет, т.к. это один процесс.

ПЕРЕД запуском: останови 4 старых зависших терминала (Ctrl+C или закрыть
окно) -- иначе они по-прежнему будут держать rate limit заняты.

Запуск:
    python run_all_4_combined.py --symbol ETHUSDT SOLUSDT ARBUSDT INJUSDT TIAUSDT --bars 500000

Результаты каждой стратегии лягут в свою папку `<strategy>_out_combined/`
рядом с этим файлом -- отдельно от старых (зависших) `_out_v2` папок,
чтобы не путать частичные старые данные с новыми.
"""
from __future__ import annotations

import argparse
import importlib.util
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))

import pandas as pd  # noqa: E402
import requests  # noqa: E402

from app.data import BYBIT_BASE, INTERVAL_MAP, DataError  # noqa: E402


# --------------------------------------------------------- shared fetch --

_FETCH_CACHE: dict[tuple, pd.DataFrame] = {}
_FETCH_COUNT = {"real": 0, "cached": 0}


def _fetch_page(params: dict, symbol: str, retries: int = 4, timeout: float = 15.0) -> dict:
    # Identical to the retry patch already applied in all 4 original
    # scripts on 2026-09-05 (retries on retCode != 0, not just network
    # exceptions -- Bybit's rate-limit error is a normal HTTP 200).
    last_exc: Exception | None = None
    for attempt in range(retries):
        try:
            resp = requests.get(f"{BYBIT_BASE}/v5/market/kline", params=params, timeout=timeout)
            resp.raise_for_status()
            payload = resp.json()
            if payload.get("retCode") == 0:
                return payload
            last_exc = RuntimeError(f"retCode={payload.get('retCode')} {payload.get('retMsg')}")
        except requests.RequestException as exc:
            last_exc = exc
        if attempt < retries - 1:
            time.sleep(1.5 * (attempt + 1))
    raise DataError(f"Bybit request failed for {symbol} after {retries} attempts: {last_exc}")


def shared_fetch_history(symbol: str, timeframe: str, total_bars: int, category: str = "linear") -> pd.DataFrame:
    """Drop-in replacement for each script's own fetch_history(), memoized
    for this process's lifetime. The 4 strategy modules below all get this
    same function monkey-patched in, so a symbol's candles are downloaded
    once no matter how many of the 4 strategies ask for them."""
    key = (symbol, timeframe, total_bars, category)
    if key in _FETCH_CACHE:
        _FETCH_COUNT["cached"] += 1
        print(f"  [cache hit] {symbol} {timeframe} {total_bars} bars -- reusing already-fetched data, 0 new requests")
        return _FETCH_CACHE[key].copy()

    _FETCH_COUNT["real"] += 1
    interval = INTERVAL_MAP[timeframe]
    all_rows: list = []
    end = None
    while len(all_rows) < total_bars:
        params = {"category": category, "symbol": symbol, "interval": interval, "limit": 1000}
        if end is not None:
            params["end"] = end
        payload = _fetch_page(params, symbol)
        rows = payload["result"]["list"]
        if not rows:
            break
        all_rows.extend(rows)
        oldest_ts = int(rows[-1][0])
        end = oldest_ts - 1
        if len(rows) < 1000:
            break
        time.sleep(0.6)

    if not all_rows:
        raise DataError(f"No kline data returned for {symbol} {timeframe}")

    df = pd.DataFrame(all_rows, columns=["open_time", "open", "high", "low", "close", "volume", "turnover"])
    df["open_time"] = df["open_time"].astype("int64")
    df = df.drop_duplicates(subset="open_time")
    for col in ("open", "high", "low", "close", "volume", "turnover"):
        df[col] = df[col].astype(float)
    df["open_time"] = pd.to_datetime(df["open_time"], unit="ms", utc=True)
    df = df.sort_values("open_time").reset_index(drop=True)
    if len(df) > total_bars:
        df = df.tail(total_bars).reset_index(drop=True)

    if len(df) > 1:
        step_seconds = df["open_time"].diff().dt.total_seconds()
        expected_step = step_seconds.median()
        max_gap = step_seconds.max()
        max_gap_idx = step_seconds.idxmax()
        span_days = (df["open_time"].iloc[-1] - df["open_time"].iloc[0]).days
        print(f"  [fetch_history] {symbol}: {len(df)} bars, "
              f"{df['open_time'].iloc[0]} -> {df['open_time'].iloc[-1]} "
              f"({span_days} days)")
        if pd.notna(max_gap) and max_gap > expected_step * 3:
            print(f"  [fetch_history] WARNING: {symbol} has a gap of "
                  f"{max_gap / 60:.1f} min -- data is likely NON-CONTIGUOUS, "
                  f"treat this run's results as unreliable until re-fetched.")

    _FETCH_CACHE[key] = df
    return df.copy()


# ------------------------------------------------------- module loading --

STRATEGIES = [
    ("bb_roc", "bb_roc_atr_adx_donchian_sar_backtest.py", "bb_roc_atr_adx_donchian_sar_backtest_out_combined"),
    ("cci_rsi", "cci_rsi_wr_signal_grid_backtest.py", "cci_rsi_wr_signal_grid_backtest_out_combined"),
    ("latuserge", "long_strategy15_latuserge_backtest.py", "long_strategy15_latuserge_backtest_out_combined"),
    ("etnar", "etnar_bb_adx_scalp_backtest.py", "etnar_bb_adx_scalp_backtest_out_combined"),
]


def load_module(name: str, filename: str):
    path = HERE / filename
    if not path.exists():
        raise FileNotFoundError(f"Не найден {path} -- запускай этот скрипт из той же папки, что и 4 оригинальных .py")
    spec = importlib.util.spec_from_file_location(f"_combined_{name}", path)
    module = importlib.util.module_from_spec(spec)
    # ВАЖНО: должно быть зарегистрировано в sys.modules ДО exec_module --
    # иначе dataclasses (в паре с "from __future__ import annotations",
    # которую используют все 4 скрипта) не может резолвить свои
    # строковые аннотации через sys.modules[cls.__module__] и падает с
    # "'NoneType' object has no attribute '__dict__'" на первом же @dataclass.
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    module.fetch_history = shared_fetch_history  # <- сама суть фикса
    return module


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--symbol", nargs="+", default=["ETHUSDT", "SOLUSDT", "ARBUSDT", "INJUSDT", "TIAUSDT"])
    parser.add_argument("--bars", type=int, default=500000)
    args = parser.parse_args()

    print("=" * 78)
    print(f"ЕДИНЫЙ ПРОГОН 4 СТРАТЕГИЙ: symbols={args.symbol}, bars={args.bars}")
    print("Данные каждого символа будут скачаны РОВНО ОДИН РАЗ и переиспользованы всеми 4 стратегиями.")
    print("=" * 78)

    t0 = time.time()
    for name, filename, out_dir in STRATEGIES:
        print(f"\n\n{'#' * 78}\n# СТРАТЕГИЯ: {name}  ({filename})\n{'#' * 78}")
        module = load_module(name, filename)
        old_argv = sys.argv
        sys.argv = [filename, "--symbol", *args.symbol, "--bars", str(args.bars), "--out", out_dir]
        try:
            module.main()
        except SystemExit as exc:
            print(f"  [WARN] {name}: argparse завершился с кодом {exc} -- проверь совместимость аргументов")
        finally:
            sys.argv = old_argv

    elapsed = time.time() - t0
    print(f"\n\n{'=' * 78}")
    print(f"ВСЕ 4 СТРАТЕГИИ ЗАВЕРШЕНЫ за {elapsed/60:.1f} мин.")
    print(f"Реальных скачиваний с Bybit: {_FETCH_COUNT['real']}   "
          f"Обращений к кэшу (сэкономленных запросов): {_FETCH_COUNT['cached']}")
    print("Результаты в папках: " + ", ".join(f"{s[2]}/" for s in STRATEGIES))
    print("=" * 78)


if __name__ == "__main__":
    main()
