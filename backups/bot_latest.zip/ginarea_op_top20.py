"""ginarea_op_top20.py — 2026-10-18. Те же настройки бота «OP_Test3_Rsi_or_SuperTrend» на топ-20 монетах OKX (USDT-перпы
по обороту за 24 ч). Размер ордера выровнен: 1 $ на ордер для всех монет (полная сетка 120 $), чтобы монеты были
сравнимы. Логика — ginarea_op_test.py (вход RSI<38 или цена>ST 15m, режим «разовая проверка», 120×шаг 0.1%×1.001,
цель 0.4%, Инстоп 0.05%, стопы 0.05/0.2%, без выхода по средней, без стоп-лосса, taker 0.05%).
По умолчанию 90 дней (1m-свечи 20 монет качаются долго: ~5–8 мин на монету в первый раз, потом из кеша).
Ничего не торгует. Запуск: ginarea_op_top20.bat [дней] → bt_lab_bots/ginarea_op_top20.txt
"""
from __future__ import annotations
import sys, time
from pathlib import Path
import numpy as np
import pandas as pd
import requests
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import ginarea_op_test as G  # noqa: E402
OUT = BASE / "bt_lab_bots" / "ginarea_op_top20.txt"
LINES = []
def say(s=""):
    print(s, flush=True); LINES.append(s)

def top20():
    j = requests.get("https://www.okx.com/api/v5/market/tickers", params={"instType": "SWAP"}, timeout=20).json()
    rows = []
    for x in j.get("data", []):
        if not x["instId"].endswith("-USDT-SWAP"):
            continue
        try:
            rows.append((float(x["volCcy24h"]) * float(x["last"]), x["instId"]))
        except (ValueError, KeyError):
            pass
    return [i for _, i in sorted(rows, reverse=True)[:20]]

def main():
    days = int(sys.argv[1]) if len(sys.argv) > 1 else 90
    say(f"«OP_Test3_Rsi_or_SuperTrend» на топ-20 OKX · {days} дн. · 1 $ на ордер (сетка 120 $) · taker 0.05% · "
        f"{time.strftime('%Y-%m-%d %H:%M')}")
    insts = top20()
    say("Монеты: " + ", ".join(i.split("-")[0] for i in insts))
    say(""); say(f"{'монета':<8}{'закрыто':>9}{'висит':>9}{'итог':>9}{'1-я пол.':>10}{'2-я пол.':>10}{'худшая':>9}{'сделок':>8}{'ход цены':>10}")
    tot = []
    for inst in insts:
        try:
            d = G.okx_1m(inst, days)
            if len(d) < 20000:
                say(f"{inst.split('-')[0]:<8} мало истории"); continue
            G.P["qty"] = 1.0 / float(d.c.iloc[0])
            gate = G.entry_gate(d)
            m = len(d) // 2
            r = G.run(d, gate, "once")
            r1 = G.run(d.iloc[:m].reset_index(drop=True), gate[:m], "once")
            r2 = G.run(d.iloc[m:].reset_index(drop=True), gate[m:], "once")
            f = lambda x: x["real"] + x["open"]  # noqa: E731
            ok = f(r1) > 0 and f(r2) > 0
            tot.append(f(r))
            say(f"{inst.split('-')[0]:<8}{r['real']:>+9.2f}{r['open']:>+9.2f}{f(r):>+9.2f}{f(r1):>+10.2f}{f(r2):>+10.2f}"
                f"{r['worst']:>+9.2f}{r['deals']:>8}{(d.c.iloc[-1] / d.c.iloc[0] - 1) * 100:>+9.0f}% {'✅' if ok else '❌'}")
        except Exception as exc:  # noqa: BLE001
            say(f"{inst.split('-')[0]:<8} ошибка: {str(exc)[:80]}")
    if tot:
        say(""); say(f"В плюсе {sum(x > 0 for x in tot)}/{len(tot)} монет · сумма {sum(tot):+.2f} $ · средний итог {np.mean(tot):+.2f} $ на монету")
    say("Итог = закрыто + висящая позиция на конец. ✅ = итог в плюсе в обеих половинах. Суммы на 1 $ за ордер:")
    say("умножь на свой размер ордера в $ (например, при 5 $ за ордер — ×5).")
    OUT.parent.mkdir(exist_ok=True); OUT.write_text("\n".join(LINES), encoding="utf-8"); print(f"\nОтчёт: {OUT}")

if __name__ == "__main__":
    main()
