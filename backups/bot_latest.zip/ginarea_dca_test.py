"""ginarea_dca_test.py — 2026-11-02. Приближённый бэктест бота GinArea «40% DCA @BlindScalper_c» (Default grid, LONG, OKX ETC).

Настройки со скриншотов: 10 ордеров, шаг 3.59% (сетка ≈ −28% от первого), размер 0.2 ETC × мультипликатор 1.3 (макс. нет),
выход по СРЕДНЕЙ: цель 2% от средней → стоп-профит, трейлинг мин. 0.05% / макс. 0.2%, Instop 0.1%.
Тейк/стоп бота НЕТ. Индикатора нет: новый цикл сразу после закрытия предыдущего (после отката на Instop).
Комиссия taker 0.05% (OKX). Ничего не торгует.
Запуск: ginarea_dca_test.bat [дней=365] [монета=ETC] → bt_lab_bots/ginarea_dca_test_<COIN>.txt
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import pandas as pd

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
from ginarea_sui_test import okx_1m  # noqa: E402
from ginarea_lot import fl, lot  # noqa: E402

LINES = []


def say(s=""):
    print(s, flush=True); LINES.append(s)


def run(d, P, fee=0.0005):
    t, o, h, l, c = (d[k].to_numpy() for k in ("t", "o", "h", "l", "c"))
    pos, total, R, monthly = None, 0.0, {"cycles": 0, "full": 0, "sl": 0, "worst": 0.0, "worst_t": None, "hang_h": 0.0,
                                          "max_notional": 0.0, "fees": 0.0, "max_n": 0}, {}
    ref = o[0]

    def book(x, ts):
        nonlocal total
        total += x; m = pd.to_datetime(ts, unit="ms").strftime("%Y-%m"); monthly[m] = monthly.get(m, 0.0) + x

    def close(px, ts):
        nonlocal pos, ref
        R["fees"] += px * pos["qty"] * fee; book((px - pos["avg"]) * pos["qty"] - px * pos["qty"] * fee, ts)
        R["hang_h"] = max(R["hang_h"], (ts - pos["t0"]) / 3_600_000); pos = None; ref = px

    for i in range(1, len(c)):
        if pos is None:
            ref = max(ref, h[i - 1])                                   # Instop: IN после отката на 0.1% от максимума
            px = ref * (1 - P["instop"])
            if l[i] > px:
                continue
            px = min(px, o[i]); q = fl(P["qty"], P)
            R["fees"] += px * q * fee; book(-px * q * fee, t[i])
            pos = {"qty": q, "avg": px, "last": px, "n": 1, "q": q, "qr": P["qty"], "stop": None, "t0": t[i]}; R["cycles"] += 1
        while pos["n"] < P["n"] and l[i] <= pos["last"] * (1 - P["step"]):
            px = pos["last"] * (1 - P["step"]); pos["qr"] *= P["mult"]; q = fl(pos["qr"], P)
            pos["avg"] = (pos["avg"] * pos["qty"] + px * q) / (pos["qty"] + q); pos["qty"] += q; pos["q"] = q
            pos["last"] = px; pos["n"] += 1; R["fees"] += px * q * fee; book(-px * q * fee, t[i])
            if pos["n"] == P["n"]:
                R["full"] += 1
        R["max_n"] = max(R["max_n"], pos["n"])
        R["max_notional"] = max(R["max_notional"], pos["qty"] * c[i])
        un = (l[i] - pos["avg"]) * pos["qty"]
        if un < R["worst"]:
            R["worst"], R["worst_t"] = un, t[i]
        if P.get("sl") is not None and un <= P["sl"]:
            close(l[i], t[i]); R["sl"] += 1; continue
        trig = pos["avg"] * (1 + P["target"])
        if pos["stop"] is None and h[i] >= trig:
            pos["stop"] = trig * (1 - P["min_stop"])
        if pos["stop"] is not None:
            pos["stop"] = max(pos["stop"], h[i] * (1 - P["max_stop"]))
            if l[i] <= pos["stop"]:
                close(pos["stop"], t[i])
    R["open_un"] = 0.0 if pos is None else (c[-1] - pos["avg"]) * pos["qty"]
    R["open_n"] = 0 if pos is None else pos["n"]
    if pos is not None:
        R["hang_h"] = max(R["hang_h"], (t[-1] - pos["t0"]) / 3_600_000)
    R["total"], R["all"], R["monthly"] = total, total + R["open_un"], monthly
    return R


def rep(name, r):
    say(f"--- {name}")
    say(f"  ИТОГО {r['all']:+.2f} $ (закрыто {r['total']:+.2f}, сейчас висит {r['open_n']} орд. {r['open_un']:+.2f}) · циклов {r['cycles']} · "
        f"стопов {r['sl']} · сетка заполнялась целиком {r['full']} раз · комиссии {r['fees']:.2f} $")
    say(f"  макс. ордеров {r['max_n']} · позиция до {r['max_notional']:.0f} $ · худшая просадка {r['worst']:.2f} $"
        + (f" ({pd.to_datetime(r['worst_t'], unit='ms'):%Y-%m-%d})" if r["worst_t"] else "") + f" · самый долгий цикл {r['hang_h'] / 24:.0f} дн.")
    say("  по месяцам: " + "  ".join(f"{m[2:]} {v:+.1f}" for m, v in sorted(r["monthly"].items())))


def main():
    days = int(sys.argv[1]) if len(sys.argv) > 1 else 365
    coin = (sys.argv[2] if len(sys.argv) > 2 else "ETC").upper()
    say(f"GinArea Default grid «40% DCA» — приближённый бэктест · OKX {coin} 1m · {days} дн. · taker 0.05% · {time.strftime('%Y-%m-%d %H:%M')}")
    d = okx_1m(coin, days)
    if len(d) < 10000:
        say("мало свечей"); return
    say(f"{pd.to_datetime(d.t.iloc[0], unit='ms'):%Y-%m-%d} → {pd.to_datetime(d.t.iloc[-1], unit='ms'):%Y-%m-%d} · {coin} "
        f"{d.c.iloc[0]:.3f} → {d.c.iloc[-1]:.3f} ({(d.c.iloc[-1] / d.c.iloc[0] - 1) * 100:+.0f}%) · мин {d.l.min():.3f} макс {d.h.max():.3f}")
    base = dict(n=10, step=0.0359, qty=0.2, mult=1.3, target=0.02, min_stop=0.0005, max_stop=0.002, instop=0.001, sl=None, lot=lot(coin))
    say(f"Лот OKX {coin}: шаг {base['lot'][0]:g}, минимум {base['lot'][1]:g} (размер округляется вниз)")
    full = sum(fl(base["qty"] * base["mult"] ** k, base) for k in range(base["n"]))
    say(f"Полная сетка {full:.2f} {coin} ≈ {full * d.c.iloc[-1]:.0f} $ · покрывает падение ≈ {(1 - (1 - base['step']) ** 9) * 100:.0f}% · "
        f"последний ордер в {base['mult'] ** 9:.1f} раза больше первого")
    rep("как у тебя (10 × 3.59%, ×1.3, цель 2% от средней, без стопа)", run(d, base))
    say(""); say("===== варианты =====")
    rep("стоп-лосс бота −15 $", run(d, {**base, "sl": -15.0}))
    rep("стоп-лосс бота −25 $", run(d, {**base, "sl": -25.0}))
    rep("цель 1% вместо 2%", run(d, {**base, "target": 0.01}))
    rep("мультипликатор 1.15", run(d, {**base, "mult": 1.15}))
    rep("шаг 5% (сетка ≈ −37%)", run(d, {**base, "step": 0.05}))
    half = len(d) // 2
    say(""); say("===== половины истории (как у тебя) =====")
    rep("1-я половина", run(d.iloc[:half].reset_index(drop=True), base))
    rep("2-я половина", run(d.iloc[half:].reset_index(drop=True), base))
    say(""); say("Приближение алгоритма GinArea (минутные свечи). Сверяй с бэктестом GinArea на тиках.")
    out = BASE / "bt_lab_bots" / f"ginarea_dca_test_{coin}.txt"
    out.parent.mkdir(exist_ok=True); out.write_text("\n".join(LINES), encoding="utf-8")
    print(f"\nОтчёт: {out}")


if __name__ == "__main__":
    main()
