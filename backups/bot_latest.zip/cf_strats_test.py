"""cf_strats_test.py — 2026-11-01. Моя версия 3 открытых стратегий из CryptoFORA (G-RSI Heiken Ashi, SSL & CCI (EMA), MACD RSI Stochastic).
Это НЕ их точные сигналы — общеизвестные правила этих индикаторов. 12 монет, 15m/1h/4h, комиссия 0.08% (Hash Hedge), стоп 1.5 ATR,
выход: обратный сигнал или тейк 2R. Проверка: обе половины истории, 180/90 дней, монет в плюсе. Пишет bt_lab_bots/cf_strats_test.txt"""
from __future__ import annotations
import sys, time
from pathlib import Path
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import recheck_recent as RR  # noqa: E402
import strat_batch5 as B5  # noqa: E402
B5.FEE = 0.0008


def extra(d, I):
    c, h, l, o = d.c, d.h, d.l, d.o
    # Heiken Ashi
    hc = (o + h + l + c) / 4; ho = hc.copy(); ho.iloc[0] = (o.iloc[0] + c.iloc[0]) / 2
    hov = ho.to_numpy(dtype=float, copy=True); hcv = hc.to_numpy(dtype=float)
    for i in range(1, len(d)):
        hov[i] = (hov[i - 1] + hcv[i - 1]) / 2
    I["ha_up"] = hcv > hov
    x = pd.Series(hcv).diff(); u = x.clip(lower=0).ewm(alpha=1 / 14, adjust=False).mean(); w = (-x).clip(lower=0).ewm(alpha=1 / 14, adjust=False).mean()
    I["ha_rsi"] = (100 - 100 / (1 + u / w.replace(0, 1e-12))).values
    # SSL channel 10 + CCI 20
    sh = h.rolling(10).mean(); sl = l.rolling(10).mean(); hl = np.zeros(len(d))
    cv, shv, slv = c.to_numpy(float), sh.to_numpy(float), sl.to_numpy(float)
    for i in range(1, len(d)):
        hl[i] = 1 if cv[i] > shv[i] else (-1 if cv[i] < slv[i] else hl[i - 1])
    I["ssl"] = hl
    tp = (h + l + c) / 3; md = tp.rolling(20).apply(lambda a: np.abs(a - a.mean()).mean(), raw=True)
    I["cci"] = ((tp - tp.rolling(20).mean()) / (0.015 * md)).values
    # MACD 12/26/9 + Stoch 14/3
    m = c.ewm(span=12, adjust=False).mean() - c.ewm(span=26, adjust=False).mean(); I["macd"] = m.values; I["msig"] = m.ewm(span=9, adjust=False).mean().values
    k = 100 * (c - l.rolling(14).min()) / (h.rolling(14).max() - l.rolling(14).min()).replace(0, np.nan); I["stk"] = k.rolling(3).mean().values


def grsi(I, i):
    if I["ha_up"][i] and not I["ha_up"][i - 1] and I["ha_rsi"][i] > 50: return 1
    if not I["ha_up"][i] and I["ha_up"][i - 1] and I["ha_rsi"][i] < 50: return -1
    return 0
def grsi_x(I, j, s): return (not I["ha_up"][j]) if s > 0 else I["ha_up"][j]

def sslcci(I, i):
    if I["ssl"][i] == 1 and I["ssl"][i - 1] != 1 and I["cci"][i] > 0 and I["c"][i] > I["ema200"][i]: return 1
    if I["ssl"][i] == -1 and I["ssl"][i - 1] != -1 and I["cci"][i] < 0 and I["c"][i] < I["ema200"][i]: return -1
    return 0
def sslcci_x(I, j, s): return I["ssl"][j] == -s

def mrs(I, i):
    up = I["macd"][i] > I["msig"][i] and I["macd"][i - 1] <= I["msig"][i - 1]
    dn = I["macd"][i] < I["msig"][i] and I["macd"][i - 1] >= I["msig"][i - 1]
    if up and I["rsi14"][i] > 50 and I["stk"][i] < 80: return 1
    if dn and I["rsi14"][i] < 50 and I["stk"][i] > 20: return -1
    return 0
def mrs_x(I, j, s): return (I["macd"][j] < I["msig"][j]) if s > 0 else (I["macd"][j] > I["msig"][j])

STR = {"G-RSI Heiken Ashi": (grsi, grsi_x), "SSL & CCI (EMA200)": (sslcci, sslcci_x), "MACD RSI Stochastic": (mrs, mrs_x)}


def main():
    import kvoo_longtest as K  # noqa: PLC0415
    now = int(time.time() * 1000); lines = []
    for tf in ("15m", "1h", "4h"):
        data = []
        for s in K.COINS:
            try:
                d = RR.load(s, tf)
            except Exception:  # noqa: BLE001
                d = None
            if d is not None and len(d) > 600:
                d = d.reset_index(drop=True); I = B5.ind(d); extra(d, I); data.append((s, d, I))
        if not data:
            lines.append(f"\n=== {tf}: нет данных ==="); print(lines[-1], flush=True); continue
        t0 = min(int(d.t.iloc[0]) for _s, d, _I in data); mid = (t0 + now) // 2
        lines.append(f"\n=== {tf} · {len(data)} монет ===  сд · R/сд · всё · 1пол · 2пол · 180д · 90д · 30д · монет+")
        for nm, (en, ex) in STR.items():
            for tp_r, xl in ((None, "выход по обратному"), (2.0, "тейк 2R")):
                allt = []; pos = 0
                for _s, d, I in data:
                    tr = B5.sim(d, I, en, ex, 1.5, tp_r, 300); allt += tr; pos += sum(r for _t, r in tr) > 0
                if not allt:
                    continue
                w = lambda D: sum(r for t, r in allt if t >= now - D * 86400_000)  # noqa: E731
                h1 = sum(r for t, r in allt if t < mid); h2 = sum(r for t, r in allt if t >= mid)
                ok = h1 > 0 and h2 > 0 and w(180) > 0 and pos >= 8
                line = (f"{'✅' if ok else '❌'} {nm:<22} {xl:<19} {len(allt):6} · {w(99999) / len(allt):+.3f} · {w(99999):+6.0f} · {h1:+6.0f} · {h2:+6.0f} · "
                        f"{w(180):+5.0f} · {w(90):+5.0f} · {w(30):+4.0f} · {pos}/{len(data)}")
                print(line, flush=True); lines.append(line)
    (BASE / "bt_lab_bots" / "cf_strats_test.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("готово")


if __name__ == "__main__":
    main()
