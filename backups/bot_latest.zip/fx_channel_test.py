"""fx_channel_test.py — 2026-10-05. Тот же тест пробоя/отскока канала, но на традиционных рынках:
золото, серебро, нефть, газ, валюты, индексы (данные Yahoo Finance, публичные, без ключей).
4h — собрано из 1h за последние ~2 года (больше Yahoo не даёт); 1D — с 2005 года.
Комиссия/спред условно 0.03% (у CFD/фьючерсов меньше, чем у крипты). Итог: первая и вторая половина истории
отдельно (проверка вперёд), сколько инструментов в плюсе. Результат — fx_channel_test.csv.
"""
import csv, time
from pathlib import Path
import pandas as pd, requests
import channel_test as C

C.COST = 0.0003
BASE = Path(__file__).resolve().parent
SYMS = {"Золото": "GC=F", "Серебро": "SI=F", "Нефть WTI": "CL=F", "Нефть Brent": "BZ=F", "Газ": "NG=F", "Медь": "HG=F",
        "EURUSD": "EURUSD=X", "GBPUSD": "GBPUSD=X", "USDJPY": "JPY=X", "AUDUSD": "AUDUSD=X", "USDCAD": "CAD=X", "USDCHF": "CHF=X",
        "S&P500": "ES=F", "Nasdaq": "NQ=F", "Dow": "YM=F", "DAX": "^GDAXI"}


def yahoo(sym, interval, rng):
    """С повторами и кэшем на диске (market_cache/yahoo): Yahoo иногда рвёт соединение."""
    f = BASE / "market_cache" / "yahoo" / f"{sym.replace('=', '_').replace('^', '')}_{interval}.csv"
    f.parent.mkdir(parents=True, exist_ok=True)
    if f.exists() and time.time() - f.stat().st_mtime < 6 * 3600:
        return pd.read_csv(f)
    last = None
    for attempt in range(4):
        try:
            d = _yahoo_once(sym, interval, rng); d.to_csv(f, index=False); return d
        except Exception as exc:  # noqa: BLE001
            last = exc; print(f"  повтор {attempt + 1}/4…"); time.sleep(5 * (attempt + 1))
    if f.exists():
        print("  беру прошлую копию с диска"); return pd.read_csv(f)
    raise last


def _yahoo_once(sym, interval, rng):
    # range=max Yahoo отдаёт с огрублением (месячные точки) — для дневок просим явный период с 2005 г.
    p = {"interval": interval, "range": rng} if rng != "max" else {"interval": interval, "period1": 1104537600, "period2": int(time.time())}
    r = requests.get(f"https://query1.finance.yahoo.com/v8/finance/chart/{sym}", params=p,
                     headers={"User-Agent": "Mozilla/5.0"}, timeout=60).json()
    res = r["chart"]["result"][0]; q = res["indicators"]["quote"][0]
    d = pd.DataFrame({"t": [x * 1000 for x in res["timestamp"]], "o": q["open"], "h": q["high"], "l": q["low"], "c": q["close"], "v": q["volume"]})
    return d.dropna(subset=["o", "h", "l", "c"]).fillna({"v": 0}).reset_index(drop=True)


def to4h(d):
    d = d.copy(); d["dt"] = pd.to_datetime(d.t, unit="ms", utc=True)
    g = d.set_index("dt").resample("4h").agg({"t": "first", "o": "first", "h": "max", "l": "min", "c": "last", "v": "sum"}).dropna()
    return g.reset_index(drop=True)


if __name__ == "__main__":
    data = {}
    for name, s in SYMS.items():
        try:
            print("загрузка", name); data[(name, "4h")] = to4h(yahoo(s, "1h", "730d")); time.sleep(0.5)
            data[(name, "1D")] = yahoo(s, "1d", "max"); data[(name, "1D")] = data[(name, "1D")][data[(name, "1D")].t >= 1104537600000].reset_index(drop=True); time.sleep(0.5)
        except Exception as exc:  # noqa: BLE001
            print("  не загрузилось:", exc)
    rows = []
    for tf in ("4h", "1D"):
        for n in (53, 100):
            for kind, opt, vname in C.VARS:
                a = b = 0.0; nt = wins = plus = 0; per = {}
                for name in SYMS:
                    d = data.get((name, tf))
                    if d is None or len(d) < n + 50: continue
                    cut = d.t.iloc[len(d) // 2]
                    tr = C.run(d, n, kind, opt); rs = sum(r for _, r in tr); per[name] = rs; plus += rs > 0
                    for tt, r in tr:
                        nt += 1; wins += r > 0
                        if tt < cut: a += r
                        else: b += r
                row = {"tf": tf, "len": n, "вариант": vname, "сделок": nt, "WR%": round(100 * wins / max(1, nt), 1),
                       "R_1я_половина": round(a, 1), "R_2я_половина": round(b, 1), "в_плюсе": f"{plus}/{len(per)}", **{k: round(v, 1) for k, v in per.items()}}
                rows.append(row)
                print(f"{tf} канал {n:3} | {vname:28} | сделок {nt:5} WR {row['WR%']:5}% | 1-я пол. {a:+7.1f}R | 2-я пол. {b:+7.1f}R | в плюсе {plus}/{len(per)}")
    keys = list(dict.fromkeys(k for r in rows for k in r))
    with open(BASE / "fx_channel_test.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=keys, delimiter=";"); w.writeheader(); w.writerows(rows)
    print("\nГотово. Пришлите скрин или fx_channel_test.csv")
    input("Enter — закрыть")
