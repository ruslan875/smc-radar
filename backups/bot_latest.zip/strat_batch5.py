"""strat_batch5.py — 2026-10-29. Новая партия стратегий: что работает И за всю историю, И в последние месяцы.
12 монет (Binance Futures), ТФ 1h / 2h / 4h, комиссия+проскальзывание 0.11% за круг, вход по закрытию свечи.
Окна: вся история · 180 · 90 · 30 дней + число монет в плюсе. ✅ = плюс во всех окнах кроме 30 д и ≥ 8/12 монет.
Результат в R (риск = расстояние до стопа). Пишет bt_lab_bots/strat_batch5.txt
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import recheck_recent as RR  # noqa: E402

FEE = 0.0011


def ind(d):
    c, h, l = d.c, d.h, d.l
    tr = pd.concat([h - l, (h - c.shift()).abs(), (l - c.shift()).abs()], axis=1).max(axis=1)
    atr = tr.ewm(alpha=1 / 14, adjust=False).mean()
    def rsi(n):
        x = c.diff(); u = x.clip(lower=0).ewm(alpha=1 / n, adjust=False).mean(); w = (-x).clip(lower=0).ewm(alpha=1 / n, adjust=False).mean()
        return 100 - 100 / (1 + u / w.replace(0, 1e-12))
    sma20 = c.rolling(20).mean(); sd20 = c.rolling(20).std(ddof=0)
    ema20 = c.ewm(span=20, adjust=False).mean()
    return {"c": c.values, "h": h.values, "l": l.values, "o": d.o.values, "atr": atr.values, "rsi2": rsi(2).values, "rsi14": rsi(14).values,
            "sma5": c.rolling(5).mean().values, "sma200": c.rolling(200).mean().values, "ema50": c.ewm(span=50, adjust=False).mean().values,
            "ema200": c.ewm(span=200, adjust=False).mean().values, "bbm": sma20.values, "bbu": (sma20 + 2 * sd20).values, "bbl": (sma20 - 2 * sd20).values,
            "kcu": (ema20 + 1.5 * atr).values, "kcl": (ema20 - 1.5 * atr).values,
            "hh55": h.rolling(55).max().shift(1).values, "ll55": l.rolling(55).min().shift(1).values,
            "hh20": h.rolling(20).max().shift(1).values, "ll20": l.rolling(20).min().shift(1).values,
            "z50": ((c - c.rolling(50).mean()) / c.rolling(50).std(ddof=0)).values,
            "macd": (c.ewm(span=12, adjust=False).mean() - c.ewm(span=26, adjust=False).mean()).values}


def sim(d, I, entry, exit_fn, sl_atr, tp_r, hold):
    """entry(I,i) → side|0; exit_fn(I,i,side) → True закрыть по сигналу; стоп sl_atr·ATR, тейк tp_r·R (None — без тейка)."""
    c, h, l, a, t = I["c"], I["h"], I["l"], I["atr"], d.t.values
    out = []; i = 210; n = len(c)
    while i < n - 1:
        s = entry(I, i)
        if not s or not a[i] > 0:
            i += 1; continue
        e = c[i]; risk = sl_atr * a[i]; stp = e - s * risk; tp = e + s * tp_r * risk if tp_r else None; res = None
        for j in range(i + 1, min(n, i + hold + 1)):
            if (l[j] <= stp) if s > 0 else (h[j] >= stp):
                res = (j, -1.0); break
            if tp and ((h[j] >= tp) if s > 0 else (l[j] <= tp)):
                res = (j, tp_r); break
            if exit_fn and exit_fn(I, j, s):
                res = (j, s * (c[j] - e) / risk); break
        if res is None:
            j = min(n - 1, i + hold); res = (j, s * (c[j] - e) / risk)
        out.append((int(t[res[0]]), res[1] - FEE * e / risk)); i = res[0] + 1
    return out


# ---------------- стратегии ----------------
S = {}
S["RSI2 Коннорс (лонг выше SMA200)"] = (lambda I, i: 1 if I["c"][i] > I["sma200"][i] and I["rsi2"][i] < 10 else 0,
                                         lambda I, j, s: I["c"][j] > I["sma5"][j], 2.5, None, 30)
S["RSI2 Коннорс в обе стороны"] = (lambda I, i: 1 if I["c"][i] > I["sma200"][i] and I["rsi2"][i] < 10 else (-1 if I["c"][i] < I["sma200"][i] and I["rsi2"][i] > 90 else 0),
                                    lambda I, j, s: I["c"][j] > I["sma5"][j] if s > 0 else I["c"][j] < I["sma5"][j], 2.5, None, 30)
S["Боллинджер возврат к средней (+RSI14)"] = (
    lambda I, i: 1 if I["c"][i] < I["bbl"][i] and I["rsi14"][i] < 30 else (-1 if I["c"][i] > I["bbu"][i] and I["rsi14"][i] > 70 else 0),
    lambda I, j, s: I["c"][j] >= I["bbm"][j] if s > 0 else I["c"][j] <= I["bbm"][j], 2.0, None, 40)
S["Боллинджер возврат по тренду EMA200"] = (
    lambda I, i: 1 if I["c"][i] < I["bbl"][i] and I["c"][i] > I["ema200"][i] else (-1 if I["c"][i] > I["bbu"][i] and I["c"][i] < I["ema200"][i] else 0),
    lambda I, j, s: I["c"][j] >= I["bbm"][j] if s > 0 else I["c"][j] <= I["bbm"][j], 2.0, None, 40)
S["Z-score 50 < −2 → к средней"] = (lambda I, i: 1 if I["z50"][i] < -2 else (-1 if I["z50"][i] > 2 else 0),
                                    lambda I, j, s: I["z50"][j] >= 0 if s > 0 else I["z50"][j] <= 0, 2.5, None, 60)
S["Сжатие BB в KC → пробой, 2R"] = (
    lambda I, i: (1 if I["c"][i] > I["bbu"][i] else -1 if I["c"][i] < I["bbl"][i] else 0)
    if (I["bbu"][i - 1] < I["kcu"][i - 1] and I["bbl"][i - 1] > I["kcl"][i - 1]) else 0, None, 1.5, 2.0, 80)
S["Черепахи 55 / выход 20"] = (lambda I, i: 1 if I["c"][i] > I["hh55"][i] else (-1 if I["c"][i] < I["ll55"][i] else 0),
                               lambda I, j, s: I["c"][j] < I["ll20"][j] if s > 0 else I["c"][j] > I["hh20"][j], 2.0, None, 300)
S["Откат к EMA50 в тренде (RSI14<40), 2R"] = (
    lambda I, i: 1 if I["ema50"][i] > I["ema200"][i] and I["l"][i] <= I["ema50"][i] < I["c"][i] and I["rsi14"][i] < 45 else
    (-1 if I["ema50"][i] < I["ema200"][i] and I["h"][i] >= I["ema50"][i] > I["c"][i] and I["rsi14"][i] > 55 else 0), None, 1.5, 2.0, 80)
S["MACD через ноль по EMA200, 2R"] = (
    lambda I, i: 1 if I["macd"][i] > 0 >= I["macd"][i - 1] and I["c"][i] > I["ema200"][i] else (-1 if I["macd"][i] < 0 <= I["macd"][i - 1] and I["c"][i] < I["ema200"][i] else 0),
    None, 2.0, 2.0, 120)
S["Внутренний бар → пробой, 1.5R"] = (
    lambda I, i: (1 if I["c"][i] > I["h"][i - 1] else -1 if I["c"][i] < I["l"][i - 1] else 0)
    if (I["h"][i - 1] < I["h"][i - 2] and I["l"][i - 1] > I["l"][i - 2]) else 0, None, 1.0, 1.5, 40)


def main():
    import kvoo_longtest as K  # noqa: PLC0415
    now = int(time.time() * 1000); lines = []; best = []
    data = {}
    for tf in ("1h", "2h", "4h"):
        for s in K.COINS:
            try:
                d = RR.load(s, tf)
            except Exception:  # noqa: BLE001
                d = None
            if d is not None and len(d) > 600:
                data[(s, tf)] = (d, ind(d))
    for name, (en, ex, sl, tp, hold) in S.items():
        for tf in ("1h", "2h", "4h"):
            allt = []; pos = 0; n = 0
            for (s, t_), (d, I) in data.items():
                if t_ != tf:
                    continue
                tr = sim(d, I, en, ex, sl, tp, hold); allt += tr; n += 1; pos += sum(r for _t, r in tr) > 0
            w = {lab: sum(r for t, r in allt if t >= now - days * 86400_000) for lab, days in (("all", 99999), ("180", 180), ("90", 90), ("30", 30))}
            k = len(allt); avg = w["all"] / k if k else 0
            ok = w["all"] > 0 and w["180"] > 0 and w["90"] > 0 and pos >= 8 and k >= 100
            line = (f"{'✅' if ok else '❌'} {name:<40} {tf} · {k:>5} сд · {avg:+.3f}R/сд · всё {w['all']:+7.1f} · 180д {w['180']:+6.1f} · "
                    f"90д {w['90']:+6.1f} · 30д {w['30']:+6.1f} · монет {pos}/{n}")
            print(line, flush=True); lines.append(line)
            if ok:
                best.append((w["90"] + w["180"] / 2, line))
    lines.append("\nЛУЧШИЕ (по 90 д + 180 д/2):")
    lines += [l for _s, l in sorted(best, reverse=True)[:10]] or ["нет"]
    (BASE / "bt_lab_bots" / "strat_batch5.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines[-11:])); print("готово")


if __name__ == "__main__":
    main()
