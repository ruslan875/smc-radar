#!/usr/bin/env python3
"""
Запуск kc_roc_cci_wt_grid_backtest с визуализацией и диагностикой фильтров.

Все параметры стратегии и их значения по умолчанию синхронизированы с
main() из kc_roc_cci_wt_grid_backtest.py (сверено 2026-09-19). Менять их
здесь без сверки с оригиналом нельзя: расхождение в одном пороге (например
--atr-min) молча обнуляет количество сделок.

Примеры:
    python run_grid_backtest_viz.py --symbol BTCUSDT --bars 20000
    python run_grid_backtest_viz.py --symbol ETHUSDT SOLUSDT --bars 50000
    python run_grid_backtest_viz.py --symbol BTCUSDT --bars 20000 --diagnose
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import pandas as pd

from kc_roc_cci_wt_grid_backtest import (
    fetch_history, build_params, simulate_symbol, summarize, save_csv, Params,
)
from app.config import Settings
from app.data import DataError
from app.indicators.common import cci
from app.indicators.veles_style import (
    rate_of_change, keltner_channel, atr_percent, htf_closed_series,
)
from kc_roc_grid_visualizer import visualize_grid_backtest, plot_deals_closeup


# ----------------------------------------------------------- диагностика --

def diagnose_filters(df: pd.DataFrame, p: Params) -> None:
    """
    Показывает, какая доля баров проходит каждый фильтр входа по отдельности
    и все вместе. Нужно, чтобы при нуле сделок сразу видеть, какое именно
    условие режет вход, а не гадать.
    """
    _, _, kc_lower = keltner_channel(df, length=p.kc_length, mult=p.kc_mult,
                                     use_true_range=True)
    roc = rate_of_change(df["close"], p.roc_length)
    atr_htf = htf_closed_series(
        df, p.htf1_minutes, lambda h: atr_percent(h, length=p.atr_length)
    )
    cci_htf = htf_closed_series(
        df, p.htf2_minutes,
        lambda h: cci((h["high"] + h["low"] + h["close"]) / 3, p.cci_length),
    )

    conds = {
        f"KC   close <= lower (len={p.kc_length}, mult={p.kc_mult})": df["close"] <= kc_lower,
        f"ROC  roc({p.roc_length}) <= {p.roc_threshold}": roc <= p.roc_threshold,
        f"ATR  atr%({p.htf1_minutes}m) in [{p.atr_min}, {p.atr_max}]": atr_htf.between(p.atr_min, p.atr_max),
        f"CCI  cci({p.htf2_minutes}m) <= {p.cci_threshold}": cci_htf <= p.cci_threshold,
    }

    n = len(df)
    print("\n   Фильтры входа (сколько баров прошло):")
    combined = None
    for name, cond in conds.items():
        cond = cond.fillna(False)
        print(f"     {int(cond.sum()):6d}/{n}  {cond.sum() / n * 100:5.1f}%   {name}")
        combined = cond if combined is None else (combined & cond)

    print(f"     {int(combined.sum()):6d}/{n}  {combined.sum() / n * 100:5.1f}%   >>> ВСЕ ВМЕСТЕ")

    edges = combined & ~combined.shift(1).fillna(False)
    print(f"     {int(edges.sum()):6d}          сигналов входа (по фронту)")

    print("\n   Фактические диапазоны индикаторов:")
    series = (
        ("ROC", roc),
        (f"ATR%({p.htf1_minutes}m)", atr_htf),
        (f"CCI({p.htf2_minutes}m)", cci_htf),
    )
    for label, s in series:
        s = s.dropna()
        if len(s):
            print(f"     {label:14s} min={s.min():9.3f}  p5={s.quantile(0.05):9.3f}  "
                  f"med={s.median():9.3f}  max={s.max():9.3f}")


# ------------------------------------------------------------------ main --

def main() -> None:
    parser = argparse.ArgumentParser(description="Grid backtest + визуализация")

    parser.add_argument("--symbol", nargs="+", default=None)
    parser.add_argument("--timeframe", default="1m")
    parser.add_argument("--bars", type=int, default=20000)
    parser.add_argument("--out", default="kc_roc_cci_wt_grid_backtest_out")

    # --- параметры стратегии: 1:1 с main() оригинала ---
    parser.add_argument("--grid-offsets", default="0,3")
    parser.add_argument("--grid-volumes", default="65,35")

    parser.add_argument("--kc-length", type=int, default=20)
    parser.add_argument("--kc-mult", type=float, default=2.0)
    parser.add_argument("--roc-length", type=int, default=14)
    parser.add_argument("--roc-threshold", type=float, default=-1.0)

    parser.add_argument("--htf1", type=int, default=15)
    parser.add_argument("--atr-length", type=int, default=14)
    parser.add_argument("--atr-min", type=float, default=0.05)
    parser.add_argument("--atr-max", type=float, default=5.0)

    parser.add_argument("--htf2", type=int, default=30)
    parser.add_argument("--cci-length", type=int, default=20)
    parser.add_argument("--cci-threshold", type=float, default=-100.0)

    parser.add_argument("--wt-n1", type=int, default=10)
    parser.add_argument("--wt-n2", type=int, default=21)
    parser.add_argument("--wt-avg-len", type=int, default=4)

    parser.add_argument("--tp-min-pnl-pct", type=float, default=0.5)
    parser.add_argument("--stop-loss-pct", type=float, default=4.0)
    parser.add_argument("--max-deal-bars", type=int, default=20000)

    # --- визуализация ---
    parser.add_argument("--no-viz", action="store_true", help="не строить графики")
    parser.add_argument("--viz-dir", default="kc_roc_cci_wt_grid_backtest_out",
                        help="куда сохранять PNG")
    parser.add_argument("--viz-max-bars", type=int, default=1500,
                        help="ширина окна графика в барах")
    parser.add_argument("--capital-per-deal", type=float, default=20.0,
                        help="капитал на сделку, USDT (для пересчёта P&% в USDT)")
    parser.add_argument("--diagnose", action="store_true",
                        help="показать статистику по фильтрам входа")
    parser.add_argument("--no-closeup", action="store_true",
                        help="не строить крупный план каждой сделки")
    parser.add_argument("--closeup-max", type=int, default=12,
                        help="сколько сделок показать крупным планом")

    args = parser.parse_args()

    symbols = args.symbol
    if not symbols:
        symbols = Settings.load().watchlist
    symbols = [s.upper() for s in symbols]

    params = build_params(args)
    out_dir = Path(args.out)
    viz_dir = Path(args.viz_dir)

    print("\n" + "=" * 70)
    print("KC_ROC_CCI_WT GRID BACKTEST + VISUALIZATION")
    print("=" * 70)
    print(f"Символы:      {', '.join(symbols)}")
    print(f"Баров:        {args.bars} × {args.timeframe}")
    print(f"Сетка:        offsets={args.grid_offsets}  volumes={args.grid_volumes}")
    print(f"Стоп:         -{args.stop_loss_pct}%   TP min P&L: {args.tp_min_pnl_pct}%")
    print(f"Фильтры:      KC({args.kc_length}, {args.kc_mult})  ROC({args.roc_length})<={args.roc_threshold}  "
          f"ATR%[{args.atr_min},{args.atr_max}]  CCI<={args.cci_threshold}")
    print("=" * 70)

    all_deals: list = []

    for symbol in symbols:
        print(f"\n>>> {symbol}")
        try:
            df = fetch_history(symbol, args.timeframe, args.bars)
        except DataError as exc:
            print(f"   [SKIP] {exc}")
            continue

        if args.diagnose:
            diagnose_filters(df, params)

        deals = simulate_symbol(df, symbol, params)
        print(f"\n   Сделок найдено: {len(deals)}")

        summarize(deals, f"   ИТОГ {symbol}")
        save_csv(deals, out_dir / f"{symbol}_deals.csv")
        all_deals.extend(deals)

        if deals and not args.no_viz:
            visualize_grid_backtest(
                df, deals,
                symbol=symbol,
                timeframe=args.timeframe,
                output_path=str(viz_dir / f"{symbol}_{args.timeframe}.png"),
                stop_loss_pct=args.stop_loss_pct,
                capital_per_deal=args.capital_per_deal,
                max_bars=args.viz_max_bars,
            )
            if not args.no_closeup:
                plot_deals_closeup(
                    df, deals, params.grid,
                    symbol=symbol,
                    timeframe=args.timeframe,
                    output_path=str(viz_dir / f"{symbol}_{args.timeframe}_deals.png"),
                    stop_loss_pct=args.stop_loss_pct,
                    max_deals=args.closeup_max,
                )
        elif not deals and not args.diagnose:
            print("   Подсказка: запустите с --diagnose, чтобы увидеть, "
                  "какой фильтр не пропускает входы")

    if len(symbols) > 1:
        summarize(all_deals, "=== ВСЕ СИМВОЛЫ ===")

    print(f"\nCSV: {out_dir.resolve()}")
    if not args.no_viz:
        print(f"PNG: {viz_dir.resolve()}")
    print()


if __name__ == "__main__":
    main()
