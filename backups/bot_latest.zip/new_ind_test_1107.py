import pandas as pd,numpy as np,glob,os
D='/mnt/user-data/uploads/VANTORIX/bot/market_cache_tf/'
def ld(f):
    d=pd.read_csv(f);d['t']=pd.to_datetime(d.t,unit='ms');return d.set_index('t')
def rma(x,n): return x.ewm(alpha=1/n,adjust=False).mean()
def atr(d,n=14):
    tr=pd.concat([d.h-d.l,(d.h-d.c.shift()).abs(),(d.l-d.c.shift()).abs()],axis=1).max(axis=1);return rma(tr,n)
def rsi(c,n=14):
    g=c.diff().clip(lower=0);l=-c.diff().clip(upper=0);return 100-100/(1+rma(g,n)/rma(l,n))
b=ld(D+'BTCUSDT_4h.csv');BT=np.sign(b.c.ewm(span=50).mean()-b.c.ewm(span=200).mean())
def env(d):
    bs=rma(d.c,100);a=atr(d,100);u=bs+3*a;l=bs-3*a;t=np.zeros(len(d));c=d.c.values;uu=u.values;ll=l.values
    for i in range(1,len(d)):
        t[i]=t[i-1]
        if c[i]>uu[i] and c[i-1]<=uu[i-1]: t[i]=1
        elif c[i]<ll[i] and c[i-1]>=ll[i-1]: t[i]=-1
    t=pd.Series(t,d.index)
    f618=np.where(t==1,l+(u-l)*0.382,u-(u-l)*0.382);f786=np.where(t==1,l+(u-l)*0.214,u-(u-l)*0.214)
    pk=(d.c<=np.maximum(f618,f786))&(d.c>=np.minimum(f618,f786))
    return t,pk
def run(d,sig,stop,tp,exitf,maxbars=10**9):
    """sig: +1/-1 array; stop/tp arrays of prices at signal bar; exitf(i,pos)->bool on close"""
    c=d.c.values;h=d.h.values;l=d.l.values;out=[];pos=0
    for i in range(210,len(d)):
        if pos:
            ex=None
            if (pos==1 and l[i]<=sl) or (pos==-1 and h[i]>=sl): ex=sl
            elif tpp==tpp and ((pos==1 and h[i]>=tpp) or (pos==-1 and l[i]<=tpp)): ex=tpp
            elif exitf(i,pos) or i-ei>=maxbars: ex=c[i]
            if ex is not None:
                out.append((d.index[ei],pos,(ex-en)*pos/rk-0.0011*en/rk));pos=0
            continue
        s=sig[i]
        if s and stop[i]==stop[i]:
            en=c[i];sl=stop[i];rk=abs(en-sl)
            if rk<=0 or rk/en<0.002 or (sl-en)*s>=0: continue
            pos=s;tpp=tp[i];ei=i
    return out
rows=[]
for f in sorted(glob.glob(D+'*_4h.csv')):
    sym=os.path.basename(f)[:-7];d=ld(f);c=d.c;A=atr(d);a=A.values;cv=c.values
    t,pk=env(d);tv=t.values;r=rsi(c);rv=r.values;nan=np.full(len(d),np.nan)
    up=(r.shift()<30)&(r>=30);dn=(r.shift()>70)&(r<=70)
    rx=lambda i,p:(p==1 and rv[i-1]>50 and rv[i]<=50) or (p==-1 and rv[i-1]<50 and rv[i]>=50)
    # 1a RSI trend-only
    s=np.where(up&(t==1),1,np.where(dn&(t==-1),-1,0));st=cv-s*2*a
    for k,v in [('ATRfib RSI тренд',s),('ATRfib RSI тренд+покет',np.where(pk,s,0)),('RSI без фильтра',np.where(up,1,np.where(dn,-1,0)))]:
        rows+=[(k,sym)+x for x in run(d,v,cv-v*2*a,nan,rx)]
    # 1b envelope trend flip (trend following)
    fl=np.where((t!=t.shift())&(t!=0),t,0)
    rows+=[('ATRfib смена тренда',sym)+x for x in run(d,fl,cv-fl*3*a,nan,lambda i,p:tv[i]!=p)]
    # 1c pullback into golden pocket in trend (first touch) -> enter, stop 2ATR, exit trend flip
    pkf=(pk&~pk.shift(fill_value=False)).values;s2=np.where(pkf,tv,0)
    rows+=[('ATRfib откат в покет',sym)+x for x in run(d,s2,cv-s2*2*a,nan,lambda i,p:tv[i]!=p)]
    # 2 LSMR
    bs=c.rolling(20).mean();sd=c.rolling(20).std();U=bs+2*sd;L=bs-2*sd;tr=d.h-d.l
    uw=(d.h-d[['o','c']].max(axis=1))/tr.replace(0,np.nan);lw=(d[['o','c']].min(axis=1)-d.l)/tr.replace(0,np.nan)
    rv_=d.v/d.v.rolling(20).mean()
    usw=((d.h>U.shift())&(c<U.shift())&(uw>=0.55)&(rv_>=1.3)).values;lsw=((d.l<L.shift())&(c>L.shift())&(lw>=0.55)&(rv_>=1.3)).values
    Uv,Lv,hv,lv=U.values,L.values,d.h.values,d.l.values;bsv=bs.values
    sig=np.zeros(len(d));sl=nan.copy();tpm=nan.copy();tp15=nan.copy()
    bu=bl=999;shl=sll=np.nan;lastb=lasts=-99
    for i in range(1,len(d)):
        if usw[i]: shl=hv[i];bu=0
        else: bu+=1
        if lsw[i]: sll=lv[i];bl=0
        else: bl+=1
        if 0<bl<=4 and cv[i]>Lv[i] and (cv[i-1]<=Lv[i-1] or lv[i-1]<Lv[i-1]) and i-lastb>=6:
            sig[i]=1;lastb=i;sl[i]=sll-0.15*a[i];tpm[i]=bsv[i];tp15[i]=cv[i]+1.5*(cv[i]-sl[i])
        elif 0<bu<=4 and cv[i]<Uv[i] and (cv[i-1]>=Uv[i-1] or hv[i-1]>Uv[i-1]) and i-lasts>=6:
            sig[i]=-1;lasts=i;sl[i]=shl+0.15*a[i];tpm[i]=bsv[i];tp15[i]=cv[i]-1.5*(sl[i]-cv[i])
    no=lambda i,p:False
    rows+=[('LSMR цель=средняя',sym)+x for x in run(d,sig,sl,tpm,no,25)]
    rows+=[('LSMR цель=1.5R',sym)+x for x in run(d,sig,sl,tp15,no,25)]
    # 3 BOS (swing 20)
    n=20;ph=d.h.rolling(2*n+1,center=True).max();pl=d.l.rolling(2*n+1,center=True).min()
    phv=np.where(d.h.values==ph.values,d.h.values,np.nan);plv=np.where(d.l.values==pl.values,d.l.values,np.nan)
    bos=np.zeros(len(d));ph_=pl_=np.nan;ha=la=False;last=0;bdir=np.zeros(len(d))
    for i in range(2*n,len(d)):
        j=i-n
        if phv[j]==phv[j]: ph_=phv[j];ha=True
        if plv[j]==plv[j]: pl_=plv[j];la=True
        if ha and cv[i]>ph_: bos[i]=1;ha=False;last=1
        elif la and cv[i]<pl_: bos[i]=-1;la=False;last=-1
        bdir[i]=last
    rows+=[('BOS структура',sym)+x for x in run(d,bos,cv-bos*2*a,nan,lambda i,p:bos[i]==-p)]
T=pd.DataFrame(rows,columns=['st','sym','t','side','r']);T['bt']=BT.reindex(T.t).values
def dd(r): c=r.cumsum();return (c-c.cummax()).min()
print(f"{'стратегия':26}{'сд':>6}{'R/сд':>7}{'всего':>7}{'просад':>7}{'%приб':>6}{'до23':>7}{'23+':>7}{'25+':>7}{'по BTC':>8}")
for k,x in T.groupby('st',sort=False):
    a_=x[x.t<'2023'];b_=x[x.t>='2023'];c_=x[x.t>='2025'];f=x[x.side==x.bt]
    print(f"{k:26}{len(x):6}{x.r.mean():7.3f}{x.r.sum():7.0f}{dd(x.r.values if False else x.sort_values('t').r):7.0f}{(x.r>0).mean()*100:6.0f}{a_.r.mean():7.3f}{b_.r.mean():7.3f}{c_.r.mean():7.3f}{f.r.mean():8.3f}")
T.to_csv('/home/claude/rg/ind_trades.csv',index=False)
