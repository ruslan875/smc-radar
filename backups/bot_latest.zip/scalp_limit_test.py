"""scalp_limit_test.py — 2026-10-14. Скальпинг ТОЛЬКО ЛИМИТКАМИ: крипта и TradFi (XAU/XAG/нефть), 1m / 5m (+15m для проверки).

Почему лимитки: вход и тейк мейкером дешевле в 3 раза (крипта: мейкер 0.0324%, тейкер 0.09%;
TradFi: мейкер 0%, тейкер 0.02475%). Стоп и выход по времени — рынком (тейкер).

ЧЕСТНАЯ модель исполнения лимитки:
  * заявка ставится по закрытию свечи i и живёт 3 следующие свечи, потом снимается;
  * исполнена, только если цена ПРОШЛА сквозь неё (low < цена − 0.01%), касание не считается (очередь);
  * на свече исполнения тейк не засчитывается, а если там же задет стоп — считаем стоп (худший случай);
  * дальше на каждой свече сначала проверяется стоп, потом тейк (тоже сквозь цену); лимит удержания 60 свечей.

Стратегии (все — возврат к среднему или забор ликвидности, под них и нужны лимитки):
  A  BB-фейд:            лимит на SMA20 ∓ k·σ, тейк на SMA20, стоп s·ATR за лимитом
  B  Отклонение от EMA:  лимит на EMA20 ∓ k·ATR, тейк на EMA20
  C  Снятие экстремума:  лимит чуть за минимумом/максимумом N свечей, тейк r·ATR
  D  Откат по тренду:    EMA50 > EMA200 → лимит-лонг на EMA20 (шорт зеркально), тейк r·ATR
  E  Маркет-мейкинг:     лимиты с двух сторон close ± k·ATR, тейк на close сигнальной свечи
У каждой 4–8 вариантов параметров. ПОДБОР — только на 1-й половине истории, ЭКЗАМЕН — на 2-й.
✅ — на экзамене средний результат > 0, ≥ 60% инструментов в плюсе, и 1-я половина тоже > 0.
Настоящий результат — тот, что держится на 2–3 таймфреймах. Ничего не торгует.
Запуск: scalp_limit_test.bat → bt_lab_bots/scalp_limit_test.txt
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np
import requests

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
OUT = BASE / "bt_lab_bots" / "scalp_limit_test.txt"
CRYPTO = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT", "DOGEUSDT", "ADAUSDT", "SUIUSDT", "LINKUSDT", "AVAXUSDT",
          "BNBUSDT", "NEARUSDT", "HYPEUSDT"]
TRADFI_WANT = ("XAU", "XAG", "CL", "WTI", "BRENT", "OIL", "UKOIL", "USOIL")
FEES = {"крипта": (0.000324, 0.0009), "TradFi": (0.0, 0.0002475)}
TFS = [("1", "1m", 30000), ("5", "5m", 30000), ("15", "15m", 25000)]
VALID, HOLD, THRU = 3, 60, 0.0001
LINES = []


def say(s=""):
    print(s, flush=True)
    LINES.append(s)


# ---------------- данные ----------------
def tradfi_symbols():
    out, cur = [], ""
    while True:
        r = requests.get("https://api.bybit.com/v5/market/instruments-info",
                         params={"category": "linear", "limit": 1000, "cursor": cur}, timeout=20).json()["result"]
        for x in r["list"]:
            s = x["symbol"]
            if s.endswith("USDT") and s[:-4] in TRADFI_WANT and x.get("status") == "Trading":
                out.append(s)
        cur = r.get("nextPageCursor") or ""
        if not cur:
            return sorted(set(out))


def klines(sym, interval, total):
    rows, end = [], None
    while len(rows) < total:
        p = {"category": "linear", "symbol": sym, "interval": interval, "limit": 1000}
        if end:
            p["end"] = end
        j = None
        for k in range(4):
            try:
                j = requests.get("https://api.bybit.com/v5/market/kline", params=p, timeout=20).json(); break
            except requests.RequestException:
                time.sleep(2 * (k + 1))
        lst = (j or {}).get("result", {}).get("list") or []
        if not lst:
            break
        rows += lst; end = int(lst[-1][0]) - 1
        if len(lst) < 1000:
            break
        time.sleep(0.12)
    rows = sorted({int(r[0]): r for r in rows}.values(), key=lambda r: int(r[0]))[:-1]   # последняя — не закрыта
    if len(rows) < 2000:
        return None
    a = np.array([[float(x) for x in r[:6]] for r in rows])
    return {"t": a[:, 0], "o": a[:, 1], "h": a[:, 2], "l": a[:, 3], "c": a[:, 4], "v": a[:, 5]}


# ---------------- индикаторы ----------------
def ema(x, n):
    out = np.empty_like(x); k = 2 / (n + 1); out[0] = x[0]
    for i in range(1, len(x)):
        out[i] = out[i - 1] + k * (x[i] - out[i - 1])
    return out


def sma(x, n):
    c = np.cumsum(np.r_[0.0, x]); out = np.full(len(x), np.nan)
    out[n - 1:] = (c[n:] - c[:-n]) / n
    return out


def std(x, n):
    m = sma(x, n); m2 = sma(x * x, n)
    return np.sqrt(np.maximum(m2 - m * m, 0))


def atr(d, n=14):
    pc = np.r_[d["c"][0], d["c"][:-1]]
    tr = np.maximum(d["h"] - d["l"], np.maximum(abs(d["h"] - pc), abs(d["l"] - pc)))
    out = np.empty_like(tr); out[0] = tr[0]
    for i in range(1, len(tr)):
        out[i] = out[i - 1] + (tr[i] - out[i - 1]) / n
    return out


def rollmin(x, n):
    from numpy.lib.stride_tricks import sliding_window_view as sw  # noqa: PLC0415
    out = np.full(len(x), np.nan); out[n - 1:] = sw(x, n).min(axis=1); return out


def rollmax(x, n):
    from numpy.lib.stride_tricks import sliding_window_view as sw  # noqa: PLC0415
    out = np.full(len(x), np.nan); out[n - 1:] = sw(x, n).max(axis=1); return out


def feats(d):
    c = d["c"]
    return {"a": atr(d), "m20": sma(c, 20), "sd20": std(c, 20), "e20": ema(c, 20), "e50": ema(c, 50), "e200": ema(c, 200)}


# ---------------- стратегии: массивы заявок, посчитанные на закрытии свечи i ----------------
NAN = np.nan


def strat_A(d, F, k, s):
    m, sd, a = F["m20"], F["sd20"], F["a"]
    ll = m - k * sd; sl_ = m + k * sd
    return (ll, m, ll - s * a), (sl_, m, sl_ + s * a)


def strat_B(d, F, k, s):
    e, a = F["e20"], F["a"]
    ll = e - k * a; sl_ = e + k * a
    return (ll, e, ll - s * a), (sl_, e, sl_ + s * a)


def strat_C(d, F, n, r):
    a = F["a"]
    lo = rollmin(d["l"], n) - 0.1 * a; hi = rollmax(d["h"], n) + 0.1 * a
    return (lo, lo + r * a, lo - 1.0 * a), (hi, hi - r * a, hi + 1.0 * a)


def strat_D(d, F, r, s):
    e, a = F["e20"], F["a"]
    up = F["e50"] > F["e200"]
    ll = np.where(up & (d["c"] > e), e, NAN); sl_ = np.where(~up & (d["c"] < e), e, NAN)
    return (ll, ll + r * a, ll - s * a), (sl_, sl_ - r * a, sl_ + s * a)


def strat_E(d, F, k, s):
    c, a = d["c"], F["a"]
    ll = c - k * a; sl_ = c + k * a
    return (ll, c, ll - s * a), (sl_, c, sl_ + s * a)


STRATS = {
    "A BB-фейд":           (strat_A, [(k, s) for k in (2.0, 2.5, 3.0) for s in (1.0, 2.0)], "k σ={}, стоп {} ATR"),
    "B Отклонение от EMA": (strat_B, [(k, s) for k in (1.5, 2.5, 3.5) for s in (1.0, 2.0)], "k={} ATR, стоп {} ATR"),
    "C Снятие экстремума": (strat_C, [(n, r) for n in (20, 60) for r in (0.7, 1.5)], "N={}, тейк {} ATR"),
    "D Откат по тренду":   (strat_D, [(r, s) for r in (0.5, 1.0, 1.5) for s in (1.0, 2.0)], "тейк {} ATR, стоп {} ATR"),
    "E Маркет-мейкинг":    (strat_E, [(k, s) for k in (0.5, 1.0) for s in (1.5, 3.0)], "k={} ATR, стоп {} ATR"),
}


# ---------------- симуляция ----------------
def sim(d, L, S, fees, lo, hi):
    """Возвращает (сумма доли, сделок). Одна позиция за раз. L/S = (лимит, тейк, стоп) массивы."""
    mk, tk = fees
    h, l, c = d["h"], d["l"], d["c"]
    tot, n, i = 0.0, 0, max(lo, 210)
    while i < hi - 1:
        best = None
        for side, (lp, tp, sp) in ((1, L), (-1, S)):
            px = lp[i]
            if not px == px or not tp[i] == tp[i] or not sp[i] == sp[i]:
                continue
            if side > 0 and not (sp[i] < px < tp[i]):
                continue
            if side < 0 and not (tp[i] < px < sp[i]):
                continue
            if (side > 0 and c[i] <= px) or (side < 0 and c[i] >= px):
                continue                                 # лимит должен быть «за» ценой
            for j in range(i + 1, min(hi, i + 1 + VALID)):
                if (l[j] < px * (1 - THRU)) if side > 0 else (h[j] > px * (1 + THRU)):
                    if best is None or j < best[0]:
                        best = (j, side, px, tp[i], sp[i])
                    break
        if best is None:
            i += 1; continue
        j, side, e, tp, sp = best
        ex, fee_out, k = None, tk, j
        if (l[j] <= sp) if side > 0 else (h[j] >= sp):
            ex = sp
        else:
            for k in range(j + 1, min(hi, j + 1 + HOLD)):
                if (l[k] <= sp) if side > 0 else (h[k] >= sp):
                    ex = sp; break
                if (h[k] > tp * (1 + THRU)) if side > 0 else (l[k] < tp * (1 - THRU)):
                    ex = tp; fee_out = mk; break
            if ex is None:
                k = min(hi - 1, j + HOLD); ex = c[k]
        tot += side * (ex / e - 1) - mk - fee_out; n += 1
        i = k + 1
    return tot, n


# ---------------- главное ----------------
def main():
    t0 = time.time()
    say(f"Лимитный скальпинг — крипта и TradFi · {time.strftime('%Y-%m-%d %H:%M')}")
    say("Вход и тейк — лимитки (мейкер), стоп и выход по времени — рынок. Лимитка исполняется только «сквозь» цену.")
    say("Подбор параметров — 1-я половина, экзамен — 2-я. Результат: средний % на инструмент (сумма сделок).")
    try:
        tf_syms = tradfi_symbols()
    except Exception as exc:  # noqa: BLE001
        tf_syms = []; say(f"TradFi: не нашёл символы ({exc})")
    say(f"TradFi на Bybit: {', '.join(tf_syms) or 'нет'}")
    groups = [("крипта", CRYPTO), ("TradFi", tf_syms)]
    passed = {}
    for code, tf, nb in TFS:
        for gname, syms in groups:
            if not syms:
                continue
            data = {}
            for s in syms:
                try:
                    d = klines(s, code, nb)
                except Exception:  # noqa: BLE001
                    d = None
                if d is not None:
                    data[s] = (d, feats(d))
            if len(data) < (2 if gname == "TradFi" else 6):
                say(f"\n=== {tf} · {gname}: мало данных ==="); continue
            days = np.median([(d["t"][-1] - d["t"][0]) / 86400000 for d, _ in data.values()])
            say(""); say(f"=== {tf} · {gname} · {len(data)} инстр. · ~{days:.0f} дней · комиссии мейкер {FEES[gname][0]*100:.4f}% / тейкер {FEES[gname][1]*100:.4f}% ===")
            for name, (fn, grid, fmt) in STRATS.items():
                rows = []
                for prm in grid:
                    r1, r2, n1, n2 = [], [], 0, 0
                    for s, (d, F) in data.items():
                        L, S = fn(d, F, *prm)
                        m = len(d["c"]) // 2
                        a, na = sim(d, L, S, FEES[gname], 0, m)
                        b, nb2 = sim(d, L, S, FEES[gname], m, len(d["c"]))
                        r1.append(a); r2.append(b); n1 += na; n2 += nb2
                    rows.append((prm, np.mean(r1) * 100, np.mean(r2) * 100, sum(x > 0 for x in r2), len(r2), n1, n2))
                ok_rows = [r for r in rows if r[5] >= 20] or rows
                best = max(ok_rows, key=lambda r: r[1])
                prm, a1, a2, pos, cnt, n1, n2 = best
                ok = a1 > 0 and a2 > 0 and pos >= 0.6 * cnt
                per = a2 / max(1, n2 / cnt)
                say(f"  {name:<22} лучшее ({fmt.format(*prm)}): 1-я {a1:+7.2f}% · экзамен {a2:+7.2f}% · в плюсе {pos}/{cnt}"
                    f" · сделок {n1}+{n2} · на сделку {per:+.3f}%  {'✅' if ok else '❌'}")
                if ok:
                    passed.setdefault((name, gname), []).append(f"{tf} ({fmt.format(*prm)}, экзамен {a2:+.1f}%)")
            say(f"  ({time.time() - t0:.0f} с)")
    say(""); say("ИТОГ — прошедшие экзамен (стратегия · рынок → таймфреймы):")
    if not passed:
        say("  ни одной: лимитный скальпинг на этих правилах после честной модели исполнения не зарабатывает")
    for (name, g), lst in sorted(passed.items(), key=lambda x: -len(x[1])):
        say(f"  {'★ ' if len(lst) >= 2 else '  '}{name} · {g}: " + "; ".join(lst))
    say("★ — прошла на 2+ таймфреймах: кандидат на бумажного бота. Одиночный ✅ скорее случайность.")
    OUT.parent.mkdir(exist_ok=True)
    OUT.write_text("\n".join(LINES), encoding="utf-8")
    print(f"\nОтчёт: {OUT}")


if __name__ == "__main__":
    main()
