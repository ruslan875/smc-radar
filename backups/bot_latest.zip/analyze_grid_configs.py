#!/usr/bin/env python3
"""
Analyze grid configuration backtest results and compare performance.

Reads CSV files from different backtest outputs and generates a summary
comparing average P&L, win rate, stop loss rate, and other metrics.
"""
import pandas as pd
import os
from pathlib import Path

configs = {
    "BASELINE (0,3 / 65,35 / -4%)": "backtest_out",
    "NO_AVG (0 / 100 / -4%)": "backtest_out_no_avg",
    "WIDER_AVG (0,5 / 65,35 / -4%)": "backtest_out_wider_avg",
    "REDUCED_2ND (0,3 / 80,20 / -4%)": "backtest_out_reduced_2nd",
    "WIDER_STOP (0,3 / 65,35 / -6%)": "backtest_out_wider_stop",
    "COMBINED (0,5 / 80,20 / -4%)": "backtest_out_combined",
    "AGGRESSIVE (0,5 / 65,35 / -6%)": "backtest_out_aggressive",
}

symbols = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "ARBUSDT", "INJUSDT", "HYPEUSDT"]

print("\n" + "=" * 100)
print("GRID CONFIGURATION BACKTEST ANALYSIS")
print("=" * 100)
print()

results = {}

for config_name, output_dir in configs.items():
    print(f"\n{config_name}")
    print("-" * 100)

    config_results = {
        "total_deals": 0,
        "total_pnl": 0.0,
        "winning_deals": 0,
        "stop_losses": 0,
        "avg_pnl_pct": 0.0,
        "win_rate": 0.0,
        "stop_rate": 0.0,
    }

    for symbol in symbols:
        csv_path = Path(output_dir) / f"{symbol}_deals.csv"

        if not csv_path.exists():
            print(f"  {symbol}: NO DATA")
            continue

        try:
            df = pd.read_csv(csv_path)

            if len(df) == 0:
                print(f"  {symbol}: 0 deals")
                continue

            # Count metrics
            n_deals = len(df)
            n_wins = len(df[df["gross_pnl_pct"] > 0])
            n_stops = len(df[df["reason"] == "stop_loss"])
            avg_pnl = df["gross_pnl_pct"].mean()

            # Accumulate for config totals
            config_results["total_deals"] += n_deals
            config_results["total_pnl"] += df["gross_pnl_pct"].sum()
            config_results["winning_deals"] += n_wins
            config_results["stop_losses"] += n_stops

            win_rate = (n_wins / n_deals * 100) if n_deals > 0 else 0
            stop_rate = (n_stops / n_deals * 100) if n_deals > 0 else 0

            print(f"  {symbol:10s}: {n_deals:3d} deals  |  "
                  f"avg P&L: {avg_pnl:+6.2f}%  |  "
                  f"win rate: {win_rate:5.1f}%  |  "
                  f"stops: {n_stops:2d} ({stop_rate:5.1f}%)")

        except Exception as e:
            print(f"  {symbol}: ERROR - {e}")

    # Calculate config averages
    if config_results["total_deals"] > 0:
        config_results["avg_pnl_pct"] = config_results["total_pnl"] / config_results["total_deals"]
        config_results["win_rate"] = (config_results["winning_deals"] / config_results["total_deals"] * 100)
        config_results["stop_rate"] = (config_results["stop_losses"] / config_results["total_deals"] * 100)

        print(f"\n  TOTAL:      {config_results['total_deals']:3d} deals  |  "
              f"avg P&L: {config_results['avg_pnl_pct']:+6.2f}%  |  "
              f"win rate: {config_results['win_rate']:5.1f}%  |  "
              f"stops: {config_results['stop_losses']:2d} ({config_results['stop_rate']:5.1f}%)")

    results[config_name] = config_results

# Summary comparison
print("\n" + "=" * 100)
print("SUMMARY COMPARISON (ranked by avg P&L)")
print("=" * 100)
print()

sorted_results = sorted(results.items(), key=lambda x: x[1]["avg_pnl_pct"], reverse=True)

print(f"{'Config':<40} {'Deals':>6} {'Avg P&L':>10} {'Win Rate':>10} {'Stop Rate':>10}")
print("-" * 100)

best_pnl = sorted_results[0][1]["avg_pnl_pct"] if sorted_results else 0

for config_name, metrics in sorted_results:
    if metrics["total_deals"] == 0:
        print(f"{config_name:<40} {'NO DATA':>6}")
        continue

    # Highlight best result
    marker = "⭐ " if metrics["avg_pnl_pct"] == best_pnl else "   "

    print(f"{marker}{config_name:<37} {metrics['total_deals']:>6} "
          f"{metrics['avg_pnl_pct']:>+9.2f}% "
          f"{metrics['win_rate']:>9.1f}% "
          f"{metrics['stop_rate']:>9.1f}%")

print()
print("=" * 100)
print()
print("KEY FINDINGS:")
print()
print("1. Compare avg P&L across configurations to find the best setup")
print("2. Watch for improvements in STOP RATE - the critical metric")
print("3. Single-order (NO_AVG) should show 0 stops in averaging scenarios")
print("4. Wider averaging (WIDER_AVG) may reduce stop rate by spreading entry")
print("5. Reduced weight (REDUCED_2ND) limits averaging exposure")
print("6. Wider stop (WIDER_STOP) gives more room but increases loss when triggered")
print()
print("RECOMMENDATION:")
print("- If NO_AVG shows +0.50%+ with lower stops → eliminate averaging")
print("- If COMBINED shows improvement → adjust both offset and weight")
print("- If AGGRESSIVE works best → accept wider stop as trade-off")
print()
