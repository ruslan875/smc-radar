@echo off
cd /d D:\VANTORIX\bot
set P=venv\Scripts\python.exe
%P% ut_bot_test.py
%P% std_ind_test.py
%P% combo71_new_test.py
%P% ginarea_soldca_test.py 730 SOL
%P% ginarea_sui_test.py 180 SUI
%P% ginarea_dca_test.py 365 ETC
%P% ginarea_trend_test.py 365 SUI
%P% ginarea_trend_all.py 180
echo ===== ВСЕ ТЕСТЫ ГОТОВЫ =====
pause
