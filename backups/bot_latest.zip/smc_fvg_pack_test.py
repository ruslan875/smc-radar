"""smc_fvg_pack_test.py — 2026-10-14. «[Crypto-Scalping] Smart Money Concept | FVG | Pattern» (сборник TradingView).

Скрипт — индикатор-склейка. Большая часть рисует зоны (OB, ликвидность, FVG, трендлинии) без правил входа.
Правила с входом и выходом в нём два — их и тестируем, один в один с Pine:

1) RSI+BOLLINGER (L/S), параметры по умолчанию (BB 20/2, RSI 14, уровни 29/71, «каскад» 5%):
   BUY — RSI14 пересёк вверх 29; повторная покупка только если цена ≥5% ниже прошлой покупки (усреднение);
   COVER LONG — close пересёк вниз верхнюю BB → закрываем ВСЕ покупки.
   SHORT — RSI14 пересёк вниз 71; повторно — если цена ≥5% выше; COVER SHORT — close пересёк вверх нижнюю BB.
   Стопа в оригинале нет. Каждый вход = 1 доля. Лонг и шорт ведутся независимо (как сигналы индикатора).
   Вариант «+стоп −15%»: аварийный стоп от средней (по закрытию), чтобы видеть хвостовой риск.
2) ChoCh-паттерн (смена структуры): пивоты 10/10; close/high пробил последний пивот-максимум при медвежьей
   структуре → лонг; low пробил пивот-минимум при бычьей → шорт (разворот). Выход — по встречному ChoCh.
Исполнение: сигнал на закрытии свечи → вход по открытию следующей. Комиссии пользователя: рынок 0.09% на сторону.
12 монет, ТФ 5m / 15m / 1h / 4h, 1-я и 2-я половины истории отдельно.
✅ — в плюсе в целом, ≥ 8/12 монет и обе половины > 0. Ничего не торгует.
Запуск: smc_fvg_pack_test.bat → bt_lab_bots/smc_fvg_pack_test.txt
"""
from __future__ import annotations

import time
from pathlib import Path

import numpy as np

import tg_strats_test as T

OUT = Path(__file__).resolve().parent / "bt_lab_bots" / "smc_fvg_pack_test.txt"
TK = 0.0009
TFS = [("5", "5m", 30000), ("15", "15m", 25000), ("60", "1h", 15000), ("240", "4h", 6000)]
LINES = []


def say(s=""):
    print(s, flush=True)
    LINES.append(s)


def rsi(c, n=14):
    d = np.diff(c, prepend=c[0]); up = np.clip(d, 0, None); dn = np.clip(-d, 0, None)
    au = np.empty_like(c); ad = np.empty_like(c); au[0] = up[0]; ad[0] = dn[0]
    for i in range(1, len(c)):
        au[i] = au[i - 1] + (up[i] - au[i - 1]) / n; ad[i] = ad[i - 1] + (dn[i] - ad[i - 1]) / n
    return 100 - 100 / (1 + au / np.where(ad == 0, 1e-12, ad))


def sma(x, n):
    cs = np.cumsum(np.r_[0.0, x]); out = np.full(len(x), np.nan); out[n - 1:] = (cs[n:] - cs[:-n]) / n; return out


def bb(c, n=20, k=2.0):
    m = sma(c, n); s = np.sqrt(np.maximum(sma(c * c, n) - m * m, 0)); return m, m + k * s, m - k * s


# ---------------- 1) RSI + Bollinger L/S с каскадом ----------------
def rsi_bb(d, side, stop=None, lvl=29.0, step=0.05):
    o, c = d["o"], d["c"]; r = rsi(c); m, up, lo = bb(c)
    tot, n, layers_max = 0.0, 0, 0
    pos = []              # цены входов
    last = None
    for i in range(30, len(c) - 1):
        if side > 0:
            sig = r[i - 1] <= lvl < r[i]
            cover = c[i - 1] >= up[i - 1] and c[i] < up[i]
        else:
            sig = r[i - 1] >= 100 - lvl > r[i]
            cover = c[i - 1] <= lo[i - 1] and c[i] > lo[i]
        if pos and stop is not None:
            avg = np.mean(pos)
            if side * (c[i] / avg - 1) <= -stop:
                px = o[i + 1]
                tot += sum(side * (px / e - 1) - 2 * TK for e in pos); n += len(pos); pos = []; last = None
                continue
        if cover and pos:
            px = o[i + 1]
            tot += sum(side * (px / e - 1) - 2 * TK for e in pos); n += len(pos); pos = []; last = None
        elif cover:
            last = None
        elif sig and (last is None or (c[i] <= last * (1 - step) if side > 0 else c[i] >= last * (1 + step))):
            pos.append(o[i + 1]); last = c[i]; layers_max = max(layers_max, len(pos))
    if pos:
        px = c[-1]; tot += sum(side * (px / e - 1) - 2 * TK for e in pos); n += len(pos)
    return tot, n, layers_max


# ---------------- 2) ChoCh ----------------
def choch(d, ln=10):
    o, h, l, c = d["o"], d["h"], d["l"], d["c"]
    ph = pl = np.nan; trend = False; pos = 0; e = 0.0; tot, n = 0.0, 0
    for i in range(2 * ln, len(c) - 1):
        j = i - ln                              # пивот подтверждается через ln свечей
        if h[j] == h[j - ln:i + 1].max():
            ph = h[j]
        if l[j] == l[j - ln:i + 1].min():
            pl = l[j]
        sig = 0
        if not np.isnan(ph) and h[i] > ph and h[i - 1] <= ph and not trend:
            trend = True; sig = 1
        elif not np.isnan(pl) and l[i] < pl and l[i - 1] >= pl and trend:
            trend = False; sig = -1
        if sig:
            px = o[i + 1]
            if pos:
                tot += pos * (px / e - 1) - 2 * TK; n += 1
            pos, e = sig, px
    if pos:
        tot += pos * (c[-1] / e - 1) - 2 * TK; n += 1
    return tot, n, 0


TESTS = {
    "RSI+BB лонг (каскад, без стопа)":  lambda d: rsi_bb(d, 1),
    "RSI+BB шорт (каскад, без стопа)":  lambda d: rsi_bb(d, -1),
    "RSI+BB лонг + стоп −15%":          lambda d: rsi_bb(d, 1, 0.15),
    "RSI+BB шорт + стоп −15%":          lambda d: rsi_bb(d, -1, 0.15),
    "ChoCh разворот (10/10)":           lambda d: choch(d, 10),
}


def half(d, w):
    n = len(d["c"]); m = n // 2; sl = slice(0, m) if w == 0 else slice(m, n)
    return {k: v[sl] for k, v in d.items()}


def main():
    say(f"[Crypto-Scalping] SMC | FVG | Pattern — тест правил с входом · {time.strftime('%Y-%m-%d %H:%M')}")
    say("Результат: средний % на монету (сумма сделок, каждая доля = 100% ставки), комиссия рынок 0.09%×2")
    passed = {}
    for code, tf, nb in TFS:
        data = {s: T.klines(s, code, nb) for s in T.COINS}
        data = {s: d for s, d in data.items() if len(d["c"]) >= 1000}
        if not data:
            continue
        days = np.median([(d["t"][-1] - d["t"][0]) / 86400000 for d in data.values()])
        say(""); say(f"=== {tf} · ~{days:.0f} дней · монет {len(data)} ===")
        for name, fn in TESTS.items():
            full, h1, h2, nn, lay = [], [], [], 0, 0
            for d in data.values():
                a = fn(d); full.append(a[0]); nn += a[1]; lay = max(lay, a[2])
                h1.append(fn(half(d, 0))[0]); h2.append(fn(half(d, 1))[0])
            avg, a1, a2 = np.mean(full) * 100, np.mean(h1) * 100, np.mean(h2) * 100
            plus = sum(x > 0 for x in full)
            ok = avg > 0 and plus >= 8 and a1 > 0 and a2 > 0
            if ok:
                passed.setdefault(name, []).append(tf)
            say(f"  {name:<34} {avg:+8.1f}% · в плюсе {plus:>2}/{len(full)} · 1-я {a1:+7.1f}% · 2-я {a2:+7.1f}%"
                f" · входов {nn}{f' · макс. слоёв {lay}' if lay else ''}  {'✅' if ok else '❌'}")
    say(""); say("ИТОГ:")
    if not passed:
        say("  ни одно правило не прошло")
    for k, v in passed.items():
        say(f"  {'★ ' if len(v) >= 2 else '  '}{k}: {', '.join(v)}")
    say("★ — прошло на 2+ ТФ. Варианты «без стопа» с каскадом — смотреть вместе с версией «+стоп»: если со стопом")
    say("  результат рушится, значит прибыль держится на том, что убыточные лонги/шорты просто пересиживали.")
    OUT.parent.mkdir(exist_ok=True)
    OUT.write_text("\n".join(LINES), encoding="utf-8")
    print(f"\nОтчёт: {OUT}")


if __name__ == "__main__":
    main()
