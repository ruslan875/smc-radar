"""own_ai2.py — 2026-11-08. Свой ИИ v2: оценивает сигналы ОСНОВНЫХ стратегий (BOS 4h, ATR Fib, Donchian, + прочие боты)
и учится НЕ ТОЛЬКО на истории, но и на ЖИВЫХ сделках: бумажные боты, демо Bybit (demo_mirror) и реальные ручные сделки (журнал челленджа).
Живые сделки весят ×3 (они ближе к реальности). Переобучение — автоматически раз в 7 дней (поток в панели) или:
  python own_ai2.py train
Модель: own_ai2_model.pkl, отчёт: own_ai2_report.json. Проверка: учим на старых 75% (по времени), проверяем на свежих 25%.
Режим: подсказка в сигнале («ИИ: сильный / средний / слабый»), сделки НЕ фильтрует, пока не накопит живых сделок."""
from __future__ import annotations

import json, pickle, sys, threading, time
from pathlib import Path

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parent
if str(BASE) not in sys.path:
    sys.path.insert(0, str(BASE))
MODEL = BASE / "own_ai2_model.pkl"
REPORT = BASE / "own_ai2_report.json"
BOTS = BASE / "bt_lab_bots"
COINS = ["BTCUSDT", "ETHUSDT", "XRPUSDT", "DOGEUSDT", "ADAUSDT", "SOLUSDT", "LINKUSDT", "LTCUSDT", "BNBUSDT", "AVAXUSDT", "TAOUSDT", "HYPEUSDT"]
STRATS = ["bos", "af", "donch", "tu", "ch", "tf", "other"]   # 2026-11-14: + черепахи, канал, TradFi
SIGNED = ("ema20_dist", "ema50_dist", "ema200_dist", "ema20_slope", "ema50_slope", "ema200_slope", "sma200_dist", "macd",
          "macd_hist", "bb_pos", "di_diff", "obv_slope", "ret1", "ret5", "ret20", "ret60", "body", "htf_trend", "ch_slope")
H4 = 4 * 3600_000
LIVE_W = 3.0


def _candles(sym: str, net: bool = True) -> pd.DataFrame | None:
    f = BASE / "market_cache" / "binance" / f"{sym}_4h.csv"
    if net:
        try:
            import kvoo_longtest as K  # noqa: PLC0415
            d = K.load(sym, "4h")
            if d is not None:
                return d
        except Exception:  # noqa: BLE001
            pass
    for p in (f, BASE / "market_cache_tf" / f"{sym}_4h.csv"):
        if p.exists():
            d = pd.read_csv(p)
            return d[["t", "o", "h", "l", "c", "v"]].drop_duplicates("t").sort_values("t").reset_index(drop=True)
    return None


def _feat_table(d):
    import ml_filter_test as M  # noqa: PLC0415
    f, _m, _s = M.feats(d.reset_index(drop=True))
    return f.replace([np.inf, -np.inf], np.nan).fillna(0)


def _row(f, i, side, strat):
    x = f.iloc[i].to_dict()
    for k in SIGNED:
        if k in x:
            x[k] = x[k] * side
    x["side"] = side
    for s in STRATS:
        x["st_" + s] = 1.0 if s == strat else 0.0
    return x


def _sim(h, l, c, i, side, stop, exit_sig=None, tp=None, hold=300):
    risk = abs(c[i] - stop)
    if risk <= 0:
        return None
    for j in range(i + 1, min(len(c), i + hold)):
        if (l[j] <= stop) if side > 0 else (h[j] >= stop):
            return -1.0 - 0.0011 * c[i] / risk
        if tp is not None and ((h[j] >= tp) if side > 0 else (l[j] <= tp)):
            return (abs(tp - c[i]) - 0.0011 * c[i]) / risk
        if exit_sig is not None and exit_sig[j] == -side:
            return (side * (c[j] - c[i]) - 0.0011 * c[i]) / risk
    return None


def hist_samples(net=True):
    from windows_app import afbos_paper as A  # noqa: PLC0415
    rows = []
    for sym in COINS:
        d = _candles(sym, net)
        if d is None or len(d) < 600:
            continue
        f = _feat_table(d); h, l, c = d.h.values.tolist(), d.l.values.tolist(), d.c.values.tolist()
        a14 = A._atr(h, l, c, 14); t = d.t.values
        bos = A.bos_signals(h, l, c); af = A.af_signals(h, l, c)
        e200 = pd.Series(c).ewm(span=200, adjust=False).mean().values
        hh = d.h.rolling(20).max().shift(1).values; ll = d.l.rolling(20).min().shift(1).values
        for i in range(260, len(c) - 1):
            cand = []
            if bos[i]: cand.append(("bos", bos[i], c[i] - bos[i] * 2 * a14[i], bos, None))
            if af[i] > 0: cand.append(("af", 1, c[i] - 2.6 * a14[i], af, None))
            if c[i] > hh[i] and c[i] > e200[i]:
                st = (hh[i] + ll[i]) / 2; cand.append(("donch", 1, st, None, c[i] + 3 * (c[i] - st)))
            elif c[i] < ll[i] and c[i] < e200[i]:
                st = (hh[i] + ll[i]) / 2; cand.append(("donch", -1, st, None, c[i] - 3 * (st - c[i])))
            for strat, side, stop, ex, tp in cand:
                r = _sim(h, l, c, i, side, stop, ex, tp)
                if r is None:
                    continue
                x = _row(f, i, side, strat); x.update(t=int(t[i]), r=r, w=1.0, src="история", sym=sym)
                rows.append(x)
    return rows


def _strat_of(name: str) -> str:
    n = name.lower()
    return "bos" if ("bos" in n or "bs4h" in n or "bs1h" in n or "br4h" in n) else "af" if ("af4h" in n or "atr fib" in n) else \
        "donch" if ("donch" in n or "dc4h" in n) else "tu" if ("turtle" in n or n.startswith("tu")) else \
        "ch" if ("chan" in n or n.startswith("ch")) else "tf" if (n.startswith("tf") or "tradfi" in n) else "other"


def live_trades():
    """Живые сделки: бумажные боты (журналы с R), демо Bybit (demo_mirror closed), реальные ручные (challenge.json)."""
    out = []
    for f in BOTS.glob("*.json"):
        if f.stem in ("demo_mirror", "demo_manual", "webhook_demo", "sig_watch_state", "pump_alerts", "wall_paper", "forum_topics", "group_guard") \
                or f.stem.isdigit() or f.stem.startswith(("cf_", "pine_", "tg_scan")):
            continue
        try:
            st = json.loads(f.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            continue
        for t in (st.get("trades") or []) if isinstance(st, dict) else []:
            if not isinstance(t, dict) or t.get("r") is None or not t.get("open_t"):
                continue
            sym = str(t.get("sym", "")).upper(); sym = sym if sym.endswith("USDT") else sym + "USDT"
            out.append({"sym": sym, "side": 1 if str(t.get("side", "")).upper().startswith("L") else -1, "t": int(t["open_t"]),
                        "r": float(t["r"]), "strat": _strat_of(f.stem), "src": "бумага"})
    for fn, src in (("demo_mirror.json", "демо"), ("hyro_mirror.json", "hyro")):
        try:
            for x in json.loads((BOTS / fn).read_text(encoding="utf-8")).get("closed") or []:
                if x.get("r") is None or not x.get("since") or x.get("r_est"):
                    continue
                # 2026-11-14: «закрытия» в первые 15 мин — ошибка журнала до 07.11 (сделка не закрывалась), не учим на них
                try:
                    if (pd.Timestamp(x["closed"]) - pd.Timestamp(x["opened"])).total_seconds() < 900:
                        continue
                except Exception:  # noqa: BLE001
                    pass
                out.append({"sym": x["symbol"], "side": int(x.get("side") or 1), "t": int(x["since"]), "r": float(x["r"]),
                            "strat": _strat_of(x.get("tag", "")), "src": src})
        except Exception:  # noqa: BLE001
            pass
    try:   # реальные ручные сделки: pnl в $, переводим в знак (+1R/−1R условно), дата/время входа
        for t in [t for fn in ("challenge.json", "challenge_wsct.json")
                  for t in (json.loads((BASE / fn).read_text(encoding="utf-8")).get("trades") or [])]:
            sym = str(t.get("sym") or t.get("symbol") or "").upper()
            if not sym or not t.get("date"):
                continue
            sym = sym if sym.endswith("USDT") else sym + "USDT"
            ts = int(pd.Timestamp(f"{t['date']} {t.get('time') or '12:00'}").value // 1_000_000)
            pnl = float(t.get("pnl") or 0)
            out.append({"sym": sym, "side": 1 if str(t.get("side", "LONG")).upper().startswith("L") else -1, "t": ts,
                        "r": 1.0 if pnl > 0 else -1.0 if pnl < 0 else 0.0, "strat": "other", "src": "реал"})
    except Exception:  # noqa: BLE001
        pass
    return out


def live_samples(net=True):
    rows = []; cache = {}
    for x in live_trades():
        if x["sym"] not in cache:
            d = _candles(x["sym"], net)
            cache[x["sym"]] = (d, _feat_table(d)) if d is not None and len(d) > 300 else (None, None)
        d, f = cache[x["sym"]]
        if d is None:
            continue
        i = int(np.searchsorted(d.t.values, x["t"] - H4, side="right")) - 1   # последняя ЗАКРЫТАЯ свеча 4h до входа
        if i < 260 or i >= len(d):
            continue
        z = _row(f, i, x["side"], x["strat"]); z.update(t=x["t"], r=x["r"], w=LIVE_W, src=x["src"], sym=x["sym"])
        rows.append(z)
    return rows


def train(net=True) -> dict:
    from sklearn.ensemble import HistGradientBoostingClassifier  # noqa: PLC0415
    H = hist_samples(net); L = live_samples(net)
    df = pd.DataFrame(H + L).replace([np.inf, -np.inf], np.nan).fillna(0).sort_values("t").reset_index(drop=True)
    cols = [c for c in df.columns if c not in ("t", "r", "w", "src", "sym")]
    y = (df.r > 0).astype(int).values; w = df.w.values
    mk = lambda: HistGradientBoostingClassifier(max_depth=3, learning_rate=0.05, max_iter=250, l2_regularization=1.0,
                                                min_samples_leaf=40, random_state=1)
    cut = int(len(df) * 0.75)
    chk = mk().fit(df[cols].values[:cut], y[:cut], sample_weight=w[:cut])
    pt = chk.predict_proba(df[cols].values[cut:])[:, 1]; te = df.iloc[cut:].copy(); te["p"] = pt
    q3, q7 = np.quantile(pt, 0.3), np.quantile(pt, 0.7)
    def grp(x):
        return {"n": int(len(x)), "R": round(float(x.r.mean()), 3) if len(x) else None}
    check = {"test": int(len(te)), "all": grp(te), "strong": grp(te[te.p >= q7]), "weak": grp(te[te.p < q3]),
             "by_strat": {s: {"all": grp(te[te[f"st_{s}"] == 1]), "strong": grp(te[(te[f"st_{s}"] == 1) & (te.p >= q7)])} for s in STRATS},
             "live_test": {"all": grp(te[te.src != "история"]), "strong": grp(te[(te.src != "история") & (te.p >= q7)]),
                           "weak": grp(te[(te.src != "история") & (te.p < q3)])}}
    check["works"] = bool(check["strong"]["R"] is not None and check["weak"]["R"] is not None and check["strong"]["R"] > check["weak"]["R"])
    m = mk().fit(df[cols].values, y, sample_weight=w)
    p_all = m.predict_proba(df[cols].values)[:, 1]
    rep = {"trained": time.strftime("%Y-%m-%d %H:%M"), "hist": len(H), "live": len(L),
           "live_by_src": pd.Series([x["src"] for x in L]).value_counts().to_dict() if L else {},
           "base_wr": round(float(y.mean()), 3), "lo": float(np.quantile(p_all, 0.3)), "hi": float(np.quantile(p_all, 0.7)),
           "check": check, "cols": cols}
    MODEL.write_bytes(pickle.dumps({"model": m, "cols": cols, "lo": rep["lo"], "hi": rep["hi"], "trained": rep["trained"]}))
    REPORT.write_text(json.dumps(rep, ensure_ascii=False, indent=1), encoding="utf-8")
    return rep


_cache: dict = {}


def score(sym: str, side: int, bot: str = "") -> dict | None:
    """Оценка сигнала сейчас (по последней закрытой 4h-свече). Свечи Bybit, кеш 15 мин."""
    try:
        if "m" not in _cache or _cache.get("mt") != MODEL.stat().st_mtime:
            _cache["m"] = pickle.loads(MODEL.read_bytes()); _cache["mt"] = MODEL.stat().st_mtime
        m = _cache["m"]; sym = sym.upper(); sym = sym if sym.endswith("USDT") else sym + "USDT"
        k = ("d", sym)
        if k not in _cache or time.time() - _cache[k][0] > 900:
            from app.data import get_klines  # noqa: PLC0415
            g = get_klines(sym, "4h", 400).reset_index()
            d = pd.DataFrame({"t": g["open_time"].astype("int64") // 1_000_000, "o": g["open"], "h": g["high"], "l": g["low"], "c": g["close"], "v": g["volume"]})
            d = d[d.t + H4 <= time.time() * 1000].reset_index(drop=True)
            _cache[k] = (time.time(), d, _feat_table(d))
        _ts, d, f = _cache[k]
        x = _row(f, len(d) - 1, side, _strat_of(bot))
        row = np.array([[float(np.nan_to_num(x.get(c, 0.0), posinf=0, neginf=0)) for c in m["cols"]]])
        p = float(m["model"].predict_proba(row)[0, 1])
        return {"p": p, "level": "сильный" if p >= m["hi"] else "слабый" if p < m["lo"] else "средний", "trained": m["trained"]}
    except Exception:  # noqa: BLE001
        return None


def age_days() -> float:
    return (time.time() - MODEL.stat().st_mtime) / 86400 if MODEL.exists() else 1e9


_started = False


def start() -> None:
    """Фоновое переобучение раз в 7 дней (первое — через 10 минут после запуска панели, если модели нет или она старше 7 дней)."""
    global _started
    if _started:
        return
    _started = True

    def loop():
        time.sleep(600)
        while True:
            try:
                if age_days() >= 7:
                    train()
            except Exception as exc:  # noqa: BLE001
                try:
                    REPORT.with_suffix(".err").write_text(str(exc)[:500], encoding="utf-8")
                except OSError:
                    pass
            time.sleep(6 * 3600)
    threading.Thread(target=loop, daemon=True, name="own_ai2").start()


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "train":
        print(json.dumps(train(), ensure_ascii=False, indent=1)[:3000])
