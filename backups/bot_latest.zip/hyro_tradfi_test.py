"""hyro_tradfi_test.py — 2026-11-14. Акции/металлы/нефть на Hyro (USDT-перпетуалы Bybit): тест по правилам челленджа.
Сделки — кодом бота hh_tradfi_paper (BOS 1D, пробой на объёме, FVG, ложный пробой), дневки Yahoo за 3 года.
Только ликвидные на Bybit: TSLA, AAPL, MU, INTC, QQQ(NQ=F), XAU, XAG, MSTR, CL.
Портфель как у бота Hyro: макс. 2 сделки, дневной стоп −3%, общий −7%, серия стопов режет риск. Риск 0.5% / 0.75%.
Итог: hyro_tradfi_test.txt"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
from windows_app import hh_tradfi_paper as H  # noqa: E402
from windows_app import bos_tradfi_paper as BOS, fvg_tradfi_paper as FVG, fb2_tradfi_paper as FB2  # noqa: E402

INST = {"TSLA": ("TSLA", ("bos", "vol")), "AAPL": ("AAPL", ("bos", "vol")), "MU": ("MU", ("bos", "vol")), "INTC": ("INTC", ("bos",)),
        "QQQ": ("NQ=F", ("bos",)), "XAU": ("GC=F", ("bos",)), "XAG": ("SI=F", ("bos",)), "MSTR": ("MSTR", ("vol",)),
        "CL": ("CL=F", ("fb2", "fvg"))}
REP = {"bos": BOS.replay, "vol": H.vol_replay, "fvg": FVG.replay, "fb2": FB2.replay}
EXTRA_COST_R = 0.03   # доп. комиссия Bybit-перпетуала против теста (~0.1% от позиции при стопе ~3%)


def main() -> None:
    T = []
    for name, (sym, strats) in INST.items():
        try:
            d = H._yahoo(sym)
        except Exception as e:  # noqa: BLE001
            print(name, "нет данных", e, flush=True); continue
        for sk in strats:
            for x in REP[sk](d):
                if x.get("status") != "closed" or x.get("r") is None:
                    continue
                T.append({"sym": name, "tag": sk, "t_in": int(x["in_t"]), "t_out": int(x.get("out_t") or x["in_t"] + 5 * 86400_000),
                          "r": float(x["r"]) - EXTRA_COST_R})
        print(name, "ok", len(T), flush=True)
        time.sleep(1.5)
    G = pd.DataFrame(T).sort_values("t_in").reset_index(drop=True)
    lines = [f"Hyro · акции/металлы/нефть — {time.strftime('%Y-%m-%d %H:%M')} · сделок {len(G)}", ""]
    for (s, k), g in G.groupby(["sym", "tag"]):
        lines.append(f"  {s:5s} {k:4s} сделок {len(g):3d} · в плюс {(g.r > 0).mean() * 100:3.0f}% · средняя {g.r.mean():+.2f}R · сумма {g.r.sum():+.1f}R")
    t0, t1 = int(G.t_in.min()), int(G.t_in.max())

    def run(start, target, maxloss, dayloss, risk, halt=0.07):
        bal = 1.0; peak = 1.0; mdd = 0.0; opn = []; streak = {}; day = None; day0 = 1.0; n = 0

        def settle(upto):
            nonlocal bal, peak, mdd
            for o in sorted([o for o in opn if o["t_out"] <= upto], key=lambda o: o["t_out"]):
                opn.remove(o); bal += o["pnl"]
                k = streak.get(o["tag"], 0); streak[o["tag"]] = 0 if o["r"] >= 2 else k + 1 if o["r"] < 0 else k
                peak = max(peak, bal); mdd = max(mdd, (peak - bal) / peak)
                if bal - 1 >= target: return ("pass", o["t_out"])
                if 1 - bal >= maxloss or day0 - bal >= dayloss: return ("fail", o["t_out"])
            return None
        for _, x in G[G.t_in >= start].iterrows():
            ev = settle(x.t_in)
            if ev:
                return ev[0], (ev[1] - start) / 86400e3, n, bal, mdd
            dd = time.strftime("%Y-%m-%d", time.gmtime(x.t_in / 1000))
            if dd != day:
                day, day0 = dd, bal
            if bal <= day0 * 0.97 or bal <= 1 - halt or len(opn) >= 2 or any(o["sym"] == x.sym for o in opn):
                continue
            k = streak.get(x.tag, 0); m = 0.25 if k >= 10 else 0.5 if k >= 5 else 1.0
            opn.append({"t_out": x.t_out, "sym": x.sym, "tag": x.tag, "r": x.r, "pnl": risk * m * x.r}); n += 1
        ev = settle(10 ** 15)
        if ev:
            return ev[0], (ev[1] - start) / 86400e3, n, bal, mdd
        return "open", None, n, bal, mdd

    for risk in (0.005, 0.0075):
        res = run(t0, 99, 99, 99, risk, halt=99)
        lines += ["", f"РИСК {risk * 100:.2f}% · весь период {(t1 - t0) / 86400e3:.0f} дн: итог {(res[3] - 1) * 100:+.1f}% · "
                      f"{res[2]} сделок (≈{res[2] / ((t1 - t0) / 86400e3 / 30):.1f} в мес) · макс. просадка {res[4] * 100:.1f}%"]
        starts = pd.date_range(pd.to_datetime(t0, unit="ms").normalize() + pd.offsets.MonthBegin(1),
                               pd.to_datetime(t1, unit="ms") - pd.Timedelta(days=60), freq="MS")
        for nm, tg, ml, dl in (("One-Step (+10% / −8%)", .10, .08, .04), ("Two-Step э.1 (+10% / −10%)", .10, .10, .05),
                               ("Core (+10% / −5% / −3%)", .10, .05, .03)):
            R = [run(int(s.value // 1e6), tg, ml, dl, risk) for s in starts]
            p = [r for r in R if r[0] == "pass"]; f = [r for r in R if r[0] == "fail"]
            lines.append(f"  {nm}: стартов {len(R)} · прошли {len(p)} ({len(p) / max(1, len(R)) * 100:.0f}%) · провал {len(f)} · "
                         f"не дошли {len(R) - len(p) - len(f)}" + (f" · медиана до цели {np.median([r[1] for r in p]):.0f} дн" if p else ""))
    lines += ["", "Комиссия перпетуала Bybit учтена грубо (−0.03R на сделку). Ночные/выходные гэпы — как в дневных свечах Yahoo."]
    (BASE / "hyro_tradfi_test.txt").write_text("\n".join(lines), encoding="utf-8")
    print("\n".join(lines), flush=True)


if __name__ == "__main__":
    main()
