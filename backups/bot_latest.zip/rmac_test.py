"""rmac_test.py — 2026-10-06. Реконструкция по скриншоту «RSI+MFI+ADX+Cloud» (индикатор участника Hash Hedge, код закрыт).
ЭТО ДОГАДКА, не оригинал. Что видно на скриншоте: RSI(7) пороги 28/72, MFI(7) 28/72, ADX(14) > 20, облако (BEARISH/BULLISH),
фильтр ATR-волатильности, тейк 1% / стоп 2% (auto), ТФ 15м, сигнал SHORT base при перекупленности под медвежьим облаком.
Варианты облака: Ишимоку (9/26/52) и EMA 20/50. Логика: возврат — SHORT, когда облако медвежье, ADX>20 и RSI7/MFI7 ≥ 72
(откат вверх против тренда); LONG зеркально. Плюс вариант «на пробой» (RSI/MFI выходят из зоны в сторону облака).
Тейк 1% / стоп 2% и альтернатива 2% / 2%. Комиссия 0.11%. Крипта 12 монет, 15м и 1h, с 2019; история пополам.
"""
import sys as _sys
try:
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass
import numpy as np
import pandas as pd

COST = 0.0011


def ind(d):
    h, l, c, v = (d[k].astype(float) for k in "hlcv")
    dl = c.diff(); up = dl.clip(lower=0).ewm(alpha=1 / 7, adjust=False).mean(); dn = (-dl.clip(upper=0)).ewm(alpha=1 / 7, adjust=False).mean()
    rsi = 100 - 100 / (1 + up / dn.replace(0, 1e-12))
    tp = (h + l + c) / 3; mf = tp * v
    pos = mf.where(tp > tp.shift(1), 0.0).rolling(7).sum(); neg = mf.where(tp < tp.shift(1), 0.0).rolling(7).sum()
    mfi = 100 - 100 / (1 + pos / neg.replace(0, 1e-9))
    pc = c.shift(1); tr = pd.concat([h - l, (h - pc).abs(), (l - pc).abs()], axis=1).max(axis=1)
    atr = tr.ewm(alpha=1 / 14, adjust=False).mean()
    pdm = h.diff().where((h.diff() > -l.diff()) & (h.diff() > 0), 0.0); ndm = (-l.diff()).where((-l.diff() > h.diff()) & (-l.diff() > 0), 0.0)
    pdi = 100 * pdm.ewm(alpha=1 / 14, adjust=False).mean() / atr; ndi = 100 * ndm.ewm(alpha=1 / 14, adjust=False).mean() / atr
    adx = (100 * (pdi - ndi).abs() / (pdi + ndi).replace(0, 1e-9)).ewm(alpha=1 / 14, adjust=False).mean()
    tk = (h.rolling(9).max() + l.rolling(9).min()) / 2; kj = (h.rolling(26).max() + l.rolling(26).min()) / 2
    sa = ((tk + kj) / 2).shift(26); sb = ((h.rolling(52).max() + l.rolling(52).min()) / 2).shift(26)
    ichi = np.where(c > np.maximum(sa, sb), 1, np.where(c < np.minimum(sa, sb), -1, 0))
    e20, e50 = c.ewm(span=20, adjust=False).mean(), c.ewm(span=50, adjust=False).mean()
    ema = np.where(e20 > e50, 1, -1)
    volok = (atr / atr.rolling(100).mean()).between(0.7, 2.0).values
    return rsi.values, mfi.values, adx.values, ichi, ema, volok


def run(d, cloud, mode, tp_pct, sl_pct):
    rsi, mfi, adx, ichi, ema, volok = ind(d)
    cl = ichi if cloud == "ichi" else ema
    h, l, c, t = d.h.values, d.l.values, d.c.values, d.t.values
    out = []; i = 120
    while i < len(c) - 1:
        side = 0
        if adx[i] > 20 and volok[i]:
            if mode == "rev":
                if cl[i] < 0 and rsi[i] >= 72 and mfi[i] >= 72: side = -1
                elif cl[i] > 0 and rsi[i] <= 28 and mfi[i] <= 28: side = 1
            else:
                if cl[i] < 0 and rsi[i - 1] >= 72 > rsi[i] and mfi[i] >= 50: side = -1
                elif cl[i] > 0 and rsi[i - 1] <= 28 < rsi[i] and mfi[i] <= 50: side = 1
        if not side:
            i += 1; continue
        e = c[i]; tp = e * (1 + side * tp_pct); sl = e * (1 - side * sl_pct); r = None
        for k in range(i + 1, min(len(c), i + 200)):
            if (l[k] <= sl) if side > 0 else (h[k] >= sl): r = -sl_pct; break
            if (h[k] >= tp) if side > 0 else (l[k] <= tp): r = tp_pct; break
        else:
            r = side * (c[k] - e) / e
        out.append((t[i], (r - COST) / sl_pct)); i = k + 1
    return out


if __name__ == "__main__":
    import kvoo_longtest as K
    import fvg_test  # noqa: F401
    data = {}
    for s in K.COINS:
        d = K.load(s, "1h")
        if d is not None and len(d) > 1000:
            data[(s, "1h")] = d.reset_index(drop=True)
    print("Внимание: 15м на складе нет — проверка на 1h (ближайший ТФ). Комиссия 0.11%.\n")
    CUT = pd.Timestamp("2024-01-01", tz="UTC").value // 10**6
    for cloud in ("ichi", "ema"):
        for mode in ("rev", "brk"):
            for tp_pct, sl_pct in ((0.01, 0.02), (0.02, 0.02)):
                a = b = 0.0; n = w = plus = 0
                for (s, tf), d in data.items():
                    tr = run(d, cloud, mode, tp_pct, sl_pct); rs = sum(r for _, r in tr); plus += rs > 0
                    for tt, r in tr:
                        n += 1; w += r > 0
                        if tt < CUT: a += r
                        else: b += r
                ok = "✅" if n >= 30 and a > 0 and b > 0 and plus > len(data) / 2 else "  "
                print(f"{ok} облако {'Ишимоку' if cloud == 'ichi' else 'EMA20/50':8} | {'возврат' if mode == 'rev' else 'выход из зоны':13} | "
                      f"тейк {tp_pct * 100:.0f}% стоп {sl_pct * 100:.0f}% | сделок {n:5} WR {100 * w / max(1, n):5.1f}% | "
                      f"до 2024 {a:+7.1f}R | 2024–26 {b:+7.1f}R | {(a + b) / max(1, n):+.3f}R/сд | в плюсе {plus}/{len(data)}")
    print("\n✅ = плюс в обеих половинах и на большинстве монет. Это РЕКОНСТРУКЦИЯ по скриншоту, не оригинал.")
    input("Enter — закрыть")
