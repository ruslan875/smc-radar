@echo off
chcp 65001 >nul
title PAPER TRADING - 10 strategies
cd /d "%~dp0"

if exist "venv\Scripts\python.exe" (
    set PY=venv\Scripts\python.exe
) else (
    set PY=python
)

echo.
echo  Запуск paper-трейдинга: 10 стратегий, депозит $200 на каждую.
echo  Реальные ордера НЕ отправляются. API-ключи не нужны.
echo.

%PY% paper_live.py %*

echo.
echo  Остановлено. Нажмите любую клавишу.
pause >nul
