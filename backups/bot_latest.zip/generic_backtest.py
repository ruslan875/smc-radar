#!/usr/bin/env python3
"""
Generic fee-aware, no-lookahead backtester for the third-party Pine
indicators ported under app/indicators/ -- same methodology as
backtest.py (walk-forward, last-closed-candle convention, static stop
never trailed, SL wins if SL and a new TP land on the same bar) but
driven by any module that exposes `generate_signals(df) -> list[Signal]`
instead of being hardwired to app/smc.py.

Needs network access to Bybit's public API -- run this on your own
machine, same as backtest.py:

    python generic_backtest.py --indicator quantum_scalper
    python generic_backtest.py --indicator sr_range_module --symbol ETHUSDT SOLUSDT
    python generic_backtest.py --indicator ml_lorentzian --timeframe 15m --bars 3000
    python generic_backtest.py --list          # show every available indicator module

Every ported indicator module lives at app/indicators/<name>.py; --indicator
<name> imports it dynamically. Results print to console and save to
generic_backtest_out/<indicator>/<SYMBOL>_trades.csv, same shape as
backtest.py's own output so fee_analysis.py-style post-hoc fee scenarios
apply unchanged.
"""
from __future__ import annotations

import argparse
import csv
import importlib
import pkgutil
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import pandas as pd
import requests

from app.config import Settings
from app.data import BYBIT_BASE, INTERVAL_MAP, DataError
from app.indicators.common import Signal, RISK_MULTIPLES_DEFAULT

FEE_SCENARIOS = {
    "taker+taker": 0.0011,   # market in, market out -- ~0.11% round trip
    "taker+maker": 0.00075,  # market in, limit out   -- ~0.075% round trip
    "maker+maker": 0.0004,   # both limit orders      -- ~0.04% round trip
}


# --------------------------------------------------------------- data --
# (identical to backtest.py's fetch_history -- duplicated rather than
# imported so this file stays runnable standalone / diff-able against it)

def fetch_history(symbol: str, timeframe: str, total_bars: int, category: str = "linear") -> pd.DataFrame:
    interval = INTERVAL_MAP[timeframe]
    all_rows: list = []
    end = None
    while len(all_rows) < total_bars:
        params = {"category": category, "symbol": symbol, "interval": interval, "limit": 1000}
        if end is not None:
            params["end"] = end
        resp = requests.get(f"{BYBIT_BASE}/v5/market/kline", params=params, timeout=15)
        resp.raise_for_status()
        payload = resp.json()
        if payload.get("retCode") != 0:
            raise DataError(f"Bybit API error for {symbol}: {payload.get('retMsg')}")
        rows = payload["result"]["list"]
        if not rows:
            break
        all_rows.extend(rows)
        oldest_ts = int(rows[-1][0])
        end = oldest_ts - 1
        if len(rows) < 1000:
            break
        time.sleep(0.15)

    if not all_rows:
        raise DataError(f"No kline data returned for {symbol} {timeframe}")

    df = pd.DataFrame(all_rows, columns=["open_time", "open", "high", "low", "close", "volume", "turnover"])
    df["open_time"] = df["open_time"].astype("int64")
    df = df.drop_duplicates(subset="open_time")
    for col in ("open", "high", "low", "close", "volume", "turnover"):
        df[col] = df[col].astype(float)
    df["open_time"] = pd.to_datetime(df["open_time"], unit="ms", utc=True)
    df = df.sort_values("open_time").reset_index(drop=True)
    if len(df) > total_bars:
        df = df.tail(total_bars).reset_index(drop=True)
    return df


# ------------------------------------------------------------ outcome --

def simulate_outcome(df: pd.DataFrame, sig: Signal, max_bars_forward: int = 200) -> dict:
    """Same rule as backtest.py's simulate_outcome: walk forward from the
    bar AFTER the trigger candle (entry assumed on next bar's open/close,
    same convention as the SMC bot), static stop, SL wins ties. Uses
    sig.take_profits verbatim if the original indicator defined explicit
    levels (QuantumScalper, sr_range_module); otherwise falls back to the
    same 1R/2R/3R ladder backtest.py uses for the SMC bot."""
    risk = abs(sig.entry - sig.stop_loss)
    if risk <= 0:
        return {"outcome": "invalid", "r": 0.0}

    if sig.take_profits:
        tps = sorted(sig.take_profits, reverse=(sig.direction == "short"))
        r_per_tp = [abs(tp - sig.entry) / risk for tp in tps]
    else:
        tps = [sig.entry + m * risk for m in RISK_MULTIPLES_DEFAULT] if sig.direction == "long" \
            else [sig.entry - m * risk for m in RISK_MULTIPLES_DEFAULT]
        r_per_tp = list(RISK_MULTIPLES_DEFAULT)

    start = sig.trigger_index + 1
    end = min(len(df), start + max_bars_forward)
    achieved = 0
    achieved_r = 0.0
    for i in range(start, end):
        row = df.iloc[i]
        sl_hit = row["low"] <= sig.stop_loss if sig.direction == "long" else row["high"] >= sig.stop_loss
        if sl_hit:
            note = f" (had touched TP{achieved} on an earlier bar)" if achieved else ""
            return {"outcome": "SL" + note, "r": -1.0}
        for level, (tp, r_val) in enumerate(zip(tps, r_per_tp), start=1):
            touched = row["high"] >= tp if sig.direction == "long" else row["low"] <= tp
            if touched:
                achieved = max(achieved, level)
                achieved_r = max(achieved_r, r_val)
        if achieved == len(tps):
            return {"outcome": f"TP{achieved}", "r": achieved_r}
    if achieved:
        return {"outcome": f"TP{achieved} (still open at cutoff)", "r": achieved_r}
    return {"outcome": "open (no resolution within window)", "r": None}


# --------------------------------------------------------------- fees --

def net_r(trade: dict, fee_rate: float) -> float | None:
    if trade["r"] is None:
        return None
    risk_pct = abs(trade["entry"] - trade["stop_loss"]) / trade["entry"]
    if risk_pct <= 0:
        return None
    fee_in_r = fee_rate / risk_pct
    return trade["r"] - fee_in_r


# --------------------------------------------------------------- report --

def summarize(trades: list[dict], label: str) -> None:
    if not trades:
        print(f"\n{label}: no setups fired in this window.")
        return
    resolved = [t for t in trades if t["r"] is not None]
    wins = [t for t in resolved if t["r"] > 0]
    still_open = [t for t in trades if t["r"] is None]
    win_rate = (len(wins) / len(resolved) * 100) if resolved else float("nan")
    avg_r = (sum(t["r"] for t in resolved) / len(resolved)) if resolved else float("nan")

    print(f"\n{label}")
    print(f"  Total setups fired:      {len(trades)}")
    print(f"  Resolved (SL or TP hit): {len(resolved)}   Still open at cutoff: {len(still_open)}")
    print(f"  Gross win rate:          {win_rate:.1f}%")
    print(f"  Gross avg R:             {avg_r:+.2f}")

    for label_fee, fee_rate in FEE_SCENARIOS.items():
        net_rs = [net_r(t, fee_rate) for t in resolved]
        net_rs = [r for r in net_rs if r is not None]
        if not net_rs:
            continue
        net_wins = sum(1 for r in net_rs if r > 0)
        print(f"    net R after {label_fee:12s} fees: {sum(net_rs)/len(net_rs):+.2f}  "
              f"win rate {net_wins/len(net_rs)*100:.1f}%")


def save_csv(trades: list[dict], path: Path) -> None:
    if not trades:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = ["symbol", "label", "direction", "entry", "stop_loss", "synthetic_stop", "time", "outcome", "r"]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for t in trades:
            writer.writerow({k: t.get(k) for k in fieldnames})


# --------------------------------------------------------- walk-forward --

def run_backtest(indicator_module, symbol: str, timeframe: str, bars: int, max_bars_forward: int) -> list[dict]:
    df = fetch_history(symbol, timeframe, bars)
    signals = indicator_module.generate_signals(df)

    trades: list[dict] = []
    for sig in signals:
        # A handful of modules (ml_lorentzian) have a time/signal-based
        # exit rather than a price target and resolve their own outcome
        # up front (see that module's docstring) instead of going through
        # the generic touch-based TP scan below.
        outcome = sig.meta.get("resolved_outcome") or simulate_outcome(df, sig, max_bars_forward)
        trades.append({
            "symbol": symbol, "label": sig.label, "direction": sig.direction,
            "entry": sig.entry, "stop_loss": sig.stop_loss,
            "synthetic_stop": sig.synthetic_stop, "time": sig.trigger_time,
            **outcome,
        })
    return trades


def list_indicators() -> list[str]:
    import app.indicators as pkg
    return sorted(m.name for m in pkgutil.iter_modules(pkg.__path__) if m.name not in ("common",))


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--indicator", help="Module name under app/indicators/ (e.g. quantum_scalper)")
    parser.add_argument("--list", action="store_true", help="List available indicator modules and exit")
    settings = Settings.load()
    parser.add_argument("--symbol", nargs="+", default=settings.watchlist)
    parser.add_argument("--timeframe", default=settings.timeframe)
    parser.add_argument("--bars", type=int, default=2000)
    parser.add_argument("--max-forward", type=int, default=200)
    parser.add_argument("--out", default="generic_backtest_out")
    args = parser.parse_args()

    if args.list or not args.indicator:
        print("Available indicator modules:")
        for name in list_indicators():
            print(f"  {name}")
        if not args.indicator:
            return

    try:
        module = importlib.import_module(f"app.indicators.{args.indicator}")
    except ModuleNotFoundError as exc:
        print(f"Unknown indicator module '{args.indicator}': {exc}")
        print("Run with --list to see available modules.")
        return

    out_dir = Path(args.out) / args.indicator
    all_trades: list[dict] = []
    for symbol in args.symbol:
        symbol = symbol.upper()
        print(f"\nFetching + simulating {symbol} ({args.bars} bars of {args.timeframe}) for {args.indicator}...")
        try:
            trades = run_backtest(module, symbol, args.timeframe, args.bars, args.max_forward)
        except DataError as exc:
            print(f"  [SKIP] {symbol}: {exc}")
            continue
        summarize(trades, symbol)
        save_csv(trades, out_dir / f"{symbol}_trades.csv")
        all_trades.extend(trades)

    summarize(all_trades, f"=== COMBINED ({args.indicator}, all symbols) ===")
    print(f"\nPer-trade CSVs written to {out_dir.resolve()}")


if __name__ == "__main__":
    main()
