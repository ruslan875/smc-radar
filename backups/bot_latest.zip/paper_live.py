#!/usr/bin/env python3
"""
PAPER-ТРЕЙДИНГ 10 СТРАТЕГИЙ — живой терминальный монитор.

БЕЗОПАСНОСТЬ: этот скрипт НИКОГДА не отправляет ордера на биржу. Он вообще
не умеет этого делать — здесь нет ни одного вызова на создание ордера и не
читаются торговые ключи. Используются только ПУБЛИЧНЫЕ рыночные данные.
Никаких API-ключей не нужно.

КАК СЧИТАЮТСЯ СИГНАЛЫ (важно понимать):
Логика стратегий НЕ переписана заново. На каждом закрытии часового бара
скрипт вызывает ту же самую функцию run_backtest() из соответствующего
*_backtest.py на скользящем окне баров. То есть сигналы здесь по построению
совпадают с бэктестом — расхождение возможно только из-за данных, а не из-за
кода. Цена за это — пересчёт всего окна раз в час (несколько секунд).

ОТКРЫТАЯ ПОЗИЦИЯ: run_backtest() возвращает только закрытые сделки, но
принудительно закрывает последнюю позицию в конце данных с признаком
end_of_data / EOB. Такие строки трактуются как ОТКРЫТАЯ СЕЙЧАС позиция с
плавающим P&L, а не как реальное закрытие.

РАЗМЕР ПОЗИЦИИ: депозит стратегии делится на число её символов, чтобы
несколько одновременных позиций не требовали больше 100% депозита. В
бэктесте этого деления нет (там каждый символ считался отдельно на полном
депозите), поэтому проценты здесь будут меньше бэктестовых — это осознанно.

Запуск:
    python paper_live.py                      # все доступные стратегии
    python paper_live.py --only "Gaussian Channel" "High-Low Cloud"
    python paper_live.py --deposit 200 --poll-seconds 60
    python paper_live.py --once               # один проход и выход
"""

from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path

import warnings

import pandas as pd

# Предупреждения библиотек забивали экран и прятали саму таблицу.
# Ошибки это не скрывает: они ловятся отдельно и пишутся в paper_live_errors.log.
warnings.filterwarnings("ignore")

BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))

# Переменные Telegram живут в .env рядом со скриптом. Сами по себе в
# окружение процесса они не попадают — боевые боты проекта грузят их так же.
try:
    from dotenv import load_dotenv
    load_dotenv(BASE_DIR / ".env")
except Exception:
    pass

STATE_FILE = BASE_DIR / "paper_live_state.json"
TRADES_CSV = BASE_DIR / "paper_live_trades.csv"
ERROR_LOG = BASE_DIR / "paper_live_errors.log"
PID_FILE = BASE_DIR / "paper_live.pid"

DEFAULT_SYMBOLS = ["BTC/USDT", "ETH/USDT", "SOL/USDT"]
DEFAULT_TIMEFRAME = "1h"
DEFAULT_DEPOSIT = 200.0
DEFAULT_COMMISSION = 0.055
DEFAULT_SLIPPAGE = 0.03
WARMUP_BARS = 2000

# Признаки, которыми бэктест помечает принудительное закрытие в конце данных.
# Такая строка = позиция, открытая прямо сейчас.
OPEN_REASONS = {"end_of_data", "eob", "end", "open"}


# ----------------------------------------------------------------------------
# Адаптеры стратегий
# ----------------------------------------------------------------------------
# Каждый адаптер получает готовый DataFrame баров и возвращает DataFrame сделок
# в общей схеме. Внутри вызывается РОДНАЯ функция стратегии — ничего не
# дублируется и не переписывается.

def _adapt_gaussian(df, commission, slippage):
    import gaussian_channel_backtest as m
    sig = m.generate_signals(m.gaussian_channel(df, m.CONFIG), m.CONFIG)
    return m.run_backtest(sig, m.CONFIG, tp_pct=0.0, sl_pct=0.0,
                          commission_pct=commission, slippage_pct=slippage)


def _adapt_hlcloud(df, commission, slippage):
    import high_low_cloud_backtest as m
    sig = m.compute_signals(df, m.CONFIG)
    return m.run_backtest(sig, m.CONFIG, tp_pct=0.0, sl_pct=0.0,
                          commission_pct=commission, slippage_pct=slippage,
                          entry_next_open=False)


def _adapt_liqtherm(df, commission, slippage):
    import liq_therm_map_backtest as m
    return m.run_backtest(df, m.CONFIG, commission_pct=commission,
                          slippage_pct=slippage)


def _adapt_third_eye(df, commission, slippage):
    import third_eye_backtest as m
    sig = m.generate_signals(m.compute_indicators(df, m.CONFIG), m.CONFIG)
    return m.run_backtest(sig, m.CONFIG, commission_pct=commission,
                          slippage_pct=slippage)


def _adapt_combo_otm(df, commission, slippage):
    import combo_otm_backtest as m
    return m.run_backtest(df, m.CONFIG, commission_pct=commission,
                          slippage_pct=slippage)


def _adapt_pavlova(df, commission, slippage):
    import pavlova_backtest as m
    cfg = dict(m.DEFAULTS)
    sig = m.compute_signals(df, cfg, True, True, True, None)
    return m.run_backtest(sig, cfg, commission, slippage, False)


def _adapt_ce_zlsma(df, commission, slippage):
    import ce_zlsma_backtest as m
    cfg = dict(m.DEFAULTS)
    sig = m.compute_signals(df, cfg)
    return m.run_backtest(sig, cfg, commission, slippage, 0.0, False)


def _adapt_order_block(df, commission, slippage):
    import order_block_backtest as m
    cfg = dict(m.DEFAULTS)
    sig = m.compute_signals(df, cfg, False)
    return m.run_backtest(sig, cfg, commission, slippage, False)


def _adapt_rsi_connors(df, commission, slippage):
    import rsi_connors_backtest as m
    import pine_ta as ta
    cfg = dict(m.DEFAULTS)
    # EMA старшего ТФ берём с рабочего ТФ: отдельный 15m-фид сюда не заводим,
    # ровно как это делает бэктест, когда 15m-данные недоступны.
    ema_series = ta.ema(df["close"], cfg["ema_len"])
    sig = m.compute_signals(df, cfg, ema_series)
    return m.run_backtest(sig, cfg, commission, slippage, False)


def _adapt_hype_r4(df, commission, slippage, symbol="PAPER"):
    import hype_r4_backtest as m
    cfg_path = _find_hype_config()
    if cfg_path is None:
        raise FileNotFoundError("R4_OKX_HYPE_1H.csv не найден")
    config = m.load_config_from_csv(str(cfg_path))
    strategy = m.HypeR4Strategy(config)
    return m.backtest_symbol(symbol, df.copy(), strategy, commission, slippage)


def _find_hype_config():
    for name in ("R4_OKX_HYPE_1H.csv", "strategies/R4_OKX_HYPE_1H.csv"):
        p = BASE_DIR / name
        if p.exists():
            return p
    hits = list(BASE_DIR.glob("**/R4_OKX_HYPE*.csv"))
    return hits[0] if hits else None


STRATEGIES = [
    # (имя, модуль для проверки наличия, адаптер, символы)
    ("Gaussian Channel", "gaussian_channel_backtest", _adapt_gaussian, None),
    ("High-Low Cloud", "high_low_cloud_backtest", _adapt_hlcloud, None),
    ("LiqTherm MAP", "liq_therm_map_backtest", _adapt_liqtherm, ["BTC/USDT", "ETH/USDT"]),
    ("Third Eye", "third_eye_backtest", _adapt_third_eye, None),
    ("Combo OTM", "combo_otm_backtest", _adapt_combo_otm, None),
    ("Pavlova", "pavlova_backtest", _adapt_pavlova, None),
    ("CE ZLSMA", "ce_zlsma_backtest", _adapt_ce_zlsma, None),
    ("Order Block", "order_block_backtest", _adapt_order_block, None),
    ("RSI Connors", "rsi_connors_backtest", _adapt_rsi_connors, None),
    ("HYPE R4", "hype_r4_backtest", _adapt_hype_r4, None),
]


# ----------------------------------------------------------------------------
# Данные
# ----------------------------------------------------------------------------

def load_bars(symbol, timeframe, bars, exchange_id, market):
    """Свежие бары через штатный загрузчик проекта (публичные данные)."""
    import market_data
    hours = {"1h": 1, "15m": 0.25, "4h": 4}.get(timeframe, 1)
    span_days = int(bars * hours / 24) + 10
    start = (pd.Timestamp.now('UTC') - pd.Timedelta(days=span_days)).strftime("%Y-%m-%d")
    end = (pd.Timestamp.now('UTC') + pd.Timedelta(days=1)).strftime("%Y-%m-%d")

    df = market_data.load_ohlcv(symbol, timeframe, start, end,
                                exchange_id=exchange_id, market=market)
    if df is None or len(df) == 0:
        return None

    df = df.copy()
    if "time" in df.columns:
        df["time"] = pd.to_datetime(df["time"], utc=True)
        df = df.sort_values("time").reset_index(drop=True)
        df = df.set_index("time", drop=False)
    elif isinstance(df.index, pd.DatetimeIndex):
        df.index = pd.to_datetime(df.index, utc=True)
        df = df.sort_index()
        df["time"] = df.index
    else:
        raise ValueError(f"{symbol}: нет ни колонки time, ни DatetimeIndex")

    # Последний бар может быть ещё не закрыт — его отбрасываем, чтобы не
    # торговать по незавершённой свече.
    if len(df) > 1:
        df = df.iloc[:-1]
    return df.tail(bars)


# ----------------------------------------------------------------------------
# Разбор результатов стратегии
# ----------------------------------------------------------------------------

def split_deals(deals_df):
    """Делит результат бэктеста на закрытые сделки и открытую позицию."""
    if deals_df is None or len(deals_df) == 0:
        return [], None

    rows = deals_df.to_dict("records")
    closed, open_pos = [], None

    last = rows[-1]
    reason = str(last.get("reason", "")).strip().lower()
    if reason in OPEN_REASONS:
        open_pos = last
        rows = rows[:-1]

    for r in rows:
        closed.append(r)
    return closed, open_pos


def deal_key(symbol, row):
    """Стабильный идентификатор сделки, чтобы не логировать её дважды."""
    return f"{symbol}|{row.get('entry_time')}|{row.get('exit_time')}|{row.get('side')}"


def to_float(v, default=0.0):
    try:
        f = float(v)
        return default if pd.isna(f) else f
    except (TypeError, ValueError):
        return default


# ----------------------------------------------------------------------------
# Состояние
# ----------------------------------------------------------------------------

def load_state():
    if STATE_FILE.exists():
        try:
            return json.loads(STATE_FILE.read_text(encoding="utf-8"))
        except Exception:
            pass
    return {"strategies": {}, "started": datetime.now(timezone.utc).isoformat()}


def forward_start(state):
    """Момент, с которого этот форвард-тест считает сделки своими.

    Одного множества «уже виденных» ключей мало: размер окна влияет на прогрев
    индикаторов, поэтому тот же участок истории, пересчитанный на окне другой
    длины, даёт сделки с другими ценами и временами — то есть другие ключи, и
    они проходят как новые. Именно так в первый день в журнал попали 32 сделки
    с датами выхода 5–18 сентября, залогированные 21-го. Время закрытия сделки
    от длины окна не зависит, поэтому отсекаем по нему."""
    raw = state.get("forward_start") or state.get("started")
    if not raw:
        return None
    try:
        ts = pd.Timestamp(raw)
        return ts.tz_localize("UTC") if ts.tzinfo is None else ts.tz_convert("UTC")
    except Exception:
        return None


def save_state(state):
    tmp = STATE_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(state, indent=2, default=str), encoding="utf-8")
    tmp.replace(STATE_FILE)


def log_trade(row):
    new = not TRADES_CSV.exists()
    fields = ["logged_at", "strategy", "symbol", "side", "entry_time",
              "exit_time", "entry_price", "exit_price", "pnl_pct",
              "pnl_usd", "reason"]
    with TRADES_CSV.open("a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        if new:
            w.writeheader()
        w.writerow({k: row.get(k, "") for k in fields})


def pid_alive(pid):
    """Жив ли процесс с таким PID. Без внешних зависимостей: psutil в этом
    окружении может не стоять, а ошибиться здесь — значит либо отказать в
    запуске впустую, либо пустить второй процесс к общему файлу состояния."""
    if pid <= 0:
        return False
    if os.name == "nt":
        import ctypes
        PROCESS_QUERY_LIMITED = 0x1000
        STILL_ACTIVE = 259
        k = ctypes.windll.kernel32
        h = k.OpenProcess(PROCESS_QUERY_LIMITED, False, int(pid))
        if not h:
            return False
        try:
            code = ctypes.c_ulong()
            if k.GetExitCodeProcess(h, ctypes.byref(code)):
                return code.value == STILL_ACTIVE
            return True
        finally:
            k.CloseHandle(h)
    try:
        os.kill(int(pid), 0)
        return True
    except (OSError, ProcessLookupError):
        return False


def check_single_instance():
    """Два монитора на один paper_live_state.json перетирают счёт друг друга
    и пишут вперемешку в общий лог. Один раз это уже случилось: старая копия
    скрипта не вела pid-файл, stop_paper.bat её не нашёл, и рядом поднялся
    второй процесс."""
    if not PID_FILE.exists():
        return True
    try:
        old = int(PID_FILE.read_text(encoding="utf-8").strip())
    except Exception:
        return True
    if not pid_alive(old):
        return True   # остался от процесса, которого уже нет

    print(f"ОТКАЗ: paper_live уже запущен, PID {old}.\n"
          f"  Два процесса пишут в один paper_live_state.json и портят счёт.\n"
          f"  Останови прежний (stop_paper.bat) либо смотри его: "
          f"paper_status.bat")
    return False


def make_notifier(enabled):
    """Telegram-уведомления через тот же клиент и те же переменные окружения
    (TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID из .env), что и боевые боты проекта.
    Новых ключей не нужно. Любая ошибка отправки не должна ронять монитор."""
    def _noop(_msg):
        return None

    if not enabled:
        return _noop

    token = os.environ.get("TELEGRAM_BOT_TOKEN")
    chat_id = os.environ.get("TELEGRAM_CHAT_ID")
    if not token or not chat_id:
        print("[TELEGRAM] алерты запрошены, но TELEGRAM_BOT_TOKEN/TELEGRAM_CHAT_ID "
              "не заданы — отключены.")
        return _noop

    try:
        from app.telegram_client import TelegramClient
        client = TelegramClient(token, chat_id)
    except Exception as exc:
        print(f"[TELEGRAM] клиент недоступен ({exc}) — алерты отключены.")
        return _noop

    def notify(msg):
        # Три попытки с паузой: за первые сутки ВСЕ пять отправок упали по
        # таймауту соединения, хотя api.telegram.org с этой же машины
        # отвечает за доли секунды. Причина плавающая, но терять из-за неё
        # уведомление о сделке нельзя — сделка уже произошла и не повторится.
        try:  # 2026-09-24: /notify в Telegram может выключить paper-уведомления
            from app import notify_prefs
            if not notify_prefs.is_enabled("paper"):
                return
        except Exception:  # noqa: BLE001 -- настройки не читаются -> шлём как раньше
            pass
        try:  # 2026-10-10: старые порты — в бумажный канал, компактно, с хэштегом
            import sys as _s, pathlib as _p  # noqa: PLC0415
            _s.path.insert(0, str(_p.Path(__file__).resolve().parent))
            from windows_app import risk_center as _rc  # noqa: PLC0415
            if _rc.tg_send(f"🧪 {msg}\n#Paper10 · старые порты", channel="paper") is not None:
                return
        except Exception:  # noqa: BLE001
            pass
        last = None
        for attempt in (1, 2, 3):
            try:
                client.send_message(f"{msg}\n<i>paper · симуляция</i>")
                if attempt > 1:
                    print(f"[TELEGRAM] отправлено с попытки {attempt}")
                return
            except Exception as exc:
                last = exc
                if attempt < 3:
                    time.sleep(3)
        print(f"[TELEGRAM] не отправлено за 3 попытки (не критично): {last}",
              file=sys.stderr)

    print("[TELEGRAM] алерты включены.")
    return notify


def format_trade_alert(rec):
    p = to_float(rec.get("pnl_pct"))
    mark = "\u2705" if p > 0 else "\u274c"
    side = "LONG" if str(rec.get("side", "")).lower().startswith("l") else "SHORT"
    return (f"{mark} <b>{rec['symbol']}</b> {side} {p:+.2f}% "
            f"({to_float(rec.get('pnl_usd')):+.2f}$)\n"
            f"{rec['strategy']} · выход: {rec.get('reason', '')}")


def format_daily_report(state, cfg):
    rows, tot_dep, tot_eq, tot_trades = [], 0.0, 0.0, 0
    for name, _m, _f, _s in STRATEGIES:
        st = state["strategies"].get(name)
        if not st:
            continue
        tot_dep += st["deposit"]
        tot_eq += st["equity"]
        tot_trades += st["closed_count"]
        if st["closed_count"] or st.get("open"):
            pnl = st["equity"] - st["deposit"]
            rows.append(f"{name}: {pnl:+.2f}$ · {st['closed_count']} сд. · "
                        f"win {st['win_rate']:.0f}%")
    ret = (tot_eq / tot_dep - 1) * 100 if tot_dep else 0.0
    head = (f"<b>Paper · сводка за сутки</b>\n"
            f"Капитал ${tot_eq:,.2f} из ${tot_dep:,.0f} ({ret:+.2f}%), "
            f"сделок {tot_trades}")
    return head + ("\n\n" + "\n".join(rows) if rows else "\n\nСделок пока не было.")


# ----------------------------------------------------------------------------
# Веб-страница с результатами
# ----------------------------------------------------------------------------
# Панель управления рисует свой список из собранного бандла, пересобрать
# который нечем. Поэтому монитор отдаёт собственную страницу: вкладка в
# браузере рядом с панелью, живые цифры по каждой стратегии.

PAGE = """<!doctype html>
<html lang="ru"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Paper — 10 стратегий</title>
<style>
:root{--bg:#050810;--card:#0d1424;--line:#1c2740;--tx:#dbe4f5;--dim:#7c8aa5;
--up:#34d399;--dn:#f87171;--ac:#22d3ee;--warn:#fbbf24}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--tx);
font:14px/1.5 "Segoe UI",system-ui,sans-serif;padding:20px}
h1{font-size:17px;margin:0 0 2px;letter-spacing:.5px}
.sub{color:var(--dim);font-size:12px;margin-bottom:18px}
.tot{display:flex;gap:26px;flex-wrap:wrap;background:var(--card);
border:1px solid var(--line);border-radius:10px;padding:14px 18px;margin-bottom:16px}
.tot div{min-width:92px}
.tot b{display:block;font-size:21px;font-variant-numeric:tabular-nums}
.tot small{color:var(--dim);font-size:11px;text-transform:uppercase;letter-spacing:.6px}
table{width:100%;border-collapse:collapse;background:var(--card);
border:1px solid var(--line);border-radius:10px;overflow:hidden}
th{text-align:left;font-size:11px;color:var(--dim);text-transform:uppercase;
letter-spacing:.6px;padding:10px 12px;border-bottom:1px solid var(--line);font-weight:600}
td{padding:11px 12px;border-bottom:1px solid rgba(28,39,64,.5);
font-variant-numeric:tabular-nums}
tr:last-child td{border-bottom:none}
.num{text-align:right}
.up{color:var(--up)} .dn{color:var(--dn)} .dim{color:var(--dim)}
.pill{display:inline-block;padding:2px 8px;border-radius:99px;font-size:11px;
border:1px solid var(--line)}
.on{color:var(--warn);border-color:rgba(251,191,36,.4)}
.off{color:var(--dim)}
.pos{font-size:12px;color:var(--dim)}
.err{color:var(--dn);font-size:12px}
h2{font-size:12px;color:var(--dim);text-transform:uppercase;letter-spacing:.6px;
margin:22px 0 8px}
@media(max-width:640px){body{padding:12px}.hide{display:none}}
</style></head><body>
<h1>PAPER — 10 стратегий</h1>
<div class="sub" id="sub">загрузка…</div>
<div class="tot" id="tot"></div>
<table><thead><tr><th>Стратегия</th><th>Статус</th><th class="hide">Позиции</th>
<th class="num">Сделок</th><th class="num">Win</th><th class="num">P&amp;L $</th>
<th class="num">Доход</th></tr></thead><tbody id="rows"></tbody></table>
<h2>Последние сделки</h2>
<table><thead><tr><th>Время</th><th>Стратегия</th><th>Пара</th><th>Сторона</th>
<th class="num">P&amp;L</th><th class="hide">Выход</th></tr></thead>
<tbody id="tr"></tbody></table>
<script>
const f=(v,d=2)=>(v>=0?"+":"")+v.toFixed(d);
const cls=v=>v>0?"up":v<0?"dn":"dim";
async function tick(){
 let d; try{d=await (await fetch("/api",{cache:"no-store"})).json()}catch(e){return}
 document.getElementById("sub").textContent=
   "обновлено "+(d.last_update||"").slice(0,19).replace("T"," ")+" UTC · старт теста "+
   (d.forward_start||"").slice(0,19).replace("T"," ")+" · депозит $200 на стратегию";
 const t=d.totals;
 document.getElementById("tot").innerHTML=
  `<div><small>Капитал</small><b>$${t.equity.toFixed(2)}</b></div>
   <div><small>P&L</small><b class="${cls(t.pnl)}">${f(t.pnl)}$</b></div>
   <div><small>Доходность</small><b class="${cls(t.ret)}">${f(t.ret)}%</b></div>
   <div><small>Сделок</small><b>${t.trades}</b></div>
   <div><small>В рынке</small><b>${t.open}</b></div>`;
 document.getElementById("rows").innerHTML=d.rows.map(r=>{
  if(r.error)return `<tr><td>${r.name}</td><td colspan="6" class="err">${r.error}</td></tr>`;
  const pos=r.open.map(o=>`${o.sym} ${o.side} <span class="${cls(o.pnl)}">${f(o.pnl,1)}%</span>`).join("<br>")||"<span class=dim>—</span>";
  return `<tr><td>${r.name}</td>
   <td><span class="pill ${r.open.length?"on":"off"}">${r.open.length?"в рынке":"ждёт"}</span></td>
   <td class="pos hide">${pos}</td>
   <td class="num">${r.trades}</td>
   <td class="num">${r.trades?r.win.toFixed(0)+"%":"<span class=dim>—</span>"}</td>
   <td class="num ${cls(r.pnl)}">${f(r.pnl)}</td>
   <td class="num ${cls(r.ret)}">${f(r.ret)}%</td></tr>`}).join("");
 document.getElementById("tr").innerHTML=d.trades.length?d.trades.map(x=>
  `<tr><td class="dim">${(x.exit_time||"").slice(0,16)}</td><td>${x.strategy}</td>
   <td>${x.symbol}</td><td>${x.side}</td>
   <td class="num ${cls(x.pnl_pct)}">${f(x.pnl_pct)}%</td>
   <td class="dim hide">${x.reason||""}</td></tr>`).join("")
  :`<tr><td colspan="6" class="dim">Сделок после старта теста пока не было.</td></tr>`;
}
tick();setInterval(tick,20000);
</script></body></html>"""


def build_payload():
    """Состояние для страницы — читаем тот же файл, что пишет основной цикл."""
    st = load_state()
    rows, t_dep, t_eq, t_tr, t_op = [], 0.0, 0.0, 0, 0
    for name, _m, _f, _s in STRATEGIES:
        v = st.get("strategies", {}).get(name)
        if v is None:
            continue
        dep = v.get("deposit", 0.0) or 0.0
        eq = v.get("equity", dep)
        t_dep += dep
        t_eq += eq
        t_tr += v.get("closed_count", 0)
        opens = [{"sym": s.split("/")[0],
                  "side": "LONG" if str(p.get("side", "")).lower().startswith("l") else "SHORT",
                  "pnl": to_float(p.get("pnl_pct"))}
                 for s, p in (v.get("open") or {}).items()]
        t_op += len(opens)
        rows.append({
            "name": name, "error": v.get("error"),
            "trades": v.get("closed_count", 0), "win": v.get("win_rate", 0.0),
            "pnl": eq - dep, "ret": (eq / dep - 1) * 100 if dep else 0.0,
            "open": opens,
        })
    return {
        "last_update": st.get("last_update", ""),
        "forward_start": st.get("forward_start", st.get("started", "")),
        "totals": {"equity": t_eq, "pnl": t_eq - t_dep,
                   "ret": (t_eq / t_dep - 1) * 100 if t_dep else 0.0,
                   "trades": t_tr, "open": t_op},
        "rows": rows,
        "trades": list(reversed(st.get("recent_trades", [])))[:15],
    }


def start_web(port):
    """Страница поднимается в отдельном потоке и только читает файл состояния —
    на торговую логику повлиять не может. Слушаем 127.0.0.1: наружу не торчит."""
    import json as _json
    import threading
    from http.server import BaseHTTPRequestHandler, HTTPServer

    class H(BaseHTTPRequestHandler):
        def do_GET(self):
            if self.path.startswith("/api"):
                body = _json.dumps(build_payload(), default=str).encode("utf-8")
                ctype = "application/json; charset=utf-8"
            else:
                body = PAGE.encode("utf-8")
                ctype = "text/html; charset=utf-8"
            self.send_response(200)
            self.send_header("Content-Type", ctype)
            self.send_header("Content-Length", str(len(body)))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, *a):
            return   # не засоряем paper_live.log обращениями браузера

    # Порт по умолчанию может быть занят соседом по проекту (8766, например,
    # слушает main.py). Молча остаться без страницы хуже, чем взять
    # следующий свободный, поэтому пробуем несколько подряд.
    srv = None
    for candidate in range(port, port + 6):
        try:
            srv = HTTPServer(("127.0.0.1", candidate), H)
            port = candidate
            break
        except OSError:
            continue

    if srv is None:
        print(f"[WEB] порты {port}..{port + 5} заняты — страница не поднята.")
        return

    threading.Thread(target=srv.serve_forever, daemon=True).start()
    print(f"[WEB] СТРАНИЦА РЕЗУЛЬТАТОВ: http://127.0.0.1:{port}")


def log_error(name, exc):
    with ERROR_LOG.open("a", encoding="utf-8") as f:
        f.write(f"\n{'=' * 70}\n{datetime.now(timezone.utc).isoformat()} — {name}\n")
        f.write(traceback.format_exc())


# ----------------------------------------------------------------------------
# Дашборд
# ----------------------------------------------------------------------------

C = {
    "reset": "\033[0m", "bold": "\033[1m", "dim": "\033[2m",
    "green": "\033[92m", "red": "\033[91m", "yellow": "\033[93m",
    "cyan": "\033[96m", "grey": "\033[90m", "white": "\033[97m",
}


def _supports_color():
    if os.name == "nt":
        try:
            import colorama  # noqa: F401
            colorama.just_fix_windows_console()
            return True
        except Exception:
            # Windows 10+ понимает ANSI после включения VT-режима
            try:
                import ctypes
                k = ctypes.windll.kernel32
                k.SetConsoleMode(k.GetStdHandle(-11), 7)
                return True
            except Exception:
                return False
    return sys.stdout.isatty()


COLOR = _supports_color()


def c(text, color):
    if not COLOR:
        return str(text)
    return f"{C.get(color, '')}{text}{C['reset']}"


def money(v):
    s = f"{v:+.2f}"
    return c(s, "green" if v > 0 else "red" if v < 0 else "grey")


def pct(v):
    s = f"{v:+.2f}%"
    return c(s, "green" if v > 0 else "red" if v < 0 else "grey")


def clear_screen():
    sys.stdout.write("\033[2J\033[H" if COLOR else "\n" * 3)


def render(state, cfg, last_update, next_update, cycle_info):
    clear_screen()
    strategies = state["strategies"]

    total_dep = sum(s["deposit"] for s in strategies.values())
    total_eq = sum(s["equity"] for s in strategies.values())
    total_pnl = total_eq - total_dep
    total_trades = sum(s["closed_count"] for s in strategies.values())
    total_open = sum(len(s.get("open", {})) for s in strategies.values())

    w = 104
    print(c("═" * w, "cyan"))
    title = "  PAPER TRADING — 10 СТРАТЕГИЙ  ·  СИМУЛЯЦИЯ, РЕАЛЬНЫЕ ОРДЕРА НЕ ОТПРАВЛЯЮТСЯ  "
    print(c(title, "bold"))
    print(c("═" * w, "cyan"))

    print(f"  {c('Обновлено:', 'grey')} {last_update}   "
          f"{c('Следующий расчёт:', 'grey')} {next_update}   "
          f"{c('ТФ:', 'grey')} {cfg['timeframe']}   "
          f"{c('Биржа:', 'grey')} {cfg['exchange']} (публичные данные)")
    if cycle_info:
        print(f"  {c(cycle_info, 'dim' if COLOR else 'grey')}")
    print(c("─" * w, "grey"))

    hdr = (f"  {'СТРАТЕГИЯ':<18} {'СТАТУС':<10} {'ПОЗИЦИИ':<22} "
           f"{'СДЕЛОК':>7} {'WIN':>6} {'P&L $':>10} {'ДОХОД':>9}")
    print(c(hdr, "bold"))
    print(c("─" * w, "grey"))

    for name, _mod, _fn, _syms in STRATEGIES:
        s = strategies.get(name)
        if s is None:
            print(f"  {name:<18} {c('нет', 'grey'):<10}")
            continue

        if s.get("error"):
            print(f"  {name:<18} {c('ОШИБКА', 'red')}     "
                  f"{c(str(s['error'])[:60], 'grey')}")
            continue

        open_pos = s.get("open", {})
        if open_pos:
            parts = []
            for sym, p in list(open_pos.items())[:2]:
                tag = "L" if str(p["side"]).lower().startswith("l") else "S"
                col = "green" if p["pnl_pct"] > 0 else "red"
                parts.append(f"{sym.split('/')[0]}{c(tag, col)} {p['pnl_pct']:+.1f}%")
            pos_str = " ".join(parts)
            if len(open_pos) > 2:
                pos_str += f" +{len(open_pos) - 2}"
            while len(_strip_ansi(pos_str)) > 22 and len(parts) > 1:
                parts.pop()
                pos_str = " ".join(parts) + f" +{len(open_pos) - len(parts)}"
            status = c("В РЫНКЕ", "yellow")
        else:
            pos_str = c("—", "grey")
            status = c("ждёт", "grey")

        wr = s["win_rate"]
        wr_str = c(f"{wr:.0f}%", "green" if wr >= 50 else "yellow" if wr >= 35 else "red")
        pnl_usd = s["equity"] - s["deposit"]
        ret = (s["equity"] / s["deposit"] - 1) * 100 if s["deposit"] else 0.0

        # Видимая ширина строки с цветами больше реальной, поэтому колонку
        # позиций выравниваем вручную по длине без escape-последовательностей.
        raw_len = len(pos_str) - (len(pos_str) - len(_strip_ansi(pos_str)))
        pad = " " * max(0, 22 - raw_len)

        print(f"  {name:<18} {status:<{10 + _ansi_pad(status)}} {pos_str}{pad} "
              f"{s['closed_count']:>7} {wr_str:>{6 + _ansi_pad(wr_str)}} "
              f"{money(pnl_usd):>{10 + _ansi_pad(money(pnl_usd))}} "
              f"{pct(ret):>{9 + _ansi_pad(pct(ret))}}")

    print(c("─" * w, "grey"))
    tot_ret = (total_eq / total_dep - 1) * 100 if total_dep else 0.0
    print(f"  {c('ИТОГО', 'bold'):<{18 + _ansi_pad(c('ИТОГО', 'bold'))}} "
          f"депозит ${total_dep:,.0f}   капитал ${total_eq:,.2f}   "
          f"P&L {money(total_pnl)}   {pct(tot_ret)}   "
          f"сделок {total_trades}   в рынке {total_open}")
    print(c("═" * w, "cyan"))

    recent = state.get("recent_trades", [])[-5:]
    if recent:
        print(c("  ПОСЛЕДНИЕ СДЕЛКИ", "bold"))
        for t in reversed(recent):
            p = to_float(t.get("pnl_pct"))
            mark = c("✓", "green") if p > 0 else c("✗", "red")
            when = str(t.get("exit_time", ""))[:16]
            print(f"   {mark} {when}  {t['strategy']:<17} {t['symbol']:<9} "
                  f"{str(t['side']).upper():<5} {pct(p)}  "
                  f"{c(str(t.get('reason', '')), 'grey')}")
        print(c("═" * w, "cyan"))

    print(c("  Ctrl+C — выход.  Состояние: paper_live_state.json · "
            "сделки: paper_live_trades.csv", "grey"))


def _strip_ansi(s):
    out, i = [], 0
    while i < len(s):
        if s[i] == "\033":
            while i < len(s) and s[i] != "m":
                i += 1
            i += 1
        else:
            out.append(s[i])
            i += 1
    return "".join(out)


def _ansi_pad(s):
    return len(s) - len(_strip_ansi(s))


# ----------------------------------------------------------------------------
# Основной цикл
# ----------------------------------------------------------------------------

def run_cycle(state, cfg, bars_cache, notify=None):
    """Один полный пересчёт всех стратегий."""
    now = datetime.now(timezone.utc)

    for name, module_name, adapter, own_symbols in STRATEGIES:
        if cfg["only"] and name not in cfg["only"]:
            continue

        symbols = own_symbols or cfg["symbols"]
        st = state["strategies"].setdefault(name, {
            "deposit": cfg["deposit"], "equity": cfg["deposit"],
            "closed_count": 0, "wins": 0, "win_rate": 0.0,
            "seen": [], "open": {}, "error": None, "baselined": False,
        })
        st["deposit"] = cfg["deposit"]
        st["error"] = None

        # Размер одной позиции: депозит делится между символами стратегии.
        per_symbol = cfg["deposit"] / max(1, len(symbols))
        seen = set(st.get("seen", []))
        open_now = {}
        # Первый проход: сделки, уже лежащие в окне истории, произошли ДО старта
        # paper-теста. Их помечаем как виденные, но в P&L не берём — иначе счёт
        # стартовал бы с чужим результатом вместо чистого депозита.
        baseline = not st.get("baselined", False)
        cutoff = forward_start(state)

        try:
            for sym in symbols:
                df = bars_cache.get(sym)
                if df is None or len(df) < 200:
                    continue

                if name == "HYPE R4":
                    deals = adapter(df, cfg["commission"], cfg["slippage"], sym)
                else:
                    deals = adapter(df, cfg["commission"], cfg["slippage"])

                closed, open_pos = split_deals(deals)

                for row in closed:
                    k = deal_key(sym, row)
                    if k in seen:
                        continue
                    seen.add(k)
                    if baseline:
                        continue

                    # Сделка, закрывшаяся до старта теста, — это история,
                    # всплывшая из-за другого размера окна, а не наш результат.
                    if cutoff is not None:
                        try:
                            xt = pd.Timestamp(row.get("exit_time"))
                            xt = (xt.tz_localize("UTC") if xt.tzinfo is None
                                  else xt.tz_convert("UTC"))
                            if xt < cutoff:
                                continue
                        except Exception:
                            pass

                    p = to_float(row.get("gross_pnl_pct"))
                    pnl_usd = per_symbol * p / 100.0
                    st["equity"] += pnl_usd
                    st["closed_count"] += 1
                    if p > 0:
                        st["wins"] += 1

                    rec = {
                        "logged_at": now.isoformat(),
                        "strategy": name, "symbol": sym,
                        "side": row.get("side"),
                        "entry_time": row.get("entry_time"),
                        "exit_time": row.get("exit_time"),
                        "entry_price": row.get("entry_price"),
                        "exit_price": row.get("exit_price"),
                        "pnl_pct": round(p, 4),
                        "pnl_usd": round(pnl_usd, 4),
                        "reason": row.get("reason"),
                    }
                    log_trade(rec)
                    state.setdefault("recent_trades", []).append(rec)
                    if notify is not None:
                        notify(format_trade_alert(rec))

                if open_pos is not None:
                    open_now[sym] = {
                        "side": open_pos.get("side"),
                        "entry_price": to_float(open_pos.get("entry_price")),
                        "entry_time": str(open_pos.get("entry_time")),
                        "pnl_pct": to_float(open_pos.get("gross_pnl_pct")),
                    }

            st["open"] = open_now
            st["baselined"] = True
            st["seen"] = sorted(seen)[-4000:]
            st["win_rate"] = (100.0 * st["wins"] / st["closed_count"]
                              if st["closed_count"] else 0.0)

        except Exception as exc:
            st["error"] = f"{type(exc).__name__}: {exc}"
            log_error(name, exc)

    state.setdefault("forward_start", now.isoformat())
    state["recent_trades"] = state.get("recent_trades", [])[-50:]
    state["last_update"] = now.isoformat()
    return state


def main():
    p = argparse.ArgumentParser(
        description="Paper-трейдинг 10 стратегий с живым монитором в терминале",
        formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--symbols", nargs="+", default=DEFAULT_SYMBOLS)
    p.add_argument("--timeframe", default=DEFAULT_TIMEFRAME)
    p.add_argument("--deposit", type=float, default=DEFAULT_DEPOSIT,
                   help="депозит НА КАЖДУЮ стратегию, по умолчанию 200")
    p.add_argument("--commission", type=float, default=DEFAULT_COMMISSION)
    p.add_argument("--slippage", type=float, default=DEFAULT_SLIPPAGE)
    p.add_argument("--bars", type=int, default=WARMUP_BARS)
    p.add_argument("--poll-seconds", type=int, default=300)
    p.add_argument("--exchange", default="bybit")
    p.add_argument("--market", default="swap")
    p.add_argument("--only", nargs="+", default=None,
                   help="запустить только указанные стратегии")
    p.add_argument("--once", action="store_true", help="один проход и выход")
    p.add_argument("--reset", action="store_true", help="сбросить состояние")
    p.add_argument("--telegram", action="store_true",
                   help="слать алерты в Telegram (ключи берутся из .env)")
    p.add_argument("--daily-report-hour", type=int, default=9,
                   help="час UTC для суточной сводки в Telegram; -1 отключает")
    p.add_argument("--status", action="store_true",
                   help="напечатать текущее состояние из файла и выйти "
                        "(для фонового режима — ничего не пересчитывает)")
    p.add_argument("--web-port", type=int, default=8780,
                   help="порт страницы с результатами; 0 — не поднимать. "
                        "8766 намеренно не берём: это порт main.py, и paper "
                        "однажды занял его, пока Telegram-бот был остановлен")
    p.add_argument("--log-file", default=None,
                   help="дублировать вывод в файл; нужен для запуска через "
                        "pythonw.exe, у которого нет консоли")
    p.add_argument("--no-dashboard", action="store_true",
                   help="без перерисовки экрана: только строки событий "
                        "(для запуска в фоне с перенаправлением в лог)")
    args = p.parse_args()

    # Режим просмотра: читаем то, что записал фоновый процесс, и выходим.
    # Ничего не считаем и не трогаем — файл состояния только читается.
    if args.status:
        st = load_state()
        if not st.get("strategies"):
            print("Состояния пока нет: paper_live_state.json не найден или пуст.\n"
                  "Похоже, фоновый процесс ещё не отработал первый цикл.")
            return
        upd = str(st.get("last_update", "?"))[:19].replace("T", " ")
        render(st, {"timeframe": args.timeframe, "exchange": args.exchange},
               upd + " UTC", "—", "снимок из paper_live_state.json")
        return

    # pythonw.exe запускается без консоли: без этого весь вывод пропал бы.
    if args.log_file:
        log_path = Path(args.log_file)
        if not log_path.is_absolute():
            log_path = BASE_DIR / log_path
        stream = open(log_path, "a", encoding="utf-8", buffering=1)
        sys.stdout = stream
        sys.stderr = stream
        print(f"\n{'=' * 70}\n"
              f"{datetime.now(timezone.utc).isoformat()} — запуск paper_live",
              flush=True)

    if not check_single_instance():
        return

    # Свой PID на диск: stop_paper.bat останавливает именно этот процесс,
    # а не все pythonw.exe в системе — среди них могут быть чужие.
    try:
        PID_FILE.write_text(str(os.getpid()), encoding="utf-8")
    except Exception:
        pass

    if args.reset:
        if STATE_FILE.exists():
            STATE_FILE.unlink()
        # Журнал сделок не удаляем, а отводим в сторону: он мог содержать
        # и настоящие сделки. Смешивать его со свежим счётом нельзя —
        # получится журнал, по которому нельзя посчитать ни один итог.
        if TRADES_CSV.exists():
            stamp = datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S")
            backup = TRADES_CSV.with_name(f"{TRADES_CSV.stem}.{stamp}.bak.csv")
            TRADES_CSV.replace(backup)
            print(f"Прежний журнал сохранён как {backup.name}")
        print("Состояние сброшено, счёт начнётся с чистого депозита.")

    cfg = {
        "symbols": args.symbols, "timeframe": args.timeframe,
        "deposit": args.deposit, "commission": args.commission,
        "slippage": args.slippage, "exchange": args.exchange,
        "market": args.market, "only": set(args.only) if args.only else None,
    }

    state = load_state()

    # Смена длины окна меняет прогрев индикаторов, а значит и сами сделки.
    # Молча это делать нельзя — именно так в журнал попала чужая история.
    prev_bars = state.get("bars")
    if prev_bars is not None and prev_bars != args.bars:
        print(f"ВНИМАНИЕ: окно изменилось с {prev_bars} на {args.bars} баров.\n"
              f"  От длины окна зависит прогрев индикаторов, поэтому сделки\n"
              f"  пересчитаются иначе. Прошлые результаты с новыми несравнимы.\n"
              f"  Если это не нарочно — запусти с прежним --bars {prev_bars};\n"
              f"  если нарочно — лучше начать чисто: --reset\n")
    state["bars"] = args.bars

    notify = make_notifier(args.telegram)

    if args.web_port:
        start_web(args.web_port)

    # Сообщение на старте: сразу видно, пробивается ли отправка из фонового
    # процесса. Ждать для этого сделку нельзя — они редкие, а отправки за
    # первые сутки падали все до единой, причём только из-под pythonw.exe.
    if args.telegram:
        notify(f"Paper-монитор запущен: {len(STRATEGIES)} стратегий, "
               f"${args.deposit:.0f} на каждую.\n"
               f"Результаты: http://127.0.0.1:{args.web_port}")

    print("Загружаю историю (прогрев индикаторов)...")
    while True:
        try:
            bars_cache = {}
            need = set(cfg["symbols"])
            for _n, _m, _f, own in STRATEGIES:
                if own:
                    need.update(own)
            for sym in sorted(need):
                try:
                    df = load_bars(sym, cfg["timeframe"], args.bars,
                                   cfg["exchange"], cfg["market"])
                    bars_cache[sym] = df
                    if df is not None:
                        print(f"  {sym:<10} {len(df):>5} баров, последний "
                              f"{df.index[-1]}")
                    else:
                        print(f"  {sym:<10} нет данных")
                except Exception as exc:
                    print(f"  {sym:<10} ошибка: {exc}")
                    log_error(f"load {sym}", exc)
                    bars_cache[sym] = None

            t0 = time.time()
            trades_before = sum(v["closed_count"]
                                for v in state["strategies"].values())
            state = run_cycle(state, cfg, bars_cache, notify)
            elapsed = time.time() - t0

            now = datetime.now(timezone.utc)

            # Суточная сводка: один раз в назначенный час UTC.
            if args.telegram and args.daily_report_hour >= 0:
                stamp = now.strftime("%Y-%m-%d")
                if (now.hour == args.daily_report_hour
                        and state.get("last_daily_report") != stamp):
                    notify(format_daily_report(state, cfg))
                    state["last_daily_report"] = stamp

            save_state(state)

            if args.no_dashboard:
                new = sum(v["closed_count"]
                          for v in state["strategies"].values()) - trades_before
                eq = sum(v["equity"] for v in state["strategies"].values())
                opn = sum(len(v.get("open", {}))
                          for v in state["strategies"].values())
                print(f"{now.strftime('%Y-%m-%d %H:%M:%S')} UTC  "
                      f"новых сделок {new}  в рынке {opn}  "
                      f"капитал ${eq:,.2f}  ({elapsed:.1f} с)", flush=True)
            else:
                nxt = now + pd.Timedelta(seconds=args.poll_seconds)
                render(state, cfg,
                       now.strftime("%Y-%m-%d %H:%M:%S UTC"),
                       nxt.strftime("%H:%M:%S UTC"),
                       f"пересчёт занял {elapsed:.1f} с · окно {args.bars} баров")

            if args.once:
                break

            time.sleep(args.poll_seconds)

        except KeyboardInterrupt:
            print("\n\nОстановлено. Состояние сохранено в paper_live_state.json")
            save_state(state)
            break
        except Exception as exc:
            log_error("main loop", exc)
            print(f"\nОшибка цикла: {exc}\nПодробности в paper_live_errors.log")
            if args.once:
                break
            time.sleep(30)


if __name__ == "__main__":
    try:
        main()
    finally:
        try:
            if PID_FILE.exists():
                PID_FILE.unlink()
        except Exception:
            pass
