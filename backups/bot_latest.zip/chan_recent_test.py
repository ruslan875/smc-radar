"""chan_recent_test.py — 2026-10-22. Пробой канала 100 (2R, стоп центр): как он работает СЕЙЧАС.
Сделки считаются по всей истории (канал «прогрет»), но итог показывается за последние 1/3/6/10/12 месяцев
и по кварталам — видно, не «сдулась» ли стратегия в последнее время. ТФ 1h, 2h, 3h, 4h.
Свечи: OKX (комиссия 0.05%) и Bybit (0.09% и 0.055%). Кеши свечей обновляются, если старше 1 дня.
Ничего не торгует. Запуск: chan_recent_test.bat → bt_lab_bots/chan_recent_test.txt
"""
from __future__ import annotations
import pickle, sys, time
from pathlib import Path
import numpy as np
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import chan_speed_test as CS  # noqa: E402
import chan_saw_bybit as CB  # noqa: E402
import okx_current_test as OC  # noqa: E402
from chan_saw_test import CACHE as OKX_CACHE, COINS  # noqa: E402

OUT = BASE / "bt_lab_bots" / "chan_recent_test.txt"
WINDOWS = [1, 3, 6, 10, 12]          # месяцев назад
TFS = [1, 2, 3, 4]
LINES = []
def say(s=""):
    print(s, flush=True); LINES.append(s)

def load(cache, fetch, name):
    raw = {}
    if cache.exists():
        raw = pickle.loads(cache.read_bytes())
    if not raw or time.time() - cache.stat().st_mtime > 86400:
        new = {}
        for s in COINS:
            print(f"  обновляю {s} 1h {name}…", flush=True)
            try:
                new[s] = fetch(s)
            except Exception as exc:  # noqa: BLE001
                print(f"  {s}: {exc} — беру из кеша", flush=True)
                if s in raw:
                    new[s] = raw[s]
        raw = new
        cache.parent.mkdir(exist_ok=True); cache.write_bytes(pickle.dumps(raw))
    return {s: d for s, d in raw.items() if len(d["c"]) >= 3000}

def trades(raw, k, fee):
    CS.FEE = fee
    out = {}
    for s, d0 in raw.items():
        d = CS.rs(d0, k * 3600_000) if k > 1 else d0
        out[s] = CS.chan_trades(d, 2.0, 1.0)
    return out

def report(title, raw, fee):
    now = max(int(d["t"][-1]) for d in raw.values())
    say(""); say(f"=== {title} · комиссия {fee * 100:.3f}% · монет {len(raw)} ===")
    say(f"{'ТФ':<4}" + "".join(f"{f'посл. {m} мес':>14}" for m in WINDOWS) + f"{'монет + (6 мес)':>17}")
    allq = {}
    for k in TFS:
        tr = trades(raw, k, fee)
        cells = []
        for m in WINDOWS:
            t0 = now - m * 30.4 * 864e5
            r = sum(x[1] for v in tr.values() for x in v if x[0] >= t0)
            n = sum(1 for v in tr.values() for x in v if x[0] >= t0)
            cells.append(f"{r:+7.1f}R/{n:<4d}")
        t6 = now - 6 * 30.4 * 864e5
        plus6 = sum(sum(x[1] for x in v if x[0] >= t6) > 0 for v in tr.values())
        say(f"{str(k) + 'h':<4}" + "".join(f"{c:>14}" for c in cells) + f"{f'{plus6}/{len(tr)}':>17}")
        q = {}
        for v in tr.values():
            for x in v:
                t, r = x[0], x[1]
                lt = time.gmtime(t / 1000); key = f"{lt.tm_year}-Q{(lt.tm_mon - 1) // 3 + 1}"
                q[key] = q.get(key, 0.0) + r
        allq[k] = q
    keys = sorted({kk for q in allq.values() for kk in q})[-8:]
    say("  по кварталам (R, все монеты):")
    say("  " + f"{'ТФ':<4}" + "".join(f"{kk:>9}" for kk in keys))
    for k in TFS:
        say("  " + f"{str(k) + 'h':<4}" + "".join(f"{allq[k].get(kk, 0):>+9.1f}" for kk in keys))

def main():
    say(f"Пробой канала 100 (2R, стоп центр) — свежий период · {time.strftime('%Y-%m-%d %H:%M')}")
    say("Формат ячейки: сумма R / число сделок (по 12 монетам). Последний квартал — неполный.")
    okx = load(OKX_CACHE, lambda s: OC.okx_klines(s, "60", 3 * 365 * 24), "OKX")
    byb = load(CB.CACHE, CB.bybit_1h, "Bybit")
    if okx:
        report("OKX", okx, 0.0005)
    if byb:
        report("Bybit", byb, 0.0009)
        report("Bybit", byb, 0.00055)
    say(""); say("Как читать: если за 6–10 месяцев ТФ в минусе и в минусе последние кварталы — сейчас он не работает,")
    say("даже если за 3 года итог плюсовой. Для сигналов и челленджа брать ТФ, который в плюсе и в свежем периоде.")
    OUT.parent.mkdir(exist_ok=True); OUT.write_text("\n".join(LINES), encoding="utf-8"); print(f"\nОтчёт: {OUT}")

if __name__ == "__main__":
    main()
