@echo off
cd /d D:\VANTORIX\bot
venv\Scripts\python.exe ginarea_tune.py 300
pause
