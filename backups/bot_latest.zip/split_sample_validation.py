#!/usr/bin/env python3
"""
Out-of-sample check for the "exclude BOS, limit-orders-only" filter found
by strategy_filter_analysis.py / combined_filter_fee_analysis.py.

That filter was found by searching several variants on ONE year of trades
-- the same data it was then "validated" against, which is a real risk of
overfitting (multiple-comparisons / data-snooping). This script splits a
LONGER history (e.g. 2 years, fetched via `backtest.py --bars 17520`) into
an EARLIER half the filter search never saw, and a LATER half that
roughly matches the original ~1-year sample -- then reports the same
filter's gross/net R separately in each half. If the edge only shows up
in the later half, it was probably curve-fit to that specific window, not
a real structural edge.

Run:
    python backtest.py --bars 17520          # ~2 years of 1h bars (re-fetch)
    python split_sample_validation.py
"""
from __future__ import annotations

import csv
from pathlib import Path

FEE_SCENARIOS = {
    "taker+taker (~0.11%)": 0.0011,
    "taker+maker (~0.075%)": 0.00075,
    "maker+maker (~0.04%)": 0.0004,
}


def load_trades(directory: Path) -> list:
    trades = []
    for path in sorted(directory.glob("*_trades.csv")):
        with path.open(newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                if row.get("r") in (None, "", "None") or not row.get("time"):
                    continue
                try:
                    row["r"] = float(row["r"])
                    row["entry"] = float(row["entry"])
                    row["stop_loss"] = float(row["stop_loss"])
                except (TypeError, ValueError):
                    continue
                trades.append(row)
    return trades


def gross_stats(trades: list) -> dict:
    if not trades:
        return {"n": 0, "win_rate": float("nan"), "avg_r": float("nan")}
    wins = sum(1 for t in trades if t["r"] > 0)
    return {"n": len(trades), "win_rate": wins / len(trades) * 100,
            "avg_r": sum(t["r"] for t in trades) / len(trades)}


def net_stats(trades: list, fee_rate: float) -> dict:
    net_rs = []
    for t in trades:
        risk_pct = abs(t["entry"] - t["stop_loss"]) / t["entry"]
        if risk_pct <= 0:
            continue
        net_rs.append(t["r"] - fee_rate / risk_pct)
    if not net_rs:
        return {"n": 0, "avg_net_r": float("nan")}
    return {"n": len(net_rs), "avg_net_r": sum(net_rs) / len(net_rs)}


def report(label: str, trades: list) -> None:
    g = gross_stats(trades)
    if g["n"] == 0:
        print(f"  {label}: n=0, skipping")
        return
    print(f"  {label}")
    print(f"    gross: n={g['n']}  win rate={g['win_rate']:.1f}%  avg R={g['avg_r']:+.3f}")
    for fee_label, fee_rate in FEE_SCENARIOS.items():
        n = net_stats(trades, fee_rate)
        print(f"    net @ {fee_label:22s} avg R={n['avg_net_r']:+.3f}  (n={n['n']})")


def main() -> None:
    directory = Path("backtest_out")
    trades = load_trades(directory)
    if not trades:
        print(f"No resolved trades with a time field found in {directory.resolve()} "
              f"-- run backtest.py first (with --bars 17520 or similar for a longer history).")
        return

    times = sorted(t["time"] for t in trades)
    cutoff = times[len(times) // 2]
    print(f"Loaded {len(trades)} resolved trades, {times[0]} .. {times[-1]}")
    print(f"Splitting at midpoint: {cutoff}\n")

    early = [t for t in trades if t["time"] < cutoff]   # out-of-sample: filter never saw this
    late = [t for t in trades if t["time"] >= cutoff]    # roughly the original ~1yr search window

    for label, half in (("EARLIER half (out-of-sample, filter never searched here)", early),
                         ("LATER half (close to original search window)", late)):
        print(f"=== {label} ===")
        report("Baseline (all setups, BTC already excluded via watchlist.json)", half)
        report("Exclude BOS (the filter found earlier)", [t for t in half if t["event"] != "BOS"])
        print()

    print(
        "Reading this: if 'Exclude BOS' nets positive (at taker+maker or maker+maker) "
        "in BOTH halves, that's real evidence of a structural edge, not a fluke of one "
        "window. If it's only positive in the LATER half, treat the earlier finding as "
        "likely overfit to that specific year and don't change live code based on it yet."
    )


if __name__ == "__main__":
    main()
