"""ginarea_op_test.py — 2026-10-18. Приближённый бэктест бота GinArea «OP_Test3_Rsi_or_SuperTrend» (Indicator grid, OP, OKX, LONG).

Настройки со скриншотов:
  вход: RSI(14) 15m < 38  ИЛИ  цена > SuperTrend(7, 2) 15m; «разовая проверка» ВКЛ;
  120 ордеров, шаг 0.1% × множитель шага 1.001, размер 1 OP (без мультипликатора);
  % режим: цель 0.4%, Инстоп 0.05%, мин. стоп 0.05%, макс. стоп 0.2%; «выход по средней» ВЫКЛ (каждый ордер со своим
  триггером), «не ухудшать» ВЫКЛ; тейк бота 100 $ (недостижим при таком размере), стоп-лосса нет.

Модель (по справке GinArea, алгоритм закрыт — приближение):
  * каждый IN закрывается сам: цена ≥ вход × 1.004 → стоп-профит = max(триггер × (1 − 0.05%), пик × (1 − 0.2%));
  * доборы: уровень = последний вход × (1 − шагₙ), шагₙ = 0.1% × 1.001^(n−1); Инстоп 0.05%: пересечённые уровни
    копятся и открываются ОДНИМ ордером, когда цена отскочит на 0.05% от минимума (так описан Инстоп);
  * условие входа — два режима: «каждый цикл» (новый цикл после закрытия всех ордеров только при RSI<38 или цена>ST)
    и «разово» (условие проверено один раз на старте, дальше обычная сетка);
  * комиссия OKX taker 0.05% на вход и выход. Остановка «30 мин / 50 $» не моделируется (50 $ недостижимо).
Ничего не торгует. Запуск: ginarea_op_test.bat [дней, по умолч. 300] → bt_lab_bots/ginarea_op_test.txt
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import requests

BASE = Path(__file__).resolve().parent
OUT = BASE / "bt_lab_bots" / "ginarea_op_test.txt"
CACHE = BASE / "market_cache"
INST = "OP-USDT-SWAP"
P = dict(rsi_len=14, rsi_lvl=38, st_len=7, st_mult=2.0, tf="15min", n_orders=120, step=0.001, step_mult=1.001,
         qty=1.0, target=0.004, instop=0.0005, min_stop=0.0005, max_stop=0.002, fee=0.0005)
LINES = []


def say(s=""):
    print(s, flush=True)
    LINES.append(s)


def okx_1m(inst, days):
    CACHE.mkdir(exist_ok=True)
    path = CACHE / f"okx_{inst.split('-')[0]}_1m.pkl"
    old = pd.read_pickle(path) if path.exists() else pd.DataFrame(columns=["t", "o", "h", "l", "c"])
    need_from = int((time.time() - days * 86400) * 1000)
    have_new = int(old.t.max()) if len(old) else 0
    have_old = int(old.t.min()) if len(old) else None

    def pull(after, stop):
        rows, k = [], 0
        while True:
            q = {"instId": inst, "bar": "1m", "limit": 100}
            if after:
                q["after"] = after
            j = None
            for tr in range(6):
                try:
                    j = requests.get("https://www.okx.com/api/v5/market/history-candles", params=q, timeout=20).json()
                    if j.get("code") == "0":
                        break
                except requests.RequestException:
                    pass
                time.sleep(1.5 * (tr + 1))
            lst = (j or {}).get("data") or []
            if not lst:
                break
            rows += [r for r in lst if len(r) < 9 or r[8] == "1"]
            after = lst[-1][0]
            k += 1
            if k % 100 == 0:
                print(f"  качаю {inst} 1m: {pd.to_datetime(int(after), unit='ms'):%Y-%m-%d %H:%M}", flush=True)
            if int(after) <= stop or len(lst) < 100:
                break
            time.sleep(0.1)
        return rows

    rows = pull(None, max(have_new, need_from))
    if have_old is not None and have_old > need_from + 60_000:
        rows += pull(str(have_old), need_from)
    if rows:
        a = pd.DataFrame([[int(r[0])] + [float(x) for x in r[1:5]] for r in rows], columns=["t", "o", "h", "l", "c"])
        old = pd.concat([old, a]).drop_duplicates("t").sort_values("t").reset_index(drop=True)
        old.to_pickle(path)
    old = old.astype({"t": "int64", "o": "float64", "h": "float64", "l": "float64", "c": "float64"})
    return old[old.t >= need_from].reset_index(drop=True)


def entry_gate(d):
    """True на минуте, если по последней ЗАКРЫТОЙ 15m-свече RSI14 < 38 ИЛИ close > SuperTrend(7, 2)."""
    ix = pd.DatetimeIndex(pd.to_datetime(d.t.to_numpy(), unit="ms"))
    m = pd.DataFrame({"h": d.h.to_numpy(), "l": d.l.to_numpy(), "c": d.c.to_numpy()}, index=ix)
    b = m.resample(P["tf"]).agg({"h": "max", "l": "min", "c": "last"}).dropna()
    dl = b.c.diff()
    up = dl.clip(lower=0).ewm(alpha=1 / P["rsi_len"], adjust=False).mean()
    dn = (-dl.clip(upper=0)).ewm(alpha=1 / P["rsi_len"], adjust=False).mean()
    rsi = 100 - 100 / (1 + up / dn.replace(0, 1e-12))
    tr = pd.concat([b.h - b.l, (b.h - b.c.shift()).abs(), (b.l - b.c.shift()).abs()], axis=1).max(axis=1)
    atr = tr.ewm(alpha=1 / P["st_len"], adjust=False).mean()
    mid = (b.h + b.l) / 2
    upb = (mid - P["st_mult"] * atr).to_numpy().copy()
    dnb = (mid + P["st_mult"] * atr).to_numpy().copy()
    cc = b.c.to_numpy()
    dirn = np.ones(len(b))
    for i in range(1, len(b)):
        if cc[i - 1] > upb[i - 1]:
            upb[i] = max(upb[i], upb[i - 1])
        if cc[i - 1] < dnb[i - 1]:
            dnb[i] = min(dnb[i], dnb[i - 1])
        dirn[i] = 1 if cc[i] > dnb[i - 1] else -1 if cc[i] < upb[i - 1] else dirn[i - 1]
    ok = pd.Series((rsi.to_numpy() < P["rsi_lvl"]) | (dirn > 0), index=b.index)
    key = ix.floor(P["tf"]) - pd.Timedelta(P["tf"])
    return ok.reindex(key).fillna(False).to_numpy().astype(bool)


def run(d, gate, mode):
    t, o, h, l, c = (d[k].to_numpy() for k in ("t", "o", "h", "l", "c"))
    fee, q0 = P["fee"], P["qty"]
    orders = []          # dict entry, qty, stop(None)
    last = None          # цена последнего IN
    n_step = 0           # номер следующего шага (для множителя)
    pending, low = 0, None
    res = {"deals": 0, "fees": 0.0, "max_orders": 0, "max_notional": 0.0, "worst": 0.0, "worst_t": None}
    real, monthly = 0.0, {}
    started = False

    def book(x, ts):
        nonlocal real
        real += x
        m = pd.to_datetime(ts, unit="ms").strftime("%Y-%m")
        monthly[m] = monthly.get(m, 0.0) + x

    for i in range(1, len(c)):
        # 1) старт цикла
        if not orders and pending == 0:
            allowed = gate[i] if (mode == "cycle" or not started) else True
            if allowed:
                px = o[i]
                orders.append({"e": px, "q": q0, "u": 1, "stop": None})
                book(-px * q0 * fee, t[i]); res["fees"] += px * q0 * fee
                last, n_step, started = px, 1, True
            else:
                continue
        # 2) уровни доборов (копятся, открываются по Инстопу)
        while sum(od["u"] for od in orders) + pending < P["n_orders"]:
            lvl = last * (1 - P["step"] * P["step_mult"] ** (n_step - 1))
            if l[i] > lvl:
                break
            pending += 1; n_step += 1; last = lvl
            low = l[i] if low is None else min(low, l[i])
        if pending:
            low = min(low, l[i])
            if c[i] >= low * (1 + P["instop"]):
                px = c[i]; qq = q0 * pending
                orders.append({"e": px, "q": qq, "u": pending, "stop": None})
                book(-px * qq * fee, t[i]); res["fees"] += px * qq * fee
                last = min(last, px) if px < last else last
                pending, low = 0, None
        # 3) выход каждого ордера по своему триггеру + трейлинг
        keep = []
        for od in orders:
            trig = od["e"] * (1 + P["target"])
            if od["stop"] is None and h[i] >= trig:
                od["stop"] = trig * (1 - P["min_stop"])
            if od["stop"] is not None:
                od["stop"] = max(od["stop"], h[i] * (1 - P["max_stop"]))
                if c[i] <= od["stop"]:
                    px = od["stop"]
                    book((px - od["e"]) * od["q"] - px * od["q"] * fee, t[i]); res["fees"] += px * od["q"] * fee
                    res["deals"] += 1
                    continue
            keep.append(od)
        if len(keep) != len(orders) and keep and pending == 0:
            # 2026-10-18 fix: после закрытия нижних ордеров следующий добор считается от самого нижнего
            # ОТКРЫТОГО ордера, а не от давно закрытого минимума (иначе сетка «засыпала» на месяцы)
            last = min(od["e"] for od in keep)
            n_step = sum(od["u"] for od in keep)
        orders = keep
        if not orders and pending == 0:
            last, n_step = None, 0
        qty = sum(od["q"] for od in orders)
        res["max_orders"] = max(res["max_orders"], sum(od["u"] for od in orders) + pending)
        res["max_notional"] = max(res["max_notional"], qty * c[i])
        un = sum((l[i] - od["e"]) * od["q"] for od in orders)
        if un < res["worst"]:
            res["worst"], res["worst_t"] = un, t[i]
    res["real"] = real
    res["open"] = sum((c[-1] - od["e"]) * od["q"] for od in orders)
    res["open_n"] = sum(od["u"] for od in orders)
    res["monthly"] = monthly
    return res


def main():
    days = int(sys.argv[1]) if len(sys.argv) > 1 else 300
    say(f"GinArea Indicator grid «OP_Test3_Rsi_or_SuperTrend» — приближённый бэктест · OKX {INST} 1m · {days} дн. · "
        f"{time.strftime('%Y-%m-%d %H:%M')}")
    say(f"Настройки: {P}")
    d = okx_1m(INST, days)
    if len(d) < 10000:
        say("мало свечей — OKX не отдал историю"); return
    say(f"Свечей: {len(d)} · {pd.to_datetime(d.t.iloc[0], unit='ms'):%Y-%m-%d} → "
        f"{pd.to_datetime(d.t.iloc[-1], unit='ms'):%Y-%m-%d} · OP {d.c.iloc[0]:.4f} → {d.c.iloc[-1]:.4f}")
    cover = sum(P["step"] * P["step_mult"] ** k for k in range(P["n_orders"] - 1))
    say(f"Полная сетка: {P['n_orders'] * P['qty']:.0f} OP ≈ {P['n_orders'] * P['qty'] * d.c.iloc[-1]:.2f} $, "
        f"покрывает падение ≈ {(1 - np.exp(-cover)) * 100:.1f}% от старта")
    gate = entry_gate(d)
    say(f"Условие входа (RSI<38 или цена>ST) выполнено {gate.mean() * 100:.0f}% времени")
    m = len(d) // 2
    for mode, label in (("cycle", "условие на каждый цикл"), ("once", "разовая проверка (дальше сетка)")):
        say(""); say(f"=== {label} ===")
        for name, part, g in (("весь период", d, gate), ("1-я половина", d.iloc[:m].reset_index(drop=True), gate[:m]),
                              ("2-я половина", d.iloc[m:].reset_index(drop=True), gate[m:])):
            r = run(part, g, mode)
            say(f"  {name:<13} закрыто {r['real']:+7.2f} $ · открыто {r['open']:+6.2f} $ ({r['open_n']} орд.) · "
                f"сделок {r['deals']} · комиссии {r['fees']:.2f} $ · макс. ордеров {r['max_orders']} "
                f"(до {r['max_notional']:.2f} $) · худшая просадка {r['worst']:.2f} $"
                + (f" ({pd.to_datetime(r['worst_t'], unit='ms'):%Y-%m-%d})" if r["worst_t"] else ""))
            if name == "весь период":
                say("    по месяцам: " + "  ".join(f"{k} {v:+.2f}" for k, v in sorted(r["monthly"].items())))
    say("")
    say("Размер маленький (1 OP ≈ 0.13 $), поэтому цифры в долларах малы — смотри на знак, просадку и стабильность по")
    say("половинам. Чтобы перевести на свой размер: умножь все $ на (твой размер ордера в OP).")
    OUT.parent.mkdir(exist_ok=True)
    OUT.write_text("\n".join(LINES), encoding="utf-8")
    print(f"\nОтчёт: {OUT}")


if __name__ == "__main__":
    main()
