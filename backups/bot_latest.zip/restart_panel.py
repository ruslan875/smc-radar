"""restart_panel.py — 2026-11-02: перезапуск панели (windows_app\\run.py — сервер, который кормит терминал).
Запускается отдельно (detached), ждёт 2 с, завершает run.py и поднимает его той же командой без окна. Лог: logs\\panel_restart.log"""
import json, subprocess, time
from pathlib import Path
BOT = Path(__file__).resolve().parent
LOG = BOT / "logs" / "panel_restart.log"; LOG.parent.mkdir(exist_ok=True)
def log(*a):
    with open(LOG, "a", encoding="utf-8") as f: f.write(time.strftime("%H:%M:%S ") + " ".join(map(str, a)) + "\n")
def procs():
    ps = ("Get-CimInstance Win32_Process -Filter \"Name like 'python%'\" | Select-Object ProcessId,CommandLine | ConvertTo-Json -Compress")
    o = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True).stdout.strip() or "[]"
    o = json.loads(o); return o if isinstance(o, list) else [o]
time.sleep(2)
# 2026-11-15: реальные боты не должны умирать при перезапуске панели — проверяем до и после.
_REAL = ("combo_xrp_live.py", "long_strategy15_latuserge_live.py", "kc_roc_cci_wt_grid_live.py")
def real():
    return sorted({n for p in procs() for n in _REAL if n in (p.get("CommandLine") or "")})
_before = real(); log("реальные боты до:", _before)
hits = [p for p in procs() if "windows_app\\run.py" in (p.get("CommandLine") or "").replace("/", "\\")]
log("найдено:", [(p["ProcessId"], p["CommandLine"]) for p in hits])
# 2026-11-07: панель — всегда системным Python (там стоит pywebview → отдельное окно). venv без pywebview → открывалась вкладка браузера.
_ok = [p for p in hits if "\\venv\\" not in (p.get("CommandLine") or "").lower()]
cmd = _ok[0]["CommandLine"] if _ok else "python -u windows_app\\run.py"
for p in hits:
    subprocess.run(["taskkill", "/PID", str(p["ProcessId"]), "/F"], capture_output=True)
time.sleep(3)
# 2026-11-21: ротация panel.log > 100 МБ (старое — в panel_YYYYMMDD.log, держим 5).
from bot_services import rotate_log  # noqa: E402
rotate_log(BOT / "logs" / "panel.log")
lg = open(BOT / "logs" / "panel.log", "a", encoding="utf-8", errors="replace")
subprocess.Popen(cmd, cwd=str(BOT), stdout=lg, stderr=subprocess.STDOUT,
                 creationflags=subprocess.CREATE_NO_WINDOW | subprocess.CREATE_NEW_PROCESS_GROUP)
log("запущено:", cmd)
time.sleep(15)
log("после:", [(p["ProcessId"], p["CommandLine"]) for p in procs() if "run.py" in (p.get("CommandLine") or "")])
_after = real(); _lost = [n for n in _before if n not in _after]
log("реальные боты после:", _after, "ПОТЕРЯНЫ:" if _lost else "", _lost or "")
if _lost:
    (BOT / "REAL_BOTS_LOST.txt").write_text(time.strftime("%Y-%m-%d %H:%M ") + " ".join(_lost), encoding="utf-8")
