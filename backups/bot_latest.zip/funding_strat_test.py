"""funding_strat_test.py — 2026-11-15. Сколько ФАНДИНГ съедает у наших основных стратегий (бэктест его не учитывает).
Сделки — тем же кодом, что боты (bt_lab.sim_honest, как hyro_test), 1h-свечи Bybit ~3 года, 10 крупных монет.
Фандинг — история Bybit /v5/market/funding/history. Лонг платит при положительной ставке, шорт получает (и наоборот).
Стоимость в R = сторона × сумма ставок за время удержания × 100 / типичный убыток стратегии в % (как r_of в hyro_test).
Итог: funding_strat_test.txt. Только чтение публичных данных."""
from __future__ import annotations

import json, sys, time, urllib.request
from pathlib import Path

import numpy as np

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import bt_lab as B  # noqa: E402
import big_coins_test as BC  # noqa: E402

COINS = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT", "BNBUSDT", "DOGEUSDT", "ADAUSDT", "AVAXUSDT", "LINKUSDT", "LTCUSDT"]
STRATS = {"honest:bos4h": "BOS 4h", "honest:atrfib": "ATR Fib 4h", "honest:donch": "Donchian 4h",
          "honest:turtle_4h": "Черепахи 4h", "honest:turtle_2h": "Черепахи 2h", "honest:chan": "Пробой канала 2h"}
OUT = BASE / "funding_strat_test.txt"


def funding(sym: str, start_ms: int) -> tuple[np.ndarray, np.ndarray]:
    ts, rs = [], []; end = int(time.time() * 1000)
    while end > start_ms:
        url = f"https://api.bybit.com/v5/market/funding/history?category=linear&symbol={sym}&limit=200&endTime={end}"
        for att in range(4):
            try:
                L = json.load(urllib.request.urlopen(url, timeout=20))["result"]["list"]; break
            except Exception:  # noqa: BLE001
                time.sleep(2 + att * 3)
        else:
            break
        if not L:
            break
        for x in L:
            ts.append(int(x["fundingRateTimestamp"])); rs.append(float(x["fundingRate"]))
        end = int(L[-1]["fundingRateTimestamp"]) - 1
        time.sleep(0.15)
    o = np.argsort(ts)
    return np.array(ts)[o], np.array(rs)[o]


def main() -> None:
    B.deals_to_trades = lambda rows, df, p, prog=None: rows
    agg = {k: {"n": 0, "r": 0.0, "f": 0.0, "fl": [], "long_f": 0.0, "short_f": 0.0} for k in STRATS}
    lines = [f"Фандинг против наших стратегий — {time.strftime('%Y-%m-%d %H:%M')}", ""]
    for s in COINS:
        df = BC.load_1h(s, 1100)
        if df is None:
            lines.append(f"{s}: нет свечей"); continue
        ft, fr = funding(s, int(df.t.iloc[0]))
        cs = np.concatenate([[0.0], np.cumsum(fr)])
        lines.append(f"{s}: свечей {len(df)}, платежей фандинга {len(ft)}, средний {fr.mean() * 100:+.4f}% за платёж")
        for st in STRATS:
            if st not in B.HONEST:
                continue
            rows = B.sim_honest(df, {"strategy": st, "tf": B.HONEST[st][1]}, lambda *x: None)
            if not rows:
                continue
            lm = float(np.median([-q["pct"] for q in rows if q["pct"] < 0] or [1.0]))
            for q in rows:
                ti, to = int(q["t_in"]), int(q.get("t_out") or q["t_in"])
                i0, i1 = np.searchsorted(ft, ti, side="right"), np.searchsorted(ft, to, side="right")
                paid = (cs[i1] - cs[i0]) * 100 * (1 if q["side"] > 0 else -1)      # % от позиции, + = заплатили
                a = agg[st]; a["n"] += 1; a["r"] += q["pct"] / lm; a["f"] += paid / lm; a["fl"].append(paid / lm)
                a["long_f" if q["side"] > 0 else "short_f"] += paid / lm
        lines.append("")
        print(s, "ok", flush=True)
    lines += ["", "Стратегия           сделок  итог R без фандинга  фандинг R  итог R с фандингом  на сделку  (лонги / шорты)"]
    for st, a in agg.items():
        if not a["n"]:
            continue
        lines.append(f"{STRATS[st]:18s} {a['n']:6d}   {a['r']:+10.1f}         {-a['f']:+8.1f}    {a['r'] - a['f']:+10.1f}       {-a['f'] / a['n']:+.3f}R"
                     f"   ({-a['long_f']:+.1f} / {-a['short_f']:+.1f})   худшая сделка {-max(a['fl']):+.2f}R")
    lines += ["", "Минус в колонке «фандинг» = заплатили. R считается от типичного убытка стратегии (как в hyro_test)."]
    OUT.write_text("\n".join(lines), encoding="utf-8")
    print("\n".join(lines), flush=True)


if __name__ == "__main__":
    main()
