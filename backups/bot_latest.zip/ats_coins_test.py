"""ats_coins_test.py — 2026-10-18. ATS-Multi v7 по КАЖДОЙ монете отдельно (особенно BTC — под него настройки),
ТФ 4h…12h, свечи OKX, комиссия taker 0.05%. В клетке: % за всю историю (1-я половина / 2-я половина).
Ничего не торгует. Запуск: ats_coins_test.bat → bt_lab_bots/ats_coins_test.txt"""
from __future__ import annotations
import sys, time
from pathlib import Path
import numpy as np
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import chat_scripts_okx_test as CS  # noqa: E402
import pack_strats_test as PS  # noqa: E402
OUT = BASE / "bt_lab_bots" / "ats_coins_test.txt"
LINES = []
def say(s=""):
    print(s, flush=True); LINES.append(s)
def main():
    say(f"ATS-Multi v7 по монетам · OKX · {time.strftime('%Y-%m-%d %H:%M')} · % всего (1-я пол. / 2-я пол.)")
    import pickle
    cache = BASE / "market_cache" / "okx_1h_3y_12coins.pkl"
    if cache.exists() and time.time() - cache.stat().st_mtime < 3 * 86400:
        raw = pickle.loads(cache.read_bytes())
    else:
        raw = {}
        for s in CS.COINS:
            print(f"  качаю {s} 1h с OKX…", flush=True)
            raw[s] = CS.okx_klines(s, "60", 3 * 365 * 24)
        cache.parent.mkdir(exist_ok=True); cache.write_bytes(pickle.dumps(raw))
    raw = {s: d for s, d in raw.items() if len(d["c"]) >= 3000}
    coins = sorted(raw, key=lambda s: s != "BTCUSDT")
    KS = [4, 6, 8, 10, 12]
    say(f"{'монета':<10}" + "".join(f"{str(k)+'h':>22}" for k in KS))
    for s in coins:
        row = f"{s.replace('USDT',''):<10}"
        for k in KS:
            d = PS.resample(raw[s], k)
            CS.CTX["tick"] = CS.TICKS.get(s)
            a = CS.ats(d, False)[0] * 100; b = CS.ats(CS.half(d, 0), False)[0] * 100; c = CS.ats(CS.half(d, 1), False)[0] * 100
            CS.CTX["tick"] = None
            row += f"{a:+8.0f} ({b:+5.0f}/{c:+5.0f}){'✅' if a > 0 and b > 0 and c > 0 else '  '}"
        say(row)
    say("✅ = плюс в целом и в обеих половинах истории.")
    OUT.parent.mkdir(exist_ok=True); OUT.write_text("\n".join(LINES), encoding="utf-8"); print(f"\nОтчёт: {OUT}")
if __name__ == "__main__":
    main()
