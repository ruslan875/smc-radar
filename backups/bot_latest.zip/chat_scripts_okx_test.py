"""chat_scripts_okx_test.py — 2026-10-17. Скрипты TradingView из чата (ChatExport_2026-10-17/files) → честный бэктест на OKX.

Данные: свечи OKX USDT-SWAP (okx_current_test.okx_klines), 12 монет (BTC ETH SOL XRP DOGE ADA SUI LINK AVAX BNB NEAR HYPE)
и TradFi OKX (XAU XAG XCU CL BZ NG), таймфреймы 1h и 4h (ни один скрипт явно не задаёт свой ТФ).
Комиссии OKX: тейкер 0.05% (вход по рынку, стоп, выход по сигналу/времени), мейкер 0.02% (тейк-профит лимиткой).
Исполнение: сигнал на закрытии свечи → вход по открытию следующей. Стоп/тейк внутри свечи, если задеты оба — стоп;
гэп через уровень — исполнение по open. Никаких перерисовок: пивоты только подтверждённые (через правые бары),
ZigZag считается свеча за свечой только по прошлым данным, request.security не используется (все на текущем ТФ).
Результат — сумма сделок в % на инструмент (каждая сделка 1× депозита, без плеча); у сетки — доходность счёта.
✅ = в среднем > 0, в плюсе ≥ 8/12 монет (TradFi ≥ 4/6), обе половины истории > 0. ★ — прошёл и на 1h, и на 4h.

ПЕРЕНЕСЕНЫ (настройки по умолчанию):
 1. ATR Trailing Stop Multi-Strategy v9 (ATS-Multi v9): голосование 6 систем (Доу ×2, ATR-трейл 3 линии ×2, Gaussian
    Smooth Trend, KAMA 10/24, VWMA20, Аллигатор) с фильтрами CCI/ATR%/Аллигатор; вход ≥ 60% доступных голосов;
    выход — встречные ≥ 80% порога, стоп 2.5% по закрытию, ATR-трейлинг (2×ATR14, после +0.5%) по закрытию.
 2. ATSMulti (v7): те же голоса, вход/выход при ≥ 3 голосах, стоп 2.5% по закрытию, без трейлинга.
 3. FAST SIGNALS SYSTEM STRATEGI (= FAST SIGNALS WITHOUT REDRAW, одна логика — перенесена один раз):
    ZigZag(30,5,5) — новый экстремум/смена направления, ждём 2 свечи подтверждения; лонг только если close в нижних 25%
    диапазона закрытий 200 свечей (шорт — в верхних 25%); стоп 0.1% за экстремумом (в пределах 0.05–2%), тейк 1.5R
    (0.1–4%); одна позиция.
 4. FAST SIGNALS (BS-GR-Combo): смена направления ZigZag(30,5,5): вниз → «Buy», вверх → «Sell» (алерт). Индикатор →
    разворот и вариант «+ стоп 2 / тейк 3 ATR».
 5. TUTCI (Turtle Trade Channels): пробой 20-канала (с фильтром «был выход после прошлого входа»), выход по 10-каналу,
    стоп 2% / тейк 4% от цены входа; встречный вход в позиции запрещён.
 6. VSA Precision: VSA-бары (accumulation/spring/bag holding/EFM — лонг под EMA20; distribution/upthrust/ERM — шорт над
    EMA20; объём > 75-го перцентиля 100 свечей); переворот встречным сигналом; стоп 1.5 ATR, после +0.5% — трейл 1% от
    high/low прошлой свечи.
 7. S&R Power + RSI Div Zones (S&RPowerRSI; SRPOWER2 с настройками по умолчанию идентичен — перенесён один раз):
    уровень бычьей дивергенции RSI(mom10) (пивоты 5/5) — лонг при касании уровня сверху, если low в зоне BUY POWER
    (мин. 130 свечей + 0.5·ATR200), ожидание до 3 свечей; шорт зеркально; тейк 2% / стоп 1%.
 8. GridBot v6: сетка 10 уровней ±0.5…4.5% (шаг 1%) от стартовой цены, Touch: покупка при касании уровня ниже
    последнего сигнального, продажа выше; пирамидинг, встречный сигнал переворачивает всю позицию. Симуляция счёта.
 9. Larry Williams Donchian Breakout V3: пробой «комбинированного» Дончиана 20 (цена + подтверждённые пивоты 2/4),
    уровень ровный 3 свечи, фильтры LWTI/объём/стоп ≤3%/ширина ≥2%/пробой ≥0.2%; стоп = середина канала −0.1%
    (пересчитывается каждую свечу), тейк 2R, безубыток/трейл к середине, пирамидинг до +3, выход по времени 50 свечей.
10. Larry Williams Donchian Breakout V2: то же без выхода по времени (второй вариант).
11. Take Profit X: 8 индикаторов «перегрева» (RSI, MACD, Stoch, BB, Supertrend, CCI, EMA-кросс, пробой 5) ≥ 5 голосов:
    бычий TP → шорт, медвежий TP → лонг. Разворот и «+ стоп 2 / тейк 3 ATR».
12. Strategy [High-Low Cloud Trend] (стратегия.txt): ретест облака по тренду + объём ×1.5 + RSI (<30 лонг/>70 шорт) +
    MACD; стоп 1.5 ATR, тейк 2 ATR, встречный сигнал переворачивает.
13. МЕГА +RSI: регулярная RSI-дивергенция (пивоты 5/5, 5…60 свечей) Bull → лонг, Bear → шорт. Разворот и
    «+ стоп 2 / тейк 3 ATR» (Zero-Lag Trend из того же индикатора не брали — лимит 2 варианта на скрипт).
14. Order Block Strategy (OBS.V1, ОрдерБлок(сырая)): свинги 13, ордерблок при пробое свинга; лонг при касании
    бычьего OB, частичное закрытие 50% у медвежьего OB, полное — выше медвежьего OB / ниже бычьего; стоп 1.1%, тейк 3.2%.
15. 3 Eye • Strategy 8.12: CCI(hlc3,20) пересекает +100 → лонг (−100 вниз → шорт) над/под облаком Ишимоку, линии
    Тенкан/Киджун за облаком, EMA200, анти-FOMO ATR; повторный вход только после касания облака; стоп 1%, тейк 2%,
    выход по таймауту 50 свечей; встречный вход переворачивает.

ПРОПУЩЕНЫ:
  • FCN (nOI + Funding + CVD) — нужны история открытого интереса (окно 500 свечей), фандинга и CVD с младшего ТФ;
    в свечах OKX этого нет, история OI на OKX короткая.
  • Eigen.txt — это не скрипт, а текстовый обзор монеты EIGEN.
  • 3in1-SWINGS-CPR-TANGENTS, PIVOTpoints levels MTF, Liquidity thermal map MOD — чисто визуальные (уровни, пивоты,
    тепловая карта), сигналов входа/выхода нет.
  • FAST SIGNALS WITHOUT REDRAW — та же логика, что FAST SIGNALS SYSTEM STRATEGI (перенесена один раз); SRPOWER2 —
    по умолчанию идентичен S&RPowerRSI.
  • Платных/приватных/invite-only скриптов в списке нет (заголовки — MPL-2.0 / CC BY-NC-SA / без лицензии);
    файл «LE VAN DO®…» не использовался.

ПРИБЛИЖЕНИЯ:
  • syminfo.mintick (ZigZag deviation 5 тиков, фильтр дистанции ATS 10 тиков) — таблица шагов цены OKX, для
    неизвестных — 10^(порядок цены − 4).
  • Библиотека signalLib_yashgode9 (закрытая для чтения тут) восстановлена как ZigZag++ (DevLucem): hr/lr через
    barssince, направление −1 после backstep свечей; стартовые точки — первая свеча.
  • KAMA/SMMA/DEMA/EMA стартуют с первого значения (в Pine — со своих затравок), влияет только на прогрев.
  • GridBot: B_Price по умолчанию 0 (сетка не работает) → центр = первая цена окна теста; лот = 10% стартового счёта
    по цене исполнения; разорение = эквити ≤ 0.
  • Order Block: SL/TP в оригинале закрывают strategy.close (по рынку) — здесь стоп/тейк по уровню внутри свечи.
  • Скрипты с process_orders_on_close (ATS, LW, 3 Eye) исполняют по закрытию — здесь по открытию следующей свечи, уровни
    стопа/тейка считаются, как в скрипте (от close сигнальной свечи или от цены входа).
  • High-Low Cloud: лимит «5 сделок в день» не моделируется. По умолчанию ретест облака в восходящем тренде требует
    ещё RSI < 30 (шорт — RSI > 70) — такое совпадение почти не случается, сделок может быть 0 (это свойство настроек). TUTCI: стоп/тейк проверяются уже на свече входа.
  • LW: каждая доливка — отдельная сделка 1× (в оригинале 50% эквити на ордер).
Запуск: chat_scripts_okx_test.bat → bt_lab_bots/chat_scripts_okx_test.txt. Ничего не торгует.
"""
from __future__ import annotations

import math
import sys
import time
from pathlib import Path

import numpy as np
from numpy.lib.stride_tricks import sliding_window_view as _sw

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))

import okx_current_test as OC  # noqa: E402  (подменяет модули тестов на OKX — это нормально)
import pack_strats_test as PS  # noqa: E402

okx_klines, TRADFI = OC.okx_klines, OC.TRADFI
MK, TK = 0.0002, 0.0005
PS.TK = TK
OUT = BASE / "bt_lab_bots" / "chat_scripts_okx_test.txt"
COINS = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT", "DOGEUSDT", "ADAUSDT", "SUIUSDT", "LINKUSDT", "AVAXUSDT",
         "BNBUSDT", "NEARUSDT", "HYPEUSDT"]
TFS = [("60", "1h", 15000), ("240", "4h", 6000)]
TICKS = {"BTCUSDT": 0.1, "ETHUSDT": 0.01, "SOLUSDT": 0.01, "XRPUSDT": 0.0001, "DOGEUSDT": 0.00001, "ADAUSDT": 0.0001,
         "SUIUSDT": 0.0001, "LINKUSDT": 0.001, "AVAXUSDT": 0.001, "BNBUSDT": 0.01, "NEARUSDT": 0.001, "HYPEUSDT": 0.001,
         "XAUUSDT": 0.01, "XAGUSDT": 0.001, "XCUUSDT": 0.0001, "CLUSDT": 0.01, "BZUSDT": 0.01, "NGUSDT": 0.001}
CTX = {"tick": None}
LINES = []

sma, ema, atr = PS.sma, PS.ema, PS.atr
rma, smaN, emaN, stdevN, rmaxN, rminN, rsumN = PS.rma, PS.smaN, PS.emaN, PS.stdevN, PS.rmaxN, PS.rminN, PS.rsumN
shift, change, tr_, rsi, cci, xover, xunder = PS.shift, PS.change, PS.tr_, PS.rsi, PS.cci, PS.xover, PS.xunder
barssince, ffill, to_sig, gt, lt, ge, le = PS.barssince, PS.ffill, PS.to_sig, PS.gt, PS.lt, PS.ge, PS.le


def say(s=""):
    print(s, flush=True)
    LINES.append(s)


def tick(d):
    if CTX["tick"]:
        return CTX["tick"]
    p = float(np.nanmedian(d["c"])) if len(d["c"]) else 1.0
    return 10 ** (math.floor(math.log10(max(p, 1e-12))) - 4)


def patr(d, n):
    return rma(tr_(d), n)


def nz(x, v=0.0):
    return np.where(np.isnan(x), v, x)


def bshift(b, k=1):
    b = np.asarray(b, bool); out = np.zeros(len(b), bool)
    if k < len(b):
        out[k:] = b[:len(b) - k]
    return out


def half(d, w):
    n = len(d["c"]); m = n // 2; sl = slice(0, m) if w == 0 else slice(m, n)
    return {k: v[sl] for k, v in d.items()}


class Book:
    """Учёт сделок: доля депозита w, вход тейкер, выход тейкер или мейкер (тейк лимиткой)."""
    def __init__(self):
        self.tot, self.n = 0.0, 0

    def close(self, side, e, px, maker=False, w=1.0):
        self.tot += w * (side * (px / e - 1) - TK - (MK if maker else TK)); self.n += 1


def stop_hit(side, o, h, l, s, t):
    """Проверка уровней на свече: стоп первым. Возврат (цена, мейкер?) или None."""
    if side > 0:
        if s == s and l <= s:
            return min(o, s), False
        if t == t and h >= t:
            return max(o, t), True
    else:
        if s == s and h >= s:
            return max(o, s), False
        if t == t and l <= t:
            return min(o, t), True
    return None


# ------------------------------------------------------------------------------------------------
# Общий симулятор: sig[i]=±1 на закрытии i → вход по open i+1. sl/tp: доля от цены входа (float) или массив
# абсолютных уровней на сигнальной свече. xsig[i]=+1 закрыть лонг/−1 шорт по open i+1. rev — встречный сигнал
# переворачивает (иначе игнор). refresh — повторный сигнал в ту же сторону переставляет уровни (как strategy.exit).
# ------------------------------------------------------------------------------------------------
def _lv(x, k, e, pos, i):
    if x is None:
        return np.nan
    if isinstance(x, (float, int)):
        return e * (1 - k * pos * x)
    return x[i]


def sim(d, sig, sl=None, tp=None, xsig=None, rev=False, refresh=False, hold=None, start=60):
    o, h, l, c = d["o"], d["h"], d["l"], d["c"]
    bk = Book(); pos, e, s, t, eb = 0, 0.0, np.nan, np.nan, 0
    for i in range(start, len(c) - 1):
        if pos:
            r = stop_hit(pos, o[i], h[i], l[i], s, t)
            if r:
                bk.close(pos, e, r[0], r[1]); pos = 0
        pos1 = pos
        if pos and ((hold and i - eb >= hold) or (xsig is not None and xsig[i] == pos)):
            bk.close(pos, e, o[i + 1]); pos = 0
        w = sig[i]
        if not w:
            continue
        if pos1 == 0 or (rev and w != pos1):
            if pos:
                bk.close(pos, e, o[i + 1])
            pos, e, eb = w, o[i + 1], i
        elif refresh and pos == w:
            eb = i
        else:
            continue
        s, t = _lv(sl, 1, e, pos, i), _lv(tp, -1, e, pos, i)
    if pos:
        bk.close(pos, e, c[-1])
    return bk.tot, bk.n


def rev_test(fn, atr_st=False):
    if atr_st:
        return lambda d: PS.run_exit(d, fn(d), atr_sl_tp=(2, 3), refresh=False)
    return lambda d: PS.run_reverse(d, fn(d))


# =================================================================================================
# 1–2. ATR Trailing Stop Multi-Strategy v9 / v7
# =================================================================================================
def ats_votes(d):
    o, h, l, c, v = d["o"], d["h"], d["l"], d["c"], d["v"]
    n = len(c); tk = tick(d)
    a14 = patr(d, 14); natr = a14 / c * 100
    volc = (smaN(v, 20) > 0) & (v > smaN(v, 20) * 1.5)
    ma20, ma50 = smaN(c, 20), smaN(c, 50)
    trend = np.where(gt(c, ma20) & gt(ma20, ma50), 1, np.where(lt(c, ma20) & lt(ma20, ma50), -1, 0))
    dowsig = np.where(volc & (natr > 1.0), trend, 0)
    hl2 = (h + l) / 2
    jaw, teeth, lips = rma(hl2, 13), rma(hl2, 8), rma(hl2, 5)
    cc = cci(c, 20)
    atrp = a14 / c * 100

    def others(dr):
        if dr > 0:
            cciok = gt(cc, -100) & gt(cc, shift(cc))
            dist = nz((c - lips) / tk, -1e18) >= 10
            st = gt(lips, teeth) & gt(teeth, jaw) & gt(c, lips)
        else:
            cciok = lt(cc, 100) & lt(cc, shift(cc))
            dist = nz((lips - c) / tk, -1e18) >= 10
            st = lt(lips, teeth) & lt(teeth, jaw) & lt(c, lips)
        return cciok & (atrp >= 0.3) & dist & st
    fL, fS = others(1), others(-1)
    fLd, fSd = fL & volc & (natr > 1.0), fS & volc & (natr > 1.0)

    def gate(state, a, b):
        return np.where((state == 1) & ~a, 0, np.where((state == -1) & ~b, 0, state))
    # KAMA 10/24
    fsc, ssc = 2 / 3, 2 / 31

    def kama(L):
        ch = np.abs(c - shift(c, L)); vol = rsumN(np.abs(change(c)), L)
        with np.errstate(divide="ignore", invalid="ignore"):
            sc = (ch / vol * (fsc - ssc) + ssc) ** 2
        k = np.full(n, np.nan); p = np.nan
        for i in range(n):
            if sc[i] == sc[i]:
                p = c[i] if p != p else p + sc[i] * (c[i] - p)
            k[i] = p
        return k
    k1, k2 = kama(10), kama(24)
    kst = ffill(np.where(xover(k1, k2), 1.0, np.where(xunder(k1, k2), -1.0, np.nan))); kst = nz(kst).astype(int)
    kamaF = gate(kst, fL, fS)

    # ATR trailing 3 линии
    def trail(p, m):
        sl = m * atr(d, p); t = np.zeros(n); prev = 0.0
        for i in range(n):
            s1 = c[i - 1] if i else c[i]; x = c[i]
            if x > prev and s1 > prev:
                cur = max(prev, x - sl[i])
            elif x < prev and s1 < prev:
                cur = min(prev, x + sl[i])
            else:
                cur = x - sl[i] if x > prev else x + sl[i]
            t[i] = cur; prev = cur
        return t
    tf_, tm_, ts_ = trail(5, 0.5), trail(10, 1.5), trail(20, 3.0)
    ast = np.where((tm_ > ts_) & (tf_ > tm_), 1, np.where((tm_ < ts_) & (tf_ < tm_), -1, 0))
    pst = np.r_[0, ast[:-1]]
    up = (tm_ > ts_) & (pst <= 0) & (ast == 1); dn = (tm_ < ts_) & (pst >= 0) & (ast == -1)
    aflt = nz(ffill(np.where(up, 1.0, np.where(dn, -1.0, np.nan)))).astype(int)
    atrF = gate(aflt, fL, fS)
    # Gaussian Smooth Trend
    e1 = emaN(c, 7); dema = 2 * e1 - emaN(e1, 7)
    w = np.exp(-0.5 * ((np.arange(4) - 1.5) / 2.0) ** 2)
    g = sum(w[j] * shift(dema, j) for j in range(4)) / w.sum()
    smm = np.full(n, np.nan); p = np.nan
    for i in range(n):
        if g[i] == g[i]:
            p = g[i] if p != p else p + (g[i] - p) / 12
        smm[i] = p
    sd = stdevN(smm, 30)
    LV, SV = smm + sd * 2.5, smm - sd * 1.8
    gst = np.where(gt(c, LV) & ~lt(c, SV), 1, np.where(lt(c, SV), -1, 0))
    gstF = gate(gst, fL, fS)
    # Аллигатор
    alc = gt(lips, teeth) & gt(teeth, jaw) & gt(c, lips); asc = lt(lips, teeth) & lt(teeth, jaw) & lt(c, lips)
    alst = nz(ffill(np.where(alc, 1.0, np.where(asc, -1.0, np.nan)))).astype(int)
    alF = gate(alst, fL, fS)
    # VWMA
    vw = rsumN(c * v, 20) / rsumN(v, 20)
    vst = nz(ffill(np.where(xover(c, vw), 1.0, np.where(xunder(c, vw), -1.0, np.nan)))).astype(int)
    vwF = gate(vst, fL, fS)
    dowF = gate(dowsig, fLd, fSd)
    comps = [(dowF, 2), (atrF, 2), (gstF, 1), (kamaF, 1), (vwF, 1), (alF, 1)]
    LC = sum(wt * (x > 0) for x, wt in comps); SC = sum(wt * (x < 0) for x, wt in comps)
    mL = np.zeros(n); mS = np.zeros(n)
    for x, wt in comps:
        neutral = x == 0
        if x is dowF:
            neutral = (x == 0) & (dowsig == 0)
        mL += wt * ((x > 0) | neutral); mS += wt * ((x < 0) | neutral)
    reqL = np.where(mL <= 0, 0, np.minimum(np.maximum(1, np.ceil(mL * 0.6)), mL))
    reqS = np.where(mS <= 0, 0, np.minimum(np.maximum(1, np.ceil(mS * 0.6)), mS))
    return LC, SC, reqL, reqS, a14


def ats(d, v9=True):
    o, h, l, c = d["o"], d["h"], d["l"], d["c"]
    LC, SC, reqL, reqS, a14 = ats_votes(d)
    if v9:
        enL = (LC >= reqL) & (reqL > 0); enS = (SC >= reqS) & (reqS > 0)
        exL = SC >= np.maximum(1, np.ceil(reqS * 0.8)); exS = LC >= np.maximum(1, np.ceil(reqL * 0.8))
    else:
        enL, enS, exL, exS = LC >= 3, SC >= 3, SC >= 3, LC >= 3
    bk = Book(); pos, eC, e, tr = 0, 0.0, 0.0, np.nan
    for i in range(60, len(c) - 1):
        if pos:
            if v9:
                tv = min(max(a14[i] * 2.0, c[i] * 0.001), c[i] * 0.05)
                prof = pos * (c[i] - eC) / eC * 100
                if tr != tr:
                    tr = eC * (1 - pos * 0.025)
                elif prof >= 0.5:
                    tr = max(tr, h[i] - tv) if pos > 0 else min(tr, l[i] + tv)
            slx = (c[i] <= eC * 0.975) if pos > 0 else (c[i] >= eC * 1.025)
            trx = v9 and ((c[i] <= tr) if pos > 0 else (c[i] >= tr))
            if (exL[i] if pos > 0 else exS[i]) or slx or trx:
                bk.close(pos, e, o[i + 1]); pos = 0; tr = np.nan
            continue
        if enL[i] or enS[i]:
            pos = 1 if enL[i] else -1; eC, e, tr = c[i], o[i + 1], np.nan
    if pos:
        bk.close(pos, e, c[-1])
    return bk.tot, bk.n


# =================================================================================================
# 3–4. ZigZag (signalLib = ZigZag++) · FSS+GR-lite · BS-GR-Combo
# =================================================================================================
def zigzag(d, depth=30, dev=5, back=5):
    h, l = d["h"], d["l"]; n = len(h); tk = tick(d) * dev
    hh, ll = rmaxN(h, depth), rminN(l, depth)
    with np.errstate(invalid="ignore"):
        ch = (hh - h) > tk; cl = (l - ll) > tk
    hr = barssince(~bshift(ch) & (np.arange(n) > 0)); lr = barssince(~bshift(cl) & (np.arange(n) > 0))
    g = gt(hr, lr)
    x = barssince(~g)
    dr = np.where(ge(x, back), -1, 1)
    z2 = np.full(n, np.nan)
    zp, z2p = l[0], h[0]
    for i in range(n):
        if i and dr[i] != dr[i - 1]:
            z2p = zp
        if dr[i] > 0:
            if h[i] > z2p:
                z2p = h[i]; zp = l[i]
            if l[i] < zp:
                zp = l[i]
        else:
            if l[i] < z2p:
                z2p = l[i]; zp = h[i]
            if h[i] > zp:
                zp = h[i]
        z2[i] = z2p
    return dr, z2


def fss_lite(d):
    o, h, l, c = d["o"], d["h"], d["l"], d["c"]; n = len(c)
    dr, z2 = zigzag(d)
    dch = np.r_[False, dr[1:] != dr[:-1]]; pm = np.r_[False, z2[1:] != z2[:-1]]
    rb = (dch | pm) & (dr < 0); rs = (dch | pm) & (dr > 0)
    hc, lc = rmaxN(c, 200), rminN(c, 200)
    lvL, lvH = lc + (hc - lc) * 0.25, lc + (hc - lc) * 0.75
    bk = Book(); pos, e, s, t = 0, 0.0, np.nan, np.nan
    sig, sp, wc = 0, np.nan, 0
    for i in range(n - 1):
        if pos and i >= 1:
            r = stop_hit(pos, o[i], h[i], l[i], s, t)
            if r:
                bk.close(pos, e, r[0], r[1]); pos = 0
        if rb[i]:
            sig, sp, wc = 1, l[i], 0
        elif rs[i]:
            sig, sp, wc = -1, h[i], 0
        elif sig:
            wc += 1
        if sig and wc >= 2:
            ok = (sig > 0 and lt(c[i], lvL[i])) or (sig < 0 and gt(c[i], lvH[i]))
            if ok and pos == 0 and i >= 200:
                en = c[i]; raw = sp * (1 - sig * 0.001)
                sdist = max(en * 0.0005, min(en * 0.02, abs(en - raw)))
                tdist = max(en * 0.001, min(en * 0.04, sdist * 1.5))
                pos, e = sig, o[i + 1]; s, t = en - sig * sdist, en + sig * tdist
            sig, sp, wc = 0, np.nan, 0
    if pos:
        bk.close(pos, e, c[-1])
    return bk.tot, bk.n


def bsgr_sig(d):
    dr, _ = zigzag(d)
    ch = np.r_[False, dr[1:] != dr[:-1]]
    return to_sig(ch & (dr < 0), ch & (dr > 0))


# =================================================================================================
# 5. TUTCI
# =================================================================================================
def tutci(d):
    h, l = d["h"], d["l"]
    up, lo = rmaxN(h, 20), rminN(l, 20); sup, sdn = rmaxN(h, 10), rminN(l, 10)
    with np.errstate(invalid="ignore"):
        buy = (h == shift(up)) | xover(h, shift(up))
        sell = (l == shift(lo)) | xover(shift(lo), l)
        bx = (l == shift(sdn)) | xover(shift(sdn), l)
        sx = (h == shift(sup)) | xover(h, shift(sup))
    O1, O2, O3, O4 = barssince(buy), barssince(sell), barssince(bx), barssince(sx)
    le_ = buy & lt(O3, shift(O1)); se_ = sell & lt(O4, shift(O2))
    lx = bx & lt(O1, shift(O3)); sx_ = sx & lt(O2, shift(O4))
    return sim(d, to_sig(le_, se_), sl=0.02, tp=0.04, xsig=to_sig(lx, sx_))


# =================================================================================================
# 6. VSA Precision
# =================================================================================================
def vsa(d):
    o, h, l, c, v = d["o"], d["h"], d["l"], d["c"], d["v"]; n = len(c)
    vma = smaN(v, 20); a = patr(d, 14)
    p75 = np.full(n, np.nan)
    if n >= 100:
        p75[99:] = np.partition(_sw(v, 100), 74, axis=1)[:, 74]
    hv = gt(v, p75); uhv = gt(v / vma, 2.5)
    rg = h - l; wide = ge(rg, a * 1.2); narrow = le(rg, a * 0.8)
    body = np.abs(c - o); upb, dnb = c > o, c < o
    e20 = emaN(c, 20); tu, td = gt(c, e20), lt(c, e20)
    lo10, hi10, lo20 = rminN(l, 10), rmaxN(h, 10), rminN(l, 20)
    mid = np.abs(c - (h + l) * 0.5) <= rg * 0.2
    acc = td & dnb & wide & hv & (c > l)
    spr = td & le(l, lo10) & dnb & hv & (c > l)
    bag = td & dnb & narrow & uhv & le(l, lo20) & (c > l) & (body > rg * 0.2)
    efm = td & narrow & lt(c, shift(c)) & hv & mid
    dis = tu & upb & wide & hv & (c < h)
    upt = tu & ge(h, hi10) & upb & hv & (c < h)
    erm = tu & narrow & gt(c, shift(c)) & hv & mid
    L = (acc | spr | bag | efm) & td; S = (dis | upt | erm) & tu
    bk = Book(); pos, e, st = 0, 0.0, np.nan
    for i in range(60, n - 1):
        if pos and st == st:
            r = stop_hit(pos, o[i], h[i], l[i], st, np.nan)
            if r:
                bk.close(pos, e, r[0]); pos = 0; st = np.nan
        new = False
        if L[i] and pos <= 0:
            if pos:
                bk.close(pos, e, o[i + 1])
            pos, e, st, new = 1, o[i + 1], np.nan, True
        elif S[i] and pos >= 0:
            if pos:
                bk.close(pos, e, o[i + 1])
            pos, e, st, new = -1, o[i + 1], np.nan, True
        if pos and not new:
            if pos > 0:
                st = h[i] * 0.99 if h[i] >= e * 1.005 else e - 1.5 * a[i]
            else:
                st = l[i] * 1.01 if l[i] <= e * 0.995 else e + 1.5 * a[i]
    if pos:
        bk.close(pos, e, c[-1])
    return bk.tot, bk.n


# =================================================================================================
# 7. S&R Power + RSI Div Zones
# =================================================================================================
def srpower(d):
    o, h, l, c = d["o"], d["h"], d["l"], d["c"]; n = len(c)
    osc = rsi(change(c, 10), 14)
    bull, bear = PS.pivot_div(osc, l, h, 5, 5, 5, 50)
    a2 = patr(d, 200) * 0.5
    buyTop = rminN(l, 130) + a2; sellBot = rmaxN(h, 130) - a2
    fL, fS = le(l, buyTop), ge(h, sellBot)
    BL, BR = [], []
    bk = Book(); pos, e, s, t = 0, 0.0, np.nan, np.nan
    pL = pS = False; eL = eS = -1
    for i in range(1, n - 1):
        if bull[i]:
            BL.append(l[i - 5]); BL = BL[-10:]
        if bear[i]:
            BR.append(h[i - 5]); BR = BR[-10:]
        BL = [x for x in BL if h[i] > x]; BR = [x for x in BR if l[i] < x]
        bl = BL[-1] if BL else np.nan; br = BR[-1] if BR else np.nan
        ls = bl == bl and l[i] <= bl and l[i - 1] > bl
        ss = br == br and h[i] >= br and h[i - 1] < br
        if pos:
            r = stop_hit(pos, o[i], h[i], l[i], s, t)
            if r:
                bk.close(pos, e, r[0], r[1]); pos = 0
        if pos:
            pL = pS = False; continue
        want = 0
        if ls:
            if fL[i]:
                want = 1
            else:
                pL, eL = True, i + 2
        if ss and not want:
            if fS[i]:
                want = -1
            else:
                pS, eS = True, i + 2
        if not want and pL:
            if fL[i]:
                want = 1
            elif i >= eL:
                pL = False
        if not want and pS:
            if fS[i]:
                want = -1
            elif i >= eS:
                pS = False
        if want and i >= 200:
            pos, e = want, o[i + 1]; s, t = c[i] * (1 - want * 0.01), c[i] * (1 + want * 0.02)
            pL = pS = False
    if pos:
        bk.close(pos, e, c[-1])
    return bk.tot, bk.n


# =================================================================================================
# 8. GridBot v6 — счёт целиком
# =================================================================================================
def gridbot(d, lot=0.10):
    o, h, l, c = d["o"], d["h"], d["l"], d["c"]; n = len(c)
    Y = c[0]; GI = 0.01
    G = np.sort(np.r_[[Y * (1 - GI * (k + 0.5)) for k in range(5)], [Y * (1 + GI * (k + 0.5)) for k in range(5)]])
    cash, units, nf = 1.0, 0.0, 0
    peak, mdd, ruin, LSI = 1.0, 0.0, False, 5

    def trade(qty, px):
        nonlocal cash, units, nf
        cash -= qty * px + abs(qty) * px * TK; units += qty; nf += 1
    for i in range(1, n - 1):
        RMB = int(np.searchsorted(G, l[i], "left")); LMS = int(np.searchsorted(G, h[i], "right")) - 1
        buy = RMB < LSI and l[i] <= G[8]
        sell = LMS > LSI and LMS >= 0 and h[i] >= G[1]
        LSI = RMB if buy else (LMS if sell else LSI)
        px = o[i + 1]
        if buy:
            if units < 0:
                trade(-units, px)
            trade(lot / px, px)
        if sell:
            if units > 0:
                trade(-units, px)
            trade(-lot / px, px)
        worst = cash + units * (l[i + 1] if units > 0 else h[i + 1])
        eq = cash + units * c[i + 1]
        peak = max(peak, eq); mdd = max(mdd, (peak - min(eq, worst)) / peak if peak > 0 else 1.0)
        if worst <= 0:
            ruin = True; break
    eq = cash + units * c[-1] - abs(units) * c[-1] * TK
    return (eq - 1.0 if not ruin else -1.0), nf, mdd, ruin


# =================================================================================================
# 9–10. Larry Williams Donchian Breakout V3 / V2
# =================================================================================================
def pivots_hl(x, L, R, high=True):
    n = len(x); out = np.full(n, np.nan); W = L + R + 1
    if n < W:
        return out
    win = _sw(x, W); cen = x[L:n - R]
    ok = cen == (win.max(axis=1) if high else win.min(axis=1))
    out[W - 1:][ok] = cen[ok]
    return out


def lw_cond(d):
    o, h, l, c, v = d["o"], d["h"], d["l"], d["c"], d["v"]
    ph = shift(pivots_hl(h, 2, 4, True)); pl = shift(pivots_hl(l, 2, 4, False))
    phl = nz(ffill(ph)); pll = nz(ffill(pl))
    topP, botP = rmaxN(phl, 20), rminN(pll, 20); midP = (topP + botP) / 2
    topC, botC = rmaxN(h, 20), rminN(l, 20); midC = (topC + botC) / 2
    top, bot, mid = np.fmax(topP, topC), np.fmin(botP, botC), (midP + midC) / 2

    def flat(x):
        return (shift(x, 1) == shift(x, 2)) & (shift(x, 2) == shift(x, 3)) & ~np.isnan(shift(x, 3))
    t1, b1 = shift(top), shift(bot)
    bL = flat(top) & xover(h, t1) & gt(h, shift(top, 1)) & gt(h, shift(top, 2)) & gt(h, shift(top, 3))
    bS = flat(bot) & xunder(l, b1) & lt(l, shift(bot, 1)) & lt(l, shift(bot, 2)) & lt(l, shift(bot, 3))
    with np.errstate(invalid="ignore", divide="ignore"):
        dL = nz((h - t1) / np.abs(t1) * 100); dS = nz((b1 - l) / np.abs(b1) * 100)
        lw = sma(c - nz(shift(c, 8)), 8) / patr(d, 8) * 50 + 50
        slL, slS = mid * 0.999, mid * 1.001
        sdL, sdS = np.abs(c - slL) / c * 100, np.abs(slS - c) / c * 100
        cw = np.maximum(top - bot, 0) / np.abs(mid) * 100
    volok = gt(v, smaN(v, 30)); chok = ge(cw, 2.0)
    LC = bL & (dL >= 0.2) & gt(lw, 50) & volok & le(sdL, 3.0) & chok
    SC = bS & (dS >= 0.2) & ~gt(lw, 50) & volok & le(sdS, 3.0) & chok
    return LC, SC, mid


def larry(d, time_exit=True):
    o, h, l, c = d["o"], d["h"], d["l"], d["c"]; n = len(c)
    LC, SC, mid = lw_cond(d)
    bk = Book(); ods = []
    st = {1: dict(adds=0, last=None, trail=False, e0=np.nan), -1: dict(adds=0, last=None, trail=False, e0=np.nan)}
    prev = 0
    for i in range(60, n - 1):
        for od in list(ods):
            if od["fill"] > i:
                continue
            r = stop_hit(od["side"], o[i], h[i], l[i], od["sl"], od["tp"])
            if r:
                bk.close(od["side"], od["e"], r[0], r[1]); ods.remove(od)
        dr = ods[0]["side"] if ods else 0
        if dr == 0:
            for k in (1, -1):
                st[k].update(adds=0, last=None, trail=False)
        elif dr != prev:
            st[-dr].update(adds=0, last=None, trail=False); st[dr]["trail"] = False
        nxt = o[i + 1]

        def enter(sd):
            sl0 = mid[i] * (1 - sd * 0.001); tp = c[i] + 2.0 * (c[i] - sl0)
            ods.append(dict(side=sd, e=nxt, eC=c[i], sl=sl0, tp=tp, bar=i, be=False, fill=i + 1))
        for sd, cond in ((1, LC), (-1, SC)):
            if cond[i] and (dr * sd) <= 0:
                for od in [x for x in ods if x["side"] == -sd]:
                    bk.close(-sd, od["e"], nxt); ods.remove(od)
                st[sd]["adds"] = 0; enter(sd); st[sd]["last"] = i; st[sd]["e0"] = c[i]
                break
        else:
            for sd, cond in ((1, LC), (-1, SC)):
                s_ = st[sd]
                if dr == sd and cond[i] and s_["adds"] < 3 and (s_["last"] is None or i - s_["last"] >= 5):
                    s_["adds"] += 1; enter(sd); s_["last"] = i
        prev = dr
        for od in list(ods):
            sd = od["side"]; s_ = st[sd]
            new = mid[i] * (1 - sd * 0.001)
            if not od["be"] and sd * (c[i] - od["eC"] * (1 + sd * 0.015)) >= 0:
                new = max(new, od["eC"] * 1.001) if sd > 0 else min(new, od["eC"] * 0.999); od["be"] = True
            if s_["e0"] == s_["e0"]:
                if not s_["trail"] and sd * (c[i] - s_["e0"] * (1 + sd * 0.02)) >= 0:
                    s_["trail"] = True
                if s_["trail"]:
                    new = max(new, mid[i]) if sd > 0 else min(new, mid[i])
            od["sl"] = new
            if time_exit and i - od["bar"] >= 50 and od["fill"] <= i:
                bk.close(sd, od["e"], nxt); ods.remove(od)
    for od in ods:
        bk.close(od["side"], od["e"], c[-1])
    return bk.tot, bk.n


# =================================================================================================
# 11. Take Profit X
# =================================================================================================
def supertrend_dir(d, mult=3.0, n=10):
    h, l, c = d["h"], d["l"], d["c"]; a = patr(d, n); hl2 = (h + l) / 2
    up, dn = hl2 - mult * a, hl2 + mult * a
    dr = np.ones(len(c), int); uf, df, stp = np.nan, np.nan, np.nan
    for i in range(len(c)):
        pu, pd_ = uf, df
        uf = up[i] if not (pu == pu) or not (c[i - 1] > pu) else max(up[i], pu)
        df = dn[i] if not (pd_ == pd_) or not (c[i - 1] < pd_) else min(dn[i], pd_)
        if i == 0 or not (a[i - 1] == a[i - 1]):
            dr[i] = 1
        elif stp == pd_:
            dr[i] = -1 if c[i] > df else 1
        else:
            dr[i] = 1 if c[i] < uf else -1
        stp = uf if dr[i] == -1 else df
    return dr


def tpx_sig(d):
    h, l, c = d["h"], d["l"], d["c"]
    r = rsi(c, 14)
    m = emaN(c, 12) - emaN(c, 26); ms = emaN(m, 9)
    hh, ll = rmaxN(h, 14), rminN(l, 14)
    with np.errstate(invalid="ignore", divide="ignore"):
        st = 100 * (c - ll) / (hh - ll)
    k = smaN(st, 3); dd = smaN(k, 3)
    bb = smaN(c, 20); dv = 2 * stdevN(c, 20)
    sdir = supertrend_dir(d)
    cc = cci(c, 20)
    ef, es = emaN(c, 12), emaN(c, 26)
    bull = (gt(r, 70).astype(int) + xunder(m, ms) + (xunder(k, dd) & gt(k, 80)) + gt(c, bb + dv) + (sdir == -1)
            + gt(cc, 100) + xunder(ef, es) + gt(c, shift(c, 5)))
    bear = (lt(r, 30).astype(int) + xover(m, ms) + (xover(k, dd) & lt(k, 20)) + lt(c, bb - dv) + (sdir == 1)
            + lt(cc, -100) + xover(ef, es) + lt(c, shift(c, 5)))
    bTP = (bull >= 5) & (bull > bear); sTP = ~bTP & (bear >= 5) & (bear > bull)
    return to_sig(sTP, bTP)          # бычий «тейк» → шорт, медвежий → лонг


# =================================================================================================
# 12. Strategy [High-Low Cloud Trend]
# =================================================================================================
def hlc_strat(d):
    o, h, l, c, v = d["o"], d["h"], d["l"], d["c"], d["v"]; n = len(c)
    hi, lo, hi1, lo1 = rmaxN(h, 35), rminN(l, 35), rmaxN(h, 8), rminN(l, 8)
    val = np.full(n, np.nan); p = np.nan
    for i in range(n):
        if l[i] == lo[i]:
            p = hi[i]
        elif h[i] == hi[i]:
            p = lo[i]
        else:
            p = 0.0 if p != p else p
        val[i] = p
    up = gt(c, val)
    band, band1 = np.where(up, lo, hi), np.where(up, lo1, hi1)
    tdir = np.where(up, 1, -1)
    volok = gt(v, smaN(v, 20) * 1.5); r = rsi(c, 14)
    m = emaN(c, 12) - emaN(c, 26); ms = emaN(m, 9)
    bret = (tdir > 0) & gt(c, band) & le(l, band1) & gt(shift(l), shift(band1)) & (c > o)
    sret = (tdir < 0) & lt(c, band) & ge(h, band1) & lt(shift(h), shift(band1)) & (c < o)
    L = bret & volok & lt(r, 30) & gt(m, ms); S = sret & volok & gt(r, 70) & lt(m, ms)
    a = patr(d, 14)
    sig = to_sig(L, S); slv = c - sig * 1.5 * a; tpv = c + sig * 2.0 * a
    return sim(d, sig, sl=slv, tp=tpv, rev=True, refresh=True)


# =================================================================================================
# 13. МЕГА RSI — регулярная дивергенция
# =================================================================================================
def mega_sig(d):
    bull, bear = PS.pivot_div(rsi(d["c"], 14), d["l"], d["h"], 5, 5, 5, 60)
    return to_sig(bull, bear)


# =================================================================================================
# 14. Order Block Strategy (OBS.V1)
# =================================================================================================
def ob_strat(d, L=13):
    o, h, l, c = d["o"], d["h"], d["l"], d["c"]; n = len(c)
    hi_, lo_ = np.maximum(o, c), np.minimum(o, c)
    up, dn = rmaxN(h, L), rminN(l, L)
    bT = np.full(n, np.nan); bB = np.full(n, np.nan); sT = np.full(n, np.nan); sB = np.full(n, np.nan)
    os_, pos_ = 0, 0
    top = [np.nan, -1, False]; bot = [np.nan, -1, False]
    bull, bear, nb, ns = (np.nan, np.nan), (np.nan, np.nan), 0, 0
    for i in range(n):
        if i >= L:
            if h[i - L] > up[i]:
                os_ = 0
            elif l[i - L] < dn[i]:
                os_ = 1
            if os_ == 0 and pos_ != 0:
                top = [h[i - L], i - L, False]
            if os_ == 1 and pos_ != 1:
                bot = [l[i - L], i - L, False]
        pos_ = os_
        if top[0] == top[0] and c[i] > top[0] and not top[2] and i >= 1:
            top[2] = True; mi, ma = hi_[i - 1], lo_[i - 1]
            for k in range(1, i - top[1] + 1):
                mi = min(lo_[i - k], mi)
                if mi == lo_[i - k]:
                    ma = hi_[i - k]
            bull = (ma, mi); nb += 1
        if nb and c[i] < bull[1]:
            nb -= 1
        if bot[0] == bot[0] and c[i] < bot[0] and not bot[2] and i >= 1:
            bot[2] = True; mi, ma = lo_[i - 1], hi_[i - 1]
            for k in range(1, i - bot[1] + 1):
                ma = max(hi_[i - k], ma)
                if ma == hi_[i - k]:
                    mi = lo_[i - k]
            bear = (ma, mi); ns += 1
        if ns and c[i] > bear[0]:
            ns -= 1
        if nb:
            bT[i], bB[i] = bull
        if ns:
            sT[i], sB[i] = bear
    okb = ~np.isnan(bB) & ~np.isnan(bT); oks = ~np.isnan(sT) & ~np.isnan(sB)
    bE = (okb & le(l, bB) & gt(c, bB)) | (le(l, bT) & ge(c, bT))
    sE = (oks & ge(h, sT) & lt(c, sT)) | (ge(h, sB) & le(c, sB))
    pcl = ~np.isnan(sT) & ge(h, sB); pcs = ~np.isnan(bB) & le(l, bT)
    fcl = ~np.isnan(bB) & (ge(h, sT) | lt(c, bB)); fcs = ~np.isnan(sT) & (le(l, bB) | gt(c, sT))
    bk = Book(); pos, e, w, part, fb = 0, 0.0, 1.0, False, 0
    for i in range(60, n - 1):
        start = pos
        if pos and i > fb:
            s = e * (1 - pos * 0.011); t = e * (1 + pos * 0.032)
            r = stop_hit(pos, o[i], h[i], l[i], s, t)
            if r:
                bk.close(pos, e, r[0], r[1], w); pos = 0; continue
        if pos:
            if (pcl[i] if pos > 0 else pcs[i]):
                if not part:
                    bk.close(pos, e, o[i + 1], False, w * 0.5); w *= 0.5; part = True
                else:
                    bk.close(pos, e, o[i + 1], False, w); pos = 0; continue
            if (fcl[i] if pos > 0 else fcs[i]):
                bk.close(pos, e, o[i + 1], False, w); pos = 0
            continue
        if start == 0 and (bE[i] or sE[i]):
            pos = 1 if bE[i] else -1; e, w, part, fb = o[i + 1], 1.0, False, i + 1
    if pos:
        bk.close(pos, e, c[-1], False, w)
    return bk.tot, bk.n


# =================================================================================================
# 15. 3 Eye • Strategy 8.12
# =================================================================================================
def three_eye(d):
    o, h, l, c = d["o"], d["h"], d["l"], d["c"]; n = len(c)
    don = lambda k: (rmaxN(h, k) + rminN(l, k)) / 2  # noqa: E731
    conv, base = don(9), don(26); lead1, lead2 = (conv + base) / 2, don(52)
    sA, sB = shift(lead1, 25), shift(lead2, 25)
    kt, kb = np.fmax(sA, sB), np.fmin(sA, sB); has = ~np.isnan(sA) & ~np.isnan(sB)
    ma = emaN(c, 200)
    cc = cci((h + l + c) / 3, 20)
    a = patr(d, 14); atrok = ~gt(h - l, a * 2.5)
    lc = gt(shift(cc), -1e18) & lt(shift(cc), 100) & gt(cc, 100) & has & gt(c, kt) & gt(conv, kt) & gt(base, kt) & gt(c, ma) & atrok
    sc = lt(shift(cc), 1e18) & gt(shift(cc), -100) & lt(cc, -100) & has & lt(c, kb) & lt(conv, kb) & lt(base, kb) & lt(c, ma) & atrok
    inL = has & le(l, kt) & ge(l, kb); inS = has & ge(h, kb) & le(h, kt); inK = has & le(c, kt) & ge(c, kb)
    bk = Book(); pos, e, fb = 0, 0.0, 0
    aL = aS = True
    for i in range(60, n - 1):
        if pos and i > fb:
            r = stop_hit(pos, o[i], h[i], l[i], e * (1 - pos * 0.01), e * (1 + pos * 0.02))
            if r:
                bk.close(pos, e, r[0], r[1]); pos = 0
        if pos == 0:
            if inL[i]:
                aL = True
            if inS[i]:
                aS = True
            if inK[i]:
                aL = aS = True
        done = False
        for sd, cond in ((1, lc), (-1, sc)):
            if cond[i] and (aL if sd > 0 else aS) and pos * sd <= 0 and not done:
                if pos:
                    bk.close(pos, e, o[i + 1])
                pos, e, fb, done = sd, o[i + 1], i + 1, True
                aL, aS = (False, True) if sd > 0 else (True, False)
        if pos and not done and i - fb >= 50:
            bk.close(pos, e, o[i + 1]); pos = 0
    if pos:
        bk.close(pos, e, c[-1])
    return bk.tot, bk.n


# (название, функция → (сумма, сделок[, просадка, разорение]), "acct" для сетки)
TESTS = [
    ("ATS-Multi v9 (голоса 60%, трейл)", lambda d: ats(d, True), ""),
    ("ATS-Multi v7 (3 голоса, стоп 2.5%)", lambda d: ats(d, False), ""),
    ("FSS+GR-lite ZigZag (стоп/тейк 1.5R)", fss_lite, ""),
    ("BS-GR ZigZag — разворот", rev_test(bsgr_sig), ""),
    ("BS-GR ZigZag + стоп2/тейк3 ATR", rev_test(bsgr_sig, True), ""),
    ("TUTCI 20/10, стоп 2% тейк 4%", tutci, ""),
    ("VSA Precision (трейл)", vsa, ""),
    ("S&R Power + RSI div (2%/1%)", srpower, ""),
    ("GridBot v6 (счёт, лот 10%)", gridbot, "acct"),
    ("LW Donchian V3 (время 50)", lambda d: larry(d, True), ""),
    ("LW Donchian V2 (без времени)", lambda d: larry(d, False), ""),
    ("Take Profit X — разворот", rev_test(tpx_sig), ""),
    ("Take Profit X + стоп2/тейк3 ATR", rev_test(tpx_sig, True), ""),
    ("High-Low Cloud strategy (1.5/2 ATR)", hlc_strat, ""),
    ("МЕГА RSI дивергенция — разворот", rev_test(mega_sig), ""),
    ("МЕГА RSI дивергенция + стоп2/тейк3 ATR", rev_test(mega_sig, True), ""),
    ("Order Block OBS.V1 (1.1%/3.2%)", ob_strat, ""),
    ("3 Eye 8.12 (CCI+Ишимоку, 1%/2%)", three_eye, ""),
]


def main():
    t0 = time.time()
    say(f"Скрипты из чата 2026-10-17 на OKX · {time.strftime('%Y-%m-%d %H:%M')} · комиссии мейкер {MK*100:.2f}% / тейкер {TK*100:.2f}%")
    say("Средний результат на инструмент (сумма сделок, 1× депозита), 1-я и 2-я половины истории отдельно; сигнал на закрытии → вход по открытию.")
    passed = {}
    for gname, syms, need, minbars in (("КРИПТА · 12 монет", COINS, 8, 600), ("TradFi OKX · XAU XAG XCU CL BZ NG", TRADFI, 4, 300)):
        tradfi = need == 4
        for code, tf, nb in TFS:
            data = {}
            for s in syms:
                try:
                    d = okx_klines(s, code, nb)
                except Exception as exc:  # noqa: BLE001
                    say(f"  {s} {tf}: ошибка загрузки {type(exc).__name__}: {str(exc)[:80]}"); continue
                if len(d["c"]) >= minbars:
                    data[s] = d
                else:
                    say(f"  {s} {tf}: мало истории на OKX ({len(d['c'])} свечей) — пропуск")
            if len(data) < (6 if not tradfi else 3):
                say(f"=== {gname} · {tf}: мало инструментов с данными ({len(data)}) ==="); continue
            days = np.median([(d["t"][-1] - d["t"][0]) / 86400000 for d in data.values()])
            say(""); say(f"=== {gname} · {tf} · ~{days:.0f} дней · инструментов {len(data)} ===")
            for name, fn, kind in TESTS:
                full, h1, h2, nn, dds, ruins, errs = [], [], [], 0, [], 0, 0
                for s, d in data.items():
                    CTX["tick"] = TICKS.get(s)
                    try:
                        a = fn(d); b1 = fn(half(d, 0)); b2 = fn(half(d, 1))
                    except Exception as exc:  # noqa: BLE001
                        errs += 1
                        say(f"  {name} {s}: ошибка {type(exc).__name__}: {str(exc)[:90]}"); continue
                    full.append(a[0]); h1.append(b1[0]); h2.append(b2[0]); nn += a[1]
                    if kind == "acct":
                        dds.append(a[2]); ruins += bool(a[3])
                CTX["tick"] = None
                if not full:
                    say(f"  {name}: нет результатов"); continue
                avg, a1, a2 = np.mean(full) * 100, np.mean(h1) * 100, np.mean(h2) * 100
                plus = sum(x > 0 for x in full)
                ok = avg > 0 and a1 > 0 and a2 > 0 and plus >= min(need, len(full) - 1) and nn > 0
                if ok:
                    passed.setdefault((("TradFi: " if tradfi else "") + name), []).append(tf)
                extra = f" · макс. просадка (медиана) {np.median(dds)*100:.0f}% · разорений {ruins}" if kind == "acct" else ""
                why = "  (нет сделок)" if nn == 0 else ""
                say(f"  {name:<40} {avg:+8.1f}% · в плюсе {plus:>2}/{len(full)} · 1-я {a1:+7.1f}% · 2-я {a2:+7.1f}%"
                    f" · сделок {nn} (~{nn / len(full):.0f} на инстр.){extra}  {'✅' if ok else '❌'}{why}   ({time.time() - t0:.0f} с)")
    say(""); say("ИТОГ (★ — прошёл и на 1h, и на 4h):")
    if not passed:
        say("  ни один тест не прошёл")
    for k, v in passed.items():
        say(f"  {'★ ' if len(v) >= 2 else '  '}{k}: {', '.join(v)}")
    say("Пропущены: FCN (нужны OI/фандинг/CVD), Eigen (текст, не код), 3in1 Swings/CPR, Pivot Points MTF, Liquidity "
        "Thermal Map (только визуализация); FAST SIGNALS WITHOUT REDRAW и SRPOWER2 — дубликаты логики.")
    OUT.parent.mkdir(exist_ok=True)
    OUT.write_text("\n".join(LINES), encoding="utf-8")
    print(f"\nОтчёт: {OUT}  ({time.time() - t0:.0f} с)")


if __name__ == "__main__":
    main()
