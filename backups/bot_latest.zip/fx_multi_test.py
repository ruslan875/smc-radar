"""fx_multi_test.py — 2026-10-05. Проверка классических систем на традиционных рынках (золото, нефть, валюты, индексы).
Данные Yahoo, как в fx_channel_test. Честно: история делится пополам, рабочая система — плюс в обеих половинах
и на большинстве инструментов. Издержки 0.03% на сделку. Одна позиция за раз.
Системы:
  1. RSI(2) возврат: выше SMA200 и RSI2<10 → лонг (зеркально шорт), выход: закрытие выше SMA5 / стоп 2 ATR.   (1D, 4h)
  2. Боллинджер возврат: закрытие за BB(20,2) против тренда SMA200 нет → возврат к средней, стоп 1.5 ATR.      (1D, 4h)
  3. Черепахи: пробой 55-дневного максимума/минимума, выход по 20-дневному противоположному, стоп 2 ATR.       (1D)
  4. Пересечение SMA 50/200: в сторону тренда, выход по обратному пересечению.                                (1D)
  5. Пробой Лондона: диапазон 00–07 UTC (1h), пробой 07–12 UTC, стоп — другая сторона диапазона, тейк 1.5R, выход в 20 UTC. (1h)
  6. Импульс 3 месяца: раз в месяц в сторону доходности за 63 дня, держать месяц.                              (1D)
Результат — fx_multi_test.csv.
"""
import csv
import numpy as np
import pandas as pd
import fx_channel_test as F

COST = 0.0003


def ind(d):
    c = d.c.values; h = d.h.values; l = d.l.values
    pc = np.r_[c[0], c[:-1]]; tr = np.maximum(h - l, np.maximum(abs(h - pc), abs(l - pc)))
    s = pd.Series(c)
    dlt = s.diff(); up = dlt.clip(lower=0).ewm(alpha=1 / 2, adjust=False).mean(); dn = (-dlt.clip(upper=0)).ewm(alpha=1 / 2, adjust=False).mean()
    return {"atr": pd.Series(tr).ewm(alpha=1 / 14, adjust=False).mean().values, "sma5": s.rolling(5).mean().values,
            "sma20": s.rolling(20).mean().values, "sd20": s.rolling(20).std().values, "sma50": s.rolling(50).mean().values,
            "sma200": s.rolling(200).mean().values, "rsi2": (100 - 100 / (1 + up / dn.replace(0, 1e-12))).values,
            "hh55": pd.Series(h).rolling(55).max().shift(1).values, "ll55": pd.Series(l).rolling(55).min().shift(1).values,
            "hh20": pd.Series(h).rolling(20).max().shift(1).values, "ll20": pd.Series(l).rolling(20).min().shift(1).values}


def sim(d, entry_fn, exit_fn, stop_mult):
    """Общий прогон: вход по закрытию, стоп stop_mult·ATR, выход по exit_fn на закрытии. Итог в R."""
    I = ind(d); c, h, l, t = d.c.values, d.h.values, d.l.values, d.t.values
    out = []; i = 200
    while i < len(c) - 1:
        side = entry_fn(I, c, i)
        if not side:
            i += 1; continue
        e = c[i]; risk = stop_mult * I["atr"][i]; stop = e - side * risk; r = None
        for j in range(i + 1, len(c)):
            if (l[j] <= stop) if side > 0 else (h[j] >= stop): r = -1.0; break
            if exit_fn(I, c, j, side): r = side * (c[j] - e) / risk; break
        else:
            r = side * (c[-1] - e) / risk
        out.append((t[i], r - COST * e / risk)); i = j + 1
    return out


def rsi2(d):
    return sim(d, lambda I, c, i: 1 if c[i] > I["sma200"][i] and I["rsi2"][i] < 10 else -1 if c[i] < I["sma200"][i] and I["rsi2"][i] > 90 else 0,
               lambda I, c, j, s: (c[j] > I["sma5"][j]) if s > 0 else (c[j] < I["sma5"][j]), 2.0)


def boll(d):
    return sim(d, lambda I, c, i: 1 if c[i] < I["sma20"][i] - 2 * I["sd20"][i] else -1 if c[i] > I["sma20"][i] + 2 * I["sd20"][i] else 0,
               lambda I, c, j, s: (c[j] >= I["sma20"][j]) if s > 0 else (c[j] <= I["sma20"][j]), 1.5)


def turtle(d):
    return sim(d, lambda I, c, i: 1 if c[i] > I["hh55"][i] else -1 if c[i] < I["ll55"][i] else 0,
               lambda I, c, j, s: (c[j] < I["ll20"][j]) if s > 0 else (c[j] > I["hh20"][j]), 2.0)


def smax(d):
    def en(I, c, i):
        a, b, pa, pb = I["sma50"][i], I["sma200"][i], I["sma50"][i - 1], I["sma200"][i - 1]
        return 1 if a > b and pa <= pb else -1 if a < b and pa >= pb else 0
    return sim(d, en, lambda I, c, j, s: (I["sma50"][j] < I["sma200"][j]) if s > 0 else (I["sma50"][j] > I["sma200"][j]), 4.0)


def momentum(d):
    c, t = d.c.values, d.t.values; out = []
    for i in range(63, len(c) - 21, 21):
        side = 1 if c[i] > c[i - 63] else -1
        atr = ind(d)["atr"][i] if i == 63 else None
        risk = np.std(np.diff(c[i - 63:i])) * 4.6 or 1e-9  # ≈ месячная волатильность как 1R
        out.append((t[i], side * (c[i + 21] - c[i]) / risk - COST * c[i] / risk))
    return out


def london(d1h):
    d = d1h.copy(); d["dt"] = pd.to_datetime(d.t, unit="ms", utc=True); d["day"] = d.dt.dt.date; d["hr"] = d.dt.dt.hour
    out = []
    for _, g in d.groupby("day"):
        rng = g[g.hr < 7]; tr = g[(g.hr >= 7) & (g.hr < 20)]
        if len(rng) < 4 or len(tr) < 4: continue
        hi, lo = rng.h.max(), rng.l.min(); risk = hi - lo
        if risk <= 0: continue
        side = 0; e = None
        for _, r in tr.iterrows():
            if side == 0 and r.hr < 12:
                if r.c > hi: side, e = 1, r.c
                elif r.c < lo: side, e = -1, r.c
                if side: stop = lo if side > 0 else hi; risk = abs(e - stop); tp = e + side * 1.5 * risk; continue
            if side:
                if (r.l <= stop) if side > 0 else (r.h >= stop): out.append((int(r.t), -1 - COST * e / risk)); side = 2; break
                if (r.h >= tp) if side > 0 else (r.l <= tp): out.append((int(r.t), 1.5 - COST * e / risk)); side = 2; break
        if side in (1, -1):
            last = tr.iloc[-1]; out.append((int(last.t), side * (last.c - e) / risk - COST * e / risk))
    return out


if __name__ == "__main__":
    import time
    D1, H4, H1 = {}, {}, {}
    for name, s in F.SYMS.items():
        try:
            print("загрузка", name)
            h1 = F.yahoo(s, "1h", "730d"); H1[name] = h1; H4[name] = F.to4h(h1); time.sleep(0.4)
            d = F.yahoo(s, "1d", "max"); D1[name] = d[d.t >= 1104537600000].reset_index(drop=True); time.sleep(0.4)
        except Exception as exc:  # noqa: BLE001
            print("  не загрузилось:", exc)
    tests = [("RSI(2) возврат", "1D", rsi2, D1), ("RSI(2) возврат", "4h", rsi2, H4), ("Боллинджер возврат", "1D", boll, D1),
             ("Боллинджер возврат", "4h", boll, H4), ("Черепахи 55/20", "1D", turtle, D1), ("SMA 50/200", "1D", smax, D1),
             ("Импульс 3 мес", "1D", momentum, D1), ("Пробой Лондона", "1h", london, H1)]
    rows = []
    for vname, tf, fn, src in tests:
        a = b = 0.0; nt = wins = plus = 0; per = {}
        for name, d in src.items():
            if len(d) < 260: continue
            cut = d.t.iloc[len(d) // 2]
            try:
                tr = fn(d)
            except Exception as exc:  # noqa: BLE001
                print(" ", vname, name, exc); continue
            rs = sum(r for _, r in tr); per[name] = rs; plus += rs > 0
            for tt, r in tr:
                nt += 1; wins += r > 0
                if tt < cut: a += r
                else: b += r
        row = {"система": vname, "tf": tf, "сделок": nt, "WR%": round(100 * wins / max(1, nt), 1), "R_1я_половина": round(a, 1),
               "R_2я_половина": round(b, 1), "R_на_сделку": round((a + b) / max(1, nt), 3), "в_плюсе": f"{plus}/{len(per)}",
               **{k: round(v, 1) for k, v in per.items()}}
        rows.append(row)
        print(f"{vname:20} {tf:3} | сделок {nt:5} WR {row['WR%']:5}% | 1-я {a:+7.1f}R | 2-я {b:+7.1f}R | {row['R_на_сделку']:+.3f}R/сд | в плюсе {plus}/{len(per)}")
    keys = list(dict.fromkeys(k for r in rows for k in r))
    with open(F.BASE / "fx_multi_test.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=keys, delimiter=";"); w.writeheader(); w.writerows(rows)
    print("\nГотово. Пришлите скрин или fx_multi_test.csv")
    input("Enter — закрыть")
