"""chan_1h_coins_test.py — 2026-10-26. Можно ли спасти пробой канала 1h ВЫБОРОМ МОНЕТ — честно.
Ловушка: если взять 6 монет, которые были в плюсе последние 6 мес, и смотреть их же за те же 6 мес —
результат всегда хороший (подгонка). Поэтому две честные проверки:
 A) «выбор вперёд» на 12 старых монетах: монеты выбираем по периоду 16…6 мес назад, а результат смотрим
    за последние 6 мес (их при выборе не видели). Сравниваем: выбранные vs все vs невыбранные.
 B) НОВЫЕ монеты (не участвовали ни в одном тесте): 1h против 2h/4h за 3/6/10/12 мес.
Варианты защиты: нет, умный БУ, трейл ATR без тейка (лучший для 1h в chan_protect_test).
Комиссия OKX 0.05% и Bybit 0.055% (на свечах OKX). Новые монеты качаются с OKX один раз (кеш), ~5–10 мин.
Ничего не торгует. Запуск: chan_1h_coins_test.bat → bt_lab_bots/chan_1h_coins_test.txt
"""
from __future__ import annotations
import pickle, sys, time
from pathlib import Path
import numpy as np
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import chan_protect_test as P  # noqa: E402
OUT = BASE / "bt_lab_bots" / "chan_1h_coins_test.txt"
NEW_CACHE = BASE / "market_cache" / "okx_1h_new20.pkl"
NEW = ["LTCUSDT", "BCHUSDT", "DOTUSDT", "TRXUSDT", "ATOMUSDT", "UNIUSDT", "AAVEUSDT", "FILUSDT", "APTUSDT",
       "ARBUSDT", "OPUSDT", "INJUSDT", "TIAUSDT", "WLDUSDT", "PEPEUSDT", "WIFUSDT", "ETCUSDT", "ICPUSDT",
       "SEIUSDT", "TONUSDT"]
VARS = ["нет", "умный БУ", "ATR б/тейка"]
MON = 30.4 * 864e5
LINES = []
def say(s=""):
    print(s, flush=True); LINES.append(s)

def prep(d, k):
    if k > 1:
        return P.rs(d, k * 3600_000)
    return {x: (np.asarray(d[x]) if x == "t" else np.asarray(d[x], float)) for x in ("t", "h", "l", "c")}

def win(tr, a, b):
    return sum(x[1] for x in tr if a <= x[0] < b)

def part_a(raw, fee):
    now = max(int(d["t"][-1]) for d in raw.values())
    sel0, sel1, test0 = now - 16 * MON, now - 6 * MON, now - 6 * MON
    say(f"--- A) выбор вперёд · 1h · комиссия {fee * 100:.3f}% · выбор по 16…6 мес назад, проверка — последние 6 мес ---")
    say(f"{'защита':<13}{'выбрано':>9}{'выбранные 6м':>14}{'все 6м':>9}{'остальные 6м':>14}  выбранные монеты")
    for v in VARS:
        per = {s: P.trades(prep(d, 1), v, fee) for s, d in raw.items()}
        pick = [s for s, tr in per.items() if win(tr, sel0, sel1) > 0]
        rest = [s for s in per if s not in pick]
        a = sum(win(per[s], test0, now + 1) for s in pick); b = sum(win(per[s], test0, now + 1) for s in per)
        c = sum(win(per[s], test0, now + 1) for s in rest)
        say(f"{v:<13}{len(pick):>6}/{len(per):<2}{a:>+14.1f}{b:>+9.1f}{c:>+14.1f}  {', '.join(x.replace('USDT', '') for x in pick)}")
    say("Если «выбранные 6м» не лучше «все 6м» — выбор монет по прошлому НЕ помогает, это была подгонка.")

def part_b(raw, fee):
    now = max(int(d["t"][-1]) for d in raw.values())
    say(f"--- B) НОВЫЕ монеты ({len(raw)}) · комиссия {fee * 100:.3f}% ---")
    say(f"{'ТФ':<4}{'защита':<13}" + "".join(f"{f'{m} мес':>9}" for m in (3, 6, 10, 12)) + f"{'монет+ 6м':>11}{'монет+ 12м':>12}")
    for k in (1, 2, 4):
        for v in VARS:
            per = {s: P.trades(prep(d, k), v, fee) for s, d in raw.items()}
            cells = [sum(win(tr, now - m * MON, now + 1) for tr in per.values()) for m in (3, 6, 10, 12)]
            p6 = sum(win(tr, now - 6 * MON, now + 1) > 0 for tr in per.values())
            p12 = sum(win(tr, now - 12 * MON, now + 1) > 0 for tr in per.values())
            say(f"{str(k) + 'h':<4}{v:<13}" + "".join(f"{x:>+9.1f}" for x in cells) + f"{f'{p6}/{len(per)}':>11}{f'{p12}/{len(per)}':>12}")
        say("")

def load_new():
    raw = pickle.loads(NEW_CACHE.read_bytes()) if NEW_CACHE.exists() else {}
    if not raw or time.time() - NEW_CACHE.stat().st_mtime > 3 * 86400:
        import okx_current_test as OC  # noqa: PLC0415
        for s in NEW:
            print(f"  качаю {s} 1h с OKX (~13 мес)…", flush=True)
            try:
                d = OC.okx_klines(s, "60", 400 * 24)
                if len(d["c"]) >= 2000:
                    raw[s] = d
            except Exception as exc:  # noqa: BLE001
                print(f"  {s}: {exc}", flush=True)
        NEW_CACHE.parent.mkdir(exist_ok=True); NEW_CACHE.write_bytes(pickle.dumps(raw))
    return raw

def main():
    t0 = time.time()
    say(f"Пробой канала 1h: выбор монет и новые монеты · {time.strftime('%Y-%m-%d %H:%M')}")
    old = P.load(P.OKX_CACHE)
    if old:
        for fee in (0.0005, 0.00055):
            say(""); part_a(old, fee)
    new = load_new()
    if new:
        for fee in (0.0005, 0.00055):
            say(""); part_b(new, fee)
    else:
        say("Новые монеты не скачались (нет связи с OKX?) — запусти ещё раз позже.")
    say("Решение: включать 1h только если (A) выбор вперёд лучше «всех» И (B) на новых монетах 1h в плюсе за 6 и 12 мес")
    say("на ≥ 60% монет. Иначе 1h остаётся выключенным, торгуем 2h/4h.")
    say(f"Время: {time.time() - t0:.0f} с")
    OUT.parent.mkdir(exist_ok=True); OUT.write_text("\n".join(LINES), encoding="utf-8"); print(f"\nОтчёт: {OUT}")

if __name__ == "__main__":
    main()
