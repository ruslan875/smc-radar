#!/usr/bin/env python3
"""
RSI + Connors + ADX + SuperTrend + EMA - port of rsi_connors_adx_st_ema_full_visual_strategy.pine
==================================================================================================

SOURCE: strategies/rsi_connors_adx_st_ema_full_visual_strategy.pine (v6, (c) VaIr)

WHAT SURVIVED THE PORT, AND WHAT DID NOT

The script's title advertises RSI, Connors RSI, ADX, MFI, ROC, SuperTrend and
EMA. Four of those toggles - use_mfi, use_roc, use_volume, use_rsi2 - have no
indicator behind them anywhere in the file. They are inputs that change
nothing. use_ema is the same: it gates a plot, while the EMA cross is an
unconditional part of every signal. The author's saved config has "MFI: true",
which is worth knowing: the settings that were tuned include a filter that
was never running.

They are not ported. What is left, and what the strategy actually is:

    entry long : close crosses UP through EMA(21) taken from the 15m chart
                 AND RSI(14) < 30
                 AND ADX(14) between 20 and 45
                 AND close above the SuperTrend(10, 3.0) line
    entry short: mirror image, RSI > 70, close below SuperTrend

Connors RSI is implemented and available, but its toggle is off in the Pine
defaults, so the baseline run does not use it.

THE CONTRADICTION WORTH NOTICING BEFORE READING ANY RESULT

A long needs RSI below 30 (oversold) at the same moment as price above the
SuperTrend line (uptrend) and ADX above 20 (a trend in progress). Those
conditions pull against each other, so signals will be rare by construction.
A thin sample here is the design, not bad luck, and the trade count should be
read before the profit factor.

THE 15m EMA

ema_tf is hardcoded to "15" in the source. On a 1h chart that is a LOWER
timeframe, and Pine returns the last 15m value inside the hourly bar. This
port reproduces that properly: it loads 15m candles separately, computes
EMA(21) on them, and aligns each value to the chart bar it was actually known
inside of. The same code path handles a higher ema_tf correctly too - it takes
the last CLOSED higher-timeframe bar, so nothing repaints either way.
Pass --ema-tf "" to use the chart timeframe and skip the extra download.

EXITS, REPRODUCED AS WRITTEN

Every bar, from the entry price:
    sl = the TIGHTER of (entry -1%) and (entry - 1.5*ATR(14))
    tp = entry + (entry - sl) * 1.618          <- computed BEFORE break-even
    if close >= entry * 1.01: sl = entry        <- break-even

Two properties of this that are easy to miss:

* Break-even is NOT sticky. It is re-evaluated from scratch on every bar, so
  if price pushes 1% up and then falls back, the stop drops from entry all the
  way back to -1%. Reproduced as written; --sticky-be makes it latch, which is
  what most people assume it already does.
* Because the stop is recomputed each bar from the CURRENT bar's ATR, levels
  can only be set at a bar's close and can only be hit from the next bar
  onward. That is how Pine runs it, and it means the entry bar carries no
  stop. This is inherent to the design here, not a bug to flag.

Costs come from --commission and --slippage-pct; the Pine sets none.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

import pine_ta as ta
from port_common import (deals_frame, load_from_ccxt, load_sources, net_pnl_pct,
                         print_summary, write_manifest)

DEFAULTS = {
    "use_rsi1": True, "rsi_len": 14, "rsi_os": 30, "rsi_ob": 70,
    "adx_len": 14, "adx_min": 20, "adx_max": 45,
    "ema_len": 21, "ema_tf": "15",
    "st_period": 10, "st_mult": 3.0,
    "use_crsi": False, "crsi_os": 30, "crsi_ob": 70,
    "sl_pct": 1.0, "atr_len": 14, "atr_mult": 1.5, "use_sl_atr": True,
    "tp_pct": 2.0, "fibo_ext": 1.618, "use_tp_fibo": True,
    "be_trigger": 1.0, "use_be": True,
}

_TF_MIN = {"1m": 1, "3m": 3, "5m": 5, "15m": 15, "30m": 30, "1h": 60, "2h": 120,
           "4h": 240, "6h": 360, "12h": 720, "1d": 1440}


def _tf_minutes(tf: str) -> int:
    tf = str(tf).strip()
    if tf in _TF_MIN:
        return _TF_MIN[tf]
    if tf.isdigit():                       # Pine writes minutes as bare numbers
        return int(tf)
    if tf.upper() in ("D", "1D"):
        return 1440
    raise ValueError(f"unrecognised timeframe: {tf!r}")


def _tf_ccxt(tf: str) -> str:
    m = _tf_minutes(tf)
    for name, mins in _TF_MIN.items():
        if mins == m:
            return name
    raise ValueError(f"no ccxt timeframe for {tf!r}")


def align_other_tf(series: pd.Series, series_tf: str,
                   chart_index: pd.DatetimeIndex, chart_tf: str) -> pd.Series:
    """Map a series computed on one timeframe onto chart bars, without leaking.

    A bar's value is only knowable once that bar has closed, so each value is
    stamped with open + its own timeframe and then taken as-of the chart bar's
    CLOSE. Works in both directions: for a lower timeframe this gives the last
    sub-bar inside the chart bar (what Pine does), for a higher one the last
    fully closed bar.
    """
    known_at = series.index + pd.Timedelta(minutes=_tf_minutes(series_tf))
    src = pd.DataFrame({"known_at": known_at, "value": series.to_numpy()}).dropna()
    src = src.sort_values("known_at")
    chart_close = chart_index + pd.Timedelta(minutes=_tf_minutes(chart_tf))
    tgt = pd.DataFrame({"known_at": chart_close}).sort_values("known_at")
    merged = pd.merge_asof(tgt, src, on="known_at", direction="backward")
    return pd.Series(merged["value"].to_numpy(), index=chart_index)


def compute_signals(df: pd.DataFrame, cfg: dict, ema_series: pd.Series) -> pd.DataFrame:
    out = df.copy()
    out["ema_htf"] = ema_series
    out["rsi"] = ta.rsi(out["close"], cfg["rsi_len"])
    out["adx"] = ta.adx(out, cfg["adx_len"])
    st_line, _ = ta.supertrend(out, cfg["st_mult"], cfg["st_period"])
    out["st_line"] = st_line
    out["atr"] = ta.atr(out, cfg["atr_len"])
    out["crsi"] = ta.connors_rsi(out) if cfg["use_crsi"] else np.nan

    cross_up = ta.crossover(out["close"], out["ema_htf"])
    cross_dn = ta.crossunder(out["close"], out["ema_htf"])
    adx_ok = (out["adx"] >= cfg["adx_min"]) & (out["adx"] <= cfg["adx_max"])

    crsi_buy = (out["crsi"] < cfg["crsi_os"]) if cfg["use_crsi"] else True
    crsi_sell = (out["crsi"] > cfg["crsi_ob"]) if cfg["use_crsi"] else True
    rsi_buy = (out["rsi"] < cfg["rsi_os"]) if cfg["use_rsi1"] else True
    rsi_sell = (out["rsi"] > cfg["rsi_ob"]) if cfg["use_rsi1"] else True

    out["long_signal"] = (cross_up & rsi_buy & adx_ok
                          & (out["close"] > out["st_line"]) & crsi_buy)
    out["short_signal"] = (cross_dn & rsi_sell & adx_ok
                           & (out["close"] < out["st_line"]) & crsi_sell)
    out["long_signal"] = out["long_signal"].fillna(False)
    out["short_signal"] = out["short_signal"].fillna(False)
    return out


def _levels(side: str, entry: float, atr_val: float, close: float,
            cfg: dict, be_latched: bool):
    """Stop and target as the Pine computes them, in the Pine's order."""
    if side == "long":
        sl = entry * (1 - cfg["sl_pct"] / 100)
        if cfg["use_sl_atr"] and not np.isnan(atr_val):
            sl = max(sl, entry - atr_val * cfg["atr_mult"])
        tp = (entry + (entry - sl) * cfg["fibo_ext"]) if cfg["use_tp_fibo"] \
            else entry * (1 + cfg["tp_pct"] / 100)
        hit_be = cfg["use_be"] and (be_latched or close >= entry * (1 + cfg["be_trigger"] / 100))
        if hit_be:
            sl = entry
    else:
        sl = entry * (1 + cfg["sl_pct"] / 100)
        if cfg["use_sl_atr"] and not np.isnan(atr_val):
            sl = min(sl, entry + atr_val * cfg["atr_mult"])
        tp = (entry - (sl - entry) * cfg["fibo_ext"]) if cfg["use_tp_fibo"] \
            else entry * (1 - cfg["tp_pct"] / 100)
        hit_be = cfg["use_be"] and (be_latched or close <= entry * (1 - cfg["be_trigger"] / 100))
        if hit_be:
            sl = entry
    return sl, tp, hit_be


def run_backtest(df: pd.DataFrame, cfg: dict, commission_pct: float,
                 slippage_pct: float, sticky_be: bool) -> pd.DataFrame:
    deals, pos, pending = [], None, None
    idx = df.index
    o, h, l, c = (df[k].to_numpy(dtype=float) for k in ("open", "high", "low", "close"))
    atr_v = df["atr"].to_numpy(dtype=float)
    ls = df["long_signal"].to_numpy(dtype=bool)
    ss = df["short_signal"].to_numpy(dtype=bool)

    def close_pos(price, ts, reason):
        nonlocal pos
        deals.append({
            "entry_time": pos["entry_time"], "exit_time": ts, "side": pos["side"],
            "entry_price": pos["entry_price"], "exit_price": price,
            "gross_pnl_pct": net_pnl_pct(pos["side"], pos["entry_price"], price,
                                         commission_pct, slippage_pct),
            "reason": reason})
        pos = None

    for i in range(len(df)):
        ts = idx[i]

        if pending is not None:
            side, reason = pending
            pending = None
            if pos is not None and side != pos["side"]:
                close_pos(o[i], ts, reason)
            if pos is None and side in ("long", "short"):
                pos = {"side": side, "entry_time": ts, "entry_price": o[i],
                       "sl": None, "tp": None, "be": False}

        # levels placed at the previous close are what this bar can hit
        if pos is not None and pos["sl"] is not None:
            if pos["side"] == "long":
                if l[i] <= pos["sl"]:
                    close_pos(pos["sl"], ts, "stop_loss")
                elif h[i] >= pos["tp"]:
                    close_pos(pos["tp"], ts, "take_profit")
            else:
                if h[i] >= pos["sl"]:
                    close_pos(pos["sl"], ts, "stop_loss")
                elif l[i] <= pos["tp"]:
                    close_pos(pos["tp"], ts, "take_profit")

        if pos is None:
            if ls[i]:
                pending = ("long", "entry")
            elif ss[i]:
                pending = ("short", "entry")
            continue

        # a signal against an open position reverses it at the next open
        if ls[i] and pos["side"] == "short":
            pending = ("long", "reverse")
        elif ss[i] and pos["side"] == "long":
            pending = ("short", "reverse")

        sl, tp, be = _levels(pos["side"], pos["entry_price"], atr_v[i], c[i], cfg,
                             pos["be"] if sticky_be else False)
        pos["sl"], pos["tp"] = sl, tp
        if sticky_be:
            pos["be"] = pos["be"] or be

    if pos is not None:
        close_pos(c[-1], idx[-1], "end_of_data")
    return deals_frame(deals)


def main():
    p = argparse.ArgumentParser(description="RSI+Connors+ADX+SuperTrend+EMA backtester")
    p.add_argument("--symbol")
    p.add_argument("--symbols", nargs="+")
    p.add_argument("--csv")
    p.add_argument("--exchange", default="bybit")
    p.add_argument("--market", default="swap", choices=["swap", "spot"])
    p.add_argument("--timeframe", default="1h")
    p.add_argument("--start", default="2024-01-01")
    p.add_argument("--end", default="2025-12-31")
    p.add_argument("--out", default="backtest_out_rsi_connors")
    p.add_argument("--commission", type=float, default=0.055)
    p.add_argument("--slippage-pct", type=float, default=0.0)
    p.add_argument("--ema-tf", default=DEFAULTS["ema_tf"],
                   help='timeframe for the signal EMA; "15" as in the Pine, '
                        '"" for the chart timeframe')
    p.add_argument("--ema-len", type=int, default=DEFAULTS["ema_len"])
    p.add_argument("--rsi-len", type=int, default=DEFAULTS["rsi_len"],
                   help="Pine default 14; the author's saved config says 10")
    p.add_argument("--no-rsi1", action="store_true",
                   help="turn off the RSI filter (use_rsi1=false, an input the "
                        "Pine already has). With it ON, long needs a cross UP "
                        "through the EMA at the same instant RSI is below 30 - "
                        "two things that essentially never coincide, so the "
                        "faithful defaults produce no trades at all.")
    p.add_argument("--use-crsi", action="store_true",
                   help="add the Connors RSI filter (off in the Pine defaults)")
    p.add_argument("--sticky-be", action="store_true",
                   help="make break-even latch instead of being re-evaluated each bar")
    args = p.parse_args()

    cfg = dict(DEFAULTS)
    cfg.update(ema_len=args.ema_len, rsi_len=args.rsi_len, use_crsi=args.use_crsi,
               use_rsi1=not args.no_rsi1)

    out_dir = Path(args.out)
    write_manifest(out_dir, Path(__file__).stem, args,
                   extra_keys=("ema_tf", "ema_len", "rsi_len", "use_crsi",
                               "no_rsi1", "sticky_be"))

    sources = load_sources(args, p)
    ema_tf = args.ema_tf.strip()

    print("\n" + "=" * 100)
    print("RSI + CONNORS + ADX + SUPERTREND + EMA - BACKTEST RESULTS")
    rsi_txt = (f"RSI({cfg['rsi_len']}) <{cfg['rsi_os']}/>{cfg['rsi_ob']}"
               if cfg["use_rsi1"] else "RSI filter OFF")
    print(f"EMA({cfg['ema_len']}) on {ema_tf or args.timeframe} | {rsi_txt} | ADX({cfg['adx_len']}) "
          f"{cfg['adx_min']}-{cfg['adx_max']} | ST({cfg['st_period']},{cfg['st_mult']})"
          f"{' | +ConnorsRSI' if cfg['use_crsi'] else ''}")
    print(f"SL: tighter of -{cfg['sl_pct']}% and {cfg['atr_mult']}xATR | "
          f"TP: entry + risk x{cfg['fibo_ext']} | BE at +{cfg['be_trigger']}%"
          f"{' (sticky)' if args.sticky_be else ' (re-evaluated every bar, as in the Pine)'}")
    print("NOT ported: use_mfi / use_roc / use_volume / use_rsi2 - no indicator exists "
          "behind those toggles in the source.")
    if cfg["use_rsi1"]:
        print("WARNING: with the RSI filter on, a long needs a cross UP through the EMA "
              "on the same bar RSI is below 30. Expect zero or near-zero trades - "
              "that is the strategy, not the port. --no-rsi1 tests it without.")
    print("=" * 100)

    for sym, ohlcv in sources.items():
        if len(ohlcv) < 300:
            print(f"  {sym:14s}: insufficient data ({len(ohlcv)} bars)")
            continue

        if ema_tf and _tf_minutes(ema_tf) != _tf_minutes(args.timeframe):
            if args.csv:
                print(f"  {sym:14s}: --csv cannot supply {ema_tf} candles for the EMA; "
                      f"falling back to the chart timeframe")
                ema_series = ta.ema(ohlcv["close"], cfg["ema_len"])
            else:
                sub = load_from_ccxt(sym, _tf_ccxt(ema_tf), args.start, args.end,
                                     args.exchange, args.market)
                ema_series = align_other_tf(ta.ema(sub["close"], cfg["ema_len"]),
                                            ema_tf, ohlcv.index, args.timeframe)
        else:
            ema_series = ta.ema(ohlcv["close"], cfg["ema_len"])

        df = compute_signals(ohlcv, cfg, ema_series)
        deals = run_backtest(df, cfg, args.commission, args.slippage_pct, args.sticky_be)
        deals.to_csv(out_dir / f"{sym.replace('/', '')}_deals.csv", index=False)
        print_summary(sym, deals)

    print("=" * 100)
    print(f"\nDeal logs + _run.json written to: {out_dir}/")


if __name__ == "__main__":
    main()
