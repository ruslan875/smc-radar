"""okx_key_check.py — 2026-10-22. Проверка, КАКОЙ ключ OKX берёт Combo XRP и какие у него права.
Ничего не торгует и НЕ печатает ключи: только метку ключа, права (perm), режим счёта и привязку IP — то,
что OKX сам отдаёт в /api/v5/account/config. Запуск: okx_key_check.bat
"""
from __future__ import annotations
import hashlib, sys
from pathlib import Path
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
from app.config import TRADE_KEYS_FILE  # noqa: E402
from app.trade_keys_store import TradeKeysStore  # noqa: E402
from app.exchanges import okx  # noqa: E402

ACCT = {"1": "Спот (деривативы НЕЛЬЗЯ)", "2": "Фьючерсный (Futures)", "3": "Мультивалютная маржа", "4": "Портфельная маржа"}

def fp(c):   # отпечаток, чтобы сравнить ключи между собой, не показывая их
    return hashlib.sha256(c["api_key"].encode()).hexdigest()[:6]

def check(name, c):
    print(f"\n--- {name} ---")
    if not c or not c.get("api_key"):
        print("  ключа нет"); return
    print(f"  отпечаток ключа: {fp(c)}  (одинаковый отпечаток = один и тот же ключ)")
    if not c.get("passphrase"):
        print("  нет passphrase — OKX без него не работает"); return
    try:
        p = okx._signed_get_once("/api/v5/account/config", c["api_key"], c["api_secret"], c["passphrase"], {})  # noqa: SLF001
        d = (p.get("data") or [{}])[0]
        perm = d.get("perm", "?")
        print(f"  метка ключа на OKX: {d.get('label') or '—'}")
        print(f"  права: {perm}   →  {'ТОРГОВЛЯ ЕСТЬ ✅' if 'trade' in perm else 'ТОРГОВЛИ НЕТ ❌ (только чтение)'}")
        print(f"  режим счёта: {ACCT.get(str(d.get('acctLv')), d.get('acctLv'))}")
        print(f"  режим позиций: {d.get('posMode')}")
        print(f"  привязка IP: {'есть' if d.get('ip') else 'нет'}")
        print(f"  KYC уровень: {d.get('kycLv', '?')}   главный/суб-аккаунт: {'суб' if d.get('mainUid') != d.get('uid') else 'главный'}")
    except Exception as exc:  # noqa: BLE001
        print(f"  OKX ответил ошибкой: {str(exc)[:200]}")

def main():
    st = TradeKeysStore(TRADE_KEYS_FILE)
    used = st.get_for_strategy("combo_xrp", "okx")
    check("ключ, который РЕАЛЬНО берёт Combo XRP", used)
    for nm in ("get_for_strategy",):
        other = st.get_for_strategy("__no_such_strategy__", "okx")
        if other and used and fp(other) != fp(used):
            check("общий ключ OKX (/tradekey okx …)", other)
        elif other and used:
            print("\nCombo XRP использует ОБЩИЙ ключ OKX (/tradekey okx …) — личного ключа comboxrp нет.")
        else:
            print("\nОбщего ключа OKX нет.")
    print("\nЕсли «ТОРГОВЛИ НЕТ» — боту отдан не тот ключ. Отправь ключ с правом «Торговля» командой:")
    print("  /tradekey comboxrp okx <ключ> <секрет> <passphrase>   (личный для Combo, имеет приоритет)")
    input("\nEnter — закрыть")

if __name__ == "__main__":
    main()
