@echo off
setlocal enabledelayedexpansion

REM Grid Configuration Tests for KC_ROC_CCI_WT Strategy
REM Tests alternative configurations to address stop-loss vulnerability in averaging orders
REM Run this from D:\VANTORIX\bot\ directory

cd /d D:\VANTORIX\bot

echo.
echo ============================================================================
echo GRID CONFIGURATION TESTS - Alternative Setups
echo ============================================================================
echo.
echo Testing 6 symbols on 30000 bars each to identify better grid configuration
echo Baseline: offsets=0,3  volumes=65,35  stop=-4%%
echo.

REM Test 1: Single order (NO AVERAGING)
echo.
echo TEST 1: NO AVERAGING (single order only)
echo offsets=0  volumes=100  stop=-4%%
echo.
python run_grid_backtest_viz.py --symbol BTCUSDT ETHUSDT SOLUSDT ARBUSDT INJUSDT HYPEUSDT --bars 30000 --grid-offsets 0 --grid-volumes 100 --no-closeup --out backtest_out_no_avg

REM Test 2: Wider averaging (offsets at -5% instead of -3%)
echo.
echo TEST 2: WIDER AVERAGING
echo offsets=0,5  volumes=65,35  stop=-4%%
echo.
python run_grid_backtest_viz.py --symbol BTCUSDT ETHUSDT SOLUSDT ARBUSDT INJUSDT HYPEUSDT --bars 30000 --grid-offsets 0,5 --grid-volumes 65,35 --no-closeup --out backtest_out_wider_avg

REM Test 3: Reduced weight on 2nd order
echo.
echo TEST 3: REDUCED 2ND ORDER WEIGHT
echo offsets=0,3  volumes=80,20  stop=-4%%
echo.
python run_grid_backtest_viz.py --symbol BTCUSDT ETHUSDT SOLUSDT ARBUSDT INJUSDT HYPEUSDT --bars 30000 --grid-offsets 0,3 --grid-volumes 80,20 --no-closeup --out backtest_out_reduced_2nd

REM Test 4: Wider stop loss for averaging scenarios
echo.
echo TEST 4: WIDER STOP LOSS
echo offsets=0,3  volumes=65,35  stop=-6%%
echo.
python run_grid_backtest_viz.py --symbol BTCUSDT ETHUSDT SOLUSDT ARBUSDT INJUSDT HYPEUSDT --bars 30000 --grid-offsets 0,3 --grid-volumes 65,35 --stop-loss-pct 6.0 --no-closeup --out backtest_out_wider_stop

REM Test 5: Combined - wider averaging + reduced weight
echo.
echo TEST 5: COMBINED - Wider Averaging + Reduced Weight
echo offsets=0,5  volumes=80,20  stop=-4%%
echo.
python run_grid_backtest_viz.py --symbol BTCUSDT ETHUSDT SOLUSDT ARBUSDT INJUSDT HYPEUSDT --bars 30000 --grid-offsets 0,5 --grid-volumes 80,20 --no-closeup --out backtest_out_combined

REM Test 6: Aggressive - wider everything
echo.
echo TEST 6: AGGRESSIVE - Wider Stop + Wider Averaging
echo offsets=0,5  volumes=65,35  stop=-6%%
echo.
python run_grid_backtest_viz.py --symbol BTCUSDT ETHUSDT SOLUSDT ARBUSDT INJUSDT HYPEUSDT --bars 30000 --grid-offsets 0,5 --grid-volumes 65,35 --stop-loss-pct 6.0 --no-closeup --out backtest_out_aggressive

echo.
echo ============================================================================
echo ALL TESTS COMPLETED
echo ============================================================================
echo.
echo Results saved to:
echo   - backtest_out_no_avg\
echo   - backtest_out_wider_avg\
echo   - backtest_out_reduced_2nd\
echo   - backtest_out_wider_stop\
echo   - backtest_out_combined\
echo   - backtest_out_aggressive\
echo.
echo Next: Review CSV files in each directory and compare average P&L across configs
echo.
pause
