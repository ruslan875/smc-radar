"""levando_test.py — 2026-10-28. Проверка «LE VAN DO Swing Signals 7.9-X» (присланный Pine).

Что на самом деле делает скрипт (режим по умолчанию Open/Close + Trailing, фильтр «No Filtering»):
  берёт свечи Хейкен-Аши на таймфрейме в 18 раз старше графика (1h → 18h, 4h → 72h) через request.security
  с lookahead=barmerge.lookahead_on и входит, когда HA close пересекает HA open. Выход — переворот в обратную сторону.
ВАЖНО: lookahead_on на старшем ТФ = скрипт на истории «видит» итог старшей свечи, которая ещё не закрылась.
Поэтому на истории в TradingView он выглядит почти идеально, а вживую сигналы перерисовываются.

Тест сравнивает:
  «как в TradingView» — с заглядыванием вперёд (так рисует бэктест TV; повторить вживую нельзя);
  «честно»            — только по уже ЗАКРЫТОЙ старшей свече (так он работает вживую).
Выходы: (1) переворот по обратному сигналу, как в скрипте; (2) стоп 2.5·ATR20 и тейки 2.5/5/7.5·ATR частями 50/30/20%, как в его блоке риска.
Комиссия+проскальзывание 0.11% за круг. 12 монет, свечи 1h и 4h (кэш kvoo_longtest).
"""
from __future__ import annotations

import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
FEE = 0.0011
MULT = 18


def ha_htf(d: pd.DataFrame, tf_ms: int):
    """HA open/close старшего ТФ; для каждой базовой свечи — значения «честно» и «с заглядыванием»."""
    H = tf_ms * MULT
    g = d.assign(b=d.t // H * H).groupby("b")
    hb = pd.DataFrame({"o": g.o.first(), "h": g.h.max(), "l": g.l.min(), "c": g.c.last()})
    hac = (hb.o + hb.h + hb.l + hb.c) / 4
    hao = hac.copy()
    hao.iloc[0] = (hb.o.iloc[0] + hb.c.iloc[0]) / 2
    for i in range(1, len(hb)):
        hao.iloc[i] = (hao.iloc[i - 1] + hac.iloc[i - 1]) / 2
    bucket = (d.t // H * H).values
    pos = np.searchsorted(hb.index.values, bucket)                 # старшая свеча, в которой лежит базовая
    look_o, look_c = hao.values[pos], hac.values[pos]               # итог ТЕКУЩЕЙ старшей свечи — будущее
    # честно: последняя старшая свеча, закрывшаяся к закрытию базовой свечи
    end = d.t.values + tf_ms
    closed = np.where(end >= bucket + H, pos, pos - 1)
    ok = closed >= 0
    hon_o = np.where(ok, hao.values[np.clip(closed, 0, None)], np.nan)
    hon_c = np.where(ok, hac.values[np.clip(closed, 0, None)], np.nan)
    return (look_o, look_c), (hon_o, hon_c)


def sig(o, c):
    up = (c > o) & (np.r_[False, (c <= o)[:-1]])
    dn = (c < o) & (np.r_[False, (c >= o)[:-1]])
    return up, dn


def run_reverse(d, up, dn):
    c = d.c.values; t = d.t.values; out = []; pos = 0; e = 0.0; et = 0
    for i in range(len(c)):
        s = 1 if up[i] else -1 if dn[i] else 0
        if s and s != pos:
            if pos:
                out.append((et, pos * (c[i] / e - 1) - FEE))
            pos, e, et = s, c[i], t[i]
    return out


def run_atr(d, up, dn):
    h, l, c, t = d.h.values, d.l.values, d.c.values, d.t.values
    pc = np.r_[c[0], c[:-1]]
    tr = np.maximum(h - l, np.maximum(abs(h - pc), abs(l - pc)))
    atr = pd.Series(tr).ewm(alpha=1 / 20, adjust=False).mean().values
    out = []; i = 0; n = len(c)
    while i < n - 1:
        s = 1 if up[i] else -1 if dn[i] else 0
        if not s:
            i += 1; continue
        e = c[i]; k = 2.5 * atr[i]; sl = e - s * k
        tps = [(e + s * k, .5), (e + s * 2 * k, .3), (e + s * 3 * k, .2)]
        left, res, j = 1.0, 0.0, i
        for j in range(i + 1, min(n, i + 300)):
            if (l[j] <= sl) if s > 0 else (h[j] >= sl):
                res += left * s * (sl / e - 1); left = 0; break
            while tps and ((h[j] >= tps[0][0]) if s > 0 else (l[j] <= tps[0][0])):
                p, q = tps.pop(0); res += q * s * (p / e - 1); left -= q
            if left <= 1e-9:
                break
            if (dn[j] if s > 0 else up[j]):                       # обратный сигнал закрывает остаток
                res += left * s * (c[j] / e - 1); left = 0; break
        if left > 1e-9:
            res += left * s * (c[j] / e - 1)
        out.append((t[i], res - FEE)); i = j + 1
    return out


def summary(all_tr, mid):
    r = np.array([x[1] for x in all_tr]) * 100
    if not len(r):
        return "сделок нет", False
    g, b = r[r > 0].sum(), -r[r < 0].sum()
    h1 = sum(x[1] for x in all_tr if x[0] < mid) * 100; h2 = sum(x[1] for x in all_tr if x[0] >= mid) * 100
    return (f"{len(r)} сд, сумма {r.sum():+.0f}% (на сделку {r.mean():+.2f}%), WR {(r > 0).mean() * 100:.0f}%, PF {g / b if b else 9.9:.2f} | "
            f"1-я половина {h1:+.0f}%, 2-я {h2:+.0f}%"), (h1 > 0 and h2 > 0)


def main():
    import kvoo_longtest as K  # noqa: PLC0415
    lines = []
    for tf, ms in (("1h", 3600_000), ("4h", 4 * 3600_000)):
        res = {k: [] for k in ("look_rev", "hon_rev", "look_atr", "hon_atr")}
        coins = {k: 0 for k in res}; tot = 0; t0 = t1 = None
        for s in K.COINS:
            d = K.load(s, tf)
            if d is None or len(d) < 2000:
                continue
            d = d.reset_index(drop=True)[["t", "o", "h", "l", "c", "v"]] if "o" in d else d.reset_index(drop=True)
            print(f"{tf} {s}…")
            (lo, lc), (ho, hc) = ha_htf(d, ms)
            for key, (o, c) in (("look", (lo, lc)), ("hon", (ho, hc))):
                up, dn = sig(o, c)
                for ex, fn in (("rev", run_reverse), ("atr", run_atr)):
                    tr = fn(d, up, dn)
                    res[f"{key}_{ex}"] += tr
                    coins[f"{key}_{ex}"] += sum(x[1] for x in tr) > 0
            tot += 1; t0 = min(t0 or d.t.iloc[0], d.t.iloc[0]); t1 = max(t1 or 0, d.t.iloc[-1])
        mid = (t0 + t1) // 2
        names = {"look_rev": "как в TradingView (с заглядыванием), переворот", "hon_rev": "ЧЕСТНО, переворот",
                 "look_atr": "как в TradingView, стоп/тейки ATR", "hon_atr": "ЧЕСТНО, стоп/тейки ATR"}
        lines.append(f"\n=== {tf} (старший ТФ ×18), монет {tot} ===")
        for k, nm in names.items():
            txt, ok = summary(res[k], mid)
            mark = "👁" if k.startswith("look") else ("✅" if ok and coins[k] >= 8 else "❌")
            lines.append(f"{mark} {nm}: {txt} | монет в плюсе {coins[k]}/{tot}")
    txt = "\n".join(lines)
    print(txt)
    print("\n👁 — так выглядит в TradingView, вживую недостижимо (скрипт видит будущее старшей свечи).")
    print("✅ — честная версия в плюсе в обеих половинах и на ≥8 из 12 монет. Только её можно ставить бумажным ботом.")
    (BASE / "levando_test.txt").write_text(txt + "\n", encoding="utf-8")
    input("\nEnter — закрыть")


if __name__ == "__main__":
    main()
