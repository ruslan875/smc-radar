# -*- coding: utf-8 -*-
"""Честный тест Donchian Ultimate и Vortex Ultimate (EarnForex) без сетки: стоп + тейк R.
Свечи 4h (из 1h). Комиссия 0.11% крипта / 0.006% TradFi, учитывается в R.
"""
import os, sys, glob
import numpy as np, pandas as pd
try: sys.stdout.reconfigure(encoding="utf-8")
except Exception: pass
HERE = os.path.dirname(os.path.abspath(__file__))
CACHE = os.path.join(HERE, "market_cache") if os.path.isdir(os.path.join(HERE, "market_cache")) else sys.argv[1]

def load(p):
    d = pd.read_csv(p); d.index = pd.to_datetime(d.t, unit="ms")
    d = d[["o", "h", "l", "c"]].astype(float)
    return d.resample("4h").agg({"o": "first", "h": "max", "l": "min", "c": "last"}).dropna()

def atr(d, n=14):
    tr = pd.concat([d.h - d.l, (d.h - d.c.shift()).abs(), (d.l - d.c.shift()).abs()], axis=1).max(axis=1)
    return tr.ewm(alpha=1 / n, adjust=False).mean()

def signals(d, kind, n):
    """возвращает (side array, stop distance array)"""
    a = atr(d).values
    if kind == "donchian":
        up = d.h.rolling(n).max().shift(); lo = d.l.rolling(n).min().shift(); mid = (up + lo) / 2
        s = np.where(d.c > up, 1, np.where(d.c < lo, -1, 0))
        stop = (d.c - mid).abs().values           # стоп за среднюю линию
    else:  # vortex
        pm = (d.h - d.l.shift()).abs().rolling(n).sum(); mm = (d.l - d.h.shift()).abs().rolling(n).sum()
        tr = pd.concat([d.h, d.c.shift()], axis=1).max(axis=1) - pd.concat([d.l, d.c.shift()], axis=1).min(axis=1)
        vp, vm = pm / tr.rolling(n).sum(), mm / tr.rolling(n).sum()
        diff = vp - vm
        s = np.where((diff > 0) & (diff.shift() <= 0), 1, np.where((diff < 0) & (diff.shift() >= 0), -1, 0))
        stop = 2 * a
    trend = (d.c > d.c.ewm(span=200, adjust=False).mean()).values
    return s, np.asarray(stop, float), trend

def run(d, kind, n, rr, fee, trend_filter):
    s, st, tr = signals(d, kind, n)
    H, L, C = d.h.values, d.l.values, d.c.values
    res = []; i = 210
    while i < len(C) - 1:
        side = s[i]
        if side == 0 or not (st[i] > 0) or (trend_filter and (side == 1) != tr[i]): i += 1; continue
        e = C[i]; sl = e - side * st[i]; tp = e + side * rr * st[i]
        risk = st[i] / e; fr = 2 * fee / risk
        r = None; j = i + 1
        while j < len(C):
            if (side == 1 and L[j] <= sl) or (side == -1 and H[j] >= sl): r = -1; break
            if (side == 1 and H[j] >= tp) or (side == -1 and L[j] <= tp): r = rr; break
            j += 1
        if r is None: r = side * (C[-1] - e) / st[i]
        res.append((d.index[i], r - fr)); i = j + 1
    return pd.DataFrame(res, columns=["t", "r"])

def main():
    files = sorted(glob.glob(os.path.join(CACHE, "binance", "*_1h.csv")))
    tradfi = [os.path.join(CACHE, "yahoo", f) for f in ("GC_F_1h.csv", "EURUSD_X_1h.csv")]
    configs = []
    for kind, ns in (("donchian", (20, 55)), ("vortex", (14, 28))):
        for n in ns:
            for rr in (2, 3):
                for tf in (False, True):
                    configs.append((kind, n, rr, tf))
    rows = []
    for kind, n, rr, tf in configs:
        for group, fl, fee in (("крипта", files, 0.00055), ("TradFi", tradfi, 0.00003)):
            per = []
            for f in fl:
                if not os.path.exists(f): continue
                d = load(f); t = run(d, kind, n, rr, fee, tf)
                if t.empty: continue
                mid = d.index[0] + (d.index[-1] - d.index[0]) / 2
                per.append((os.path.basename(f)[:6], len(t), t.r.sum(), t[t.t < mid].r.sum(), t[t.t >= mid].r.sum()))
            if not per: continue
            p = pd.DataFrame(per, columns=["sym", "n", "R", "h1", "h2"])
            name = f"{kind} {n}, {rr}R" + (", по тренду EMA200" if tf else "")
            ok = ((p.h1 > 0) & (p.h2 > 0)).sum()
            verdict = "✅" if p.h1.sum() > 0 and p.h2.sum() > 0 and ok > len(p) / 2 else "❌"
            rows.append(dict(система=name, рынок=group, сделок=int(p.n.sum()), R_всего=round(p.R.sum(), 1),
                             R_на_сделку=round(p.R.sum() / p.n.sum(), 3), половина1=round(p.h1.sum(), 1),
                             половина2=round(p.h2.sum(), 1), инстр_ok=f"{ok}/{len(p)}", вердикт=verdict))
            print(f"{verdict} {group:6} {name:38} сделок {p.n.sum():5}  R {p.R.sum():+7.1f}  ({p.R.sum()/p.n.sum():+.3f}/сд)  H1 {p.h1.sum():+6.1f}  H2 {p.h2.sum():+6.1f}  ок {ok}/{len(p)}")
    pd.DataFrame(rows).to_csv(os.path.join(HERE, "donchian_vortex_test.csv"), index=False, encoding="utf-8-sig")

if __name__ == "__main__":
    main()
