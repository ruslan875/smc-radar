"""atr_filters_test.py — 2026-10-05. Два ATR-индикатора (присланы пользователем) как ФИЛЬТР входа:
  A) «ATR Gerchik Light» (lotophagi108): ATR(5) по True Range дневок без аномальных дней (TR ≥ 2× или ≤ ½ среднего);
     «пройдено» по направлению дня: бычий день — close−low, медвежий — high−close. Фильтр: пройдено > 75% → не входить.
  B) «Custom ATR»: средний ход high−low за 5 дней (в оригинале ошибка — исключение баров при avg=0, здесь исправлено:
     исключаются дни ≥ 2× или ≤ ⅓ среднего), «пройдено» = весь ход дня; при ≥ 65% и поглощении вчерашнего дня — сброс в 0.
Сами по себе они сигналов не дают, поэтому проверяются как фильтр на двух рабочих системах:
  пробой канала 100 (крипта 4h) и пробой канала 100 (TradFi 1D: вход раз в день — фильтр смотрит на вчерашний день).
Сравнение: без фильтра / с A / с B. Итог — atr_filters_test.csv.
"""
import sys as _sys
try:
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace"); _sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass
import csv
import numpy as np
import pandas as pd
import gerchik_test as G


def daily_maps(d):
    """Для каждой свечи: процент по A и по B на момент закрытия этой свечи (используются только прошлые дни + сегодня до этой свечи)."""
    day = (d.t // 86_400_000).values
    g = pd.DataFrame({"day": day, "o": d.o.values, "h": d.h.values, "l": d.l.values, "c": d.c.values})
    D = g.groupby("day").agg(o=("o", "first"), h=("h", "max"), l=("l", "min"), c=("c", "last"))
    pcD = D.c.shift(1)
    TR = np.maximum(D.h - D.l, np.maximum(abs(D.h - pcD), abs(D.l - pcD))).fillna(D.h - D.l)
    ref = TR.rolling(5).mean().shift(6)
    trs = TR.shift(1)
    atrA = {}
    rngB = (D.h - D.l); refB = rngB.rolling(5).mean().shift(6); atrB = {}
    for k in D.index:
        pos = D.index.get_loc(k)
        if pos < 12: continue
        last5 = TR.iloc[pos - 5:pos]; r = ref.iloc[pos]
        ok = last5[(last5 < 2 * r) & (last5 > r / 2)]
        atrA[k] = (ok if len(ok) else last5).mean()
        l5 = rngB.iloc[pos - 5:pos]; rb = refB.iloc[pos]
        okb = l5[(l5 < 2 * rb) & (l5 > rb / 3)]
        atrB[k] = (okb if len(okb) else l5).mean()
    g["dhi"] = g.groupby("day").h.cummax(); g["dlo"] = g.groupby("day").l.cummin(); g["dop"] = g.groupby("day").o.transform("first")
    prevH = g.day.map(D.h.shift(1)); prevL = g.day.map(D.l.shift(1))
    A = np.full(len(g), np.nan); B = np.full(len(g), np.nan)
    for i in range(len(g)):
        k = day[i]
        if k not in atrA: continue
        mv = (g.c.iat[i] - g.dlo.iat[i]) if g.c.iat[i] > g.dop.iat[i] else (g.dhi.iat[i] - g.c.iat[i])
        A[i] = mv / atrA[k] * 100
        pb = (g.dhi.iat[i] - g.dlo.iat[i]) / atrB[k] * 100
        if pb >= 65 and ((g.dlo.iat[i] <= prevL.iat[i] and g.dhi.iat[i] > prevH.iat[i]) or (g.dhi.iat[i] >= prevH.iat[i] and g.dlo.iat[i] < prevL.iat[i])): pb = 0
        B[i] = pb
    return A, B


def run(d, cost, flt, daily_tf):
    d = G.prep(d)
    S = G.signals(d, "КАНАЛ", None)
    if flt:
        A, B = daily_maps(d); arr = A if flt == "A" else B
        S = [s for s in S if not (arr[s[0] - (1 if daily_tf else 0)] > 75)] if not daily_tf else [s for s in S if s[0] > 0 and not (arr[s[0]] > 75)]
    return G.sim(d, S, cost, False)


if __name__ == "__main__":
    import kvoo_longtest as K
    import fx_channel_test as F
    sets = []
    for s in K.COINS:
        d = K.load(s, "4h")
        if d is not None and len(d) > 600: sets.append(("Крипта 4h", s.replace("USDT", ""), d.reset_index(drop=True), 0.0011, False))
    for name, sym in F.SYMS.items():
        print("загрузка", name)
        try:
            dd = F.yahoo(sym, "1d", "max"); sets.append(("TradFi 1D", name, dd[dd.t >= 1104537600000].reset_index(drop=True), 0.0003, True))
        except Exception as exc:  # noqa: BLE001
            print("  пропуск:", exc)
    rows = []
    for grp in ("Крипта 4h", "TradFi 1D"):
        for flt, fname in ((None, "без фильтра"), ("A", "ATR Gerchik Light ≤75%"), ("B", "Custom ATR ≤75%")):
            a = b = 0.0; nt = wins = plus = cnt = 0
            for g2, name, d, cost, dly in sets:
                if g2 != grp: continue
                cut = d.t.iat[len(d) // 2]; tr = run(d, cost, flt, dly); cnt += 1
                rs = sum(r for _, r in tr); plus += rs > 0
                for tt, r in tr:
                    nt += 1; wins += r > 0
                    if tt < cut: a += r
                    else: b += r
            ok = "✅" if nt >= 30 and a > 0 and b > 0 and plus > cnt / 2 else "  "
            rows.append({"система": "пробой канала 100", "рынок": grp, "фильтр": fname, "сделок": nt, "WR%": round(100 * wins / max(1, nt), 1),
                         "R_1я": round(a, 1), "R_2я": round(b, 1), "R_на_сделку": round((a + b) / max(1, nt), 3), "в_плюсе": f"{plus}/{cnt}", "прошла": ok.strip()})
            print(f"{ok} {grp:9} | {fname:24} | сделок {nt:5} WR {rows[-1]['WR%']:5}% | 1-я {a:+7.1f}R | 2-я {b:+7.1f}R | {rows[-1]['R_на_сделку']:+.3f}R/сд | в плюсе {plus}/{cnt}")
    with open(F.BASE / "atr_filters_test.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]), delimiter=";"); w.writeheader(); w.writerows(rows)
    print("\nФильтр полезен, если R_на_сделку с ним выше, чем без фильтра, в обеих половинах.")
    input("Enter — закрыть")
