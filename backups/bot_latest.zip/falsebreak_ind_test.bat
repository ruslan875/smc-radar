@echo off
cd /d %~dp0
if exist venv\Scripts\python.exe (venv\Scripts\python.exe falsebreak_ind_test.py) else (python falsebreak_ind_test.py)
