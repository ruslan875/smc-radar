"""lux_fbo_test.py — 2026-10-05. «Filtered False Breakout Detector» (LuxAlgo) — точный перенос и проверка на истории.
Логика: свеча [2] — локальный экстремум (выше/ниже 5 предыдущих), свеча [1] пробивает её экстремум, свеча [0] закрывается обратно.
Фильтр объёма (по умолчанию ВКЛ): объём [1] > объём [2]. У валют на Yahoo объёма нет — там тест только без фильтра.
Индикатор не даёт стоп/тейк: вход по закрытию [0], стоп за максимумом/минимумом свечей [1]–[0] + 0.1 ATR, тейк 1/2/3R, лимит 60 свечей.
Рынки и проверка — как в falsebreak_ind_test (крипта 1h/4h, TradFi 4h/1D, история пополам). Итог — lux_fbo_test.csv.
"""
import sys as _sys
try:
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace"); _sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass
import csv
import numpy as np
import pandas as pd
from falsebreak_ind_test import sim

LB = 5


def signals(d, use_vol):
    h, l, c, v = d.h.values, d.l.values, d.c.values, d.v.values; n = len(c)
    pc = np.r_[c[0], c[:-1]]; tr = np.maximum(h - l, np.maximum(abs(h - pc), abs(l - pc)))
    atr = pd.Series(tr).ewm(alpha=1 / 14, adjust=False).mean().values; out = []
    for i in range(LB + 3, n):
        vok = (not use_vol) or v[i - 1] > v[i - 2]
        if h[i - 2] >= h[i - 2 - LB:i - 2].max() and h[i - 1] > h[i - 2] and c[i] < h[i - 2] and vok:
            out.append((i, -1, max(h[i - 1], h[i]) + 0.1 * atr[i], "s"))
        elif l[i - 2] <= l[i - 2 - LB:i - 2].min() and l[i - 1] < l[i - 2] and c[i] > l[i - 2] and vok:
            out.append((i, 1, min(l[i - 1], l[i]) - 0.1 * atr[i], "b"))
    return out


if __name__ == "__main__":
    import kvoo_longtest as K
    import fx_channel_test as F
    sets = {}
    for s in K.COINS:
        for tf in ("1h", "4h"):
            d = K.load(s, tf)
            if d is not None and len(d) > 600: sets[("Крипта", tf, s.replace("USDT", ""))] = d.reset_index(drop=True)
    for name, sym in F.SYMS.items():
        print("загрузка", name)
        try:
            sets[("TradFi", "4h", name)] = F.to4h(F.yahoo(sym, "1h", "730d")).reset_index(drop=True)
            dd = F.yahoo(sym, "1d", "max"); sets[("TradFi", "1D", name)] = dd[dd.t >= 1104537600000].reset_index(drop=True)
        except Exception as exc:  # noqa: BLE001
            print("  пропуск:", exc)
    print("\nсчитаю…")
    rows = []
    for mkt, tfs, cost in (("Крипта", ("1h", "4h"), 0.0011), ("TradFi", ("4h", "1D"), 0.0003)):
        for tf in tfs:
            for use_vol in (True, False):
                for rr in (1.0, 2.0, 3.0):
                    a = b = 0.0; nt = wins = plus = 0; per = {}
                    for key, d in sets.items():
                        if key[0] != mkt or key[1] != tf: continue
                        if use_vol and d.v.sum() == 0: continue           # нет объёма (валюты)
                        cut = d.t.iat[len(d) // 2]
                        tr = sim(d, signals(d, use_vol), rr, cost); rs = sum(r for _, r in tr); per[key[2]] = round(rs, 1); plus += rs > 0
                        for tt, r in tr:
                            nt += 1; wins += r > 0
                            if tt < cut: a += r
                            else: b += r
                    ok = "✅" if nt >= 30 and a > 0 and b > 0 and plus > len(per) / 2 else "  "
                    row = {"рынок": mkt, "tf": tf, "фильтр_объёма": "да" if use_vol else "нет", "тейк": f"{rr:.0f}R", "сделок": nt,
                           "WR%": round(100 * wins / max(1, nt), 1), "R_1я": round(a, 1), "R_2я": round(b, 1),
                           "R_на_сделку": round((a + b) / max(1, nt), 3), "в_плюсе": f"{plus}/{len(per)}", "прошла": ok.strip(), **per}
                    rows.append(row)
                    print(f"{ok} {mkt:6} {tf:2} | объём {'да ' if use_vol else 'нет'} | тейк {rr:.0f}R | сделок {nt:6} WR {row['WR%']:5}% | "
                          f"1-я {a:+8.1f}R | 2-я {b:+8.1f}R | {row['R_на_сделку']:+.3f}R/сд | в плюсе {plus}/{len(per)}")
    keys = list(dict.fromkeys(k for r in rows for k in r))
    with open(F.BASE / "lux_fbo_test.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=keys, delimiter=";"); w.writeheader(); w.writerows(rows)
    print("\n✅ = плюс в обеих половинах, больше чем на половине инструментов, не меньше 30 сделок.")
    print("Готово. Пришлите скрин или lux_fbo_test.csv")
    input("Enter — закрыть")
