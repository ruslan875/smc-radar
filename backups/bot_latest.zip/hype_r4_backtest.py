#!/usr/bin/env python3
"""
R4 HYPE 1H Mirror Fibonacci Strategy
Ports configuration from R4_OKX_HYPE_1H.csv (165 parameters)
Entry: Swing highs/lows with mirror Fibonacci retracements
Exits: 4-stage partial profit taking (10%, 20%, 30%, 40%)
Filters: ATR, ADX, EMA slope, impulse, volume, choppiness, CVD, RSI, nOI, Z-score, NATR
"""

import sys
import argparse
from pathlib import Path
import json
import numpy as np
import pandas as pd
from datetime import datetime

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent))

from pine_ta import atr, rsi, adx, choppiness, natr


def linreg_slope(series, length):
    """Наклон линейной регрессии за `length` баров.

    Определён здесь, а не взят из pine_ta: в рабочей сборке проекта этой
    функции нет (там есть linreg), и импорт бы упал.
    """
    length = int(length)
    y = pd.Series(series).astype(float)
    x_mean = (length - 1) / 2.0
    var_x = sum((i - x_mean) ** 2 for i in range(length))
    if var_x == 0:
        return pd.Series(0.0, index=y.index)

    def _slope(win):
        w_mean = win.mean()
        return sum((i - x_mean) * (win[i] - w_mean) for i in range(length)) / var_x

    return y.rolling(length).apply(_slope, raw=True).fillna(0.0)


def net_pnl_pct(entry_price, exit_price, side, qty=1,
                commission_pct=0.055, slippage_pct=0.03):
    """Чистый процент по сделке после комиссии обеих сторон и проскальзывания.

    Своя реализация вместо port_common.net_pnl_pct: в рабочей сборке у той
    функции другой порядок аргументов (side первым), и молчаливое расхождение
    давало бы неверные цифры вместо ошибки.
    """
    if side == "long":
        gross = (exit_price - entry_price) / entry_price * 100.0
    else:
        gross = (entry_price - exit_price) / entry_price * 100.0
    return gross - 2.0 * commission_pct - slippage_pct


class HypeR4Strategy:
    """Mirror Fibonacci swing strategy with 4-tier profit taking"""

    def __init__(self, config):
        self.config = config
        self.positions = {}  # symbol -> {side, entry_price, qty, entry_bar, entry_time, tp_stages}
        self.closed_trades = []
        self.pending_fills = {}  # symbol -> {type, price, qty, ...}

    def init_symbol(self, symbol, df):
        """Pre-compute indicators for symbol"""
        self.positions[symbol] = None

        # Core indicators
        df['atr'] = atr(df, self.config['Mirror: Stop Distance ATR Length'])
        df['adx'] = adx(df, self.config['ADX Length Long'])

        # EMA slope filter
        ema_length = int(self.config['EMA Length (Slope)'])
        df['ema_slope'] = linreg_slope(df['close'].ewm(span=ema_length).mean(),
                                       self.config['EMA Slope Lookback'])

        # RSI
        df['rsi'] = rsi(df['close'], self.config['RSI Length'])

        # Volume spike
        df['volume_sma'] = df['volume'].rolling(20).mean()
        df['volume_ratio'] = df['volume'] / (df['volume_sma'] + 1e-8)

        # Choppiness
        df['chop'] = choppiness(df, self.config['Choppiness Length'])

        # CVD (Cumulative Volume Delta) - simplified version
        # In real Pine: uses built-in ta.cum(close > close[1] ? volume : close < close[1] ? -volume : 0)
        df['cvd_raw'] = np.where(df['close'] > df['close'].shift(1), df['volume'],
                                 np.where(df['close'] < df['close'].shift(1), -df['volume'], 0))
        df['cvd'] = df['cvd_raw'].rolling(self.config['CVD Window (bars)']).sum()
        df['cvd_ema'] = df['cvd'].ewm(span=int(self.config['CVD EMA smooth'])).mean()

        # nOI (Number of Impulses) - simplified: count up/down impulses
        # Считаем в numpy-массиве, а не через df['noi'].iloc[i] = ...:
        # при Copy-on-Write (pandas 3+) такое присваивание молча НЕ попадает
        # в исходный DataFrame, и фильтр оставался нулевым на всех барах.
        high_v = df['high'].to_numpy(dtype=float)
        low_v = df['low'].to_numpy(dtype=float)
        close_v = df['close'].to_numpy(dtype=float)
        open_v = df['open'].to_numpy(dtype=float)

        noi = np.zeros(len(df), dtype=float)
        for i in range(2, len(df)):
            up_impulse = high_v[i] > high_v[i-1] and close_v[i] > open_v[i]
            down_impulse = low_v[i] < low_v[i-1] and close_v[i] < open_v[i]
            if up_impulse or down_impulse:
                noi[i] = noi[i-1] + 1
            else:
                noi[i] = max(0.0, noi[i-1] - 1)

        df['noi'] = pd.Series(noi, index=df.index).rolling(
            int(self.config['NOI Window (bars)'])).sum()

        # Z-Score (deviation from SMA)
        sma_len = int(self.config['Length of SMA'])
        df['sma'] = df['close'].rolling(sma_len).mean()
        df['std'] = df['close'].rolling(sma_len).std()
        df['zscore'] = (df['close'] - df['sma']) / (df['std'] + 1e-8)

        # NATR
        df['natr'] = natr(df, self.config['NATR Length'])

        # Swing detection (mirror Fibo swing highs/lows)
        df['swing_high'] = False
        df['swing_low'] = False
        lookback = 2
        for i in range(lookback, len(df) - lookback):
            is_high = df['high'].iloc[i] > df['high'].iloc[i-lookback:i].max() and \
                     df['high'].iloc[i] >= df['high'].iloc[i+1:i+lookback+1].max()
            is_low = df['low'].iloc[i] < df['low'].iloc[i-lookback:i].min() and \
                    df['low'].iloc[i] <= df['low'].iloc[i+1:i+lookback+1].min()
            df.loc[df.index[i], 'swing_high'] = is_high
            df.loc[df.index[i], 'swing_low'] = is_low

        # Fibo retracement levels (from last swing)
        df['fibo_high'] = 0.0
        df['fibo_low'] = 0.0
        last_high = df['high'].iloc[0]
        last_low = df['low'].iloc[0]
        last_high_idx = 0
        last_low_idx = 0

        for i in range(len(df)):
            if df['swing_high'].iloc[i]:
                last_high = df['high'].iloc[i]
                last_high_idx = i
            if df['swing_low'].iloc[i]:
                last_low = df['low'].iloc[i]
                last_low_idx = i

            # Fibo levels for mirror targeting
            if last_high_idx > last_low_idx:  # In downtrend from high
                range_val = last_high - last_low
                fib_38 = last_high - range_val * (self.config['Fibo High Trend Limit (%)'] / 100)
                fib_88 = last_high - range_val * (self.config['Fibo Low Trend Limit (%)'] / 100)
                df.loc[df.index[i], 'fibo_high'] = fib_38
                df.loc[df.index[i], 'fibo_low'] = fib_88
            else:  # In uptrend from low
                range_val = last_high - last_low
                fib_38 = last_low + range_val * (self.config['Fibo High Trend Limit (%)'] / 100)
                fib_88 = last_low + range_val * (self.config['Fibo Low Trend Limit (%)'] / 100)
                df.loc[df.index[i], 'fibo_high'] = fib_38
                df.loc[df.index[i], 'fibo_low'] = fib_88

    def check_filters(self, row, side):
        """Verify all filter conditions for entry"""
        config = self.config

        # ATR filter
        if side == 'long' and config['ATR Active (Long)']:
            if row['atr'] < config['ATR Threshold Long']:
                return False, 'ATR too low for long'
        elif side == 'short' and config['ATR Active (Short)']:
            if row['atr'] < config['ATR Threshold Short']:
                return False, 'ATR too low for short'

        # ADX filter
        if side == 'long':
            if row['adx'] < config['ADX Long Min'] or row['adx'] > config['ADX Long Max']:
                return False, f'ADX {row["adx"]:.1f} outside [{config["ADX Long Min"]}, {config["ADX Long Max"]}]'
        else:
            if row['adx'] < config['ADX Short Min'] or row['adx'] > config['ADX Short Max']:
                return False, f'ADX {row["adx"]:.1f} outside [{config["ADX Short Min"]}, {config["ADX Short Max"]}]'

        # EMA slope filter
        if config['EMA Slope Filter Active']:
            min_slope = config['Min EMA Slope (%)'] / 100
            if side == 'long' and config['Use Slope (Long)']:
                if row['ema_slope'] < min_slope:
                    return False, 'EMA slope too flat for long'
            elif side == 'short' and config['Use Slope (Short)']:
                if row['ema_slope'] > -min_slope:
                    return False, 'EMA slope too flat for short'

        # Volume spike
        if side == 'long' and config['Volume Spike Active (Long)']:
            if row['volume_ratio'] < config['Volume Multiplier Long']:
                return False, 'Insufficient volume for long'
        elif side == 'short' and config['Volume Spike Active (Short)']:
            if row['volume_ratio'] < config['Volume Multiplier Short']:
                return False, 'Insufficient volume for short'

        # Choppiness
        if side == 'long' and config['Choppiness Active (Long)']:
            if row['chop'] > config['Choppiness Threshold Long']:
                return False, f'Chop {row["chop"]:.1f} > {config["Choppiness Threshold Long"]}'
        elif side == 'short' and config['Choppiness Active (Short)']:
            if row['chop'] > config['Choppiness Threshold Short']:
                return False, f'Chop {row["chop"]:.1f} > {config["Choppiness Threshold Short"]}'

        # CVD filter
        if config['Use CVD Filter']:
            if side == 'long':
                if row['cvd_ema'] > config['Block LONG if CVD >'] or \
                   row['cvd_ema'] < config['Block LONG if CVD <']:
                    return False, f'CVD {row["cvd_ema"]:.0f} blocks long'
            else:
                if row['cvd_ema'] > config['Block SHORT if CVD >'] or \
                   row['cvd_ema'] < config['Block SHORT if CVD <']:
                    return False, f'CVD {row["cvd_ema"]:.0f} blocks short'

        # RSI filter
        if config['Use RSI Filter']:
            if side == 'long':
                if row['rsi'] > config['Block LONG if RSI >'] or \
                   row['rsi'] < config['Block LONG if RSI <']:
                    return False, f'RSI {row["rsi"]:.1f} blocks long'
            else:
                if row['rsi'] > config['Block SHORT if RSI >'] or \
                   row['rsi'] < config['Block SHORT if RSI <']:
                    return False, f'RSI {row["rsi"]:.1f} blocks short'

        # nOI filter
        if config['Use nOI Filter']:
            if side == 'long':
                if row['noi'] > config['Block LONG if nOI >'] or \
                   row['noi'] < config['Block LONG if nOI <']:
                    return False, f'nOI blocks long'
            else:
                if row['noi'] > config['Block SHORT if nOI >'] or \
                   row['noi'] < config['Block SHORT if nOI <']:
                    return False, f'nOI blocks short'

        # Z-Score filter
        if config['Enable Z-Score filter']:
            if side == 'long':
                if row['zscore'] < config['LONG: allow if Z >']:
                    return False, f'Z-score {row["zscore"]:.2f} too low for long'
            else:
                if row['zscore'] > config['SHORT: allow if Z <']:
                    return False, f'Z-score {row["zscore"]:.2f} too high for short'

        # NATR filter
        if config['Use NATR Filter']:
            if side == 'long':
                if row['natr'] < config['NATR: Long min'] or row['natr'] > config['NATR: Long max']:
                    return False, f'NATR {row["natr"]:.2f} outside range'
            else:
                if row['natr'] < config['NATR: Short min'] or row['natr'] > config['NATR: Short max']:
                    return False, f'NATR {row["natr"]:.2f} outside range'

        return True, 'All filters pass'

    def get_stop_loss(self, entry_price, side):
        """Mirror stop distance using ATR"""
        # Placeholder - would need to pass current ATR
        if side == 'long':
            return entry_price * (1 - self.config['Long: Stop Loss (%)'] / 100)
        else:
            return entry_price * (1 + self.config['Short: Stop Loss (%)'] / 100)

    def get_tp_levels(self, entry_price, side, row):
        """Calculate 4-stage TP levels using mirror Fibo"""
        tp_levels = []
        stop_loss = self.get_stop_loss(entry_price, side)
        risk = abs(entry_price - stop_loss)

        # TP levels as % of entry
        tp1_pct = self.config['Long: Take Profit 1 (%)'] if side == 'long' else self.config['Short: Take Profit 1 (%)']
        tp2_pct = self.config['Long: Take Profit 2 (%)'] if side == 'long' else self.config['Short: Take Profit 2 (%)']
        tp3_pct = self.config['Long: Take Profit 3 (%)'] if side == 'long' else self.config['Short: Take Profit 3 (%)']
        tp4_pct = self.config['Long: Take Profit 4 (%)'] if side == 'long' else self.config['Short: Take Profit 4 (%)']

        if side == 'long':
            tp_levels = [
                entry_price * (1 + tp1_pct / 100),
                entry_price * (1 + tp2_pct / 100),
                entry_price * (1 + tp3_pct / 100),
                entry_price * (1 + tp4_pct / 100),
            ]
        else:
            tp_levels = [
                entry_price * (1 - tp1_pct / 100),
                entry_price * (1 - tp2_pct / 100),
                entry_price * (1 - tp3_pct / 100),
                entry_price * (1 - tp4_pct / 100),
            ]

        return tp_levels, stop_loss

    def process_bar(self, symbol, row, idx, df):
        """Process single bar"""
        pos = self.positions[symbol]

        # Check for entry signal
        if pos is None:
            # Long entry: swing low with filters
            if row['swing_low'] and self.config['Trade on ' + ['Mondays', 'Tuesdays', 'Wednesdays',
                                                                 'Thursdays', 'Fridays', 'Saturdays', 'Sundays'][
                                                                 pd.Timestamp(row['time']).dayofweek]]:
                filters_ok, reason = self.check_filters(row, 'long')
                if filters_ok:
                    entry_price = row['close']
                    tp_levels, sl = self.get_tp_levels(entry_price, 'long', row)
                    qty = self.config['Order Volume (lots)']

                    self.positions[symbol] = {
                        'side': 'long',
                        'entry_price': entry_price,
                        'qty': qty,
                        'entry_bar': idx,
                        'entry_time': row['time'],
                        'tp_stages': [False, False, False, False],  # Track which TPs closed
                        'tp_levels': tp_levels,
                        'sl': sl,
                        'qty_remaining': qty,
                    }

            # Short entry: swing high with filters
            elif row['swing_high'] and self.config['Trade on ' + ['Mondays', 'Tuesdays', 'Wednesdays',
                                                                   'Thursdays', 'Fridays', 'Saturdays', 'Sundays'][
                                                                   pd.Timestamp(row['time']).dayofweek]]:
                filters_ok, reason = self.check_filters(row, 'short')
                if filters_ok:
                    entry_price = row['close']
                    tp_levels, sl = self.get_tp_levels(entry_price, 'short', row)
                    qty = self.config['Order Volume (lots)']

                    self.positions[symbol] = {
                        'side': 'short',
                        'entry_price': entry_price,
                        'qty': qty,
                        'entry_bar': idx,
                        'entry_time': row['time'],
                        'tp_stages': [False, False, False, False],
                        'tp_levels': tp_levels,
                        'sl': sl,
                        'qty_remaining': qty,
                    }

        else:
            # Manage open position
            tp_fractions = [
                self.config['TP1 Fraction (%)'] / 100,
                self.config['TP2 Fraction (%)'] / 100,
                self.config['TP3 Fraction (%)'] / 100,
                self.config['TP4 Fraction (%)'] / 100,
            ]

            for stage in range(4):
                if not pos['tp_stages'][stage] and pos['qty_remaining'] > 0:
                    tp_price = pos['tp_levels'][stage]

                    # Check if TP hit
                    if pos['side'] == 'long' and row['high'] >= tp_price:
                        qty_to_close = pos['qty'] * tp_fractions[stage]
                        exit_price = tp_price
                        pnl_pct = net_pnl_pct(pos['entry_price'], exit_price, pos['side'], qty_to_close)

                        self.closed_trades.append({
                            'entry_time': pos['entry_time'],
                            'exit_time': row['time'],
                            'side': pos['side'],
                            'entry_price': pos['entry_price'],
                            'exit_price': exit_price,
                            'gross_pnl_pct': pnl_pct,
                            'reason': f'TP{stage+1}',
                            'symbol': symbol,
                        })

                        pos['qty_remaining'] -= qty_to_close
                        pos['tp_stages'][stage] = True

                    # Check if SL hit
                    elif pos['side'] == 'long' and row['low'] <= pos['sl']:
                        exit_price = pos['sl']
                        pnl_pct = net_pnl_pct(pos['entry_price'], exit_price, pos['side'], pos['qty_remaining'])

                        self.closed_trades.append({
                            'entry_time': pos['entry_time'],
                            'exit_time': row['time'],
                            'side': pos['side'],
                            'entry_price': pos['entry_price'],
                            'exit_price': exit_price,
                            'gross_pnl_pct': pnl_pct,
                            'reason': 'SL',
                            'symbol': symbol,
                        })

                        self.positions[symbol] = None
                        break

                    # Check short TP
                    elif pos['side'] == 'short' and row['low'] <= tp_price:
                        qty_to_close = pos['qty'] * tp_fractions[stage]
                        exit_price = tp_price
                        pnl_pct = net_pnl_pct(pos['entry_price'], exit_price, pos['side'], qty_to_close)

                        self.closed_trades.append({
                            'entry_time': pos['entry_time'],
                            'exit_time': row['time'],
                            'side': pos['side'],
                            'entry_price': pos['entry_price'],
                            'exit_price': exit_price,
                            'gross_pnl_pct': pnl_pct,
                            'reason': f'TP{stage+1}',
                            'symbol': symbol,
                        })

                        pos['qty_remaining'] -= qty_to_close
                        pos['tp_stages'][stage] = True

                    # Check short SL
                    elif pos['side'] == 'short' and row['high'] >= pos['sl']:
                        exit_price = pos['sl']
                        pnl_pct = net_pnl_pct(pos['entry_price'], exit_price, pos['side'], pos['qty_remaining'])

                        self.closed_trades.append({
                            'entry_time': pos['entry_time'],
                            'exit_time': row['time'],
                            'side': pos['side'],
                            'entry_price': pos['entry_price'],
                            'exit_price': exit_price,
                            'gross_pnl_pct': pnl_pct,
                            'reason': 'SL',
                            'symbol': symbol,
                        })

                        self.positions[symbol] = None
                        break

            # Объём исчерпан тейками — позиции больше нет.
            # Раньше здесь стояла только проверка qty_remaining > 0. После
            # четырёх частичных тейков (10+20+30+40 = 100%) остаток становится
            # -0.0 из-за накопления float, условие давало False, и позиция
            # висела открытой: стоп её уже не проверял (все стадии True), а в
            # конце данных она закрывалась вторично по последней цене — тот же
            # объём засчитывался и в тейки, и в огромный фантомный убыток.
            EPS = 1e-9
            if pos is not None and pos['qty_remaining'] <= EPS:
                self.positions[symbol] = None
                pos = None

            if pos and all(pos['tp_stages']) and pos['qty_remaining'] > EPS:
                exit_price = row['close']
                pnl_pct = net_pnl_pct(pos['entry_price'], exit_price, pos['side'], pos['qty_remaining'])

                self.closed_trades.append({
                    'entry_time': pos['entry_time'],
                    'exit_time': row['time'],
                    'side': pos['side'],
                    'entry_price': pos['entry_price'],
                    'exit_price': exit_price,
                    'gross_pnl_pct': pnl_pct,
                    'reason': 'TP_FINAL',
                    'symbol': symbol,
                })

                self.positions[symbol] = None


def load_config_from_csv(csv_path):
    """Load config parameters from R4_OKX_HYPE_1H.csv"""
    df = pd.read_csv(csv_path)
    config = {}
    for _, row in df.iterrows():
        key = row['Name']
        val = row['Value']
        # Parse value type
        if isinstance(val, str):
            if val.lower() in ('true', 'false'):
                config[key] = val.lower() == 'true'
            else:
                try:
                    config[key] = float(val) if '.' in str(val) else int(val)
                except:
                    config[key] = val
        else:
            config[key] = val
    return config


def backtest_symbol(symbol, df, strategy, commission_pct, slippage_pct):
    """Run backtest for single symbol - properly isolates trades per symbol"""
    strategy.init_symbol(symbol, df)

    # Track trades count before processing this symbol
    trades_count_before = len(strategy.closed_trades)

    for idx, row in df.iterrows():
        strategy.process_bar(symbol, row, idx, df)

    # Close any open position at end
    pos = strategy.positions[symbol]
    if pos is not None:
        last_row = df.iloc[-1]
        exit_price = last_row['close']
        pnl_pct = net_pnl_pct(pos['entry_price'], exit_price, pos['side'], pos['qty_remaining'],
                             commission_pct, slippage_pct)
        strategy.closed_trades.append({
            'entry_time': pos['entry_time'],
            'exit_time': last_row['time'],
            'side': pos['side'],
            'entry_price': pos['entry_price'],
            'exit_price': exit_price,
            'gross_pnl_pct': pnl_pct,
            'reason': 'EOB',
            'symbol': symbol,
        })

    # Extract only the trades added during this symbol's processing
    symbol_trades = strategy.closed_trades[trades_count_before:]
    return pd.DataFrame(symbol_trades) if symbol_trades else pd.DataFrame()


def find_config(explicit=None):
    """Путь к R4_OKX_HYPE_1H.csv. По умолчанию ищем рядом со скриптом и в
    strategies/ — прежний дефолт указывал на путь внутри песочницы, которого
    на рабочей машине не существует."""
    if explicit:
        return Path(explicit)
    here = Path(__file__).resolve().parent
    for name in ("R4_OKX_HYPE_1H.csv", "strategies/R4_OKX_HYPE_1H.csv"):
        cand = here / name
        if cand.exists():
            return cand
    hits = sorted(here.glob("**/R4_OKX_HYPE*.csv"))
    return hits[0] if hits else None


def main():
    # Интерфейс намеренно повторяет остальные порты (см. ce_zlsma_backtest.py),
    # чтобы run_backtests.py мог звать этот скрипт тем же набором аргументов.
    import argparse
    from port_common import load_sources, print_summary, write_manifest

    p = argparse.ArgumentParser(description="R4 HYPE Mirror Fibonacci strategy backtester")
    p.add_argument("--symbol")
    p.add_argument("--symbols", nargs="+")
    p.add_argument("--csv")
    p.add_argument("--exchange", default="bybit")
    p.add_argument("--market", default="swap", choices=["swap", "spot"])
    p.add_argument("--timeframe", default="1h")
    p.add_argument("--start", default="2024-01-01")
    p.add_argument("--end", default="2025-12-31")
    p.add_argument("--out", default="backtest_out_hype_r4")
    p.add_argument("--commission", type=float, default=0.055)
    p.add_argument("--slippage-pct", type=float, default=0.0)
    p.add_argument("--config", default=None,
                   help="R4_OKX_HYPE_1H.csv; по умолчанию ищется рядом и в strategies/")
    args = p.parse_args()

    cfg_path = find_config(args.config)
    if cfg_path is None or not cfg_path.exists():
        p.error("R4_OKX_HYPE_1H.csv не найден — укажи путь через --config")

    config = load_config_from_csv(str(cfg_path))

    out_dir = Path(args.out)
    write_manifest(out_dir, Path(__file__).stem, args, extra_keys=("config",))

    sources = load_sources(args, p)

    print("\n" + "=" * 100)
    print("R4 HYPE - MIRROR FIBONACCI - BACKTEST RESULTS")
    print(f"config: {cfg_path.name} ({len(config)} параметров) | "
          f"commission {args.commission}%/side | slippage {args.slippage_pct}%")
    print("Выходы: четыре частичных тейка (10/20/30/40% объёма) + стоп.")
    print("=" * 100)

    for sym, ohlcv in sources.items():
        if ohlcv is None or len(ohlcv) < 300:
            n = 0 if ohlcv is None else len(ohlcv)
            print(f"  {sym:14s}: недостаточно данных ({n} баров)")
            continue

        df = ohlcv.copy()
        # backtest_symbol читает row["time"], а загрузчик отдаёт DatetimeIndex.
        if "time" not in df.columns:
            df["time"] = df.index

        strategy = HypeR4Strategy(config)
        deals = backtest_symbol(sym, df, strategy, args.commission, args.slippage_pct)
        if len(deals):
            deals.to_csv(out_dir / f"{sym.replace('/', '')}_deals.csv", index=False)
        print_summary(sym, deals)

    print("=" * 100)
    print(f"\nЖурналы сделок + _run.json записаны в: {out_dir}/")


if __name__ == '__main__':
    main()
