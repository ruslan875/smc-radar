"""std_ind_test.py — 2026-11-03. Пакетный тест стандартных индикаторов из терминала Hash Hedge (TradingView), которые мы ещё не проверяли.

Одинаковые правила для всех: сигнал на закрытии свечи → вход по закрытию; стоп 1.5×ATR14, тейк 2R;
выход раньше — по обратному сигналу (по закрытию) или через 100 свечей. Одна позиция на монету.
R чистые: минус комиссия вход+выход. Площадки: Hash Hedge 0.03% и Bybit 0.055% (свечи Bybit), OKX 0.05% (свечи OKX).
12 монет, ~3 года, 1h/2h/4h. ✅ = 3 года плюс, обе половины плюс, ≥8/12 монет. Для сравнения: пробой канала 4h ≈ +0.15R/сд.
Индикаторы с объёмом (Klinger, Elder Force, Chaikin, VWAP) — только если в кеше свечей есть объём.
Запуск: std_ind_test.bat → bt_lab_bots/std_ind_test.txt. Ничего не торгует.
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
from chan_protect_test import BYB_CACHE, OKX_CACHE, load  # noqa: E402

OUT = BASE / "bt_lab_bots" / "std_ind_test.txt"
LINES = []
STOP_ATR, RR, MAXB = 1.5, 2.0, 100


def say(s=""):
    print(s, flush=True); LINES.append(s)


def to_df(d, hours):
    df = pd.DataFrame({"t": pd.to_datetime(np.asarray(d["t"], dtype="int64"), unit="ms"),
                       "o": np.asarray(d.get("o", d["c"]), float), "h": np.asarray(d["h"], float),
                       "l": np.asarray(d["l"], float), "c": np.asarray(d["c"], float)})
    if "v" in d:
        df["v"] = np.asarray(d["v"], float)
    df = df.set_index("t")
    if hours > 1:
        agg = {"o": "first", "h": "max", "l": "min", "c": "last"}
        if "v" in df:
            agg["v"] = "sum"
        df = df.resample(f"{hours}h").agg(agg).dropna()
    return df


def ema(s, n): return s.ewm(span=n, adjust=False).mean()
def rma(s, n): return s.ewm(alpha=1 / n, adjust=False).mean()
def wma(s, n):
    w = np.arange(1, n + 1); return s.rolling(n).apply(lambda x: np.dot(x, w) / w.sum(), raw=True)


def cross(a, b):
    """+1 когда a пересёк b вверх, −1 вниз."""
    up = (a > b) & (a.shift(1) <= b.shift(1)); dn = (a < b) & (a.shift(1) >= b.shift(1))
    return up.astype(int) - dn.astype(int)


def atr(df, n=14):
    pc = df.c.shift(1)
    tr = pd.concat([df.h - df.l, (df.h - pc).abs(), (df.l - pc).abs()], axis=1).max(axis=1)
    return rma(tr, n)


def sig_aroon(df, n=25):
    up = df.h.rolling(n + 1).apply(lambda x: x.argmax(), raw=True) / n * 100
    dn = df.l.rolling(n + 1).apply(lambda x: x.argmin(), raw=True) / n * 100
    return cross(up, dn)


def sig_ckstop(df, p=10, x=1.0, q=9):
    a = atr(df, p)
    fs_hi = df.h.rolling(p).max() - x * a; fs_lo = df.l.rolling(p).min() + x * a
    stop_short = fs_hi.rolling(q).max(); stop_long = fs_lo.rolling(q).min()
    return cross(df.c, stop_short).clip(lower=0) + cross(df.c, stop_long).clip(upper=0)


def sig_fisher(df, n=9):
    hl2 = (df.h + df.l) / 2
    mx, mn = hl2.rolling(n).max(), hl2.rolling(n).min()
    v = np.zeros(len(df)); f = np.zeros(len(df)); raw = ((hl2 - mn) / (mx - mn).replace(0, np.nan) - 0.5).fillna(0).to_numpy()
    for i in range(1, len(df)):
        v[i] = max(min(0.66 * raw[i] + 0.67 * v[i - 1], 0.999), -0.999)
        f[i] = 0.5 * np.log((1 + v[i]) / (1 - v[i])) + 0.5 * f[i - 1]
    fs = pd.Series(f, index=df.index)
    return cross(fs, fs.shift(1))


def sig_efi(df, n=13):
    return cross(ema(df.c.diff() * df.v, n), pd.Series(0, index=df.index))


def sig_smi(df, s=5, l=20, sig=5):
    d = df.c.diff()
    tsi = 100 * ema(ema(d, l), s) / ema(ema(d.abs(), l), s)
    return cross(tsi, ema(tsi, sig))


def sig_klinger(df, f=34, s=55, sig=13):
    hlc = df.h + df.l + df.c
    sv = np.where(hlc.diff() >= 0, df.v, -df.v)
    kvo = ema(pd.Series(sv, index=df.index), f) - ema(pd.Series(sv, index=df.index), s)
    return cross(kvo, ema(kvo, sig))


def sig_coppock(df):
    roc = df.c.pct_change(14) * 100 + df.c.pct_change(11) * 100
    cp = wma(roc, 10)
    return cross(cp, pd.Series(0, index=df.index))


def sig_kst(df):
    r = lambda n, m: df.c.pct_change(n).rolling(m).mean() * 100  # noqa: E731
    kst = r(10, 10) + 2 * r(15, 10) + 3 * r(20, 10) + 4 * r(30, 15)
    return cross(kst, kst.rolling(9).mean())


def sig_mass(df):
    rng = df.h - df.l; e1 = ema(rng, 9); mi = (e1 / ema(e1, 9)).rolling(25).sum()
    bulge = (mi.shift(1) > 27).rolling(10).max().fillna(0).astype(bool) & (mi < 26.5) & (mi.shift(1) >= 26.5)
    e9 = ema(df.c, 9)
    return (bulge & (df.c > e9)).astype(int) - (bulge & (df.c < e9)).astype(int)


def sig_fractal(df):
    h, l = df.h, df.l
    upf = (h.shift(2) > h.shift(3)) & (h.shift(2) > h.shift(4)) & (h.shift(2) > h.shift(1)) & (h.shift(2) > h)
    dnf = (l.shift(2) < l.shift(3)) & (l.shift(2) < l.shift(4)) & (l.shift(2) < l.shift(1)) & (l.shift(2) < l)
    lvl_up = h.shift(2).where(upf).ffill(); lvl_dn = l.shift(2).where(dnf).ffill()
    return cross(df.c, lvl_up).clip(lower=0) + cross(df.c, lvl_dn).clip(upper=0)


def sig_guppy(df):
    fast = sum(ema(df.c, n) for n in (3, 5, 8, 10, 12, 15)) / 6
    slow = sum(ema(df.c, n) for n in (30, 35, 40, 45, 50, 60)) / 6
    return cross(fast, slow)


def sig_pivot(df):
    d = df.resample("1D").agg({"h": "max", "l": "min", "c": "last"}).shift(1)
    p = (d.h + d.l + d.c) / 3; r1 = 2 * p - d.l; s1 = 2 * p - d.h
    r1 = r1.reindex(df.index, method="ffill"); s1 = s1.reindex(df.index, method="ffill")
    return cross(df.c, r1).clip(lower=0) + cross(df.c, s1).clip(upper=0)


def sig_vwap(df):
    tp = (df.h + df.l + df.c) / 3; day = df.index.floor("1D")
    vw = (tp * df.v).groupby(day).cumsum() / df.v.groupby(day).cumsum()
    e200 = ema(df.c, 200); s = cross(df.c, vw)
    return s.where(((s > 0) & (df.c > e200)) | ((s < 0) & (df.c < e200)), 0)


def sig_hull(df, n=55):
    h = wma(2 * wma(df.c, n // 2) - wma(df.c, n), int(np.sqrt(n)))
    slope = np.sign(h.diff())
    return ((slope > 0) & (slope.shift(1) <= 0)).astype(int) - ((slope < 0) & (slope.shift(1) >= 0)).astype(int)


def sig_alma(df, n=50, off=0.85, sg=6):
    m = off * (n - 1); s = n / sg; w = np.exp(-((np.arange(n) - m) ** 2) / (2 * s * s)); w /= w.sum()
    al = df.c.rolling(n).apply(lambda x: np.dot(x, w), raw=True)
    return cross(df.c, al)


def tema(s, n): e1 = ema(s, n); e2 = ema(e1, n); return 3 * e1 - 3 * e2 + ema(e2, n)
def dema(s, n): e1 = ema(s, n); return 2 * e1 - ema(e1, n)


def sig_tema(df): return cross(tema(df.c, 20), tema(df.c, 50))
def sig_dema(df): return cross(dema(df.c, 20), dema(df.c, 50))


def sig_lsma(df, n=25):
    x = np.arange(n); xm = x.mean()
    ls = df.c.rolling(n).apply(lambda y: y.mean() + np.dot(x - xm, y - y.mean()) / np.dot(x - xm, x - xm) * (n - 1 - xm), raw=True)
    return cross(df.c, ls)


def sig_alligator(df):
    hl2 = (df.h + df.l) / 2
    jaw = rma(hl2, 13).shift(8); teeth = rma(hl2, 8).shift(5); lips = rma(hl2, 5).shift(3)
    bull = (lips > teeth) & (teeth > jaw); bear = (lips < teeth) & (teeth < jaw)
    return (bull & ~bull.shift(1, fill_value=False)).astype(int) - (bear & ~bear.shift(1, fill_value=False)).astype(int)


def sig_psar(df, af0=0.02, step=0.02, mx=0.2):
    h, l = df.h.to_numpy(), df.l.to_numpy(); n = len(h); trend = np.ones(n); sar = np.zeros(n)
    up, af, ep, sar[0] = True, af0, h[0], l[0]
    for i in range(1, n):
        s = sar[i - 1] + af * (ep - sar[i - 1])
        if up:
            s = min(s, l[i - 1], l[i - 2] if i > 1 else l[i - 1])
            if l[i] < s:
                up, s, ep, af = False, ep, l[i], af0
            elif h[i] > ep:
                ep, af = h[i], min(af + step, mx)
        else:
            s = max(s, h[i - 1], h[i - 2] if i > 1 else h[i - 1])
            if h[i] > s:
                up, s, ep, af = True, ep, h[i], af0
            elif l[i] < ep:
                ep, af = l[i], min(af + step, mx)
        sar[i] = s; trend[i] = 1 if up else -1
    tr = pd.Series(trend, index=df.index)
    return ((tr > 0) & (tr.shift(1) < 0)).astype(int) - ((tr < 0) & (tr.shift(1) > 0)).astype(int)


def sig_mcginley(df, n=14):
    c = df.c.to_numpy(); md = np.zeros(len(c)); md[0] = c[0]
    for i in range(1, len(c)):
        md[i] = md[i - 1] + (c[i] - md[i - 1]) / (n * (c[i] / md[i - 1]) ** 4)
    return cross(df.c, pd.Series(md, index=df.index))


def sig_trix(df, n=15):
    tr = ema(ema(ema(np.log(df.c), n), n), n).diff() * 10000
    return cross(tr, pd.Series(0, index=df.index))


def sig_uo(df):
    pc = df.c.shift(1); bp = df.c - pd.concat([df.l, pc], axis=1).min(axis=1)
    tr = pd.concat([df.h, pc], axis=1).max(axis=1) - pd.concat([df.l, pc], axis=1).min(axis=1)
    a = lambda n: bp.rolling(n).sum() / tr.rolling(n).sum()  # noqa: E731
    uo = 100 * (4 * a(7) + 2 * a(14) + a(28)) / 7
    return cross(uo, pd.Series(30, index=df.index)).clip(lower=0) + cross(uo, pd.Series(70, index=df.index)).clip(upper=0)


def sig_stochrsi(df):
    d = df.c.diff(); rs = rma(d.clip(lower=0), 14) / rma((-d).clip(lower=0), 14)
    r = 100 - 100 / (1 + rs); st = (r - r.rolling(14).min()) / (r.rolling(14).max() - r.rolling(14).min()) * 100
    k = st.rolling(3).mean(); dd = k.rolling(3).mean(); x = cross(k, dd)
    return x.where(((x > 0) & (k < 20)) | ((x < 0) & (k > 80)), 0)


def sig_chaikin(df):
    mfm = ((df.c - df.l) - (df.h - df.c)) / (df.h - df.l).replace(0, np.nan)
    adl = (mfm.fillna(0) * df.v).cumsum()
    return cross(ema(adl, 3) - ema(adl, 10), pd.Series(0, index=df.index))


def sig_cmo(df, n=9):
    d = df.c.diff(); su = d.clip(lower=0).rolling(n).sum(); sd = (-d).clip(lower=0).rolling(n).sum()
    cmo = 100 * (su - sd) / (su + sd)
    return cross(cmo, pd.Series(-50, index=df.index)).clip(lower=0) + cross(cmo, pd.Series(50, index=df.index)).clip(upper=0)


IND = [("Aroon 25", sig_aroon, False), ("Chande Kroll Stop", sig_ckstop, False), ("Fisher Transform 9", sig_fisher, False),
       ("Elder Force 13", sig_efi, True), ("SMI Ergodic", sig_smi, False), ("Klinger", sig_klinger, True),
       ("Coppock", sig_coppock, False), ("KST (Знать наверняка)", sig_kst, False), ("Индекс массы", sig_mass, False),
       ("Фракталы Вильямса", sig_fractal, False), ("Гуппи MMA", sig_guppy, False), ("Точки разворота R1/S1", sig_pivot, False),
       ("VWAP + EMA200", sig_vwap, True), ("Hull MA 55", sig_hull, False), ("ALMA 50 (Арно Легу)", sig_alma, False),
       ("TEMA 20/50", sig_tema, False), ("DEMA 20/50", sig_dema, False), ("LSMA 25", sig_lsma, False),
       ("Аллигатор", sig_alligator, False), ("Parabolic SAR", sig_psar, False), ("McGinley 14", sig_mcginley, False),
       ("TRIX 15", sig_trix, False), ("Ultimate Oscillator", sig_uo, False), ("Stoch RSI", sig_stochrsi, False),
       ("Chaikin осциллятор", sig_chaikin, True), ("Chande Momentum (CMO)", sig_cmo, False)]


def trades(df, sig, fee):
    c, h, l = df.c.to_numpy(), df.h.to_numpy(), df.l.to_numpy(); a = atr(df).to_numpy(); s = sig.fillna(0).to_numpy()
    t = df.index.values.astype("datetime64[ms]").astype("int64"); out = []; i = 210; n = len(c)
    while i < n - 1:
        if not s[i] or not np.isfinite(a[i]) or a[i] <= 0:
            i += 1; continue
        sd, e = int(s[i]), c[i]; rk = STOP_ATR * a[i]; sl, tp = e - sd * rk, e + sd * RR * rk; r = None
        j = i + 1
        while j < min(n, i + 1 + MAXB):
            if (sd > 0 and l[j] <= sl) or (sd < 0 and h[j] >= sl):
                r = -1.0; break
            if (sd > 0 and h[j] >= tp) or (sd < 0 and l[j] <= tp):
                r = RR; break
            if s[j] == -sd:
                r = sd * (c[j] - e) / rk; break
            j += 1
        if r is None:
            j = min(j, n - 1); r = sd * (c[j] - e) / rk
        out.append((t[j], r - 2 * fee * e / rk)); i = j + (0 if s[j] == -sd else 1)
    return out


def run_block(title, raw, fee, res):
    say(""); say(f"=== {title} · комиссия {fee * 100:.3f}% · монет {len(raw)} ===")
    say(f"{'ТФ':<4}{'индикатор':<26}{'3 года R':>9}{'1-я':>8}{'2-я':>8}{'монет+':>8}{'10 мес':>8}{'сделок':>8}{'R/сд':>7}  итог")
    hasv = all("v" in d for d in raw.values())
    for k in (1, 2, 4):
        dfs = {s: to_df(d, k) for s, d in raw.items()}
        now = max(df.index[-1] for df in dfs.values())
        for nm, fn, needv in IND:
            if needv and not hasv:
                continue
            tot = h1 = h2 = w10 = 0.0; plus = 0; n = 0
            for s, df in dfs.items():
                try:
                    tr = trades(df, fn(df), fee)
                except Exception:  # noqa: BLE001
                    continue
                if not tr:
                    continue
                mid = int(df.index.values[len(df) // 2].astype("datetime64[ms]").astype("int64")); rr = [x[1] for x in tr]
                tot += sum(rr); n += len(rr); plus += sum(rr) > 0
                h1 += sum(x[1] for x in tr if x[0] < mid); h2 += sum(x[1] for x in tr if x[0] >= mid)
                w10 += sum(x[1] for x in tr if x[0] >= int(np.datetime64(now - pd.Timedelta(days=304), "ms").astype("int64")))
            ok = tot > 0 and h1 > 0 and h2 > 0 and plus >= 8
            say(f"{str(k) + 'h':<4}{nm:<26}{tot:>+9.1f}{h1:>+8.1f}{h2:>+8.1f}{f'{plus}/{len(dfs)}':>8}{w10:>+8.1f}{n:>8}{(tot / n if n else 0):>+7.3f}  {'✅' if ok else '❌'}")
            res.append((title, k, nm, tot, n, ok, w10))


def main():
    t0 = time.time()
    say(f"Стандартные индикаторы TradingView/Hash Hedge · стоп 1.5 ATR, тейк 2R · {time.strftime('%Y-%m-%d %H:%M')}")
    okx, byb = load(OKX_CACHE), load(BYB_CACHE)
    if not okx and not byb:
        say("Нет кешей свечей — сначала chan_recent_test.bat"); return
    res = []
    if byb:
        run_block("Hash Hedge (свечи Bybit)", byb, 0.0003, res)
        run_block("Bybit", byb, 0.00055, res)
    if okx:
        run_block("OKX", okx, 0.0005, res)
    say(""); say("===== ПРОШЛИ (✅), по R на сделку =====")
    good = sorted([r for r in res if r[5]], key=lambda r: -(r[3] / max(r[4], 1)))
    for title, k, nm, tot, n, ok, w10 in good:
        say(f"  {title:<26} {k}h  {nm:<26} {tot:+.1f}R за {n} сд = {tot / n:+.3f}R/сд · 10 мес {w10:+.1f}R")
    if not good:
        say("  ни один не прошёл")
    say(f"Время расчёта: {time.time() - t0:.0f} с")
    OUT.parent.mkdir(exist_ok=True); OUT.write_text("\n".join(LINES), encoding="utf-8"); print(f"\nОтчёт: {OUT}")


if __name__ == "__main__":
    main()
