"""tbo_test.py — 2026-10-05. «True Breakout Pattern [TradingFinder]» (TFlab) — перенос логики и проверка на истории.
Логика индикатора (упрощённо, но по коду):
  1. Крупные развороты 50/50 (ta.pivothigh/pivotlow, подтверждение через 50 свечей). Хранятся все неиспользованные (берём последние 30).
  2. Уровень снимается без сигнала, если его проткнули тенью и закрылись обратно ДО пробоя.
  3. Пробой: закрытие за уровнем. Если в течение 4 свечей после пробоя закрытие вернулось обратно
     (и закрытие ниже/выше открытия прошлой свечи, а минимум/максимум обновил прошлый) — это ложный пробой (сигнал FBO).
  4. Вход как у индикатора: строится Фибо от экстремума последних 5 свечей до противоположного края; если в течение 5 свечей
     цена откатывает к 0.618 и не обновляет экстремум — вход (лимит на 0.618). Стоп за экстремумом +0.1 ATR, тейк 1/2/3R.
Рынки и проверка — как в falsebreak_ind_test (крипта 1h/4h, TradFi 4h/1D, история пополам). Итог — tbo_test.csv.
"""
import sys as _sys
try:
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace"); _sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass
import csv
import numpy as np
import pandas as pd

SW, BACK, VALID, KEEP = 50, 4, 5, 30


def trades(d, rr, cost):
    o, h, l, c, t = d.o.values, d.h.values, d.l.values, d.c.values, d.t.values; n = len(c)
    pc = np.r_[c[0], c[:-1]]; tr = np.maximum(h - l, np.maximum(abs(h - pc), abs(l - pc)))
    atr = pd.Series(tr).ewm(alpha=1 / 14, adjust=False).mean().values
    HI, LO = [], []                       # [цена, бар пробоя или None, активен]
    out = []; busy = -1
    for i in range(2 * SW + 1, n):
        k = i - SW
        if h[k] == h[k - SW:i + 1].max(): HI.append([h[k], None, True]); HI[:] = HI[-KEEP:]
        if l[k] == l[k - SW:i + 1].min(): LO.append([l[k], None, True]); LO[:] = LO[-KEEP:]
        sig = 0
        for z in HI:
            if not z[2]: continue
            P, brk = z[0], z[1]
            if brk is None and h[i] > P > c[i]: z[2] = False; continue
            if brk is not None and i <= brk + BACK and P > c[i] and P < c[i - 1] and c[i] < o[i - 1] and l[i] < l[i - 1]:
                z[2] = False; sig = -1
            elif brk is not None and i > brk + BACK: z[2] = False
            if z[2] and brk is None and c[i] > P: z[1] = i
        for z in LO:
            if not z[2]: continue
            P, brk = z[0], z[1]
            if brk is None and l[i] < P < c[i]: z[2] = False; continue
            if brk is not None and i <= brk + BACK and P < c[i] and P > c[i - 1] and c[i] > o[i - 1] and h[i] > h[i - 1]:
                z[2] = False; sig = 1
            elif brk is not None and i > brk + BACK: z[2] = False
            if z[2] and brk is None and c[i] < P: z[1] = i
        if not sig or i <= busy: continue
        # вход на откате к 0.618
        if sig < 0:
            ext = max(h[i - 4:i + 1]); lo = l[i]; j0 = None
            for j in range(i + 1, min(n, i + VALID + 1)):
                if h[j] >= ext: break
                lo = min(lo, l[j]); f618 = lo + (ext - lo) * 0.618
                if h[j] > f618: j0, e = j, f618; break
            if j0 is None: continue
            stop = ext + 0.1 * atr[i]
        else:
            ext = min(l[i - 4:i + 1]); hi = h[i]; j0 = None
            for j in range(i + 1, min(n, i + VALID + 1)):
                if l[j] <= ext: break
                hi = max(hi, h[j]); f618 = hi - (hi - ext) * 0.618
                if l[j] < f618: j0, e = j, f618; break
            if j0 is None: continue
            stop = ext - 0.1 * atr[i]
        risk = abs(e - stop)
        if risk <= 0 or risk / e > 0.15: continue
        tp = e + sig * rr * risk; r = None; m = j0
        for m in range(j0 + 1, min(n, j0 + 61)):
            if (l[m] <= stop) if sig > 0 else (h[m] >= stop): r = -1.0; break
            if (h[m] >= tp) if sig > 0 else (l[m] <= tp): r = rr; break
        if r is None: r = sig * (c[m] - e) / risk
        out.append((t[j0], r - cost * e / risk)); busy = m
    return out


if __name__ == "__main__":
    import kvoo_longtest as K
    import fx_channel_test as F
    sets = {}
    for s in K.COINS:
        for tf in ("1h", "4h"):
            d = K.load(s, tf)
            if d is not None and len(d) > 600: sets[("Крипта", tf, s.replace("USDT", ""))] = d.reset_index(drop=True)
    for name, sym in F.SYMS.items():
        print("загрузка", name)
        try:
            sets[("TradFi", "4h", name)] = F.to4h(F.yahoo(sym, "1h", "730d")).reset_index(drop=True)
            dd = F.yahoo(sym, "1d", "max"); sets[("TradFi", "1D", name)] = dd[dd.t >= 1104537600000].reset_index(drop=True)
        except Exception as exc:  # noqa: BLE001
            print("  пропуск:", exc)
    print("\nсчитаю…")
    rows = []
    for mkt, tfs, cost in (("Крипта", ("1h", "4h"), 0.0011), ("TradFi", ("4h", "1D"), 0.0003)):
        for tf in tfs:
            for rr in (1.0, 2.0, 3.0):
                a = b = 0.0; nt = wins = plus = 0; per = {}
                for key, d in sets.items():
                    if key[0] != mkt or key[1] != tf: continue
                    cut = d.t.iat[len(d) // 2]
                    tr = trades(d, rr, cost); rs = sum(r for _, r in tr); per[key[2]] = round(rs, 1); plus += rs > 0
                    for tt, r in tr:
                        nt += 1; wins += r > 0
                        if tt < cut: a += r
                        else: b += r
                ok = "✅" if nt >= 30 and a > 0 and b > 0 and plus > len(per) / 2 else "  "
                row = {"рынок": mkt, "tf": tf, "тейк": f"{rr:.0f}R", "сделок": nt, "WR%": round(100 * wins / max(1, nt), 1),
                       "R_1я": round(a, 1), "R_2я": round(b, 1), "R_на_сделку": round((a + b) / max(1, nt), 3),
                       "в_плюсе": f"{plus}/{len(per)}", "прошла": ok.strip(), **per}
                rows.append(row)
                print(f"{ok} {mkt:6} {tf:2} | тейк {rr:.0f}R | сделок {nt:5} WR {row['WR%']:5}% | 1-я {a:+7.1f}R | 2-я {b:+7.1f}R | "
                      f"{row['R_на_сделку']:+.3f}R/сд | в плюсе {plus}/{len(per)}")
    keys = list(dict.fromkeys(k for r in rows for k in r))
    with open(F.BASE / "tbo_test.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=keys, delimiter=";"); w.writeheader(); w.writerows(rows)
    print("\n✅ = плюс в обеих половинах, больше чем на половине инструментов, не меньше 30 сделок.")
    print("Готово. Пришлите скрин или tbo_test.csv")
    input("Enter — закрыть")
