@echo off
chcp 65001 >nul
cd /d "%~dp0"

if not exist "paper_live.pid" (
    echo  Фоновый paper_live не запущен ^(нет paper_live.pid^).
    timeout /t 3 >nul
    exit /b
)

set /p PID=<paper_live.pid
echo  Останавливаю paper_live, PID %PID%...
taskkill /PID %PID% /F >nul 2>&1

if errorlevel 1 (
    echo  Процесс %PID% не найден - возможно, уже остановлен.
    del paper_live.pid >nul 2>&1
) else (
    echo  Остановлено.
)
timeout /t 3 >nul
