"""ginarea_soldca_test.py — 2026-11-02. Бэктест витринных ботов GinArea «sol dca short / long» (Default grid, OKX SOL).

Настройки сняты из окна клонирования GinArea:
  short «0.5 0.75/0.15/0.6»: 300 ордеров, шаг 0.05% × множ. шага 1.05, размер 0.01 SOL × 1.05 (макс. не задан),
      цель 0.75%, мин. стоп 0.15%, макс. стоп 0.6%, Instop 0, «не ухудшать цену» ВКЛ, «выход по средней» ВКЛ, TP/SL нет.
  long «1.2 6/1/5»: 100 ордеров, шаг 1.2% × 1.05, размер 0.1 SOL × 1.05 (макс. 50), цель 6%, стоп 1%/5%, те же флажки.
Имя бота = «шаг цель/мин/макс»; у short 0.5 в окне шаг 0.05 — проверяем оба (0.05 и 0.5).
Модель: выход по средней (цель от средней, после триггера новые IN не открываются, трейлинг мин/макс),
следующий IN — на шаг×1.05^k дальше от последнего; новый цикл сразу после закрытия.
Депозит = мин. рекомендуемый баланс GinArea; ЛИКВИДАЦИЯ, если капитал < 0.5% позиции. Комиссия taker 0.05%.
Запуск: ginarea_soldca_test.bat [дней=730] [монета=SOL] → bt_lab_bots/ginarea_soldca_test_<COIN>.txt
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import pandas as pd

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
from ginarea_sui_test import okx_1m  # noqa: E402
from ginarea_lot import fl, lot  # noqa: E402

LINES = []


def say(s=""):
    print(s, flush=True); LINES.append(s)


def run(d, P, fee=0.0005):
    t, o, h, l, c = (d[k].to_numpy() for k in ("t", "o", "h", "l", "c"))
    sg = 1 if P["side"] == "long" else -1
    pos, total = None, 0.0
    R = {"cycles": 0, "liq": None, "min_eq": P["dep"], "min_t": None, "max_n": 0, "max_notional": 0.0, "hang": 0.0, "fees": 0.0}
    monthly = {}

    def book(x, ts):
        nonlocal total
        total += x; m = pd.to_datetime(ts, unit="ms").strftime("%Y-%m"); monthly[m] = monthly.get(m, 0.0) + x

    def fill(px, q, ts):
        R["fees"] += px * q * fee; book(-px * q * fee, ts)

    for i in range(1, len(c)):
        if pos is None:
            q = fl(P["qty"], P); fill(o[i], q, t[i]); R["cycles"] += 1
            pos = {"qty": q, "avg": o[i], "last": o[i], "n": 1, "q": q, "qr": P["qty"], "step": P["step"], "stop": None, "t0": t[i]}
        if pos["stop"] is None:                                    # после триггера доборов нет
            while pos["n"] < P["n"]:
                nxt = pos["last"] * (1 - sg * pos["step"])
                if not ((sg > 0 and l[i] <= nxt) or (sg < 0 and h[i] >= nxt)):
                    break
                pos["qr"] = min(pos["qr"] * P["mult"], P["qmax"]) if P.get("qmax") else pos["qr"] * P["mult"]; q = fl(pos["qr"], P)
                pos["avg"] = (pos["avg"] * pos["qty"] + nxt * q) / (pos["qty"] + q); pos["qty"] += q; pos["q"] = q
                pos["last"] = nxt; pos["n"] += 1; pos["step"] *= P["step_mult"]; fill(nxt, q, t[i])
        R["max_n"] = max(R["max_n"], pos["n"]); R["max_notional"] = max(R["max_notional"], pos["qty"] * c[i])
        adv = l[i] if sg > 0 else h[i]
        eq = P["dep"] + total + sg * (adv - pos["avg"]) * pos["qty"]
        if eq < R["min_eq"]:
            R["min_eq"], R["min_t"] = eq, t[i]
        if eq <= 0.005 * pos["qty"] * adv:
            book(-(P["dep"] + total), t[i]); R["liq"] = t[i]; pos = None; break
        trig = pos["avg"] * (1 + sg * P["target"])
        fav = h[i] if sg > 0 else l[i]
        if pos["stop"] is None and sg * (fav - trig) >= 0:
            pos["stop"] = trig * (1 - sg * P["min_stop"])
        if pos["stop"] is not None:
            pos["stop"] = max(pos["stop"], fav * (1 - P["max_stop"])) if sg > 0 else min(pos["stop"], fav * (1 + P["max_stop"]))
            if (sg > 0 and l[i] <= pos["stop"]) or (sg < 0 and h[i] >= pos["stop"]):
                px = pos["stop"]; fill(px, pos["qty"], t[i]); book(sg * (px - pos["avg"]) * pos["qty"], t[i])
                R["hang"] = max(R["hang"], (t[i] - pos["t0"]) / 864e5); pos = None
    R["open_un"] = 0.0 if pos is None else sg * (c[-1] - pos["avg"]) * pos["qty"]
    R["open_n"] = 0 if pos is None else pos["n"]
    if pos is not None:
        R["hang"] = max(R["hang"], (t[-1] - pos["t0"]) / 864e5)
    R["total"], R["all"], R["monthly"] = total, total + R["open_un"], monthly
    return R


def rep(name, r, dep):
    say(f"--- {name} · депозит {dep:.0f} $")
    if r["liq"]:
        say(f"  ⛔ ЛИКВИДАЦИЯ {pd.to_datetime(r['liq'], unit='ms'):%Y-%m-%d}")
    say(f"  ИТОГО {r['all']:+.2f} $ ({r['all'] / dep * 100:+.0f}% депозита) · закрыто {r['total']:+.2f}, висит {r['open_n']} орд. {r['open_un']:+.2f} · "
        f"циклов {r['cycles']} · комиссии {r['fees']:.2f}")
    say(f"  макс. ордеров {r['max_n']} · позиция до {r['max_notional']:.0f} $ · минимум капитала {r['min_eq']:.0f} $"
        + (f" ({pd.to_datetime(r['min_t'], unit='ms'):%Y-%m-%d})" if r["min_t"] else "") + f" · самый долгий цикл {r['hang']:.0f} дн.")
    q = {}
    for m, v in r["monthly"].items():
        q[m[:4] + ("H1" if int(m[5:]) <= 6 else "H2")] = q.get(m[:4] + ("H1" if int(m[5:]) <= 6 else "H2"), 0) + v
    say("  по полугодиям: " + "  ".join(f"{k} {v:+.1f}" for k, v in sorted(q.items())))


def main():
    days = int(sys.argv[1]) if len(sys.argv) > 1 else 730
    coin = (sys.argv[2] if len(sys.argv) > 2 else "SOL").upper()
    say(f"GinArea «sol dca» short/long · OKX {coin} 1m · {days} дн. · taker 0.05% · {time.strftime('%Y-%m-%d %H:%M')}")
    d = okx_1m(coin, days)
    if len(d) < 10000:
        say("мало свечей"); return
    say(f"{pd.to_datetime(d.t.iloc[0], unit='ms'):%Y-%m-%d} → {pd.to_datetime(d.t.iloc[-1], unit='ms'):%Y-%m-%d} · {coin} "
        f"{d.c.iloc[0]:.2f} → {d.c.iloc[-1]:.2f} ({(d.c.iloc[-1] / d.c.iloc[0] - 1) * 100:+.0f}%) · мин {d.l.min():.2f} макс {d.h.max():.2f}")
    LOT = lot(coin); say(f"Лот OKX {coin}: шаг {LOT[0]:g}, минимум {LOT[1]:g} (размер округляется вниз)")
    S = dict(lot=LOT, side="short", n=300, step=0.0005, step_mult=1.05, qty=0.01, mult=1.05, qmax=None, target=0.0075, min_stop=0.0015, max_stop=0.006, dep=100.0)
    L = dict(lot=LOT, side="long", n=100, step=0.012, step_mult=1.05, qty=0.1, mult=1.05, qmax=50.0, target=0.06, min_stop=0.01, max_stop=0.05, dep=600.0)
    say(""); say("===== как на витрине =====")
    rs = run(d, S); rep("SHORT 0.5 0.75/0.15/0.6 (шаг 0.05%, как в окне)", rs, S["dep"])
    rs5 = run(d, {**S, "step": 0.005}); rep("SHORT шаг 0.5% (как в имени)", rs5, S["dep"])
    rl = run(d, L); rep("LONG 1.2 6/1/5", rl, L["dep"])
    say(""); say("===== с той же логикой в обратную сторону =====")
    rep("LONG с настройками short 0.5 0.75/0.15/0.6", run(d, {**S, "side": "long"}), S["dep"])
    rep("SHORT с настройками long 1.2 6/1/5", run(d, {**L, "side": "short"}), L["dep"])
    say(""); say(f"ПАРА short(0.05%)+long: {rs['all'] + rl['all']:+.2f} $ на {S['dep'] + L['dep']:.0f} $")
    half = len(d) // 2
    say(""); say("===== половины истории =====")
    for nm, part in (("1-я половина", d.iloc[:half]), ("2-я половина", d.iloc[half:])):
        p = part.reset_index(drop=True)
        say(f"{nm}: {coin} {p.c.iloc[0]:.2f} → {p.c.iloc[-1]:.2f}")
        rep("  SHORT 0.05%", run(p, S), S["dep"]); rep("  LONG 1.2", run(p, L), L["dep"])
    say(""); say("Приближение алгоритма GinArea (минутные свечи). Сверяй с бэктестом GinArea.")
    out = BASE / "bt_lab_bots" / f"ginarea_soldca_test_{coin}.txt"
    out.parent.mkdir(exist_ok=True); out.write_text("\n".join(LINES), encoding="utf-8")
    print(f"\nОтчёт: {out}")


if __name__ == "__main__":
    main()
