"""fx_fvg_test.py — 2026-10-05. Неэффективность (FVG) на традиционных рынках: золото, нефть, валюты, индексы.
Та же логика, что fvg_test.py (вход лимитом при возврате в зону, стоп за зоной −0.3 ATR, тейк 1/2/3R),
данные Yahoo как в fx_channel_test: 4h (~2 года), 1D (с 2005), 1h (~2 года). Издержки 0.03%.
Проверка: первая и вторая половина истории отдельно, сколько инструментов в плюсе. Результат — fx_fvg_test.csv.
"""
import csv, time
import fvg_test as V
import fx_channel_test as F

V.COST = 0.0003

if __name__ == "__main__":
    data = {}
    for name, s in F.SYMS.items():
        print("загрузка", name)
        try:
            h1 = F.yahoo(s, "1h", "730d"); data[(name, "1h")] = h1; data[(name, "4h")] = F.to4h(h1); time.sleep(0.4)
            d = F.yahoo(s, "1d", "max"); data[(name, "1D")] = d[d.t >= 1104537600000].reset_index(drop=True); time.sleep(0.4)
        except Exception as exc:  # noqa: BLE001
            print("  не загрузилось:", exc)
    rows = []
    for tf in ("1h", "4h", "1D"):
        for flt, fname in (("none", "без фильтра"), ("trend", "по тренду EMA200"), ("big", "крупные ≥0.5 ATR")):
            for rr in (1, 2, 3):
                a = b = 0.0; nt = wins = plus = 0; per = {}
                for name in F.SYMS:
                    d = data.get((name, tf))
                    if d is None or len(d) < 260: continue
                    cut = d.t.iloc[len(d) // 2]
                    tr = V.run(d, rr, flt); rs = sum(r for _, r in tr); per[name] = round(rs, 1); plus += rs > 0
                    for tt, r in tr:
                        nt += 1; wins += r > 0
                        if tt < cut: a += r
                        else: b += r
                row = {"tf": tf, "фильтр": fname, "тейк": f"{rr}R", "сделок": nt, "WR%": round(100 * wins / max(1, nt), 1),
                       "R_1я": round(a, 1), "R_2я": round(b, 1), "R_на_сделку": round((a + b) / max(1, nt), 3), "в_плюсе": f"{plus}/{len(per)}", **per}
                rows.append(row)
                print(f"{tf:3} FVG {fname:18} тейк {rr}R | сделок {nt:5} WR {row['WR%']:5}% | 1-я {a:+7.1f}R | 2-я {b:+7.1f}R | {row['R_на_сделку']:+.3f}R/сд | в плюсе {plus}/{len(per)}")
    keys = list(dict.fromkeys(k for r in rows for k in r))
    with open(F.BASE / "fx_fvg_test.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=keys, delimiter=";"); w.writeheader(); w.writerows(rows)
    print("\nГотово. Пришлите скрин или fx_fvg_test.csv")
    input("Enter — закрыть")
