"""chan_saw_test.py — 2026-10-19. «Пила» таймфреймов 1h…12h для пробоя канала (канал регрессии 100, ±2σ,
вход по закрытию за границей, стоп у центра, тейк 2R — та же функция, что в okx_current_test / chan_coins_test).
Свечи OKX SWAP 1h (~3 года, 12 монет), собираются в k-часовые. Комиссия OKX taker 0.05% на сторону.
✅ = сумма R > 0, ≥ 8/12 монет в плюсе, обе половины истории > 0. Устойчиво — ✅ подряд на соседних ТФ.
Ничего не торгует. Запуск: chan_saw_test.bat → bt_lab_bots/chan_saw_test.txt
"""
from __future__ import annotations
import pickle, sys, time
from pathlib import Path
import numpy as np
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import okx_current_test as OC  # noqa: E402  (OKX-свечи, комиссии, функция chan)
import pack_strats_test as PS  # noqa: E402
import ginarea_op_test as G  # noqa: E402  (кеш минуток OKX)
MIN_DAYS = 300
OUT = BASE / "bt_lab_bots" / "chan_saw_test.txt"
CACHE = BASE / "market_cache" / "okx_1h_3y_12coins.pkl"
COINS = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT", "DOGEUSDT", "ADAUSDT", "SUIUSDT", "LINKUSDT", "AVAXUSDT",
         "BNBUSDT", "NEARUSDT", "HYPEUSDT"]
LINES = []
def say(s=""):
    print(s, flush=True); LINES.append(s)

def rs_min(d, k):
    """Свечи k минут из минутных."""
    if k == 1:
        return d
    b = (d["t"] // (k * 60_000)).astype(np.int64)
    cut = np.r_[0, np.flatnonzero(np.diff(b)) + 1]
    end = np.r_[cut[1:] - 1, len(b) - 1]
    return {"t": d["t"][cut], "o": d["o"][cut], "h": np.maximum.reduceat(d["h"], cut),
            "l": np.minimum.reduceat(d["l"], cut), "c": d["c"][end], "v": np.zeros(len(cut))}


def main():
    t0 = time.time()
    say(f"«Пила» ТФ 1m…12h · пробой канала 100 (2R) · OKX · taker 0.05% · {time.strftime('%Y-%m-%d %H:%M')}")
    if CACHE.exists() and time.time() - CACHE.stat().st_mtime < 5 * 86400:
        raw = pickle.loads(CACHE.read_bytes())
    else:
        raw = {}
        for s in COINS:
            print(f"  качаю {s} 1h с OKX…", flush=True)
            raw[s] = OC.okx_klines(s, "60", 3 * 365 * 24)
        CACHE.parent.mkdir(exist_ok=True); CACHE.write_bytes(pickle.dumps(raw))
    raw = {s: d for s, d in raw.items() if len(d["c"]) >= 3000}
    say(f"Монет {len(raw)} · истории ~{np.median([(d['t'][-1] - d['t'][0]) / 864e5 for d in raw.values()]):.0f} дней")
    rows = []
    for k in range(1, 13):
        full, h1, h2, per = [], [], [], {}
        for s, d0 in raw.items():
            d = PS.resample(d0, k) if k > 1 else d0
            if len(d["c"]) < 300:
                continue
            a = OC.chan(d); full.append(a); per[s] = a
            h1.append(OC.chan(OC.half(d, 0))); h2.append(OC.chan(OC.half(d, 1)))
        tot, plus = sum(full), sum(x > 0 for x in full)
        ok = tot > 0 and plus >= 8 and sum(h1) > 0 and sum(h2) > 0
        rows.append((k, tot, plus, len(full), sum(h1), sum(h2), ok, per))
        print(f"  {k}h готово ({time.time() - t0:.0f} с)", flush=True)
    # ---- младшие ТФ: 1m / 5m / 15m / 30m на минутках OKX (последние MIN_DAYS дней)
    small = []
    mins = {}
    for s in raw:
        try:
            m = G.okx_1m(s.replace("USDT", "") + "-USDT-SWAP", MIN_DAYS)
            mins[s] = {"t": m.t.to_numpy().astype(np.int64), "o": m.o.to_numpy(), "h": m.h.to_numpy(),
                       "l": m.l.to_numpy(), "c": m.c.to_numpy(), "v": np.zeros(len(m))}
        except Exception as exc:  # noqa: BLE001
            print(f"  {s}: минутки не скачались: {exc}", flush=True)
    for k in (1, 5, 15, 30):
        full, h1, h2, per = [], [], [], {}
        for s, d0 in mins.items():
            d = rs_min(d0, k)
            if len(d["c"]) < 300:
                continue
            a = OC.chan(d); full.append(a); per[s] = a
            h1.append(OC.chan(OC.half(d, 0))); h2.append(OC.chan(OC.half(d, 1)))
        if not full:
            continue
        tot, plus = sum(full), sum(x > 0 for x in full)
        ok = tot > 0 and plus >= 8 and sum(h1) > 0 and sum(h2) > 0
        small.append((f"{k}m", tot, plus, len(full), sum(h1), sum(h2), ok, per))
        print(f"  {k}m готово ({time.time() - t0:.0f} с)", flush=True)
    rows = small + [(f"{r[0]}h",) + r[1:] for r in rows]
    say(""); say(f"(1m–30m — последние {MIN_DAYS} дней минуток; 1h–12h — ~3 года)")
    say(""); say(f"{'ТФ':<5}{'итог R':>9}{'монет +':>9}{'1-я пол.':>10}{'2-я пол.':>10}")
    for k, tot, plus, n, a, b, ok, _ in rows:
        say(f"{k:<5}{tot:>+9.1f}{f'{plus}/{n}':>9}{a:>+10.1f}{b:>+10.1f}  {'✅' if ok else '❌'}")
    say(""); say("По монетам (R):")
    say(f"{'монета':<9}" + "".join(f"{k:>7}" for k, *_ in rows))
    for s in raw:
        say(f"{s.replace('USDT',''):<9}" + "".join(f"{r[7].get(s, 0):>+7.1f}" for r in rows))
    say(""); say("R — в единицах риска (1R = расстояние до стопа). Устойчиво — ✅ на нескольких соседних ТФ подряд.")
    OUT.parent.mkdir(exist_ok=True); OUT.write_text("\n".join(LINES), encoding="utf-8"); print(f"\nОтчёт: {OUT}")

if __name__ == "__main__":
    main()
