"""ginarea_dyn_test.py — 2026-10-18. Приближённый бэктест бота GinArea «dyn_0.6_0.02_auto» (Dynamic grid, BTC, OKX).

Настройки со скриншотов: 40 ордеров по 0.001 BTC, шаг 390.4 $, цель 390.4 $, мин. стоп 0, макс. стоп 43.4 $,
выход по средней цене ВКЛ, тейк бота +10 $ (после тейка перезапуск, тейк +2 $), стоп-лосс бота −41.33 $.

Как моделируем (точный алгоритм GinArea закрыт — это приближение, честно):
  * Старт: IN-ордер по рынку. Дальше доборы по 0.001 BTC каждые 390.4 $ против позиции, максимум 40.
  * Выход по средней: цена прошла от средней +390.4 $ → включается трейлинг 43.4 $ → закрытие всей позиции.
    После закрытия — новый цикл с текущей цены.
  * Тейк бота: суммарный PnL с (пере)запуска (закрытые + открытая) ≥ TP → закрыть всё, TP += 2, перезапуск.
  * Стоп бота: суммарный PnL ≤ −41.33 → закрыть всё. В GinArea бот ОСТАНАВЛИВАЕТСЯ; здесь считаем стоп
    и перезапускаем через 60 мин (как если бы ты включил его снова), TP сбрасывается на 10.
  * По документации GinArea: Dynamic Авто ведёт лонг (ниже нижней границы −0.6%) и шорт (выше верхней +0.6%)
    ОДНОВРЕМЕННО, границы тянутся за ценой и сдвигаются на 0.2% после каждого IN (величина сдвига в доке
    не раскрыта — берём 0.2% от границы). Считаем авто и для сравнения только лонг / только шорт.
  * Остановка «30 мин И профит > 50 $» (условие через И) почти не срабатывает раньше тейка +10 $ — не моделируем.
  * Комиссия OKX: taker 0.05% (консервативно) и maker 0.02% (если доборы лимитками).
  * Исполнение по минутным свечам: доборы и трейлинг — по high/low минуты, внутри минуты сначала худшее.
Ничего не торгует. Запуск: ginarea_dyn_test.bat [дней, по умолч. 120] → bt_lab_bots/ginarea_dyn_test.txt
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import requests

BASE = Path(__file__).resolve().parent
OUT = BASE / "bt_lab_bots" / "ginarea_dyn_test.txt"
CACHE = BASE / "market_cache"
P = dict(start_off=0.006, in_off=0.002, n_orders=40, qty=0.001, step=390.4, target=390.4, trail=43.4, tp0=10.0, tp_inc=2.0, sl=-41.33,
         restart_min=60)
LINES = []


def say(s=""):
    print(s, flush=True)
    LINES.append(s)


def okx_1m(days):
    CACHE.mkdir(exist_ok=True)
    path = CACHE / "okx_BTC_1m.pkl"
    old = pd.read_pickle(path) if path.exists() else pd.DataFrame(columns=["t", "o", "h", "l", "c"])
    need_from = int((time.time() - days * 86400) * 1000)
    have_new = int(old.t.max()) if len(old) else 0
    have_old = int(old.t.min()) if len(old) else None

    def pull(after, stop):
        rows, k = [], 0
        while True:
            q = {"instId": "BTC-USDT-SWAP", "bar": "1m", "limit": 100}
            if after:
                q["after"] = after
            j = None
            for tr in range(6):
                try:
                    j = requests.get("https://www.okx.com/api/v5/market/history-candles", params=q, timeout=20).json()
                    if j.get("code") == "0":
                        break
                except requests.RequestException:
                    pass
                time.sleep(1.5 * (tr + 1))
            lst = (j or {}).get("data") or []
            if not lst:
                break
            rows += [r for r in lst if len(r) < 9 or r[8] == "1"]
            after = lst[-1][0]
            k += 1
            if k % 100 == 0:
                print(f"  качаю OKX BTC 1m: {pd.to_datetime(int(after), unit='ms'):%Y-%m-%d %H:%M}", flush=True)
            if int(after) <= stop or len(lst) < 100:
                break
            time.sleep(0.1)
        return rows

    rows = pull(None, max(have_new, need_from))
    if have_old is not None and have_old > need_from + 60_000:
        rows += pull(str(have_old), need_from)
    if rows:
        a = pd.DataFrame([[int(r[0])] + [float(x) for x in r[1:5]] for r in rows], columns=["t", "o", "h", "l", "c"])
        old = pd.concat([old, a]).drop_duplicates("t").sort_values("t").reset_index(drop=True)
        old["t"] = old["t"].astype("int64")
        old.to_pickle(path)
    old = old.astype({"t": "int64", "o": "float64", "h": "float64", "l": "float64", "c": "float64"})
    return old[old.t >= need_from].reset_index(drop=True)


def ema200_1h(d):
    h = d.set_index(pd.to_datetime(d.t, unit="ms")).c.resample("1h").last().dropna()
    e = h.ewm(span=200, adjust=False).mean()
    # значение EMA, известное на минуту t: по последнему ЗАКРЫТОМУ часу
    idx = pd.to_datetime(d.t, unit="ms").dt.floor("h") - pd.Timedelta(hours=1)
    return e.reindex(idx).to_numpy()


def _last_closed(d, series, rule):
    """значение series (индекс = начало бара rule), известное на каждой минуте: по последнему ЗАКРЫТОМУ бару."""
    key = pd.DatetimeIndex(pd.to_datetime(d.t.astype("int64").to_numpy(), unit="ms")).floor(rule) - pd.Timedelta(rule)
    series = pd.Series(series.astype(float).to_numpy(), index=pd.DatetimeIndex(series.index))
    return series.reindex(key).to_numpy()


def regimes(d):
    """+1 = рынок вверх (лонг), −1 = вниз (шорт). Только закрытые бары, без заглядывания вперёд."""
    ix = pd.DatetimeIndex(pd.to_datetime(d.t.astype("int64").to_numpy(), unit="ms"))
    m = pd.DataFrame({"h": d.h.astype(float).to_numpy(), "l": d.l.astype(float).to_numpy(),
                      "c": d.c.astype(float).to_numpy()}, index=ix)
    out = {}
    for rule, name in (("4h", "4h"), ("1D", "1D")):
        b = m.resample(rule).agg({"h": "max", "l": "min", "c": "last"}).dropna()
        e = b.c.ewm(span=200 if rule == "4h" else 50, adjust=False).mean()
        out[f"EMA{200 if rule == '4h' else 50} {name}"] = np.sign(_last_closed(d, b.c - e, rule))
        # SuperTrend(10, 3)
        tr = pd.concat([b.h - b.l, (b.h - b.c.shift()).abs(), (b.l - b.c.shift()).abs()], axis=1).max(axis=1)
        atr = tr.ewm(alpha=1 / 10, adjust=False).mean()
        mid = (b.h + b.l) / 2
        up, dn = (mid - 3 * atr).to_numpy().copy(), (mid + 3 * atr).to_numpy().copy()
        cc = b.c.to_numpy().copy(); dirn = np.ones(len(b))
        for i in range(1, len(b)):
            if cc[i - 1] > up[i - 1]:
                up[i] = max(up[i], up[i - 1]) if dirn[i - 1] > 0 else up[i]
            if cc[i - 1] < dn[i - 1]:
                dn[i] = min(dn[i], dn[i - 1]) if dirn[i - 1] < 0 else dn[i]
            dirn[i] = 1 if cc[i] > dn[i - 1] else -1 if cc[i] < up[i - 1] else dirn[i - 1]
        out[f"SuperTrend {name}"] = _last_closed(d, pd.Series(dirn, index=b.index), rule)
    return out


def run(d, mode, fee, ema=None, reg=None):
    """Dynamic grid по документации GinArea (help.ginarea.org/strategies/dynamic):
    лонг-ордера открываются только ниже нижней границы TO = цена×(1−0.6%), граница тянется за ценой вверх;
    шорт — выше FROM = цена×(1+0.6%), тянется вниз. Авто = ОБЕ стороны одновременно, средние раздельно.
    После каждого IN граница сдвигается на 0.2% (в сторону ордера). Доборы — каждый шаг 390.4 $ от последнего.
    Выход по средней: триггер средняя±390.4, мин. стоп 0, трейлинг 43.4 $. Тейк/стоп бота — по общему PnL."""
    t, o, h, l, c = (d[k].to_numpy() for k in ("t", "o", "h", "l", "c"))
    q0, step, n_max = P["qty"], P["step"], P["n_orders"]
    off, dyn = P["start_off"], P["in_off"]
    sides = [1, -1] if mode in ("auto", "regime") else [1] if mode == "long" else [-1]
    res = {"cycles": 0, "bot_tp": 0, "bot_sl": 0, "fees": 0.0, "max_orders": 0, "max_notional": 0.0}
    monthly = {}
    st = {"total": 0.0, "sess": 0.0}
    tp = P["tp0"]
    pos = {}
    bnd = {}
    pause_until = 0

    def book(x, ts):
        st["total"] += x; st["sess"] += x
        m = pd.to_datetime(ts, unit="ms").strftime("%Y-%m")
        monthly[m] = monthly.get(m, 0.0) + x

    def fee_pay(px, q, ts):
        res["fees"] += px * q * fee; book(-px * q * fee, ts)

    def close_side(s, px, ts):
        p_ = pos.pop(s)
        fee_pay(px, p_["qty"], ts)
        book(s * (px - p_["avg"]) * p_["qty"], ts)

    def reset(px):
        for s in sides:
            bnd[s] = px * (1 - s * off)

    reset(o[0])
    for i in range(len(c)):
        if t[i] < pause_until:
            continue
        if pause_until and not bnd:
            reset(o[i])
        for s in sides:
            # граница тянется за ценой (лонг — вверх, шорт — вниз)
            ref = h[i] if s > 0 else l[i]
            bnd[s] = max(bnd[s], ref * (1 - off)) if s > 0 else min(bnd[s], ref * (1 + off))
            worst = l[i] if s > 0 else h[i]
            if mode == "regime" and not (reg[i] == s):
                continue          # против рынка новых IN не открываем (открытая сторона закроется по своему выходу)
            n_all = sum(p_["n"] for p_ in pos.values())
            while n_all < n_max:
                p_ = pos.get(s)
                lvl = bnd[s] if p_ is None else (min(bnd[s], p_["last"] - step) if s > 0 else max(bnd[s], p_["last"] + step))
                if s * (worst - lvl) > 0:
                    break
                if p_ is None:
                    pos[s] = p_ = {"qty": 0.0, "avg": lvl, "last": lvl, "n": 0, "peak": None}
                    res["cycles"] += 1
                p_["avg"] = (p_["avg"] * p_["qty"] + lvl * q0) / (p_["qty"] + q0)
                p_["qty"] += q0; p_["last"] = lvl; p_["n"] += 1; n_all += 1
                fee_pay(lvl, q0, t[i])
                bnd[s] = bnd[s] * (1 - s * dyn)
        n_all = sum(p_["n"] for p_ in pos.values())
        res["max_orders"] = max(res["max_orders"], n_all)
        res["max_notional"] = max(res["max_notional"], sum(p_["qty"] for p_ in pos.values()) * c[i])
        # стоп бота по худшему для позиции моменту минуты (оценка)
        un_w = sum(s * ((l[i] if s > 0 else h[i]) - p_["avg"]) * p_["qty"] for s, p_ in pos.items())
        if st["sess"] + un_w <= P["sl"]:
            for s in list(pos):
                close_side(s, l[i] if s > 0 else h[i], t[i])
            res["bot_sl"] += 1
            st["sess"], tp = 0.0, P["tp0"]
            pause_until = t[i] + P["restart_min"] * 60_000
            bnd.clear()
            continue
        # выход по средней + трейлинг
        for s in list(pos):
            p_ = pos[s]
            best, worst = (h[i], l[i]) if s > 0 else (l[i], h[i])
            trig = p_["avg"] + s * P["target"]
            if p_["peak"] is None and s * (best - trig) >= 0:
                p_["peak"] = best
            if p_["peak"] is not None:
                p_["peak"] = max(p_["peak"], best) if s > 0 else min(p_["peak"], best)
                stop_px = p_["peak"] - s * P["trail"]
                if s * (stop_px - trig) < 0:
                    stop_px = trig                     # мин. стоп 0 → не хуже триггера
                if s * (c[i] - stop_px) <= 0:
                    close_side(s, stop_px, t[i])
        un = sum(s * (c[i] - p_["avg"]) * p_["qty"] - c[i] * p_["qty"] * fee for s, p_ in pos.items())
        if st["sess"] + un >= tp:
            for s in list(pos):
                close_side(s, c[i], t[i])
            res["bot_tp"] += 1
            st["sess"] = 0.0
            tp += P["tp_inc"]
            reset(c[i])
    for s in list(pos):
        close_side(s, c[-1], t[-1])
    res["total"] = st["total"]
    res["monthly"] = monthly
    return res


def main():
    days = int(sys.argv[1]) if len(sys.argv) > 1 else 120
    say(f"GinArea Dynamic grid dyn_0.6_0.02_auto — приближённый бэктест · OKX BTC 1m · {days} дн. · "
        f"{time.strftime('%Y-%m-%d %H:%M')}")
    say(f"Настройки: {P}")
    d = okx_1m(days)
    if len(d) < 10000:
        say("мало свечей — OKX не отдал историю"); return
    say(f"Свечей: {len(d)} · {pd.to_datetime(d.t.iloc[0], unit='ms'):%Y-%m-%d} → "
        f"{pd.to_datetime(d.t.iloc[-1], unit='ms'):%Y-%m-%d} · BTC {d.c.iloc[0]:.0f} → {d.c.iloc[-1]:.0f}")
    regs = regimes(d)
    for fee, fname in ((0.0005, "taker 0.05%"), (0.0002, "maker 0.02%")):
        say(""); say(f"=== комиссия {fname} ===")
        variants = [("long", None, "только лонг"), ("short", None, "только шорт"), ("auto", None, "авто (обе стороны)")]
        variants += [("regime", r, f"по рынку: {n}") for n, r in regs.items()]
        for mode, reg, label in variants:
            r = run(d, mode, fee, reg=reg)
            say(f"  {label:<24} итог {r['total']:+8.2f} $ · тейков {r['bot_tp']:>3} · СТОПОВ −41 $ {r['bot_sl']:>3} · "
                f"циклов {r['cycles']:>4} · макс. орд. {r['max_orders']} (до {r['max_notional']:.0f} $) · комиссии {r['fees']:.2f} $")
            say("        по месяцам: " + "  ".join(f"{m} {v:+.1f}" for m, v in sorted(r["monthly"].items())))
    for n, r in regs.items():
        v = r[~np.isnan(r)]
        say(f"  {n}: вверх {np.mean(v > 0) * 100:.0f}% времени, переключений {int(np.sum(np.diff(v) != 0))}")
    say("")
    say("Как читать: стоп −41 $ = бот в GinArea остановился бы и ждал тебя. Если стопов много, а итог около нуля")
    say("или в минусе — шаг/число ордеров не подходят под текущую волатильность BTC. Это приближение: точный")
    say("алгоритм Auto и динамических границ GinArea не публикует; сверяй с историей бота в GinArea.")
    OUT.parent.mkdir(exist_ok=True)
    OUT.write_text("\n".join(LINES), encoding="utf-8")
    print(f"\nОтчёт: {OUT}")


if __name__ == "__main__":
    main()
