#!/usr/bin/env python3
"""
Fee-aware, no-lookahead backtester for the SECOND Veles Finance bot the user
showed screenshots of on 2026-09-04 (SOL/USDT, 15m, Bybit Futures, "Свой"/
Custom order mode with only 1/40 orders configured -- i.e. NO averaging
grid, just a single full-size order per deal). This is a DIFFERENT bot from
kc_roc_cci_wt_grid_backtest.py's (cabinet/bot/4467479) -- do not confuse the
two; this one is deliberately a separate, standalone, un-renamed file until
it's actually validated and the user decides to keep it.

WHAT THIS TRIES TO REPLICATE, and where it is honestly an APPROXIMATION
(read this before trusting any number this script prints):

  - Chart showed two indicator panels: "Пересечение MACD и нулевого уровня"
    (MACD zero-line cross) and "SrgArt DiverX". Per Veles' own filter docs
    (help.veles.finance/en/filters/macd/), "zero line crossover" is the
    standard MACD line (fast EMA - slow EMA) crossing 0, INDEPENDENT of the
    9-period signal line -- default periods 12/26/9 assumed since nothing
    in the screenshots overrode them. This part is EXACT, not approximate.

  - "SrgArt DiverX" is a proprietary Veles-native indicator. Per Veles' own
    docs (help.veles.finance/en/filters/srgart-diverx/), it detects
    MACD-vs-price divergence (bearish: price higher high + MACD lower high;
    bullish: price lower low + MACD higher low) through an undisclosed
    "unique signal-filtering algorithm" -- exact lookback/thresholds are
    NOT published anywhere public. This script's `divergence_approx` mode
    is a standard, textbook MACD/price divergence detector (confirmed
    pivot highs/lows via app/indicators/common.pivothigh/low, same
    no-lookahead convention as the rest of this project) built to the same
    CONCEPT Veles describes -- it is NOT SrgArt DiverX's real algorithm and
    will not fire on exactly the same bars. Every summary line from
    exit-mode=divergence_approx is labeled as such in the output; treat it
    as a plausibility check, not a validated replica.

  - The two screenshots did not show a dedicated "Условия открытия сделки"
    filter-combination panel (unlike the plain-text dump the user pasted
    for the OTHER bot, Влад/XWvCF) -- so whether entry actually requires
    MACD-cross alone, DiverX alone, or both together (AND) is NOT
    confirmed. This script does not guess: it runs MACD-zero-cross alone
    as the entry (the one fully-specified, exact piece), in both possible
    directions separately, and reports each direction on its own so
    nothing is silently averaged together.

  - Both "СТОП-ЛОСС" and "СТОП-ЛОСС ПО СИГНАЛУ" toggles were OFF and
    "Минимальный P&L" was "Отключено" in the screenshots -- so this engine
    has NO price-based stop-loss and NO minimum-P&L gate on the signal
    exit, matching what was actually shown. A --max-deal-bars safety
    timeout still exists purely so one bad deal can't hang open forever in
    the backtest window; it is not part of the real bot's rules.

  - "Подтяжка сетки ордеров: 0.1%" (grid pull-up) only matters when there
    are unfilled RESTING orders to cancel -- with 1/40 orders (just a
    market base order, 100% volume, 0% offset) there is nothing pending,
    so this parameter has no simulated effect here and is omitted.

Bottom line printed with every run: this is a legitimate backtest of the
ONE fully-documented piece (MACD zero-cross) combined with either an exact
mirror-signal exit (macd_flip) or a labeled approximation of the other
piece (divergence_approx) -- not a certified replica of the real bot.
Needs the "Условия открытия сделки" screenshot + confirmation on
direction/filter-combination before this can be tightened further.

Needs network access to Bybit's public API -- run on your own machine:

    python macd_zerocross_diverx_backtest.py --symbol SOLUSDT --bars 20000
"""
from __future__ import annotations

import argparse
import csv
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np
import pandas as pd
import requests

from app.data import BYBIT_BASE, INTERVAL_MAP, DataError
from app.indicators.common import ema, pivothigh, pivotlow

FEE_SCENARIOS = {
    "taker+taker": 0.0011,
    "taker+maker": 0.00075,
    "maker+maker": 0.0004,
}


# --------------------------------------------------------------- data --
# (same pattern as kc_roc_cci_wt_grid_backtest.py's fetch_history --
# duplicated on purpose so this file stays standalone/diffable)

def _fetch_page(params: dict, symbol: str, retries: int = 3, timeout: float = 15.0) -> dict:
    last_exc: Exception | None = None
    for attempt in range(retries):
        try:
            resp = requests.get(f"{BYBIT_BASE}/v5/market/kline", params=params, timeout=timeout)
            resp.raise_for_status()
            return resp.json()
        except requests.RequestException as exc:
            last_exc = exc
            if attempt < retries - 1:
                time.sleep(1.5 * (attempt + 1))
    raise DataError(f"Bybit request failed for {symbol} after {retries} attempts: {last_exc}")


def fetch_history(symbol: str, timeframe: str, total_bars: int, category: str = "linear") -> pd.DataFrame:
    interval = INTERVAL_MAP[timeframe]
    all_rows: list = []
    end = None
    while len(all_rows) < total_bars:
        params = {"category": category, "symbol": symbol, "interval": interval, "limit": 1000}
        if end is not None:
            params["end"] = end
        payload = _fetch_page(params, symbol)
        if payload.get("retCode") != 0:
            raise DataError(f"Bybit API error for {symbol}: {payload.get('retMsg')}")
        rows = payload["result"]["list"]
        if not rows:
            break
        all_rows.extend(rows)
        oldest_ts = int(rows[-1][0])
        end = oldest_ts - 1
        if len(rows) < 1000:
            break
        time.sleep(0.15)

    if not all_rows:
        raise DataError(f"No kline data returned for {symbol} {timeframe}")

    df = pd.DataFrame(all_rows, columns=["open_time", "open", "high", "low", "close", "volume", "turnover"])
    df["open_time"] = df["open_time"].astype("int64")
    df = df.drop_duplicates(subset="open_time")
    for col in ("open", "high", "low", "close", "volume", "turnover"):
        df[col] = df[col].astype(float)
    df["open_time"] = pd.to_datetime(df["open_time"], unit="ms", utc=True)
    df = df.sort_values("open_time").reset_index(drop=True)
    if len(df) > total_bars:
        df = df.tail(total_bars).reset_index(drop=True)
    return df


# ----------------------------------------------------------- indicators --

def macd_line(close: pd.Series, fast: int, slow: int) -> pd.Series:
    return ema(close, fast) - ema(close, slow)


def zero_cross_up(series: pd.Series) -> pd.Series:
    prev = series.shift(1)
    return (prev <= 0) & (series > 0)


def zero_cross_down(series: pd.Series) -> pd.Series:
    prev = series.shift(1)
    return (prev >= 0) & (series < 0)


def find_pivots(price: pd.Series, left: int, right: int, kind: str) -> list[tuple[int, int]]:
    """Returns [(confirm_bar_index, peak_bar_index), ...] in order. kind is
    'high' or 'low'. No-lookahead: a pivot at bar i is only knowable once
    `right` further bars have printed, so it's reported at i+right, same
    convention as app/indicators/common.pivothigh/pivotlow."""
    vals = price.to_numpy(dtype=float)
    n = len(vals)
    out: list[tuple[int, int]] = []
    for i in range(left, n - right):
        window = vals[i - left: i + right + 1]
        if kind == "high" and vals[i] == window.max():
            out.append((i + right, i))
        elif kind == "low" and vals[i] == window.min():
            out.append((i + right, i))
    return out


def divergence_exit_signal(close: pd.Series, macd: pd.Series, left: int, right: int,
                            kind: str) -> pd.Series:
    """kind='bearish' -> exit-longs signal (price higher high, MACD lower
    high). kind='bullish' -> exit-shorts signal (price lower low, MACD
    higher low). This is the `divergence_approx` stand-in for SrgArt
    DiverX described in the module docstring -- NOT the real algorithm."""
    n = len(close)
    out = np.zeros(n, dtype=bool)
    pivot_kind = "high" if kind == "bearish" else "low"
    pivots = find_pivots(close, left, right, pivot_kind)
    close_v = close.to_numpy(dtype=float)
    macd_v = macd.to_numpy(dtype=float)
    prev_peak_idx = None
    for confirm_bar, peak_bar in pivots:
        if np.isnan(macd_v[peak_bar]):
            continue
        if prev_peak_idx is not None and not np.isnan(macd_v[prev_peak_idx]):
            if kind == "bearish":
                diverges = close_v[peak_bar] > close_v[prev_peak_idx] and macd_v[peak_bar] < macd_v[prev_peak_idx]
            else:
                diverges = close_v[peak_bar] < close_v[prev_peak_idx] and macd_v[peak_bar] > macd_v[prev_peak_idx]
            if diverges:
                out[confirm_bar] = True
        prev_peak_idx = peak_bar
    return pd.Series(out, index=close.index)


# ------------------------------------------------------------- params --

@dataclass
class Params:
    macd_fast: int
    macd_slow: int
    exit_mode: str          # "macd_flip" | "divergence_approx"
    div_left: int
    div_right: int
    max_deal_bars: int


@dataclass
class Deal:
    symbol: str
    direction: str
    entry_time: pd.Timestamp
    exit_time: pd.Timestamp | None
    entry_price: float
    exit_price: float | None
    reason: str  # "SIGNAL" | "TIMEOUT" | "OPEN_AT_CUTOFF"
    bars_held: int
    gross_pnl_pct: float | None
    meta: dict = field(default_factory=dict)


def compute_indicators(df: pd.DataFrame, p: Params) -> dict:
    macd = macd_line(df["close"], p.macd_fast, p.macd_slow)
    long_entry = zero_cross_up(macd).fillna(False)
    short_entry = zero_cross_down(macd).fillna(False)

    if p.exit_mode == "macd_flip":
        exit_long = short_entry
        exit_short = long_entry
    elif p.exit_mode == "divergence_approx":
        exit_long = divergence_exit_signal(df["close"], macd, p.div_left, p.div_right, "bearish")
        exit_short = divergence_exit_signal(df["close"], macd, p.div_left, p.div_right, "bullish")
    else:
        raise ValueError(f"unknown exit_mode {p.exit_mode!r}")

    defined = macd.notna()
    return {
        "macd": macd, "long_entry": long_entry, "short_entry": short_entry,
        "exit_long": exit_long, "exit_short": exit_short, "defined": defined,
    }


# --------------------------------------------------------- walk-forward --

def simulate_symbol(df: pd.DataFrame, symbol: str, p: Params, direction: str) -> list[Deal]:
    """direction: 'long' (only take long-side MACD-cross-up entries),
    'short' (only cross-down entries), or 'both' (take whichever fires,
    flat-to-flat, never both sides open at once -- matches a single-order,
    no-hedge bot)."""
    ind = compute_indicators(df, p)
    defined = ind["defined"]
    n = len(df)
    first_valid = defined.idxmax() if defined.any() else None
    if first_valid is None:
        return []

    deals: list[Deal] = []
    i = int(first_valid)
    in_deal = False
    deal_dir = None
    entry_price = 0.0
    deal_start_bar = -1

    while i < n:
        if not defined.iloc[i]:
            i += 1
            continue

        if not in_deal:
            want_long = direction in ("long", "both") and bool(ind["long_entry"].iloc[i])
            want_short = direction in ("short", "both") and bool(ind["short_entry"].iloc[i])
            if want_long or want_short:
                deal_dir = "long" if want_long else "short"
                entry_price = float(df["close"].iloc[i])
                deal_start_bar = i
                in_deal = True
            i += 1
            continue

        closed = False
        sig = ind["exit_long"].iloc[i] if deal_dir == "long" else ind["exit_short"].iloc[i]
        if bool(sig):
            exit_price = float(df["close"].iloc[i])
            gross = ((exit_price - entry_price) / entry_price * 100.0 if deal_dir == "long"
                      else (entry_price - exit_price) / entry_price * 100.0)
            deals.append(Deal(
                symbol=symbol, direction=deal_dir, entry_time=df["open_time"].iloc[deal_start_bar],
                exit_time=df["open_time"].iloc[i], entry_price=entry_price, exit_price=exit_price,
                reason="SIGNAL", bars_held=i - deal_start_bar, gross_pnl_pct=gross,
            ))
            closed = True
        elif (i - deal_start_bar) >= p.max_deal_bars:
            exit_price = float(df["close"].iloc[i])
            gross = ((exit_price - entry_price) / entry_price * 100.0 if deal_dir == "long"
                      else (entry_price - exit_price) / entry_price * 100.0)
            deals.append(Deal(
                symbol=symbol, direction=deal_dir, entry_time=df["open_time"].iloc[deal_start_bar],
                exit_time=df["open_time"].iloc[i], entry_price=entry_price, exit_price=exit_price,
                reason="TIMEOUT", bars_held=i - deal_start_bar, gross_pnl_pct=gross,
            ))
            closed = True

        if closed:
            in_deal = False
            deal_dir = None
        i += 1

    if in_deal:
        last_close = float(df["close"].iloc[-1])
        gross = ((last_close - entry_price) / entry_price * 100.0 if deal_dir == "long"
                  else (entry_price - last_close) / entry_price * 100.0)
        deals.append(Deal(
            symbol=symbol, direction=deal_dir, entry_time=df["open_time"].iloc[deal_start_bar],
            exit_time=df["open_time"].iloc[-1], entry_price=entry_price, exit_price=last_close,
            reason="OPEN_AT_CUTOFF", bars_held=(n - 1) - deal_start_bar, gross_pnl_pct=gross,
        ))

    return deals


# --------------------------------------------------------------- report --

def net_pnl_pct(deal: Deal, fee_rate: float) -> float | None:
    if deal.gross_pnl_pct is None:
        return None
    return deal.gross_pnl_pct - fee_rate * 100.0


def summarize(deals: list[Deal], label: str) -> None:
    if not deals:
        print(f"\n{label}: no deals opened in this window.")
        return
    resolved = [d for d in deals if d.reason in ("SIGNAL", "TIMEOUT")]
    still_open = [d for d in deals if d.reason == "OPEN_AT_CUTOFF"]
    wins = [d for d in resolved if d.gross_pnl_pct is not None and d.gross_pnl_pct > 0]
    win_rate = (len(wins) / len(resolved) * 100) if resolved else float("nan")
    avg_gross = (sum(d.gross_pnl_pct for d in resolved) / len(resolved)) if resolved else float("nan")
    avg_bars = (sum(d.bars_held for d in deals) / len(deals)) if deals else float("nan")

    print(f"\n{label}")
    print(f"  Total deals opened:      {len(deals)}")
    print(f"  Resolved (signal/timeout):{len(resolved)}   Still open at cutoff: {len(still_open)}")
    print(f"  Avg bars held/deal:      {avg_bars:.1f}")
    print(f"  Gross win rate:          {win_rate:.1f}%")
    print(f"  Gross avg P&L% :         {avg_gross:+.3f}%")
    reasons = {}
    for d in resolved:
        reasons[d.reason] = reasons.get(d.reason, 0) + 1
    print(f"  Exit reasons: {reasons}")

    for label_fee, fee_rate in FEE_SCENARIOS.items():
        nets = [net_pnl_pct(d, fee_rate) for d in resolved]
        nets = [x for x in nets if x is not None]
        if not nets:
            continue
        net_wins = sum(1 for x in nets if x > 0)
        print(f"    net P&L% after {label_fee:12s} fees: {sum(nets)/len(nets):+.3f}%  "
              f"win rate {net_wins/len(nets)*100:.1f}%")


def save_csv(deals: list[Deal], path: Path) -> None:
    if not deals:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = ["symbol", "direction", "entry_time", "exit_time", "entry_price",
                  "exit_price", "reason", "bars_held", "gross_pnl_pct"]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for d in deals:
            writer.writerow({k: getattr(d, k) for k in fieldnames})


def split_sample(deals: list[Deal]) -> tuple[list[Deal], list[Deal]]:
    """Calendar split-in-half by entry_time, same convention used
    throughout this project's other backtests (e.g. pine-indicators split
    validation) -- checks the result isn't an artifact of one half of the
    window."""
    resolved = sorted([d for d in deals if d.reason in ("SIGNAL", "TIMEOUT")], key=lambda d: d.entry_time)
    if len(resolved) < 4:
        return resolved, []
    mid = len(resolved) // 2
    return resolved[:mid], resolved[mid:]


# -------------------------------------------------------------------- --

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--symbol", nargs="+", default=["SOLUSDT"])
    parser.add_argument("--timeframe", default="15m", help="matches the 15m chart shown in the screenshots")
    parser.add_argument("--bars", type=int, default=20000)
    parser.add_argument("--out", default="macd_zerocross_diverx_backtest_out")

    parser.add_argument("--macd-fast", type=int, default=12)
    parser.add_argument("--macd-slow", type=int, default=26)

    parser.add_argument("--exit-mode", choices=["macd_flip", "divergence_approx", "both"], default="both")
    parser.add_argument("--div-left", type=int, default=5, help="pivot lookback bars (each side) for divergence_approx")
    parser.add_argument("--div-right", type=int, default=5, help="pivot confirmation bars for divergence_approx (adds this many bars of lag before a divergence exit can fire, no-lookahead)")

    parser.add_argument("--direction", choices=["long", "short", "both"], default="both",
                         help="'both' opens whichever side fires next, one deal at a time, never both sides simultaneously")
    parser.add_argument("--max-deal-bars", type=int, default=5000, help="safety timeout only -- NOT part of the real bot's rules (see docstring)")

    args = parser.parse_args()
    exit_modes = ["macd_flip", "divergence_approx"] if args.exit_mode == "both" else [args.exit_mode]

    print(__doc__)
    print("=" * 78)

    out_dir = Path(args.out)
    for symbol in args.symbol:
        symbol = symbol.upper()
        print(f"\nFetching {symbol} ({args.bars} bars of {args.timeframe})...")
        try:
            df = fetch_history(symbol, args.timeframe, args.bars)
        except DataError as exc:
            print(f"  [SKIP] {symbol}: {exc}")
            continue
        print(f"  {len(df)} bars, {df['open_time'].iloc[0]} .. {df['open_time'].iloc[-1]}")

        for exit_mode in exit_modes:
            p = Params(
                macd_fast=args.macd_fast, macd_slow=args.macd_slow,
                exit_mode=exit_mode, div_left=args.div_left, div_right=args.div_right,
                max_deal_bars=args.max_deal_bars,
            )
            print(f"\n{'#'*78}\n# exit_mode = {exit_mode}"
                  f"{'  (APPROXIMATION of SrgArt DiverX, not the real algorithm)' if exit_mode == 'divergence_approx' else '  (exact: opposite MACD zero-cross)'}\n{'#'*78}")

            for direction in (["long", "short"] if args.direction == "both" else [args.direction]):
                deals = simulate_symbol(df, symbol, p, direction)
                label = f"{symbol} | direction={direction} | exit={exit_mode}"
                summarize(deals, label)
                save_csv(deals, out_dir / f"{symbol}_{direction}_{exit_mode}_deals.csv")

                early, late = split_sample(deals)
                if early and late:
                    summarize(early, f"  {label} -- EARLY half (split-sample)")
                    summarize(late, f"  {label} -- LATE half (split-sample)")

    print(f"\nPer-deal CSVs written to {out_dir.resolve()}")


if __name__ == "__main__":
    main()
