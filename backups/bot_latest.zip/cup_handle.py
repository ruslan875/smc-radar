"""cup_handle.py — 2026-11-09. «Чашка с ручкой» (cup & handle) — детектор и бэктест в R. Только лонг.

Чашка: левый край — локальный максимум (свинг 5/5), правый край — максимум в пределах ±5% от левого через 30–150 свечей;
дно между ними глубиной 12–50% от края, расположено в средней части чашки (20–80% ширины) — «округлое».
Ручка: после правого края 5–30 свечей отката на 15–50% глубины чашки, без новых максимумов выше края.
Вход: закрытие выше максимума ручки/края. Стоп: минимум ручки (если он дальше 3 ATR — пропуск).
Выходы (варианты): «на глубину чашки» (классика), «Фибо 1.618 чашки», «3R», «трейл EMA20 после +1R».
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def _atr(h, l, c):
    pc = np.r_[c[0], c[:-1]]
    return pd.Series(np.maximum(h - l, np.maximum(abs(h - pc), abs(l - pc)))).ewm(alpha=1 / 14, adjust=False).mean().values


def setups(h, l, c, sw=5):
    """Список (k_вход, вход, стоп, глубина, правый_край)."""
    n = len(c); piv = [i for i in range(sw, n - sw) if h[i] == h[i - sw:i + sw + 1].max()]
    a_ = _atr(h, l, c); out = []; used = -1
    for bi, b in enumerate(piv):
        R = h[b]
        for a in reversed(piv[:bi]):
            if b - a < 30:
                continue
            if b - a > 150:
                break
            L = h[a]
            if abs(L - R) / L > 0.05 or h[a + 1:b].max() > max(L, R) * 1.001:
                continue
            j = a + int(np.argmin(l[a:b + 1])); B = l[j]; depth = max(L, R) - B
            if not (0.12 <= depth / max(L, R) <= 0.50) or not (0.2 <= (j - a) / (b - a) <= 0.8):
                continue
            top = max(L, R); lo = np.inf
            for k in range(b + 1, min(n, b + 31)):
                if h[k] > top * 1.001 and c[k] <= top:
                    break                      # прокол без закрытия выше — ручка сломана
                lo = min(lo, l[k])
                if c[k] > top and k - b >= 5:
                    ret = (top - lo) / depth
                    if 0.15 <= ret <= 0.50 and k > used and 0 < c[k] - lo < 3 * a_[k]:
                        out.append((k, float(c[k]), float(lo), float(depth), float(top)))
                        used = k
                    break
            break
    return out


def trades(d: pd.DataFrame, mode: str, cost: float = 0.0011) -> list[dict]:
    h, l, c, t = d.h.values, d.l.values, d.c.values, d.t.values
    e20 = pd.Series(c).ewm(span=20, adjust=False).mean().values
    out, busy = [], -1
    for k, e, sl, depth, top in setups(h, l, c):
        if k <= busy:
            continue
        risk = e - sl
        if risk <= 0:
            continue
        tp = {"depth": top + depth, "fib": top + 0.618 * depth, "r3": e + 3 * risk}.get(mode)   # fib = 1.618 от дна чашки
        be = False; r = None
        for j in range(k + 1, len(c)):
            if l[j] <= sl:
                r = (sl - e) / risk; break
            if tp is not None and h[j] >= tp:
                r = (tp - e) / risk; break
            if mode == "trail":
                if (c[j] - e) / risk >= 1:
                    be = True
                if be and c[j] < e20[j]:
                    r = (c[j] - e) / risk; break
            if j - k > 400:
                r = (c[j] - e) / risk; break
        if r is None:
            break
        out.append({"in_t": int(t[k]), "r": r - cost * e / risk}); busy = j
    return out
