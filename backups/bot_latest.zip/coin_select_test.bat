@echo off
chcp 65001 >nul
cd /d "D:\VANTORIX\bot"
echo Coin selection honesty test. 20-40 min, no trading.
python coin_select_test.py
echo.
pause
