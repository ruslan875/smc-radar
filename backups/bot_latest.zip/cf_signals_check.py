"""cf_signals_check.py — 2026-11-01. Проверка РЕАЛЬНЫХ сигналов CryptoFORA (экспорт темы «Результаты»): каждая сделка по минутным
свечам Binance USDT-фьючерсов (запасной Bybit) от времени сигнала (МСК), вход по цене сигнала, стоп/тейк как в сигнале (1R/2R/3R), одновременное касание = стоп,
не закрылась за 25 ч — по последней цене. Комиссия 0.08% (Hash Hedge). Также: насколько цена в момент сигнала уже ушла от входа.
Вход: bt_lab_bots/cf_signals.json. Пишет bt_lab_bots/cf_signals_check.txt и cf_signals_res2.json"""
from __future__ import annotations
import json, sys, time, datetime as dt
from pathlib import Path
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass
import requests
BASE = Path(__file__).resolve().parent; BOTS = BASE / "bt_lab_bots"
FEE = 0.0008; MSK = dt.timezone(dt.timedelta(hours=3))


ERR = {}


def kl(sym, start):
    """Binance USDT-фьючерсы (источник сигналов CryptoFORA), 1m, 1500 свечей = 25 ч одним запросом; запасной — Bybit."""
    for a in range(3):
        try:
            r = requests.get("https://fapi.binance.com/fapi/v1/klines", params={"symbol": sym, "interval": "1m", "startTime": start, "limit": 1500}, timeout=25)
            j = r.json()
            if isinstance(j, list) and j:
                return [(int(x[0]), float(x[1]), float(x[2]), float(x[3]), float(x[4])) for x in j]
            ERR["binance " + str(j)[:60]] = ERR.get("binance " + str(j)[:60], 0) + 1
            break
        except Exception as exc:  # noqa: BLE001
            ERR["binance " + type(exc).__name__] = ERR.get("binance " + type(exc).__name__, 0) + 1; time.sleep(1 + a * 2)
    try:
        r = requests.get("https://api.bybit.com/v5/market/kline", params={"category": "linear", "symbol": sym, "interval": "1", "start": start, "limit": 1000}, timeout=25).json()
        rows = sorted((int(x[0]), float(x[1]), float(x[2]), float(x[3]), float(x[4])) for x in r["result"]["list"])
        return rows or None
    except Exception as exc:  # noqa: BLE001
        ERR["bybit " + type(exc).__name__] = ERR.get("bybit " + type(exc).__name__, 0) + 1
        return None


def one(s):
    risk = abs(s["entry"] - s["sl"])
    if risk <= 0:
        return {**s, "skip": "стоп = вход"}
    t0 = int(dt.datetime.strptime(s["time"], "%H:%M %d.%m.%Y").replace(tzinfo=MSK).timestamp() * 1000)
    k = kl(s["sym"] + "USDT", t0)
    if not k:
        return None                      # сеть/нет монеты — попробуем в следующий запуск
    sd = s["side"]; e = s["entry"]; slip = sd * (k[0][1] - e) / risk
    out = {}
    for j, tp in enumerate(s["tp"], 1):
        r = None
        for (_t, o, h, l, c) in k:
            if (l <= s["sl"]) if sd > 0 else (h >= s["sl"]):
                r = -1.0; break
            if (h >= tp) if sd > 0 else (l <= tp):
                r = sd * (tp - e) / risk; break
        if r is None:
            r = sd * (k[-1][4] - e) / risk
        out[f"tp{j}"] = round(r - FEE * e / risk, 3)
    return {**s, "slip_R": round(slip, 3), "stop_pct": round(risk / e * 100, 3), "fee_R": round(FEE * e / risk, 3), **out}


def main():
    from concurrent.futures import ThreadPoolExecutor  # noqa: PLC0415
    sig = json.loads((BOTS / "cf_signals.json").read_text(encoding="utf-8"))
    res = []
    for f in ("cf_signals_res2.json", "cf_signals_res3.json"):
        try:
            res += [r for r in json.loads((BOTS / f).read_text(encoding="utf-8")) if "tp1" in r or r.get("skip") == "стоп = вход"]
        except Exception:  # noqa: BLE001
            pass
    done = {(r["sym"], r["time"], r["strat"]) for r in res}
    res = list({(r["sym"], r["time"], r["strat"]): r for r in res}.values())
    todo = [s for s in sig if (s["sym"], s["time"], s["strat"]) not in done]
    print(f"уже есть {len(res)}, осталось {len(todo)}", flush=True)
    with ThreadPoolExecutor(6) as ex:
        for n, r in enumerate(ex.map(one, todo)):
            if r:
                res.append(r)
            if n % 50 == 0:
                print(f"{n}/{len(todo)} ок {len(res)} ошибки: {ERR}", flush=True)
                (BOTS / "cf_signals_res3.json").write_text(json.dumps(res, ensure_ascii=False), encoding="utf-8")
    (BOTS / "cf_signals_res3.json").write_text(json.dumps(res, ensure_ascii=False), encoding="utf-8")
    ok = [r for r in res if "tp1" in r]; lines = [f"Сигналов в экспорте {len(sig)}, проверено {len(ok)}",
                                               "стратегия · сделок · стоп% (медиана) · комиссия в R · win TP1 · R/сд TP1 · TP2 · TP3"]
    import statistics as S
    groups = {}
    for r in ok:
        groups.setdefault(r["strat"], []).append(r)
    groups["ВСЕ"] = ok
    for nm, g in sorted(groups.items(), key=lambda x: -len(x[1])):
        a = lambda key: sum(x[key] for x in g) / len(g)  # noqa: E731
        lines.append(f"{nm:<22} {len(g):5} · {S.median(x['stop_pct'] for x in g):.2f}% · {S.median(x['fee_R'] for x in g):.2f}R · "
                     f"{sum(x['tp1'] > 0 for x in g) / len(g) * 100:3.0f}% · {a('tp1'):+.3f} · {a('tp2'):+.3f} · {a('tp3'):+.3f}")
    lines.append(f"Цена в момент сигнала ушла от входа (медиана, R): {S.median(x['slip_R'] for x in ok):+.3f}")
    (BOTS / "cf_signals_check.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines)); print("готово")


if __name__ == "__main__":
    main()
