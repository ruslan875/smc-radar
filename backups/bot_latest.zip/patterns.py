"""patterns.py — 2026-11-09. Классические фигуры и свечные паттерны: детекторы + бэктест в R.
Сигнал = (индекс свечи входа, сторона ±1, уровень стопа). Вход по закрытию сигнальной свечи.
Стоп: за паттерном, но не ближе 0.5 ATR и не дальше 3 ATR (иначе пропуск). Выход: тейк 2R или 3R, или 60 свечей.
Фильтр тренда (вариант): только по EMA50/EMA200.
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def _atr(h, l, c):
    pc = np.r_[c[0], c[:-1]]
    return pd.Series(np.maximum(h - l, np.maximum(abs(h - pc), abs(l - pc)))).ewm(alpha=1 / 14, adjust=False).mean().values


def _pivots(h, l, n=5):
    N = len(h); ph, pl = [], []
    for i in range(n, N - n):
        if h[i] == h[i - n:i + n + 1].max():
            ph.append(i)
        if l[i] == l[i - n:i + n + 1].min():
            pl.append(i)
    return ph, pl


def candles(o, h, l, c):
    """Свечные: поглощение, пин-бар, внутренний бар, утренняя/вечерняя звезда, три солдата/вороны."""
    N = len(c); S = {k: [] for k in ("Поглощение", "Пин-бар", "Внутренний бар (пробой)", "Утренняя/вечерняя звезда", "Три солдата/вороны")}
    lo20 = pd.Series(l).rolling(20).min().values; hi20 = pd.Series(h).rolling(20).max().values
    body = abs(c - o); rng = np.maximum(h - l, 1e-12)
    for i in range(22, N - 1):
        # поглощение после 3 свечей против
        if c[i] > o[i] and c[i - 1] < o[i - 1] and c[i] >= o[i - 1] and o[i] <= c[i - 1] and c[i - 3] > c[i - 1]:
            S["Поглощение"].append((i, 1, min(l[i], l[i - 1])))
        if c[i] < o[i] and c[i - 1] > o[i - 1] and c[i] <= o[i - 1] and o[i] >= c[i - 1] and c[i - 3] < c[i - 1]:
            S["Поглощение"].append((i, -1, max(h[i], h[i - 1])))
        # пин-бар у 20-свечного экстремума
        lw = min(o[i], c[i]) - l[i]; uw = h[i] - max(o[i], c[i])
        if lw >= 0.66 * rng[i] and body[i] <= 0.3 * rng[i] and l[i] <= lo20[i - 1]:
            S["Пин-бар"].append((i, 1, l[i]))
        if uw >= 0.66 * rng[i] and body[i] <= 0.3 * rng[i] and h[i] >= hi20[i - 1]:
            S["Пин-бар"].append((i, -1, h[i]))
        # внутренний бар: свеча i-1 внутри i-2, вход на пробое материнской свечой i
        if h[i - 1] < h[i - 2] and l[i - 1] > l[i - 2]:
            if c[i] > h[i - 2]:
                S["Внутренний бар (пробой)"].append((i, 1, l[i - 2]))
            elif c[i] < l[i - 2]:
                S["Внутренний бар (пробой)"].append((i, -1, h[i - 2]))
        # утренняя / вечерняя звезда
        if c[i - 2] < o[i - 2] and body[i - 2] > 0.6 * rng[i - 2] and body[i - 1] < 0.3 * rng[i - 1] and c[i] > o[i] and c[i] > (o[i - 2] + c[i - 2]) / 2:
            S["Утренняя/вечерняя звезда"].append((i, 1, min(l[i - 2:i + 1])))
        if c[i - 2] > o[i - 2] and body[i - 2] > 0.6 * rng[i - 2] and body[i - 1] < 0.3 * rng[i - 1] and c[i] < o[i] and c[i] < (o[i - 2] + c[i - 2]) / 2:
            S["Утренняя/вечерняя звезда"].append((i, -1, max(h[i - 2:i + 1])))
        # три солдата / три вороны
        if all(c[i - k] > o[i - k] and body[i - k] > 0.5 * rng[i - k] and c[i - k] > c[i - k - 1] for k in range(3)):
            S["Три солдата/вороны"].append((i, 1, l[i - 2]))
        if all(c[i - k] < o[i - k] and body[i - k] > 0.5 * rng[i - k] and c[i - k] < c[i - k - 1] for k in range(3)):
            S["Три солдата/вороны"].append((i, -1, h[i - 2]))
    return S


def figures(o, h, l, c):
    """Фигуры: двойное дно/вершина, голова-плечи, треугольник, флаг. Вход — на пробое линии шеи/границы (закрытием)."""
    N = len(c); a = _atr(h, l, c); ph, pl = _pivots(h, l, 5)
    S = {k: [] for k in ("Двойное дно/вершина", "Голова и плечи", "Треугольник (пробой)", "Флаг (продолжение)")}
    used = {}

    def fire(key, start, side, lvl, stop, maxwait=30):
        for k in range(start, min(N - 1, start + maxwait)):
            if (c[k] > lvl) if side > 0 else (c[k] < lvl):
                if k > used.get(key, -1):
                    S[key].append((k, side, stop)); used[key] = k
                return
            if (l[k] < stop) if side > 0 else (h[k] > stop):
                return
    # двойное дно / вершина
    for x, y in zip(pl, pl[1:]):
        if 10 <= y - x <= 60 and abs(l[x] - l[y]) / l[x] < 0.02:
            neck = h[x:y + 1].max()
            if (neck - min(l[x], l[y])) > 1.5 * a[y]:
                fire("Двойное дно/вершина", y + 5, 1, neck, min(l[x], l[y]))
    for x, y in zip(ph, ph[1:]):
        if 10 <= y - x <= 60 and abs(h[x] - h[y]) / h[x] < 0.02:
            neck = l[x:y + 1].min()
            if (max(h[x], h[y]) - neck) > 1.5 * a[y]:
                fire("Двойное дно/вершина", y + 5, -1, neck, max(h[x], h[y]))
    # голова и плечи (шорт) / перевёрнутая (лонг)
    for p1, p2, p3 in zip(ph, ph[1:], ph[2:]):
        if h[p2] > h[p1] and h[p2] > h[p3] and abs(h[p1] - h[p3]) / h[p2] < 0.03 and p3 - p1 <= 120:
            neck = min(l[p1:p2 + 1].min(), l[p2:p3 + 1].min())
            fire("Голова и плечи", p3 + 5, -1, neck, h[p3])
    for p1, p2, p3 in zip(pl, pl[1:], pl[2:]):
        if l[p2] < l[p1] and l[p2] < l[p3] and abs(l[p1] - l[p3]) / l[p2] < 0.03 and p3 - p1 <= 120:
            neck = max(h[p1:p2 + 1].max(), h[p2:p3 + 1].max())
            fire("Голова и плечи", p3 + 5, 1, neck, l[p3])
    # треугольник: 2 понижающихся максимума и 2 повышающихся минимума, пробой в любую сторону
    j = 0
    for i in range(1, len(ph)):
        a1, a2 = ph[i - 1], ph[i]
        lows = [p for p in pl if a1 - 30 < p < a2 + 30]
        if h[a2] < h[a1] and len(lows) >= 2 and l[lows[-1]] > l[lows[-2]] and a2 - a1 <= 60:
            top, bot = h[a2], l[lows[-1]]; st = max(a2, lows[-1]) + 5
            for k in range(st, min(N - 1, st + 30)):
                if c[k] > top:
                    S["Треугольник (пробой)"].append((k, 1, bot)); break
                if c[k] < bot:
                    S["Треугольник (пробой)"].append((k, -1, top)); break
    # флаг: импульс ≥ 3 ATR за ≤ 10 свечей, затем 5–15 свечей узкого отката (< 50% импульса), пробой по импульсу
    i = 30
    while i < N - 20:
        mv = c[i] - c[i - 10]
        if abs(mv) >= 3 * a[i]:
            s = 1 if mv > 0 else -1; done = False
            for w in range(5, 16):
                seg_h, seg_l = h[i + 1:i + 1 + w].max(), l[i + 1:i + 1 + w].min()
                if seg_h - seg_l > 0.5 * abs(mv):
                    break
                k = i + 1 + w
                if k < N - 1 and ((c[k] > seg_h) if s > 0 else (c[k] < seg_l)):
                    S["Флаг (продолжение)"].append((k, s, seg_l if s > 0 else seg_h)); i = k; done = True; break
            i += 1 if not done else 1
            continue
        i += 1
    return S


def backtest(o, h, l, c, sigs, rr=2.0, cost=0.0011, trend=False, hold=60):
    a = _atr(h, l, c); N = len(c)
    e50 = pd.Series(c).ewm(span=50, adjust=False).mean().values; e200 = pd.Series(c).ewm(span=200, adjust=False).mean().values
    out, busy = [], -1
    for i, s, stop in sorted(sigs):
        if i <= busy or i < 200 or i >= N - 1:
            continue
        if trend and (1 if e50[i] > e200[i] else -1) != s:
            continue
        risk = s * (c[i] - stop)
        if not (0.5 * a[i] <= risk <= 3 * a[i]):
            continue
        tp = c[i] + s * rr * risk; r = None
        for j in range(i + 1, min(N, i + hold + 1)):
            if (l[j] <= stop) if s > 0 else (h[j] >= stop):
                r = -1.0; break
            if (h[j] >= tp) if s > 0 else (l[j] <= tp):
                r = rr; break
        else:
            j = min(N - 1, i + hold); r = s * (c[j] - c[i]) / risk
        out.append((i, r - cost * c[i] / risk)); busy = j
    return out


def random_sigs(o, h, l, c, n, seed=1):
    rng = np.random.default_rng(seed); a = _atr(h, l, c); N = len(c); out = []
    for i in sorted(rng.choice(np.arange(210, N - 2), size=min(n, N - 212), replace=False)):
        s = int(rng.choice([1, -1])); out.append((int(i), s, c[i] - s * 1.5 * a[i]))
    return out
