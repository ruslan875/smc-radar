# -*- coding: utf-8 -*-
"""EMA Strategy [DaVinchi] — порт Pine v6 (настройки по умолчанию, как на скриншоте) и прогон:
Bybit 1000PEPEUSDT.P 30m. ВАЖНО: в коде дата старта = 1 янв 2026 (inDateRange), поэтому при диапазоне тестера
1.01.2025–23.01.2026 сделки идут только с 1.01.2026 по 23.01.2026 — так и считаем.
process_orders_on_close=true → все ордера по цене закрытия свечи. Комиссия 0.005%.
Размер: 1000 USDT на сделку, капитал 100 000 (на скриншоте +328 USDT = +0.33%).
Запуск: python davinchi_ema_test.py → davinchi_report.txt"""
import os, sys, time, json, urllib.request
import numpy as np, pandas as pd
try: sys.stdout.reconfigure(encoding="utf-8")
except Exception: pass
H = os.path.dirname(os.path.abspath(__file__)); CACHE = os.path.join(H, "market_cache", "davinchi"); os.makedirs(CACHE, exist_ok=True)
TP, SL, ACT, OFF, BE, FEE, SIZE, CAP = 5.0, 2.0, 1.5, 0.5, 1.0, 0.00005, 1000.0, 100000.0

def bybit(sym, tf, start, end):
    f = os.path.join(CACHE, f"{sym}_{tf}_{start}_{end}.csv")
    if os.path.exists(f): return pd.read_csv(f, index_col=0, parse_dates=True)
    print(f"скачиваю Bybit {sym} {tf} {start}..{end}")
    s = int(pd.Timestamp(start, tz="UTC").timestamp() * 1000); e = int(pd.Timestamp(end, tz="UTC").timestamp() * 1000); rows = []
    while e > s:
        u = f"https://api.bybit.com/v5/market/kline?category=linear&symbol={sym}&interval={tf}&limit=1000&start={s}&end={e}"
        for k in range(6):
            try: d = json.loads(urllib.request.urlopen(urllib.request.Request(u, headers={"User-Agent": "Mozilla/5.0"}), timeout=25).read()); break
            except Exception as ex: print("  повтор", str(ex)[:50]); time.sleep(3)
        else: return None
        lst = (d.get("result") or {}).get("list") or []
        if not lst: break
        rows += [[int(r[0]), *map(float, r[1:5])] for r in lst]; e = int(lst[-1][0]) - 1; time.sleep(0.1)
    if not rows: return None
    df = pd.DataFrame(rows, columns=["t", "o", "h", "l", "c"]).drop_duplicates("t").sort_values("t")
    df.index = pd.to_datetime(df.t, unit="ms"); df = df.drop(columns="t"); df.to_csv(f); return df

def pema(x, n):
    out = np.full(len(x), np.nan); a = 2 / (n + 1); s = None
    for i, v in enumerate(x):
        if i == n - 1: s = np.mean(x[:n]); out[i] = s
        elif i >= n: s = a * v + (1 - a) * s; out[i] = s
    return out

def run(d, start, end):
    C, Hh, L = d.c.values, d.h.values, d.l.values; T = d.index
    e7, e30 = pema(C, 7), pema(C, 30)
    t0, t1 = pd.Timestamp(start), pd.Timestamp(end)
    st7 = st30 = -1
    pos = 0; avg = None; qty = 0.0; ps_prev = 0
    trail = None; maxp = 0.0; bea = False
    trades = []; eq = CAP; peak = CAP; mdd = 0.0
    def close_pos(px):
        nonlocal pos, avg, qty
        pnl = pos * qty * (px - avg) - qty * px * FEE - qty * avg * FEE; trades.append(pnl); pos = 0; avg = None; qty = 0.0; return pnl
    for i in range(1, len(C)):
        if np.isnan(e30[i - 1]): continue
        g7, r7 = e7[i] > e7[i - 1], e7[i] < e7[i - 1]; g30, r30 = e30[i] > e30[i - 1], e30[i] < e30[i - 1]
        bg = g7 and st7 in (-1, 0) and g30 and st30 in (-1, 0)
        br = r7 and st7 in (-1, 1) and r30 and st30 in (-1, 1)
        st7 = 1 if g7 else 0 if r7 else st7; st30 = 1 if g30 else 0 if r30 else st30
        inr = t0 < T[i] < t1; psz = pos
        if psz == 0 and ps_prev != 0: trail = None; maxp = 0.0; bea = False
        queue = []
        if bg and inr and psz <= 0:
            if psz < 0: queue.append("close")
            queue.append(("entry", 1)); trail = None; maxp = 0.0; bea = False
        if br and inr and psz >= 0:
            if psz > 0: queue.append("close")
            queue.append(("entry", -1)); trail = None; maxp = 0.0; bea = False
        if psz != 0:
            cp = psz * (C[i] - avg) / avg * 100
            if cp > maxp: maxp = cp
            if psz > 0:
                slp = avg * (1 - SL / 100); tpp = avg * (1 + TP / 100)
                if Hh[i] >= avg * (1 + BE / 100) and not bea: trail = avg; bea = True
                if bea and maxp >= ACT:
                    tsp = avg * (1 + (maxp - OFF) / 100)
                    if trail is None or tsp > trail: trail = tsp
                fsl = max(slp, slp if trail is None else trail)
                if C[i] >= tpp or C[i] <= fsl: queue.append("closeall")
            else:
                slp = avg * (1 + SL / 100); tpp = avg * (1 - TP / 100)
                if L[i] <= avg * (1 - BE / 100) and not bea: trail = avg; bea = True
                if bea and maxp >= ACT:
                    tsp = avg * (1 - (maxp - OFF) / 100)
                    if trail is None or tsp < trail: trail = tsp
                fsl = min(slp, slp if trail is None else trail)
                if C[i] <= tpp or C[i] >= fsl: queue.append("closeall")
        ps_prev = psz
        for q in queue:                       # исполнение по close в порядке постановки
            if q in ("close", "closeall"):
                if pos: eq += close_pos(C[i])
            else:
                sd = q[1]
                if pos and pos != sd: eq += close_pos(C[i])
                if pos == 0: pos = sd; avg = C[i]; qty = SIZE / C[i]
        u = eq + (pos * qty * (C[i] - avg) if pos else 0)
        lo = eq + (pos * qty * ((L[i] if pos > 0 else Hh[i]) - avg) if pos else 0)
        peak = max(peak, u); mdd = max(mdd, peak - lo)
    if pos: eq += close_pos(C[-1])
    t = np.array(trades)
    if not len(t): return None
    return dict(net=t.sum(), n=len(t), win=(t > 0).mean() * 100, pf=t[t > 0].sum() / max(-t[t < 0].sum(), 1e-9), dd=mdd, per=t.mean() / SIZE * 100)

COINS = ["1000PEPEUSDT", "BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT", "DOGEUSDT", "ADAUSDT", "LINKUSDT", "BNBUSDT", "AVAXUSDT", "LTCUSDT", "WIFUSDT"]
RUNS = [("1000PEPEUSDT", "30", "2026-01-01", "2026-01-23 21:00", "КАК НА СКРИНШОТЕ")]
RUNS += [(c, "30", "2026-01-01", "2026-01-23 21:00", "тот же период") for c in COINS[1:]]
RUNS += [(c, "30", "2025-01-01", "2026-10-08", "2025–2026 целиком") for c in COINS]
out = []
for sym, tf, a, b, note in RUNS:
    d = bybit(sym, tf, (pd.Timestamp(a) - pd.Timedelta(days=30)).strftime("%Y-%m-%d"), (pd.Timestamp(b) + pd.Timedelta(days=1)).strftime("%Y-%m-%d"))
    r = run(d, a, b) if d is not None and len(d) > 300 else None
    line = f"{sym:13} {a}..{b[:10]}  " + ("нет данных/сделок" if r is None else
           f"итог {r['net']:+8.2f}$  DD {r['dd']:7.2f}$  сделок {r['n']:4}  в плюсе {r['win']:4.1f}%  PF {r['pf']:.3f}  ({r['per']:+.3f}% на сделку)") + f"  [{note}]"
    print(line, flush=True); out.append(line)
out.append("\nСкриншот автора: 1000PEPEUSDT.P Bybit 30m: +328.46 USDT, DD 132 USDT, 115 сделок, 31.30% в плюсе, PF 1.508")
out.append("Размер сделки 1000 USDT; если у автора другой объём — сравнивать PF, число сделок и % в плюсе.")
open(os.path.join(H, "davinchi_report.txt"), "w", encoding="utf-8").write("\n".join(out)); print("\nГотово: davinchi_report.txt")
