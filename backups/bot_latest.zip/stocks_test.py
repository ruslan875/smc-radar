"""stocks_test.py — 2026-11-09. Большой тест фондового рынка (акции США + индексы + сырьё, БЕЗ валют). Запуск на ПК: stocks_test.bat.

Данные: Yahoo, дневные свечи за всю историю, С ОБЪЁМАМИ (кеш market_cache/yahoo, повторно не качает).
Стратегии (все в R — в долях риска, издержки включены):
  Наши проверенные TradFi (тот же код, что бумажные боты):
    BOS 1D (недельный тренд + трейл)   — windows_app/bos_tradfi_paper.replay
    FVG по тренду 3R                   — windows_app/fvg_tradfi_paper.replay
    Ложный пробой «2 свечи» 3R         — windows_app/fb2_tradfi_paper.replay
  Возврат к средней:
    RSI(2) < 10 выше SMA200 → лонг, выход close > SMA5, стоп 2.5 ATR
  ОБЪЁМ (то, что «работает на фондовом»):
    Пробой на объёме: close > макс 20 дн и объём > 2× средн 20, выше SMA200 → лонг, стоп 2 ATR, выход close < мин 10 дн
    Накопление→пробой: 15 дн узкий диапазон (< 1.2 ATR×√15) и объём растёт, затем пробой вверх на объёме → лонг, стоп низ диапазона, выход close < мин 10 дн
    BOS 1D + фильтр объёма: те же сделки BOS, но только где объём сигнальной свечи > 1.5× средн 20
Итог: stocks_test_summary.txt, stocks_test.csv, tradfi_pick.json
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import requests

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import bt_lab as BL  # noqa: E402
from windows_app import bos_tradfi_paper as BOS, fb2_tradfi_paper as FB2, fvg_tradfi_paper as FVG  # noqa: E402

CACHE = BASE / "market_cache" / "yahoo"
CACHE.mkdir(parents=True, exist_ok=True)
START = 0   # 09.11: максимальный период (вся история Yahoo)
COST = 0.0005

STOCKS = ("AAPL MSFT NVDA AMZN GOOGL META TSLA AVGO BRK-B JPM V MA UNH XOM LLY JNJ PG HD COST ABBV MRK CVX KO PEP ADBE CRM "
          "NFLX AMD INTC ORCL CSCO WMT BAC WFC DIS MCD NKE QCOM TXN IBM AMAT MU PYPL UBER SHOP PLTR COIN MSTR BA CAT GE GS MS "
          "C T VZ PFE TMO ABT DHR LOW SBUX BKNG GILD AMGN ISRG NOW INTU PANW CRWD SNOW ABNB F GM RIVN NIO BABA PDD JD SMCI ARM "
          "MRNA DE LMT RTX UPS FDX HON SPOT SQ ROKU DKNG RBLX HOOD SOFI AFRM MARA RIOT").split()
OTHER = {"S&P500": "ES=F", "Nasdaq": "NQ=F", "Dow": "YM=F", "Russell": "RTY=F", "DAX": "^GDAXI", "Золото": "GC=F", "Серебро": "SI=F",
         "Медь": "HG=F", "Нефть WTI": "CL=F", "Нефть Brent": "BZ=F", "Газ": "NG=F", "Платина": "PL=F"}


def yahoo(sym: str) -> pd.DataFrame | None:
    f = CACHE / f"{sym.replace('=', '_').replace('^', '')}_1dfull.csv"   # range=max отдаёт редкие свечи — берём period1=0
    if f.exists() and time.time() - f.stat().st_mtime < 3 * 86400:
        d = pd.read_csv(f)
    else:
        d = None
        for att in range(6):   # Yahoo ограничивает частоту (429) — ждём дольше и чередуем серверы
            try:
                rq = requests.get(f"https://query{1 + att % 2}.finance.yahoo.com/v8/finance/chart/{sym}", params={"interval": "1d", "period1": 0, "period2": int(time.time()), "events": "history"},
                                  headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36"}, timeout=25)
                if rq.status_code == 429:
                    time.sleep(15 + att * 15); continue
                r = rq.json()
                res = r["chart"]["result"][0]; q = res["indicators"]["quote"][0]
                d = pd.DataFrame({"t": np.array(res["timestamp"], dtype="int64") * 1000, "o": q["open"], "h": q["high"], "l": q["low"],
                                  "c": q["close"], "v": q.get("volume")}).dropna(subset=["o", "h", "l", "c"])
                d.to_csv(f, index=False)
                break
            except Exception:  # noqa: BLE001
                time.sleep(5 + att * 5)
        time.sleep(1.5)
        if d is None:
            return None
    d = d[d.t >= START].reset_index(drop=True)
    d["v"] = d["v"].fillna(0)
    return d if len(d) > 400 else None


def _atr(h, l, c):
    pc = np.r_[c[0], c[:-1]]
    return pd.Series(np.maximum(h - l, np.maximum(abs(h - pc), abs(l - pc)))).ewm(alpha=1 / 14, adjust=False).mean().values


def run_exit(i, c, h, l, t, stop, exit_fn, risk):
    for j in range(i + 1, len(c)):
        if l[j] <= stop:
            return j, (stop - c[i]) / risk
        if exit_fn(j):
            return j, (c[j] - c[i]) / risk
    return None, None


def rsi2(d):
    c, h, l, t = d.c.values, d.h.values, d.l.values, d.t.values
    dl = np.diff(c, prepend=c[0]); up = pd.Series(np.maximum(dl, 0)).ewm(alpha=1 / 2, adjust=False).mean(); dn = pd.Series(np.maximum(-dl, 0)).ewm(alpha=1 / 2, adjust=False).mean()
    rs = (100 - 100 / (1 + up / dn.replace(0, np.nan))).fillna(50).values
    s200 = pd.Series(c).rolling(200).mean().values; s5 = pd.Series(c).rolling(5).mean().values; a = _atr(h, l, c)
    out, i = [], 210
    while i < len(c) - 1:
        if rs[i] < 10 and c[i] > s200[i] and a[i] > 0:
            risk = 2.5 * a[i]; j, r = run_exit(i, c, h, l, t, c[i] - risk, lambda k: c[k] > s5[k], risk)
            if j is None:
                break
            out.append({"in_t": int(t[i]), "r": r - COST * c[i] / risk}); i = j + 1; continue
        i += 1
    return out


def vol_breakout(d):
    c, h, l, t, v = d.c.values, d.h.values, d.l.values, d.t.values, d.v.values
    hh = pd.Series(h).rolling(20).max().shift(1).values; ll = pd.Series(l).rolling(10).min().shift(1).values
    va = pd.Series(v).rolling(20).mean().shift(1).values; s200 = pd.Series(c).rolling(200).mean().values; a = _atr(h, l, c)
    out, i = [], 210
    while i < len(c) - 1:
        if c[i] > hh[i] and va[i] > 0 and v[i] > 2 * va[i] and c[i] > s200[i] and a[i] > 0:
            risk = 2 * a[i]; j, r = run_exit(i, c, h, l, t, c[i] - risk, lambda k: c[k] < ll[k], risk)
            if j is None:
                break
            out.append({"in_t": int(t[i]), "r": r - COST * c[i] / risk}); i = j + 1; continue
        i += 1
    return out


def accumulation(d):
    c, h, l, t, v = d.c.values, d.h.values, d.l.values, d.t.values, d.v.values
    N = 15; a = _atr(h, l, c)
    rh = pd.Series(h).rolling(N).max().shift(1).values; rl = pd.Series(l).rolling(N).min().shift(1).values
    v1 = pd.Series(v).rolling(N).mean().shift(1).values; v0 = pd.Series(v).rolling(50).mean().shift(N + 1).values
    ll = pd.Series(l).rolling(10).min().shift(1).values; s200 = pd.Series(c).rolling(200).mean().values
    out, i = [], 260
    while i < len(c) - 1:
        narrow = (rh[i] - rl[i]) < 1.2 * a[i - N] * np.sqrt(N) if a[i - N] > 0 else False
        if narrow and v0[i] > 0 and v1[i] > 1.1 * v0[i] and c[i] > rh[i] and v[i] > 1.5 * v1[i] and c[i] > s200[i]:
            risk = c[i] - rl[i]
            if risk > 0:
                j, r = run_exit(i, c, h, l, t, rl[i], lambda k: c[k] < ll[k], risk)
                if j is None:
                    break
                out.append({"in_t": int(t[i]), "r": r - COST * c[i] / risk}); i = j + 1; continue
        i += 1
    return out


def stats(trs, mid):
    if len(trs) < 5:
        return None
    r = np.array([x["r"] for x in trs]); ti = np.array([x["in_t"] for x in trs])
    pf = r[r > 0].sum() / max(1e-9, -r[r < 0].sum())
    return {"n": len(r), "rpt": round(float(r.mean()), 3), "sum": round(float(r.sum()), 1), "pf": round(float(pf), 2),
            "h1": round(float(r[ti < mid].sum()), 1), "h2": round(float(r[ti >= mid].sum()), 1),
            "y2": round(float(r[ti >= time.time() * 1000 - 730 * 86400e3].sum()), 1), "win": round(float((r > 0).mean() * 100))}


def main() -> None:
    BL.deals_to_trades = lambda rows, df, p, prog=None: rows
    syms = [(s, s) for s in STOCKS] + list(OTHER.items())
    print(f"Инструментов: {len(syms)} (акции {len(STOCKS)}, индексы/сырьё {len(OTHER)}), вся история, дневки", flush=True)
    rows, pick = [], {}
    for k, (name, sym) in enumerate(syms, 1):
        d = yahoo(sym)
        if d is None:
            print(f"[{k}/{len(syms)}] {name}: нет данных", flush=True); continue
        mid = (d.t.iloc[0] + d.t.iloc[-1]) / 2
        va = pd.Series(d.v.values).rolling(20).mean().shift(1).values
        vmap = dict(zip(d.t.values.tolist(), (d.v.values / np.where(va > 0, va, np.nan)).tolist()))
        res = {}
        try:
            bos = [x for x in BOS.replay(d) if x.get("status") == "closed"]
            res["BOS 1D (недельный тренд + трейл)"] = [{"in_t": x["in_t"], "r": x["r"]} for x in bos]
            res["BOS 1D + объём ×1.5"] = [{"in_t": x["in_t"], "r": x["r"]} for x in bos if (vmap.get(x["in_t"]) or 0) > 1.5]
        except Exception as e:  # noqa: BLE001
            print("  BOS", e)
        for nm, mod in (("FVG по тренду 3R", FVG), ("Ложный пробой 2 свечи 3R", FB2)):
            try:
                res[nm] = [{"in_t": x["in_t"], "r": x["r"]} for x in mod.replay(d) if x.get("status") == "closed" and "r" in x]
            except Exception as e:  # noqa: BLE001
                print(" ", nm, e)
        if d.v.sum() > 0:
            res["Пробой на объёме ×2"] = vol_breakout(d)
            res["Накопление → пробой"] = accumulation(d)
        res["RSI(2) возврат"] = rsi2(d)
        # наши КРИПТО-стратегии на дневках (тот же код ботов; итог в % хода цены, не в R; черепахи/Donchian/UT/HA — только лонг)
        try:
            dfc = pd.DataFrame({"t": d.t, "open": d.o, "high": d.h, "low": d.l, "close": d.c, "volume": d.v})
            for st in BL.HONEST:
                rr = BL.sim_honest(dfc, {"strategy": st, "tf": "1D"}, lambda *x: None)
                if st.startswith(("honest:turtle", "honest:donch", "honest:ut", "honest:ha18")):
                    rr = [q for q in rr if q["side"] > 0]
                res["крипто: " + st.split(":")[1] + " (%)"] = [{"in_t": q["t_in"], "r": q["pct"]} for q in rr]
        except Exception as e:  # noqa: BLE001
            print("  крипто-стратегии:", e)
        pk = []
        for st, trs in res.items():
            s = stats(trs, mid)
            if s:
                s["ok"] = bool(s["h1"] > 0 and s["h2"] > 0 and s["pf"] > 1.1)
                rows.append({"inst": name, "kind": "акция" if name == sym else "индекс/сырьё", "strategy": st, **s})
                pk.append({"name": st, **s})
        pk.sort(key=lambda r: (-r["ok"], -r["pf"])); pick[name] = pk
        best = next((r for r in pk if r["ok"]), None)
        print(f"[{k}/{len(syms)}] {name}: лучшая {best['name'] + ' PF ' + str(best['pf']) if best else '—'}", flush=True)
        time.sleep(0.3)
    d = pd.DataFrame(rows); d.to_csv(BASE / "stocks_test.csv", index=False, encoding="utf-8-sig")
    json.dump({"generated": time.strftime("%Y-%m-%d"), "period": "дневки, вся история Yahoo", "inst": pick}, open(BASE / "tradfi_pick.json", "w", encoding="utf-8"), ensure_ascii=False)
    L = [f"Тест фондового рынка {time.strftime('%Y-%m-%d %H:%M')}: инструментов {d.inst.nunique()}", "",
         "стратегия                         | где          | инстр | в плюсе | ✅обе пол. | R/сд  | PF  | сделок | посл.2 года"]
    for (st, kind), g in d.groupby(["strategy", "kind"]):
        n = g.n.sum(); rpt = (g.rpt * g.n).sum() / n
        L.append(f"{st:33s} | {kind:12s} | {len(g):5d} | {int((g['sum'] > 0).sum()):3d} ({(g['sum'] > 0).mean() * 100:3.0f}%) | {int(g.ok.sum()):4d} | "
                 f"{rpt:+.3f} | {g.pf.median():.2f} | {n:6d} | {g.y2.sum():+.0f}R")
    (BASE / "stocks_test_summary.txt").write_text("\n".join(L), encoding="utf-8")
    print("\n".join(L))
    print("\nГотово: stocks_test_summary.txt, stocks_test.csv, tradfi_pick.json")


if __name__ == "__main__":
    main()
