"""save_demo_key.py — 2026-10-25. Сохраняет ключ ДЕМО-счёта Bybit в отдельный слот «bybit_demo» (trade_keys.json).
Реальные боты этот слот не читают никогда. Ввод не отображается и не печатается."""
import getpass, sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
from app.config import TRADE_KEYS_FILE  # noqa: E402
from app.trade_keys_store import TradeKeysStore  # noqa: E402

print("Ключ ДЕМО-торговли Bybit (создан в режиме «Демо трейдинг»). Ввод не отображается.")
k = getpass.getpass("API Key (демо): ").strip(); s = getpass.getpass("API Secret (демо): ").strip()
if not k or not s:
    print("Пусто — ничего не сохранено."); sys.exit(1)
TradeKeysStore(TRADE_KEYS_FILE).set_key_for_strategy("bybit_demo", "bybit", k, s)
print("Сохранено в слот bybit_demo. Реальные ключи не изменены.")
