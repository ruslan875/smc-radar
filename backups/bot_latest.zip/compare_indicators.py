#!/usr/bin/env python3
"""
Runs every ported indicator in app/indicators/ across the whole watchlist
and prints a single ranked comparison table -- net R (after each of the
three fee scenarios) and win rate, same methodology as backtest.py /
generic_backtest.py, so this indicator collection can be compared
apples-to-apples against each other AND against the SMC bot's own numbers
(see the "smc-bot-backtest" doc in the Claude project for those).

Needs network access to Bybit -- run this on your own machine:

    python compare_indicators.py
    python compare_indicators.py --symbol ETHUSDT SOLUSDT --bars 3000
    python compare_indicators.py --indicators quantum_scalper sr_range_module ml_lorentzian
    python compare_indicators.py --out comparison_report.md

Note: sr_range_module needs --bars comfortably above 2000 to ever fire
(see its docstring) -- if you want it included in a fair comparison, run
with --bars 3000+ for everything, which will also just take longer.
"""
from __future__ import annotations

import argparse
import importlib
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from app.config import Settings
from app.data import DataError
from generic_backtest import FEE_SCENARIOS, list_indicators, net_r, save_csv


def fetch_all(symbols: list[str], timeframe: str, bars: int) -> dict:
    """Fetch each symbol's history exactly ONCE and reuse it for every
    indicator -- the naive per-(indicator, symbol) fetch this used to do
    meant 33 indicators x 5 symbols = 165 network round-trips for data
    that's identical across all 33 runs. This cuts it down to 5."""
    from generic_backtest import fetch_history as _fetch
    dfs = {}
    for symbol in symbols:
        print(f"Fetching {symbol} ({bars} bars of {timeframe})...")
        try:
            dfs[symbol] = _fetch(symbol, timeframe, bars)
        except DataError as exc:
            print(f"  [SKIP] {symbol}: {exc}")
    return dfs


def run_one(indicator: str, dfs: dict, max_forward: int) -> list[dict]:
    module = importlib.import_module(f"app.indicators.{indicator}")
    all_trades: list[dict] = []
    from generic_backtest import simulate_outcome
    for symbol, df in dfs.items():
        try:
            signals = module.generate_signals(df)
        except Exception as exc:  # noqa: BLE001 -- keep the sweep going even if one module misbehaves
            print(f"  [ERROR] {indicator} raised on {symbol}: {exc}")
            continue

        for sig in signals:
            outcome = sig.meta.get("resolved_outcome") or simulate_outcome(df, sig, max_forward)
            all_trades.append({
                "symbol": symbol, "label": sig.label, "direction": sig.direction,
                "entry": sig.entry, "stop_loss": sig.stop_loss,
                "synthetic_stop": sig.synthetic_stop, "time": sig.trigger_time,
                **outcome,
            })
    return all_trades


def summarize_row(indicator: str, trades: list[dict]) -> dict:
    resolved = [t for t in trades if t["r"] is not None]
    row = {"indicator": indicator, "setups": len(trades), "resolved": len(resolved)}
    if not resolved:
        for label in FEE_SCENARIOS:
            row[f"net_r_{label}"] = None
            row[f"win_rate_{label}"] = None
        row["gross_avg_r"] = None
        row["gross_win_rate"] = None
        return row

    row["gross_avg_r"] = sum(t["r"] for t in resolved) / len(resolved)
    row["gross_win_rate"] = sum(1 for t in resolved if t["r"] > 0) / len(resolved) * 100

    for label, fee_rate in FEE_SCENARIOS.items():
        net_rs = [r for r in (net_r(t, fee_rate) for t in resolved) if r is not None]
        if net_rs:
            row[f"net_r_{label}"] = sum(net_rs) / len(net_rs)
            row[f"win_rate_{label}"] = sum(1 for r in net_rs if r > 0) / len(net_rs) * 100
        else:
            row[f"net_r_{label}"] = None
            row[f"win_rate_{label}"] = None
    return row


def main() -> None:
    settings = Settings.load()
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--indicators", nargs="+", default=None, help="Subset to run (default: all discovered modules)")
    parser.add_argument("--symbol", nargs="+", default=settings.watchlist)
    parser.add_argument("--timeframe", default=settings.timeframe)
    parser.add_argument("--bars", type=int, default=2000)
    parser.add_argument("--max-forward", type=int, default=200)
    parser.add_argument("--out-dir", default="generic_backtest_out")
    parser.add_argument("--out", default=None, help="Optional markdown file to write the ranked table to")
    args = parser.parse_args()

    indicators = args.indicators or list_indicators()
    symbols = [s.upper() for s in args.symbol]
    rows = []

    dfs = fetch_all(symbols, args.timeframe, args.bars)
    if not dfs:
        print("No symbol data fetched -- nothing to backtest.")
        return

    for indicator in indicators:
        print(f"\n=== {indicator} ({', '.join(dfs.keys())}, {args.bars} bars of {args.timeframe}) ===")
        trades = run_one(indicator, dfs, args.max_forward)
        save_csv(trades, Path(args.out_dir) / indicator / "ALL_SYMBOLS_trades.csv")
        row = summarize_row(indicator, trades)
        rows.append(row)
        taker_taker = row.get("net_r_taker+taker")
        print(f"  setups={row['setups']:4d}  resolved={row['resolved']:4d}  "
              f"gross avg R={row['gross_avg_r']:+.3f}" if row['gross_avg_r'] is not None else "  no resolved trades")
        if taker_taker is not None:
            print(f"  net avg R (taker+taker fees) = {taker_taker:+.3f}  win rate = {row['win_rate_taker+taker']:.1f}%")

    rows.sort(key=lambda r: (r["net_r_taker+taker"] is None, -(r["net_r_taker+taker"] or -999)))

    header = (f"{'indicator':32s} {'setups':>7s} {'resolved':>9s} {'gross R':>9s} "
              f"{'net R (t+t)':>12s} {'net R (t+m)':>12s} {'net R (m+m)':>12s} {'win% (t+t)':>11s}")
    lines = [header, "-" * len(header)]
    for row in rows:
        def fmt(x, pct=False):
            if x is None:
                return "n/a"
            return f"{x:+.1f}%" if pct else f"{x:+.3f}"
        lines.append(
            f"{row['indicator']:32s} {row['setups']:7d} {row['resolved']:9d} "
            f"{fmt(row['gross_avg_r']):>9s} {fmt(row['net_r_taker+taker']):>12s} "
            f"{fmt(row['net_r_taker+maker']):>12s} {fmt(row['net_r_maker+maker']):>12s} "
            f"{fmt(row['win_rate_taker+taker'], pct=True):>11s}"
        )
    table_text = "\n".join(lines)
    print("\n" + "=" * len(header))
    print("RANKED COMPARISON (best net R after taker+taker fees first)")
    print("=" * len(header))
    print(table_text)

    if args.out:
        Path(args.out).write_text(
            "# Indicator comparison\n\n"
            f"Symbols: {', '.join(symbols)} | Timeframe: {args.timeframe} | Bars: {args.bars}\n\n"
            "```\n" + table_text + "\n```\n"
        )
        print(f"\nWritten to {args.out}")


if __name__ == "__main__":
    main()
