#!/usr/bin/env python3
"""Проверка отправки в Telegram ровно тем же путём, что и paper_live.py.

Ничего не меняет. Шлёт одно тестовое сообщение и печатает, что произошло.
Запуск:  .\venv\Scripts\python.exe test_telegram.py
"""
import os
import sys
import time
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))

try:
    from dotenv import load_dotenv
    load_dotenv(BASE_DIR / ".env")
    print("[.env] загружен")
except Exception as exc:
    print(f"[.env] НЕ загружен: {exc}")

token = os.environ.get("TELEGRAM_BOT_TOKEN")
chat = os.environ.get("TELEGRAM_CHAT_ID")
print(f"[токен] {'есть, ...' + token[-6:] if token else 'НЕТ'}")
print(f"[chat_id] {chat if chat else 'НЕТ'}")
if not token or not chat:
    sys.exit("Переменные не заданы — дальше проверять нечего.")

import requests

print("\n=== 1. getMe (проверка самого доступа) ===")
for attempt in (1, 2, 3):
    t0 = time.time()
    try:
        r = requests.get(f"https://api.telegram.org/bot{token}/getMe", timeout=20)
        print(f"  попытка {attempt}: HTTP {r.status_code} за {time.time()-t0:.2f}с"
              f" — бот @{r.json().get('result', {}).get('username', '?')}")
        break
    except Exception as exc:
        print(f"  попытка {attempt}: ПРОВАЛ за {time.time()-t0:.2f}с — {type(exc).__name__}")
        if attempt < 3:
            time.sleep(2)

print("\n=== 2. sendMessage (то, что делает paper_live) ===")
for attempt in (1, 2, 3):
    t0 = time.time()
    try:
        r = requests.post(
            f"https://api.telegram.org/bot{token}/sendMessage",
            data={"chat_id": chat,
                  "text": "Проверка связи от paper_live. Если это видно — отправка работает."},
            timeout=20)
        print(f"  попытка {attempt}: HTTP {r.status_code} за {time.time()-t0:.2f}с")
        if r.status_code == 200:
            print("\n  ОТПРАВЛЕНО. Проверь чат с ботом.")
        else:
            print(f"  ответ: {r.text[:200]}")
        break
    except Exception as exc:
        print(f"  попытка {attempt}: ПРОВАЛ за {time.time()-t0:.2f}с — {type(exc).__name__}: {exc}")
        if attempt < 3:
            time.sleep(2)
