"""Скачать минутки ВСЕХ монет Bybit USDT-perp (с 2020 или с листинга) в склад
market_cache/1m. Монеты идут по убыванию оборота за сутки — самые нужные первыми.
Повторный запуск докачивает только новое. 2026-09-26.

    download_all_candles.bat              # все монеты Bybit
    download_all_candles.bat 50           # только топ-50 по обороту
"""
import sys
import time

import candle_store as CS


def all_coins():
    ex = CS._exchange()
    ex.load_markets()
    tick = ex.fetch_tickers(params={"category": "linear"})
    coins = []
    for m in ex.markets.values():
        if m.get("swap") and m.get("linear") and m.get("quote") == "USDT" and m.get("active", True):
            vol = (tick.get(m["symbol"]) or {}).get("quoteVolume") or 0
            coins.append((vol, m["base"]))
    return [b for _, b in sorted(set(coins), reverse=True)]


if __name__ == "__main__":
    SIGNALS = "--signals" in sys.argv
    sys.argv = [a for a in sys.argv if a != "--signals"]
    coins = all_coins()
    if len(sys.argv) > 1 and sys.argv[1].isdigit():
        coins = coins[: int(sys.argv[1])]
    print(f"Склад: {CS.DIR}  формат {CS._EXT}  монет: {len(coins)} (по обороту, крупные первыми)")
    t0 = time.time()
    for k, sym in enumerate(coins, 1):
        print(f"\n[{k}/{len(coins)}] {sym}")
        try:
            df = CS.update(sym)
            if SIGNALS:
                # заранее считаем сигналы 34 индикаторов для автоподбора (потом подбор — секунды)
                import bt_lab as B, lab_builder as LB
                d2 = df[df.t >= CS.pd.Timestamp("2024-01-01", tz="UTC").timestamp() * 1000].reset_index(drop=True)
                for tf in ("4h", "1h", "15m", "5m"):
                    print(f"  сигналы индикаторов {tf}…", flush=True)
                    LB.engine_signals(B._tf_frame(d2, tf).reset_index(drop=True), sym, tf)
            print(f"  готово: {len(df):,} минуток, {CS.pd.to_datetime(df.t.iloc[0], unit='ms'):%Y-%m-%d} → "
                  f"{CS.pd.to_datetime(df.t.iloc[-1], unit='ms'):%Y-%m-%d %H:%M}")
        except Exception as exc:  # noqa: BLE001
            print(f"  ПРОПУСК {sym}: {exc}")
    print(f"\nВсё. {(time.time() - t0) / 60:.0f} мин.")
