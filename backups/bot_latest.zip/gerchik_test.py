"""gerchik_test.py — 2026-10-05. Модели Александра Герчика на истории — ОДИН ЗАПУСК для крипты и традиционных рынков.
Рынки: 12 криптомонет (склад Binance с 2019; 4h и 1D из 4h) + 16 инструментов Yahoo (4h ~2 года, 1D с 2005).
Уровни: развороты 5/5 свечей (подтверждаются только через 5 свечей — без подглядывания), близкие (< 0.25 ATR) сливаются,
«сильный» уровень = 2+ касания. Тейк 3R (правило Герчика), лимит сделки 60 свечей.
Модели:
  ЛП  — ложный пробой: свеча проколола уровень и закрылась обратно → вход по закрытию против прокола, стоп за хвостом +0.1 ATR.
  ОТБ — отбой: лимит прямо на уровне при подходе сверху/снизу, короткий стоп 0.2 ATR за уровнем.
  ПРБ — пробой после поджатия: 5 свечей жмутся к уровню (< 0.4 ATR), закрытие за уровнем → вход, стоп за мин/макс 3 свечей.
  + «Пробой канала 100» (наша система) для сравнения.
Каждая модель — без фильтра и с ATR-фильтром Герчика (не входить, если за текущие сутки пройдено > 75% среднего дневного хода).
Честно: история делится пополам, рабочая модель — плюс в обеих половинах и на большинстве инструментов. Итог — gerchik_test.csv.
"""
import csv, time
import numpy as np
import pandas as pd

RR, HOLD = 3.0, 60


def prep(d):
    d = d.reset_index(drop=True).copy()
    c, h, l = d.c.values, d.h.values, d.l.values
    pc = np.r_[c[0], c[:-1]]; tr = np.maximum(h - l, np.maximum(abs(h - pc), abs(l - pc)))
    d["atr"] = pd.Series(tr).ewm(alpha=1 / 14, adjust=False).mean().values
    day = (d.t // 86_400_000).astype("int64"); d["day"] = day
    d["dhi"] = d.groupby("day").h.cummax(); d["dlo"] = d.groupby("day").l.cummin()
    rng = d.groupby("day").agg(hi=("h", "max"), lo=("l", "min")); rng["r"] = rng.hi - rng.lo
    datr = rng.r.rolling(14).mean().shift(1)                      # средний дневной ход по прошлым 14 дням
    d["datr"] = day.map(datr).values
    return d


def atr_ok(d, i, side):
    """ATR-фильтр Герчика: за сутки пройдено > 75% среднего дневного хода — в эту сторону не входим."""
    da = d.datr.iat[i]
    if not da or np.isnan(da): return True
    return (d.dhi.iat[i] - d.dlo.iat[i]) <= 0.75 * da


def levels_at(d, W=5):
    """Для каждой свечи — список уровней, известных на тот момент: [(цена, касаний)]."""
    h, l, a = d.h.values, d.l.values, d.atr.values; n = len(d); out = [None] * n; lv = []
    for i in range(n):
        k = i - W                                                  # разворот на k подтверждён к свече i
        if k >= W:
            for p, is_h in ((h[k], True), (l[k], False)):
                ok = all((h[k - j] <= p and h[k + j] <= p) if is_h else (l[k - j] >= p and l[k + j] >= p) for j in range(1, W + 1))
                if ok:
                    for z in lv:
                        if abs(z[0] - p) < 0.25 * a[k]: z[1] += 1; break
                    else:
                        lv.append([p, 1])
            lv = lv[-12:]
        out[i] = [tuple(z) for z in lv]
    return out


def signals(d, model, LV):
    o, h, l, c, a = d.o.values, d.h.values, d.l.values, d.c.values, d.atr.values; S = []
    if model == "КАНАЛ":
        s = pd.Series(c); n = 100; x = pd.Series(np.arange(len(c), dtype=float))
        sx, sy, sxy, sxx, syy = (x.rolling(n).sum(), s.rolling(n).sum(), (x * s).rolling(n).sum(), (x * x).rolling(n).sum(), (s * s).rolling(n).sum())
        b = (n * sxy - sx * sy) / (n * sxx - sx * sx); aa = (sy - b * sx) / n; mid = (aa + b * x).values
        sd = np.sqrt(((syy - 2 * aa * sy - 2 * b * sxy + n * aa * aa + 2 * aa * b * sx + b * b * sxx).clip(lower=0) / n).values)
        for i in range(n + 1, len(c)):
            up, lo, pu, pl = mid[i] + 2 * sd[i], mid[i] - 2 * sd[i], mid[i - 1] + 2 * sd[i - 1], mid[i - 1] - 2 * sd[i - 1]
            if c[i] > up and c[i - 1] <= pu: S.append((i, 1, c[i], mid[i], 2.0, "close"))
            elif c[i] < lo and c[i - 1] >= pl: S.append((i, -1, c[i], mid[i], 2.0, "close"))
        return S
    for i in range(20, len(c)):
        strong = [p for p, t in LV[i] if t >= 2]
        if not strong: continue
        for L in strong:
            if model == "ЛП":
                if l[i] < L < c[i] and o[i] > L: S.append((i, 1, c[i], l[i] - 0.1 * a[i], RR, "close")); break
                if h[i] > L > c[i] and o[i] < L: S.append((i, -1, c[i], h[i] + 0.1 * a[i], RR, "close")); break
            elif model == "ОТБ":
                if c[i] > L + 0.3 * a[i] and l[i] > L: S.append((i, 1, L, L - 0.2 * a[i], RR, "limit")); break
                if c[i] < L - 0.3 * a[i] and h[i] < L: S.append((i, -1, L, L + 0.2 * a[i], RR, "limit")); break
            elif model == "ПРБ" and i >= 6:
                hs, ls = h[i - 5:i], l[i - 5:i]
                if c[i] > L >= hs.max() and L - hs.min() < 0.6 * a[i] and ls[-1] > ls[0]: S.append((i, 1, c[i], l[i - 3:i + 1].min(), RR, "close")); break
                if c[i] < L <= ls.min() and ls.max() - L < 0.6 * a[i] and hs[-1] < hs[0]: S.append((i, -1, c[i], h[i - 3:i + 1].max(), RR, "close")); break
    return S


def sim(d, S, cost, use_atr):
    h, l, c, t = d.h.values, d.l.values, d.c.values, d.t.values; n = len(c); out = []; busy = -1
    for i, side, e, stop, rr, kind in S:
        if i <= busy or (use_atr and not atr_ok(d, i, side)): continue
        risk = abs(e - stop)
        if risk <= 0 or risk / e > 0.15: continue
        tp = e + side * rr * risk; j0 = i
        if kind == "limit":                                       # лимит ждёт касания 10 свечей
            j0 = None
            for j in range(i + 1, min(n, i + 11)):
                if (l[j] <= e) if side > 0 else (h[j] >= e): j0 = j; break
            if j0 is None: continue
            if (l[j0] <= stop) if side > 0 else (h[j0] >= stop):
                out.append((t[j0], -1 - cost * e / risk)); busy = j0; continue
        r = None; k = j0
        for k in range(j0 + 1, min(n, j0 + HOLD + 1)):
            if (l[k] <= stop) if side > 0 else (h[k] >= stop): r = -1.0; break
            if (h[k] >= tp) if side > 0 else (l[k] <= tp): r = rr; break
        if r is None: r = side * (c[k] - e) / risk
        out.append((t[j0], r - cost * e / risk)); busy = k
    return out


def to1d(d):
    g = d.copy(); g["day"] = g.t // 86_400_000
    return g.groupby("day").agg(t=("t", "first"), o=("o", "first"), h=("h", "max"), l=("l", "min"), c=("c", "last"), v=("v", "sum")).reset_index(drop=True)


if __name__ == "__main__":
    import kvoo_longtest as K
    import fx_channel_test as F
    sets = {}
    print("=== Крипта (склад Binance) ===")
    for s in K.COINS:
        d = K.load(s, "4h")
        if d is not None and len(d) > 600:
            sets[("Крипта", "4h", s.replace("USDT", ""))] = d; sets[("Крипта", "1D", s.replace("USDT", ""))] = to1d(d)
    print("=== Традиционные рынки (Yahoo) ===")
    for name, sym in F.SYMS.items():
        print("загрузка", name)
        try:
            sets[("TradFi", "4h", name)] = F.to4h(F.yahoo(sym, "1h", "730d"))
            dd = F.yahoo(sym, "1d", "max"); sets[("TradFi", "1D", name)] = dd[dd.t >= 1104537600000]
        except Exception as exc:  # noqa: BLE001
            print("  пропуск:", exc)
    print("\nсчитаю…")
    prepared = {k: prep(v) for k, v in sets.items() if len(v) > 260}
    LVs = {k: levels_at(v) for k, v in prepared.items()}
    rows = []
    for mkt, cost in (("Крипта", 0.0011), ("TradFi", 0.0003)):
        for tf in ("4h", "1D"):
            for model, mname in (("ЛП", "Ложный пробой"), ("ОТБ", "Отбой от уровня"), ("ПРБ", "Пробой после поджатия"), ("КАНАЛ", "Пробой канала 100 (наш)")):
                for use_atr in (False, True):
                    a = b = 0.0; nt = wins = plus = 0; per = {}
                    for (m2, tf2, name), d in prepared.items():
                        if m2 != mkt or tf2 != tf: continue
                        cut = d.t.iat[len(d) // 2]
                        tr = sim(d, signals(d, model, LVs[(m2, tf2, name)]), cost, use_atr)
                        rs = sum(r for _, r in tr); per[name] = round(rs, 1); plus += rs > 0
                        for tt, r in tr:
                            nt += 1; wins += r > 0
                            if tt < cut: a += r
                            else: b += r
                    ok = "✅" if a > 0 and b > 0 and plus > len(per) / 2 else "  "
                    row = {"рынок": mkt, "tf": tf, "модель": mname, "ATR-фильтр": "да" if use_atr else "нет", "сделок": nt,
                           "WR%": round(100 * wins / max(1, nt), 1), "R_1я": round(a, 1), "R_2я": round(b, 1),
                           "R_на_сделку": round((a + b) / max(1, nt), 3), "в_плюсе": f"{plus}/{len(per)}", "прошла": ok.strip(), **per}
                    rows.append(row)
                    print(f"{ok} {mkt:6} {tf:2} | {mname:24} | ATR {'да ' if use_atr else 'нет'} | сделок {nt:5} WR {row['WR%']:5}% | "
                          f"1-я {a:+7.1f}R | 2-я {b:+7.1f}R | {row['R_на_сделку']:+.3f}R/сд | в плюсе {plus}/{len(per)}")
    keys = list(dict.fromkeys(k for r in rows for k in r))
    with open(F.BASE / "gerchik_test.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=keys, delimiter=";"); w.writeheader(); w.writerows(rows)
    print("\n✅ = плюс в обеих половинах истории и больше чем на половине инструментов.")
    print("Готово. Пришлите скрин или gerchik_test.csv")
    input("Enter — закрыть")
