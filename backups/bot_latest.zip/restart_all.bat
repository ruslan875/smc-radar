@echo off
REM Restarts all three of this project's processes at once, each in its own
REM new window (same as running restart_grid_bot.bat / start_latuserge.bat /
REM start_bot.bat separately, just in one click):
REM   - main.py                        (Telegram control bot, /report, /maxdeals, etc.)
REM   - kc_roc_cci_wt_grid_live.py      (live grid bot)
REM   - long_strategy15_latuserge_live.py (latuserge live bot)
REM
REM SAFETY, read before running -- this mirrors start_latuserge.bat's own
REM rule and does NOT weaken it:
REM   - main.py has no live/paper distinction, always restarts the same way.
REM   - kc_roc_cci_wt_grid_live.py restarts with the SAME flags
REM     restart_grid_bot.bat already uses (--live --max-concurrent-deals 3)
REM     -- this script just calls that file, so if you ever change kc_roc's
REM     flags, edit the ARGS line in restart_grid_bot.bat itself, not here.
REM   - long_strategy15_latuserge_live.py is DIFFERENT ON PURPOSE: plain
REM     "restart_all.bat" (no argument) restarts it in SAFE/paper mode --
REM     ZERO real orders. To restart it live, you must type
REM     "restart_all.bat --live" yourself, same as start_latuserge.bat's own
REM     "type --live every time" rule -- this script does not remove that
REM     last safety check, it only saves you re-typing the OTHER two bots.
REM     Currently running live with --capital-per-deal 300 -- that value is
REM     reused below only when you pass --live; edit LATUSERGE_ARGS if you
REM     want a different --capital-per-deal.

cd /d "%~dp0"

set LATUSERGE_ARGS=--capital-per-deal 300 %*

if not exist "venv\Scripts\python.exe" (
    echo venv not found next to this file. Run the setup steps from the
    echo instructions first ^(python -m venv venv, pip install -r requirements.txt^).
    pause
    exit /b 1
)

echo === Stopping any running main.py / kc_roc_cci_wt_grid_live.py / long_strategy15_latuserge_live.py ===
REM 2026-09-13: killer perepisan. BYLO: Stop-Process -Force po odnomu
REM processu s -ErrorAction SilentlyContinue. Tri problemy srazu:
REM   1) bilo odin process, a ne derevo -- ubityy cmd.exe ostavlyal
REM      python-detey sirotami;
REM   2) lyuboy otkaz glushilsya, i skript molcha shel zapuskat novuyu
REM      kopiyu poverh vyzhivshey;
REM   3) rezultat ne proveryalsya voobshche.
REM Tak kopiya latuserge ot 19:38 perezhila dva perezapuska i dozhila do
REM 23:00 -- tri kopii odnoy strategii odnovremenno.
REM STALO: taskkill /T /F (derevom), do 5 prohodov, proverka rezultata i
REM OTKAZ zapuskat novoe, esli chto-to vyzhilo. Luchshe ne zapustit
REM vovse, chem zapustit vtoruyu kopiyu.
REM Vnutri "..." cmd NE trebuet ekranirovat | & > -- poetomu ih tut net.
powershell -NoProfile -Command "$ErrorActionPreference='Continue'; $pat='main\.py|kc_roc_cci_wt_grid_live\.py|long_strategy15_latuserge_live\.py'; for($i=1;$i -le 5;$i++){ $ps=@(Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match $pat }); if($ps.Count -eq 0){ break }; Write-Host ('  prohod ' + $i + ': processov ' + $ps.Count); foreach($p in $ps){ & taskkill /PID $p.ProcessId /T /F *>$null }; Start-Sleep -Seconds 2 }; $left=@(Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match $pat }); if($left.Count -gt 0){ Write-Host ('  !!! VYZHILO PROCESSOV: ' + $left.Count); exit 1 } else { Write-Host '  vse ostanovleny' }"

if errorlevel 1 (
    echo.
    echo Ostanovka ne udalas -- novye kopii NE zapuskayu, chtoby ne poluchit dubli.
    echo Zakroy okna botov vruchnuyu i zapusti etot fail snova.
    pause
    exit /b 1
)

REM give Bybit / Telegram / the OS a moment to release old connections
timeout /t 2 /nobreak >nul

REM 2026-09-26: zaodno publikuem svezhiy Mini App -- chtoby odna knopka
REM "Boty LIVE" v terminale obnovlyala vsyo, bez ruchnogo publish_mini_app.py.
if exist "publish_mini_app.py" (
    echo === Publishing Mini App ===
    .\venv\Scripts\python.exe publish_mini_app.py
)

echo === Starting main.py ===
.\venv\Scripts\python.exe launch_hidden.py telegram_main main.py

echo === Starting kc_roc_cci_wt_grid_live.py via restart_grid_bot.bat (keeps its own flags in one place) ===
if exist "restart_grid_bot.bat" (
    call restart_grid_bot.bat
) else (
    echo   restart_grid_bot.bat not found -- starting kc_roc_cci_wt_grid_live.py with its own defaults instead.
    .\venv\Scripts\python.exe launch_hidden.py kc_roc_grid_live kc_roc_cci_wt_grid_live.py --live --max-concurrent-deals 3
)

echo === Starting long_strategy15_latuserge_live.py (%LATUSERGE_ARGS%) ===
.\venv\Scripts\python.exe launch_hidden.py latuserge_live long_strategy15_latuserge_live.py %LATUSERGE_ARGS%

echo.
echo Done -- three new windows should now be open: main.py, kc_roc_cci_wt_grid_live, long_strategy15_latuserge_live.
echo (latuserge started WITHOUT --live unless you ran "restart_all.bat --live" -- check its window's own banner to confirm which mode it's in.)
echo This window will close itself in a few seconds.
timeout /t 4 >nul
