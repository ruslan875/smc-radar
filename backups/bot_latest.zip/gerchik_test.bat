@echo off
cd /d %~dp0
if exist venv\Scripts\python.exe (venv\Scripts\python.exe gerchik_test.py) else (python gerchik_test.py)
