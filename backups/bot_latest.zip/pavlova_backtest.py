#!/usr/bin/env python3
"""
Pavlova / Combo(OB+TC+MF) - Python port of Pavlova.pine
========================================================

SOURCE: strategies/Pavlova.pine ("Combo(OB+TC+MF) Strategy", v6, (c) g79029831521)

WHAT IT ACTUALLY IS

The title promises Order Blocks, Trend Catcher and Money Flow. There is no
order-block code anywhere in the file. The entry is a bare three-bar swing:

    long : low > low[1] and low[1] < low[2]     (the middle bar is the low)
    short: high < high[1] and high[1] > high[2]

Everything else in 500 lines is veto. Trend Catcher is EMA(12) rising, Money
Flow is MFI(hlc3, 13) under 78 for longs and over 16 for shorts, and then the
"R4 donor" pack adds ADX, Choppiness, CVD, RSI, normalised Open Interest and a
Z-score spread against a reference asset. Exits are fixed: 1.8% stop, 4.4%
target, from the average entry price.

So it is a swing entry with a heavy filter stack, and the useful question is
how much of any result comes from the swing and how much from the stack.
--no-r4 answers the first half of that; the audit's advice was to look at the
bare system first, and that flag is why.

THE COMMISSION BUG THIS PORT FIXES

    commission_type = strategy.commission.cash_per_order, commission_value = 0.05

That is five CENTS per order, not 0.05 percent. On a position sized at 100% of
equity against Bybit's 0.055% per side, the backtest was understating costs by
one to two orders of magnitude - and this strategy takes a 4.4% target against
a 1.8% stop, so cost per round trip is not a rounding error. Costs here come
from --commission and --slippage-pct like every other port.

TWO FILTERS THAT CANNOT BE REPRODUCED EXACTLY, AND WHAT HAPPENS INSTEAD

* NORMALISED OPEN INTEREST. The Pine requests `{TICKER}_OI` with
  ignore_invalid_symbol=true, so when OI is missing the value is na and the
  filter silently passes - meaning the same script behaves differently on two
  symbols for a reason that never appears in the report. No OI feed is wired
  in here, so nOI passes always, exactly as it does on any symbol TradingView
  has no OI for. The script prints this rather than leaving it implied.

* THE Z-SCORE SPREAD. The reference is hardcoded to COINBASE:BTCUSD. This port
  uses BTC/USDT from the same exchange and market as the symbol under test
  (--z-ref to change, --no-z to switch the filter off). Spot BTC on Coinbase
  and BTC perp on Bybit are not the same series, but their 120-bar z-scores
  track closely enough that a -2.55 / +2.5 threshold sees the same things.
  When the tested symbol IS the reference, the spread is identically zero and
  the filter passes, which is also what the Pine does.

ENTRY TIMING

`process_orders_on_close = true` with `entry_on_close = true`: entries fill at
the SIGNAL BAR'S CLOSE. Live, they would fill at the next bar's open. That gap
flatters a backtest, so --entry-next-open runs it the realistic way and the
difference between the two is worth more than either number alone.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

import pine_ta as ta
from port_common import (deals_frame, load_from_ccxt, load_sources, net_pnl_pct,
                         print_summary, write_manifest)

DEFAULTS = {
    "tc_length": 12,
    "mf_length": 13, "mf_overbought": 78.0, "mf_oversold": 16.0,
    "adx_len_long": 14, "adx_len_short": 14,
    "adx_min_long": 20.0, "adx_max_long": 60.0,
    "adx_min_short": 11.0, "adx_max_short": 45.0,
    "chop_length": 14, "chop_avg_length": 4,
    "chop_long_max": 57.0, "chop_short_max": 58.3,
    "cvd_len": 150, "cvd_smooth": 20,
    "cvd_long_min": 3.0, "cvd_long_max": 84.0,
    "cvd_short_min": 3.0, "cvd_short_max": 100.0,
    "rsi_length": 15,
    "rsi_long_min": 47.0, "rsi_long_max": 73.0,
    "rsi_short_min": 17.0, "rsi_short_max": 47.0,
    "z_len": 120, "z_long_min": -2.55, "z_short_max": 2.5,
    "sl_pct": 1.8, "tp_pct": 4.4,
}


def _pass_block_range(enabled: bool, value: pd.Series, lo: float, hi: float) -> pd.Series:
    """r4_pass_block_range: block only when the value EXISTS and is out of range."""
    if not enabled:
        return pd.Series(True, index=value.index)
    ok = ~((value > hi) | (value < lo))
    return ok.where(value.notna(), True)


def compute_signals(df: pd.DataFrame, cfg: dict, use_tc: bool, use_mf: bool,
                    use_r4: bool, z_ref: pd.Series | None) -> pd.DataFrame:
    out = df.copy()
    close, open_, high, low = out["close"], out["open"], out["high"], out["low"]
    hlc3 = (high + low + close) / 3.0
    hl2 = (high + low) / 2.0

    # --- the entry itself -------------------------------------------------
    out["bullish_swing"] = (low > low.shift(1)) & (low.shift(1) < low.shift(2))
    out["bearish_swing"] = (high < high.shift(1)) & (high.shift(1) > high.shift(2))

    # --- Trend Catcher / Money Flow ---------------------------------------
    ema_tc = ta.ema(close, cfg["tc_length"])
    tc_up = ema_tc > ema_tc.shift(1)
    out["mfi"] = ta.mfi(out, hlc3, cfg["mf_length"])

    tc_long = tc_up if use_tc else pd.Series(True, index=out.index)
    tc_short = (~tc_up) if use_tc else pd.Series(True, index=out.index)
    mf_long = (out["mfi"] < cfg["mf_overbought"]) if use_mf else pd.Series(True, index=out.index)
    mf_short = (out["mfi"] > cfg["mf_oversold"]) if use_mf else pd.Series(True, index=out.index)

    # --- R4 pack -----------------------------------------------------------
    if use_r4:
        adx_l = ta.adx(out, cfg["adx_len_long"])
        adx_s = ta.adx(out, cfg["adx_len_short"])
        adx_long = (adx_l >= cfg["adx_min_long"]) & (adx_l <= cfg["adx_max_long"])
        adx_short = (adx_s >= cfg["adx_min_short"]) & (adx_s <= cfg["adx_max_short"])
        adx_long = adx_long.where(adx_l.notna(), False)
        adx_short = adx_short.where(adx_s.notna(), False)

        chop = ta.choppiness(out, cfg["chop_length"])
        chop_f = ta.sma(chop, cfg["chop_avg_length"])
        chop_long = (chop_f < cfg["chop_long_max"]).where(chop_f.notna(), False)
        chop_short = (chop_f < cfg["chop_short_max"]).where(chop_f.notna(), False)

        delta = np.where(close > open_, out["volume"],
                         np.where(close < open_, -out["volume"], 0.0))
        cvd_cum = ta.cum(pd.Series(delta, index=out.index))
        cvd_roll = cvd_cum - cvd_cum.shift(cfg["cvd_len"]).fillna(0.0)
        cvd_sm = ta.ema(cvd_roll, cfg["cvd_smooth"])
        abs_max = pd.concat([ta.highest(cvd_sm, cfg["cvd_len"]).abs(),
                             ta.lowest(cvd_sm, cfg["cvd_len"]).abs()], axis=1).max(axis=1)
        cvd_norm = (cvd_sm / abs_max).where(abs_max != 0, 0.0)
        out["cvd_pct"] = (cvd_norm + 1.0) * 50.0

        out["rsi"] = ta.rsi(close, cfg["rsi_length"])

        flow_long = (_pass_block_range(True, out["cvd_pct"], cfg["cvd_long_min"], cfg["cvd_long_max"])
                     & _pass_block_range(True, out["rsi"], cfg["rsi_long_min"], cfg["rsi_long_max"]))
        flow_short = (_pass_block_range(True, out["cvd_pct"], cfg["cvd_short_min"], cfg["cvd_short_max"])
                      & _pass_block_range(True, out["rsi"], cfg["rsi_short_min"], cfg["rsi_short_max"]))
        # nOI: no Open Interest feed -> na -> passes, exactly as in the Pine

        if z_ref is not None:
            z_self = ta.zscore(hl2, cfg["z_len"])
            z_other = ta.zscore(z_ref.reindex(out.index), cfg["z_len"])
            z_delta = z_self - z_other
            out["z_delta"] = z_delta
            z_long = (z_delta > cfg["z_long_min"]).where(z_delta.notna(), True)
            z_short = (z_delta < cfg["z_short_max"]).where(z_delta.notna(), True)
        else:
            z_long = pd.Series(True, index=out.index)
            z_short = pd.Series(True, index=out.index)

        r4_long = adx_long & chop_long & flow_long & z_long
        r4_short = adx_short & chop_short & flow_short & z_short
    else:
        r4_long = pd.Series(True, index=out.index)
        r4_short = pd.Series(True, index=out.index)

    out["long_signal"] = (out["bullish_swing"] & tc_long & mf_long & r4_long).fillna(False)
    out["short_signal"] = (out["bearish_swing"] & tc_short & mf_short & r4_short).fillna(False)
    return out


def run_backtest(df: pd.DataFrame, cfg: dict, commission_pct: float,
                 slippage_pct: float, entry_next_open: bool) -> pd.DataFrame:
    deals, pos, pending = [], None, None
    idx = df.index
    o, h, l, c = (df[k].to_numpy(dtype=float) for k in ("open", "high", "low", "close"))
    ls = df["long_signal"].to_numpy(dtype=bool)
    ss = df["short_signal"].to_numpy(dtype=bool)

    def close_pos(price, ts, reason):
        nonlocal pos
        deals.append({
            "entry_time": pos["entry_time"], "exit_time": ts, "side": pos["side"],
            "entry_price": pos["entry_price"], "exit_price": price,
            "gross_pnl_pct": net_pnl_pct(pos["side"], pos["entry_price"], price,
                                         commission_pct, slippage_pct),
            "reason": reason})
        pos = None

    def open_pos(side, price, ts):
        nonlocal pos
        s, t = cfg["sl_pct"] / 100, cfg["tp_pct"] / 100
        pos = {"side": side, "entry_time": ts, "entry_price": price,
               "stop": price * (1 - s) if side == "long" else price * (1 + s),
               "target": price * (1 + t) if side == "long" else price * (1 - t)}

    for i in range(len(df)):
        ts = idx[i]

        if pending is not None and pos is None:
            open_pos(pending, o[i], ts)
            pending = None

        if pos is not None:
            # the exit order is placed on the entry bar and lives from the next
            if ts != pos["entry_time"]:
                if pos["side"] == "long":
                    if l[i] <= pos["stop"]:
                        close_pos(pos["stop"], ts, "stop_loss")
                    elif h[i] >= pos["target"]:
                        close_pos(pos["target"], ts, "take_profit")
                else:
                    if h[i] >= pos["stop"]:
                        close_pos(pos["stop"], ts, "stop_loss")
                    elif l[i] <= pos["target"]:
                        close_pos(pos["target"], ts, "take_profit")

        if pos is not None or pending is not None:
            continue

        if ls[i]:
            if entry_next_open:
                pending = "long"
            else:
                open_pos("long", c[i], ts)      # process_orders_on_close
        elif ss[i]:
            if entry_next_open:
                pending = "short"
            else:
                open_pos("short", c[i], ts)

    if pos is not None:
        close_pos(c[-1], idx[-1], "end_of_data")
    return deals_frame(deals)


def main():
    p = argparse.ArgumentParser(description="Pavlova / Combo(OB+TC+MF) backtester")
    p.add_argument("--symbol")
    p.add_argument("--symbols", nargs="+")
    p.add_argument("--csv")
    p.add_argument("--exchange", default="bybit")
    p.add_argument("--market", default="swap", choices=["swap", "spot"])
    p.add_argument("--timeframe", default="1h")
    p.add_argument("--start", default="2024-01-01")
    p.add_argument("--end", default="2025-12-31")
    p.add_argument("--out", default="backtest_out_pavlova")
    p.add_argument("--commission", type=float, default=0.055)
    p.add_argument("--slippage-pct", type=float, default=0.0)
    p.add_argument("--sl-pct", type=float, default=DEFAULTS["sl_pct"])
    p.add_argument("--tp-pct", type=float, default=DEFAULTS["tp_pct"])
    p.add_argument("--no-tc", action="store_true", help="drop the Trend Catcher filter")
    p.add_argument("--no-mf", action="store_true", help="drop the Money Flow filter")
    p.add_argument("--no-r4", action="store_true",
                   help="drop the whole R4 pack - leaves the bare three-bar swing")
    p.add_argument("--z-ref", default="BTC/USDT",
                   help="reference asset for the Z-score spread (Pine: COINBASE:BTCUSD)")
    p.add_argument("--no-z", action="store_true", help="drop the Z-score filter")
    p.add_argument("--entry-next-open", action="store_true",
                   help="fill entries at the next bar's open instead of the signal "
                        "bar's close, which is what live trading does")
    args = p.parse_args()

    cfg = dict(DEFAULTS)
    cfg.update(sl_pct=args.sl_pct, tp_pct=args.tp_pct)
    use_r4 = not args.no_r4

    out_dir = Path(args.out)
    write_manifest(out_dir, Path(__file__).stem, args,
                   extra_keys=("sl_pct", "tp_pct", "no_tc", "no_mf", "no_r4",
                               "z_ref", "no_z", "entry_next_open"))

    sources = load_sources(args, p)

    z_ref_series = None
    if use_r4 and not args.no_z and not args.csv:
        try:
            ref = load_from_ccxt(args.z_ref, args.timeframe, args.start, args.end,
                                 args.exchange, args.market)
            z_ref_series = (ref["high"] + ref["low"]) / 2.0
        except Exception as exc:
            print(f"  Z-score reference {args.z_ref} unavailable ({exc}); "
                  f"filter will pass everything")

    print("\n" + "=" * 100)
    print("PAVLOVA / COMBO(OB+TC+MF) - BACKTEST RESULTS")
    active = []
    if not args.no_tc:
        active.append(f"TrendCatcher EMA{cfg['tc_length']}")
    if not args.no_mf:
        active.append(f"MFI{cfg['mf_length']} <{cfg['mf_overbought']}/>{cfg['mf_oversold']}")
    if use_r4:
        active.append("R4: ADX + Choppiness + CVD + RSI"
                      + ("" if args.no_z or z_ref_series is None else f" + Z vs {args.z_ref}"))
    print(f"entry: 3-bar swing | filters: {', '.join(active) if active else 'NONE (bare swing)'}")
    print(f"SL {cfg['sl_pct']}% | TP {cfg['tp_pct']}% | commission {args.commission}%/side | "
          f"slippage {args.slippage_pct}%")
    print("FIXED vs Pine: commission is a PERCENTAGE. The source charges "
          "cash_per_order 0.05, i.e. five cents an order.")
    if use_r4:
        print("nOI filter passes everything: no Open Interest feed is wired in, which is "
              "also what the Pine does whenever OI is missing for a symbol.")
    if not args.entry_next_open:
        print("Entries fill at the SIGNAL BAR'S CLOSE (process_orders_on_close=true). "
              "Live fills are the next bar's open - see --entry-next-open.")
    print("=" * 100)

    for sym, ohlcv in sources.items():
        if len(ohlcv) < cfg["z_len"] + cfg["cvd_len"] + 20:
            print(f"  {sym:14s}: insufficient data ({len(ohlcv)} bars)")
            continue
        df = compute_signals(ohlcv, cfg, not args.no_tc, not args.no_mf, use_r4,
                             None if args.no_z else z_ref_series)
        deals = run_backtest(df, cfg, args.commission, args.slippage_pct,
                             args.entry_next_open)
        deals.to_csv(out_dir / f"{sym.replace('/', '')}_deals.csv", index=False)
        print_summary(sym, deals)

    print("=" * 100)
    print(f"\nDeal logs + _run.json written to: {out_dir}/")


if __name__ == "__main__":
    main()
