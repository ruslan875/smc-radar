#!/usr/bin/env python3
"""
Combo OTM v3.2 - FULL bar-by-bar port (all 23 entry filters + Shadow Trade Lock)
================================================================================
Derived from bot/combo_otm_backtest.py (partial port: 6 filters, no shadow lock,
no equity sizing). This file re-implements the trading part of
strategies/Combo_OTM_v3.2.pine line-for-line in logic:

  * Inputs are parsed DIRECTLY from the Pine source (291 input.* lines):
    config keys are the Pine variable names, defaults are the Pine defaults,
    and a TradingView settings CSV (Name,Value; Name = input title) is applied
    on top by title (load_settings_csv).
  * All 23 quality filters (Trend Catcher, MFI, EMA Direction/Slope, Extreme
    Distance, Late Entry, Impulse, Volume Spike, ATR Extension, RSI, CCI, ADX,
    CVD (candle-volume proxy, exactly as Pine), nOI, Z-Score Delta, NATR,
    Choppiness, Williams %R, RVOL, KER, WaveTrend, Awesome, Bollinger).
  * Entry control: cooldown, loss-streak pause, direction streak, session,
    opposite-signal block, master switch, First Trade.
  * Shadow Trade Lock (Pine lines 679-924, 1015-1086) incl. its feed into
    longStreak/shortStreak, consecutiveLosses, lastLong/ShortLossBar when
    Control State Source = "Real + Shadow Trades", and the
    `not shadowTradeActive and not shadowTradePending` guard on real entries.
  * Broker emulation like TradingView strategy(): orders placed on bar t's
    close fill at bar t+1 open; strategy.exit orders live from the bar after
    the fill; intrabar path = TradingView's rule (open->high->low->close when
    the high is nearer the open, else open->low->high->close); gaps through a
    stop/limit fill at the open; percent_of_equity sizing (qty computed from
    equity / close at order placement), commission % on every fill.

KNOWN APPROXIMATIONS (see results.md):
  * nOI: needs <SYMBOL>_OI open interest - unavailable -> noiPct = na ->
    Pine passes the filter (`na(noiPct) or ...`). This is also what TV does
    when the _OI symbol does not exist (ignore_invalid_symbol=true).
  * Z-Score reference COINBASE:BTCUSD hl2 -> Binance BTCUSDT hl2 (ffilled).
  * RVOL timeframe must equal chart TF (true for "1 час" on 1h data).
  * pivots: strict comparison both sides (Pine tie rule unpublished).
  * If long and short orders are placed on the same bar, the short (placed
    second in Pine) is assumed to win (counted in stats as 'dual_signal').
"""
from __future__ import annotations

import csv
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd

import os as _os
_H = _os.path.dirname(_os.path.abspath(__file__))
PINE_PATH = next((x for x in (_os.path.join(_H, "strategies", "Combo_OTM_v3.2.pine"), "/mnt/user-data/uploads/VANTORIX/bot/strategies/Combo_OTM_v3.2.pine") if _os.path.exists(x)), "")
DATA_DIR = "/mnt/user-data/uploads/VANTORIX/bot/market_cache/binance"

# ============================================================================
# INPUT PARSING  (Pine input titles -> Pine variable names)
# ============================================================================

def _split_top(s: str):
    out, depth, cur, q = [], 0, "", False
    for ch in s:
        if ch == '"':
            q = not q
        if not q:
            if ch in "([":
                depth += 1
            elif ch in ")]":
                depth -= 1
            elif ch == "," and depth == 0:
                out.append(cur.strip()); cur = ""; continue
        cur += ch
    if cur.strip():
        out.append(cur.strip())
    return out


def _norm_title(t: str) -> str:
    return re.sub(r"[\s_]+", " ", t).strip().lower()


def parse_pine_inputs(path=PINE_PATH):
    inputs = {}  # var -> dict(type, default, title)
    for line in open(path, encoding="utf-8"):
        m = re.match(r"^(\w+)\s*=\s*input\.(\w+)\((.*)\)\s*$", line.rstrip())
        if not m:
            continue
        var, typ, args = m.groups()
        parts = _split_top(args)
        default = parts[0]
        title = None
        for p in parts[1:]:
            mm = re.match(r'^(?:title\s*=\s*)?"(.*)"$', p)
            if mm and (p.startswith('"') or p.startswith("title")):
                title = mm.group(1); break
        for p in parts:
            if p.startswith("title="):
                title = p.split("=", 1)[1].strip().strip('"')
        if default.startswith("defval="):
            default = default.split("=", 1)[1]
        inputs[var] = {"type": typ, "default": _conv(typ, default), "title": title}
    return inputs


def _conv(typ, v):
    v = v.strip()
    if typ == "bool":
        return str(v).lower() == "true"
    if typ == "int":
        return int(float(v))
    if typ == "float":
        return float(v)
    if typ in ("string", "symbol", "timeframe"):
        return v.strip('"')
    if typ == "source":
        return v
    if typ == "time":
        m = re.search(r'"([^"]+)"', v)
        return pd.Timestamp(m.group(1)) if m else v
    return v


SOURCE_RU = {
    "цена закрытия": "close", "цена открытия": "open", "макс.": "high", "мин.": "low",
    "максимум": "high", "минимум": "low",
    "(макс+мин)/2": "hl2", "(макс+мин+закр)/3": "hlc3",
    "(откр+макс+мин+закр)/4": "ohlc4", "(макс+мин+закр+закр)/4": "hlcc4",
    "close": "close", "open": "open", "high": "high", "low": "low",
    "hl2": "hl2", "hlc3": "hlc3", "ohlc4": "ohlc4", "hlcc4": "hlcc4",
}
TF_RU = {"1 час": "60", "2 часа": "120", "4 часа": "240", "1 день": "1D", "15 минут": "15",
         "30 минут": "30", "5 минут": "5", "1 минута": "1"}
# CSV titles exported in TV's localized form that differ from the Pine titles
TITLE_ALIAS = {"данные для rsi": "rsiSrc", "длина rsi": "rsiLen", "данные": "zSrc"}

INPUTS = parse_pine_inputs()


def default_config():
    return {k: v["default"] for k, v in INPUTS.items()}


def load_settings_csv(path, cfg=None):
    cfg = default_config() if cfg is None else dict(cfg)
    by_title = {}
    for var, meta in INPUTS.items():
        if meta["title"]:
            by_title.setdefault(_norm_title(meta["title"]), var)
    unmatched, applied = [], 0
    with open(path, encoding="utf-8") as f:
        for row in csv.reader(f):
            if not row or row[0] in ("Name", "__indicatorName"):
                continue
            name, val = row[0], row[1]
            key = _norm_title(name)
            var = TITLE_ALIAS.get(key) or by_title.get(key)
            if var is None:
                unmatched.append(name); continue
            typ = INPUTS[var]["type"]
            if typ == "source":
                cfg[var] = SOURCE_RU[val.strip().lower()]
            elif typ == "timeframe":
                cfg[var] = TF_RU.get(val.strip().lower(), val)
            elif typ == "string":
                cfg[var] = val
            else:
                cfg[var] = _conv(typ, val)
            applied += 1
    return cfg, applied, unmatched

# ============================================================================
# PINE TA PRIMITIVES
# ============================================================================

def _seeded_smooth(x, n, alpha):
    x = np.asarray(x, float)
    out = np.full(len(x), np.nan)
    start = None
    for i in range(n - 1, len(x)):
        if not np.isnan(x[i - n + 1:i + 1]).any():
            start = i; break
    if start is None:
        return out
    out[start] = float(np.mean(x[start - n + 1:start + 1]))
    a = alpha
    for i in range(start + 1, len(x)):
        v = x[i]
        out[i] = out[i - 1] if np.isnan(v) else a * v + (1 - a) * out[i - 1]
    return out


def rma(x, n): return _seeded_smooth(x, n, 1.0 / n)
def ema(x, n): return _seeded_smooth(x, n, 2.0 / (n + 1.0))
def sma(x, n): return pd.Series(x).rolling(n).mean().to_numpy()
def ssum(x, n): return pd.Series(x).rolling(n).sum().to_numpy()
def stdev(x, n): return pd.Series(x).rolling(n).std(ddof=0).to_numpy()   # ta.stdev biased
def highest(x, n): return pd.Series(x).rolling(n).max().to_numpy()
def lowest(x, n): return pd.Series(x).rolling(n).min().to_numpy()


def shift(x, k):
    x = np.asarray(x, float)
    if k == 0:
        return x.copy()
    out = np.full(len(x), np.nan)
    out[k:] = x[:-k]
    return out


def true_range(h, l, c):
    pc = shift(c, 1)
    tr = np.maximum(h - l, np.maximum(np.abs(h - pc), np.abs(l - pc)))
    tr[0] = h[0] - l[0]
    return tr


def atr(h, l, c, n): return rma(true_range(h, l, c), n)


def rsi(src, n):
    ch = src - shift(src, 1)
    up = rma(np.where(np.isnan(ch), np.nan, np.maximum(ch, 0.0)), n)
    dn = rma(np.where(np.isnan(ch), np.nan, np.maximum(-ch, 0.0)), n)
    with np.errstate(divide="ignore", invalid="ignore"):
        r = 100.0 - 100.0 / (1.0 + up / dn)
    r = np.where(dn == 0, 100.0, r)
    r = np.where(up == 0, 0.0, r)
    return np.where(np.isnan(up) | np.isnan(dn), np.nan, r)


def cci(src, n):
    s = pd.Series(src)
    ma = s.rolling(n).mean()
    md = s.rolling(n).apply(lambda w: np.abs(w - w.mean()).mean(), raw=True)
    with np.errstate(divide="ignore", invalid="ignore"):
        return ((s - ma) / (0.015 * md)).to_numpy()


def mfi(src, vol, n):
    ch = src - shift(src, 1)
    # Pine: upper = sum(volume * (change <= 0 ? 0 : src)); na change -> src
    upper = ssum(vol * np.where(ch <= 0.0, 0.0, src), n)
    lower = ssum(vol * np.where(ch >= 0.0, 0.0, src), n)
    with np.errstate(divide="ignore", invalid="ignore"):
        return 100.0 - 100.0 / (1.0 + upper / lower)


def calc_adx(h, l, c, n):
    up = h - shift(h, 1)
    dn = shift(l, 1) - l
    pdm = np.where((up > dn) & (up > 0), up, 0.0)
    mdm = np.where((dn > up) & (dn > 0), dn, 0.0)
    tr = np.maximum(np.maximum(h - l, np.abs(h - shift(c, 1))), np.abs(l - shift(c, 1)))
    trs, ps, ms = rma(tr, n), rma(pdm, n), rma(mdm, n)
    with np.errstate(divide="ignore", invalid="ignore"):
        pdi = 100 * ps / trs
        mdi = 100 * ms / trs
        dx = 100 * np.abs(pdi - mdi) / (pdi + mdi)
    return rma(dx, n)


def pivots(high, low, left, right):
    n = len(high)
    ph = np.zeros(n, bool); pl = np.zeros(n, bool)
    for p in range(left, n - right):
        hv, lv = high[p], low[p]
        win_h = np.concatenate([high[p - left:p], high[p + 1:p + right + 1]])
        win_l = np.concatenate([low[p - left:p], low[p + 1:p + right + 1]])
        ph[p] = (win_h < hv).all()
        pl[p] = (win_l > lv).all()
    vis_h = np.zeros(n, bool); vis_l = np.zeros(n, bool)
    vis_h[right:] = ph[:n - right]; vis_l[right:] = pl[:n - right]
    # pivot value visible at bar t is high/low of bar t-right
    val_h = np.where(vis_h, shift(high, right), np.nan)
    val_l = np.where(vis_l, shift(low, right), np.nan)
    return val_h, val_l

# ============================================================================
# FILTER CONDITIONS (Pine lines 512-631, 926-1013)
# ============================================================================

def source(df, name):
    o, h, l, c = (df[k].to_numpy(float) for k in ("open", "high", "low", "close"))
    return {"close": c, "open": o, "high": h, "low": l, "hl2": (h + l) / 2,
            "hlc3": (h + l + c) / 3, "ohlc4": (o + h + l + c) / 4, "hlcc4": (h + l + 2 * c) / 4}[name]


def compute_conditions(df, cfg, ref_df=None):
    P = cfg
    o, h, l, c, v = (df[k].to_numpy(float) for k in ("open", "high", "low", "close", "volume"))
    n = len(c)
    g = lambda a: np.nan_to_num(a, nan=np.nan)  # noqa
    ge = lambda a, b: np.where(np.isnan(a), False, a >= b)
    le = lambda a, b: np.where(np.isnan(a), False, a <= b)
    gt = lambda a, b: np.where(np.isnan(a), False, a > b)
    lt = lambda a, b: np.where(np.isnan(a), False, a < b)
    T = np.ones(n, bool)
    R = {}

    pvh, pvl = pivots(h, l, P["pivotLeftBars"], P["pivotRightBars"])
    R["pivotHigh"], R["pivotLow"] = pvh, pvl

    # ATR extension
    axl = atr(h, l, c, P["atrExtensionLengthLong"]); axs = atr(h, l, c, P["atrExtensionLengthShort"])
    with np.errstate(invalid="ignore", divide="ignore"):
        extL = np.where(~np.isnan(pvl) & (axl > 0), np.maximum(c - pvl, 0) / axl, np.nan)
        extS = np.where(~np.isnan(pvh) & (axs > 0), np.maximum(pvh - c, 0) / axs, np.nan)

    tcl = ema(c, P["trendCatcherPeriodLong"]); tcs = ema(c, P["trendCatcherPeriodShort"])
    mfL = mfi((h + l + c) / 3, v, P["moneyFlowPeriodLong"]); mfS = mfi((h + l + c) / 3, v, P["moneyFlowPeriodShort"])
    edl = ema(c, P["emaDirectionLengthLong"]); eds = ema(c, P["emaDirectionLengthShort"])
    esl = ema(c, P["emaSlopeLengthLong"]); ess = ema(c, P["emaSlopeLengthShort"])
    eslb = shift(esl, P["emaSlopeLookbackLong"]); essb = shift(ess, P["emaSlopeLookbackShort"])
    with np.errstate(invalid="ignore", divide="ignore"):
        espL = np.where(~np.isnan(eslb) & (eslb != 0), (esl - eslb) / eslb * 100, np.nan)
        espS = np.where(~np.isnan(essb) & (essb != 0), (ess - essb) / essb * 100, np.nan)
    rlow = lowest(l, P["extremeDistanceLookbackLong"]); rhigh = highest(h, P["extremeDistanceLookbackShort"])
    edpL = np.maximum(c - rlow, 0) / c * 100; edpS = np.maximum(rhigh - c, 0) / c * 100
    body = np.abs(c - o)
    leabL = sma(body, P["lateEntryAverageBodyLengthLong"]); leabS = sma(body, P["lateEntryAverageBodyLengthShort"])
    bigBull = (c > o) & gt(body, leabL * P["lateEntryBigBodyMultiplierLong"])
    bigBear = (c < o) & gt(body, leabS * P["lateEntryBigBodyMultiplierShort"])
    leL = ssum(bigBull.astype(float), P["lateEntryLookbackLong"])
    leS = ssum(bigBear.astype(float), P["lateEntryLookbackShort"])
    avgBody = sma(body, 20)
    impL = gt(body, avgBody * P["impulseMultiplierLong"]); impS = gt(body, avgBody * P["impulseMultiplierShort"])
    avgVol = sma(v, 20)
    volL = gt(v, avgVol * P["volMultiplierLong"]); volS = gt(v, avgVol * P["volMultiplierShort"])
    rsiV = rsi(source(df, P["rsiSrc"]), P["rsiLen"])
    cciV = cci(source(df, P["cciSrc"]), P["cciLen"])
    adxL = calc_adx(h, l, c, P["adxLengthLong"]); adxS = calc_adx(h, l, c, P["adxLengthShort"])
    # CVD (candle-volume proxy, verbatim)
    delta = np.where(c > o, v, np.where(c < o, -v, 0.0))
    cum = np.cumsum(delta)
    cumL = shift(cum, P["cvdLen"]); cumL = np.where(np.isnan(cumL), 0.0, cumL)
    roll = cum - cumL
    smoothed = ema(roll, P["cvdSmooth"])
    absMax = np.maximum(np.abs(highest(smoothed, P["cvdLen"])), np.abs(lowest(smoothed, P["cvdLen"])))
    with np.errstate(invalid="ignore", divide="ignore"):
        norm = np.where(absMax != 0, smoothed / absMax, 0.0)
    cvdPct = (norm + 1.0) * 50.0
    # nOI: no open-interest feed -> na -> filter passes
    noiPct = np.full(n, np.nan)
    if "oi" in df.columns and df["oi"].notna().sum() > P["noiLen"]:
        oi = df["oi"].astype(float).to_numpy()
        lo_, hi_ = lowest(oi, P["noiLen"]), highest(oi, P["noiLen"])
        with np.errstate(invalid="ignore", divide="ignore"):
            noiPct = np.where(hi_ - lo_ != 0, (oi - lo_) / (hi_ - lo_) * 100.0, np.nan)
    # Z-Score Delta
    zsrc = source(df, P["zSrc"]); zLen = P["zLen"]; off = P["zOffset"]
    if ref_df is not None:
        r = ref_df.reindex(df.index).ffill()
        comp = source(r, P["zSrc"])
    else:
        comp = np.full(n, np.nan)
    if off >= 0:
        zs_ = shift(zsrc, off); cs_ = comp
    else:
        zs_ = zsrc; cs_ = shift(comp, -off)
    with np.errstate(invalid="ignore", divide="ignore"):
        zd = stdev(zs_, zLen); cd = stdev(cs_, zLen)
        zScore = np.where(zd != 0, (zs_ - sma(zs_, zLen)) / zd, np.nan)
        zRef = np.where(cd != 0, (cs_ - sma(cs_, zLen)) / cd, np.nan)
    zDelta = zScore - zRef
    natr = 100.0 * atr(h, l, c, P["natr_len"]) / c
    # Choppiness
    tr = true_range(h, l, c)
    pc = shift(c, 1)
    chL = P["chopLength"]
    trSum = ssum(tr, chL)
    lowSrc = np.where(l <= pc, l, pc); lowSrc[0] = pc[0]  # Pine: low <= na -> false -> close[1] (na)
    highSrc = np.where(h >= pc, h, pc); highSrc[0] = pc[0]
    cLow = lowest(lowSrc, chL); cHigh = highest(highSrc, chL)
    height = cHigh - cLow
    with np.errstate(invalid="ignore", divide="ignore"):
        chop = np.where((height > 0) & (trSum > 0), 100 * np.log10(trSum / height) / np.log10(chL), np.nan)
    chopF = sma(chop, P["chopAvgLength"]) if P["chopDoAvg"] else chop

    def wpr(n_):
        hh = highest(h, n_); ll = lowest(l, n_); rg = hh - ll
        with np.errstate(invalid="ignore", divide="ignore"):
            return np.where(rg != 0, -100 * (hh - c) / rg, np.nan)
    wprL, wprS = wpr(P["wprLengthLong"]), wpr(P["wprLengthShort"])

    def rvol(n_, tf):
        if tf not in ("60", "", None):
            # 2026-11-07: RVOL со старшего ТФ (например 240) — по ПОСЛЕДНЕЙ ЗАКРЫТОЙ старшей свече (без заглядывания)
            try:
                mins = int(str(tf).rstrip("mM")) if str(tf).rstrip("mM").isdigit() else {"D": 1440, "1D": 1440, "W": 10080}[str(tf).upper()]
                idx = pd.to_datetime(df.index if isinstance(df.index, pd.DatetimeIndex) else df["time"] if "time" in df else df["t"], unit=None if isinstance(df.index, pd.DatetimeIndex) else "ms")
                idx = pd.DatetimeIndex(idx)
                b = idx.floor(f"{mins}min")
                hv = pd.Series(v, index=b).groupby(level=0).sum()
                hav = hv.rolling(int(n_)).mean()
                hr = (hv / hav.replace(0, np.nan)).shift(1)          # закрытая предыдущая старшая свеча
                last_in = (idx + pd.Timedelta(hours=1)) >= (b + pd.Timedelta(minutes=mins))   # бар 1h, закрывающий старшую свечу
                cur = hr.reindex(b).to_numpy()
                full = (hv / hav.replace(0, np.nan)).reindex(b).to_numpy()
                return np.where(last_in, full, cur)                     # на последнем часе старшей свечи она уже закрыта
            except Exception as exc:  # noqa: BLE001
                raise NotImplementedError(f"RVOL timeframe {tf}: {exc}") from exc
        av = sma(v, n_)
        with np.errstate(invalid="ignore", divide="ignore"):
            return np.where(~np.isnan(av) & (av != 0), v / av, np.nan)
    rvL, rvS = rvol(P["rvolLengthLong"], P["rvolTFLong"]), rvol(P["rvolLengthShort"], P["rvolTFShort"])

    def ker(n_):
        d = np.abs(c - shift(c, n_))
        vol_ = ssum(np.abs(c - pc), n_)
        with np.errstate(invalid="ignore", divide="ignore"):
            return np.where(vol_ != 0, d / vol_, 0.0)   # NaN vol_ -> != 0 True -> nan
    kerL, kerS = ker(P["kerLengthLong"]), ker(P["kerLengthShort"])

    # WaveTrend
    ap = (h + l + c) / 3
    esa = ema(ap, P["waveTrendChannelLength"])
    dev = ema(np.abs(ap - esa), P["waveTrendChannelLength"])
    with np.errstate(invalid="ignore", divide="ignore"):
        ci = np.where(dev != 0, (ap - esa) / (0.015 * dev), 0.0)
    ci = np.where(np.isnan(dev), np.nan, ci)
    wtM = ema(ci, P["waveTrendAverageLength"]); wtS = sma(wtM, P["waveTrendSignalLength"])
    # Awesome
    aoV = sma((h + l) / 2, P["awesomeFastLength"]) - sma((h + l) / 2, P["awesomeSlowLength"])
    aoP = shift(aoV, 1); aoPct = aoV / c * 100
    # Bollinger (current-bar variant, as used)
    bsrc = source(df, P["bollingerSource"])

    def boll(n_, m_):
        b = sma(bsrc, n_); d = stdev(bsrc, n_) * m_
        up, lo = b + d, b - d
        with np.errstate(invalid="ignore", divide="ignore"):
            w = np.where(~np.isnan(b) & (b != 0), (up - lo) / np.abs(b) * 100, np.nan)
        return up, lo, w
    bUL, bLL, bWL = boll(P["bollingerLengthLong"], P["bollingerMultiplierLong"])
    bUS, bLS, bWS = boll(P["bollingerLengthShort"], P["bollingerMultiplierShort"])

    C = {}
    C["TrendCatcher"] = (T if not P["useTrendCatcherLong"] else gt(tcl, shift(tcl, 1)),
                         T if not P["useTrendCatcherShort"] else lt(tcs, shift(tcs, 1)))

    def mfc(use, val, mn, mx):
        if not use or (mn <= 0 and mx >= 100):
            return T
        return ge(val, mn) & le(val, mx)
    C["MoneyFlow"] = (mfc(P["useMoneyFlowLong"], mfL, P["moneyFlowLongMinimum"], P["moneyFlowLongMaximum"]),
                      mfc(P["useMoneyFlowShort"], mfS, P["moneyFlowShortMinimum"], P["moneyFlowShortMaximum"]))
    C["EmaDirection"] = (T if not P["emaDirectionActiveLong"] else (c >= edl),
                         T if not P["emaDirectionActiveShort"] else (c <= eds))
    C["EmaSlope"] = (T if not P["emaSlopeActiveLong"] else ge(espL, P["emaSlopeMinimumLong"]),
                     T if not P["emaSlopeActiveShort"] else le(espS, -P["emaSlopeMinimumShort"]))
    C["ExtremeDistance"] = (T if not P["extremeDistanceActiveLong"] else ge(edpL, P["extremeDistanceMinimumLong"]) & le(edpL, P["extremeDistanceMaximumLong"]),
                            T if not P["extremeDistanceActiveShort"] else ge(edpS, P["extremeDistanceMinimumShort"]) & le(edpS, P["extremeDistanceMaximumShort"]))
    C["LateEntry"] = (T if not P["lateEntryFilterActiveLong"] else le(leL, P["lateEntryMaximumBigCandlesLong"]),
                      T if not P["lateEntryFilterActiveShort"] else le(leS, P["lateEntryMaximumBigCandlesShort"]))
    C["Impulse"] = (T if not P["impulseCandleFilterActiveLong"] else impL,
                    T if not P["impulseCandleFilterActiveShort"] else impS)
    C["Volume"] = (T if not P["volumeSpikeFilterActiveLong"] else volL,
                   T if not P["volumeSpikeFilterActiveShort"] else volS)
    C["AtrExtension"] = (T if not P["atrExtensionActiveLong"] else le(extL, P["atrExtensionMaximumLong"]),
                         T if not P["atrExtensionActiveShort"] else le(extS, P["atrExtensionMaximumShort"]))
    C["RSI"] = (T if not P["useRSIFilter"] else le(rsiV, P["rsiL_gt_th"]) & ge(rsiV, P["rsiL_lt_th"]),
                T if not P["useRSIFilter"] else le(rsiV, P["rsiS_gt_th"]) & ge(rsiV, P["rsiS_lt_th"]))
    C["CCI"] = (T if not P["useCCIFilter"] else le(cciV, P["cciL_gt_th"]) & ge(cciV, P["cciL_lt_th"]),
                T if not P["useCCIFilter"] else le(cciV, P["cciS_gt_th"]) & ge(cciV, P["cciS_lt_th"]))
    C["ADX"] = (T if not P["adxFilterActiveLong"] else ge(adxL, P["adxThresholdLong"]) & le(adxL, P["adxThresholdLongMax"]),
                T if not P["adxFilterActiveShort"] else ge(adxS, P["adxThresholdShort"]) & le(adxS, P["adxThresholdShortMax"]))
    C["CVD"] = (T if not P["useCVDFilter"] else le(cvdPct, P["cvdL_gt_th"]) & ge(cvdPct, P["cvdL_lt_th"]),
                T if not P["useCVDFilter"] else le(cvdPct, P["cvdS_gt_th"]) & ge(cvdPct, P["cvdS_lt_th"]))
    na_noi = np.isnan(noiPct)
    C["NOI"] = (T if not P["useNOIFilter"] else na_noi | (le(noiPct, P["noiL_gt_th"]) & ge(noiPct, P["noiL_lt_th"])),
                T if not P["useNOIFilter"] else na_noi | (le(noiPct, P["noiS_gt_th"]) & ge(noiPct, P["noiS_lt_th"])))
    na_z = np.isnan(zDelta)
    C["ZScore"] = (T if not P["z_on"] else na_z | gt(zDelta, P["zLongMax"]),
                   T if not P["z_on"] else na_z | lt(zDelta, P["zShortMin"]))
    C["NATR"] = (T if not P["use_natr_filter"] else ge(natr, P["natr_long_min"]) & le(natr, P["natr_long_max"]),
                 T if not P["use_natr_filter"] else ge(natr, P["natr_short_min"]) & le(natr, P["natr_short_max"]))
    C["Choppiness"] = (T if not P["chopFilterActiveLong"] else lt(chopF, P["chopThresholdLong"]),
                       T if not P["chopFilterActiveShort"] else lt(chopF, P["chopThresholdShort"]))
    C["WPR"] = (T if not P["wprFilterActiveLong"] else ge(wprL, P["wprMinLong"]) & le(wprL, P["wprMaxLong"]),
                T if not P["wprFilterActiveShort"] else ge(wprS, P["wprMinShort"]) & le(wprS, P["wprMaxShort"]))
    C["RVOL"] = (T if not P["rvolFilterActiveLong"] else ge(rvL, P["rvolMinLong"]) & le(rvL, P["rvolMaxLong"]),
                 T if not P["rvolFilterActiveShort"] else ge(rvS, P["rvolMinShort"]) & le(rvS, P["rvolMaxShort"]))

    def kerc(active, mode, k, mn):
        if not active:
            return T
        rising = gt(k, shift(k, 1))
        sel = ge(k, mn) if mode == "Minimum Value" else rising if mode == "Rising Efficiency" else (ge(k, mn) | rising)
        return ~np.isnan(k) & sel
    C["KER"] = (kerc(P["kerActiveLong"], P["kerModeLong"], kerL, P["kerMinimumLong"]),
                kerc(P["kerActiveShort"], P["kerModeShort"], kerS, P["kerMinimumShort"]))

    def wtc(active, mode, side):
        if not active:
            return T
        up, lo = P["waveTrendUpperLevel"], P["waveTrendLowerLevel"]
        pm, ps = shift(wtM, 1), shift(wtS, 1)
        if side == 1:
            veto = ~(ge(wtM, up) & lt(wtM, wtS))
            dirc = gt(wtM, wtS)
            ext = gt(wtM, wtS) & le(pm, ps) & le(wtM, lo)          # ta.crossover
            sel = veto if mode == "Late Entry Veto" else dirc if mode == "Direction Confirmation" else ext
        else:
            veto = ~(le(wtM, lo) & gt(wtM, wtS))
            dirc = lt(wtM, wtS)
            ext = lt(wtM, wtS) & ge(pm, ps) & ge(wtM, up)          # ta.crossunder
            sel = veto if mode == "Late Entry Veto" else dirc if mode == "Direction Confirmation" else ext
        return ~np.isnan(wtM) & ~np.isnan(wtS) & sel
    C["WaveTrend"] = (wtc(P["waveTrendActiveLong"], P["waveTrendModeLong"], 1),
                      wtc(P["waveTrendActiveShort"], P["waveTrendModeShort"], -1))

    def aoc(active, mode, side):
        if not active:
            return T
        mn = P["awesomeMinimumLong"] if side == 1 else P["awesomeMinimumShort"]
        mx = P["awesomeMaximumLong"] if side == 1 else P["awesomeMaximumShort"]
        rng = ge(aoPct, mn) & le(aoPct, mx)
        dirc = gt(aoV, aoP) if side == 1 else lt(aoV, aoP)
        zero = ge(aoV, 0.0) if side == 1 else le(aoV, 0.0)
        return dirc if mode == "Direction" else zero if mode == "Zero Line" else rng if mode == "Range" else (rng & dirc)
    C["Awesome"] = (aoc(P["awesomeActiveLong"], P["awesomeModeLong"], 1),
                    aoc(P["awesomeActiveShort"], P["awesomeModeShort"], -1))

    def bbc(active, up, lo, w, th):
        if not active:
            return T
        wide = ge(w, th)
        outside = ~np.isnan(up) & ~np.isnan(lo) & ((bsrc > up) | (bsrc < lo))
        return wide | outside
    C["Bollinger"] = (bbc(P["bollingerActiveLong"], bUL, bLL, bWL, P["bollingerWidthThresholdLong"]),
                      bbc(P["bollingerActiveShort"], bUS, bLS, bWS, P["bollingerWidthThresholdShort"]))

    shadow_map = {"TrendCatcher": "shadowIncludeTrendCatcher", "MoneyFlow": "shadowIncludeMoneyFlow",
                  "EmaDirection": "shadowIncludeEmaDirection", "EmaSlope": "shadowIncludeEmaSlope",
                  "ExtremeDistance": "shadowIncludeExtremeDistance", "LateEntry": "shadowIncludeLateEntry",
                  "Impulse": "shadowIncludeImpulse", "Volume": "shadowIncludeVolume",
                  "AtrExtension": "shadowIncludeAtrExtension", "RSI": "shadowIncludeRSI", "CCI": "shadowIncludeCCI",
                  "ADX": "shadowIncludeADX", "CVD": "shadowIncludeCVD", "NOI": "shadowIncludeNOI",
                  "ZScore": "shadowIncludeZScore", "NATR": "shadowIncludeNATR",
                  "Choppiness": "shadowIncludeChoppiness", "WPR": "shadowIncludeWPR", "RVOL": "shadowIncludeRVOL",
                  "KER": "shadowIncludeKER", "WaveTrend": "shadowIncludeWaveTrend",
                  "Awesome": "shadowIncludeAwesome", "Bollinger": "shadowIncludeBollinger"}
    qL = T.copy(); qS = T.copy(); sfL = np.zeros(n, bool); sfS = np.zeros(n, bool)
    for k, (a, b) in C.items():
        qL &= a; qS &= b
        if P[shadow_map[k]]:
            sfL |= ~a; sfS |= ~b
    R.update(qualL=qL, qualS=qS, shadowFailL=sfL, shadowFailS=sfS, conds=C,
             atrSlL=atr(h, l, c, P["longAtrLength"]), atrSlS=atr(h, l, c, P["shortAtrLength"]),
             atrTpL=atr(h, l, c, P["longTakeProfitAtrLength"]), atrTpS=atr(h, l, c, P["shortTakeProfitAtrLength"]))
    return R

# ============================================================================
# SESSION
# ============================================================================

DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]


def session_allowed(P, wd, hr):
    def cur(en, s, e):
        return en and (True if (s == e or (s == 0 and e == 24)) else (s <= hr < e) if s < e else hr >= s)

    def prev(en, s, e):
        return en and s > e and hr < e
    d, pd_ = DAYS[wd], DAYS[(wd - 1) % 7]
    g = lambda D: (P[f"sessionTrade{D}"], P[f"session{D}StartHour"], P[f"session{D}EndHour"])
    return cur(*g(d)) or prev(*g(pd_))

# ============================================================================
# ENGINE
# ============================================================================

def run(df, cfg, ref_df=None, start=None, end=None, initial_capital=500.0,
        pct_equity=50.0, commission_pct=0.055):
    P = cfg
    R = compute_conditions(df, cfg, ref_df)
    o, h, l, c = (df[k].to_numpy(float) for k in ("open", "high", "low", "close"))
    idx = df.index
    n = len(c)
    comm = commission_pct / 100.0
    two_tp = P["takeProfitStructure"] == "2 TP"
    tpReqL = P["longTakeProfit2Mode"] == "ATR" or (two_tp and P["longTakeProfit1Mode"] == "ATR")
    tpReqS = P["shortTakeProfit2Mode"] == "ATR" or (two_tp and P["shortTakeProfit1Mode"] == "ATR")
    ts_start = pd.Timestamp(start) if start else idx[0]
    ts_end = pd.Timestamp(end) if end else idx[-1] + pd.Timedelta(hours=1)
    in_win = (idx >= ts_start) & (idx < ts_end)
    wd = idx.weekday.to_numpy(); hr = idx.hour.to_numpy()
    shadow_on = P["shadowLockActive"]
    shadow_ctrl = P["shadowControlStateSource"] == "Real + Shadow Trades"

    # var state
    lastLongLossBar = lastShortLossBar = None
    longStreak = shortStreak = 0
    consecutiveLosses = 0
    lpL = lpS = False; lpStart = None
    activeEntryBar = None; mfe = 0.0; beDone = False
    tp1FilledL = tp1FilledS = False
    accProfit = 0.0; activeId = ""
    stopP = tp1P = tp2P = np.nan
    # shadow
    shPending = False; shPendDir = 0; shPendBar = None
    shActive = False; shDir = 0; shEntry = np.nan; shEntryBar = None
    shSL = shTP1 = shTP2 = np.nan; shTp1Hit = False; shMfe = 0.0; shBE = False
    shMCP = False; shMCPBar = None
    stats = {"shadow_trades": 0, "shadow_wins": 0, "shadow_losses": 0, "dual_signal": 0}

    equity_realized = initial_capital
    pos = None  # dict side(+1/-1), qty, avg, entry_bar, entry_time
    pending_entries = []   # list of (dir, qty)
    pending_close = False
    closed_parts = []      # parts closed during this bar's broker phase: (profit, comment)
    trades = []            # aggregated per position
    eq_curve = np.full(n, np.nan)
    peak = initial_capital; maxdd = 0.0

    def close_part(qty, price, comment, t):
        nonlocal equity_realized
        side = pos["side"]
        gross = (price - pos["avg"]) * qty * side
        fee = qty * pos["avg"] * comm + qty * price * comm
        prof = gross - fee
        equity_realized += prof
        pos["qty"] -= qty
        pos["profit"] += prof
        pos["legs"].append((comment, price, qty))
        closed_parts.append((prof, comment))
        if pos["qty"] <= 1e-12:
            trades.append({"entry_time": pos["entry_time"], "exit_time": idx[t],
                           "side": "long" if side == 1 else "short", "entry": pos["avg"],
                           "exit": price, "profit": pos["profit"], "reason": comment,
                           "ret_pct": pos["profit"] / pos["notional"] * 100})
            return True
        return False

    for t in range(n):
        closed_parts = []
        # ---------------- broker phase ----------------
        if pending_close and pos is not None:
            close_part(pos["qty"], o[t], pos["close_comment"], t)
            pos = None
        pending_close = False
        if pending_entries:
            # last order wins on dual signals (short placed after long in Pine)
            d, qty = pending_entries[-1]
            if len(pending_entries) > 1:
                stats["dual_signal"] += 1
            pending_entries = []
            if pos is None:
                pos = {"side": d, "qty": qty, "orig_qty": qty, "avg": o[t], "entry_bar": t,
                       "entry_time": idx[t], "profit": 0.0, "legs": [], "notional": qty * o[t],
                       "exits_live": False, "tp1_done": False}
        if pos is not None and pos["exits_live"]:
            side = pos["side"]
            sl, lim1, lim2 = pos["sl"], pos["tp1"], pos["tp2"]
            highFirst = abs(o[t] - h[t]) <= abs(o[t] - l[t])
            path = [o[t], h[t], l[t], c[t]] if highFirst else [o[t], l[t], h[t], c[t]]
            done = False
            # check at open (gap) then along segments
            for si in range(len(path)):
                if done:
                    break
                a = path[si - 1] if si > 0 else path[0]
                b = path[si]
                a, b = float(a), float(b)
                lo_, hi_ = min(a, b), max(a, b)
                events = []
                if side == 1:
                    if (si == 0 and b <= sl) or (si > 0 and lo_ <= sl <= hi_ and b <= a):
                        events.append(("SL", b if si == 0 else sl))
                    if two_tp and not pos["tp1_done"] and ((si == 0 and b >= lim1) or (si > 0 and lo_ <= lim1 <= hi_ and b >= a)):
                        events.append(("TP1", b if si == 0 else lim1))
                    if (si == 0 and b >= lim2) or (si > 0 and lo_ <= lim2 <= hi_ and b >= a):
                        events.append(("TP2", b if si == 0 else lim2))
                    if b >= a:
                        events.sort(key=lambda e: e[1])
                else:
                    if (si == 0 and b >= sl) or (si > 0 and lo_ <= sl <= hi_ and b >= a):
                        events.append(("SL", b if si == 0 else sl))
                    if two_tp and not pos["tp1_done"] and ((si == 0 and b <= lim1) or (si > 0 and lo_ <= lim1 <= hi_ and b <= a)):
                        events.append(("TP1", b if si == 0 else lim1))
                    if (si == 0 and b <= lim2) or (si > 0 and lo_ <= lim2 <= hi_ and b <= a):
                        events.append(("TP2", b if si == 0 else lim2))
                    if b >= a:
                        events.sort(key=lambda e: e[1])
                    else:
                        events.sort(key=lambda e: e[1], reverse=True)
                for ev, px in events:
                    sname = "Long" if side == 1 else "Short"
                    if ev == "SL":
                        done = close_part(pos["qty"], px, f"SL {sname}", t); break
                    if ev == "TP1" and not pos["tp1_done"]:
                        pct = P["longTakeProfit1PositionPercent"] if side == 1 else P["shortTakeProfit1PositionPercent"]
                        q1 = pos["orig_qty"] * pct / 100.0
                        pos["tp1_done"] = True
                        done = close_part(min(q1, pos["qty"]), px, f"TP1 {sname}", t)
                        if done:
                            break
                    if ev == "TP2":
                        done = close_part(pos["qty"], px, f"TP2 {sname}", t); break
            if done:
                pos = None
        # mark-to-market / drawdown (intrabar adverse)
        if pos is not None:
            worst = l[t] if pos["side"] == 1 else h[t]
            eq_w = equity_realized + (worst - pos["avg"]) * pos["qty"] * pos["side"]
            eq_c = equity_realized + (c[t] - pos["avg"]) * pos["qty"] * pos["side"]
        else:
            eq_w = eq_c = equity_realized
        if in_win[t]:
            maxdd = max(maxdd, (peak - eq_w) / peak)
            peak = max(peak, eq_c)
        eq_curve[t] = eq_c
        pos_size = 0 if pos is None else pos["side"]

        # ---------------- script phase ----------------
        # 646-671 closed-trade bookkeeping
        if closed_parts:
            for prof, cm in closed_parts:
                accProfit += prof
                if cm == "TP1 Long":
                    tp1FilledL = True
                if cm == "TP1 Short":
                    tp1FilledS = True
            if pos_size == 0 and activeId != "":
                if accProfit < 0.0:
                    consecutiveLosses += 1
                    if P["lossStreakPauseActive"] and consecutiveLosses >= int(P["lossesBeforePause"]):
                        lpL = lpS = True; lpStart = t; consecutiveLosses = 0
                else:
                    consecutiveLosses = 0
                if accProfit < 0.0 and activeId == "Long":
                    lastLongLossBar = t
                if accProfit < 0.0 and activeId == "Short":
                    lastShortLossBar = t
                accProfit = 0.0; activeId = ""
        if P["lossStreakPauseActive"] and lpStart is not None and t > lpStart:
            if lpL and t - lpStart > P["lossPauseBarsLong"]:
                lpL = False
            if lpS and t - lpStart > P["lossPauseBarsShort"]:
                lpS = False

        # 683-731 shadow open
        if shadow_on and shPending and not shActive and pos_size == 0 and t > shPendBar:
            shPending = False; shActive = True; shDir = shPendDir; shPendDir = 0
            shEntry = o[t]; shEntryBar = t; shMfe = 0.0; shTp1Hit = False; shBE = False
            shMCP = False; shMCPBar = None
            shSL, shTP1, shTP2 = levels(P, shDir, shEntry, R, t)
            stats["shadow_trades"] += 1
            if shadow_ctrl:
                if shDir == 1:
                    longStreak += 1; shortStreak = 0
                else:
                    shortStreak += 1; longStreak = 0
        shExit = False; shExitPx = np.nan
        if shadow_on and shActive and shMCP and t > shMCPBar:
            shExit = True; shExitPx = o[t]
        if shadow_on and shActive and not shExit and t > shEntryBar:
            hf = abs(o[t] - h[t]) <= abs(o[t] - l[t])
            if shDir == 1:
                stopHit = l[t] <= shSL; tp2T = h[t] >= shTP2
                if not two_tp:
                    if stopHit and tp2T:
                        shExit = True; shExitPx = shTP2 if hf else shSL
                    elif stopHit:
                        shExit = True; shExitPx = shSL
                    elif tp2T:
                        shExit = True; shExitPx = shTP2
                else:
                    tp1T = h[t] >= shTP1
                    if stopHit and tp2T:
                        if hf:
                            shTp1Hit = True; shExit = True; shExitPx = shTP2
                        else:
                            shExit = True; shExitPx = shSL
                    elif stopHit:
                        if not shTp1Hit and tp1T and hf:
                            shTp1Hit = True
                            if P["progressBreakEvenActiveLong"] and P["progressBreakEvenModeLong"] == "TP1" and not shBE:
                                shSL = max(shSL, shEntry * (1 + P["progressBreakEvenOffsetLong"] / 100)); shBE = True
                            if l[t] <= shSL:
                                shExit = True; shExitPx = shSL
                        else:
                            shExit = True; shExitPx = shSL
                    elif tp2T:
                        shTp1Hit = True; shExit = True; shExitPx = shTP2
                    elif not shTp1Hit and tp1T:
                        shTp1Hit = True
                        if P["progressBreakEvenActiveLong"] and P["progressBreakEvenModeLong"] == "TP1" and not shBE:
                            shSL = max(shSL, shEntry * (1 + P["progressBreakEvenOffsetLong"] / 100)); shBE = True
            else:
                stopHit = h[t] >= shSL; tp2T = l[t] <= shTP2
                if not two_tp:
                    if stopHit and tp2T:
                        shExit = True; shExitPx = shSL if hf else shTP2
                    elif stopHit:
                        shExit = True; shExitPx = shSL
                    elif tp2T:
                        shExit = True; shExitPx = shTP2
                else:
                    tp1T = l[t] <= shTP1
                    if stopHit and tp2T:
                        if hf:
                            shExit = True; shExitPx = shSL
                        else:
                            shTp1Hit = True; shExit = True; shExitPx = shTP2
                    elif stopHit:
                        if not shTp1Hit and tp1T and not hf:
                            shTp1Hit = True
                            if P["progressBreakEvenActiveShort"] and P["progressBreakEvenModeShort"] == "TP1" and not shBE:
                                shSL = min(shSL, shEntry * (1 - P["progressBreakEvenOffsetShort"] / 100)); shBE = True
                            if h[t] >= shSL:
                                shExit = True; shExitPx = shSL
                        else:
                            shExit = True; shExitPx = shSL
                    elif tp2T:
                        shTp1Hit = True; shExit = True; shExitPx = shTP2
                    elif not shTp1Hit and tp1T:
                        shTp1Hit = True
                        if P["progressBreakEvenActiveShort"] and P["progressBreakEvenModeShort"] == "TP1" and not shBE:
                            shSL = min(shSL, shEntry * (1 - P["progressBreakEvenOffsetShort"] / 100)); shBE = True
        if shadow_on and shActive and not shExit and t > shEntryBar:
            bars = t - shEntryBar
            S = "Long" if shDir == 1 else "Short"
            fav = (max(h[t] - shEntry, 0) if shDir == 1 else max(shEntry - l[t], 0)) / shEntry * 100
            adv = (max(shEntry - l[t], 0) if shDir == 1 else max(h[t] - shEntry, 0)) / shEntry * 100
            shMfe = max(shMfe, fav)
            if P[f"progressBreakEvenActive{S}"] and P[f"progressBreakEvenMode{S}"] == "Fixed %" and not shBE and shMfe >= P[f"progressBreakEvenActivation{S}"]:
                bep = shEntry * (1 + shDir * P[f"progressBreakEvenOffset{S}"] / 100)
                shSL = max(shSL, bep) if shDir == 1 else min(shSL, bep); shBE = True
            ef = P[f"earlyFailureActive{S}"] and bars >= P[f"earlyFailureBars{S}"] and shMfe < P[f"earlyFailureMinimumMove{S}"]
            npg = P[f"noProgressStopActive{S}"] and shMfe < P[f"noProgressMaximumFavorable{S}"] and adv >= P[f"noProgressAdverseMove{S}"]
            mb = P[f"maximumBarsWithoutProgressActive{S}"] and bars >= P[f"maximumBarsWithoutProgress{S}"] and shMfe < P[f"requiredProgress{S}"]
            if ef or npg or mb:
                shMCP = True; shMCPBar = t
        if shadow_on and shActive and shExit:
            S = "Long" if shDir == 1 else "Short"
            fl = (shExitPx - shEntry) / shEntry * 100 * shDir
            t1 = (shTP1 - shEntry) / shEntry * 100 * shDir
            w = P[f"{'long' if shDir == 1 else 'short'}TakeProfit1PositionPercent"] / 100
            ret = t1 * w + fl * (1 - w) if (two_tp and shTp1Hit) else fl
            if ret > 0:
                stats["shadow_wins"] += 1
            elif ret < 0:
                stats["shadow_losses"] += 1
            if shadow_ctrl:
                if ret < 0.0:
                    consecutiveLosses += 1
                    if shDir == 1:
                        lastLongLossBar = t
                    else:
                        lastShortLossBar = t
                    if P["lossStreakPauseActive"] and consecutiveLosses >= int(P["lossesBeforePause"]):
                        lpL = lpS = True; lpStart = t; consecutiveLosses = 0
                else:
                    consecutiveLosses = 0
            shActive = False; shDir = 0; shEntry = np.nan; shEntryBar = None
            shSL = shTP1 = shTP2 = np.nan; shTp1Hit = False; shMfe = 0.0; shBE = False
            shMCP = False; shMCPBar = None

        # conditions
        master = P["enableAllEntryFilters"]
        ft_ok = (not P["useFirstTrade"]) or idx[t] >= P["firstTrade"]
        baseL = ft_ok and not np.isnan(R["pivotLow"][t]) and (not tpReqL or not np.isnan(R["atrTpL"][t])) and in_win[t]
        baseS = ft_ok and not np.isnan(R["pivotHigh"][t]) and (not tpReqS or not np.isnan(R["atrTpS"][t])) and in_win[t]
        sess = session_allowed(P, int(wd[t]), int(hr[t]))
        ctrlL = (not master) or ((not P["lossStreakPauseActive"] or not lpL)
                                 and (not P["blockOppositeSignalsWhilePositionOpen"] or pos_size >= 0)
                                 and (not P["cooldownAfterLossActiveLong"] or lastLongLossBar is None or t - lastLongLossBar > P["cooldownBarsAfterLossLong"])
                                 and (not P["useStreakControlLong"] or longStreak < P["maxConsecutiveLong"]) and sess)
        ctrlS = (not master) or ((not P["lossStreakPauseActive"] or not lpS)
                                 and (not P["blockOppositeSignalsWhilePositionOpen"] or pos_size <= 0)
                                 and (not P["cooldownAfterLossActiveShort"] or lastShortLossBar is None or t - lastShortLossBar > P["cooldownBarsAfterLossShort"])
                                 and (not P["useStreakControlShort"] or shortStreak < P["maxConsecutiveShort"]) and sess)
        qL = (not master) or bool(R["qualL"][t])
        qS = (not master) or bool(R["qualS"][t])
        longSig = baseL and ctrlL and qL
        shortSig = baseS and ctrlS and qS
        slotBusy = shActive or shPending
        shCandL = shadow_on and pos_size == 0 and not slotBusy and baseL and ctrlL and not qL and bool(R["shadowFailL"][t])
        shCandS = shadow_on and pos_size == 0 and not slotBusy and baseS and ctrlS and not qS and bool(R["shadowFailS"][t])
        if shCandL:
            shPending = True; shPendDir = 1; shPendBar = t
        elif shCandS:
            shPending = True; shPendDir = -1; shPendBar = t
        eq_now = eq_c
        if longSig and pos_size == 0 and not shActive and not shPending:
            pending_entries.append((1, eq_now * pct_equity / 100 / c[t]))
        if shortSig and pos_size == 0 and not shActive and not shPending:
            pending_entries.append((-1, eq_now * pct_equity / 100 / c[t]))

        # position opened this bar
        if pos is not None and pos["entry_bar"] == t:
            activeEntryBar = t; mfe = 0.0; beDone = False; tp1FilledL = tp1FilledS = False
            accProfit = 0.0
            if pos["side"] == 1:
                activeId = "Long"; longStreak += 1; shortStreak = 0
            else:
                activeId = "Short"; shortStreak += 1; longStreak = 0
            pos["sl"], pos["tp1"], pos["tp2"] = levels(P, pos["side"], pos["avg"], R, t)
        # management
        if pos is not None and activeEntryBar is not None:
            d = pos["side"]; S = "Long" if d == 1 else "Short"; avg = pos["avg"]
            bars = t - activeEntryBar
            fav = (max(h[t] - avg, 0) if d == 1 else max(avg - l[t], 0)) / avg * 100
            adv = (max(avg - l[t], 0) if d == 1 else max(h[t] - avg, 0)) / avg * 100
            mfe = max(mfe, fav)
            tp1f = tp1FilledL if d == 1 else tp1FilledS
            becond = mfe >= P[f"progressBreakEvenActivation{S}"] if P[f"progressBreakEvenMode{S}"] == "Fixed %" else (two_tp and tp1f)
            if P[f"progressBreakEvenActive{S}"] and not beDone and becond:
                bep = avg * (1 + d * P[f"progressBreakEvenOffset{S}"] / 100)
                pos["sl"] = max(pos["sl"], bep) if d == 1 else min(pos["sl"], bep); beDone = True
            cm = None
            if P[f"earlyFailureActive{S}"] and bars >= P[f"earlyFailureBars{S}"] and mfe < P[f"earlyFailureMinimumMove{S}"]:
                cm = "Early Failure"
            if P[f"noProgressStopActive{S}"] and mfe < P[f"noProgressMaximumFavorable{S}"] and adv >= P[f"noProgressAdverseMove{S}"]:
                cm = cm or "No Progress Stop"
            if P[f"maximumBarsWithoutProgressActive{S}"] and bars >= P[f"maximumBarsWithoutProgress{S}"] and mfe < P[f"requiredProgress{S}"]:
                cm = cm or "Maximum Bars Without Progress"
            if cm:
                pending_close = True; pos["close_comment"] = cm
            pos["exits_live"] = True
            if two_tp and tp1f:
                pos["tp1_done"] = True
        if pos is None:
            activeEntryBar = None; mfe = 0.0; beDone = False; tp1FilledL = tp1FilledS = False
        # end of window: flatten
        if pos is not None and t + 1 < n and not in_win[t + 1] and in_win[t]:
            close_part(pos["qty"], c[t], "Window End", t); pos = None
            pending_close = False
        if not in_win[t] and idx[t] >= ts_end:
            pending_entries = []

    stats["open"] = None if pos is None else {"side": pos["side"], "avg": pos["avg"], "qty": pos["qty"], "sl": pos.get("sl"),
                                              "tp1": pos.get("tp1"), "tp2": pos.get("tp2"), "entry_time": pos["entry_time"]}
    stats["pending"] = list(pending_entries) if pending_entries else []
    tr = pd.DataFrame(trades)
    return tr, maxdd, equity_realized, stats


def levels(P, d, avg, R, t):
    S = "long" if d == 1 else "short"
    atrSl = R["atrSlL"][t] if d == 1 else R["atrSlS"][t]
    atrTp = R["atrTpL"][t] if d == 1 else R["atrTpS"][t]
    atrTp = 0.0 if np.isnan(atrTp) else atrTp
    fixed = avg * P[f"{S}StopLossPercent"] / 100
    atrd = min(atrSl * P[f"{S}AtrMultiplier"], avg * P[f"{S}AtrMaxStopPercent"] / 100)
    dist = fixed if P[f"{S}StopLossMode"] == "Fixed %" else atrd
    sl = avg - d * dist
    t1a = min(atrTp * P[f"{S}TakeProfit1AtrMultiplier"], avg * P[f"{S}TakeProfit1AtrMaxPercent"] / 100)
    t2a = min(atrTp * P[f"{S}TakeProfit2AtrMultiplier"], avg * P[f"{S}TakeProfit2AtrMaxPercent"] / 100)
    tp1 = avg * (1 + d * P[f"{S}TakeProfit1Percent"] / 100) if P[f"{S}TakeProfit1Mode"] == "Fixed %" else avg + d * t1a
    tp2 = avg * (1 + d * P[f"{S}TakeProfit2Percent"] / 100) if P[f"{S}TakeProfit2Mode"] == "Fixed %" else avg + d * t2a
    return sl, tp1, tp2


# ============================================================================
# DATA + REPORTING
# ============================================================================

def load(sym):
    d = pd.read_csv(f"{DATA_DIR}/{sym}USDT_1h.csv")
    d.index = pd.to_datetime(d["t"].astype("int64"), unit="ms")
    d = d.rename(columns={"o": "open", "h": "high", "l": "low", "c": "close", "v": "volume"})
    return d[["open", "high", "low", "close", "volume"]].sort_index()[lambda x: ~x.index.duplicated()]


def summarize(tr, maxdd, final, init=500.0):
    if tr is None or len(tr) == 0:
        return dict(net=0.0, dd=maxdd * 100, trades=0, win=0.0, pf=float("nan"))
    w = tr[tr.profit > 0].profit.sum(); ls = -tr[tr.profit < 0].profit.sum()
    return dict(net=(final / init - 1) * 100, dd=maxdd * 100, trades=len(tr),
                win=(tr.profit > 0).mean() * 100, pf=w / ls if ls > 0 else float("inf"))


if __name__ == "__main__":
    cfg = default_config()
    if len(sys.argv) > 1:
        cfg, a, um = load_settings_csv(sys.argv[1])
        print("applied", a, "unmatched", um)
    df = load(sys.argv[2] if len(sys.argv) > 2 else "XRP")
    ref = load("BTC")
    tr, dd, fin, st = run(df, cfg, ref, "2024-01-01", "2026-09-23")
    print(summarize(tr, dd, fin), st)
