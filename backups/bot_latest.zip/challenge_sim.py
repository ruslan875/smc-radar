"""challenge_sim.py — 2026-10-31. Честная симуляция челленджа Hash Hedge нашими сигналами (12 монет, вся история).
Правила (с сайта Hash Hedge, присланы пользователем):
  2-Stage: этап 1 цель +8%, дневной убыток 5%, общая просадка 10%; этап 2 цель +6%, 5% / 8%; ≥5 торговых дней на этап.
  1-Stage: цель +10%, дневной 3%, общая 6%; ≥3 торговых дня (по FAQ; в правилах этапа — 5, берём 5 для надёжности).
  Дневной убыток = Equity сейчас − Balance на начало дня (00:00 UTC+4). Equity включает ПЛАВАЮЩИЙ минус открытых позиций —
  здесь он считается по худшей цене каждой свечи (low для лонга, high для шорта), т.е. строже, чем закрытыми сделками.
  Плечо ≤ 1:5: если сумма позиций превысила бы 5 × Equity — сигнал пропускается.
Стратегии: пробой канала 2h/4h (стоп центр, тейк 2R), Donchian 20 по тренду 4h (3R), Черепахи 4h 40/30 и 2h 55/30 (стоп 2 ATR).
Риск на сделку — % от баланса на старте этапа. Лимит одновременных сделок в одну сторону.
Старт челленджа — каждые 28 дней истории. Пишет bt_lab_bots/challenge_sim.txt"""
from __future__ import annotations

import sys
import time
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import recheck_recent as RR  # noqa: E402

FEE = 0.0011
DAY = 86400_000
TZ = 4 * 3600_000          # сутки Hash Hedge: 00:00 UTC+4


def _atr(d):
    h, l, c = d.h.values, d.l.values, d.c.values
    pc = np.r_[c[0], c[:-1]]
    return pd.Series(np.maximum(h - l, np.maximum(abs(h - pc), abs(l - pc)))).ewm(alpha=1 / 14, adjust=False).mean().values


def _path(d, i, j, s, e, risk):
    """Путь сделки по свечам i+1..j: [(t, худший R на свече, R по закрытию)]."""
    h, l, c, t = d.h.values, d.l.values, d.c.values, d.t.values
    fee = FEE * e / risk
    return [(int(t[k]), s * ((l[k] if s > 0 else h[k]) - e) / risk - fee / 2, s * (c[k] - e) / risk - fee / 2) for k in range(i + 1, j + 1)]


def trades(name, d, sym):
    h, l, c, t = d.h.values, d.l.values, d.c.values, d.t.values
    out = []

    def fixed(sigs, rr, hold):
        nxt = 0
        for i, s, stp in sigs:
            if i < nxt or i >= len(c) - 1:
                continue
            e = c[i]; risk = abs(e - stp)
            if risk <= 0:
                continue
            tp = e + s * rr * risk; res = None
            for j in range(i + 1, min(len(c), i + hold + 1)):
                if (l[j] <= stp) if s > 0 else (h[j] >= stp):
                    res = (j, -1.0); break
                if (h[j] >= tp) if s > 0 else (l[j] <= tp):
                    res = (j, rr); break
            if res is None:
                j = min(len(c) - 1, i + hold); res = (j, s * (c[j] - e) / risk)
            out.append({"sym": sym, "s": s, "t_in": int(t[i]), "t_out": int(t[res[0]]), "R": res[1] - FEE * e / risk,
                        "stop_pct": risk / e, "path": _path(d, i, res[0], s, e, risk)})
            nxt = res[0] + 1

    if name.startswith("chan"):
        mid, sd = RR.rolling_reg(c); up, lo = mid + 2 * sd, mid - 2 * sd
        fixed([(i, 1, mid[i]) if c[i] > up[i] and c[i - 1] <= up[i - 1] else (i, -1, mid[i])
               for i in range(101, len(c)) if (c[i] > up[i] and c[i - 1] <= up[i - 1]) or (c[i] < lo[i] and c[i - 1] >= lo[i - 1])], 2.0, 100)
    elif name == "donch":
        ema = pd.Series(c).ewm(span=200, adjust=False).mean().values
        hh = d.h.rolling(20).max().shift(1).values; ll = d.l.rolling(20).min().shift(1).values
        fixed([(i, 1 if c[i] > hh[i] else -1, (hh[i] + ll[i]) / 2) for i in range(201, len(c))
               if (c[i] > hh[i] and c[i] > ema[i]) or (c[i] < ll[i] and c[i] < ema[i])], 3.0, 300)
    else:   # черепахи
        N, M = (40, 30) if name == "turtle4h" else (55, 30)
        a = _atr(d)
        hN = d.h.rolling(N).max().shift(1).values; lN = d.l.rolling(N).min().shift(1).values
        hM = d.h.rolling(M).max().shift(1).values; lM = d.l.rolling(M).min().shift(1).values
        i = 210
        while i < len(c) - 1:
            s = 1 if c[i] > hN[i] else -1 if c[i] < lN[i] else 0
            if not s or not a[i] > 0:
                i += 1; continue
            e = c[i]; risk = 2 * a[i]; stp = e - s * risk; res = None
            for j in range(i + 1, min(len(c), i + 400)):
                if (l[j] <= stp) if s > 0 else (h[j] >= stp):
                    res = (j, -1.0); break
                if (c[j] < lM[j]) if s > 0 else (c[j] > hM[j]):
                    res = (j, s * (c[j] - e) / risk); break
            if res is None:
                j = min(len(c) - 1, i + 400); res = (j, s * (c[j] - e) / risk)
            out.append({"sym": sym, "s": s, "t_in": int(t[i]), "t_out": int(t[res[0]]), "R": res[1] - FEE * e / risk,
                        "stop_pct": risk / e, "path": _path(d, i, res[0], s, e, risk)})
            i = res[0] + 1
    return out


def stage(trs, times, t0, risk, target, dl, dd, min_days, cap, max_days=730):
    """Один этап. risk/target/dl/dd — % от баланса старта этапа. → ('pass'|'fail'|'open', дней, конец_мс)."""
    import bisect
    bal = 0.0; open_ = []; days = set(); day_bal = {}
    k = bisect.bisect_left([x["t_in"] for x in trs], t0)
    for tm in times[bisect.bisect_left(times, t0):]:
        if tm - t0 > max_days * DAY:
            return "open", None, tm
        dkey = (tm + TZ) // DAY
        if dkey not in day_bal:
            day_bal[dkey] = bal
        eq_worst = bal
        for tr in open_:
            pt = tr["pd"].get(tm)
            if pt:
                tr["_last"] = pt[1]; eq_worst += pt[0] * risk
            else:
                eq_worst += tr["_last"] * risk
        if eq_worst - day_bal[dkey] <= -dl or eq_worst <= -dd:
            return "fail", (tm - t0) / DAY, tm
        keep = []
        for tr in open_:
            if tm >= tr["t_out"]:
                bal += tr["R"] * risk
            else:
                keep.append(tr)
        open_ = keep
        if bal >= target and len(days) >= min_days and not open_:
            return "pass", (tm - t0) / DAY, tm
        while k < len(trs) and trs[k]["t_in"] < tm:
            k += 1
        while k < len(trs) and trs[k]["t_in"] == tm:
            x = trs[k]; k += 1
            if bal >= target and len(days) >= min_days:
                continue
            if sum(1 for tr in open_ if tr["s"] == x["s"]) >= cap:
                continue
            if sum(risk / (tr["stop_pct"] * 100) for tr in open_) + risk / (x["stop_pct"] * 100) > 5 * (1 + bal / 100):
                continue
            x["_last"] = 0.0; open_.append(x); days.add(dkey)
    return "open", None, times[-1]


def main():
    import kvoo_longtest as K  # noqa: PLC0415
    lines = ["Челлендж Hash Hedge по истории 12 монет · плавающий минус учитывается · старт каждые 28 дней",
             "формат: стратегия · лимит в одну сторону · риск → прошли / провалили / не дошли за 2 года · медиана дней"]
    data = {tf: {s: RR.load(s, tf) for s in K.COINS} for tf in ("2h", "4h")}
    STR = {"chan2h": "2h", "chan4h": "4h", "donch": "4h", "turtle4h": "4h", "turtle2h": "2h"}
    pools = {}
    for name, tf in STR.items():
        trs = []
        for s, d in data[tf].items():
            if d is not None and len(d) > 400:
                trs += trades(name, d.reset_index(drop=True), s)
        for x in trs:
            x["pd"] = {p[0]: (p[1], p[2]) for p in x["path"]}
        pools[name] = sorted(trs, key=lambda x: x["t_in"])
        print(f"{name}: {len(trs)} сделок", flush=True)
    pools["chan2h+donch"] = sorted(pools["chan2h"] + pools["donch"], key=lambda x: x["t_in"])
    # 2026-10-31: в документации gitbook (rules/challenge-rules) цель этапа 1 — 5%, на сайте в тарифах — 8%. Считаем оба.
    FMT = {"2-Stage, этап 1 = 5% (gitbook)": [(5, 5, 10, 5), (6, 5, 8, 5)]}
    for fmt, stages in FMT.items():
        lines.append(f"\n=== {fmt} ===")
        for name, trs in pools.items():
            times = sorted({x["t_in"] for x in trs} | {p[0] for x in trs for p in x["path"]})
            t_first = trs[0]["t_in"] + 30 * DAY; t_last = trs[-1]["t_out"] - 400 * DAY
            for cap in (1, 2):
                for risk in (0.5, 1.0):
                    res = []
                    for t0 in range(t_first, t_last, 28 * DAY):
                        tt = t0; total = 0.0; out = "pass"
                        for target, dl, dd, md in stages:
                            r, dd_, tend = stage(trs, times, tt, risk, target, dl, dd, md, cap)
                            if r != "pass":
                                out = r; break
                            total += dd_; tt = tend + 1
                        res.append((out, total if out == "pass" else None))
                    n = len(res); ok = [x[1] for x in res if x[0] == "pass"]; fl = sum(1 for x in res if x[0] == "fail")
                    line = (f"{name:<13} ≤{cap} · риск {risk:<4}% → прошли {len(ok) / n * 100:3.0f}% · провал {fl / n * 100:3.0f}% · "
                            f"не дошли {100 - (len(ok) + fl) / n * 100:3.0f}% · медиана {np.median(ok):.0f} дн" if ok else
                            f"{name:<13} ≤{cap} · риск {risk:<4}% → прошли 0% · провал {fl / n * 100:3.0f}%")
                    print(line, flush=True); lines.append(line)
    (BASE / "bt_lab_bots" / "challenge_sim5.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("готово")


if __name__ == "__main__":
    main()
