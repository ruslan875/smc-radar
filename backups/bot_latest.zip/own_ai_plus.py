"""own_ai_plus.py — 2026-10-28. Дообучение «своего ИИ» на НОВЫХ данных: открытый интерес, фандинг, соотношение лонг/шорт.
Вопрос теста: помогают ли данные деривативов отличать хорошие сигналы пробоя от плохих, если одних индикаторов мало.

Сигналы — те же, что у own_ai.py (ml_filter_test.signals, 12 монет, 4h). Для каждого сигнала добавляются (только прошлое, без заглядывания):
  oi_ch1 / oi_ch6 / oi_ch30 — изменение открытого интереса за 1, 6, 30 свечей 4h (%), со знаком сделки;
  fund_last / fund_3d      — последний фандинг и средний за 3 дня, со знаком сделки (плюс = толпа против нас);
  ls_ratio / ls_ch6        — доля лонгистов-аккаунтов Bybit и её изменение (со знаком сделки).
Две модели (одинаковый бустинг) на ОДНИХ И ТЕХ ЖЕ сигналах: А — только индикаторы, Б — индикаторы + деривативы.
Учатся на ранних 75% сигналов, проверка на свежих 25%. Сравнение: итог «сильных» 30% и «слабых» 30% против всех.
Ничего не меняет в боте: рабочая модель own_ai_model.pkl остаётся прежней. Данные Bybit публичные, кэш bt_lab_out/deriv_*.json.
"""
from __future__ import annotations

import sys
import json
import time
import urllib.request
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
API = "https://api.bybit.com/v5/market"
CACHE = BASE / "bt_lab_out"


def get(url):
    for k in range(4):
        try:
            with urllib.request.urlopen(url, timeout=25) as r:
                return json.loads(r.read().decode())
        except Exception:  # noqa: BLE001
            time.sleep(1.5 * (k + 1))
    return {}


def _paged(sym, kind):
    """OI (4h) и лонг/шорт (4h) — через cursor; фандинг — через endTime."""
    f = CACHE / f"deriv_{kind}_{sym}.json"
    if f.exists() and time.time() - f.stat().st_mtime < 86400:
        return json.loads(f.read_text(encoding="utf-8"))
    out = {}
    if kind == "fund":
        end = int(time.time() * 1000)
        for _ in range(60):
            lst = get(f"{API}/funding/history?category=linear&symbol={sym}&endTime={end}&limit=200").get("result", {}).get("list", [])
            if not lst:
                break
            for x in lst:
                out[int(x["fundingRateTimestamp"])] = float(x["fundingRate"])
            end = int(lst[-1]["fundingRateTimestamp"]) - 1
            if len(lst) < 200:
                break
    else:
        url = (f"{API}/open-interest?category=linear&symbol={sym}&intervalTime=4h&limit=200" if kind == "oi"
               else f"{API}/account-ratio?category=linear&symbol={sym}&period=4h&limit=500")
        cur = ""
        for _ in range(80):
            j = get(url + (f"&cursor={cur}" if cur else "")).get("result", {})
            lst = j.get("list", [])
            if not lst:
                break
            for x in lst:
                if kind == "oi":
                    out[int(x["timestamp"])] = float(x["openInterest"])
                else:
                    out[int(x["timestamp"])] = float(x["buyRatio"])
            cur = j.get("nextPageCursor") or ""
            if not cur:
                break
    CACHE.mkdir(exist_ok=True)
    f.write_text(json.dumps(out), encoding="utf-8")
    return out


def _series(dct):
    if not dct:
        return pd.Series(dtype=float)
    s = pd.Series(dct); s.index = s.index.astype("int64")
    return s.sort_index()


def deriv_feats(sym, t, side):
    """Признаки на момент закрытия сигнальной свечи t (+4ч) — только данные с меткой ≤ этого времени."""
    now = t + 4 * 3600_000
    D = _D[sym]
    x = {}
    oi = D["oi"]; oi = oi[oi.index <= now]
    if len(oi) >= 31:
        v = oi.values
        x["oi_ch1"] = side * (v[-1] / v[-2] - 1) * 100
        x["oi_ch6"] = side * (v[-1] / v[-7] - 1) * 100
        x["oi_ch30"] = side * (v[-1] / v[-31] - 1) * 100
    fu = D["fund"]; fu = fu[fu.index <= now]
    if len(fu) >= 9:
        x["fund_last"] = side * fu.values[-1] * 100
        x["fund_3d"] = side * fu.values[-9:].mean() * 100
    ls = D["ls"]; ls = ls[ls.index <= now]
    if len(ls) >= 7:
        x["ls_ratio"] = side * (ls.values[-1] - 0.5)
        x["ls_ch6"] = side * (ls.values[-1] - ls.values[-7])
    return x


_D: dict = {}
NEW = ["oi_ch1", "oi_ch6", "oi_ch30", "fund_last", "fund_3d", "ls_ratio", "ls_ch6"]


def main():
    import kvoo_longtest as K  # noqa: PLC0415
    import ml_filter_test as M  # noqa: PLC0415
    from sklearn.ensemble import HistGradientBoostingClassifier  # noqa: PLC0415
    rows = []
    for s in K.COINS:
        print(f"{s}: свечи, сигналы, открытый интерес, фандинг, лонг/шорт…")
        d = K.load(s, "4h")
        if d is None or len(d) < 800:
            continue
        _D[s] = {"oi": _series(_paged(s, "oi")), "fund": _series(_paged(s, "fund")), "ls": _series(_paged(s, "ls"))}
        print(f"   OI {len(_D[s]['oi'])} точек, фандинг {len(_D[s]['fund'])}, лонг/шорт {len(_D[s]['ls'])}")
        for r in M.signals(d.reset_index(drop=True), s.replace("USDT", "")):
            r.update(deriv_feats(s, r["t"], r["side"]))
            rows.append(r)
    df = pd.DataFrame(rows).replace([np.inf, -np.inf], np.nan)
    have = df[["oi_ch1", "fund_last"]].notna().all(axis=1)
    sub = df[have].sort_values("t").reset_index(drop=True)
    print(f"\nВсего сигналов {len(df)}, с данными деривативов {len(sub)} "
          f"(с {pd.to_datetime(sub.t.min(), unit='ms'):%Y-%m-%d})")
    if len(sub) < 300:
        print("Слишком мало сигналов с данными деривативов — тест не имеет смысла."); input("Enter"); return
    base_cols = [c for c in df.columns if c not in ("coin", "t", "r") and c not in NEW]
    plus_cols = base_cols + [c for c in NEW if c in sub.columns]
    y = (sub.r > 0).astype(int).values; cut = int(len(sub) * 0.75)
    rt = sub.r.values[cut:]
    out = {}
    for name, cols in (("А · только индикаторы", base_cols), ("Б · индикаторы + деривативы", plus_cols)):
        X = sub[cols].fillna(0).values
        m = HistGradientBoostingClassifier(max_depth=3, learning_rate=0.05, max_iter=200, l2_regularization=1.0,
                                           min_samples_leaf=40, random_state=1).fit(X[:cut], y[:cut])
        p = m.predict_proba(X[cut:])[:, 1]
        q3, q7 = np.quantile(p, 0.3), np.quantile(p, 0.7)
        out[name] = (rt[p >= q7].mean(), rt[p < q3].mean())
        # стабильность: то же по двум половинам проверочного периода
        h = len(rt) // 2
        halves = []
        for a, b in ((0, h), (h, len(rt))):
            pp, rr_ = p[a:b], rt[a:b]
            halves.append(rr_[pp >= np.quantile(pp, 0.7)].mean() - rr_[pp < np.quantile(pp, 0.3)].mean())
        out[name] += tuple(halves)
    allr = rt.mean()
    print(f"\nПроверка на свежих {len(rt)} сигналах (модели их не видели). Все сигналы: {allr:+.3f}R/сд")
    verdict_ok = False
    for name, (s_, w_, h1, h2) in out.items():
        gap = s_ - w_
        print(f"  {name}: «сильные» {s_:+.3f}R, «слабые» {w_:+.3f}R, разница {gap:+.3f}R | по половинам {h1:+.3f} / {h2:+.3f}")
    a, b = out["А · только индикаторы"], out["Б · индикаторы + деривативы"]
    verdict_ok = (b[0] - b[1]) > 0.15 and b[2] > 0 and b[3] > 0 and (b[0] - b[1]) > (a[0] - a[1]) + 0.05
    print("\nВЫВОД: " + ("✅ данные деривативов помогают — модель Б различает сигналы устойчиво; можно ставить её оценку в сигналы (по-прежнему не фильтр)"
                         if verdict_ok else
                         "❌ даже с открытым интересом, фандингом и лонг/шорт модель не отличает хорошие пробои от плохих устойчиво. "
                         "Большая нейросеть на тех же данных не поможет — фильтровать сделки ИИ не стоит."))
    (BASE / "own_ai_plus_report.txt").write_text(json.dumps({k: [round(float(x), 3) for x in v] for k, v in out.items()} |
                                                           {"all": round(float(allr), 3), "test": int(len(rt)), "ok": bool(verdict_ok)},
                                                           ensure_ascii=False, indent=1), encoding="utf-8")
    input("\nEnter — закрыть")


if __name__ == "__main__":
    main()
