#!/usr/bin/env python3
"""
Compare every backtested strategy side by side
===============================================

Written 20.09.2026. Every backtest script in this project ends by printing
"Next: run analyze_external_strategies.py" and its docstring promises the
output is "compatible with analyze_external_strategies.py" - but the file
itself had never been written. This is it.

It reads the shared deal-log schema that third_eye_backtest.py,
gaussian_channel_backtest.py and high_low_cloud_backtest.py all emit:

    <out_dir>/<SYMBOL>_deals.csv
    entry_time, exit_time, side, entry_price, exit_price, gross_pnl_pct, reason

USAGE

    python analyze_external_strategies.py
        scans every backtest_out_* folder next to this file

    python analyze_external_strategies.py --dirs backtest_out_third_eye_perp backtest_out_hlcloud
        only those

    python analyze_external_strategies.py --csv report.csv
        also writes the per-symbol table as CSV

WHAT IT ADDS OVER THE PER-SCRIPT SUMMARIES
------------------------------------------
The individual scripts print trades / avg P&L / win rate / PF. Three things
they do not print are usually the ones that decide whether a strategy is
worth another hour:

  DRAWDOWN. None of the backtest engines models money at all - they average
  percentages. Here the deals are replayed in time order as a compounding
  equity curve and the worst peak-to-trough fall is reported. A strategy
  with a decent average and a 60% drawdown is not tradeable on leverage.

  BREAK-EVEN WIN RATE. From the deals themselves: given this strategy's own
  average win and average loss, what win rate would it need just to reach
  zero? Comparing that with the actual win rate says immediately whether a
  strategy is "slightly off" or structurally broken.

  Note this is computed from REALIZED wins and losses, not from the nominal
  take-profit and stop distances, and the two can differ a lot. Third Eye's
  nominal 6.9% TP against a 1.2% SL implies a 14.8% break-even win rate, but
  its realized average loss is only 0.86% (break-even exits cut many losses
  short) and its realized average win 7.01%, so the real bar is 10.9%. It
  delivered 6.6%. The payoff shape was better than advertised and the
  strategy still lost - which is exactly the kind of thing a nominal-numbers
  estimate hides.

  HOLDING TIME. Average bars/hours in a position. A system whose edge lives
  in 20-minute holds behaves very differently on fees than one holding days.

All figures are net of whatever commission and slippage the backtest was run
with - the deal logs already carry costs inside gross_pnl_pct despite the
column name.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd


REQUIRED_COLS = {"entry_time", "exit_time", "side", "entry_price",
                 "exit_price", "gross_pnl_pct", "reason"}


def load_deals(path: Path) -> pd.DataFrame | None:
    try:
        df = pd.read_csv(path)
    except Exception:
        return None
    if df.empty:
        return df
    if REQUIRED_COLS - set(df.columns):
        # A folder from one of the older grid backtests, which use a different
        # schema. Not an error - just not ours. Counted, not shouted about.
        return None
    for c in ("entry_time", "exit_time"):
        df[c] = pd.to_datetime(df[c], errors="coerce")
    return df.sort_values("entry_time").reset_index(drop=True)


def metrics(df: pd.DataFrame) -> dict:
    """Everything below is computed from the deal log alone."""
    n = len(df)
    if n == 0:
        return {"trades": 0}

    pnl = df["gross_pnl_pct"].astype(float)
    wins, losses = pnl[pnl > 0], pnl[pnl <= 0]

    gross_profit = wins.sum()
    gross_loss = abs(losses.sum())
    pf = gross_profit / gross_loss if gross_loss > 0 else float("inf")

    avg_win = wins.mean() if len(wins) else 0.0
    avg_loss = abs(losses.mean()) if len(losses) else 0.0

    # Break-even win rate implied by this strategy's own payoff shape:
    # p * avg_win = (1 - p) * avg_loss  ->  p = avg_loss / (avg_win + avg_loss)
    be_wr = (avg_loss / (avg_win + avg_loss) * 100) if (avg_win + avg_loss) > 0 else float("nan")

    # Compounding equity from the deals in time order. One position at a time,
    # full allocation, no leverage - the same simplification the engines make,
    # just carried through to an equity curve so drawdown becomes visible.
    equity = (1 + pnl / 100).cumprod()
    peak = equity.cummax()
    max_dd = ((equity / peak - 1).min() * 100) if n else 0.0

    hold = (df["exit_time"] - df["entry_time"]).dt.total_seconds() / 3600
    hold_h = hold.mean() if hold.notna().any() else float("nan")

    reasons = df["reason"].value_counts(normalize=True) * 100

    return {
        "trades": n,
        "win_rate": len(wins) / n * 100,
        "be_win_rate": be_wr,
        "avg_pnl": pnl.mean(),
        "median_pnl": pnl.median(),
        "avg_win": avg_win,
        "avg_loss": -avg_loss,
        "pf": pf,
        "total_return": (equity.iloc[-1] - 1) * 100,
        "max_dd": max_dd,
        "stop_rate": reasons.get("stop_loss", 0.0),
        "tp_rate": reasons.get("take_profit", 0.0),
        "hold_hours": hold_h,
        "best": pnl.max(),
        "worst": pnl.min(),
    }


def fmt(m: dict) -> str:
    if m["trades"] == 0:
        return f"{'0 trades':>12}"
    pf = "  inf " if m["pf"] == float("inf") else f"{m['pf']:5.2f}"
    return (f"{m['trades']:5d} | {m['avg_pnl']:+6.2f}% | {m['win_rate']:5.1f}% | "
            f"{m['be_win_rate']:5.1f}% | {pf} | {m['max_dd']:6.1f}% | "
            f"{m['total_return']:+8.1f}% | {m['hold_hours']:6.1f}h")


HEADER = (f"{'symbol':<14} {'trades':>5} | {'avg':>7} | {'WR':>6} | "
          f"{'need':>6} | {'PF':>5} | {'maxDD':>7} | {'total':>9} | {'hold':>7}")


def read_manifest(d: Path) -> dict | None:
    """Conditions the run happened under, written by the backtest scripts."""
    f = d / "_run.json"
    if not f.exists():
        return None
    try:
        import json
        return json.loads(f.read_text(encoding="utf-8"))
    except Exception:
        return None


def conditions_line(man: dict | None) -> str:
    if not man:
        return ("  conditions: UNKNOWN - no _run.json. Folder predates the manifest, "
                "or two runs overwrote each other here. Re-run before comparing.")
    return (f"  {man.get('timeframe','?')}  |  {man.get('start','?')} -> {man.get('end','?')}"
            f"  |  {man.get('exchange','?')} {man.get('market','?')}"
            f"  |  fee {man.get('commission_pct','?')}% slip {man.get('slippage_pct','?')}%"
            f"  |  run {str(man.get('run_at','?'))[:16]}")


def condition_key(man: dict | None):
    if not man:
        return None
    return (man.get("timeframe"), man.get("start"), man.get("end"),
            man.get("market"), str(man.get("commission_pct")))


def analyse_dir(d: Path) -> tuple[dict, list]:
    files = sorted(d.glob("*_deals.csv"))
    if not files:
        return {}, []

    per_symbol, frames, skipped = [], [], 0
    for f in files:
        df = load_deals(f)
        if df is None:
            skipped += 1
            continue
        sym = f.name.replace("_deals.csv", "")
        m = metrics(df)
        m["symbol"] = sym
        m["strategy"] = d.name
        per_symbol.append(m)
        if len(df):
            frames.append(df)

    combined = metrics(pd.concat(frames).sort_values("entry_time")) if frames else {"trades": 0}
    combined["_skipped"] = skipped
    return combined, per_symbol


def verdict(m: dict) -> str:
    """One blunt line. Deliberately conservative: this is a filter for what
    deserves more work, not a recommendation to trade anything."""
    if m.get("trades", 0) == 0:
        return "no trades - check the signal logic or the date range"
    if m["trades"] < 30:
        return "too few trades to conclude anything"
    if m["pf"] >= 1.3 and m["avg_pnl"] > 0:
        return "worth a closer look: out-of-sample split, then forward test"
    if m["pf"] >= 1.0:
        return "marginal - edge, if any, is inside the noise"
    gap = m["be_win_rate"] - m["win_rate"]
    if gap > 5:
        return f"structurally losing: needs {m['be_win_rate']:.1f}% WR, gets {m['win_rate']:.1f}%"
    return "loses after costs"


def main():
    p = argparse.ArgumentParser(description="Compare backtested strategies")
    p.add_argument("--dirs", nargs="+", help="folders to read (default: every backtest_out_*)")
    p.add_argument("--root", default=".", help="where to look for backtest_out_* folders")
    p.add_argument("--csv", help="also write the per-symbol table here")
    args = p.parse_args()

    root = Path(args.root)
    if args.dirs:
        dirs = [Path(d) for d in args.dirs]
    else:
        dirs = sorted(d for d in root.glob("backtest_out*") if d.is_dir())

    dirs = [d for d in dirs if d.exists() and any(d.glob("*_deals.csv"))]
    if not dirs:
        print("No folders with *_deals.csv found. Run a backtest first, e.g.:\n"
              "  python third_eye_backtest.py --symbol BTC/USDT --exchange bybit "
              "--market swap --out backtest_out_third_eye_perp")
        return

    all_rows, summary = [], []

    for d in dirs:
        combined, per_symbol = analyse_dir(d)
        if not per_symbol:
            continue
        all_rows.extend(per_symbol)

        man = read_manifest(d)
        print()
        print("=" * 104)
        print(f"  {d.name}")
        print(conditions_line(man))
        print("=" * 104)
        print(HEADER)
        print("-" * 104)
        for m in per_symbol:
            print(f"{m['symbol']:<14} {fmt(m)}")
        if len(per_symbol) > 1:
            print("-" * 104)
            print(f"{'ALL':<14} {fmt(combined)}")
        print()
        print(f"  avg win {combined.get('avg_win', 0):+.2f}%  |  "
              f"avg loss {combined.get('avg_loss', 0):+.2f}%  |  "
              f"stops {combined.get('stop_rate', 0):.0f}%  |  "
              f"targets {combined.get('tp_rate', 0):.0f}%")
        print(f"  >> {verdict(combined)}")

        if combined.get("_skipped"):
            print(f"  ({combined['_skipped']} file(s) in this folder use a different "
                  f"schema - older grid backtests - and were skipped)")
        combined["strategy"] = d.name
        combined["_cond"] = condition_key(man)
        summary.append(combined)

    if len(summary) > 1:
        print()
        print("=" * 104)
        print("  RANKING (all symbols pooled per strategy, sorted by profit factor)")
        print("=" * 104)
        keys = {m.get("_cond") for m in summary}
        if len(keys) > 1 or None in keys:
            print("  !! These folders were NOT produced under the same conditions")
            print("     (see the line under each heading). Ranking them against each")
            print("     other compares the settings, not the strategies. Re-run them")
            print("     through run_backtests.py, which forces one set of conditions.")
            print("-" * 104)
        print(f"{'strategy':<36} {'trades':>6} | {'avg':>7} | {'WR':>6} | "
              f"{'need':>6} | {'PF':>5} | {'maxDD':>7}")
        print("-" * 104)
        for m in sorted(summary, key=lambda x: -(x["pf"] if x["pf"] != float("inf") else 1e9)):
            pf = "  inf " if m["pf"] == float("inf") else f"{m['pf']:5.2f}"
            print(f"{m['strategy']:<36} {m['trades']:6d} | {m['avg_pnl']:+6.2f}% | "
                  f"{m['win_rate']:5.1f}% | {m['be_win_rate']:5.1f}% | {pf} | {m['max_dd']:6.1f}%")

    print()
    print("  WR   = actual win rate;  need = win rate required to break even at this")
    print("         strategy's own average win / average loss. need > WR by a wide")
    print("         margin means the payoff shape is wrong, not the parameters.")
    print("  maxDD= worst peak-to-trough fall of a compounding equity curve built")
    print("         from the deals in time order, one position at a time, no leverage.")

    if args.csv and all_rows:
        cols = ["strategy", "symbol", "trades", "win_rate", "be_win_rate", "avg_pnl",
                "median_pnl", "avg_win", "avg_loss", "pf", "total_return", "max_dd",
                "stop_rate", "tp_rate", "hold_hours", "best", "worst"]
        out = pd.DataFrame(all_rows)[cols]
        out.to_csv(args.csv, index=False)
        print(f"\n  per-symbol table written to {args.csv}")


if __name__ == "__main__":
    main()
