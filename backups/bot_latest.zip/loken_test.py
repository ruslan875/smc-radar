# -*- coding: utf-8 -*-
"""LOKEN94 LONG STRATEGY — точный порт Pine (v5) и прогон как на скриншоте:
Binance Futures HUSDT.P, 3m, 25.05.2026–09.06.2026, капитал 10000, 10% на вход, пирамида 3, мин. 3 бара,
TP 5% / SL 3% от цены каждого входа, комиссия 0.05%. Плюс проверка на других монетах и периодах.
Запуск: python loken_test.py   → loken_report.txt"""
import os, sys, time, json, urllib.request
import numpy as np, pandas as pd
try: sys.stdout.reconfigure(encoding="utf-8")
except Exception: pass
H = os.path.dirname(os.path.abspath(__file__))
CACHE = os.path.join(H, "market_cache", "loken"); os.makedirs(CACHE, exist_ok=True)
P = dict(bb=50, bp=50, hb=30, hp=40, sb=1.5, sh=0.7, tp=5.0, sl=3.0, maxp=3, qty=10.0, minbars=3, fee=0.0005)

def klines(sym, tf, start, end):
    f = os.path.join(CACHE, f"{sym}_{tf}_{start}_{end}.csv")
    if os.path.exists(f): return pd.read_csv(f, index_col=0, parse_dates=True)
    s = int(pd.Timestamp(start, tz="UTC").timestamp() * 1000); e = int(pd.Timestamp(end, tz="UTC").timestamp() * 1000); rows = []
    print(f"скачиваю {sym} {tf} {start}..{end}")
    while s < e:
        u = f"https://fapi.binance.com/fapi/v1/klines?symbol={sym}&interval={tf}&limit=1500&startTime={s}&endTime={e}"
        for k in range(6):
            try: d = json.loads(urllib.request.urlopen(u, timeout=25).read()); break
            except Exception as ex: print("  повтор", str(ex)[:50]); time.sleep(3)
        else: return None
        if not d: break
        rows += [[r[0], *map(float, r[1:6])] for r in d]; s = d[-1][0] + 1; time.sleep(0.1)
    if not rows: return None
    df = pd.DataFrame(rows, columns=["t", "o", "h", "l", "c", "v"]).drop_duplicates("t")
    df.index = pd.to_datetime(df.t, unit="ms"); df = df.drop(columns="t"); df.to_csv(f); return df

# --- Pine-функции ---
def rma(x, n):
    x = np.asarray(x, float); out = np.full(len(x), np.nan); a = 1 / n; s = None; buf = []
    for i, v in enumerate(x):
        if np.isnan(v): continue
        if s is None:
            buf.append(v)
            if len(buf) == n: s = np.mean(buf); out[i] = s
        else: s = a * v + (1 - a) * s; out[i] = s
    return out
def ema(x, n):
    x = np.asarray(x, float); out = np.full(len(x), np.nan); a = 2 / (n + 1); s = None; buf = []
    for i, v in enumerate(x):
        if np.isnan(v): continue
        if s is None:
            buf.append(v)
            if len(buf) == n: s = np.mean(buf); out[i] = s
        else: s = a * v + (1 - a) * s; out[i] = s
    return out
sma = lambda x, n: pd.Series(x).rolling(n).mean().to_numpy()
def wma(x, n):
    w = np.arange(1, n + 1); return pd.Series(x).rolling(n).apply(lambda a: (a * w).sum() / w.sum(), raw=True).to_numpy()
def rsi(c, n):
    d = np.diff(c, prepend=np.nan); up = rma(np.where(np.isnan(d), np.nan, np.maximum(d, 0)), n); dn = rma(np.where(np.isnan(d), np.nan, np.maximum(-d, 0)), n)
    with np.errstate(divide="ignore", invalid="ignore"):
        r = np.where(dn == 0, 100.0, np.where(up == 0, 0.0, 100 - 100 / (1 + up / dn)))
    r[np.isnan(up) | np.isnan(dn)] = np.nan; return r
def sh(x, k): y = np.full(len(x), np.nan); y[k:] = x[:-k] if k else x; return y if k else x.copy()
def xover(a, b): return (a > b) & (sh(a, 1) <= (sh(b, 1) if isinstance(b, np.ndarray) else b))
def xunder(a, b): return (a < b) & (sh(a, 1) >= (sh(b, 1) if isinstance(b, np.ndarray) else b))

def signals(c):
    f = lambda s, n, b: np.clip(s * (rsi(c, n) - b), 0, 40)
    rb = f(P["sb"], P["bp"], P["bb"]); rh = f(P["sh"], P["hp"], P["hb"])
    hotma = ema((rma(rh, 2) * 34 + rma(rh, 7) * 33 + rma(rh, 31) * 33) / 100, 2)
    bankma = (sma(rb, 2) * 70 + ema(rb, 7) * 20 + ema(rb, 31) * 10) / 100
    hots = rma(hotma, 2); banks = rma(bankma, 4)
    hbma = (rh * 10 + hotma * 35 + hots * 15 + bankma * 35 + banks * 5) / 100
    lowamp = rb / 2 + rb / 3 + rb / 4 + rb / 5 + rb / 6 + rb / 7; lows = ema(lowamp, 31)
    bull = xover(rb, 8.5) & (rh > 17) & (bankma > banks) & (hotma > hots) & (sh(rb, 2) < 6) & (sh(rb, 5) < 5) & (sh(rb, 24) < 12)
    entry = xover(rh, 16) & (rb > 0) & (sh(rh, 3) < 15) & (sh(rh, 10) < 13) & (sh(rh, 20) < 13)
    greed = xover(lows, hbma) & (lows > 12) & (rb > 8.5)
    bear = xunder(rb, 8.5) & (rh < 18) & (bankma < banks) & (hotma < hots) & (rb < 5)
    clim = xover(hbma, 19)
    return entry | bull, greed | bear | clim

def backtest(d, start):
    O, Hh, L, C = d.o.values, d.h.values, d.l.values, d.c.values
    ent, ex = signals(C); i0 = int(np.searchsorted(d.index, pd.Timestamp(start)))
    cash = 10000.0; pos = []; trades = []; peak = 10000.0; mdd = 0.0; last = None
    pend_entry = None; pend_close = False
    for i in range(i0, len(C)):
        # 1) ордера, созданные на закрытии прошлого бара, исполняются по open
        if pend_close and pos:
            for p in pos:
                pnl = p["q"] * (O[i] - p["e"]) - p["q"] * O[i] * P["fee"]; cash += p["q"] * O[i] - p["q"] * O[i] * P["fee"]; trades.append(pnl - p["fe"])
            pos = []
        pend_close = False
        if pend_entry:
            q = pend_entry; fe = q * O[i] * P["fee"]; cash -= q * O[i] + fe
            pos.append(dict(e=O[i], q=q, fe=fe, arm=i + 1)); pend_entry = None
        # 2) TP/SL каждой позиции (действуют со следующего бара после входа)
        keep = []
        for p in pos:
            if i >= p["arm"]:
                sl = p["e"] * (1 - P["sl"] / 100); tp = p["e"] * (1 + P["tp"] / 100); px = None
                if O[i] <= sl: px = O[i]
                elif O[i] >= tp: px = O[i]
                elif L[i] <= sl: px = sl
                elif Hh[i] >= tp: px = tp
                if px is not None:
                    fee = p["q"] * px * P["fee"]; cash += p["q"] * px - fee; trades.append(p["q"] * (px - p["e"]) - fee - p["fe"]); continue
            keep.append(p)
        pos = keep
        eq = cash + sum(p["q"] * C[i] for p in pos); eqlo = cash + sum(p["q"] * L[i] for p in pos)
        peak = max(peak, eq); mdd = max(mdd, peak - eqlo)
        # 3) логика на закрытии бара
        if pos and ex[i]: pend_close = True; continue
        bs = 999 if last is None else i - last
        if ent[i] and len(pos) < P["maxp"] and bs >= P["minbars"]:
            pend_entry = eq * P["qty"] / 100 / C[i]; last = i
    if pos: trades += [p["q"] * (C[-1] - p["e"]) - p["fe"] for p in pos]
    t = np.array(trades); net = t.sum() if len(t) else 0
    pf = t[t > 0].sum() / max(-t[t < 0].sum(), 1e-9) if len(t) else 0
    return dict(net=net, pct=net / 100, dd=mdd, ddp=mdd / peak * 100, n=len(t), win=(t > 0).mean() * 100 if len(t) else 0, pf=pf)

RUNS = [("HUSDT", "3m", "2026-05-25", "2026-06-09", "КАК НА СКРИНШОТЕ")]
for s in ["BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT", "DOGEUSDT", "BNBUSDT", "ADAUSDT", "LINKUSDT", "AVAXUSDT", "LTCUSDT"]:
    RUNS.append((s, "3m", "2026-05-25", "2026-06-09", "тот же период"))
for s in ["HUSDT", "BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT", "DOGEUSDT"]:
    RUNS.append((s, "3m", "2026-01-01", "2026-10-08", "весь 2026"))
out = []
for sym, tf, a, b, note in RUNS:
    warm = (pd.Timestamp(a) - pd.Timedelta(days=4)).strftime("%Y-%m-%d")
    d = klines(sym, tf, warm, b)
    if d is None or len(d) < 500: line = f"{sym:9} {tf} {a}..{b}: нет данных"
    else:
        r = backtest(d, a)
        line = (f"{sym:9} {tf} {a}..{b}  итог {r['net']:+9.2f}$ ({r['pct']:+6.2f}%)  DD {r['dd']:7.2f}$ ({r['ddp']:.2f}%)  "
                f"сделок {r['n']:4}  в плюсе {r['win']:5.1f}%  PF {r['pf']:.3f}   [{note}]")
    print(line, flush=True); out.append(line)
out.append("\nСкриншот автора: HUSDT.P 3m 25.05–09.06.2026: +113.21$ (+1.13%), DD 179.22$ (1.76%), 21/41 в плюсе (51.22%), PF 1.219")
open(os.path.join(H, "loken_report.txt"), "w", encoding="utf-8").write("\n".join(out)); print("\nГотово: loken_report.txt")
