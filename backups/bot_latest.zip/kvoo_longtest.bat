@echo off
cd /d %~dp0
if exist venv\Scripts\python.exe (venv\Scripts\python.exe kvoo_longtest.py) else (python kvoo_longtest.py)
