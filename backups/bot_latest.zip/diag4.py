import socket, subprocess, sys
from pathlib import Path
B = Path(__file__).resolve().parent; sys.path.insert(0, str(B))
from windows_app import mobile_gateway as mg
print("LAN_IP", mg.lan_ip())
try: print("ALL", socket.gethostbyname_ex(socket.gethostname())[2])
except Exception as e: print("ALL err", e)
o = subprocess.run(["ipconfig"], capture_output=True, text=True, encoding="cp866", errors="replace").stdout
print("\n".join(l for l in o.splitlines() if "IPv4" in l or "адаптер" in l.lower() or "adapter" in l.lower()))
r = subprocess.run(["netsh", "advfirewall", "firewall", "show", "rule", "name=all", "dir=in"], capture_output=True, text=True, encoding="cp866", errors="replace").stdout
print("FW python rules:", sum(1 for l in r.splitlines() if "python" in l.lower()))
