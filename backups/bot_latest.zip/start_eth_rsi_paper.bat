@echo off
cd /d "%~dp0"
start "ETH RSI paper" cmd /k ".\venv\Scripts\python.exe eth_rsi_paper.py --deposit 100 --leverage 2 --symbols BTC,ETH,SOL,DOGE"
