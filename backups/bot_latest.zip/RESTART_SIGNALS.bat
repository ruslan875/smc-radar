@echo off
chcp 65001 >nul
cd /d "D:\VANTORIX\bot"
echo === 1. Проверка: подключена ли группа-форум ===
findstr /b /c:"TELEGRAM_FORUM_CHAT_ID=-100" .env >nul 2>&1 && (echo   OK: группа подключена) || (echo   НЕТ: группа не подключена - добавляю& echo.>>.env& echo TELEGRAM_FORUM_CHAT_ID=-1004339432295>>.env)
echo === 2. Перезапуск панели (боты OKX-кандидатов, сборки, канал) ===
venv\Scripts\python.exe bot_services.py stop panel
timeout /t 2 >nul
venv\Scripts\python.exe bot_services.py start panel
echo === 3. Перезапуск paper-ботов лаборатории (Портфель) ===
venv\Scripts\python.exe bot_services.py restart-lab
echo === 4. Перезапуск Paper10 (Gaussian, Pavlova...) ===
if exist paper_live.pid (set /p PID=<paper_live.pid) else (set PID=)
if defined PID taskkill /PID %PID% /F >nul 2>&1
del paper_live.pid >nul 2>&1
timeout /t 2 >nul
if exist "venv\Scripts\pythonw.exe" (set PYW=venv\Scripts\pythonw.exe) else (set PYW=pythonw)
start "" %PYW% paper_live.py --no-dashboard --telegram --log-file paper_live.log
echo.
echo Готово. Новые сигналы пойдут в темы группы TRADEOS Сигналы.
echo Важные (реальные боты, риск) продублируются в личку бота.
pause
