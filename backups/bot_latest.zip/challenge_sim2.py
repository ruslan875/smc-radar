"""challenge_sim2.py — 2026-10-31. Как пройти челлендж Hash Hedge БЫСТРЕЕ при том же перевесе стратегии.
Идеи (как у проп-трейдеров): 1) риск растёт, когда есть запас прибыли, и падает в просадке («торгуй деньгами фирмы»);
2) больше НЕЗАВИСИМЫХ сигналов (пробой 2h + Donchian 4h + Черепахи 4h + пробой 4h) — больше сделок в месяц;
3) лимит одновременных сделок в одну сторону. Правила — 2-Stage (цель 8% или 5%, затем 6%), плавающий минус учитывается.
Пишет bt_lab_bots/challenge_sim2.txt"""
from __future__ import annotations

import bisect
import sys
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import numpy as np  # noqa: E402
import recheck_recent as RR  # noqa: E402
import challenge_sim as CS  # noqa: E402

DAY, TZ = CS.DAY, CS.TZ


def risk_of(bal, plan):
    base, up_at, up_r, dn_at, dn_r = plan
    if bal >= up_at:
        return up_r
    if bal <= -dn_at:
        return dn_r
    return base


def stage(trs, times, t0, plan, target, dl, dd, min_days, cap, max_days=730):
    bal = 0.0; open_ = []; days = set(); day_bal = {}
    k = bisect.bisect_left([x["t_in"] for x in trs], t0)
    for tm in times[bisect.bisect_left(times, t0):]:
        if tm - t0 > max_days * DAY:
            return "open", None, tm
        dkey = (tm + TZ) // DAY
        day_bal.setdefault(dkey, bal)
        eq = bal
        for tr in open_:
            pt = tr["pd"].get(tm)
            if pt:
                tr["_last"] = pt[1]; eq += pt[0] * tr["_risk"]
            else:
                eq += tr["_last"] * tr["_risk"]
        if eq - day_bal[dkey] <= -dl or eq <= -dd:
            return "fail", (tm - t0) / DAY, tm
        keep = []
        for tr in open_:
            if tm >= tr["t_out"]:
                bal += tr["R"] * tr["_risk"]
            else:
                keep.append(tr)
        open_ = keep
        if bal >= target and len(days) >= min_days and not open_:
            return "pass", (tm - t0) / DAY, tm
        while k < len(trs) and trs[k]["t_in"] < tm:
            k += 1
        while k < len(trs) and trs[k]["t_in"] == tm:
            x = trs[k]; k += 1
            if bal >= target and len(days) >= min_days:
                continue
            if sum(1 for tr in open_ if tr["s"] == x["s"]) >= cap:
                continue
            if any(tr["sym"] == x["sym"] for tr in open_):
                continue                       # одна позиция на монету (общий счёт, one-way)
            r = risk_of(bal, plan)
            # сделка не должна в одиночку пробить общий лимит или съесть больше половины дневного запаса
            room = min(dd + bal, dl - (day_bal[dkey] - eq))
            r = min(r, max(0.0, room / 2))
            if r <= 0.05:
                continue
            if sum(tr["_risk"] / (tr["stop_pct"] * 100) for tr in open_) + r / (x["stop_pct"] * 100) > 5 * (1 + bal / 100):
                continue
            x["_last"] = 0.0; x["_risk"] = r; open_.append(x); days.add(dkey)
    return "open", None, times[-1]


def main():
    import kvoo_longtest as K  # noqa: PLC0415
    data = {tf: {s: RR.load(s, tf) for s in K.COINS} for tf in ("2h", "4h")}
    STR = {"chan2h": "2h", "chan4h": "4h", "donch": "4h", "turtle4h": "4h"}
    raw = {}
    for name, tf in STR.items():
        trs = []
        for s, d in data[tf].items():
            if d is not None and len(d) > 400:
                trs += CS.trades(name, d.reset_index(drop=True), s)
        for x in trs:
            x["pd"] = {p[0]: (p[1], p[2]) for p in x["path"]}
        raw[name] = trs
    pools = {"пробой2h+Donchian": raw["chan2h"] + raw["donch"],
             "все 4 (пробой 2h/4h, Donchian, Черепахи 4h)": raw["chan2h"] + raw["chan4h"] + raw["donch"] + raw["turtle4h"]}
    PLANS = {"0.5% ровно": (0.5, 999, 0.5, 999, 0.5), "1% ровно": (1.0, 999, 1.0, 999, 1.0),
             "0.5% → 1% после +2%, 0.25% в −4%": (0.5, 2, 1.0, 4, 0.25),
             "0.75% → 1.5% после +3%, 0.35% в −4%": (0.75, 3, 1.5, 4, 0.35),
             "1% → 2% после +3%, 0.5% в −3%": (1.0, 3, 2.0, 3, 0.5)}
    lines = ["Как пройти быстрее · 2-Stage · плавающий минус учитывается · старт каждые 28 дней · сделка не берёт больше половины запаса до лимита"]
    for tgt in (8, 5):
        lines.append(f"\n=== этап 1 цель {tgt}%, этап 2 цель 6% ===")
        for pname, trs in pools.items():
            trs = sorted(trs, key=lambda x: x["t_in"])
            times = sorted({x["t_in"] for x in trs} | {p[0] for x in trs for p in x["path"]})
            t_first = trs[0]["t_in"] + 30 * DAY; t_last = trs[-1]["t_out"] - 400 * DAY
            for cap in (2, 3):
                for plan_name, plan in PLANS.items():
                    res = []
                    for t0 in range(t_first, t_last, 28 * DAY):
                        tt = t0; total = 0.0; out = "pass"
                        for target, dl, dd, md in [(tgt, 5, 10, 5), (6, 5, 8, 5)]:
                            r, d_, tend = stage(trs, times, tt, plan, target, dl, dd, md, cap)
                            if r != "pass":
                                out = r; break
                            total += d_; tt = tend + 1
                        res.append((out, total if out == "pass" else None))
                    n = len(res); ok = [x[1] for x in res if x[0] == "pass"]; fl = sum(1 for x in res if x[0] == "fail")
                    line = (f"{pname[:22]:<22} ≤{cap} · {plan_name:<36} → прошли {len(ok) / n * 100:3.0f}% · провал {fl / n * 100:3.0f}% · "
                            + (f"медиана {np.median(ok):.0f} дн · 25% быстрее {np.percentile(ok, 25):.0f} дн" if ok else ""))
                    print(line, flush=True); lines.append(line)
    (BASE / "bt_lab_bots" / "challenge_sim2.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("готово")


if __name__ == "__main__":
    main()
