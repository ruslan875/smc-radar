"""Paper-бот из вкладки «Бэктест»: та же стратегия и те же настройки, что в тесте,
но вперёд по живым минуткам Bybit. Ни одного ордера на бирже. 2026-09-26.

Раз в минуту: докачивает минутки (candle_store), прогоняет стратегию на окне
последних дней и берёт только сделки, открытые ПОСЛЕ запуска бота. Новые
сделки -> журнал + Telegram (категория «paper»).

    python lab_paper.py --id ID --params '{...}'     # запуск одного бота
    python lab_paper.py --resume-all                  # после перезагрузки ПК
Остановка: файл bt_lab_bots/<ID>.stop (кнопка «Стоп» во вкладке).
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path

import pandas as pd

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
BOTS = BASE / "bt_lab_bots"
WINDOW_DAYS = {"1m": 30, "5m": 30, "15m": 45, "30m": 60, "1h": 90, "2h": 120, "4h": 200, "1d": 400}


def _notifier():
    try:
        from dotenv import load_dotenv
        load_dotenv(BASE / ".env")
        from app.config import Settings
        from app.telegram_client import TelegramClient
        from app import notify_prefs
        s = Settings.load()
        if not s.telegram_token or not s.telegram_chat_id:
            return lambda _t: None
        tg = TelegramClient(s.telegram_token, s.telegram_chat_id)

        def send(text):
            if notify_prefs.is_enabled("paper"):
                try:
                    tg.send_message(text)
                except Exception:  # noqa: BLE001
                    pass
        return send
    except Exception:  # noqa: BLE001
        return lambda _t: None


class _Coin:
    """Одна монета: окно свечей в памяти + учёт сделок. Логика стратегии та же, что в бэктесте."""

    def __init__(self, sym, sub, deposit):
        self.sym, self.sub, self.cache, self.ex = sym, sub, None, None
        sub.setdefault("equity", float(deposit)); sub.setdefault("trades", []); sub.setdefault("open", None)
        self.deposit = float(deposit)
        self.seen = {(t["open_t"], t["close_t"]) for t in sub["trades"]}

    def candles(self, CS, tf):
        days = WINDOW_DAYS.get(tf, 60)
        start = pd.Timestamp.now("UTC") - pd.Timedelta(days=days)
        start_ms = int(start.timestamp() * 1000)
        if self.cache is None:
            part = CS.load_since(self.sym, start_ms) if hasattr(CS, "load_since") else None
            self.ex = CS._exchange()
            if part is None or not len(part):
                # монеты нет на складе — докачать (один раз), потом держать только окно
                full = CS.update(self.sym, start=start.strftime("%Y-%m-%d"), log=lambda *_a: None, min_save=120)
                part = full[full.t >= start_ms].reset_index(drop=True).copy()
                del full
            self.cache = part.reset_index(drop=True)
        if True:
            last = int(self.cache.t.iloc[-1])
            new = CS._fetch_range(self.ex, self.sym.upper().replace("USDT", ""), last + 60_000,
                                  int(time.time() * 1000), lambda *_a: None)
            if len(new):
                self.cache = CS._clean(pd.concat([self.cache, new], ignore_index=True))
            self.cache = self.cache[self.cache.t >= start_ms].reset_index(drop=True)
        return self.cache

    def step(self, CS, fn, p, started, notify, name, total_eq=None):
        sub = self.sub
        df = self.candles(CS, p.get("tf", "1h"))
        pc = {**p, "symbol": self.sym}
        q = {**pc, "deposit": 100.0, "reinvest": 0}                  # размер пересчитываем сами ниже
        trades, _eq, _liq, _mpu, _f, _b, open_pos = fn(df, q, lambda *_a: None)
        for t in trades:
            key = (t["open_t"], t["close_t"])
            if t["open_t"] < started or key in self.seen or t["why"] == "ликвидация":
                continue
            self.seen.add(key)
            dep = self.deposit; rein = float(p.get("reinvest") or 0) / 100
            alloc = min(dep + rein * max(sub["equity"] - dep, 0), sub["equity"])
            usd = t["net"] / 100 * alloc                              # net посчитан на депозит 100 -> масштабируем
            sub["equity"] += usd
            rec = {**{k: t[k] for k in ("side", "open_t", "close_t", "entry", "avg", "exit", "orders", "why", "pnl_pct")},
                   "sym": self.sym, "usd": round(usd, 4), "eq": round(sub["equity"], 4)}
            sub["trades"].append(rec)
            bal = sub["equity"] if total_eq is None else total_eq() 
            notify(f"{'✅' if usd > 0 else '❌'} <b>{self.sym} {t['side']}</b> {usd:+.2f}$ · {t['why']}\n"
                   f"{name} · paper · баланс {bal:.2f}")
        sub["open"] = open_pos if open_pos and open_pos.get("open_t", 0) >= started else None
        sig = {"started": started, "signals_sent": sub.setdefault("signals_sent", [])}
        try:
            signal_step(pc, sig, df)
        except Exception as exc:  # noqa: BLE001 -- сигнал не должен ломать paper-учёт
            sub["signal_error"] = str(exc)[:200]


def run_bot(bot_id: str, p: dict) -> None:
    """Один бот. Если в params есть coins — ПОРТФЕЛЬНЫЙ бот: одна программа ведёт все монеты
    (раньше на каждую монету был свой процесс — 12 монет = 12 копий Python). Стратегия на каждой
    монете считается ровно так же, депозит делится поровну, баланс каждой монеты свой."""
    import bt_lab
    import candle_store as CS
    BOTS.mkdir(exist_ok=True)
    sp = BOTS / f"{bot_id}.json"
    coins = [c.upper() for c in (p.get("coins") or [])] if p.get("portfolio") else []
    st = json.loads(sp.read_text(encoding="utf-8")) if sp.exists() else {
        "id": bot_id, "params": p, "started": int(time.time() * 1000), "equity": float(p["deposit"]),
        "trades": [], "open": None, "error": None, "last_run": None}
    notify = _notifier()
    name = p.get("label") or p["strategy"]
    if not sp.exists():
        where = f"{len(coins)} монет" if coins else p["symbol"]
        notify(f"🧪 <b>Paper-бот запущен</b>: {name} · {where} · {p.get('tf', '')}\n"
               f"депозит {p['deposit']} · x{p['leverage']} · из вкладки «Бэктест»")
    fn = bt_lab.pick(p["strategy"])
    if coins:
        per = float(p["deposit"]) / len(coins)
        subs = st.setdefault("coins", {})
        runners = [_Coin(c, subs.setdefault(c, {}), per) for c in coins]
    else:
        runners = [_Coin(p["symbol"], st, float(p["deposit"]))]
    total = lambda: sum(r.sub["equity"] for r in runners)  # noqa: E731
    while not (BOTS / f"{bot_id}.stop").exists():
        errs = []
        for r in runners:
            if (BOTS / f"{bot_id}.stop").exists():
                break
            try:
                r.step(CS, fn, p, st["started"], notify, name, total if coins else None)
            except Exception as exc:  # noqa: BLE001 -- сеть/биржа: следующая минута
                errs.append(f"{r.sym}: {str(exc)[:120]}")
        if coins:
            st["equity"] = round(total(), 4)
            st["trades"] = sorted((t for r in runners for t in r.sub["trades"]), key=lambda t: t["close_t"])[-300:]
            opens = [dict(r.sub["open"], sym=r.sym) for r in runners if r.sub.get("open")]
            st["open"] = ({**opens[0], "orders": len(opens)} if opens else None)
            st["open_list"] = opens
        st["error"] = "; ".join(errs)[:300] if errs else None
        st["last_run"] = int(time.time() * 1000)
        sp.write_text(json.dumps(st, ensure_ascii=False, default=float), encoding="utf-8")
        time.sleep(60 if not coins else max(5, 60 - 2 * len(coins)))
    st["stopped"] = int(time.time() * 1000)
    sp.write_text(json.dumps(st, ensure_ascii=False, default=float), encoding="utf-8")
    notify(f"⏹ Paper-бот остановлен: {name} · баланс {st['equity']:.2f}")


def _signal_client():
    """Telegram-клиент для сигналов с кнопкой (без фильтра категорий — это сигнал к действию)."""
    try:
        from dotenv import load_dotenv
        load_dotenv(BASE / ".env")
        from app.config import Settings
        from app.telegram_client import TelegramClient
        s = Settings.load()
        if s.telegram_token and s.telegram_chat_id:
            return TelegramClient(s.telegram_token, s.telegram_chat_id)
    except Exception:  # noqa: BLE001
        pass
    return None


def signal_step(p, st, df):
    """Новая сделка собранной стратегии -> сообщение в Telegram с кнопкой «Открыть».
    Кнопка ведёт в обычное превью «Проверь сделку» (main.py) с подтверждением «✅ Открыть»:
    реальный ордер ставит только человек, бот лишь присылает сигнал со стопом и тейком."""
    if p["strategy"] != "combo" or not p.get("signals", True):
        return
    import uuid
    import bt_lab, lab_builder as LB
    d = bt_lab._tf_frame(df, p["tf"]).reset_index(drop=True)
    spec = p["spec"]
    uses = spec["trigger"][:1] in "⚙🧠" or any(f[:1] in "⚙🧠" for f in spec.get("filters", []))
    eng, names = LB.engine_signals(d, p["symbol"], p["tf"]) if uses else (None, [])
    _rows, op = LB.run_spec(d, spec, eng, names, with_open=True)
    sent = st.setdefault("signals_sent", [])
    if not op or op["t_in"] < st["started"] or op["t_in"] in sent:
        return
    sent.append(op["t_in"]); del sent[:-50]
    if time.time() * 1000 - (op["t_in"] + op["bar_ms"]) > op["bar_ms"]:
        return                                            # опоздали на свечу — не шлём устаревший вход
    tg = _signal_client()
    if not tg:
        return
    did = uuid.uuid4().hex[:10]
    side = "LONG" if op["side"] > 0 else "SHORT"
    sym = p["symbol"].upper().replace("USDT", "") + "USDT"
    lev = int(float(p.get("leverage") or 1))
    sd = BOTS / "signals"; sd.mkdir(parents=True, exist_ok=True)
    (sd / f"{did}.json").write_text(json.dumps({"symbol": sym, "side": side, "entry": op["entry"], "tp": op["tp"],
                                                "sl": op["sl"], "tf": p["tf"], "at": time.time(), "leverage": lev},
                                               ensure_ascii=False), encoding="utf-8")
    icon = "🟢" if side == "LONG" else "🔴"
    usd = float(os.getenv("MANUAL_DEFAULT_USDT", "20"))
    exit_txt = (f"тейк {op['tp']:.6g} ({(op['tp'] / op['entry'] - 1) * 100:+.2f}%)" if op.get("tp")
                else f"без тейка — трейлинг-стоп {abs(op['sl'] / op['entry'] - 1) * 100:.2f}% за ценой")
    coin = sym.replace("USDT", "")
    sl_pct = (op["sl"] / op["entry"] - 1) * 100
    exit_txt = (f"Тейк <b>{op['tp']:.6g}</b> ({(op['tp'] / op['entry'] - 1) * 100:+.2f}%)" if op.get("tp")
                else f"трейлинг-стоп {abs(sl_pct):.2f}%")
    text = (f"🧪 #{coin} {'🟢 ЛОНГ' if side == 'LONG' else '🔴 ШОРТ'} · {p['tf']} · #Портфель · x{lev}\n"   # 2026-10-10: новый вид
            f"Вход <b>{op['entry']:.6g}</b> · Стоп <b>{op['sl']:.6g}</b> ({sl_pct:+.2f}%) · {exit_txt}\n"
            f"<i>{p.get('label', '')[:70]}</i>\n"
            f"⏳ 1 час · сделка только после «✅ Открыть»")
    kb = {"inline_keyboard": [[{"text": f"{icon} Открыть {side} {usd:g}$", "callback_data": f"mtrade:sig:{did}:{usd:g}"},
                               {"text": f"{usd * 2:g}$", "callback_data": f"mtrade:sig:{did}:{usd * 2:g}"}]]}
    try:   # 2026-10-10: через общий отправщик (темы группы + личка с кнопками); запасной путь — старый клиент
        from windows_app import risk_center as rc  # noqa: PLC0415
        if rc.tg_send(text, channel="main", reply_markup=kb) is not None:
            return
    except Exception:  # noqa: BLE001
        pass
    try:
        tg.send_message(text, reply_markup=kb)
    except Exception:  # noqa: BLE001
        pass


def resume_all() -> None:
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    for f in BOTS.glob("*.json"):
        try:
            st = json.loads(f.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        # 2026-10-12: пропускаем служебные файлы и ботов, которые работают внутри панели
        if not isinstance(st, dict) or "id" not in st or not isinstance(st.get("params"), dict) or st.get("external"):
            continue
        if st.get("stopped") or (BOTS / f"{st['id']}.stop").exists():
            continue
        subprocess.Popen([sys.executable, str(BASE / "lab_paper.py"), "--id", st["id"], "--params", json.dumps(st["params"])],
                         cwd=str(BASE), creationflags=flags)
        print("запущен", st["id"], st["params"].get("strategy"), st["params"].get("symbol"))


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--id"); ap.add_argument("--params"); ap.add_argument("--resume-all", action="store_true")
    a = ap.parse_args()
    if a.resume_all:
        BOTS.mkdir(exist_ok=True); resume_all()
    else:
        run_bot(a.id, json.loads(a.params))
