@echo off
chcp 65001 >nul
cd /d D:\VANTORIX\bot
if exist venv\Scripts\python.exe (set PY="%CD%\venv\Scripts\python.exe") else (set PY=python)
set LOG=okx_matrix_report.txt
set SYM=BTC/USDT ETH/USDT SOL/USDT XRP/USDT DOGE/USDT BNB/USDT ADA/USDT LINK/USDT AVAX/USDT HYPE/USDT
set COMMON=--exchange okx --market swap --start 2024-01-01 --end 2026-09-30 --commission 0.05 --slippage-pct 0.03
echo OKX MATRIX %date% %time% > %LOG%

echo ===== 1. РОДНЫЕ НАСТРОЙКИ (монета/ТФ под которые делали) ===== >> %LOG%
%PY% run_backtests.py --only pavlova   --symbols BTC/USDT  --timeframe 1h  %COMMON% --suffix _okx_native >> %LOG% 2>&1
%PY% run_backtests.py --only hype_r4   --symbols HYPE/USDT --timeframe 1h  %COMMON% --suffix _okx_native >> %LOG% 2>&1
%PY% run_backtests.py --only third_eye --symbols XRP/USDT  --timeframe 15m %COMMON% --suffix _okx_native15 >> %LOG% 2>&1
%PY% run_backtests.py --only third_eye --symbols DOGE/USDT --timeframe 1h  %COMMON% --suffix _okx_native1h >> %LOG% 2>&1

for %%T in (1h 4h 15m 1d) do (
  echo ===== 2. ВСЕ СТРАТЕГИИ · 10 МОНЕТ · %%T ===== >> %LOG%
  %PY% run_backtests.py --symbols %SYM% --timeframe %%T %COMMON% --suffix _okx_%%T >> %LOG% 2>&1
)

echo ===== 3. СТРАТЕГИИ ДВИЖКА (Larry, SR Power, Ichimoku, VSA...) ===== >> %LOG%
if exist strats_okx\run_ex.py (cd strats_okx & %PY% run_ex.py >> ..\%LOG% 2>&1 & cd ..)

echo ГОТОВО >> %LOG%
echo Готово. Пришлите файл okx_matrix_report.txt
pause
