#!/usr/bin/env python3
"""
Fee-aware, no-lookahead backtester for "LONG_STRATEGY 15" by Veles Finance
user latuserge (blog post: veles.finance/ru/blog/post/latuserge-crypto-
strategy/, bot template share code ebqMa -- the share link itself still
401s like every other veles.finance/share/* link tried in this project,
but the blog post spells out almost every number directly, unlike the two
SURVIVE1010 contest bots reverse-engineered from screenshots this same
session). This is a FOURTH, separate engine -- do not confuse with
kc_roc_cci_wt_grid_backtest.py, cci_rsi_wr_signal_grid_backtest.py
(Влад/XWvCF) or bb_roc_atr_adx_donchian_sar_backtest.py (Volgoflint/DcHGj).

CONFIRMED from the blog post (quoted numbers, not guessed):
  - LONG only DCA/grid bot, 20x leverage, 0.5% of total deposit per bot,
    40 concurrent-deal lock, hedge position mode, cross margin (none of
    this affects the %-return simulation below, only real-money sizing).
  - Условия открытия сделки -- ALL 5 true simultaneously, on bar close:
      CCI (1h)          < 80
      CMO (30m)         > -90
      Williams %R (30m) < -80
      Bollinger Bands (15m): close BELOW the lower band
      ATR% (5m)         > 0.5
    (The blog separately mentions "RSI levels on the 1-minute timeframe
    serve as a local reversal marker" as an ADDITIONAL, not one of the
    "five conditions" -- treated here as optional/off by default, see
    --use-rsi-filter.)
  - Order grid -- 6 orders, offsets/volumes/gating filters exactly as
    published (volumes sum to 100.00: 6.66+8+13+16+30+26.34):
      1 (base): 0.04% offset, 6.66% volume, no extra filter
      2:        6%    offset, 8%    volume, ADX(15m) > 40  AND CMO(30m) > -90
      3:        15%   offset, 13%   volume, Bollinger(5m) low AND CMO(30m) > -90
      4:        28%   offset, 16%   volume, Keltner(5m) low  AND CMO(30m) > -90
      5:        40%   offset, 30%   volume, CCI(1m) oversold AND CMO(30m) > -90
      6:        65%   offset, 26.34% volume, CCI(1m) oversold AND CMO(30m) > -90
    Grid pull-up: 0.4%.
  - Exit: Mean Reversion Channel (MRC), "средние уровни" (middle levels),
    5m, on bar close, minimum P&L 1%. Blog describes it only in prose
    ("adapts to current volatility -- locks in more profit on a strong
    move, exits at the floor target in low volatility") with no formula
    -- see APPROXIMATED below.
  - Claimed return: 6-7%/month "conservative". NOT itself verified by
    this script -- that number comes from latuserge's own Google-Sheets
    backtest (linked from the post, not fetched here), covering a
    different, unknown methodology/fee assumption than this script's.

APPROXIMATED / ASSUMED (the blog gives the shape but not every exact
knob -- override via CLI flags):
  - Every indicator's LENGTH (CCI, CMO, Williams %R, Bollinger, ATR%,
    ADX di/smoothing, Keltner): the post states timeframe + threshold for
    each but never a period. Defaults below are the standard/TradingView
    defaults used throughout this project's other backtests (CCI 20,
    CMO 14, Williams %R 14, Bollinger 20/2.0, ATR% 14, ADX 14/14, Keltner
    20/2.0) -- NOT confirmed latuserge-specific values.
  - Orders 3/4's Bollinger/Keltner condition direction: assumed "price
    below the lower band" (a pullback confirmation), matching the
    entry filter's own explicit "ниже нижней полосы" wording -- plausible
    but not separately confirmed for the order-level use.
  - Orders 5/6's "CCI Levels (1m)" oversold threshold: the post names the
    indicator but gives no number for this specific (order-level) use
    (only the entry's 1h CCI has a stated threshold, <80, which is a
    ceiling not an oversold floor). Defaults to CCI(1m) < -100 (--cci-order-threshold),
    a standard oversold read -- a guess at the shape, not a confirmed value.
  - Mean Reversion Channel exit: MRC is not a single universally-defined
    indicator (several public versions exist under that name with
    different math) and the post gives no formula. This script
    approximates the described behaviour with a basis line
    (EMA(close, mrc_length), default 50 on the confirmed 5m interval)
    and treats "reaching the middle levels" as CLOSE CROSSING BACK ABOVE
    that basis line -- i.e. price reverting to its recent mean -- gated,
    as stated, by the 1% minimum P&L floor. This is a plausible
    approximation of the described BEHAVIOUR, not a verified replica of
    the real MRC formula Veles/latuserge actually uses.
  - "RSI on 1m as a local reversal marker": off by default
    (--use-rsi-filter to enable), since the post frames it as
    supplementary rather than one of the "five conditions" -- and gives
    no threshold for it either (default <30/>70 --rsi-length 14 if
    enabled).

Fees, split-sample validation: same conventions as the rest of this
project (see FEE_SCENARIOS below).

Needs network access to Bybit's public API -- run on your own machine:

    python long_strategy15_latuserge_backtest.py --symbol SOLUSDT --bars 200000
"""
from __future__ import annotations

import argparse
import csv
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np
import pandas as pd
import requests

from app.data import BYBIT_BASE, INTERVAL_MAP, DataError
from app.indicators.common import cci, rsi, ema, sma, stdev, dmi_adx
from app.indicators.veles_style import atr_percent, keltner_channel, htf_closed_series

# CONFIRMED 2026-09-04 from real account fee screenshots (both exchanges,
# futures only -- this account does not trade spot). Round-trip rates
# (entry+exit combined), replacing the old generic placeholder guess.
# Bybit futures, "Обычный пользователь" tier, 10% MNT discount currently
# ACTIVE: maker 0.0324%, taker 0.0900% per fill.
# OKX futures, "Обычные пользователи" tier, no discount toggle shown:
# maker 0.0200%, taker 0.0500% per fill.
FEE_SCENARIOS = {
    "bybit_taker+taker": 0.0018,
    "bybit_taker+maker": 0.001224,
    "bybit_maker+maker": 0.000648,
    "okx_taker+taker": 0.0010,
    "okx_taker+maker": 0.0007,
    "okx_maker+maker": 0.0004,
}


# --------------------------------------------------------------- data --

def _fetch_page(params: dict, symbol: str, retries: int = 4, timeout: float = 15.0) -> dict:
    # Hardened 2026-09-05 after a real incident: running a heavy multi-symbol
    # backtest at the same time as the live bot on the same API key hit
    # Bybit's rate limit ("Too many visits. Exceeded the API Rate Limit."),
    # which comes back as a normal HTTP 200 with retCode != 0 -- the original
    # code only retried on network exceptions, so a rate-limit hit raised
    # DataError immediately with zero retries. Now retries on retCode != 0
    # too, with the same backoff as network errors.
    last_exc: Exception | None = None
    for attempt in range(retries):
        try:
            resp = requests.get(f"{BYBIT_BASE}/v5/market/kline", params=params, timeout=timeout)
            resp.raise_for_status()
            payload = resp.json()
            if payload.get("retCode") == 0:
                return payload
            last_exc = RuntimeError(f"retCode={payload.get('retCode')} {payload.get('retMsg')}")
        except requests.RequestException as exc:
            last_exc = exc
        if attempt < retries - 1:
            time.sleep(1.5 * (attempt + 1))
    raise DataError(f"Bybit request failed for {symbol} after {retries} attempts: {last_exc}")


def fetch_history(symbol: str, timeframe: str, total_bars: int, category: str = "linear") -> pd.DataFrame:
    interval = INTERVAL_MAP[timeframe]
    all_rows: list = []
    end = None
    while len(all_rows) < total_bars:
        params = {"category": category, "symbol": symbol, "interval": interval, "limit": 1000}
        if end is not None:
            params["end"] = end
        payload = _fetch_page(params, symbol)
        if payload.get("retCode") != 0:
            raise DataError(f"Bybit API error for {symbol}: {payload.get('retMsg')}")
        rows = payload["result"]["list"]
        if not rows:
            break
        all_rows.extend(rows)
        oldest_ts = int(rows[-1][0])
        end = oldest_ts - 1
        if len(rows) < 1000:
            break
        time.sleep(0.6)

    if not all_rows:
        raise DataError(f"No kline data returned for {symbol} {timeframe}")

    df = pd.DataFrame(all_rows, columns=["open_time", "open", "high", "low", "close", "volume", "turnover"])
    df["open_time"] = df["open_time"].astype("int64")
    df = df.drop_duplicates(subset="open_time")
    for col in ("open", "high", "low", "close", "volume", "turnover"):
        df[col] = df[col].astype(float)
    df["open_time"] = pd.to_datetime(df["open_time"], unit="ms", utc=True)
    df = df.sort_values("open_time").reset_index(drop=True)
    if len(df) > total_bars:
        df = df.tail(total_bars).reset_index(drop=True)

    # Diagnostic added 2026-09-04: surface the real fetched date range and
    # flag any gaps in the candle series. Triggered by a real finding --
    # a run requesting the same --bars 200000 for six symbols produced a
    # ~139-day span for three (SUI/INJ/TIA, newer listings) but a ~345-day
    # span for the other three (ETH/SOL/ARB, deep history) despite an
    # identical bar count, implying non-contiguous/gappy data rather than
    # a genuine 200000-consecutive-minute window for the latter three.
    if len(df) > 1:
        step_seconds = df["open_time"].diff().dt.total_seconds()
        expected_step = step_seconds.median()
        max_gap = step_seconds.max()
        max_gap_idx = step_seconds.idxmax()
        span_days = (df["open_time"].iloc[-1] - df["open_time"].iloc[0]).days
        print(f"  [fetch_history] {symbol}: {len(df)} bars, "
              f"{df['open_time'].iloc[0]} -> {df['open_time'].iloc[-1]} "
              f"({span_days} days)")
        if pd.notna(max_gap) and max_gap > expected_step * 3:
            print(f"  [fetch_history] WARNING: {symbol} has a gap of "
                  f"{max_gap/60:.1f} min (expected ~{expected_step/60:.1f} min "
                  f"between bars) right before "
                  f"{df['open_time'].iloc[max_gap_idx]} -- data is likely "
                  f"NON-CONTIGUOUS, treat this run's results as unreliable "
                  f"until re-fetched.")
    return df


# ----------------------------------------------------------- indicators --

def cmo(close: pd.Series, length: int) -> pd.Series:
    """Chande Momentum Oscillator: 100 * (sum(up) - sum(down)) /
    (sum(up) + sum(down)) over a simple (non-smoothed) rolling window --
    the classic Chande formula, distinct from RSI's Wilder-smoothed
    version. Not in app/indicators/common.py yet (added here since its
    exact Veles length is UNCONFIRMED -- see module docstring)."""
    diff = close.diff()
    up = diff.clip(lower=0)
    down = -diff.clip(upper=0)
    sum_up = up.rolling(length, min_periods=length).sum()
    sum_down = down.rolling(length, min_periods=length).sum()
    total = (sum_up + sum_down).replace(0, np.nan)
    return 100.0 * (sum_up - sum_down) / total


def williams_r(df: pd.DataFrame, length: int) -> pd.Series:
    hh = df["high"].rolling(length, min_periods=length).max()
    ll = df["low"].rolling(length, min_periods=length).min()
    return (hh - df["close"]) / (hh - ll).replace(0, np.nan) * -100.0


def bollinger_lower(close: pd.Series, length: int, mult: float) -> pd.Series:
    basis = sma(close, length)
    return basis - mult * stdev(close, length)


# ------------------------------------------------------------- params --

GRID = [
    (0.04, 6.66),
    (6.0, 8.0),
    (15.0, 13.0),
    (28.0, 16.0),
    (40.0, 30.0),
    (65.0, 26.34),
]


@dataclass
class Params:
    cci_length: int
    cmo_length: int
    wr_length: int
    bb_length: int
    bb_mult: float
    atr_length: int
    adx_di_length: int
    adx_smoothing: int
    kc_length: int
    kc_mult: float
    cci_order_threshold: float
    mrc_length: int
    min_pnl_pct: float
    use_rsi_filter: bool
    rsi_length: int
    max_deal_bars: int


@dataclass
class Deal:
    symbol: str
    entry_time: pd.Timestamp
    exit_time: pd.Timestamp | None
    orders_filled: int
    filled_pct: float
    avg_entry_price: float
    exit_price: float | None
    reason: str  # "TP" | "TIMEOUT" | "OPEN_AT_CUTOFF"
    bars_held: int
    gross_pnl_pct: float | None
    meta: dict = field(default_factory=dict)


def compute_indicators(df: pd.DataFrame, p: Params) -> dict:
    cci_1h = htf_closed_series(df, 60, lambda h: cci((h["high"] + h["low"] + h["close"]) / 3, p.cci_length))
    cmo_30m = htf_closed_series(df, 30, lambda h: cmo(h["close"], p.cmo_length))
    wr_30m = htf_closed_series(df, 30, lambda h: williams_r(h, p.wr_length))
    bb_low_15m = htf_closed_series(df, 15, lambda h: bollinger_lower(h["close"], p.bb_length, p.bb_mult))
    close_15m = htf_closed_series(df, 15, lambda h: h["close"])
    atr_pct_5m = htf_closed_series(df, 5, lambda h: atr_percent(h, p.atr_length))

    entry_raw = (
        (cci_1h < 80) & (cmo_30m > -90) & (wr_30m < -80) &
        (close_15m < bb_low_15m) & (atr_pct_5m > 0.5)
    )
    if p.use_rsi_filter:
        rsi_1m = rsi(df["close"], p.rsi_length)
        entry_raw = entry_raw & (rsi_1m < 30)
    entry_raw = entry_raw.fillna(False)
    entry_signal = entry_raw & ~entry_raw.shift(1).fillna(False)

    defined_parts = [cci_1h.notna(), cmo_30m.notna(), wr_30m.notna(), bb_low_15m.notna(), atr_pct_5m.notna()]
    entry_defined = defined_parts[0]
    for d in defined_parts[1:]:
        entry_defined = entry_defined & d

    # ---- per-order gating series ----
    adx_15m = htf_closed_series(df, 15, lambda h: dmi_adx(h, p.adx_di_length, p.adx_smoothing))
    bb_low_5m = htf_closed_series(df, 5, lambda h: bollinger_lower(h["close"], p.bb_length, p.bb_mult))
    close_5m = htf_closed_series(df, 5, lambda h: h["close"])
    _, _, kc_low_5m = keltner_channel(df, length=p.kc_length, mult=p.kc_mult, use_true_range=True)
    kc_low_5m_htf = htf_closed_series(df, 5, lambda h: keltner_channel(h, length=p.kc_length, mult=p.kc_mult)[2])
    cci_1m = cci((df["high"] + df["low"] + df["close"]) / 3, p.cci_length)

    order_conditions: dict[int, pd.Series] = {
        2: ((adx_15m > 40) & (cmo_30m > -90)).fillna(False),
        3: ((close_5m < bb_low_5m) & (cmo_30m > -90)).fillna(False),
        4: ((df["close"] < kc_low_5m_htf) & (cmo_30m > -90)).fillna(False),
        5: ((cci_1m < p.cci_order_threshold) & (cmo_30m > -90)).fillna(False),
        6: ((cci_1m < p.cci_order_threshold) & (cmo_30m > -90)).fillna(False),
    }

    # ---- exit: MRC APPROXIMATION -- see module docstring ----
    mrc_basis_5m = htf_closed_series(df, 5, lambda h: ema(h["close"], p.mrc_length))
    tp_signal = (df["close"] > mrc_basis_5m).fillna(False)

    return {
        "entry_signal": entry_signal, "entry_defined": entry_defined,
        "order_conditions": order_conditions, "tp_signal": tp_signal,
    }


# --------------------------------------------------------- walk-forward --

def simulate_symbol(df: pd.DataFrame, symbol: str, p: Params) -> list[Deal]:
    ind = compute_indicators(df, p)
    entry_signal = ind["entry_signal"]
    entry_defined = ind["entry_defined"]
    order_conditions = ind["order_conditions"]
    tp_signal = ind["tp_signal"]

    n = len(df)
    first_valid = entry_defined.idxmax() if entry_defined.any() else None
    if first_valid is None:
        return []

    close = df["close"].to_numpy()
    low = df["low"].to_numpy()

    deals: list[Deal] = []
    i = int(first_valid)
    in_deal = False
    orders: list[dict] = []
    next_order_idx = 2
    base_price = 0.0
    deal_start_bar = -1

    def avg_entry_and_filled_pct():
        total_vol = sum(o["vol_pct"] for o in orders)
        weighted = sum(o["vol_pct"] * o["price"] for o in orders)
        return (weighted / total_vol), total_vol

    while i < n:
        if not in_deal:
            if bool(entry_signal.iloc[i]):
                base_price = close[i]
                orders = [{"price": base_price, "vol_pct": GRID[0][1]}]
                next_order_idx = 2
                deal_start_bar = i
                in_deal = True
            i += 1
            continue

        if next_order_idx <= len(GRID):
            eff_offset, vol_pct = GRID[next_order_idx - 1]
            limit_price = base_price * (1 - eff_offset / 100.0)
            cond = order_conditions.get(next_order_idx)
            cond_true = bool(cond.iloc[i]) if cond is not None else True
            if low[i] <= limit_price and cond_true:
                orders.append({"price": limit_price, "vol_pct": vol_pct})
                next_order_idx += 1

        avg_entry, filled_pct = avg_entry_and_filled_pct()
        pnl_now = (close[i] - avg_entry) / avg_entry * 100.0

        closed = False
        if bool(tp_signal.iloc[i]) and pnl_now >= p.min_pnl_pct:
            deals.append(Deal(
                symbol=symbol, entry_time=df["open_time"].iloc[deal_start_bar],
                exit_time=df["open_time"].iloc[i], orders_filled=len(orders),
                filled_pct=filled_pct, avg_entry_price=avg_entry, exit_price=close[i],
                reason="TP", bars_held=i - deal_start_bar, gross_pnl_pct=pnl_now,
            ))
            closed = True
        elif (i - deal_start_bar) >= p.max_deal_bars:
            deals.append(Deal(
                symbol=symbol, entry_time=df["open_time"].iloc[deal_start_bar],
                exit_time=df["open_time"].iloc[i], orders_filled=len(orders),
                filled_pct=filled_pct, avg_entry_price=avg_entry, exit_price=close[i],
                reason="TIMEOUT", bars_held=i - deal_start_bar, gross_pnl_pct=pnl_now,
            ))
            closed = True

        if closed:
            in_deal = False
            orders = []
        i += 1

    if in_deal:
        avg_entry, filled_pct = avg_entry_and_filled_pct()
        last_close = close[-1]
        gross = (last_close - avg_entry) / avg_entry * 100.0
        deals.append(Deal(
            symbol=symbol, entry_time=df["open_time"].iloc[deal_start_bar],
            exit_time=df["open_time"].iloc[-1], orders_filled=len(orders),
            filled_pct=filled_pct, avg_entry_price=avg_entry, exit_price=last_close,
            reason="OPEN_AT_CUTOFF", bars_held=(n - 1) - deal_start_bar, gross_pnl_pct=gross,
        ))

    return deals


# --------------------------------------------------------------- report --

def net_pnl_pct(deal: Deal, fee_rate: float) -> float | None:
    if deal.gross_pnl_pct is None:
        return None
    return deal.gross_pnl_pct - fee_rate * 100.0


def summarize(deals: list[Deal], label: str) -> None:
    if not deals:
        print(f"\n{label}: no deals opened in this window.")
        return
    resolved = [d for d in deals if d.reason in ("TP", "TIMEOUT")]
    still_open = [d for d in deals if d.reason == "OPEN_AT_CUTOFF"]
    wins = [d for d in resolved if d.gross_pnl_pct is not None and d.gross_pnl_pct > 0]
    win_rate = (len(wins) / len(resolved) * 100) if resolved else float("nan")
    avg_gross = (sum(d.gross_pnl_pct for d in resolved) / len(resolved)) if resolved else float("nan")
    avg_orders = (sum(d.orders_filled for d in deals) / len(deals)) if deals else float("nan")

    print(f"\n{label}")
    print(f"  Total deals opened:      {len(deals)}")
    print(f"  Resolved (TP/timeout):   {len(resolved)}   Still open at cutoff: {len(still_open)}")
    print(f"  Avg orders filled/deal:  {avg_orders:.2f}")
    print(f"  Gross win rate:          {win_rate:.1f}%")
    print(f"  Gross avg P&L% (invested):{avg_gross:+.2f}%")
    reasons = {}
    for d in resolved:
        reasons[d.reason] = reasons.get(d.reason, 0) + 1
    print(f"  Exit reasons: {reasons}")

    for label_fee, fee_rate in FEE_SCENARIOS.items():
        nets = [net_pnl_pct(d, fee_rate) for d in resolved]
        nets = [x for x in nets if x is not None]
        if not nets:
            continue
        net_wins = sum(1 for x in nets if x > 0)
        print(f"    net P&L% after {label_fee:12s} fees: {sum(nets)/len(nets):+.2f}%  "
              f"win rate {net_wins/len(nets)*100:.1f}%")


def save_csv(deals: list[Deal], path: Path) -> None:
    if not deals:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = ["symbol", "entry_time", "exit_time", "orders_filled", "filled_pct",
                  "avg_entry_price", "exit_price", "reason", "bars_held", "gross_pnl_pct"]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for d in deals:
            writer.writerow({k: getattr(d, k) for k in fieldnames})


def split_sample(deals: list[Deal]) -> tuple[list[Deal], list[Deal]]:
    resolved = sorted([d for d in deals if d.reason in ("TP", "TIMEOUT")], key=lambda d: d.entry_time)
    if len(resolved) < 4:
        return resolved, []
    mid = len(resolved) // 2
    return resolved[:mid], resolved[mid:]


# -------------------------------------------------------------------- --

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--symbol", nargs="+", default=["SOLUSDT"])
    parser.add_argument("--timeframe", default="1m")
    parser.add_argument("--bars", type=int, default=200000)
    parser.add_argument("--out", default="long_strategy15_latuserge_backtest_out")

    parser.add_argument("--cci-length", type=int, default=20, help="ASSUMED")
    parser.add_argument("--cmo-length", type=int, default=14, help="ASSUMED")
    parser.add_argument("--wr-length", type=int, default=14, help="ASSUMED")
    parser.add_argument("--bb-length", type=int, default=20, help="ASSUMED")
    parser.add_argument("--bb-mult", type=float, default=2.0, help="ASSUMED")
    parser.add_argument("--atr-length", type=int, default=14, help="ASSUMED")
    parser.add_argument("--adx-di-length", type=int, default=14, help="ASSUMED")
    parser.add_argument("--adx-smoothing", type=int, default=14, help="ASSUMED")
    parser.add_argument("--kc-length", type=int, default=20, help="ASSUMED")
    parser.add_argument("--kc-mult", type=float, default=2.0, help="ASSUMED")
    parser.add_argument("--cci-order-threshold", type=float, default=-100.0, help="ASSUMED -- see module docstring")
    parser.add_argument("--mrc-length", type=int, default=50, help="APPROXIMATED -- see module docstring")

    parser.add_argument("--min-pnl-pct", type=float, default=1.0, help="CONFIRMED from blog post")
    parser.add_argument("--use-rsi-filter", action="store_true", help="Enable the blog's optional 1m RSI 'local reversal' filter (off by default)")
    parser.add_argument("--rsi-length", type=int, default=14, help="ASSUMED, only used with --use-rsi-filter")
    parser.add_argument("--max-deal-bars", type=int, default=50000, help="safety timeout only, not part of the real bot")

    args = parser.parse_args()
    p = Params(
        cci_length=args.cci_length, cmo_length=args.cmo_length, wr_length=args.wr_length,
        bb_length=args.bb_length, bb_mult=args.bb_mult, atr_length=args.atr_length,
        adx_di_length=args.adx_di_length, adx_smoothing=args.adx_smoothing,
        kc_length=args.kc_length, kc_mult=args.kc_mult,
        cci_order_threshold=args.cci_order_threshold, mrc_length=args.mrc_length,
        min_pnl_pct=args.min_pnl_pct, use_rsi_filter=args.use_rsi_filter, rsi_length=args.rsi_length,
        max_deal_bars=args.max_deal_bars,
    )

    print(__doc__)
    print("=" * 78)

    out_dir = Path(args.out)
    all_deals: list[Deal] = []
    for symbol in args.symbol:
        symbol = symbol.upper()
        print(f"\nFetching + simulating {symbol} ({args.bars} bars of {args.timeframe})...")
        try:
            df = fetch_history(symbol, args.timeframe, args.bars)
            deals = simulate_symbol(df, symbol, p)
        except DataError as exc:
            print(f"  [SKIP] {symbol}: {exc}")
            continue
        print(f"  {len(df)} bars, {df['open_time'].iloc[0]} .. {df['open_time'].iloc[-1]}")
        summarize(deals, symbol)
        save_csv(deals, out_dir / f"{symbol}_deals.csv")

        early, late = split_sample(deals)
        if early and late:
            summarize(early, f"  {symbol} -- EARLY half (split-sample)")
            summarize(late, f"  {symbol} -- LATE half (split-sample)")

        all_deals.extend(deals)
        time.sleep(2.0)  # 2026-09-05: avoid a rate-limit collision with the live bot on the same API key

    summarize(all_deals, "=== COMBINED (all symbols) ===")
    print(f"\nPer-deal CSVs written to {out_dir.resolve()}")


if __name__ == "__main__":
    main()
