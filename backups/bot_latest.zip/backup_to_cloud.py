"""backup_to_cloud.py — 2026-11-21: ночной бэкап проекта в GitHub.

Архивирует в zip: код (*.py и др.), конфиги (*.json), state-файлы ботов,
trades-CSV и статику панели — и заливает одним файлом backups/bot_latest.zip
в тот же репозиторий, куда публикуется Mini App (Settings.github_repo).
История версий хранится самим git-репозиторием (каждая заливка — коммит).

СЕКРЕТЫ НЕ КОПИРУЮТСЯ: .env, *_keys.json, ai_key.json, ngrok.json,
mobile_auth.json — исключены по имени. Проверка списка файлов: запусти
с --dry-run и посмотри вывод.

Заливка — через Git Data API (blob→tree→commit→ref), т.к. Contents API
(github_sync.push_binary_file) не принимает файлы больше ~1 МБ.

Запуск:       .\\venv\\Scripts\\python.exe backup_to_cloud.py
Без заливки:  .\\venv\\Scripts\\python.exe backup_to_cloud.py --dry-run
"""
from __future__ import annotations

import fnmatch
import json
import sys
import time
import zipfile
from pathlib import Path

from app.config import BASE_DIR, Settings
from app.github_sync import GITHUB_API, GitHubSyncError, _req

# --- что собираем -----------------------------------------------------------
INCLUDE_EXT = {
    ".py", ".bat", ".ps1", ".cmd", ".md", ".txt", ".json", ".csv",
    ".cjs", ".js", ".html", ".css", ".cfg", ".ini", ".toml", ".yaml", ".yml",
    ".example",
}
SECRET_NAMES = {".env", "ai_key.json", "ngrok.json", "mobile_auth.json",
                "authorized_users.json"}  # список Telegram-ID — приватные данные, в публичный репо не надо
SECRET_GLOBS = ("*_keys.json",)
EXCLUDE_DIRS = {
    "venv", "node_modules", "logs", "windows_app_logs", "market_cache",
    "market_cache_tf", "bt_lab_out", "bt_lab_bots", "tg_export",
    "tg_export_strat", "tg_candidates", "webview_data", "combo_okx",
    "strats_okx", "build", "dist", "release", "__pycache__",
    "okx_native_cache", "liq_data", "generic_backtest_out",
    "momentum_joined", "Claude outputs", "_backups", ".git", "user_files",
    "kc_roc_cci_wt_grid_backtest_out",
}
EXCLUDE_DIR_PREFIXES = ("backtest_out",)
EXCLUDE_FILE_GLOBS = ("published_backup_*.html", "*.log", "*.lock")

REMOTE_PATH = "backups/bot_latest.zip"


def collect_files() -> list[Path]:
    """Список файлов бэкапа: whitelist расширений минус секреты и мусор.
    os.walk с отсечением исключённых папок — rglob ходил бы и по market_cache."""
    import os
    out = []
    for root, dirs, names in os.walk(BASE_DIR):
        dirs[:] = [d for d in dirs
                   if d not in EXCLUDE_DIRS and not d.startswith(EXCLUDE_DIR_PREFIXES)]
        for name in names:
            p = Path(root) / name
            low = name.lower()
            if low in SECRET_NAMES or any(fnmatch.fnmatch(low, g) for g in SECRET_GLOBS):
                continue
            if any(fnmatch.fnmatch(low, g) for g in EXCLUDE_FILE_GLOBS):
                continue
            if p.suffix.lower() not in INCLUDE_EXT and low != ".env.example":
                continue
            out.append(p.relative_to(BASE_DIR))
    return sorted(out)


def build_zip(files: list[Path], dest: Path) -> int:
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for rel in files:
            z.write(BASE_DIR / rel, str(rel))
    return dest.stat().st_size


# --- заливка в GitHub через Git Data API (файл может быть > 1 МБ) -----------
def push_big_file(token: str, repo: str, path: str, data: bytes, message: str) -> None:
    h = {"Authorization": f"Bearer {token}", "Accept": "application/vnd.github+json"}
    repo_url = f"{GITHUB_API}/repos/{repo}"

    blob = _req("post", f"{repo_url}/git/blobs", headers=h,
                json={"content": __import__("base64").b64encode(data).decode("ascii"),
                      "encoding": "base64"})
    if blob.status_code != 201:
        raise GitHubSyncError(f"blob: {blob.status_code} {blob.text[:300]}")
    blob_sha = blob.json()["sha"]

    ref = _req("get", f"{repo_url}/git/ref/heads/main", headers=h)
    if ref.status_code != 200:
        raise GitHubSyncError(f"ref: {ref.status_code} {ref.text[:300]}")
    base_commit = ref.json()["object"]["sha"]
    commit = _req("get", f"{repo_url}/git/commits/{base_commit}", headers=h).json()

    tree = _req("post", f"{repo_url}/git/trees", headers=h, json={
        "base_tree": commit["tree"]["sha"],
        "tree": [{"path": path, "mode": "100644", "type": "blob", "sha": blob_sha}],
    })
    if tree.status_code != 201:
        raise GitHubSyncError(f"tree: {tree.status_code} {tree.text[:300]}")

    new_commit = _req("post", f"{repo_url}/git/commits", headers=h, json={
        "message": message, "tree": tree.json()["sha"], "parents": [base_commit],
    })
    if new_commit.status_code != 201:
        raise GitHubSyncError(f"commit: {new_commit.status_code} {new_commit.text[:300]}")

    upd = _req("patch", f"{repo_url}/git/refs/heads/main", headers=h,
               json={"sha": new_commit.json()["sha"]})
    if upd.status_code != 200:
        raise GitHubSyncError(f"ref update: {upd.status_code} {upd.text[:300]}")


def main() -> int:
    dry_run = "--dry-run" in sys.argv
    files = collect_files()
    total_raw = sum((BASE_DIR / f).stat().st_size for f in files)

    print(f"Файлов в архиве: {len(files)}, распакованных байт: {total_raw:,}")
    for rel in files:
        print(f"  {rel}  ({(BASE_DIR / rel).stat().st_size:,})")

    dest = Path(__import__("tempfile").gettempdir()) / "vantorix_bot_backup.zip"
    zipped = build_zip(files, dest)
    print(f"\nАрхив: {dest} — {zipped:,} байт ({zipped / 2**20:.1f} МБ)")

    if dry_run:
        print("\n--dry-run: ничего не залито.")
        return 0

    settings = Settings.load()
    if not settings.github_token:
        print("GITHUB_TOKEN пуст в .env — заливать нечем.", file=sys.stderr)
        return 1
    push_big_file(settings.github_token, settings.github_repo, REMOTE_PATH,
                  dest.read_bytes(),
                  f"backup bot {time.strftime('%Y-%m-%d %H:%M')} (VANTORIX nightly)")
    print(f"Опубликовано: {REMOTE_PATH} в {settings.github_repo}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
