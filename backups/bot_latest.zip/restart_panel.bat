@echo off
chcp 65001 >nul
rem 2026-10-11: путь к боту прописан явно — файл можно запускать с рабочего стола или из ярлыка
cd /d "D:\VANTORIX\bot" || (echo Не найдена папка D:\VANTORIX\bot & pause & exit /b)
"D:\VANTORIX\bot\venv\Scripts\python.exe" bot_services.py stop panel
timeout /t 2 >nul
"D:\VANTORIX\bot\venv\Scripts\python.exe" bot_services.py start panel
echo.
echo Панель перезапущена. Обнови страницу стакана: Ctrl+F5.
timeout /t 5
