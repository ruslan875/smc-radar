"""kvoo_longtest.py — 2026-10-04. Проверка волн SATTAM|KVOO на длинной истории (Binance USDT-фьючерсы, с 2019 г.).
Качает 1h и 4h свечи (публичные данные, без ключей) в market_cache/binance/, затем гоняет ту же логику, что в TRADEOS:
CALL/PUT = закрытие ушло от края волны на k·ATR14 (Скальп 1.75 / Свинг 2 / Инвест 3), вход по закрытию,
стоп за краем волны ±0.3 ATR, тейк 1R/2R/3R или до противоположного сигнала, комиссия 0.11%.
Итог по годам — в консоли и в kvoo_longtest.csv. Запуск: kvoo_longtest.bat
"""
import csv, sys, time
from pathlib import Path
import numpy as np, pandas as pd, requests

BASE = Path(__file__).resolve().parent
CACHE = BASE / "market_cache" / "binance"; CACHE.mkdir(parents=True, exist_ok=True)
COINS = ["BTCUSDT", "ETHUSDT", "XRPUSDT", "DOGEUSDT", "ADAUSDT", "SOLUSDT", "LINKUSDT", "LTCUSDT", "BNBUSDT", "AVAXUSDT", "TAOUSDT", "HYPEUSDT"]
TFS = {"1h": 3600_000, "4h": 4 * 3600_000}


def load(sym, tf):
    f = CACHE / f"{sym}_{tf}.csv"
    rows = []
    if f.exists():
        rows = pd.read_csv(f).values.tolist()
    start = int(rows[-1][0]) + TFS[tf] if rows else int(pd.Timestamp("2019-01-01", tz="UTC").timestamp() * 1000)
    now = int(time.time() * 1000)
    while start < now - TFS[tf]:
        try:
            r = requests.get("https://fapi.binance.com/fapi/v1/klines", params={"symbol": sym, "interval": tf, "startTime": start, "limit": 1500}, timeout=20)
            k = r.json()
        except Exception as exc:  # noqa: BLE001
            print("  сеть:", exc); time.sleep(3); continue
        if not isinstance(k, list) or not k:
            break
        rows += [[int(x[0]), float(x[1]), float(x[2]), float(x[3]), float(x[4]), float(x[5])] for x in k]
        start = int(k[-1][0]) + TFS[tf]
        print(f"\r  {sym} {tf}: {pd.to_datetime(start, unit='ms'):%Y-%m-%d}   ", end="")
        time.sleep(0.15)
    print()
    if not rows:
        return None
    d = pd.DataFrame(rows, columns=["t", "o", "h", "l", "c", "v"]).drop_duplicates("t").sort_values("t")
    d.to_csv(f, index=False)
    return d.reset_index(drop=True)


def signals(d, amp):
    h, l, c = d.h.values, d.l.values, d.c.values
    pc = np.r_[c[0], c[:-1]]; tr = np.maximum(h - l, np.maximum(abs(h - pc), abs(l - pc)))
    atr = pd.Series(tr).ewm(alpha=1 / 14, adjust=False).mean().values
    out = []; z = 1; ext = h[0]
    for i in range(1, len(c)):
        if z > 0:
            ext = max(ext, h[i])
            if ext - c[i] >= amp * atr[i]:
                out.append((i, -1, ext + 0.3 * atr[i])); z = -1; ext = l[i]
        else:
            ext = min(ext, l[i])
            if c[i] - ext >= amp * atr[i]:
                out.append((i, 1, ext - 0.3 * atr[i])); z = 1; ext = h[i]
    return out


def bt(d, S, rr, fee=0.0011):
    h, l, c, t = d.h.values, d.l.values, d.c.values, d.t.values; n = len(c); res = []; nxt = 0
    for k, (i, sd, st) in enumerate(S):
        if i < nxt or i >= n - 1:
            continue
        e = c[i]; risk = abs(e - st)
        if risk <= 0:
            continue
        tp = e + sd * rr * risk if rr else None
        end = S[k + 1][0] if k + 1 < len(S) else n - 1
        out = None
        for j in range(i + 1, n):
            if (l[j] <= st) if sd > 0 else (h[j] >= st):
                out = (j, -1.0); break
            if tp is not None and ((h[j] >= tp) if sd > 0 else (l[j] <= tp)):
                out = (j, rr); break
            if tp is None and j >= end:
                out = (j, sd * (c[j] - e) / risk); break
        if out is None:
            out = (n - 1, sd * (c[-1] - e) / risk)
        res.append((pd.to_datetime(t[i], unit="ms").year, out[1] - fee * e / risk)); nxt = out[0] + 1
    return res


def main():
    table = []
    for sym in COINS:
        for tf in TFS:
            print(f"{sym} {tf}: свечи…")
            d = load(sym, tf)
            if d is None or len(d) < 500:
                print("  нет данных"); continue
            for amp, nm in ((1.75, "Скальп"), (2.0, "Свинг"), (3.0, "Инвест")):
                S = signals(d, amp)
                for rr in (1, 2, 3, None):
                    r = bt(d, S, rr)
                    if not r:
                        continue
                    R = np.array([x[1] for x in r]); g, b = R[R > 0].sum(), -R[R < 0].sum()
                    yrs = {}
                    for y, v in r:
                        yrs[y] = yrs.get(y, 0) + v
                    row = {"coin": sym, "tf": tf, "mode": nm, "exit": f"{rr}R" if rr else "разворот", "trades": len(R),
                           "wr": round((R > 0).mean() * 100, 1), "pf": round(g / b, 2) if b else 99, "total_R": round(R.sum(), 1),
                           "years_plus": sum(1 for v in yrs.values() if v > 0), "years": len(yrs),
                           **{str(y): round(v, 1) for y, v in sorted(yrs.items())}}
                    table.append(row)
    keys = sorted({k for r in table for k in r}, key=lambda k: (k[0].isdigit(), k))
    with open(BASE / "kvoo_longtest.csv", "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.DictWriter(fh, fieldnames=keys, delimiter=";"); w.writeheader(); w.writerows(table)
    print("\n=== Сводка: 4h Свинг 2R и 1h Свинг 2R по монетам (итог R, PF, лет в плюсе) ===")
    for r in table:
        if r["mode"] == "Свинг" and r["exit"] == "2R":
            ys = " ".join(f"{k}:{r[k]:+.0f}" for k in sorted(r) if k.isdigit())
            print(f"{r['coin']:<9} {r['tf']}  сделок {r['trades']:>4}  PF {r['pf']:<5} итог {r['total_R']:+7.1f}R  лет в плюсе {r['years_plus']}/{r['years']}   {ys}")
    tot = {}
    for r in table:
        k = (r["tf"], r["mode"], r["exit"]); tot.setdefault(k, [0, 0, 0])
        tot[k][0] += r["total_R"]; tot[k][1] += 1; tot[k][2] += r["total_R"] > 0
    print("\n=== Все монеты вместе ===")
    for k, v in sorted(tot.items(), key=lambda x: -x[1][0]):
        print(f"{k[0]} {k[1]:<7} {k[2]:<9} сумма {v[0]:+8.1f}R   монет в плюсе {v[2]}/{v[1]}")
    print("\nПодробно: kvoo_longtest.csv")
    input("\nEnter — закрыть")


if __name__ == "__main__":
    main()
