@echo off
cd /d "%~dp0"
echo Resume paper bots stopped in the last 12 hours
venv\Scripts\python.exe lab_bots_resume.py %*
pause
