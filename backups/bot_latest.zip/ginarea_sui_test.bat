@echo off
cd /d D:\VANTORIX\bot
venv\Scripts\python.exe ginarea_sui_test.py %1 %2
pause
