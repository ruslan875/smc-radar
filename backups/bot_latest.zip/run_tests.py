"""run_tests.py — запуск тестов одним файлом. Показывает ход прямо в окне, пишет лог, в конце — итоги (строки с ✅).
  python run_tests.py indicators   → 5 присланных индикаторов
  python run_tests.py all          → все тесты
"""
import os, subprocess, sys
from pathlib import Path
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass
BASE = Path(__file__).resolve().parent
SETS = {"indicators": ["falsebreak_ind_test", "lux_fbo_test", "tbo_test", "atr_filters_test"],
        "all": ["channel_test", "fvg_test", "fx_multi_test", "fx_fvg_test", "gerchik_test",
                "falsebreak_ind_test", "lux_fbo_test", "tbo_test", "atr_filters_test"]}
which = sys.argv[1] if len(sys.argv) > 1 else "indicators"
log = BASE / f"{which}_log.txt"
env = dict(os.environ, PYTHONIOENCODING="utf-8", PYTHONUTF8="1")
summary = []
with open(log, "w", encoding="utf-8") as L:
    for name in SETS[which]:
        head = f"===================== {name} ====================="
        print(head, flush=True); L.write(head + "\n")
        if not (BASE / f"{name}.py").exists():
            msg = f"  нет файла {name}.py"; print(msg); L.write(msg + "\n"); summary.append(head); summary.append(msg); continue
        p = subprocess.Popen([sys.executable, "-X", "utf8", str(BASE / f"{name}.py")], cwd=BASE, env=env, stdin=subprocess.PIPE,
                             stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace")
        p.stdin.write("\n"); p.stdin.close()
        summary.append(head)
        for line in p.stdout:
            line = line.rstrip("\n"); L.write(line + "\n")
            if line.startswith(("свечи", "загрузка", "  ")) or not line.strip():
                print(".", end="", flush=True); continue
            print("\n" + line, flush=True)
            if "✅" in line or "Traceback" in line or "Error" in line or ("фильтр" in line and "|" in line):
                summary.append(line)
        p.wait(); print()
print("\n\n===== ИТОГИ =====")
for s in summary:
    print(s)
print(f"\nСтроки с ✅ прошли проверку. Полный вывод: {log.name}")
