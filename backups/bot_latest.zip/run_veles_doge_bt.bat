@echo off
cd /d "%~dp0"
echo Veles DOGE DCA clone backtest 2024-2026 (first run downloads 1m candles, 10-20 min)
venv\Scripts\python.exe veles_doge_dca_bt.py
pause
