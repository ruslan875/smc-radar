"""grid_pnl_audit.py — 2026-11-04. Где теряют реальные сетки Bybit (Latuserge, KC/ROC). Только чтение.
Берёт closedPnl Bybit за 30 дней (общий ключ, уже с комиссиями) и привязывает каждую запись к сделке бота
по монете и времени выхода (±10 мин). Остальное — «не от ботов» (ручные сделки и др.).
Отчёт: bt_lab_bots/grid_pnl_audit.txt
"""
import csv, datetime as dt, sys
from collections import defaultdict
from pathlib import Path
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
from app.exchanges import bybit as bx  # noqa: E402
from app.trade_keys_store import TradeKeysStore  # noqa: E402
OUT = BASE / "bt_lab_bots" / "grid_pnl_audit.txt"
BOTS = {"Latuserge": "long_strategy15_latuserge_live_trades.csv", "KC/ROC": "kc_roc_cci_wt_grid_live_trades.csv"}
L = []
def say(s=""): print(s); L.append(s)
cr = TradeKeysStore(BASE / "trade_keys.json").get_for_strategy("latuserge", "bybit")
df = bx.fetch_closed_trades(cr["api_key"], cr["api_secret"], lookback_days=30)
recs = df.to_dict("records") if df is not None and not df.empty else []
def ts(x):
    if isinstance(x, (int, float)): return float(x) / 1000
    try: return x.timestamp()
    except Exception: return dt.datetime.fromisoformat(str(x)).timestamp()
bt = []
for name, f in BOTS.items():
    for r in csv.DictReader(open(BASE / f, encoding="utf-8")):
        try: bt.append((name, r["symbol"], dt.datetime.fromisoformat(r["exit_time"]).timestamp(), r))
        except Exception: pass
agg = defaultdict(lambda: {"n": 0, "pnl": 0.0, "win": 0, "loss": 0.0, "big": []})
for rec in recs:
    t = ts(rec.get("updated_time") or rec.get("created_time")); s = rec["symbol"]; p = float(rec["closed_pnl"] or 0)
    m = min((b for b in bt if b[1] == s and abs(b[2] - t) < 600), key=lambda b: abs(b[2] - t), default=None)
    who = m[0] if m else "не от ботов (ручные/прочие)"
    a = agg[who]; a["n"] += 1; a["pnl"] += p
    if p > 0: a["win"] += p
    else: a["loss"] += p
    a["big"].append((p, s, dt.datetime.fromtimestamp(t).strftime("%d.%m %H:%M"), (m[3].get("reason") if m else "")))
say(f"Bybit closedPnl за 30 дней: {len(recs)} записей, итого {sum(float(r['closed_pnl'] or 0) for r in recs):+.2f} $ (с комиссиями)")
for who, a in sorted(agg.items(), key=lambda x: x[1]["pnl"]):
    say(""); say(f"== {who}: {a['n']} закрытий, итог {a['pnl']:+.2f} $  (плюсы {a['win']:+.2f} / минусы {a['loss']:+.2f})")
    for p, s, t, why in sorted(a["big"])[:8]: say(f"   {p:+8.2f} $  {s:<10} {t}  {why}")
    bys = defaultdict(float)
    for p, s, *_ in a["big"]: bys[s] += p
    say("   по монетам: " + ", ".join(f"{k} {v:+.2f}" for k, v in sorted(bys.items(), key=lambda x: x[1])))
OUT.write_text("\n".join(L), encoding="utf-8")
