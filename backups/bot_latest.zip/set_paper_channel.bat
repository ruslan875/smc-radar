@echo off
chcp 65001 >nul
cd /d D:\VANTORIX\bot
findstr /b /c:"TELEGRAM_PAPER_CHAT_ID=" .env >/dev/null 2>&1 && (echo Строка уже есть в .env - меняю...& powershell -NoProfile -Command "(Get-Content .env) -replace ^TELEGRAM_PAPER_CHAT_ID=.*,TELEGRAM_PAPER_CHAT_ID=-1003661949402 | Set-Content -Encoding UTF8 .env") || (echo.>>.env& echo TELEGRAM_PAPER_CHAT_ID=-1003661949402>>.env)
echo Готово: бумажный канал 1111 подключен. Теперь нажмите в терминале «Перезапуск ботов».
pause
