@echo off
cd /d "%~dp0"
chcp 65001 >nul
rem 2026-09-27: odin zapusk vsego paper/demo BEZ OKON i BEZ DUBLEY (bot_services.py).
rem Logi: papka logs\. Realnye boty (Latuserge, KC/ROC) zdes NE zapuskayutsya.
venv\Scripts\python.exe bot_services.py start
echo.
echo Panel: http://127.0.0.1:8780  -  vkladka Backtest - Fonovye processy
timeout /t 15
