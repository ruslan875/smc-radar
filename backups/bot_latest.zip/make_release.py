"""Сборка TRADEOS для передачи другим людям.

Запуск:  venv\\Scripts\\python.exe make_release.py
Результат: папка release\\TRADEOS и архив release\\TRADEOS-<дата>.zip

Что НЕ попадает в сборку (ваше личное):
  .env, любые файлы с key/secret/token/session/password в имени, authorized_users.json,
  логи, резервные копии, состояние ботов и риск-центра, журналы ваших сделок,
  скачанные свечи, venv, старые копии файлов (*.bak, v17..._*, *_old*).
Вместо .env кладётся .env.example — только НАЗВАНИЯ переменных, без значений.
В конце печатается список файлов, где в коде зашит путь D:\\VANTORIX — их надо поправить.
"""
from __future__ import annotations

import re
import shutil
import sys
import time
import zipfile
from pathlib import Path

BASE = Path(__file__).resolve().parent
OUT_ROOT = BASE / "release"
OUT = OUT_ROOT / "TRADEOS"

SKIP_DIRS = {"venv", ".venv", "__pycache__", ".git", "logs", "backups", "bots", "release",
             "candles", "candle_store", "data", "windows_app_logs", "node_modules", ".pytest_cache",
             "build", "dist", "bt_lab_out", "screenshots", "tmp", "temp"}
SECRET_WORDS = ("key", "secret", "token", "session", "password", "passwd", "credential", "authorized")
SKIP_NAMES = {".env", "authorized_users.json", "risk_state.json", "risk_settings.json",
              # личные заметки, тестовые запускалки и сама сборка — другому человеку не нужны
              "make_release.py", "make_release.bat", "start_tests.bat", "test_grid_configs.bat",
              "test_strategies.bat", "strategy_testing_checklist.md", "tradingview_mcp_setup_claude.md",
              "инструкция.md"}
SKIP_EXT = {".log", ".bak", ".parquet", ".db", ".sqlite", ".pkl", ".zip", ".csv"}
KEEP_EXT = {".py", ".bat", ".txt", ".md", ".json", ".html", ".js", ".css", ".png", ".webp", ".svg", ".ico", ".toml", ".cfg", ".ini"}
OLD_RE = re.compile(r"(^v\d{9,}_)|(_v\d{9,})|(_old)|(\.before-)|(\.broken)|(\.safe-)", re.I)
HARD_PATH_RE = re.compile(r"[A-Za-z]:\\\\?VANTORIX", re.I)


def is_secret(name: str) -> bool:
    low = name.lower()
    if low.startswith(".env"):
        return True
    stem = low.rsplit(".", 1)[0]
    return any(w in stem for w in SECRET_WORDS)


def wanted(p: Path) -> bool:
    rel = p.relative_to(BASE)
    if any(part in SKIP_DIRS for part in rel.parts[:-1]):
        return False
    n = p.name
    if n.lower() in SKIP_NAMES or is_secret(n) or OLD_RE.search(n):
        return False
    ext = p.suffix.lower()
    if ext in SKIP_EXT or ext not in KEEP_EXT:
        return False
    if n.endswith("_state.json") or n.startswith("paper_") and ext == ".json":
        return False                                  # состояние ваших paper-ботов
    return p.stat().st_size < 20 * 2**20


def env_example() -> str:
    lines = ["# Заполните сами. Ключам бирж давайте права «торговля» БЕЗ вывода средств.", ""]
    src = BASE / ".env"
    if src.exists():
        for raw in src.read_text(encoding="utf-8", errors="replace").splitlines():
            s = raw.strip()
            if not s or s.startswith("#") or "=" not in s:
                continue
            lines.append(s.split("=", 1)[0].strip() + "=")   # только имя, значение НЕ копируем
    else:
        lines += ["TELEGRAM_TOKEN=", "TELEGRAM_CHAT_ID="]
    return "\n".join(lines) + "\n"


# .bat только латиницей: cmd.exe читает файл до chcp и ломается на кириллице
INSTALL_BAT = r"""@echo off
cd /d "%~dp0bot"
echo TRADEOS setup. Requires Python 3.11+ from python.org ("Add to PATH" checked).
python -m venv venv
if errorlevel 1 (echo Python not found. Install it and run again. & pause & exit /b 1)
venv\Scripts\python.exe -m pip install --upgrade pip
if exist requirements.txt venv\Scripts\python.exe -m pip install -r requirements.txt
if not exist .env copy .env.example .env >nul
echo.
echo Done. Open bot\.env in Notepad, enter your keys, then run START.bat
pause
"""

START_BAT = r"""@echo off
cd /d "%~dp0bot"
venv\Scripts\python.exe bot_services.py start
venv\Scripts\python.exe bot_services.py status
timeout /t 8
"""

README = """TRADEOS — установка

1. Установите Python 3.11+ с python.org (галочка "Add Python to PATH").
2. Двойной клик INSTALL.bat — поставит всё нужное (5–10 минут).
3. Откройте bot\\.env Блокнотом и впишите свои ключи. Права ключей: торговля, БЕЗ вывода средств.
4. Двойной клик START.bat — откроется панель. Всё запускается в ДЕМО.
5. Реальная торговля включается только вручную: «Арсенал» → бот → «Реал» → подтвердить.

Важно: это не финансовый совет. Торговля с плечом может привести к потере всего депозита.
Сначала проверяйте стратегии на paper не меньше 2 недель.
"""


def main() -> None:
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")  # консоль Windows
    except Exception:  # noqa: BLE001
        pass
    if OUT.exists():
        shutil.rmtree(OUT)
    dst_bot = OUT / "bot"
    n = 0
    hard: list[str] = []
    print("Сборка TRADEOS… (обход папок, пропускаю venv/свечи/логи)", flush=True)
    import os
    def files():
        for root, dirs, fs in os.walk(BASE):
            dirs[:] = [d for d in dirs if d not in SKIP_DIRS and not d.startswith(".")]
            for f in fs:
                yield Path(root) / f
    for p in files():
        try:
            if not wanted(p):
                continue
        except OSError:
            continue
        if n and n % 200 == 0:
            print(f"  скопировано {n}…", flush=True)
        rel = p.relative_to(BASE)
        t = dst_bot / rel
        t.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(p, t)
        n += 1
        if p.suffix.lower() in (".py", ".bat", ".json", ".txt", ".md") and p.name != "make_release.py":
            try:
                if HARD_PATH_RE.search(p.read_text(encoding="utf-8", errors="ignore")):
                    hard.append(str(rel))
            except OSError:
                pass
    (dst_bot / ".env.example").write_text(env_example(), encoding="utf-8")
    (OUT / "INSTALL.bat").write_text(INSTALL_BAT.replace("\n", "\r\n"), encoding="utf-8")
    (OUT / "START.bat").write_text(START_BAT.replace("\n", "\r\n"), encoding="utf-8")
    (OUT / "ПРОЧТИ.txt").write_text(README, encoding="utf-8")

    # финальная проверка: секретов в сборке нет
    leaked = [str(f.relative_to(OUT)) for f in OUT.rglob("*") if f.is_file() and is_secret(f.name)
              and f.name != ".env.example"]
    if leaked:
        print("СТОП: в сборку попали файлы, похожие на секреты:", *leaked, sep="\n  ")
        sys.exit(1)

    zpath = OUT_ROOT / f"TRADEOS-{time.strftime('%Y-%m-%d')}.zip"
    with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
        for f in OUT.rglob("*"):
            if f.is_file():
                z.write(f, f.relative_to(OUT_ROOT))
    print(f"Скопировано файлов: {n}")
    print(f"Архив: {zpath}  ({zpath.stat().st_size / 2**20:.1f} МБ)")
    if not (BASE / "requirements.txt").exists():
        print("⚠ Нет requirements.txt — у другого человека не установятся библиотеки. Пришлите мне этот вывод.")
    if hard:
        print(f"⚠ Жёстко зашит путь D:\\VANTORIX в {len(hard)} файлах (у другого человека не заработает):")
        for h in hard[:40]:
            print("   ", h)


if __name__ == "__main__":
    main()
