"""pine_lab.py — 2026-10-28. Импорт стратегий TradingView (Pine Script) → честный тест → библиотека → бумажный бот.

Переводит ПРОСТОЙ Pine (v4–v6) в правила входа и гоняет их тем же движком, что генератор стратегий (strategy_gen.py):
подбор не нужен, поэтому проверка = первые 60% истории (видимая часть), последние 40% (вперёд) и те же правила на других монетах.
Вход — по закрытию свечи, где условие стало истинным. Выход — стоп sl·ATR(14) и тейк rr·стоп (как в генераторе) или по времени.
Стопы/тейки и выход по обратному сигналу из самого скрипта НЕ переносятся — об этом пишется предупреждение.

Что понимается: input.*(), присваивания, [a, b] = ta.xxx(...), if cond → strategy.entry(..., strategy.long/short),
strategy.entry(..., when=cond), alertcondition(cond, "Buy/Long/Sell/Short"), x[1], and/or/not, + - * /, сравнения,
ta.sma/ema/rma/wma/vwma/rsi/atr/tr/highest/lowest/crossover/crossunder/cross/macd/bb/stoch/cci/mfi/change/mom/roc/
stdev/supertrend/dmi/obv/rising/falling/vwap, math.abs/max/min/sqrt/log, nz, na, open/high/low/close/volume/hl2/hlc3/ohlc4.
Всё остальное — понятная ошибка с номером строки. Код выполняется в песочнице: только эти функции, без import/attribute.
"""
from __future__ import annotations

import ast
import json
import re
import sys
import uuid
from pathlib import Path

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parent


# ---------------- функции Pine на pandas ----------------
def _s(x, like):
    return x if isinstance(x, pd.Series) else pd.Series(float(x), index=like.index)


def _mk(d: pd.DataFrame) -> dict:
    o, h, l, c, v = d.o.astype(float), d.h.astype(float), d.l.astype(float), d.c.astype(float), d.v.astype(float)
    S = lambda x: _s(x, c)  # noqa: E731
    pc = c.shift()
    tr = pd.concat([h - l, (h - pc).abs(), (l - pc).abs()], axis=1).max(axis=1)

    def _seeded(x, n, alpha):
        """2026-11-07: как в TradingView — первые n-1 значений пусто, затем старт со SMA(n), дальше экспонента."""
        a_ = S(x).to_numpy(dtype=float); o_ = np.full(len(a_), np.nan); s_ = np.nan; n = int(n)
        for i in range(len(a_)):
            if s_ != s_:
                if i >= n - 1:
                    w_ = a_[i - n + 1:i + 1]
                    if not np.isnan(w_).any():
                        s_ = w_.mean()
            elif a_[i] == a_[i]:
                s_ = alpha * a_[i] + (1 - alpha) * s_
            o_[i] = s_
        return pd.Series(o_, index=c.index)

    def rma(x, n): return _seeded(x, n, 1 / n)
    def ema(x, n): return _seeded(x, n, 2 / (int(n) + 1))
    def sma(x, n): return S(x).rolling(int(n)).mean()

    def wma(x, n):
        n = int(n); w = np.arange(1, n + 1)
        return S(x).rolling(n).apply(lambda a: float(np.dot(a, w) / w.sum()), raw=True)

    def rsi(x, n):
        dx = S(x).diff(); up = rma(dx.clip(lower=0), n); dn = rma((-dx).clip(lower=0), n)
        return 100 - 100 / (1 + up / dn.replace(0, 1e-12))

    def highest(a, b=None): return (h.rolling(int(a)).max() if b is None else S(a).rolling(int(b)).max())
    def lowest(a, b=None): return (l.rolling(int(a)).min() if b is None else S(a).rolling(int(b)).min())

    def crossover(a, b): a, b = S(a), S(b); return (a > b) & (a.shift() <= b.shift())
    def crossunder(a, b): a, b = S(a), S(b); return (a < b) & (a.shift() >= b.shift())
    def cross(a, b): return crossover(a, b) | crossunder(a, b)

    def macd(x, f, s_, sig):
        m = ema(x, f) - ema(x, s_); sg = ema(m, sig); return m, sg, m - sg

    def bb(x, n, k):
        mid = sma(x, n); sd = S(x).rolling(int(n)).std(ddof=0); return mid, mid + k * sd, mid - k * sd

    def stoch(x, hh, ll, n):
        lo_, hi_ = S(ll).rolling(int(n)).min(), S(hh).rolling(int(n)).max()
        return 100 * (S(x) - lo_) / (hi_ - lo_).replace(0, 1e-12)

    def cci(x, n):
        x = S(x); m = x.rolling(int(n)).mean()
        md = x.rolling(int(n)).apply(lambda a: float(np.mean(np.abs(a - a.mean()))), raw=True)
        return (x - m) / (0.015 * md.replace(0, 1e-12))

    def mfi(x, n):
        x = S(x); mf = x * v; pos = mf.where(x.diff() > 0, 0).rolling(int(n)).sum(); neg = mf.where(x.diff() < 0, 0).rolling(int(n)).sum()
        return 100 - 100 / (1 + pos / neg.replace(0, 1e-12))

    def atr(n): return rma(tr, n)

    def supertrend(f, n):
        a = atr(n); hl = (h + l) / 2; up = (hl - f * a).to_numpy(copy=True); dn = (hl + f * a).to_numpy(copy=True); cc = c.to_numpy()
        st = np.full(len(cc), np.nan); dr = np.ones(len(cc))
        for i in range(1, len(cc)):
            if not np.isnan(up[i - 1]):
                up[i] = max(up[i], up[i - 1]) if cc[i - 1] > up[i - 1] else up[i]
                dn[i] = min(dn[i], dn[i - 1]) if cc[i - 1] < dn[i - 1] else dn[i]
            dr[i] = -1 if (dr[i - 1] == 1 and cc[i] > dn[i - 1]) else (1 if (dr[i - 1] == -1 and cc[i] < up[i - 1]) else dr[i - 1])
            st[i] = up[i] if dr[i] == -1 else dn[i]
        return pd.Series(st, index=c.index), pd.Series(dr, index=c.index)   # как в Pine: -1 = восходящий

    def dmi(n, sm):
        upm = h.diff(); dnm = -l.diff()
        p = pd.Series(np.where((upm > dnm) & (upm > 0), upm, 0.0), index=c.index)
        m = pd.Series(np.where((dnm > upm) & (dnm > 0), dnm, 0.0), index=c.index)
        a = rma(tr, n); pdi = 100 * rma(p, n) / a; mdi = 100 * rma(m, n) / a
        dx = 100 * (pdi - mdi).abs() / (pdi + mdi).replace(0, 1e-12)
        return pdi, mdi, rma(dx, sm)

    ms = int(pd.Series(d.t).diff().median()) if len(d) > 2 else 60_000
    tfm = max(1, ms // 60_000)

    def _tf_min(x):
        x = str(x).strip().upper()
        if x in ("", "0"):
            return tfm
        m = re.match(r"^(\d*)([SDWM]?)$", x)
        if not m:
            return tfm
        k = int(m.group(1) or 1); u = m.group(2)
        return {"": k, "S": max(1, k // 60), "D": 1440 * k, "W": 10080 * k, "M": 43800 * k}[u]

    EXTRA: dict = {}

    def _sec(tick, tf, src, *_a, **_k):
        """request.security на старший ТФ ЧЕСТНО: значение последней ЗАКРЫТОЙ старшей свечи (lookahead не используется)."""
        hm = _tf_min(tf)
        ha = str(tick) == "HA"
        if hm <= tfm and not ha:
            return _eval_in(d, src, EXTRA)
        H = hm * 60_000 if hm > tfm else ms
        g = d.assign(b=d.t // H * H).groupby("b")
        hb = pd.DataFrame({"t": g.t.first(), "o": g.o.first(), "h": g.h.max(), "l": g.l.min(), "c": g.c.last(), "v": g.v.sum()}).reset_index(drop=True)
        if ha:
            hc = (hb.o + hb.h + hb.l + hb.c) / 4
            hoa = np.empty(len(hb)); hoa[0] = (hb.o.iloc[0] + hb.c.iloc[0]) / 2
            for i in range(1, len(hb)):
                hoa[i] = (hoa[i - 1] + hc.iloc[i - 1]) / 2
            hb = hb.assign(o=hoa, c=hc.values, h=np.maximum(hb.h, np.maximum(hoa, hc)), l=np.minimum(hb.l, np.minimum(hoa, hc)))
        val = _eval_in(hb, src, EXTRA)
        val = val.values if isinstance(val, pd.Series) else np.full(len(hb), val)
        bucket = (d.t // H * H).values
        pos = np.searchsorted(hb.t.values // H * H, bucket)
        closed = np.where(d.t.values + ms >= bucket + H, pos, pos - 1)
        out = np.where(closed >= 0, val[np.clip(closed, 0, len(val) - 1)], np.nan)
        return pd.Series(out, index=c.index)

    tp = (h + l + c) / 3
    obv = (np.sign(c.diff()).fillna(0) * v).cumsum()
    day = pd.to_datetime(d.t, unit="ms").dt.floor("D")
    vwap = (tp * v).groupby(day.values).cumsum() / v.groupby(day.values).cumsum()

    def nz(x, r=0): return S(x).fillna(r)
    def na_(x=None): return pd.Series(np.nan, index=c.index) if x is None else S(x).isna()

    def shift(x, k): return S(x).shift(int(k))
    def _and(*a):
        r = S(a[0]).fillna(0).astype(bool)
        for x in a[1:]:
            r = r & S(x).fillna(0).astype(bool)
        return r

    def _or(*a):
        r = S(a[0]).fillna(0).astype(bool)
        for x in a[1:]:
            r = r | S(x).fillna(0).astype(bool)
        return r

    def _not(x): return ~S(x).fillna(0).astype(bool)

    def _iff(cnd, a, b):
        if not isinstance(cnd, pd.Series):            # настройка-константа (input): выбираем ветку сразу
            return a if (cnd and cnd == cnd) else b
        return pd.Series(np.where(S(cnd).fillna(0).astype(bool), S(a), S(b)), index=c.index)

    return {
        "open": o, "high": h, "low": l, "close": c, "volume": v, "hl2": (h + l) / 2, "hlc3": tp, "ohlc4": (o + h + l + c) / 4,
        "ta_sma": sma, "ta_ema": ema, "ta_rma": rma, "ta_wma": wma, "ta_vwma": lambda x, n: sma(S(x) * v, n) / sma(v, n),
        "ta_rsi": rsi, "ta_atr": atr, "ta_tr_s": tr, "ta_trf": lambda *_: tr, "ta_highest": highest, "ta_lowest": lowest,
        "ta_crossover": crossover, "ta_crossunder": crossunder, "ta_cross": cross, "ta_macd": macd, "ta_bb": bb,
        "ta_stoch": stoch, "ta_cci": cci, "ta_mfi": mfi, "ta_change": lambda x, n=1: S(x).diff(int(n)),
        "ta_mom": lambda x, n: S(x).diff(int(n)), "ta_roc": lambda x, n: 100 * S(x).pct_change(int(n)),
        "ta_stdev": lambda x, n: S(x).rolling(int(n)).std(ddof=0), "ta_supertrend": supertrend, "ta_dmi": dmi,
        "ta_obv": obv, "ta_vwap": vwap, "ta_rising": lambda x, n: S(x).diff().rolling(int(n)).min() > 0,
        "ta_falling": lambda x, n: S(x).diff().rolling(int(n)).max() < 0,
        "math_abs": lambda x: S(x).abs(), "math_max": lambda *a: pd.concat([S(x) for x in a], axis=1).max(axis=1),
        "math_min": lambda *a: pd.concat([S(x) for x in a], axis=1).min(axis=1),
        "math_sqrt": lambda x: np.sqrt(S(x)), "math_log": lambda x: np.log(S(x)),
        "nz": nz, "na": na_, "_shift": shift, "_and": _and, "_or": _or, "_not": _not, "_iff": _iff,
        "true": True, "false": False, "_NA": float("nan"), "_sec": _sec, "_extra": EXTRA, "str_tostring": lambda x, *a: str(int(x) if float(x) == int(float(x)) else x),
        "timeframe_multiplier": float(tfm if tfm < 1440 else tfm // 1440), "timeframe_isseconds": False,
        "timeframe_isminutes": tfm < 1440, "timeframe_isintraday": tfm < 1440, "timeframe_isdaily": 1440 <= tfm < 10080,
        "timeframe_isweekly": 10080 <= tfm < 43800, "timeframe_ismonthly": tfm >= 43800, "timeframe_isdwm": tfm >= 1440,
        "timeframe_period": str(tfm) if tfm < 1440 else "D", "_SYM": "SYM", "_HA": "HA", "time": d.t.astype(float), "bar_index": pd.Series(np.arange(len(c)), index=c.index, dtype=float),
        "int": lambda x: (np.trunc(x) if isinstance(x, pd.Series) else int(x)), "float": lambda x: x, "bool": lambda x: S(x).fillna(0).astype(bool),
        "math_pow": lambda a, b: S(a) ** b if isinstance(a, pd.Series) else a ** b, "math_round": lambda x, n=0: (S(x).round(int(n))),
        "math_floor": lambda x: np.floor(x), "math_ceil": lambda x: np.ceil(x), "math_avg": lambda *a: sum(S(x) for x in a) / len(a),
        "math_sign": lambda x: np.sign(x),
    }


def _eval_in(frame: pd.DataFrame, src: str, extra: dict | None = None):
    tree = ast.fix_missing_locations(_Tx().visit(ast.parse(src, mode="eval")))
    ns = _mk(frame); ns.update(extra or {}); _check(tree, set(ns))
    return eval(compile(tree, "<pine>", "eval"), {"__builtins__": {}}, ns)  # noqa: S307


FUNCS = set(_mk(pd.DataFrame({"t": [0, 1], "o": [1.0, 1], "h": [1.0, 1], "l": [1.0, 1], "c": [1.0, 1], "v": [1.0, 1]})).keys())


# ---------------- перевод текста Pine ----------------
class PineError(ValueError):
    pass


def _split_ternary(e: str):
    """a ? b : c с учётом скобок и вложенности; None — тернарного нет."""
    depth = 0; q = -1
    for i, ch in enumerate(e):
        if ch in "([": depth += 1
        elif ch in ")]": depth -= 1
        elif ch == "?" and depth == 0:
            q = i; break
    if q < 0:
        return None
    depth = 0; nest = 0
    for i in range(q + 1, len(e)):
        ch = e[i]
        if ch in "([": depth += 1
        elif ch in ")]": depth -= 1
        elif depth == 0 and ch == "?": nest += 1
        elif depth == 0 and ch == ":":
            if nest == 0:
                return e[:q], e[q + 1:i], e[i + 1:]
            nest -= 1
    return None


def _strip_security(e: str) -> str:
    """request.security(syminfo.tickerid, "" | timeframe.period, X) → (X): тот же ТФ — это просто X."""
    while True:
        m = re.search(r"request\.security\s*\(\s*syminfo\.tickerid\s*,\s*(?:''|\"\"|timeframe\.period)\s*,", e)
        if not m:
            return e
        i = m.end(); depth = 1; j = i; arg_end = None
        while j < len(e) and depth:
            if e[j] == "(": depth += 1
            elif e[j] == ")": depth -= 1
            elif e[j] == "," and depth == 1 and arg_end is None: arg_end = j
            j += 1
        inner = e[i:arg_end if arg_end else j - 1]
        e = e[:m.start()] + "(" + inner.strip() + ")" + e[j:]


def _inline_inputs(e: str) -> str:
    """input.int(7, group=...) внутри выражения → 7 (значение по умолчанию)."""
    while True:
        m = re.search(r"\binput(?:\.\w+)?\s*\(", e)
        if not m:
            return e
        i = m.end(); depth = 1; j = i; first_end = None
        while j < len(e) and depth:
            if e[j] in "([": depth += 1
            elif e[j] in ")]": depth -= 1
            elif e[j] == "," and depth == 1 and first_end is None: first_end = j
            j += 1
        first = re.sub(r"^defval\s*=\s*", "", e[i:first_end if first_end else j - 1].strip())
        e = e[:m.start()] + "(" + first + ")" + e[j:]


def _security_any(e: str, ln: int) -> str:
    """request.security(T, TF, EXPR, ...) → _sec(T, TF, "EXPR") — EXPR считается на старшем ТФ при запуске."""
    while True:
        m = re.search(r"request\.security\s*\(", e)
        if not m:
            return e
        i = m.end(); depth = 1; j = i; commas = []
        while j < len(e) and depth:
            if e[j] in "([": depth += 1
            elif e[j] in ")]": depth -= 1
            elif e[j] == "," and depth == 1: commas.append(j)
            j += 1
        if len(commas) < 2:
            return e
        a1, a2 = e[i:commas[0]].strip(), e[commas[0] + 1:commas[1]].strip()
        a3 = e[commas[1] + 1:(commas[2] if len(commas) > 2 else j - 1)].strip()
        inner = _expr_py(a3, ln).replace("\\", "\\\\").replace('"', '\\"')
        e = e[:m.start()] + f'_sec({a1}, {a2}, "{inner}")' + e[j:]


def _expr_py(e: str, ln: int) -> str:
    e = _strip_security(_inline_inputs(e.strip()))
    e = re.sub(r"\bticker\.heikinashi\s*\([^()]*\)", "_HA", e)
    e = re.sub(r"\bsyminfo\.tickerid\b", "_SYM", e)
    e = re.sub(r"\bbarmerge\.\w+", "0", e)
    e = re.sub(r"\btimeframe\.(\w+)", r"timeframe_\1", e)
    e = re.sub(r"\bstr\.tostring\s*\(", "str_tostring(", e)
    e = _security_any(e, ln)
    t = _split_ternary(e)
    if t:
        return f"_iff({_expr_py(t[0], ln)}, {_expr_py(t[1], ln)}, {_expr_py(t[2], ln)})"
    if "?" in e:                                       # тернарный внутри скобок/аргументов
        out, i = [], 0
        while i < len(e):
            if e[i] in "([":
                close = ")" if e[i] == "(" else "]"; depth = 1; j = i + 1; parts = []; st = j
                while j < len(e) and depth:
                    if e[j] in "([": depth += 1
                    elif e[j] in ")]": depth -= 1
                    if depth == 1 and e[j] == ",":
                        parts.append(e[st:j]); st = j + 1
                    j += 1
                parts.append(e[st:j - 1])
                out.append(e[i] + ", ".join(_expr_py(x, ln) if "?" in x else x for x in parts) + close); i = j
            else:
                out.append(e[i]); i += 1
        e = "".join(out)
    e = re.sub(r"\bta\.tr\b(?!\s*\()", "ta_tr_s", e)
    e = re.sub(r"\bta\.tr\s*\(", "ta_trf(", e)
    e = re.sub(r"\bta\.(obv|vwap)\b(?!\s*\()", r"ta_\1", e)
    e = re.sub(r"\b(ta|math)\.([a-z]+)", r"\1_\2", e)
    e = re.sub(r"\bstrategy\.(long|short)\b", r"'\1'", e)
    e = re.sub(r"\bcolor\.\w+(\.\w+)?(\([^()]*\))?|#[0-9A-Fa-f]{6,8}\b", "0", e)
    e = re.sub(r"\bna\b(?!\s*\()", "_NA", e)
    return e


class _Tx(ast.NodeTransformer):
    """x[1] → _shift(x,1); and/or/not → функции; a<b<c → and. Плюс белый список узлов."""
    OK = (ast.Module, ast.Expression, ast.Assign, ast.Expr, ast.Name, ast.Load, ast.Store, ast.Tuple, ast.Constant, ast.BinOp, ast.UnaryOp,
          ast.Compare, ast.Call, ast.keyword, ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Mod, ast.Pow, ast.USub, ast.UAdd,
          ast.Gt, ast.GtE, ast.Lt, ast.LtE, ast.Eq, ast.NotEq, ast.List)

    def visit_Subscript(self, n):
        self.generic_visit(n)
        return ast.Call(ast.Name("_shift", ast.Load()), [n.value, n.slice], [])

    def visit_BoolOp(self, n):
        self.generic_visit(n)
        return ast.Call(ast.Name("_and" if isinstance(n.op, ast.And) else "_or", ast.Load()), n.values, [])

    def visit_UnaryOp(self, n):
        self.generic_visit(n)
        if isinstance(n.op, ast.Not):
            return ast.Call(ast.Name("_not", ast.Load()), [n.operand], [])
        return n

    def visit_Compare(self, n):
        self.generic_visit(n)
        if len(n.ops) == 1:
            return n
        parts, left = [], n.left
        for op, r in zip(n.ops, n.comparators):
            parts.append(ast.Compare(left, [op], [r])); left = r
        return ast.Call(ast.Name("_and", ast.Load()), parts, [])


def _check(tree, known: set, ufuncs=()):
    for node in ast.walk(tree):
        if isinstance(node, ast.Attribute):
            raise PineError(f"«{ast.unparse(node)}» не поддерживается (request.*, syminfo.*, timeframe.*, объекты)")
        if not isinstance(node, _Tx.OK):
            raise PineError(f"не поддерживается: {type(node).__name__}")
        if isinstance(node, ast.Call) and not (isinstance(node.func, ast.Name) and (node.func.id in FUNCS or node.func.id in ufuncs)):
            raise PineError(f"функция «{ast.unparse(node.func)}» не поддерживается")
        if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load) and node.id not in FUNCS and node.id not in known and node.id not in ufuncs:
            raise PineError(f"неизвестное имя «{node.id}»")


class _Dep(PineError):
    pass


def _names(tree) -> set:
    return {n.id for n in ast.walk(tree) if isinstance(n, ast.Name)}


def _parse_expr(src: str, ln: int, known: set, bad: dict | None = None, ufuncs=()) -> str:
    try:
        tree = ast.parse(_expr_py(src, ln), mode="eval")
    except SyntaxError as exc:
        raise PineError(f"строка {ln}: не разобрал выражение «{src.strip()[:60]}»") from exc
    tree = ast.fix_missing_locations(_Fold().visit(ast.fix_missing_locations(_Tx().visit(tree))))
    if bad:
        hit = [n for n in _names(tree) if n in bad]
        if hit:
            raise _Dep(f"«{hit[0]}» — {bad[hit[0]]}")
    try:
        _check(tree, known, ufuncs)
    except PineError as exc:
        raise PineError(f"строка {ln}: {exc}") from exc
    return ast.unparse(tree)


_CONSTS: dict = {}


def _const_val(n):
    """Значение выражения из констант/настроек (input) или исключение."""
    if isinstance(n, ast.Constant):
        return n.value
    if isinstance(n, ast.Name) and n.id in _CONSTS:
        return _CONSTS[n.id]
    if isinstance(n, ast.Name) and n.id in ("True", "False", "true", "false"):
        return n.id in ("True", "true")
    if isinstance(n, ast.Compare) and len(n.ops) == 1:
        a, b = _const_val(n.left), _const_val(n.comparators[0]); op = n.ops[0]
        return {ast.Eq: a == b, ast.NotEq: a != b}.get(type(op)) if isinstance(op, (ast.Eq, ast.NotEq)) else \
            {ast.Gt: lambda: a > b, ast.Lt: lambda: a < b, ast.GtE: lambda: a >= b, ast.LtE: lambda: a <= b}[type(op)]()
    if isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id in ("_and", "_or", "_not"):
        vals = [_const_val(x) for x in n.args]
        return all(vals) if n.func.id == "_and" else any(vals) if n.func.id == "_or" else not vals[0]
    raise ValueError


class _Fold(ast.NodeTransformer):
    """_iff(настройка, a, b) → нужная ветка: переключатели режимов скрипта решаются сразу."""
    def visit_Call(self, n):
        self.generic_visit(n)
        if isinstance(n.func, ast.Name) and n.func.id == "_iff" and len(n.args) == 3:
            try:
                return n.args[1] if _const_val(n.args[0]) else n.args[2]
            except Exception:  # noqa: BLE001
                return n
        if isinstance(n.func, ast.Name) and n.func.id == "_and":
            keep = []
            for x in n.args:
                try:
                    v = _const_val(x)
                except Exception:  # noqa: BLE001
                    keep.append(x); continue
                if not v:
                    return ast.Constant(False)
            return keep[0] if len(keep) == 1 else (ast.Constant(True) if not keep else ast.Call(n.func, keep, []))
        return n


def _blocks(joined):
    """[(ln, indent, text, [дочерние строки])] — разбивка на блоки верхнего уровня по отступам."""
    out = []
    for ln, s in joined:
        ind = len(s) - len(s.lstrip())
        if out and ind > out[-1][1]:
            out[-1][3].append((ln, s))
        else:
            out.append((ln, ind, s.strip(), []))
    return out


def compile_pine(text: str) -> dict:
    """Мягкий перевод: всё, что не нужно для входов (рисование, таблицы, сложные блоки), пропускается.
    Ошибка — только если САМИ ВХОДЫ зависят от того, что перевести нельзя (с объяснением, от чего именно)."""
    lines = text.replace("\t", "    ").split("\n")
    joined, buf, bln = [], "", 0
    for i, raw in enumerate(lines, 1):
        s = re.sub(r"(?<![:\"'])//.*$", "", raw).rstrip()
        if not s.strip():
            continue
        if buf and (buf.rstrip().endswith((",", "(", "[", " and", " or", "+", "-", "*", "/", "?", ":", "=", "=>")) and not buf.rstrip().endswith(("==", "!=", ">=", "<=")) and not buf.rstrip().endswith("=>")
                    or buf.count("(") > buf.count(")") or buf.count("[") > buf.count("]")
                    or (s.lstrip()[:1] in ("?", ":") and len(s) - len(s.lstrip()) > len(buf) - len(buf.lstrip()))):
            buf += " " + s.strip(); continue
        if buf:
            joined.append((bln, buf))
        buf, bln = s, i
    if buf:
        joined.append((bln, buf))

    prog, known, warn = [], set(), []
    _CONSTS.clear()
    bad: dict = {}                 # имя → почему недоступно
    ufuncs: dict = {}              # пользовательские функции
    longs, shorts, title = [], [], "Pine"
    entry_fail: list = []
    alerts: list = []
    skipped = 0

    def assign(ln, st):
        nonlocal skipped
        st2 = re.sub(r"^(var|varip)\s+", "", st)
        st2 = re.sub(r"^((?:series|simple|const)\s+)?(float|int|bool|string|color|label|line|box|table|array<\w+>|matrix<\w+>)\s+(?=\w+\s*=)", "", st2)
        m = re.match(r"^\[([\w\s,]+)\]\s*=\s*(.+)$", st2) or re.match(r"^([A-Za-z_]\w*)\s*(:?=)\s*(?!=)(.+)$", st2)
        if not m:
            skipped += 1; return
        if m.re.groups == 3:
            names, op, rhs = [m.group(1)], m.group(2), m.group(3).strip()
        else:
            names, op, rhs = [x.strip() for x in m.group(1).split(",")], "=", m.group(2).strip()
        if st.startswith(("var ", "varip ")) or op == ":=":
            for n in names:
                bad[n] = f"переменная с памятью между свечами (var / :=, строка {ln})"
            known.update(names); return
        if re.match(r"^input\.time\s*\(", rhs):      # диапазон дат бэктеста TV — у нас весь период
            val = "9e15" if re.search(r"to|end|stop|до|кон", names[0], re.I) else "0"
            prog.append([names, val]); known.update(names); [bad.pop(n, None) for n in names]
            warn.append(f"строка {ln}: фильтр дат из скрипта отключён — тест идёт на всей истории"); return
        mi = re.match(r"^input(?:\.\w+)?\s*\((.*)\)$", rhs)
        if mi:
            first = re.split(r",(?![^()]*\))", mi.group(1))[0].strip()
            first = re.sub(r"^defval\s*=\s*", "", first)
            if re.match(r"^[\"']", first):
                _CONSTS[names[0]] = first.strip("\"'")
                prog.append([names, repr(first.strip("\"'"))]); known.update(names); [bad.pop(n, None) for n in names]; return
            rhs = {"true": "True", "false": "False"}.get(first, first)
            try:
                _CONSTS[names[0]] = ast.literal_eval(rhs)
            except Exception:  # noqa: BLE001
                pass
        if len(names) == 1:
            try:
                _CONSTS[names[0]] = ast.literal_eval(rhs.replace("true", "True").replace("false", "False"))
            except Exception:  # noqa: BLE001
                try:
                    _CONSTS[names[0]] = _const_val(ast.parse(_expr_py(rhs, ln), mode="eval").body)
                except Exception:  # noqa: BLE001
                    _CONSTS.pop(names[0], None)
        try:
            expr = _parse_expr(rhs, ln, known, bad, ufuncs)
        except PineError as exc:
            for n in names:
                bad[n] = str(exc) if isinstance(exc, _Dep) else f"{exc}"
            known.update(names); return
        prog.append([names, expr]); known.update(names)
        for n in names:
            bad.pop(n, None)

    for ln, ind, st, body in _blocks(joined):
        mf = re.match(r"^(?:method\s+)?([A-Za-z_]\w*)\s*\(([^()]*)\)\s*=>\s*(.*)$", st)
        if mf:                                         # пользовательская функция
            name, params = mf.group(1), [re.sub(r"^(\w+\s+)*", "", x.strip()).split("=")[0].strip() for x in mf.group(2).split(",") if x.strip()]
            lines_ = ([(ln, mf.group(3))] if mf.group(3).strip() else []) + [(l2, s2.strip()) for l2, s2 in body]
            try:
                loc = set(params) | known; fbody = []
                for l2, s2 in lines_[:-1]:
                    m2 = re.match(r"^([A-Za-z_]\w*)\s*=\s*(?!=)(.+)$", re.sub(r"^(float|int|bool|string)\s+", "", s2))
                    if not m2:
                        raise PineError(f"строка {l2}: в функции поддерживаются только присваивания и итоговое выражение")
                    fbody.append([m2.group(1), _parse_expr(m2.group(2), l2, loc, bad, ufuncs)]); loc.add(m2.group(1))
                last = lines_[-1][1]
                ma = re.match(r"^(?:float|int|bool|string\s+)?([A-Za-z_]\w*)\s*:?=\s*(?!=)(.+)$", last)
                if ma:                                 # последняя строка — присваивание: функция возвращает это значение
                    fbody.append([ma.group(1), _parse_expr(ma.group(2), lines_[-1][0], loc, bad, ufuncs)]); loc.add(ma.group(1))
                    last = ma.group(1)
                mm = re.match(r"^\[([\w\s,]+)\]$", last)
                final = ("(" + ", ".join(_parse_expr(x, lines_[-1][0], loc, bad, ufuncs) for x in mm.group(1).split(",")) + ",)") if mm \
                    else _parse_expr(last, lines_[-1][0], loc, bad, ufuncs)
                ufuncs[name] = 1
                prog.append(["__func__", name, params, fbody, final])
                bad.pop(name, None)
            except PineError as exc:
                bad[name] = f"функция {name}(): {exc}"
            continue
        if re.match(r"^(type|method|export|import|enum)\b", st):
            m = re.match(r"^\w+\s+(\w+)", st)
            if m:
                bad[m.group(1)] = f"тип/объект (строка {ln})"
            continue
        if re.match(r"^(for|while|switch)\b", st) or re.match(r"^\[?[\w\s,]+\]?\s*:?=\s*(for|while|switch)\b", st):
            for l2, s2 in [(ln, st)] + body:
                mm = re.match(r"^\s*(?:var\s+)?\[?([\w\s,]+?)\]?\s*:?=", s2)
                if mm:
                    for n in [x.strip() for x in mm.group(1).split(",")]:
                        bad[n] = f"значение из цикла/switch (строка {ln})"
            continue
        if st.startswith(("strategy(", "indicator(", "study(")):
            m = re.search(r"\(\s*(?:title\s*=\s*)?[\"']([^\"']+)", st); title = m.group(1) if m else title; continue
        if st.startswith("alertcondition("):
            m = re.match(r"alertcondition\((.+?),\s*(?:title\s*=\s*)?[\"']([^\"']*)", st)
            if m:
                alerts.append((ln, m.group(1), m.group(2).lower()))
            continue
        if re.match(r"^(plot|plotshape|plotchar|plotarrow|plotcandle|plotbar|bgcolor|fill|hline|barcolor|label\.|line\.|table\.|box\.|polyline\.|alert\(|log\.|runtime\.|strategy\.(exit|close|cancel|order|risk))", st):
            if st.startswith(("strategy.exit", "strategy.close")):
                warn.append(f"строка {ln}: выход из скрипта не переносится — стоп ATR и тейк R задаются в окне теста")
            continue
        if st.startswith("if "):                       # if-блок: входы внутри, остальное — переменные с памятью
            cond_src = st[3:].strip()
            stack = [(ind, cond_src, ln)]
            for l2, s2 in body:
                i2 = len(s2) - len(s2.lstrip()); t2 = s2.strip()
                while len(stack) > 1 and i2 <= stack[-1][0]:
                    stack.pop()
                if t2.startswith("if "):
                    stack.append((i2, t2[3:].strip(), l2)); continue
                if t2.startswith("else"):
                    stack.append((i2, None, l2)); continue
                if t2.startswith("strategy.entry("):
                    side = "long" if "strategy.long" in t2 else "short" if "strategy.short" in t2 else None
                    if side is None or any(c is None for _i, c, _l in stack):
                        entry_fail.append(f"строка {l2}: вход внутри else/без направления"); continue
                    conds = []
                    try:
                        for _i, c, lc in stack:
                            conds.append(_parse_expr(c, lc, known, bad, ufuncs))
                        mw = re.search(r"when\s*=\s*(.+)\)\s*$", t2)
                        if mw:
                            conds.append(_parse_expr(mw.group(1), l2, known, bad, ufuncs))
                    except PineError as exc:
                        entry_fail.append(f"вход {side} (строка {l2}) зависит от {exc}" if isinstance(exc, _Dep) else f"вход {side}: {exc}")
                        continue
                    if "False" in conds:          # ветка выключена настройками скрипта (другой режим)
                        continue
                    e = conds[0] if len(conds) == 1 else "_and(" + ", ".join(conds) + ")"
                    (longs if side == "long" else shorts).append(e); continue
                mm = re.match(r"^\[?([\w\s,]+?)\]?\s*:=", t2)
                if mm:
                    for n in [x.strip() for x in mm.group(1).split(",")]:
                        bad[n] = f"меняется внутри if (строка {l2}) — логика с памятью"
            continue
        if st.startswith("else"):
            continue
        if st.startswith("strategy.entry("):
            side = "long" if "strategy.long" in st else "short" if "strategy.short" in st else None
            mw = re.search(r"when\s*=\s*(.+)\)\s*$", st)
            if side and mw:
                try:
                    (longs if side == "long" else shorts).append(_parse_expr(mw.group(1), ln, known, bad, ufuncs))
                except PineError as exc:
                    entry_fail.append(f"вход {side} (строка {ln}) зависит от {exc}" if isinstance(exc, _Dep) else f"вход {side}: {exc}")
            continue
        if st.startswith("strategy."):
            continue
        assign(ln, st)

    if not longs and not shorts and alerts:
        for ln, cond, ttl in alerts:
            try:
                e = _parse_expr(cond, ln, known, bad, ufuncs)
            except PineError as exc:
                entry_fail.append(f"сигнал «{ttl}» (строка {ln}) зависит от {exc}"); continue
            if re.search(r"buy|long|покуп|лонг|bull", ttl):
                longs.append(e)
            elif re.search(r"sell|short|продаж|шорт|bear", ttl):
                shorts.append(e)
        if longs or shorts:
            warn.append("стратегии нет — входы взяты из alertcondition (Buy/Sell)")
    if not longs and not shorts:
        if entry_fail:
            why = []
            for f in entry_fail:
                core = f.split(" зависит от ", 1)[-1]
                last = core.split(" — ")[-1]
                if last not in why:
                    why.append(last)
            chain = entry_fail[0].split(" зависит от ", 1)[-1].replace("«", "").replace("»", "")
            hint = (" Это данные со старшего таймфрейма / Хейкен-Аши / Ренко — такие скрипты переношу вручную"
                    " (LE VAN DO уже перенесён: бумажный бот «HA ×18 переворот»)."
                    if any(k in " ".join(why) for k in ("heikinashi", "renko", "security", "timeframe.multiplier", "timeframe.is")) else " Пришлите скрипт мне — перенесу вручную.")
            raise PineError("входы найдены, но зависят от того, что автоматически не переводится: " + "; ".join(why[:3])
                            + f". Цепочка: {chain[:220]}." + hint)
        raise PineError("не нашёл входов: нужен strategy.entry(...) или alertcondition(..., \"Buy\"/\"Sell\")")
    for f in dict.fromkeys(entry_fail):
        warn.append(f"часть входов пропущена: {f}"[:300])
    if bad:
        warn.append(f"пропущено как не нужное для входов: {len(bad)} переменных/функций (рисование, таблицы, логика с памятью)")
    j = lambda xs: None if not xs else (xs[0] if len(xs) == 1 else "_or(" + ", ".join(xs) + ")")  # noqa: E731
    warn.append("вход — по закрытию свечи с сигналом; выход по обратному сигналу не используется")
    # оставляем только то, от чего зависят входы (быстрее и без падений на ненужных частях скрипта)
    def deps(expr):
        names = _names(ast.parse(expr, mode="eval"))
        for sm in re.findall(r'_sec\([^"]*"((?:[^"\\]|\\.)*)"', expr):
            names |= _names(ast.parse(sm.replace('\\"', '"'), mode="eval"))
        return names
    need = set()
    for e in (j(longs), j(shorts)):
        if e:
            need |= deps(e)
    keep = []
    for it in reversed(prog):
        defs = [it[1]] if it[0] == "__func__" else it[0]
        if any(n in need for n in defs):
            keep.append(it)
            if it[0] == "__func__":
                for _nm, ex in it[3]:
                    need |= deps(ex)
                need |= deps(it[4])
            else:
                need |= deps(it[1])
    prog = list(reversed(keep))
    if any("_sec(" in (it[1] if it[0] != "__func__" else it[4]) for it in prog):
        warn.append("данные старшего ТФ (request.security) считаются ЧЕСТНО — по последней закрытой старшей свече, "
                    "без lookahead; поэтому результат может сильно отличаться от бэктеста TradingView")
    return {"prog": prog, "long": j(longs), "short": j(shorts), "title": title[:60], "warnings": warn}


def _run_prog(d: pd.DataFrame, comp: dict) -> dict:
    ns = dict(_mk(d)); known = set()
    uf = {it[1] for it in comp["prog"] if it[0] == "__func__"}
    for it in comp["prog"]:
        if it[0] == "__func__":
            _n, fname, params, fbody, final = it
            loc_known = set(params) | known | set(ns) | {x[0] for x in fbody}
            for _nm, ex in fbody:
                _check(ast.parse(ex, mode="eval"), loc_known, uf)
            _check(ast.parse(final, mode="eval"), loc_known, uf)

            def _mkf(params=params, fbody=fbody, final=final):
                def f(*args):
                    loc = dict(ns); loc.update(zip(params, args))
                    for nm, ex in fbody:
                        loc[nm] = eval(compile(ast.parse(ex, mode="eval"), "<pine>", "eval"), {"__builtins__": {}}, loc)  # noqa: S307
                    return eval(compile(ast.parse(final, mode="eval"), "<pine>", "eval"), {"__builtins__": {}}, loc)  # noqa: S307
                return f
            ns[fname] = _mkf(); known.add(fname)
            continue
        names, expr = it
        tree = ast.parse(expr, mode="eval"); _check(tree, known | set(ns), uf)   # повторная проверка при каждом запуске
        val = eval(compile(tree, "<pine>", "eval"), {"__builtins__": {}}, ns)  # noqa: S307 -- белый список узлов и функций
        if len(names) == 1:
            ns[names[0]] = val
        else:
            for k, x in zip(names, val):
                ns[k] = x
        for k in names:
            if isinstance(ns[k], (int, float, str, bool)):
                ns["_extra"][k] = ns[k]
        known.update(names)
    return ns


def signal(d: pd.DataFrame, p, side: int) -> np.ndarray:
    """Булев массив входов для strategy_gen._entries / gen_paper (p — JSON скомпилированной программы)."""
    comp = json.loads(p) if isinstance(p, str) else p
    expr = comp["long"] if side > 0 else comp["short"]
    if not expr:
        return np.zeros(len(d), dtype=bool)
    ns = _run_prog(d, comp)
    tree = ast.parse(expr, mode="eval"); _check(tree, set(ns), {it[1] for it in comp["prog"] if it[0] == "__func__"})
    v = eval(compile(tree, "<pine>", "eval"), {"__builtins__": {}}, ns)  # noqa: S307
    v = v if isinstance(v, pd.Series) else pd.Series(bool(v), index=d.index)
    a = v.fillna(0).astype(bool).values
    return a & ~np.r_[False, a[:-1]]          # только первая свеча, где условие стало истинным


# ---------------- тест (отдельным процессом, как генератор) ----------------
def run(job: str, cfg_path: str) -> None:
    sys.path.insert(0, str(BASE))
    import strategy_gen as G  # noqa: PLC0415
    cfg = json.loads(Path(cfg_path).read_text(encoding="utf-8"))
    J = G._FileJob(job)
    try:
        comp = cfg["comp"]; symbol = cfg["symbol"]; tf = cfg["tf"]; sl, rr = float(cfg["sl"]), float(cfg["rr"])
        J.update(pct=3, text=f"{symbol}: свечи…")
        d = G._load(symbol, tf)
        if d is None or len(d) < 1500:
            raise RuntimeError("мало истории на складе свечей для этой монеты — выберите другую или скачайте свечи")
        F = G._feats(d); n = len(d); cut = int(n * 0.6); hold = G.HOLD[tf]
        p = json.dumps(comp, ensure_ascii=False)
        rows = []
        sides = [s for s in (1, -1) if comp["long" if s > 0 else "short"]]
        others: dict = {}
        for k, side in enumerate(sides):
            J.update(pct=10 + 40 * k / len(sides), text=f"{'лонг' if side > 0 else 'шорт'}: история и проверка вперёд")
            idx = G._entries(F, "pine", side, p, "нет")
            tr = G._sim(F, idx, side, sl, rr, hold, 0, cut); vt = G._sim(F, idx, side, sl, rr, hold, cut, n)
            full = G._sim(F, idx, side, sl, rr, hold, 0, n)
            blank = lambda t: G._score(t) or {"n": len(t), "wr": 0, "pf": 0, "r": round(sum(x[2] for x in t), 1), "avg": 0, "streak": 0, "dd_r": 0}  # noqa: E731
            c = {"trig": "pine", "p": p, "flt": "нет", "sl": sl, "rr": rr, "train": blank(tr), "valid": blank(vt)}
            c["curve"] = [[int(d.t.iloc[x[1]]), round(float(v), 2)] for x, v in zip(full, np.cumsum([x[2] for x in full]))]
            c["cut_t"] = int(d.t.iloc[cut])
            c["trades"] = [{"t": int(d.t.iloc[x[0]]), "dur": int((d.t.iloc[x[1]] - d.t.iloc[x[0]]) / 60000), "r": round(float(x[2]), 2)} for x in full[-60:]][::-1]
            res = []
            for m, sym in enumerate(cfg.get("coins") or G.OTHER[:20]):
                if sym == symbol:
                    continue
                J.update(pct=50 + 45 * (k + m / 20) / len(sides), text=f"другие монеты: {sym}")
                if sym not in others:
                    try:
                        od = G._load(sym, tf)
                    except Exception:  # noqa: BLE001
                        od = None
                    others[sym] = (G._feats(od), int(len(od) * 0.6)) if od is not None and len(od) > 1500 else None
                o = others[sym]
                if not o:
                    continue
                try:
                    oi = G._entries(o[0], "pine", side, p, "нет")
                except Exception:  # noqa: BLE001
                    continue
                sc = G._score(G._sim(o[0], oi, side, sl, rr, hold, o[1], len(o[0]["c"])))
                if sc:
                    res.append({"sym": sym.replace("USDT", ""), **sc})
            c["coins"] = res
            pos = sum(1 for x in res if x["r"] > 0); v = c["valid"]; t0 = c["train"]
            midv = cut + (n - cut) // 2      # 2026-10-28: вердикт по ВЫБРАННОЙ монете, другие — справка
            h1 = sum(x[2] for x in vt if x[0] < midv); h2 = sum(x[2] for x in vt if x[0] >= midv)
            ok = v["n"] >= 20 and v["pf"] >= 1.2 and v["r"] > 0 and t0["r"] > 0 and h1 > 0 and h2 > 0
            c["verdict"] = "прошла" if ok else ("слабо" if v["r"] > 0 and v["pf"] >= 1.0 else "не прошла")
            c["why"] = (f"{symbol.replace('USDT', '')}: история {t0['n']} сд {t0['r']:+}R; вперёд {v['n']} сд, PF {v['pf']}, {v['r']:+}R "
                        f"(половины {h1:+.1f}/{h2:+.1f}R); справка: другие монеты в плюсе {pos} из {len(res)}")
            c["name"] = f"Pine: {comp.get('title') or 'стратегия'} · {'лонг' if side > 0 else 'шорт'} · стоп {sl} ATR · тейк {rr}R"
            c["pine"] = cfg.get("src", "")[:20000]
            c["side"] = side; c["symbol"] = symbol; c["tf"] = tf
            days = max(1, (d.t.iloc[-1] - d.t.iloc[cut]) / 86400_000)
            c["month_pct_1r"] = round(v["r"] / days * 30, 1)
            rows.append(c)
        J.update(pct=100, text="готово", done=True, result={"symbol": symbol, "tf": tf, "side": sides[0], "tried": len(sides),
                                                            "passed": sum(1 for x in rows if x["verdict"] == "прошла"), "rows": rows,
                                                            "warnings": comp.get("warnings", [])})
    except Exception as exc:  # noqa: BLE001
        J.update(done=True, error=str(exc)[:300])


def start(src: str, symbol: str, tf: str, sl: float, rr: float) -> dict:
    import subprocess  # noqa: PLC0415
    comp = compile_pine(src)                      # ошибки перевода — сразу, до запуска
    sys.path.insert(0, str(BASE))
    import strategy_gen as G  # noqa: PLC0415
    job = uuid.uuid4().hex[:10]
    G.OUT.mkdir(exist_ok=True)
    cfg = G.OUT / f"pine_{job}.cfg.json"
    cfg.write_text(json.dumps({"comp": comp, "src": src, "symbol": symbol.upper(), "tf": tf if tf in G.TF_MIN else "1h",
                               "sl": sl, "rr": rr}, ensure_ascii=False), encoding="utf-8")
    G._FileJob(job).update(pct=0, text="старт", done=False)
    venv = BASE / "venv" / "Scripts" / "python.exe"
    py = str(venv) if venv.exists() else sys.executable
    subprocess.Popen([py, str(BASE / "pine_lab.py"), job, str(cfg)], cwd=str(BASE),
                     creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    return {"job": job, "compiled": comp}


if __name__ == "__main__":
    run(sys.argv[1], sys.argv[2])
