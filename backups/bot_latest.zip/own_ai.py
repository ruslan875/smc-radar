"""own_ai.py — 2026-10-06. Собственный ИИ TRADEOS: модель машинного обучения, обученная на ВАШИХ свечах.
Учится по всей истории сигналов «пробой канала 4h» (12 монет), какие из них доходят до тейка, по ~40 индикаторам.
  python own_ai.py train   — обучить/переобучить (делается и автоматически раз в 30 дней ботом пробоя)
  python own_ai.py score   — проверить загрузку модели
Модель: own_ai_model.pkl (рядом), отчёт обучения — own_ai_report.json.
Проверка 2024–26 (до обучения на всём): худшие 30% по оценке дали +0.03R/сд против +0.17R у остальных.
Режим: ЭКСПЕРИМЕНТ — оценка показывается в сигнале, но сделки не отфильтровывает.
"""
import sys as _sys
try:
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass
import json
import pickle
import time
from pathlib import Path

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parent
MODEL = BASE / "own_ai_model.pkl"
REPORT = BASE / "own_ai_report.json"


def train() -> dict:
    import kvoo_longtest as K  # noqa: PLC0415
    import ml_filter_test as M  # noqa: PLC0415
    from sklearn.ensemble import HistGradientBoostingClassifier  # noqa: PLC0415
    rows = []
    for s in K.COINS:
        d = K.load(s, "4h")
        if d is not None and len(d) > 800:
            rows += M.signals(d.reset_index(drop=True), s.replace("USDT", ""))
    df = pd.DataFrame(rows).replace([np.inf, -np.inf], np.nan).fillna(0)
    cols = [c for c in df.columns if c not in ("coin", "t", "r")]
    y = (df.r > 0).astype(int).values
    # 2026-10-27: честная проверка ПЕРЕД обучением на всём — учим на старых 75% сигналов, проверяем на свежих 25%
    df = df.sort_values("t").reset_index(drop=True); y = (df.r > 0).astype(int).values
    cut = int(len(df) * 0.75)
    chk = HistGradientBoostingClassifier(max_depth=3, learning_rate=0.05, max_iter=200, l2_regularization=1.0,
                                         min_samples_leaf=40, random_state=1).fit(df[cols].values[:cut], y[:cut])
    pt = chk.predict_proba(df[cols].values[cut:])[:, 1]; rt = df.r.values[cut:]
    q3, q7 = np.quantile(pt, 0.3), np.quantile(pt, 0.7)
    check = {"test_signals": int(len(rt)), "all_R": round(float(rt.mean()), 3),
             "strong_R": round(float(rt[pt >= q7].mean()), 3), "weak_R": round(float(rt[pt < q3].mean()), 3)}
    check["works"] = bool(check["strong_R"] > check["all_R"] + 0.05 and check["weak_R"] < check["all_R"] - 0.05)
    mdl = HistGradientBoostingClassifier(max_depth=3, learning_rate=0.05, max_iter=200, l2_regularization=1.0,
                                         min_samples_leaf=40, random_state=1).fit(df[cols].values, y)
    p = mdl.predict_proba(df[cols].values)[:, 1]
    lo, hi = float(np.quantile(p, 0.3)), float(np.quantile(p, 0.7))
    rep = {"trained": time.strftime("%Y-%m-%d %H:%M"), "signals": len(df), "cols": cols, "lo": lo, "hi": hi,
           "base_wr": float(y.mean()), "check": check}
    MODEL.write_bytes(pickle.dumps({"model": mdl, **rep}))
    REPORT.write_text(json.dumps(rep, ensure_ascii=False, indent=1), encoding="utf-8")
    return rep


_cache: dict = {}


def score(d: pd.DataFrame, i: int, side: int) -> dict | None:
    """Оценка сигнала на свече i (d: t,o,h,l,c,v). None — модели нет."""
    try:
        if "m" not in _cache or _cache.get("mt") != MODEL.stat().st_mtime:
            _cache["m"] = pickle.loads(MODEL.read_bytes()); _cache["mt"] = MODEL.stat().st_mtime
        m = _cache["m"]
        import ml_filter_test as M  # noqa: PLC0415
        f, _mid, _sd = M.feats(d.reset_index(drop=True))
        x = f.iloc[i].to_dict()
        for key in ("ema20_dist", "ema50_dist", "ema200_dist", "ema20_slope", "ema50_slope", "ema200_slope", "sma200_dist", "macd",
                    "macd_hist", "bb_pos", "di_diff", "obv_slope", "ret1", "ret5", "ret20", "ret60", "body", "htf_trend", "ch_slope"):
            x[key] = x[key] * side
        x["side"] = side
        row = np.array([[float(np.nan_to_num(x.get(c, 0.0), posinf=0, neginf=0)) for c in m["cols"]]])
        p = float(m["model"].predict_proba(row)[0, 1])
        lvl = "сильный" if p >= m["hi"] else "слабый" if p < m["lo"] else "средний"
        return {"p": p, "level": lvl, "trained": m["trained"]}
    except Exception:  # noqa: BLE001
        return None


def age_days() -> float:
    return (time.time() - MODEL.stat().st_mtime) / 86400 if MODEL.exists() else 1e9


if __name__ == "__main__":
    if len(_sys.argv) > 1 and _sys.argv[1] == "train":
        print("обучаю на всей истории сигналов…"); r = train()
        print(f"готово: {r['signals']} сигналов, модель {MODEL.name}")
        c = r["check"]
        print(f"Проверка на свежих {c['test_signals']} сигналах (модель их не видела): все {c['all_R']:+.3f}R/сд, "
              f"«сильные» {c['strong_R']:+.3f}R, «слабые» {c['weak_R']:+.3f}R")
        print("ВЫВОД: модель различает сигналы" if c["works"] else "ВЫВОД: модель НЕ отличает хорошие сигналы от плохих — фильтром не ставить")
    else:
        print("модель есть" if MODEL.exists() else "модели нет — запустите: python own_ai.py train")
    input("Enter — закрыть")
