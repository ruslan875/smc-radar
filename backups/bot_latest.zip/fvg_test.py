"""fvg_test.py — 2026-10-05. Проверка торговли по «неэффективности» (FVG / имбаланс, Smart Money) на крипте.
Свечи — тот же склад Binance с 2019 (kvoo_longtest.load), 12 монет, 1h и 4h, комиссия 0.11%.
FVG вверх: low[i] > high[i-2] (между тенями свечей i-2 и i разрыв), импульсная свеча i-1. Зона = [high[i-2], low[i]].
Вход: лимит на возврате цены в зону (верх зоны для лонга / низ для шорта) в течение 30 свечей; иначе отмена.
Стоп: за дальней границей зоны − 0.3 ATR. Тейк: 1R / 2R / 3R. Лимит сделки 100 свечей.
Фильтры: без фильтра · только по тренду (EMA 200) · только крупные FVG (≥ 0.5 ATR).
Честно: итог отдельно до 2024 и 2024–2026 (проверка вперёд), сколько монет в плюсе. Результат — fvg_test.csv.
"""
import csv
import numpy as np
import pandas as pd

COST = 0.0011
CUT = pd.Timestamp("2024-01-01", tz="UTC").value // 10**6


def run(d, rr, flt):
    o, h, l, c, t = (d[k].values for k in "ohlct")
    pc = np.r_[c[0], c[:-1]]; tr = np.maximum(h - l, np.maximum(abs(h - pc), abs(l - pc)))
    atr = pd.Series(tr).ewm(alpha=1 / 14, adjust=False).mean().values
    ema = pd.Series(c).ewm(span=200, adjust=False).mean().values
    out = []; i = 202; n = len(c)
    while i < n - 2:
        side = 0
        if l[i] > h[i - 2]: side, top, bot = 1, l[i], h[i - 2]
        elif h[i] < l[i - 2]: side, top, bot = -1, l[i - 2], h[i]
        if side and flt == "trend" and (side > 0) != (c[i] > ema[i]): side = 0
        if side and flt == "big" and (top - bot) < 0.5 * atr[i]: side = 0
        if not side:
            i += 1; continue
        entry = top if side > 0 else bot
        stop = (bot - 0.3 * atr[i]) if side > 0 else (top + 0.3 * atr[i])
        risk = abs(entry - stop); tp = entry + side * rr * risk
        j0 = None
        for j in range(i + 1, min(n, i + 31)):          # ждём возврата в зону
            if (h[j] >= tp) if side > 0 else (l[j] <= tp): break      # ушла к цели без нас — отмена
            if (l[j] <= entry) if side > 0 else (h[j] >= entry): j0 = j; break
        if j0 is None or risk <= 0:
            i += 1; continue
        r = None; k = j0
        if (l[j0] <= stop) if side > 0 else (h[j0] >= stop): r = -1.0   # в свече входа задели и стоп — считаем стопом
        else:
            for k in range(j0 + 1, min(n, j0 + 101)):
                if (l[k] <= stop) if side > 0 else (h[k] >= stop): r = -1.0; break
                if (h[k] >= tp) if side > 0 else (l[k] <= tp): r = rr; break
            else:
                k = min(n - 1, j0 + 100); r = side * (c[k] - entry) / risk
        out.append((t[j0], r - COST * entry / risk)); i = k + 1
    return out


if __name__ == "__main__":
    import kvoo_longtest as K
    data = {}
    for tf in K.TFS:
        for s in K.COINS:
            print("свечи", s, tf); d = K.load(s, tf)
            if d is not None and len(d) > 500: data[(s, tf)] = d
    rows = []
    for tf in K.TFS:
        for flt, fname in (("none", "без фильтра"), ("trend", "по тренду EMA200"), ("big", "крупные ≥0.5 ATR")):
            for rr in (1, 2, 3):
                a = b = 0.0; nt = wins = plus = 0; per = {}
                for s in K.COINS:
                    if (s, tf) not in data: continue
                    tr = run(data[(s, tf)], rr, flt); rs = sum(r for _, r in tr); per[s.replace("USDT", "")] = round(rs, 1); plus += rs > 0
                    for tt, r in tr:
                        nt += 1; wins += r > 0
                        if tt < CUT: a += r
                        else: b += r
                row = {"tf": tf, "фильтр": fname, "тейк": f"{rr}R", "сделок": nt, "WR%": round(100 * wins / max(1, nt), 1),
                       "R_2019_23": round(a, 1), "R_2024_26": round(b, 1), "R_на_сделку": round((a + b) / max(1, nt), 3), "монет_в_плюсе": f"{plus}/{len(per)}", **per}
                rows.append(row)
                print(f"{tf} FVG {fname:18} тейк {rr}R | сделок {nt:6} WR {row['WR%']:5}% | до 2024 {a:+8.1f}R | 2024–26 {b:+7.1f}R | {row['R_на_сделку']:+.3f}R/сд | монет+ {plus}/{len(per)}")
    keys = list(dict.fromkeys(k for r in rows for k in r))
    with open(K.BASE / "fvg_test.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=keys, delimiter=";"); w.writeheader(); w.writerows(rows)
    print("\nГотово. Пришлите скрин или fvg_test.csv")
    input("Enter — закрыть")
