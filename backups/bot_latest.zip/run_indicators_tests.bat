@echo off
cd /d "%~dp0"
set "PY=python"
if exist venv\Scripts\python.exe set "PY=venv\Scripts\python.exe"
"%PY%" -X utf8 run_tests.py indicators
echo.
pause
