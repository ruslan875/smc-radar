@echo off
cd /d D:\VANTORIX\bot
venv\Scripts\python.exe std_ind_test.py
pause
