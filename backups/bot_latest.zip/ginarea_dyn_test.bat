@echo off
cd /d D:\VANTORIX\bot
venv\Scripts\python.exe ginarea_dyn_test.py %1
pause
