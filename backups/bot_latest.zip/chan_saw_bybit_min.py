"""chan_saw_bybit_min.py — 2026-10-20. Пробой канала 100 (тейк 2R, стоп у центра) на МИНУТНЫХ ТФ Bybit:
1m / 3m / 5m / 15m / 30m (и 1h для сравнения), минутки Bybit за последние DAYS дней, 12 монет.
Две комиссии: 0.09% (тейкер пользователя) и 0.055%. ✅ = итог > 0, ≥ 8/12 монет, обе половины > 0.
Первый запуск качает ~430 тыс. минуток на монету (≈ 3–5 мин на монету), потом кеш market_cache/bybit_<SYM>_1m.pkl.
Ничего не торгует. Запуск: chan_saw_bybit_min.bat → bt_lab_bots/chan_saw_bybit_min.txt
"""
from __future__ import annotations
import pickle, sys, time
from pathlib import Path
import numpy as np
import requests
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import chan_speed_test as CS  # noqa: E402
OUT = BASE / "bt_lab_bots" / "chan_saw_bybit_min.txt"
CDIR = BASE / "market_cache"
DAYS = int(sys.argv[1]) if len(sys.argv) > 1 else 300
COINS = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT", "DOGEUSDT", "ADAUSDT", "SUIUSDT", "LINKUSDT", "AVAXUSDT",
         "BNBUSDT", "NEARUSDT", "HYPEUSDT"]
FEES = [(0.0009, "0.09%"), (0.00055, "0.055%")]
LINES = []
def say(s=""):
    print(s, flush=True); LINES.append(s)

def bybit_1m(sym, days):
    path = CDIR / f"bybit_{sym}_1m.pkl"
    have = pickle.loads(path.read_bytes()) if path.exists() else {}
    need_from = int((time.time() - days * 86400) * 1000)
    end, k = None, 0
    stop_at = max(have) if have else need_from
    while True:                                   # новое (или всё)
        p = {"category": "linear", "symbol": sym, "interval": "1", "limit": 1000}
        if end:
            p["end"] = end
        j = None
        for a in range(5):
            try:
                j = requests.get("https://api.bybit.com/v5/market/kline", params=p, timeout=30).json(); break
            except requests.RequestException:
                time.sleep(2 * (a + 1))
        lst = (j or {}).get("result", {}).get("list") or []
        if not lst:
            break
        for r in lst:
            have[int(r[0])] = (float(r[2]), float(r[3]), float(r[4]))
        end = int(lst[-1][0]) - 1; k += 1
        if k % 50 == 0:
            print(f"  {sym} 1m: {time.strftime('%Y-%m-%d', time.gmtime(end / 1000))}", flush=True)
        if end < stop_at or len(lst) < 1000:
            break
        time.sleep(0.08)
    if have and min(have) > need_from + 60_000:   # история раньше кеша
        end = min(have) - 1
        while end > need_from:
            j = None
            for a_ in range(6):   # 2026-10-21: повторы при таймауте Bybit (BTC/ETH падали с «Read timed out»)
                try:
                    j = requests.get("https://api.bybit.com/v5/market/kline", params={"category": "linear", "symbol": sym,
                                     "interval": "1", "limit": 1000, "end": end}, timeout=30).json(); break
                except (requests.RequestException, ValueError):
                    time.sleep(3 * (a_ + 1))
            if j is None:
                break
            lst = j.get("result", {}).get("list") or []
            if not lst:
                break
            for r in lst:
                have[int(r[0])] = (float(r[2]), float(r[3]), float(r[4]))
            end = int(lst[-1][0]) - 1; time.sleep(0.08)
    CDIR.mkdir(exist_ok=True); path.write_bytes(pickle.dumps(have))
    now = int(time.time() * 1000)
    ts = np.array(sorted(t for t in have if need_from <= t and t + 60_000 <= now), dtype=np.int64)
    a = np.array([have[t] for t in ts])
    return {"t": ts, "h": a[:, 0], "l": a[:, 1], "c": a[:, 2]}

def main():
    say(f"Пробой канала 100 (2R, стоп центр) · минутные ТФ · свечи BYBIT · {DAYS} дн. · {time.strftime('%Y-%m-%d %H:%M')}")
    raw = {}
    for s in COINS:
        for att in range(3):   # монета целиком — до 3 попыток, докачка продолжается с кеша
            try:
                raw[s] = bybit_1m(s, DAYS); break
            except Exception as exc:  # noqa: BLE001
                say(f"  {s}: попытка {att + 1}: ошибка {exc}"[:140]); time.sleep(10)
    raw = {s: d for s, d in raw.items() if len(d["c"]) > 20000}
    months = np.median([(d["t"][-1] - d["t"][0]) / (30.4 * 864e5) for d in raw.values()])
    say(f"Монет {len(raw)} · ~{months * 30.4:.0f} дней")
    for fee, fname in FEES:
        CS.FEE = fee
        say(""); say(f"=== комиссия {fname} на сторону ===")
        say(f"{'ТФ':<5}{'итог R':>10}{'R/мес':>9}{'монет +':>9}{'1-я':>10}{'2-я':>10}{'сделок':>8}{'ср. в сделке':>14}")
        for mm in (1, 3, 5, 15, 30, 60):
            tot, h1, h2, plus, n, hold = 0.0, 0.0, 0.0, 0, 0, []
            for s, d0 in raw.items():
                d = CS.rs(d0, mm * 60_000) if mm > 1 else d0
                tr = CS.chan_trades(d, 2.0, 1.0)
                if not tr:
                    continue
                mid = d["t"][len(d["t"]) // 2]
                r = sum(x[1] for x in tr); tot += r; n += len(tr); plus += r > 0; hold += [x[2] * mm for x in tr]
                h1 += sum(x[1] for x in tr if x[0] < mid); h2 += sum(x[1] for x in tr if x[0] >= mid)
            ok = tot > 0 and plus >= 8 and h1 > 0 and h2 > 0
            name = f"{mm}m" if mm < 60 else "1h"
            say(f"{name:<5}{tot:>+10.1f}{tot / months:>+9.2f}{f'{plus}/{len(raw)}':>9}{h1:>+10.1f}{h2:>+10.1f}{n:>8}"
                f"{(np.mean(hold) / 60 if hold else 0):>11.1f} ч  {'✅' if ok else '❌'}")
    say(""); say("Для сравнения: на OKX (0.05%) 1m −19137R, 5m −1512R, 15m −286R, 30m +11R (❌) за 300 дней.")
    OUT.parent.mkdir(exist_ok=True); OUT.write_text("\n".join(LINES), encoding="utf-8"); print(f"\nОтчёт: {OUT}")

if __name__ == "__main__":
    main()
