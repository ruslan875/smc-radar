#!/usr/bin/env python3
"""
Fee-aware, no-lookahead backtester for the FOURTH Veles Finance bot this
round: share code ETNAR, SUI/USDT, described by the user as "a scalping
strategy" -- and structurally very different from the other three. Read
directly off the live Veles "Создание бота" page via Claude-in-Chrome DOM
extraction (accessibility-tree textbox/toggle values + visual screenshots
for the toggle ON/OFF states, which the DOM alone can't be trusted for --
every checkbox renders value="on" in the DOM regardless of actual state).

IMPORTANT CORRECTION vs. an earlier mis-read of this same bot: the 6-row
table with offsets 0.5/0.9/1.8/2.4/3.7/4.5% and volumes 15/15/15/15/20/20%
is NOT the entry DCA grid -- it is the "Свой" (Custom) TAKE-PROFIT ladder
under "Выход из сделки". The actual entry order grid ("Ордера сделки") is
in "Простой" (Simple) mode with only 2 orders total and a 2% overlap. This
was confirmed by visually checking which "Режим торговли" tab is
highlighted in each of the two separate sections (they look identical in
the raw DOM dump, which is what caused the earlier mix-up).

CONFIRMED from the live page (DOM text/values + a visual screenshot for
every toggle):
  - LONG only, SUI/USDT.
  - Условия открытия сделки -- 2 filters (no preset used; Консервативный/
    Умеренный/Агрессивный presets with 7/4/4 filters all sit unselected):
      Filter 1: Полосы Боллинджера (Bollinger Bands), 30m, на закрытии бара.
                Renders with NO separate condition/threshold row in the
                DOM (confirmed absent) -- see ASSUMED below.
      Filter 2: ADX, 15m, на закрытии бара, Больше 25.
  - Ордера сделки -- режим "Простой" (Simple) tab confirmed highlighted
    (Свой/Сигнал both inactive). None of the Консервативный/Умеренный/
    Агрессивный presets are selected (their radio dots are unfilled) --
    a custom combination is used instead:
      ПЕРЕКРЫТИЕ (overlap):     2%
      СЕТКА ОРДЕРОВ (orders):   2      (base order + exactly 1 safety order)
      % МАРТИНГЕЙЛА:            1%     (safety order's $ volume = 1% more than base)
      ОТСТУП (order type):      Маркет
      ЛОГАРИФМИЧЕСКОЕ РАСПРЕДЕЛЕНИЕ ЦЕН: OFF (toggle visually grey)
      ЧАСТИЧНОЕ ВЫСТАВЛЕНИЕ СЕТКИ ОРДЕРОВ: 2 (of max 2 -- both orders
        placed upfront, no batching; irrelevant with only 2 orders anyway)
      ПОДТЯЖКА СЕТКИ ОРДЕРОВ (grid pull-up): 1%
      ОСТАНОВИТЬ БОТА ПОСЛЕ ЗАВЕРШЕНИЯ СДЕЛОК: OFF (visually grey)
      ВКЛЮЧАТЬ ПОЗИЦИЮ НА БИРЖЕ В СДЕЛКУ: ON (visually orange/lit)
  - Выход из сделки -- Тейк-профит режим "Свой" (Custom) confirmed
    highlighted. 6/40 orders configured, "Остаток объёма депозита: 0%"
    (i.e. the 6 rows are confirmed to sum to exactly 100% of the deal's
    volume):
      Отступ% / Объём%:  0.5 / 15,  0.9 / 15,  1.8 / 15,
                          2.4 / 15,  3.7 / 20,  4.5 / 20
    Валюта профита: USDT.
  - Стоп-лосс: OFF. Стоп-лосс по сигналу: OFF (both visually grey) -- this
    bot has NO stop-loss at all, matching Bot C (Volgoflint/DcHGj).
  - "Стоп в Б/У" (breakeven stop) toggle: ON (visually orange/lit) --
    ЗНАЧЕНИЕ: "От ТП" (from take-profit), ОТКЛОНЕНИЕ: "Отключено"
    (deviation: disabled, i.e. no offset applied to the breakeven level).
    This feature was NOT present in any of the three prior bots this
    round -- see ASSUMED below for how it's modelled here.

ASSUMED (Veles' UI doesn't expose these anywhere inspected, or the exact
mechanics of a feature are ambiguous -- every one is a CLI flag):
  - Bollinger Bands condition/direction: "close BELOW the lower band"
    (--bb-condition below|above), length 20 / mult 2.0
    (--bb-length/--bb-mult, TradingView defaults) -- same reasoning as
    Bot C: a long entry filter pairing naturally reads as a pullback/
    mean-reversion trigger, but this is inference, not a read value.
  - ADX di-length/smoothing (--adx-di-length/--adx-smoothing, default
    14/14): Veles never exposed a period field for this filter.
  - "Стоп в Б/У" mechanics: modelled as -- once ANY partial take-profit
    level fires for a deal, arm a breakeven exit for whatever quantity of
    the position is still open. From the bar AFTER arming, if price
    trades back down to the average entry price (deviation disabled = 0%
    offset, matching "Отключено"), close the remaining quantity at that
    price. This is a reasonable reading of "Значение: От ТП, Отклонение:
    Отключено" but Veles does not document the exact trigger/scope
    anywhere inspected (e.g. whether it arms after the FIRST partial fill
    specifically, as modelled here, or only after ALL of them, or moves a
    literal stop order vs. a synthetic check) -- flagged as the single
    biggest structural assumption in this script. Override nothing here
    via CLI (kept simple); if the real mechanism turns out materially
    different, results should be treated as indicative only, not final.
  - Interaction between the 2-order entry grid and the 6-level TP ladder
    when the grid hasn't finished resolving yet (order 2 still pending or
    already pulled up) while a TP level already fired once: this script
    fixes each TP level's sell quantity as a % of the *planned* full
    2-order position size (i.e. as if order 2 will eventually fill, using
    its known target price to size it), then caps the actual quantity
    sold at whatever is actually held at that moment. If order 2 never
    ends up filling (price never dipped to it, or it got pulled up), the
    later TP levels (or the final breakeven/timeout close) simply sell
    less than their nominal % once the real position runs out. This keeps
    the sum-of-percentages-must-equal-100% constraint Veles enforces in
    the UI internally consistent without inventing extra state.
  - Fees: like every other script in this batch, the primary reported
    "net" P&L subtracts one flat round-trip FEE_SCENARIOS rate from the
    deal's gross P&L%, same convention used throughout this project. This
    materially UNDERSTATES real costs here specifically, because a single
    ETNAR deal can rack up 2 entry fills + up to 7 exit fills (6 partial
    TPs + a breakeven close) -- up to 9 fills vs. the 1-2 typical of the
    other bots. A second, fill-count-scaled net P&L% is also reported
    (assuming each fill costs half of one round-trip's fee) as a more
    realistic floor for this specific bot.
  - Order fills: safety order 2 and every partial TP/breakeven level are
    assumed to fill exactly at their trigger price the instant intrabar
    high/low touches it (no slippage modelled), same simplification used
    throughout this project despite "Отступ: Маркет" implying real market
    fills would slip slightly past the trigger.

Needs network access to Bybit's public API -- run on your own machine:

    python etnar_bb_adx_scalp_backtest.py --symbol SUIUSDT --bars 200000
"""
from __future__ import annotations

import argparse
import csv
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np
import pandas as pd
import requests

from app.data import BYBIT_BASE, INTERVAL_MAP, DataError
from app.indicators.common import sma, stdev, dmi_adx
from app.indicators.veles_style import htf_closed_series

# CONFIRMED 2026-09-04 from real account fee screenshots (both exchanges,
# futures only -- this account does not trade spot). Round-trip rates
# (entry+exit combined), replacing the old generic placeholder guess.
# Bybit futures, "Обычный пользователь" tier, 10% MNT discount currently
# ACTIVE: maker 0.0324%, taker 0.0900% per fill.
# OKX futures, "Обычные пользователи" tier, no discount toggle shown:
# maker 0.0200%, taker 0.0500% per fill.
FEE_SCENARIOS = {
    "bybit_taker+taker": 0.0018,
    "bybit_taker+maker": 0.001224,
    "bybit_maker+maker": 0.000648,
    "okx_taker+taker": 0.0010,
    "okx_taker+maker": 0.0007,
    "okx_maker+maker": 0.0004,
}

TP_LEVELS_DEFAULT = [
    (0.5, 15.0),
    (0.9, 15.0),
    (1.8, 15.0),
    (2.4, 15.0),
    (3.7, 20.0),
    (4.5, 20.0),
]


# --------------------------------------------------------------- data --

def _fetch_page(params: dict, symbol: str, retries: int = 4, timeout: float = 15.0) -> dict:
    # Hardened 2026-09-05 after a real incident: running a heavy multi-symbol
    # backtest at the same time as the live bot on the same API key hit
    # Bybit's rate limit ("Too many visits. Exceeded the API Rate Limit."),
    # which comes back as a normal HTTP 200 with retCode != 0 -- the original
    # code only retried on network exceptions, so a rate-limit hit raised
    # DataError immediately with zero retries. Now retries on retCode != 0
    # too, with the same backoff as network errors.
    last_exc: Exception | None = None
    for attempt in range(retries):
        try:
            resp = requests.get(f"{BYBIT_BASE}/v5/market/kline", params=params, timeout=timeout)
            resp.raise_for_status()
            payload = resp.json()
            if payload.get("retCode") == 0:
                return payload
            last_exc = RuntimeError(f"retCode={payload.get('retCode')} {payload.get('retMsg')}")
        except requests.RequestException as exc:
            last_exc = exc
        if attempt < retries - 1:
            time.sleep(1.5 * (attempt + 1))
    raise DataError(f"Bybit request failed for {symbol} after {retries} attempts: {last_exc}")


def fetch_history(symbol: str, timeframe: str, total_bars: int, category: str = "linear") -> pd.DataFrame:
    interval = INTERVAL_MAP[timeframe]
    all_rows: list = []
    end = None
    while len(all_rows) < total_bars:
        params = {"category": category, "symbol": symbol, "interval": interval, "limit": 1000}
        if end is not None:
            params["end"] = end
        payload = _fetch_page(params, symbol)
        if payload.get("retCode") != 0:
            raise DataError(f"Bybit API error for {symbol}: {payload.get('retMsg')}")
        rows = payload["result"]["list"]
        if not rows:
            break
        all_rows.extend(rows)
        oldest_ts = int(rows[-1][0])
        end = oldest_ts - 1
        if len(rows) < 1000:
            break
        time.sleep(0.6)

    if not all_rows:
        raise DataError(f"No kline data returned for {symbol} {timeframe}")

    df = pd.DataFrame(all_rows, columns=["open_time", "open", "high", "low", "close", "volume", "turnover"])
    df["open_time"] = df["open_time"].astype("int64")
    df = df.drop_duplicates(subset="open_time")
    for col in ("open", "high", "low", "close", "volume", "turnover"):
        df[col] = df[col].astype(float)
    df["open_time"] = pd.to_datetime(df["open_time"], unit="ms", utc=True)
    df = df.sort_values("open_time").reset_index(drop=True)
    if len(df) > total_bars:
        df = df.tail(total_bars).reset_index(drop=True)

    # Diagnostic added 2026-09-04: surface the real fetched date range and
    # flag any gaps in the candle series. Triggered by a real finding --
    # a run requesting the same --bars 200000 for six symbols produced a
    # ~139-day span for three (SUI/INJ/TIA, newer listings) but a ~345-day
    # span for the other three (ETH/SOL/ARB, deep history) despite an
    # identical bar count, implying non-contiguous/gappy data rather than
    # a genuine 200000-consecutive-minute window for the latter three.
    if len(df) > 1:
        step_seconds = df["open_time"].diff().dt.total_seconds()
        expected_step = step_seconds.median()
        max_gap = step_seconds.max()
        max_gap_idx = step_seconds.idxmax()
        span_days = (df["open_time"].iloc[-1] - df["open_time"].iloc[0]).days
        print(f"  [fetch_history] {symbol}: {len(df)} bars, "
              f"{df['open_time'].iloc[0]} -> {df['open_time'].iloc[-1]} "
              f"({span_days} days)")
        if pd.notna(max_gap) and max_gap > expected_step * 3:
            print(f"  [fetch_history] WARNING: {symbol} has a gap of "
                  f"{max_gap/60:.1f} min (expected ~{expected_step/60:.1f} min "
                  f"between bars) right before "
                  f"{df['open_time'].iloc[max_gap_idx]} -- data is likely "
                  f"NON-CONTIGUOUS, treat this run's results as unreliable "
                  f"until re-fetched.")
    return df


# ----------------------------------------------------------- indicators --

def bollinger_bands(close: pd.Series, length: int, mult: float) -> tuple[pd.Series, pd.Series, pd.Series]:
    basis = sma(close, length)
    dev = mult * stdev(close, length)
    return basis, basis + dev, basis - dev


# ------------------------------------------------------------- params --

@dataclass
class Params:
    bb_length: int
    bb_mult: float
    bb_condition: str        # "below" | "above" -- ASSUMED
    adx_di_length: int       # ASSUMED
    adx_smoothing: int       # ASSUMED
    adx_threshold: float     # CONFIRMED 25
    overlap_pct: float       # CONFIRMED 2.0  (Перекрытие)
    martingale_pct: float    # CONFIRMED 1.0  (% Мартингейла, order2 $ step)
    pullup_pct: float        # CONFIRMED 1.0  (Подтяжка сетки ордеров)
    tp_levels: list[tuple[float, float]]  # CONFIRMED, see TP_LEVELS_DEFAULT
    max_deal_bars: int


@dataclass
class Deal:
    symbol: str
    entry_time: pd.Timestamp
    exit_time: pd.Timestamp | None
    entry_price: float          # order-1 (base) fill price
    avg_price: float            # final average cost basis (order1, +order2 if filled)
    exit_price: float           # volume-weighted average exit price across all fills
    reason: str                 # "TP_FULL" | "BREAKEVEN_REMAINDER" | "TIMEOUT" | "OPEN_AT_CUTOFF"
    bars_held: int
    gross_pnl_pct: float | None
    order2_filled: bool
    pulled_up: bool
    fill_count: int             # entry fills (1 or 2) + exit events with qty>0
    tp_levels_hit: int
    meta: dict = field(default_factory=dict)


def compute_indicators(df: pd.DataFrame, p: Params) -> dict:
    bb_lower_30m = htf_closed_series(df, 30, lambda h: bollinger_bands(h["close"], p.bb_length, p.bb_mult)[2])
    bb_upper_30m = htf_closed_series(df, 30, lambda h: bollinger_bands(h["close"], p.bb_length, p.bb_mult)[1])
    bb_cond = (df["close"] < bb_lower_30m) if p.bb_condition == "below" else (df["close"] > bb_upper_30m)

    adx_15m = htf_closed_series(df, 15, lambda h: dmi_adx(h, p.adx_di_length, p.adx_smoothing))
    adx_cond = adx_15m > p.adx_threshold

    entry_raw = bb_cond.fillna(False) & adx_cond.fillna(False)
    entry_signal = entry_raw & ~entry_raw.shift(1).fillna(False)
    entry_defined = bb_lower_30m.notna() & adx_15m.notna()

    return {"entry_signal": entry_signal, "entry_defined": entry_defined}


# --------------------------------------------------------- walk-forward --

def simulate_symbol(df: pd.DataFrame, symbol: str, p: Params) -> list[Deal]:
    ind = compute_indicators(df, p)
    entry_signal = ind["entry_signal"]
    entry_defined = ind["entry_defined"]

    n = len(df)
    first_valid = entry_defined.idxmax() if entry_defined.any() else None
    if first_valid is None:
        return []

    close = df["close"].to_numpy()
    high = df["high"].to_numpy()
    low = df["low"].to_numpy()

    deals: list[Deal] = []
    i = int(first_valid)
    in_deal = False

    # per-deal mutable state
    base_price = order2_price = avg_price = 0.0
    order1_qty = order2_notional = planned_order2_qty = planned_total_qty = 0.0
    qty_held = cost_basis = proceeds = 0.0
    order2_pending = order2_filled = pulled_up = False
    filled_tp_idx: set[int] = set()
    breakeven_armed = False
    breakeven_price = 0.0
    armed_bar = -1
    deal_start_bar = -1
    num_exit_fills = 0

    ORDER1_NOTIONAL = 100.0

    while i < n:
        if not in_deal:
            if bool(entry_signal.iloc[i]):
                base_price = close[i]
                order1_qty = ORDER1_NOTIONAL / base_price
                qty_held = order1_qty
                cost_basis = ORDER1_NOTIONAL
                avg_price = base_price
                order2_price = base_price * (1 - p.overlap_pct / 100.0)
                order2_notional = ORDER1_NOTIONAL * (1 + p.martingale_pct / 100.0)
                planned_order2_qty = order2_notional / order2_price
                planned_total_qty = order1_qty + planned_order2_qty
                order2_pending = True
                order2_filled = False
                pulled_up = False
                filled_tp_idx = set()
                breakeven_armed = False
                breakeven_price = 0.0
                armed_bar = -1
                proceeds = 0.0
                num_exit_fills = 0
                deal_start_bar = i
                in_deal = True
            i += 1
            continue

        j = i
        closed = False
        reason = ""

        # 1) resolve pending safety order (fill vs pull-up cancel)
        if order2_pending:
            if low[j] <= order2_price:
                order2_filled = True
                order2_pending = False
                qty_held += planned_order2_qty
                cost_basis += order2_notional
                avg_price = cost_basis / (order1_qty + planned_order2_qty)
            elif high[j] >= base_price * (1 + p.pullup_pct / 100.0):
                order2_pending = False
                pulled_up = True

        # 2) partial take-profit ladder (ascending offsets), off current avg_price
        for idx, (offset_pct, vol_pct) in enumerate(p.tp_levels):
            if idx in filled_tp_idx:
                continue
            tp_price = avg_price * (1 + offset_pct / 100.0)
            if high[j] >= tp_price:
                intended_qty = planned_total_qty * (vol_pct / 100.0)
                sell_qty = min(intended_qty, qty_held)
                if sell_qty > 1e-12:
                    proceeds += sell_qty * tp_price
                    qty_held -= sell_qty
                    num_exit_fills += 1
                filled_tp_idx.add(idx)
                if not breakeven_armed:
                    breakeven_armed = True
                    breakeven_price = avg_price
                    armed_bar = j

        if qty_held <= 1e-9:
            reason = "TP_FULL"
            closed = True

        # 3) breakeven-remainder close (only from the bar AFTER arming)
        if not closed and breakeven_armed and qty_held > 1e-9 and j > armed_bar:
            if low[j] <= breakeven_price:
                proceeds += qty_held * breakeven_price
                num_exit_fills += 1
                qty_held = 0.0
                reason = "BREAKEVEN_REMAINDER"
                closed = True

        # 4) safety timeout (not part of the real bot)
        if not closed and (j - deal_start_bar) >= p.max_deal_bars:
            proceeds += qty_held * close[j]
            if qty_held > 1e-12:
                num_exit_fills += 1
            qty_held = 0.0
            reason = "TIMEOUT"
            closed = True

        if closed:
            gross_pnl_pct = (proceeds - cost_basis) / cost_basis * 100.0
            fill_count = (2 if order2_filled else 1) + num_exit_fills
            total_qty_sold = cost_basis / avg_price
            deals.append(Deal(
                symbol=symbol, entry_time=df["open_time"].iloc[deal_start_bar],
                exit_time=df["open_time"].iloc[j], entry_price=base_price, avg_price=avg_price,
                exit_price=proceeds / total_qty_sold if total_qty_sold else float("nan"),
                reason=reason, bars_held=j - deal_start_bar, gross_pnl_pct=gross_pnl_pct,
                order2_filled=order2_filled, pulled_up=pulled_up, fill_count=fill_count,
                tp_levels_hit=len(filled_tp_idx),
            ))
            in_deal = False
        i += 1

    if in_deal:
        proceeds += qty_held * close[-1]
        if qty_held > 1e-12:
            num_exit_fills += 1
        gross_pnl_pct = (proceeds - cost_basis) / cost_basis * 100.0
        fill_count = (2 if order2_filled else 1) + num_exit_fills
        total_qty_sold = cost_basis / avg_price
        deals.append(Deal(
            symbol=symbol, entry_time=df["open_time"].iloc[deal_start_bar],
            exit_time=df["open_time"].iloc[-1], entry_price=base_price, avg_price=avg_price,
            exit_price=proceeds / total_qty_sold if total_qty_sold else float("nan"),
            reason="OPEN_AT_CUTOFF", bars_held=(n - 1) - deal_start_bar, gross_pnl_pct=gross_pnl_pct,
            order2_filled=order2_filled, pulled_up=pulled_up, fill_count=fill_count,
            tp_levels_hit=len(filled_tp_idx),
        ))

    return deals


# --------------------------------------------------------------- report --

def net_pnl_pct(deal: Deal, fee_rate: float) -> float | None:
    if deal.gross_pnl_pct is None:
        return None
    return deal.gross_pnl_pct - fee_rate * 100.0


def net_pnl_pct_scaled(deal: Deal, fee_rate: float) -> float | None:
    """Fill-count-scaled net P&L: charges half of one round-trip's fee per
    actual fill, instead of one flat round-trip per deal. More realistic
    for this bot given it can have up to 9 fills per deal (2 entries + up
    to 7 exits) vs. the 1-2 typical elsewhere in this project."""
    if deal.gross_pnl_pct is None:
        return None
    return deal.gross_pnl_pct - (fee_rate / 2.0 * 100.0) * deal.fill_count


def summarize(deals: list[Deal], label: str) -> None:
    if not deals:
        print(f"\n{label}: no deals opened in this window.")
        return
    resolved = [d for d in deals if d.reason in ("TP_FULL", "BREAKEVEN_REMAINDER", "TIMEOUT")]
    still_open = [d for d in deals if d.reason == "OPEN_AT_CUTOFF"]
    wins = [d for d in resolved if d.gross_pnl_pct is not None and d.gross_pnl_pct > 0]
    win_rate = (len(wins) / len(resolved) * 100) if resolved else float("nan")
    avg_gross = (sum(d.gross_pnl_pct for d in resolved) / len(resolved)) if resolved else float("nan")
    avg_bars = (sum(d.bars_held for d in deals) / len(deals)) if deals else float("nan")
    avg_fills = (sum(d.fill_count for d in resolved) / len(resolved)) if resolved else float("nan")
    order2_rate = (sum(1 for d in resolved if d.order2_filled) / len(resolved) * 100) if resolved else float("nan")
    pullup_rate = (sum(1 for d in resolved if d.pulled_up) / len(resolved) * 100) if resolved else float("nan")

    print(f"\n{label}")
    print(f"  Total deals opened:      {len(deals)}")
    print(f"  Resolved:                {len(resolved)}   Still open at cutoff: {len(still_open)}")
    print(f"  Avg bars held/deal:      {avg_bars:.1f}")
    print(f"  Avg fills/deal:          {avg_fills:.2f}   (order2 filled: {order2_rate:.0f}%, pulled up: {pullup_rate:.0f}%)")
    print(f"  Gross win rate:          {win_rate:.1f}%")
    print(f"  Gross avg P&L% :         {avg_gross:+.3f}%")
    reasons = {}
    for d in resolved:
        reasons[d.reason] = reasons.get(d.reason, 0) + 1
    print(f"  Exit reasons: {reasons}")

    for label_fee, fee_rate in FEE_SCENARIOS.items():
        nets = [net_pnl_pct(d, fee_rate) for d in resolved]
        nets = [x for x in nets if x is not None]
        nets_scaled = [net_pnl_pct_scaled(d, fee_rate) for d in resolved]
        nets_scaled = [x for x in nets_scaled if x is not None]
        if not nets:
            continue
        net_wins = sum(1 for x in nets if x > 0)
        print(f"    net (flat) P&L% after {label_fee:12s} fees: {sum(nets)/len(nets):+.3f}%  "
              f"win rate {net_wins/len(nets)*100:.1f}%   |  fill-count-scaled: {sum(nets_scaled)/len(nets_scaled):+.3f}%")


def save_csv(deals: list[Deal], path: Path) -> None:
    if not deals:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = ["symbol", "entry_time", "exit_time", "entry_price", "avg_price", "exit_price",
                  "reason", "bars_held", "gross_pnl_pct", "order2_filled", "pulled_up",
                  "fill_count", "tp_levels_hit"]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for d in deals:
            writer.writerow({k: getattr(d, k) for k in fieldnames})


def split_sample(deals: list[Deal]) -> tuple[list[Deal], list[Deal]]:
    resolved = sorted([d for d in deals if d.reason in ("TP_FULL", "BREAKEVEN_REMAINDER", "TIMEOUT")],
                       key=lambda d: d.entry_time)
    if len(resolved) < 4:
        return resolved, []
    mid = len(resolved) // 2
    return resolved[:mid], resolved[mid:]


# -------------------------------------------------------------------- --

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--symbol", nargs="+", default=["SUIUSDT"])
    parser.add_argument("--timeframe", default="1m")
    parser.add_argument("--bars", type=int, default=200000)
    parser.add_argument("--out", default="etnar_bb_adx_scalp_backtest_out")

    parser.add_argument("--bb-length", type=int, default=20, help="ASSUMED")
    parser.add_argument("--bb-mult", type=float, default=2.0, help="ASSUMED")
    parser.add_argument("--bb-condition", choices=["below", "above"], default="below",
                         help="ASSUMED direction -- see module docstring")

    parser.add_argument("--adx-di-length", type=int, default=14, help="ASSUMED")
    parser.add_argument("--adx-smoothing", type=int, default=14, help="ASSUMED")
    parser.add_argument("--adx-threshold", type=float, default=25.0, help="CONFIRMED from the live page")

    parser.add_argument("--overlap-pct", type=float, default=2.0, help="CONFIRMED (Перекрытие)")
    parser.add_argument("--martingale-pct", type=float, default=1.0, help="CONFIRMED (% Мартингейла)")
    parser.add_argument("--pullup-pct", type=float, default=1.0, help="CONFIRMED (Подтяжка сетки ордеров)")

    parser.add_argument("--max-deal-bars", type=int, default=50000, help="safety timeout only, not part of the real bot")

    args = parser.parse_args()
    p = Params(
        bb_length=args.bb_length, bb_mult=args.bb_mult, bb_condition=args.bb_condition,
        adx_di_length=args.adx_di_length, adx_smoothing=args.adx_smoothing, adx_threshold=args.adx_threshold,
        overlap_pct=args.overlap_pct, martingale_pct=args.martingale_pct, pullup_pct=args.pullup_pct,
        tp_levels=TP_LEVELS_DEFAULT, max_deal_bars=args.max_deal_bars,
    )

    print(__doc__)
    print("=" * 78)

    out_dir = Path(args.out)
    all_deals: list[Deal] = []
    for symbol in args.symbol:
        symbol = symbol.upper()
        print(f"\nFetching + simulating {symbol} ({args.bars} bars of {args.timeframe})...")
        try:
            df = fetch_history(symbol, args.timeframe, args.bars)
            deals = simulate_symbol(df, symbol, p)
        except DataError as exc:
            print(f"  [SKIP] {symbol}: {exc}")
            continue
        print(f"  {len(df)} bars, {df['open_time'].iloc[0]} .. {df['open_time'].iloc[-1]}")
        summarize(deals, symbol)
        save_csv(deals, out_dir / f"{symbol}_deals.csv")

        early, late = split_sample(deals)
        if early and late:
            summarize(early, f"  {symbol} -- EARLY half (split-sample)")
            summarize(late, f"  {symbol} -- LATE half (split-sample)")

        all_deals.extend(deals)
        time.sleep(2.0)  # 2026-09-05: avoid a rate-limit collision with the live bot on the same API key

    summarize(all_deals, "=== COMBINED (all symbols) ===")
    print(f"\nPer-deal CSVs written to {out_dir.resolve()}")


if __name__ == "__main__":
    main()
