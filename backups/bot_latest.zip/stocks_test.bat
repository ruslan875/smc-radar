@echo off
chcp 65001 >nul
cd /d %~dp0
if exist venv\Scripts\python.exe (set PY=venv\Scripts\python.exe) else (set PY=python)
%PY% -X utf8 stocks_test.py
echo.
echo Готово. Результат: stocks_test_summary.txt
pause
