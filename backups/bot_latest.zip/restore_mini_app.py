"""restore_mini_app.py — вернуть в Telegram рабочий Mini App.

ЧТО СЛОМАЛОСЬ. В репозиторий GitHub Pages (ruslan875/smc-radar), из которого
Telegram открывает Mini App, был опубликован HTML панели Pulsar. Панель по
устройству локальная: она ходит на 127.0.0.1:8765 и на этом строит всё, что
показывает. На компьютере это работает. С телефона 127.0.0.1 -- это сам
телефон, там ничего не слушает, поэтому Mini App показывает прочерки вместо
статистики, "Не удалось получить цены (нет сети?)" и "График: HTTP 404".
Никакой поломки сети или туннеля здесь нет: страница просто опубликована не
та.

ЧТО ДЕЛАЕТ ЭТОТ СКРИПТ. Возвращает на место mini_app/index.html -- ту
версию, которая рассчитана на телефон: цены берёт из публичного API Bybit,
статистику из health.json в этом же репозитории, а на локальную машину ходит
только за исполнением ордера, и то через опубликованный адрес туннеля.

Перед заливкой скачивает то, что опубликовано сейчас, в
mini_app/published_backup_<дата>.html -- чтобы вариант с Pulsar не пропал,
если он ещё понадобится.

Запуск:  .\venv\Scripts\python.exe restore_mini_app.py
Проверка без записи:  .\venv\Scripts\python.exe restore_mini_app.py --dry-run
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import requests

from app.config import BASE_DIR, Settings
from app.github_sync import GitHubSyncError, push_binary_file

LOCAL_MINI_APP = BASE_DIR / "mini_app" / "index.html"
REMOTE_PATH = "index.html"


def main() -> int:
    dry_run = "--dry-run" in sys.argv
    settings = Settings.load()

    if not settings.github_token:
        print("GITHUB_TOKEN пуст в .env -- публиковать нечем.", file=sys.stderr)
        return 1

    if not LOCAL_MINI_APP.exists():
        print(f"Нет файла {LOCAL_MINI_APP} -- восстанавливать нечего.", file=sys.stderr)
        return 1

    local = LOCAL_MINI_APP.read_bytes()
    print(f"Локальный Mini App: {LOCAL_MINI_APP} ({len(local):,} байт)")

    # Скачиваем то, что сейчас лежит опубликованным.
    raw_url = f"https://raw.githubusercontent.com/{settings.github_repo}/main/{REMOTE_PATH}"
    try:
        resp = requests.get(raw_url, timeout=20)
        published = resp.content if resp.status_code == 200 else None
    except requests.RequestException as exc:
        print(f"Не удалось скачать опубликованную версию ({exc}); бэкапа не будет.", file=sys.stderr)
        published = None

    if published is not None:
        print(f"Опубликовано сейчас: {len(published):,} байт", end="")
        marker = b"Pulsar"
        print("  (содержит 'Pulsar' -- это панель, а не Mini App)" if marker in published else "")
        if published == local:
            print("Опубликованная версия уже совпадает с локальной. Делать нечего.")
            return 0
        backup = LOCAL_MINI_APP.parent / f"published_backup_{time.strftime('%Y%m%d-%H%M%S')}.html"
        backup.write_bytes(published)
        print(f"Бэкап текущей опубликованной версии: {backup}")

    if dry_run:
        print("\n--dry-run: ничего не залито. Убери флаг, чтобы опубликовать.")
        return 0

    try:
        push_binary_file(
            settings.github_token,
            settings.github_repo,
            REMOTE_PATH,
            local,
            "restore working Telegram Mini App (Pulsar panel is local-only and cannot work from a phone)",
        )
    except GitHubSyncError as exc:
        print(f"Публикация не удалась: {exc}", file=sys.stderr)
        return 1

    print(f"\nГотово. Опубликовано в {settings.github_repo}/{REMOTE_PATH}.")
    print("GitHub Pages обновляется примерно минуту. Потом открой Mini App заново")
    print("(в Telegram имеет смысл закрыть и открыть его снова -- он кэширует страницу).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
