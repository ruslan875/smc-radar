"""chan_speed_test.py — 2026-10-19. Как ускорить пробой канала для челленджа: тейк 1R / 1.5R / 2R × стоп у центра /
на половине пути до центра, на ТФ 15m / 30m / 1h / 2h / 4h. Главная метрика — R В МЕСЯЦ (сумма по 12 монетам),
плюс время в сделке, винрейт, обе половины истории.
Канал регрессии 100, ±2σ, вход по закрытию свечи пробоя (как сигнал в Telegram), не дольше 100 свечей.
Свечи OKX: 1h+ — ~3 года (кеш market_cache/okx_1h_3y_12coins.pkl), 15m/30m — минутки за 300 дней (кеш GinArea-тестов).
Комиссия OKX taker 0.05% на сторону. Ничего не торгует. Запуск: chan_speed_test.bat → bt_lab_bots/chan_speed_test.txt
"""
from __future__ import annotations
import pickle, sys, time
from pathlib import Path
import numpy as np
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
OUT = BASE / "bt_lab_bots" / "chan_speed_test.txt"
CACHE = BASE / "market_cache" / "okx_1h_3y_12coins.pkl"
FEE = 0.0005
N = 100
LINES = []
def say(s=""):
    print(s, flush=True); LINES.append(s)

def rs(d, ms):
    b = (d["t"] // ms).astype(np.int64)
    cut = np.r_[0, np.flatnonzero(np.diff(b)) + 1]
    end = np.r_[cut[1:] - 1, len(b) - 1]
    return {"t": d["t"][cut], "h": np.maximum.reduceat(d["h"], cut), "l": np.minimum.reduceat(d["l"], cut), "c": d["c"][end]}

def chan_trades(d, rr, sf):
    """Возвращает список (t_входа, R, баров в сделке)."""
    t, h, l, c = d["t"], d["h"], d["l"], d["c"]
    n = len(c)
    if n < N + 50:
        return []
    x = np.arange(n, dtype=float)
    cs = lambda a: np.r_[0.0, np.cumsum(a)]  # noqa: E731
    Sy, Sxy, Syy = cs(c), cs(c * x), cs(c * c)
    sx = N * (N - 1) / 2; sxx = (N - 1) * N * (2 * N - 1) / 6; varx = sxx - sx * sx / N
    mid = np.full(n, np.nan); sd = np.full(n, np.nan)
    i = np.arange(N - 1, n); s0 = i - N + 1
    sy = Sy[i + 1] - Sy[s0]; sxy = (Sxy[i + 1] - Sxy[s0]) - s0 * sy; syy = Syy[i + 1] - Syy[s0]
    b = (sxy - sx * sy / N) / varx
    a = sy / N - b * sx / N
    mid[i] = a + b * (N - 1)
    ss = syy - sy * sy / N - b * (sxy - sx * sy / N)
    sd[i] = np.sqrt(np.maximum(ss, 0) / N)
    up, lo = mid + 2 * sd, mid - 2 * sd
    out, k = [], N
    while k < n:
        side = 1 if (c[k] > up[k] and c[k - 1] <= up[k - 1]) else -1 if (c[k] < lo[k] and c[k - 1] >= lo[k - 1]) else 0
        if not side or np.isnan(mid[k]):
            k += 1; continue
        e = c[k]; risk = abs(e - mid[k]) * sf
        if risk <= 0:
            k += 1; continue
        sl, tp = e - side * risk, e + side * rr * risk
        r, j = None, k + 1
        while j < n and j <= k + 100:
            if (l[j] <= sl) if side > 0 else (h[j] >= sl):
                r = -1.0; break
            if (h[j] >= tp) if side > 0 else (l[j] <= tp):
                r = rr; break
            j += 1
        if r is None:
            j = min(j, n - 1); r = side * (c[j] - e) / risk
        out.append((t[k], r - 2 * FEE * e / risk, j - k))
        k = j + 1
    return out

def load():
    raw = pickle.loads(CACHE.read_bytes()) if CACHE.exists() else {}
    if not raw:
        import okx_current_test as OC
        for s in ["BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT", "DOGEUSDT", "ADAUSDT", "SUIUSDT", "LINKUSDT", "AVAXUSDT",
                  "BNBUSDT", "NEARUSDT", "HYPEUSDT"]:
            print(f"  качаю {s} 1h…", flush=True); raw[s] = OC.okx_klines(s, "60", 3 * 365 * 24)
        CACHE.parent.mkdir(exist_ok=True); CACHE.write_bytes(pickle.dumps(raw))
    return {s: d for s, d in raw.items() if len(d["c"]) >= 3000}

def mins(coins):
    import ginarea_op_test as G
    out = {}
    for s in coins:
        try:
            m = G.okx_1m(s.replace("USDT", "") + "-USDT-SWAP", 300)
            out[s] = {"t": m.t.to_numpy().astype(np.int64), "h": m.h.to_numpy(), "l": m.l.to_numpy(), "c": m.c.to_numpy()}
        except Exception as exc:  # noqa: BLE001
            print(f"  {s}: минутки: {exc}", flush=True)
    return out

def main():
    say(f"Скорость пробоя канала · OKX · taker 0.05% · {time.strftime('%Y-%m-%d %H:%M')}")
    hourly = load(); minute = mins(list(hourly))
    tfs = [("15m", minute, 15), ("30m", minute, 30), ("1h", hourly, 60), ("2h", hourly, 120), ("4h", hourly, 240)]
    say(""); say(f"{'ТФ':<5}{'тейк':>5}{'стоп':>8}{'сделок':>8}{'R/мес':>8}{'итог R':>9}{'1-я':>8}{'2-я':>8}"
                 f"{'винрейт':>9}{'ср. в сделке':>14}{'монет+':>8}")
    best = []
    for name, src, mm in tfs:
        data = {s: rs(d, mm * 60_000) for s, d in src.items()}
        months = np.median([(d["t"][-1] - d["t"][0]) / (30.4 * 864e5) for d in data.values()]) if data else 1
        for rr in (1.0, 1.5, 2.0):
            for sf, sname in ((1.0, "центр"), (0.5, "½ пути")):
                allr, h1, h2, hold, plus = [], 0.0, 0.0, [], 0
                for s, d in data.items():
                    tr = chan_trades(d, rr, sf)
                    if not tr:
                        continue
                    mid_t = d["t"][len(d["t"]) // 2]
                    rr_ = [x[1] for x in tr]
                    allr += rr_; hold += [x[2] for x in tr]
                    h1 += sum(x[1] for x in tr if x[0] < mid_t); h2 += sum(x[1] for x in tr if x[0] >= mid_t)
                    plus += sum(rr_) > 0
                if not allr:
                    continue
                tot = sum(allr); pm = tot / months
                ok = tot > 0 and h1 > 0 and h2 > 0 and plus >= 8
                hrs = np.mean(hold) * mm / 60
                say(f"{name:<5}{rr:>4.1f}R{sname:>8}{len(allr):>8}{pm:>+8.2f}{tot:>+9.1f}{h1:>+8.1f}{h2:>+8.1f}"
                    f"{np.mean(np.array(allr) > 0) * 100:>8.0f}%{hrs:>11.1f} ч{plus:>6}/{len(data)} {'✅' if ok else '❌'}")
                if ok:
                    best.append((pm, name, rr, sname, hrs))
        say("")
    say("Лучшие по R в месяц (только ✅):")
    for pm, name, rr, sname, hrs in sorted(best, reverse=True)[:6]:
        say(f"  {name} · тейк {rr}R · стоп {sname}: {pm:+.2f} R/мес на 12 монет, в сделке ~{hrs:.0f} ч")
    say("")
    say("R/мес × риск на сделку в $ = ожидаемый доход в месяц (до серий убытков). Сейчас: 4h · 2R · центр.")
    say("15m/30m — только 300 дней истории, поэтому R/мес там менее надёжен, чем на 1h+ (3 года).")
    OUT.parent.mkdir(exist_ok=True); OUT.write_text("\n".join(LINES), encoding="utf-8"); print(f"\nОтчёт: {OUT}")

if __name__ == "__main__":
    main()
