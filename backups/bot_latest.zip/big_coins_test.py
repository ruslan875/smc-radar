"""big_coins_test.py — 2026-11-09. Большой тест ПРОВЕРЕННЫХ стратегий по многим монетам (запускать на ПК).

Что делает:
  1. Берёт топ-N USDT-перпетуалов Bybit по обороту (по умолчанию 80) + 12 наших монет.
  2. Качает часовые свечи за 3 года (кеш: market_cache/big/<SYM>_1h.pkl — повторный запуск не качает заново).
  3. Прогоняет все стратегии bt_lab.HONEST тем же кодом, что боты (sim_honest): комиссия, проскальзывание, фандинг.
     Черепахи, Donchian, UT и Хейкен-Аши — только лонги (решение 09.11).
  4. Пишет:
     strat_pick.json            — для «Подбора ИИ» (мини-апп и /aipick) по ВСЕМ монетам
     big_coins_test.csv         — каждая монета × стратегия
     big_coins_test_summary.txt — по стратегиям: на скольких монетах плюс, в обеих половинах
Запуск: big_coins_test.bat  (или: python big_coins_test.py --top 80)
"""
from __future__ import annotations

import argparse
import json
import pickle
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import requests

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import bt_lab as B  # noqa: E402

CACHE = BASE / "market_cache" / "big"
CACHE.mkdir(parents=True, exist_ok=True)
OURS = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT", "DOGEUSDT", "ADAUSDT", "SUIUSDT", "LINKUSDT", "AVAXUSDT", "BNBUSDT", "NEARUSDT", "HYPEUSDT"]
LONGONLY = ("honest:turtle", "honest:donch", "honest:ut", "honest:ha18")
NAME = {"honest:turtle_4h": "Черепахи 4h", "honest:turtle_2h": "Черепахи 2h", "honest:chan": "Пробой канала 2h", "honest:donch": "Donchian 4h",
        "honest:bos4h": "BOS 4h", "honest:bos1h": "BOS 1h", "honest:atrfib": "ATR Fib 4h", "honest:bosrt": "BOS ретест 4h",
        "honest:ut": "UT Bot 4h", "honest:ha18": "Хейкен-Аши 2h"}
API = "https://api.bybit.com/v5/market/"


def top_symbols(n: int) -> list[str]:
    r = requests.get(API + "tickers", params={"category": "linear"}, timeout=20).json()
    L = [t for t in r["result"]["list"] if t["symbol"].endswith("USDT") and not t["symbol"].startswith(("USDC", "USDE"))]
    L.sort(key=lambda t: -float(t.get("turnover24h") or 0))
    out = list(OURS)
    for t in L:
        if len(out) >= n + len(OURS):
            break
        if t["symbol"] not in out:
            out.append(t["symbol"])
    return out


def load_1h(sym: str, days: int) -> pd.DataFrame | None:
    f = CACHE / f"{sym}_1h.pkl"
    if f.exists() and time.time() - f.stat().st_mtime < 3 * 86400:
        return pickle.loads(f.read_bytes())
    end = int(time.time() * 1000); start = end - days * 86400_000; rows = []
    cur = end
    while cur > start:
        for att in range(4):
            try:
                r = requests.get(API + "kline", params={"category": "linear", "symbol": sym, "interval": "60", "end": cur, "limit": 1000}, timeout=20).json()
                break
            except Exception:  # noqa: BLE001
                time.sleep(2 + att * 3)
        else:
            return None
        L = (r.get("result") or {}).get("list") or []
        if not L:
            break
        rows += L
        cur = int(L[-1][0]) - 1
        time.sleep(0.12)
    if len(rows) < 2000:
        return None
    df = pd.DataFrame([[int(k[0]), float(k[1]), float(k[2]), float(k[3]), float(k[4]), float(k[5])] for k in rows],
                      columns=["t", "open", "high", "low", "close", "volume"]).drop_duplicates("t").sort_values("t").reset_index(drop=True)
    df = df[df.t >= start].reset_index(drop=True)
    f.write_bytes(pickle.dumps(df))
    return df


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--top", type=int, default=80)
    ap.add_argument("--days", type=int, default=1100)
    a = ap.parse_args()
    B.deals_to_trades = lambda rows, df, p, prog=None: rows   # нужны сами сделки
    syms = top_symbols(a.top)
    print(f"Монет: {len(syms)}. Стратегий: {len(B.HONEST)}. Кеш свечей: {CACHE}", flush=True)
    pick, csv = {}, []
    for k, s in enumerate(syms, 1):
        try:
            df = load_1h(s, a.days)
        except Exception as e:  # noqa: BLE001
            print(f"[{k}/{len(syms)}] {s}: ошибка загрузки {e}", flush=True); continue
        if df is None:
            print(f"[{k}/{len(syms)}] {s}: мало истории — пропуск", flush=True); continue
        t0, t1 = int(df.t.iloc[0]), int(df.t.iloc[-1]); mid = (t0 + t1) / 2; r180 = t1 - 180 * 86400e3
        res = []
        for st, (_desc, tf) in B.HONEST.items():
            try:
                rows = B.sim_honest(df, {"strategy": st, "tf": tf}, lambda *x: None)
            except Exception as e:  # noqa: BLE001
                print(f"   {s} {st}: {e}", flush=True); continue
            if st.startswith(LONGONLY):
                rows = [q for q in rows if q["side"] > 0]
            if len(rows) < 8:
                continue
            arr = np.array([q["pct"] for q in rows]); ti = np.array([q["t_in"] for q in rows])
            pf = arr[arr > 0].sum() / max(1e-9, -arr[arr < 0].sum())
            h1, h2, l6 = arr[ti < mid].sum(), arr[ti >= mid].sum(), arr[ti >= r180].sum()
            r = {"id": st, "name": NAME.get(st, st) + (" · только лонг" if st.startswith(LONGONLY) else ""), "n": int(len(arr)),
                 "win": round(float((arr > 0).mean() * 100)), "sum": round(float(arr.sum()), 1), "pf": round(float(pf), 2),
                 "h1": round(float(h1), 1), "h2": round(float(h2), 1), "d180": round(float(l6), 1), "ok": bool(h1 > 0 and h2 > 0 and pf > 1.1),
                 "days": round((t1 - t0) / 86400e3)}
            res.append(r); csv.append({"symbol": s, **r})
        res.sort(key=lambda r: (-r["ok"], -r["pf"]))
        pick[s] = res
        best = next((r for r in res if r["ok"]), None)
        print(f"[{k}/{len(syms)}] {s}: {round((t1 - t0) / 86400e3)} дн · лучшая: {best['name'] + ' PF ' + str(best['pf']) if best else 'нет ✅'}", flush=True)
    json.dump({"generated": time.strftime("%Y-%m-%d"), "period": f"последние {a.days} дн, Bybit, издержки 0.11%+0.04%+фандинг",
               "coins": pick}, open(BASE / "strat_pick.json", "w", encoding="utf-8"), ensure_ascii=False)
    d = pd.DataFrame(csv); d.to_csv(BASE / "big_coins_test.csv", index=False, encoding="utf-8-sig")
    lines = [f"Большой тест {time.strftime('%Y-%m-%d %H:%M')}: монет {d.symbol.nunique()}, стратегий {d.id.nunique()}", ""]
    for st, g in d.groupby("name"):
        lines.append(f"{st:32s} монет {len(g):3d} · в плюсе {int((g['sum'] > 0).sum()):3d} ({(g['sum'] > 0).mean() * 100:3.0f}%) · "
                     f"✅ обе половины {int(g['ok'].sum()):3d} · средний PF {g['pf'].median():.2f} · сумма {g['sum'].sum():+.0f}%")
    (BASE / "big_coins_test_summary.txt").write_text("\n".join(lines), encoding="utf-8")
    print("\n".join(lines))
    print("\nГотово: strat_pick.json обновлён (мини-апп подхватит за 15 мин), big_coins_test.csv, big_coins_test_summary.txt")


if __name__ == "__main__":
    main()
