@echo off
REM 2026-10-25: DEMO-kopii Latuserge i KC/ROC na demo-schete Bybit (api-demo.bybit.com), svoy uchet obema.
REM Realnye boty ne trogayutsya. Klyuch - iz slota bybit_demo (save_demo_key.bat). Telegram-uvedomleniya vyklyucheny.
cd /d D:\VANTORIX\bot
set BYBIT_TRADE_BASE=https://api-demo.bybit.com
venv\Scripts\python.exe launch_hidden.py latuserge_demo long_strategy15_latuserge_live.py --live --demo --capital-per-deal 100 --max-concurrent-deals 10 --no-telegram-alerts
venv\Scripts\python.exe launch_hidden.py kcroc_demo kc_roc_cci_wt_grid_live.py --live --demo --max-concurrent-deals 10 --no-telegram-alerts
echo.
echo Demo-boty zapushcheny. Logi: logs\latuserge_demo.log i logs\kcroc_demo.log
pause
