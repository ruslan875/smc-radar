"""challenge_sim3.py — 2026-11-01. Челлендж Hash Hedge по ИХ комиссиям: maker 0.01%, taker 0.03% (документация gitbook).
Раньше все тесты шли с 0.11% за круг (Bybit taker + проскальзывание). Тут: 0.03%×2 + 0.02% проскальзывание = 0.08% за круг.
Проверяем: что меняется, и оживают ли 1h-стратегии, которые «убила» комиссия. Цель этапа 1 = 5% (challenge-types), этап 2 = 6%.
План риска: 0.5% → 1% после +2%, 0.25% в −4%; ≤2 в одну сторону. Пишет bt_lab_bots/challenge_sim3.txt"""
from __future__ import annotations

import sys
import time
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import numpy as np  # noqa: E402
import recheck_recent as RR  # noqa: E402
import challenge_sim as CS  # noqa: E402
import challenge_sim2 as C2  # noqa: E402

DAY = CS.DAY


def main():
    import kvoo_longtest as K  # noqa: PLC0415
    now = int(time.time() * 1000)
    lines = ["Hash Hedge, их комиссии 0.08% за круг против наших 0.11% · 12 монет · плавающий минус учитывается"]
    data = {tf: {s: RR.load(s, tf) for s in K.COINS} for tf in ("1h", "2h", "4h")}
    for fee in (0.0011, 0.0008):
        CS.FEE = fee
        raw = {}
        for name, tf in (("chan1h", "1h"), ("chan2h", "2h"), ("donch", "4h"), ("turtle4h", "4h")):
            nm = "chan2h" if name == "chan1h" else name
            trs = []
            for s, d in data[tf].items():
                if d is not None and len(d) > 400:
                    trs += CS.trades(nm, d.reset_index(drop=True), s)
            for x in trs:
                x["pd"] = {p[0]: (p[1], p[2]) for p in x["path"]}
            raw[name] = trs
            r = [x["R"] for x in trs]
            w = lambda days: sum(x["R"] for x in trs if x["t_out"] >= now - days * DAY)  # noqa: E731
            line = (f"комиссия {fee * 100:.2f}% · {name:<9} {len(r):>5} сд · {np.mean(r):+.3f}R/сд · всё {sum(r):+7.0f}R · "
                    f"180д {w(180):+6.0f} · 90д {w(90):+6.0f} · 30д {w(30):+6.0f}")
            print(line, flush=True); lines.append(line)
        pools = {"пробой 2h + Donchian": raw["chan2h"] + raw["donch"], "пробой 1h": raw["chan1h"],
                 "пробой 1h + 2h + Donchian": raw["chan1h"] + raw["chan2h"] + raw["donch"]}
        plan = (0.5, 2, 1.0, 4, 0.25)
        for pname, trs in pools.items():
            trs = sorted(trs, key=lambda x: x["t_in"])
            times = sorted({x["t_in"] for x in trs} | {p[0] for x in trs for p in x["path"]})
            t_first = trs[0]["t_in"] + 30 * DAY; t_last = trs[-1]["t_out"] - 400 * DAY
            res = []
            for t0 in range(t_first, t_last, 28 * DAY):
                tt = t0; total = 0.0; out = "pass"
                for target, dl, dd, md in [(5, 5, 10, 5), (6, 5, 8, 5)]:
                    r_, d_, tend = C2.stage(trs, times, tt, plan, target, dl, dd, md, 2)
                    if r_ != "pass":
                        out = r_; break
                    total += d_; tt = tend + 1
                res.append((out, total if out == "pass" else None))
            n = len(res); ok = [x[1] for x in res if x[0] == "pass"]; fl = sum(1 for x in res if x[0] == "fail")
            line = (f"   челлендж · {pname:<26} → прошли {len(ok) / n * 100:3.0f}% · провал {fl / n * 100:3.0f}% · "
                    + (f"медиана {np.median(ok):.0f} дн · быстрые 25% {np.percentile(ok, 25):.0f} дн" if ok else ""))
            print(line, flush=True); lines.append(line)
    (BASE / "bt_lab_bots" / "challenge_sim3.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("готово")


if __name__ == "__main__":
    main()
