# Идеи из курса PrizrakTrade на базе Пробоя канала 4h (10 монет Binance, 2019–2026, комиссия 0.11%)
import sys, glob, os, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from be_test import load
C = sys.argv[1]; FEE = 0.0011
def chan(d, N=100):
    c = d.c.values; x = np.arange(N); xm = x.mean(); mid = np.full(len(c), np.nan); sd = mid.copy()
    for i in range(N-1, len(c)):
        y = c[i-N+1:i+1]; b = ((x-xm)*(y-y.mean())).sum()/((x-xm)**2).sum(); a = y.mean()-b*xm
        mid[i] = a+b*(N-1); sd[i] = np.sqrt(((y-a-b*x)**2).mean())
    return mid, mid+2*sd, mid-2*sd
def sim(d, entries, rr):
    # entries: list of (i_entry_bar, side, entry_price, stop)  — вход в момент i (по цене entry_price)
    H, L, Cc = d.h.values, d.l.values, d.c.values; n = len(Cc); res = []; nxt = 0
    for i, s, e, st in entries:
        if i < nxt: continue
        risk = abs(e-st)
        if risk <= 0 or risk/e > 0.15: continue
        tp = e+s*rr*risk; r = None
        for j in range(i+1, min(n, i+101)):
            if (s == 1 and L[j] <= st) or (s == -1 and H[j] >= st): r = -1.0; break
            if (s == 1 and H[j] >= tp) or (s == -1 and L[j] <= tp): r = rr; break
        else: j = min(n-1, i+100); r = s*(Cc[j]-e)/risk
        res.append((d.index[i], r-FEE*e/risk)); nxt = j+1
    return pd.DataFrame(res, columns=['t', 'r'])
def base(d):
    mid, up, lo = chan(d); c = d.c.values; out = []
    for i in range(101, len(c)):
        if c[i] > up[i] and c[i-1] <= up[i-1]: out.append((i, 1, c[i], mid[i], up[i]))
        elif c[i] < lo[i] and c[i-1] >= lo[i-1]: out.append((i, -1, c[i], mid[i], lo[i]))
    return out, mid, up, lo
def v_base(d):
    s, *_ = base(d); return [(i, sd, e, st) for i, sd, e, st, b in s]
def v_retest(d, wait=6):
    s, mid, up, lo = base(d); H, L = d.h.values, d.l.values; out = []
    for i, sd, e, st, b in s:
        for j in range(i+1, min(len(H), i+1+wait)):
            if (sd == 1 and L[j] <= b) or (sd == -1 and H[j] >= b):
                out.append((j, sd, b, st)); break      # лимит на пробитой границе, стоп тот же (центр)
    return out
def v_confirm(d, k=2):
    s, mid, up, lo = base(d); c = d.c.values; out = []
    for i, sd, e, st, b in s:
        j = i+k
        if j < len(c) and all((c[t] > up[t]) if sd == 1 else (c[t] < lo[t]) for t in range(i, j+1)):
            out.append((j, sd, c[j], mid[j]))
    return out
def v_bos(d, piv=5, wait=12):
    # слом структуры: закрытие выше последнего подтверждённого swing-high (лонг) / ниже swing-low; вход на ретесте уровня, стоп за последний противоположный swing
    H, L, c = d.h.values, d.l.values, d.c.values; n = len(c); out = []; sh = sl = None
    for i in range(2*piv, n):
        k = i-piv
        if H[k] == H[k-piv:k+piv+1].max(): sh = (k, H[k])
        if L[k] == L[k-piv:k+piv+1].min(): sl = (k, L[k])
        if sh and sl and c[i] > sh[1] and c[i-1] <= sh[1]:
            lvl, st = sh[1], sl[1]
            for j in range(i+1, min(n, i+1+wait)):
                if L[j] <= lvl: out.append((j, 1, lvl, st)); break
            sh = None
        elif sh and sl and c[i] < sl[1] and c[i-1] >= sl[1]:
            lvl, st = sl[1], sh[1]
            for j in range(i+1, min(n, i+1+wait)):
                if H[j] >= lvl: out.append((j, -1, lvl, st)); break
            sl = None
    return out
data = {os.path.basename(f)[:-7]: load(f) for f in sorted(glob.glob(os.path.join(C, 'binance', '*_1h.csv')))}
for name, fn, rr in (("База: вход на закрытии пробоя, 2R", v_base, 2), ("1. Вход на ретесте пробитой границы, 2R", v_retest, 2),
                     ("1b. Ретест, 3R", v_retest, 3), ("2. Подтверждение 2 свечами, 2R", v_confirm, 2),
                     ("3. Слом структуры + ретест, 2R", v_bos, 2), ("3b. Слом структуры + ретест, 3R", v_bos, 3)):
    tot = []; h1 = h2 = 0; ok = 0
    for k, d in data.items():
        t = sim(d, fn(d), rr); mid = d.index[0]+(d.index[-1]-d.index[0])/2
        a, b = t[t.t < mid].r.sum(), t[t.t >= mid].r.sum(); h1 += a; h2 += b; ok += (a > 0 and b > 0); tot.append(t)
    t = pd.concat(tot)
    print(f"{name:42} сделок {len(t):5}  R {t.r.sum():+7.1f}  {t.r.mean():+.3f}/сд  в плюсе {100*(t.r>0).mean():.0f}%  H1 {h1:+.0f} H2 {h2:+.0f}  ок {ok}/{len(data)}", flush=True)
