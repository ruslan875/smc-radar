#!/usr/bin/env python3
"""
Fee-aware, no-lookahead backtester for a Veles Finance-style DCA/grid bot
replica -- same house style as generic_backtest.py / backtest.py (walk-
forward, last-closed-candle convention, static rules never re-tuned mid-
deal) but a materially different ENGINE: this drives a multi-order
averaging-down grid (one "deal" = a base order + N resting safety limit
orders), not a single-entry/static-stop trade. Nothing in this file is
wired into generic_backtest.py's `generate_signals(df) -> list[Signal]`
contract -- that shape cannot express a DCA grid (multiple weighted
entries, a moving average price, an exit gated by a live signal instead of
a fixed price level), so this is a standalone engine.

WHAT THIS REPLICATES (from the user's Veles Finance bot screenshots,
cabinet/bot/4467479), and where it's an approximation:
  - Entry filter: a Keltner Channel pullback (base timeframe close <=
    lower band) + Rate-of-Change dip confirmation (base tf) + an ATR%
    volatility-regime band read from a 15m confirmation timeframe + a CCI
    oversold read from a 30m confirmation timeframe. The exact combining
    logic/thresholds Veles uses for its 6 filter rows were not all legible
    in the screenshots this was built from -- this wires the four
    indicators Veles displays into one reasonable "all conditions true,
    edge-triggered" long-entry rule, fully exposed as CLI flags. Re-tune
    the flags (or ask to adjust the combining logic itself) to match a
    specific saved bot exactly.
  - Order grid: base order (0% offset) + safety orders at fixed % price
    drops FROM THE BASE ORDER'S FILL PRICE (not from a moving average),
    with fixed volume-% weights of one deal's total allocation. Defaults
    -- 0%/55%, 2%/35%, 3.5%/10% -- match the numbers read directly off the
    screenshots.
  - Exit: a VMC/LazyBear-style WaveTrend bearish cross (wt1 crossing under
    wt2) AND unrealized P&L on the deal's invested capital >= a minimum
    threshold (0.5% default, from the screenshots) -- both must be true on
    the same bar. Also an unconditional hard percentage stop-loss (-4%
    default, from the screenshots) that closes the deal regardless of the
    signal (matches "стоп-лосс по сигналу" = OFF in the screenshots). The
    bot keeps opening new deals after a stop-loss (matches "остановить
    бота после стоп-лосса" = OFF) -- there is no cool-down here either.
  - Long-only. Veles supports short-grid bots too; this does not attempt
    that direction (extend the same engine symmetrically if needed).

FEES: same three round-trip scenarios used everywhere else in this
project. Because fee is proportional to notional traded and total entry
notional == total exit notional for a deal, the round-trip fee as a
percent of INVESTED capital is exactly the scenario rate regardless of
how many separate orders filled -- so net P&L%/deal = gross P&L% -
scenario_rate*100, applied per deal.

Needs network access to Bybit's public API -- run on your own machine:

    python kc_roc_cci_wt_grid_backtest.py --symbol ETHUSDT SOLUSDT --bars 20000
    python kc_roc_cci_wt_grid_backtest.py --symbol BTCUSDT --bars 50000 --tp-min-pnl-pct 0.5 --stop-loss-pct 4

1-minute bars are used as the base timeframe by default (--timeframe 1m)
to match Veles' own bar-by-bar order-fill simulation; fetching tens of
thousands of 1-minute bars means many paginated requests -- expect this to
take a while and to be rate-limited by fetch_history's own backoff, same
as any other script here pulling 1m history.
"""
from __future__ import annotations

import argparse
import csv
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import pandas as pd
import requests

from app.config import Settings
from app.data import BYBIT_BASE, INTERVAL_MAP, DataError
from app.indicators.common import cci
from app.indicators.veles_style import (
    rate_of_change, keltner_channel, atr_percent, wave_trend, wt_sell_cross,
    htf_closed_series,
)

# CONFIRMED 2026-09-04 from real account fee screenshots (both exchanges,
# futures only -- this account does not trade spot). Round-trip rates
# (entry+exit combined), replacing the old generic placeholder guess.
# Bybit futures, "Обычный пользователь" tier, 10% MNT discount currently
# ACTIVE: maker 0.0324%, taker 0.0900% per fill.
# OKX futures, "Обычные пользователи" tier, no discount toggle shown:
# maker 0.0200%, taker 0.0500% per fill.
FEE_SCENARIOS = {
    "bybit_taker+taker": 0.0018,
    "bybit_taker+maker": 0.001224,
    "bybit_maker+maker": 0.000648,
    "okx_taker+taker": 0.0010,
    "okx_taker+maker": 0.0007,
    "okx_maker+maker": 0.0004,
}


# --------------------------------------------------------------- data --
# (identical pattern to generic_backtest.py's fetch_history -- duplicated
# rather than imported so this file stays runnable/diff-able standalone)

def _fetch_page(params: dict, symbol: str, retries: int = 3, timeout: float = 15.0) -> dict:
    """One paginated request with retry-with-backoff, same pattern as
    app/data.py's _get() (and the fix next_gen_combo.py needed for the
    same class of bug in app/derivatives_data.py) -- a bare requests.get()
    with no retries means one transient timeout/connection blip mid-run
    kills the whole multi-hundred-page fetch instead of just costing a
    few seconds. Converts any persistent network failure into DataError
    so main()'s existing per-symbol `except DataError` skip-and-continue
    handles it without needing its own network-exception handling."""
    last_exc: Exception | None = None
    for attempt in range(retries):
        try:
            resp = requests.get(f"{BYBIT_BASE}/v5/market/kline", params=params, timeout=timeout)
            resp.raise_for_status()
            return resp.json()
        except requests.RequestException as exc:
            last_exc = exc
            if attempt < retries - 1:
                time.sleep(1.5 * (attempt + 1))
    raise DataError(f"Bybit request failed for {symbol} after {retries} attempts: {last_exc}")


def fetch_history(symbol: str, timeframe: str, total_bars: int, category: str = "linear") -> pd.DataFrame:
    interval = INTERVAL_MAP[timeframe]
    all_rows: list = []
    end = None
    while len(all_rows) < total_bars:
        params = {"category": category, "symbol": symbol, "interval": interval, "limit": 1000}
        if end is not None:
            params["end"] = end
        payload = _fetch_page(params, symbol)
        if payload.get("retCode") != 0:
            raise DataError(f"Bybit API error for {symbol}: {payload.get('retMsg')}")
        rows = payload["result"]["list"]
        if not rows:
            break
        all_rows.extend(rows)
        oldest_ts = int(rows[-1][0])
        end = oldest_ts - 1
        if len(rows) < 1000:
            break
        time.sleep(0.15)

    if not all_rows:
        raise DataError(f"No kline data returned for {symbol} {timeframe}")

    df = pd.DataFrame(all_rows, columns=["open_time", "open", "high", "low", "close", "volume", "turnover"])
    df["open_time"] = df["open_time"].astype("int64")
    df = df.drop_duplicates(subset="open_time")
    for col in ("open", "high", "low", "close", "volume", "turnover"):
        df[col] = df[col].astype(float)
    df["open_time"] = pd.to_datetime(df["open_time"], unit="ms", utc=True)
    df = df.sort_values("open_time").reset_index(drop=True)
    if len(df) > total_bars:
        df = df.tail(total_bars).reset_index(drop=True)

    # Diagnostic added 2026-09-04: surface the real fetched date range and
    # flag any gaps in the candle series. Triggered by a real finding --
    # a run requesting the same --bars 200000 for six symbols produced a
    # ~139-day span for three (SUI/INJ/TIA, newer listings) but a ~345-day
    # span for the other three (ETH/SOL/ARB, deep history) despite an
    # identical bar count, implying non-contiguous/gappy data rather than
    # a genuine 200000-consecutive-minute window for the latter three.
    if len(df) > 1:
        step_seconds = df["open_time"].diff().dt.total_seconds()
        expected_step = step_seconds.median()
        max_gap = step_seconds.max()
        max_gap_idx = step_seconds.idxmax()
        span_days = (df["open_time"].iloc[-1] - df["open_time"].iloc[0]).days
        print(f"  [fetch_history] {symbol}: {len(df)} bars, "
              f"{df['open_time'].iloc[0]} -> {df['open_time'].iloc[-1]} "
              f"({span_days} days)")
        if pd.notna(max_gap) and max_gap > expected_step * 3:
            print(f"  [fetch_history] WARNING: {symbol} has a gap of "
                  f"{max_gap/60:.1f} min (expected ~{expected_step/60:.1f} min "
                  f"between bars) right before "
                  f"{df['open_time'].iloc[max_gap_idx]} -- data is likely "
                  f"NON-CONTIGUOUS, treat this run's results as unreliable "
                  f"until re-fetched.")
    return df


# ---------------------------------------------------------------- grid --

def parse_grid(offsets_csv: str, volumes_csv: str) -> list[tuple[float, float]]:
    offsets = [float(x) for x in offsets_csv.split(",")]
    volumes = [float(x) for x in volumes_csv.split(",")]
    if len(offsets) != len(volumes):
        raise ValueError("--grid-offsets and --grid-volumes must have the same number of entries")
    total = sum(volumes)
    if abs(total - 100.0) > 0.01:
        raise ValueError(f"--grid-volumes must sum to 100 (got {total})")
    if offsets[0] != 0.0:
        raise ValueError("first --grid-offsets entry (the base order) must be 0")
    return list(zip(offsets, volumes))


# ------------------------------------------------------------- params --

@dataclass
class Params:
    grid: list[tuple[float, float]]
    kc_length: int
    kc_mult: float
    roc_length: int
    roc_threshold: float
    htf1_minutes: int
    atr_length: int
    atr_min: float
    atr_max: float
    htf2_minutes: int
    cci_length: int
    cci_threshold: float
    wt_n1: int
    wt_n2: int
    wt_avg_len: int
    tp_min_pnl_pct: float
    stop_loss_pct: float
    max_deal_bars: int


@dataclass
class Deal:
    symbol: str
    entry_time: pd.Timestamp
    exit_time: pd.Timestamp | None
    orders_filled: int
    filled_pct: float
    avg_entry_price: float
    exit_price: float | None
    reason: str  # "SL" | "TP" | "TIMEOUT" | "OPEN_AT_CUTOFF"
    bars_held: int
    gross_pnl_pct: float | None  # on invested capital
    meta: dict = field(default_factory=dict)


# ------------------------------------------------------------- signals --

def compute_indicators(df: pd.DataFrame, p: Params) -> dict:
    _, _, kc_lower = keltner_channel(df, length=p.kc_length, mult=p.kc_mult, use_true_range=True)
    roc = rate_of_change(df["close"], p.roc_length)
    wt1, wt2 = wave_trend(df, n1=p.wt_n1, n2=p.wt_n2, avg_len=p.wt_avg_len)
    sell_cross = wt_sell_cross(wt1, wt2)

    atr_htf = htf_closed_series(df, p.htf1_minutes, lambda h: atr_percent(h, length=p.atr_length))
    cci_htf = htf_closed_series(
        df, p.htf2_minutes,
        lambda h: cci((h["high"] + h["low"] + h["close"]) / 3, p.cci_length),
    )

    kc_cond = df["close"] <= kc_lower
    roc_cond = roc <= p.roc_threshold
    atr_cond = atr_htf.between(p.atr_min, p.atr_max)
    cci_cond = cci_htf <= p.cci_threshold

    raw = kc_cond & roc_cond & atr_cond & cci_cond
    raw = raw.fillna(False)
    entry_signal = raw & ~raw.shift(1).fillna(False)

    defined = kc_lower.notna() & roc.notna() & atr_htf.notna() & cci_htf.notna() & sell_cross.notna()

    return {
        "entry_signal": entry_signal,
        "sell_cross": sell_cross,
        "defined": defined,
    }


# --------------------------------------------------------- walk-forward --

def simulate_symbol(df: pd.DataFrame, symbol: str, p: Params) -> list[Deal]:
    ind = compute_indicators(df, p)
    entry_signal = ind["entry_signal"]
    sell_cross = ind["sell_cross"]
    defined = ind["defined"]

    n = len(df)
    first_valid = defined.idxmax() if defined.any() else None
    if first_valid is None:
        return []

    deals: list[Deal] = []
    i = int(first_valid)
    in_deal = False
    orders: list[dict] = []
    pending: list[dict] = []
    deal_start_bar = -1
    base_price = 0.0

    def avg_entry_and_filled_pct():
        if not orders:
            return 0.0, 0.0
        total_vol = sum(o["vol_pct"] for o in orders)
        weighted = sum(o["vol_pct"] * o["price"] for o in orders)
        return (weighted / total_vol), total_vol

    while i < n:
        if not defined.iloc[i]:
            i += 1
            continue

        if not in_deal:
            if bool(entry_signal.iloc[i]):
                base_price = float(df["close"].iloc[i])
                orders = [{"price": base_price, "vol_pct": p.grid[0][1]}]
                pending = [
                    {"limit_price": base_price * (1 - off / 100.0), "vol_pct": vol}
                    for off, vol in p.grid[1:]
                ]
                deal_start_bar = i
                in_deal = True
            i += 1
            continue

        row = df.iloc[i]
        still_pending = []
        for order in pending:
            if row["low"] <= order["limit_price"]:
                orders.append({"price": order["limit_price"], "vol_pct": order["vol_pct"]})
            else:
                still_pending.append(order)
        pending = still_pending

        avg_entry, filled_pct = avg_entry_and_filled_pct()
        stop_price = avg_entry * (1 - p.stop_loss_pct / 100.0)

        closed = False
        if row["low"] <= stop_price:
            gross = (stop_price - avg_entry) / avg_entry * 100.0
            deals.append(Deal(
                symbol=symbol, entry_time=df["open_time"].iloc[deal_start_bar],
                exit_time=df["open_time"].iloc[i], orders_filled=len(orders),
                filled_pct=filled_pct, avg_entry_price=avg_entry, exit_price=stop_price,
                reason="SL", bars_held=i - deal_start_bar, gross_pnl_pct=gross,
            ))
            closed = True
        else:
            pnl_now = (row["close"] - avg_entry) / avg_entry * 100.0
            if bool(sell_cross.iloc[i]) and pnl_now >= p.tp_min_pnl_pct:
                deals.append(Deal(
                    symbol=symbol, entry_time=df["open_time"].iloc[deal_start_bar],
                    exit_time=df["open_time"].iloc[i], orders_filled=len(orders),
                    filled_pct=filled_pct, avg_entry_price=avg_entry, exit_price=float(row["close"]),
                    reason="TP", bars_held=i - deal_start_bar, gross_pnl_pct=pnl_now,
                ))
                closed = True
            elif (i - deal_start_bar) >= p.max_deal_bars:
                deals.append(Deal(
                    symbol=symbol, entry_time=df["open_time"].iloc[deal_start_bar],
                    exit_time=df["open_time"].iloc[i], orders_filled=len(orders),
                    filled_pct=filled_pct, avg_entry_price=avg_entry, exit_price=float(row["close"]),
                    reason="TIMEOUT", bars_held=i - deal_start_bar, gross_pnl_pct=pnl_now,
                ))
                closed = True

        if closed:
            in_deal = False
            orders = []
            pending = []

        i += 1

    if in_deal:
        avg_entry, filled_pct = avg_entry_and_filled_pct()
        last_close = float(df["close"].iloc[-1])
        gross = (last_close - avg_entry) / avg_entry * 100.0
        deals.append(Deal(
            symbol=symbol, entry_time=df["open_time"].iloc[deal_start_bar],
            exit_time=df["open_time"].iloc[-1], orders_filled=len(orders),
            filled_pct=filled_pct, avg_entry_price=avg_entry, exit_price=last_close,
            reason="OPEN_AT_CUTOFF", bars_held=(n - 1) - deal_start_bar, gross_pnl_pct=gross,
        ))

    return deals


# --------------------------------------------------------------- report --

def net_pnl_pct(deal: Deal, fee_rate: float) -> float | None:
    if deal.gross_pnl_pct is None:
        return None
    return deal.gross_pnl_pct - fee_rate * 100.0


def summarize(deals: list[Deal], label: str) -> None:
    if not deals:
        print(f"\n{label}: no deals opened in this window.")
        return
    resolved = [d for d in deals if d.reason in ("SL", "TP", "TIMEOUT")]
    still_open = [d for d in deals if d.reason == "OPEN_AT_CUTOFF"]
    wins = [d for d in resolved if d.gross_pnl_pct is not None and d.gross_pnl_pct > 0]
    win_rate = (len(wins) / len(resolved) * 100) if resolved else float("nan")
    avg_gross = (sum(d.gross_pnl_pct for d in resolved) / len(resolved)) if resolved else float("nan")
    avg_orders = (sum(d.orders_filled for d in deals) / len(deals)) if deals else float("nan")

    print(f"\n{label}")
    print(f"  Total deals opened:      {len(deals)}")
    print(f"  Resolved (SL/TP/timeout):{len(resolved)}   Still open at cutoff: {len(still_open)}")
    print(f"  Avg orders filled/deal:  {avg_orders:.2f}")
    print(f"  Gross win rate:          {win_rate:.1f}%")
    print(f"  Gross avg P&L% (invested):{avg_gross:+.2f}%")
    reasons = {}
    for d in resolved:
        reasons[d.reason] = reasons.get(d.reason, 0) + 1
    print(f"  Exit reasons: {reasons}")

    for label_fee, fee_rate in FEE_SCENARIOS.items():
        nets = [net_pnl_pct(d, fee_rate) for d in resolved]
        nets = [x for x in nets if x is not None]
        if not nets:
            continue
        net_wins = sum(1 for x in nets if x > 0)
        print(f"    net P&L% after {label_fee:12s} fees: {sum(nets)/len(nets):+.2f}%  "
              f"win rate {net_wins/len(nets)*100:.1f}%")


def save_csv(deals: list[Deal], path: Path) -> None:
    if not deals:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = ["symbol", "entry_time", "exit_time", "orders_filled", "filled_pct",
                  "avg_entry_price", "exit_price", "reason", "bars_held", "gross_pnl_pct"]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for d in deals:
            writer.writerow({k: getattr(d, k) for k in fieldnames})


# -------------------------------------------------------------------- --

def build_params(args) -> Params:
    grid = parse_grid(args.grid_offsets, args.grid_volumes)
    return Params(
        grid=grid,
        kc_length=args.kc_length, kc_mult=args.kc_mult,
        roc_length=args.roc_length, roc_threshold=args.roc_threshold,
        htf1_minutes=args.htf1, atr_length=args.atr_length,
        atr_min=args.atr_min, atr_max=args.atr_max,
        htf2_minutes=args.htf2, cci_length=args.cci_length, cci_threshold=args.cci_threshold,
        wt_n1=args.wt_n1, wt_n2=args.wt_n2, wt_avg_len=args.wt_avg_len,
        tp_min_pnl_pct=args.tp_min_pnl_pct, stop_loss_pct=args.stop_loss_pct,
        max_deal_bars=args.max_deal_bars,
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    settings = Settings.load()
    parser.add_argument("--symbol", nargs="+", default=settings.watchlist)
    parser.add_argument("--timeframe", default="1m", help="Base timeframe for entries/exits (default 1m, matches Veles' own bar granularity)")
    parser.add_argument("--bars", type=int, default=20000)
    parser.add_argument("--out", default="kc_roc_cci_wt_grid_backtest_out")

    parser.add_argument("--grid-offsets", default="0,3", help="Comma-separated %% price drops from the base order price (first must be 0). 2026-09-01: default rebalanced from 0,2,3.5 to 0,3 -- see kc_roc_cci_wt_grid_live.py's 2026-09-01 note")
    parser.add_argument("--grid-volumes", default="65,35", help="Comma-separated %% of deal allocation per order (must sum to 100). 2026-09-01: default rebalanced from 55,35,10 to 65,35 so the smallest leg clears Bybit's ~5 USDT order minimum at --capital-per-deal 20 -- backtested statistically equivalent to the old 3-leg grid on all 6 live symbols")

    parser.add_argument("--kc-length", type=int, default=20)
    parser.add_argument("--kc-mult", type=float, default=2.0)
    parser.add_argument("--roc-length", type=int, default=14)
    parser.add_argument("--roc-threshold", type=float, default=-1.0)

    parser.add_argument("--htf1", type=int, default=15, help="Confirmation timeframe in minutes for the ATR%% filter")
    parser.add_argument("--atr-length", type=int, default=14)
    parser.add_argument("--atr-min", type=float, default=0.05)
    parser.add_argument("--atr-max", type=float, default=5.0)

    parser.add_argument("--htf2", type=int, default=30, help="Confirmation timeframe in minutes for the CCI filter")
    parser.add_argument("--cci-length", type=int, default=20)
    parser.add_argument("--cci-threshold", type=float, default=-100.0)

    parser.add_argument("--wt-n1", type=int, default=10, help="WaveTrend Channel Length")
    parser.add_argument("--wt-n2", type=int, default=21, help="WaveTrend Average Length")
    parser.add_argument("--wt-avg-len", type=int, default=4, help="WaveTrend wt2 smoothing length")

    parser.add_argument("--tp-min-pnl-pct", type=float, default=0.5)
    parser.add_argument("--stop-loss-pct", type=float, default=4.0)
    parser.add_argument("--max-deal-bars", type=int, default=20000, help="Safety cap on how long a single deal can stay open before being marked TIMEOUT")

    args = parser.parse_args()
    params = build_params(args)

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    # 2026-09-20: record what produced this folder.
    #
    # Five grid-configuration folders were compared today and the comparison
    # had to be thrown away: three of them turned out byte-identical, the
    # others had been run over a different window, and nothing on disk said
    # so. Worse, every deal in them had a single grid leg filled - the
    # averaging step the whole experiment was meant to test never fired in
    # that window at all, which is only visible by opening the CSVs.
    #
    # A variant run whose settings are not written down is not an
    # experiment, it is a folder of numbers. analyze_live_bots.py reads this
    # file and prints the configuration next to the metrics.
    import json as _json, datetime as _dt
    _manifest = {
        "strategy": "kc_roc_cci_wt_grid",
        "run_at": _dt.datetime.now().astimezone().isoformat(timespec="seconds"),
        "symbols": [s.upper() for s in args.symbol],
        "timeframe": args.timeframe,
        "bars": args.bars,
        "grid_offsets": args.grid_offsets,
        "grid_volumes": args.grid_volumes,
        "stop_loss_pct": args.stop_loss_pct,
        "tp_min_pnl_pct": args.tp_min_pnl_pct,
        "roc_threshold": args.roc_threshold,
        "cci_threshold": args.cci_threshold,
        "atr_min": args.atr_min,
        "atr_max": args.atr_max,
        "note": "gross_pnl_pct in the CSVs is GROSS - fees are not deducted here",
    }
    (out_dir / "_run.json").write_text(_json.dumps(_manifest, indent=2), encoding="utf-8")

    print(f"\nconfig: grid {args.grid_offsets} @ {args.grid_volumes}% | "
          f"stop {args.stop_loss_pct}% | tp-min {args.tp_min_pnl_pct}% | "
          f"{args.bars} bars of {args.timeframe}")

    all_deals: list[Deal] = []
    for symbol in args.symbol:
        symbol = symbol.upper()
        print(f"\nFetching + simulating {symbol} ({args.bars} bars of {args.timeframe})...")
        try:
            df = fetch_history(symbol, args.timeframe, args.bars)
            deals = simulate_symbol(df, symbol, params)
        except DataError as exc:
            print(f"  [SKIP] {symbol}: {exc}")
            continue
        summarize(deals, symbol)
        save_csv(deals, out_dir / f"{symbol}_deals.csv")
        all_deals.extend(deals)

    summarize(all_deals, "=== COMBINED (all symbols) ===")
    print(f"\nPer-deal CSVs written to {out_dir.resolve()}")


if __name__ == "__main__":
    main()
