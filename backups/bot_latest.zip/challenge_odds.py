"""challenge_odds.py — 2026-10-31. Шанс пройти 2-Stage Challenge Hash Hedge с нашими сигналами (история 12 монет).
Правила: этап 1 цель +8%, этап 2 цель +6%; дневной убыток 5%, общая просадка 10% / 8% от старта этапа; ≥5 торговых дней.
Старт в каждый день истории (с шагом 7 дней), сделки по порядку входа, ≤N в одну сторону, риск r% от старта этапа.
Упрощение: убыток считаем по ЗАКРЫТЫМ сделкам (плавающий минус внутри дня не виден — реальный шанс ниже)."""
from __future__ import annotations

import sys
import time
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import numpy as np  # noqa: E402
import recheck_recent as RR  # noqa: E402
import chan2h_fix_test as F  # noqa: E402

DAY = 86400_000


def stage(tr, t0, risk_pct, target, dd, dl=5.0):
    """tr: [(t_in, t_out, R)] после t0. → ('pass'|'fail'|'open', дней)."""
    eq = 0.0; days = set(); daily = {}
    for tin, tout, r in tr:
        if tin < t0:
            continue
        days.add(tin // DAY)
        pnl = r * risk_pct
        d = tout // DAY; daily[d] = daily.get(d, 0) + pnl; eq += pnl
        if daily[d] <= -dl or eq <= -dd:
            return "fail", (tout - t0) / DAY
        if eq >= target and len(days) >= 5:
            return "pass", (tout - t0) / DAY
    return "open", None


def main():
    import kvoo_longtest as K  # noqa: PLC0415
    out = []
    for tf in ("2h", "4h"):
        allt = []
        for s in K.COINS:
            d = RR.load(s, tf)
            if d is not None and len(d) > 400:
                allt += [(a, b, c, r, v, s) for a, b, c, r, v in F.trades_for(d)]
        for cap in (2, 99):
            book = []
            for tin, tout, s, r, _v, _sym in sorted(allt, key=lambda x: x[0]):
                if sum(1 for b in book if b[2] == s and b[0] <= tin < b[1]) >= cap:
                    continue
                book.append((tin, tout, s, r))
            tr = sorted([(a, b, r) for a, b, _s, r in book])
            t_first, t_last = tr[0][0], tr[-1][1]
            for risk in (0.25, 0.5, 0.75, 1.0):
                res = []
                for t0 in range(t_first + 30 * DAY, t_last - 120 * DAY, 7 * DAY):
                    a, da = stage(tr, t0, risk, 8, 10)
                    if a != "pass":
                        res.append((a, None)); continue
                    b, db = stage(tr, t0 + int(da * DAY), risk, 6, 8)
                    res.append((b, (da + db) if b == "pass" else None))
                n = len(res); ok = [x for x in res if x[0] == "pass"]; fail = sum(1 for x in res if x[0] == "fail")
                med = np.median([x[1] for x in ok]) if ok else None
                line = (f"Пробой {tf} · ≤{cap if cap < 99 else '∞'} в сторону · риск {risk}%: прошли оба этапа {len(ok) / n * 100:4.0f}% · "
                        f"провал {fail / n * 100:4.0f}% · не дошли {100 - (len(ok) + fail) / n * 100:4.0f}% · "
                        f"медиана времени {med:.0f} дн" if med else f"Пробой {tf} · ≤{cap} · риск {risk}%: прошли 0%")
                print(line, flush=True); out.append(line)
    (BASE / "bt_lab_bots" / "challenge_odds.txt").write_text("\n".join(out) + "\n", encoding="utf-8")
    print("готово")


if __name__ == "__main__":
    main()
