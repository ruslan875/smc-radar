"""
Визуализация результатов бэктеста с графиками входов/выходов/стопов.
Использует matplotlib для отрисовки свечей, входов, выходов, P&L.
"""

import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.patches import Rectangle
import numpy as np
import pandas as pd
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')


class BacktestVisualizer:
    """
    Визуализирует результаты торговой стратегии на графике OHLC.

    Входные данные:
        df: DataFrame с колонками ['open', 'high', 'low', 'close', 'volume']
            и индексом datetime
        trades: List[dict] - список сделок вида:
            {
                'entry_index': int,           # индекс свечи входа
                'exit_index': int,            # индекс свечи выхода
                'entry_price': float,
                'exit_price': float,
                'stop_loss': float,
                'take_profit_1': float (optional),
                'take_profit_2': float (optional),
                'direction': 'LONG' или 'SHORT',
                'pnl': float,                 # прибыль/убыток в USDT
                'pnl_percent': float,         # прибыль/убыток в %
                'exit_reason': str            # 'TP1', 'TP2', 'SL', 'timeout' и т.д.
            }
    """

    def __init__(self, df, trades, symbol="UNKNOWN", timeframe="15m"):
        """
        Args:
            df: DataFrame с OHLC данными
            trades: List[dict] со сделками
            symbol: название пары (для заголовка)
            timeframe: таймфрейм (для заголовка)
        """
        self.df = df.reset_index(drop=True)
        self.trades = trades
        self.symbol = symbol
        self.timeframe = timeframe

        # Проверяем наличие необходимых колонок
        required_cols = ['open', 'high', 'low', 'close']
        for col in required_cols:
            if col not in self.df.columns:
                raise ValueError(f"DataFrame должен содержать колонку '{col}'")

    def plot_trades(self, figsize=(16, 10), show_grid=True, bars_visible=200):
        """
        Рисует график с входами, выходами, стопами и TP.

        Args:
            figsize: размер фигуры (width, height)
            show_grid: показывать ли сетку
            bars_visible: количество свечей для отображения (последние N)
        """
        fig, (ax_price, ax_pnl) = plt.subplots(2, 1, figsize=figsize,
                                                 gridspec_kw={'height_ratios': [3, 1]})

        # Определяем диапазон баров для отображения
        if len(self.df) > bars_visible:
            start_idx = len(self.df) - bars_visible
        else:
            start_idx = 0

        df_plot = self.df.iloc[start_idx:]
        x_offset = start_idx  # смещение для корректных индексов

        # ===== ГРАФИК ЦЕНЫ =====
        self._plot_candlesticks(ax_price, df_plot, x_offset)
        self._plot_trades_on_chart(ax_price, df_plot, x_offset)
        self._format_price_axis(ax_price, show_grid)

        # ===== ГРАФИК P&L =====
        self._plot_cumulative_pnl(ax_pnl)
        self._format_pnl_axis(ax_pnl, show_grid)

        # Общие настройки
        fig.suptitle(f'{self.symbol} {self.timeframe} - Backtest Results',
                     fontsize=14, fontweight='bold')

        plt.tight_layout()
        return fig, (ax_price, ax_pnl)

    def _plot_candlesticks(self, ax, df_plot, x_offset):
        """Рисует свечи OHLC."""
        width = 0.6

        for i, (idx, row) in enumerate(df_plot.iterrows()):
            x = i
            open_p, high_p, low_p, close_p = row['open'], row['high'], row['low'], row['close']

            # Цвет свечи
            color = '#26a69a' if close_p >= open_p else '#ef5350'

            # Высокая/низкая точка (тень)
            ax.plot([x, x], [low_p, high_p], color=color, linewidth=0.5)

            # Тело свечи
            body_height = abs(close_p - open_p)
            body_bottom = min(open_p, close_p)
            rect = Rectangle((x - width/2, body_bottom), width, body_height,
                            facecolor=color, edgecolor=color, linewidth=1)
            ax.add_patch(rect)

        ax.set_xlim(-1, len(df_plot))

    def _plot_trades_on_chart(self, ax, df_plot, x_offset):
        """Рисует входы, выходы, стопы и TP."""

        for trade in self.trades:
            entry_idx = trade['entry_index']
            exit_idx = trade['exit_index']

            # Проверяем, входит ли сделка в видимый диапазон
            if exit_idx < x_offset or entry_idx >= x_offset + len(df_plot):
                continue

            # Корректируем индексы для визуального отображения
            entry_x = max(0, entry_idx - x_offset)
            exit_x = min(len(df_plot) - 1, exit_idx - x_offset)

            entry_price = trade['entry_price']
            exit_price = trade['exit_price']
            stop_loss = trade['stop_loss']
            direction = trade['direction']
            exit_reason = trade.get('exit_reason', 'unknown')
            pnl = trade['pnl']

            # ===== ВЕРТИКАЛЬНЫЕ ЛИНИИ: СТОП И TP =====
            x_entry = entry_x

            # Линия стопа (красная пунктир)
            ax.plot([x_entry, exit_x], [stop_loss, stop_loss],
                   color='red', linestyle='--', linewidth=1.5, alpha=0.7, label='SL' if entry_idx == self.trades[0]['entry_index'] else '')

            # Линия TP
            tp_price = trade.get('take_profit_2', trade.get('take_profit_1', exit_price))
            tp_color = 'gold' if exit_reason.startswith('TP') else 'gray'
            ax.plot([x_entry, exit_x], [tp_price, tp_price],
                   color=tp_color, linestyle='--', linewidth=1.5, alpha=0.7)

            # ===== МАРКЕРЫ ВХОДА И ВЫХОДА =====
            # Вход
            marker_entry = '^' if direction == 'LONG' else 'v'
            color_entry = 'green' if direction == 'LONG' else 'red'
            ax.scatter(x_entry, entry_price, marker=marker_entry, s=150,
                      color=color_entry, zorder=5, edgecolors='black', linewidth=1)

            # Выход
            marker_exit = 'o'
            color_exit = 'lime' if pnl >= 0 else 'crimson'
            ax.scatter(exit_x, exit_price, marker=marker_exit, s=150,
                      color=color_exit, zorder=5, edgecolors='black', linewidth=1)

            # ===== ЛИНИЯ СРЕДНЕЙ ЦЕНЫ ВХОДА (для сетки) =====
            # Если есть несколько ног сетки, рисуем области
            if direction == 'LONG':
                ax.fill_between([x_entry, exit_x], stop_loss, entry_price,
                               alpha=0.1, color='green')
            else:
                ax.fill_between([x_entry, exit_x], entry_price, stop_loss,
                               alpha=0.1, color='red')

            # ===== ТЕКСТ С ИНФОРМАЦИЕЙ =====
            mid_x = (x_entry + exit_x) / 2
            mid_y = (entry_price + exit_price) / 2

            pnl_text = f'{pnl:+.2f} ({trade["pnl_percent"]:+.2f}%)'
            ax.text(mid_x, mid_y, pnl_text, fontsize=8,
                   bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.7),
                   ha='center', va='center')

    def _plot_cumulative_pnl(self, ax):
        """Рисует кумулятивный P&L."""
        if not self.trades:
            return

        # Сортируем сделки по индексу выхода
        sorted_trades = sorted(self.trades, key=lambda t: t['exit_index'])

        # Вычисляем кумулятивный P&L
        cumulative_pnl = []
        cumsum = 0

        for trade in sorted_trades:
            cumsum += trade['pnl']
            cumulative_pnl.append(cumsum)

        exit_indices = [t['exit_index'] for t in sorted_trades]

        # Цвет линии в зависимости от финального результата
        color = 'green' if cumulative_pnl[-1] >= 0 else 'red'

        ax.plot(exit_indices, cumulative_pnl, color=color, linewidth=2, marker='o', markersize=4)
        ax.axhline(y=0, color='black', linestyle='-', linewidth=0.5, alpha=0.5)
        ax.fill_between(exit_indices, cumulative_pnl, 0, alpha=0.3, color=color)

        ax.set_ylabel('Cumulative P&L (USDT)', fontweight='bold')
        ax.set_xlabel('Bar Index')

    def _format_price_axis(self, ax, show_grid):
        """Форматирует оси графика цены."""
        ax.set_ylabel('Price (USDT)', fontweight='bold')
        ax.set_xlabel('Bar Index')

        if show_grid:
            ax.grid(True, alpha=0.3)

        # Улучшаем визуализацию
        ax.set_facecolor('#f8f9fa')
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)

    def _format_pnl_axis(self, ax, show_grid):
        """Форматирует оси графика P&L."""
        if show_grid:
            ax.grid(True, alpha=0.3)

        ax.set_facecolor('#f8f9fa')
        ax.spines['top'].set_visible(False)
        ax.spines['right'].set_visible(False)

    def print_statistics(self):
        """Печатает статистику сделок."""
        if not self.trades:
            print("Нет сделок для анализа")
            return

        df_trades = pd.DataFrame(self.trades)

        total_trades = len(df_trades)
        winning_trades = (df_trades['pnl'] > 0).sum()
        losing_trades = (df_trades['pnl'] < 0).sum()

        total_pnl = df_trades['pnl'].sum()
        total_pnl_percent = df_trades['pnl_percent'].sum()

        avg_pnl = df_trades['pnl'].mean()
        avg_pnl_percent = df_trades['pnl_percent'].mean()

        max_pnl = df_trades['pnl'].max()
        min_pnl = df_trades['pnl'].min()

        win_rate = (winning_trades / total_trades * 100) if total_trades > 0 else 0

        print(f"\n{'='*60}")
        print(f"BACKTEST STATISTICS - {self.symbol} {self.timeframe}")
        print(f"{'='*60}")
        print(f"Total Trades:        {total_trades}")
        print(f"Winning Trades:      {winning_trades} ({win_rate:.1f}%)")
        print(f"Losing Trades:       {losing_trades}")
        print(f"")
        print(f"Total P&L:           {total_pnl:+.2f} USDT ({total_pnl_percent:+.2f}%)")
        print(f"Average P&L:         {avg_pnl:+.2f} USDT ({avg_pnl_percent:+.2f}%)")
        print(f"Max P&L:             {max_pnl:+.2f} USDT")
        print(f"Min P&L:             {min_pnl:+.2f} USDT")
        print(f"")
        print(f"Exit Reasons:")
        exit_reasons = df_trades['exit_reason'].value_counts()
        for reason, count in exit_reasons.items():
            print(f"  {reason}: {count}")
        print(f"{'='*60}\n")


# ===== ПРИМЕР ИСПОЛЬЗОВАНИЯ =====
if __name__ == "__main__":
    # Генерируем пример данных
    dates = pd.date_range('2024-01-01', periods=1000, freq='15min')
    np.random.seed(42)

    close_prices = 100 + np.cumsum(np.random.randn(1000) * 0.5)
    df = pd.DataFrame({
        'open': close_prices + np.random.randn(1000) * 0.1,
        'high': close_prices + np.abs(np.random.randn(1000) * 0.3),
        'low': close_prices - np.abs(np.random.randn(1000) * 0.3),
        'close': close_prices,
        'volume': np.random.randint(1000, 10000, 1000)
    }, index=dates)

    # Пример сделок
    trades = [
        {
            'entry_index': 50,
            'exit_index': 80,
            'entry_price': 100.5,
            'exit_price': 102.0,
            'stop_loss': 99.0,
            'take_profit_1': 101.5,
            'take_profit_2': 103.0,
            'direction': 'LONG',
            'pnl': 1.5,
            'pnl_percent': 1.49,
            'exit_reason': 'TP1'
        },
        {
            'entry_index': 100,
            'exit_index': 130,
            'entry_price': 103.2,
            'exit_price': 101.5,
            'stop_loss': 105.0,
            'take_profit_2': 100.0,
            'direction': 'SHORT',
            'pnl': 1.7,
            'pnl_percent': 1.65,
            'exit_reason': 'TP2'
        },
        {
            'entry_index': 150,
            'exit_index': 170,
            'entry_price': 102.0,
            'exit_price': 99.5,
            'stop_loss': 104.0,
            'take_profit_2': 98.0,
            'direction': 'SHORT',
            'pnl': -2.5,
            'pnl_percent': -2.45,
            'exit_reason': 'SL'
        }
    ]

    # Визуализируем
    viz = BacktestVisualizer(df, trades, symbol="BTC/USDT", timeframe="15m")
    fig, axes = viz.plot_trades()
    viz.print_statistics()
    plt.show()
