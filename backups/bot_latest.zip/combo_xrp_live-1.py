"""combo_xrp_live.py — 2026-10-17. Combo OTM (сборка подписчика №2, combo_sub2.csv), ТОЛЬКО XRP-USDT-SWAP на OKX, 1H.

Тот же движок и те же настройки, что у бумажного windows_app/combo_xrp_paper.py (combo_full.run, OI = None,
BTC как ref), но свечи берутся с OKX (публично), а сделки — либо симуляция (PAPER), либо реальные ордера (LIVE).

КАК РЕШАЕТСЯ ВХОД/ВЫХОД. Каждый новый закрытый часовой бар движок прогоняется по истории + одному «синтетическому»
бару, который открывается прямо сейчас по текущей цене. Движок входит по open бара, следующего за сигналом, — значит,
если на синтетическом баре у движка открылась позиция, это ровно вход стратегии «сейчас»; SL/TP берутся из этой
позиции движка (levels() на баре входа). Если у бота позиция, а у движка её больше нет (ранний выход, смена
стороны) — бот закрывает по рынку. SL/TP самого движка (в т.ч. перенос в безубыток) синхронизируются с биржей.

РАЗМЕР. Маржа на сделку = 50% депозита (как в стратегии, 50% equity): 0.5 × min(deposit, баланс) = 25 $;
нотионал = маржа × плечо = 25 × 3 = 75 $, но не больше max_notional (150) и HARD_MAX_NOTIONAL;
контракты = floor(нотионал / (цена × ctVal) / lotSz) × lotSz; меньше minSz — сделка пропускается с уведомлением.

БЕЗОПАСНОСТЬ (всё ниже — обязательные условия, не настройки по умолчанию):
 (a) LIVE только если: флаг --live И "mode": "live" в combo_xrp_live_settings.json И одноразовый токен
     подтверждения от панели (process_supervisor пишет combo_xrp_live_confirm.json и передаёт тот же токен через
     переменную окружения COMBO_XRP_CONFIRM_TOKEN только после кнопки LIVE с подтверждением). Иначе — PAPER.
 (b) Каждый реальный вход — с SL, привязанным на бирже (attachAlgoOrds). Если SL на бирже не подтверждается —
     позиция немедленно закрывается, бот останавливается, тревога в Telegram.
 (c) Kill-switch: PnL с запуска (реализованный + нереализованный) ≤ −daily_loss_stop $, ИЛИ PnL за сутки (UTC)
     ≤ −daily_loss_stop $, ИЛИ (опц.) просадка всего счёта > account_drop_stop $ → закрыть позицию, остановиться, тревога;
     до конца суток UTC бот повторно не торгует (флаг в файле состояния).
 (d) Не больше одной позиции, никаких доливок; позиция биржи сверяется каждый цикл; чужая позиция по XRP →
     бот ничего не трогает, одна тревога, пауза до исчезновения.
 (e) Одна копия (lock-файл .combo_xrp_live.lock).  (f) Ошибки → лог + Telegram, экспоненциальная пауза.
 (g) Только XRP-USDT-SWAP (зашито, из настроек не меняется).
Ключи читаются только из trade_keys.json через TradeKeysStore.get_for_strategy("combo_xrp", "okx") — личный ключ
стратегии (/tradekey comboxrp okx …) или общий OKX (/tradekey okx …). Ключи никогда не печатаются и не пишутся.
"""
from __future__ import annotations

import argparse
import csv
import html
import json
import logging
import math
import os
import sys
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path

BASE = Path(__file__).resolve().parent
if str(BASE) not in sys.path:
    sys.path.insert(0, str(BASE))

try:
    from dotenv import load_dotenv
    load_dotenv(BASE / ".env")
except ImportError:
    pass

STRATEGY_ID = "combo_xrp"
LABEL = "Combo OTM XRP · OKX"
SYMBOL = "XRPUSDT"                 # имя в файлах/панели
INST_ID = "XRP-USDT-SWAP"          # (g) только этот инструмент — константа
REF_INST = "BTC-USDT-SWAP"
H1 = 3600_000
HARD_MAX_LEVERAGE = 5
HARD_MAX_NOTIONAL = 300.0

SETTINGS_FILE = BASE / "combo_xrp_live_settings.json"
STATE_FILE = BASE / "combo_xrp_live_state.json"
PAPER_STATE_FILE = BASE / "combo_xrp_live_paper_state.json"
TRADES_CSV = BASE / "combo_xrp_live_trades.csv"
LOG_FILE = BASE / "logs" / "combo_xrp_live.log"
CONFIRM_FILE = BASE / "combo_xrp_live_confirm.json"
CONFIRM_ENV = "COMBO_XRP_CONFIRM_TOKEN"
CONFIRM_MAX_AGE = 300

DEFAULT_SETTINGS = {
    "mode": "paper",            # "paper" | "live" — LIVE ещё требует --live и подтверждение в панели
    "deposit": 50.0,            # потолок капитала бота, $
    "leverage": 3,
    "margin_pct": 50.0,         # % депозита в марже на сделку (как в стратегии)
    "max_notional": 150.0,
    "daily_loss_stop": 15.0,    # $ — kill-switch по PnL
    "balance_drop_stop": 15.0,  # $ — kill-switch по балансу
    "max_open": 1,
    "max_entry_delay_min": 15,  # вход только в первые N минут нового часа (не догоняем)
    "sl_trigger_px_type": "mark",
    "poll_seconds": 30,
    "telegram": True,
}

TRADE_FIELDS = ["symbol", "entry_time", "exit_time", "orders_filled", "filled_pct", "avg_entry_price", "exit_price",
                "reason", "bars_held", "gross_pnl_pct", "side", "contracts", "qty_coins", "pnl_usd", "mode"]

log = logging.getLogger("combo_xrp_live")


class StopBot(Exception):
    """Штатная остановка бота (kill-switch, нет SL, нет ключа)."""


# ---------------------------------------------------------------- settings / files --
def load_settings(path: Path = SETTINGS_FILE) -> dict:
    s = dict(DEFAULT_SETTINGS)
    try:
        s.update(json.loads(path.read_text(encoding="utf-8")))
    except FileNotFoundError:
        path.write_text(json.dumps(DEFAULT_SETTINGS, ensure_ascii=False, indent=2), encoding="utf-8")
    except (OSError, ValueError) as exc:
        raise StopBot(f"не читается {path.name}: {exc}")
    s["leverage"] = int(s["leverage"])
    if not 1 <= s["leverage"] <= HARD_MAX_LEVERAGE:
        raise StopBot(f"плечо {s['leverage']} вне 1..{HARD_MAX_LEVERAGE}")
    s["max_notional"] = min(float(s["max_notional"]), HARD_MAX_NOTIONAL)
    s["max_open"] = 1                                   # (d) жёстко
    for k in ("deposit", "margin_pct", "daily_loss_stop", "balance_drop_stop"):
        s[k] = float(s[k])
        if s[k] <= 0:
            raise StopBot(f"{k} должен быть > 0")
    if s["margin_pct"] > 100:
        raise StopBot("margin_pct > 100")
    return s


def plan_size(settings: dict, equity: float | None, price: float, inst: dict) -> dict:
    """margin = margin_pct% × min(deposit, equity); notional = margin × leverage (≤ max_notional);
    contracts = floor(notional/(price·ctVal)/lotSz)·lotSz, 0 если < minSz."""
    from app.exchanges import okx  # noqa: PLC0415
    cap = settings["deposit"] if equity is None else max(0.0, min(settings["deposit"], equity))
    margin = cap * settings["margin_pct"] / 100.0
    notional = min(margin * settings["leverage"], settings["max_notional"], HARD_MAX_NOTIONAL)
    contracts = okx.contracts_for_notional(notional, price, inst)
    return {"cap": cap, "margin": margin, "notional": notional, "contracts": contracts,
            "qty_coins": contracts * inst["ctVal"]}


def iso(ms) -> str:
    return datetime.fromtimestamp(int(ms) / 1000, tz=timezone.utc).strftime("%Y-%m-%dT%H:%M:%S+00:00")


def utc_day(ms) -> str:
    return datetime.fromtimestamp(int(ms) / 1000, tz=timezone.utc).strftime("%Y-%m-%d")


class StateFile:
    """{"XRPUSDT": {deal...}, "_meta": {...}} — все значения верхнего уровня словари (так читает server.py)."""

    def __init__(self, path: Path):
        self.path = path
        try:
            self.data = json.loads(path.read_text(encoding="utf-8"))
            if not isinstance(self.data, dict):
                self.data = {}
        except (OSError, ValueError):
            self.data = {}
        self.data.setdefault(SYMBOL, {"in_deal": False})
        self.data.setdefault("_meta", {})

    @property
    def deal(self) -> dict:
        return self.data[SYMBOL]

    @property
    def meta(self) -> dict:
        return self.data["_meta"]

    def save(self) -> None:
        tmp = self.path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.data, ensure_ascii=False, indent=1, default=str), encoding="utf-8")
        tmp.replace(self.path)


def log_trade(row: dict, path: Path = TRADES_CSV) -> None:
    new = not path.exists()
    with path.open("a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=TRADE_FIELDS, extrasaction="ignore")
        if new:
            w.writeheader()
        w.writerow(row)


# ---------------------------------------------------------------- notifications --
def make_notifier(enabled: bool, mode: str):
    tag = "🔴 LIVE (реальные ордера)" if mode == "live" else "🧪 PAPER (симуляция)"

    def notify(msg: str) -> None:
        log.info("[TG] %s", msg.replace("\n", " | "))
        if not enabled:
            return
        token, chat = os.environ.get("TELEGRAM_BOT_TOKEN"), os.environ.get("TELEGRAM_CHAT_ID")
        if not token or not chat:
            return
        try:
            from app.telegram_client import TelegramClient  # noqa: PLC0415
            TelegramClient(token, chat).send_message(html.escape(msg) + f"\n<i>{html.escape(LABEL)} · {tag}</i>")
        except Exception as exc:  # noqa: BLE001
            log.warning("telegram send failed: %s", type(exc).__name__)
    return notify


# ---------------------------------------------------------------- market data --
def candles_df(rows: list, now_ms: int):
    """Только закрытые свечи (confirm=1 и ts+1h ≤ now) -> DataFrame как у paper-бота."""
    import pandas as pd  # noqa: PLC0415
    rows = [r for r in rows if (r[6] if len(r) > 6 else True) and int(r[0]) + H1 <= now_ms]
    if not rows:
        raise ValueError("нет закрытых свечей")
    df = pd.DataFrame([r[:6] for r in rows], columns=["ts", "open", "high", "low", "close", "volume"])
    df.index = pd.to_datetime(df["ts"], unit="ms")
    return df[["open", "high", "low", "close", "volume"]].astype(float)


def engine_target(df, ref_df, cfg, start_ms: int, price: float) -> tuple:
    """(target|None, synthetic_ts_ms). target = {'side':+1/-1,'sl','tp','entry_ts','avg'} — позиция движка
    на синтетическом баре, открытом сейчас по текущей цене."""
    import pandas as pd  # noqa: PLC0415
    import combo_full as cf  # noqa: PLC0415
    syn_ts = df.index[-1] + pd.Timedelta(hours=1)
    syn = pd.DataFrame({"open": [price], "high": [price], "low": [price], "close": [price],
                        "volume": [float(df["volume"].iloc[-1])]}, index=[syn_ts])
    d2 = pd.concat([df, syn])
    ref2 = None
    if ref_df is not None and len(ref_df):
        last = ref_df.iloc[[-1]].copy()
        last.index = [syn_ts]
        ref2 = pd.concat([ref_df[ref_df.index < syn_ts], last])
    start = pd.Timestamp(int(start_ms), unit="ms").floor("h")
    _tr, _dd, _eq, stats = cf.run(d2, cfg, ref2, start=str(start), initial_capital=500.0)
    o = stats.get("open")
    syn_ms = int(syn_ts.value // 1_000_000)
    if not o:
        return None, syn_ms
    return ({"side": int(o["side"]), "sl": float(o["sl"]) if o.get("sl") else None,
             "tp": float(o["tp2"]) if o.get("tp2") else None, "avg": float(o["avg"]),
             "entry_ts": int(pd.Timestamp(o["entry_time"]).value // 1_000_000)}, syn_ms)


# ---------------------------------------------------------------- backends --
class PaperBackend:
    """Симуляция биржи: позиция со «стоящими» SL/TP, исполнение по high/low закрытых баров и текущей цене."""
    mode = "paper"

    def __init__(self, settings: dict, state: StateFile):
        self.s = settings
        self.st = state
        self.inst = {"instId": INST_ID, "ctVal": 100.0, "lotSz": 0.01, "minSz": 0.01, "tickSz": 0.0001}
        self.fee = 0.0005

    def instrument(self) -> dict:
        try:
            from app.exchanges import okx  # noqa: PLC0415
            self.inst = okx.get_instrument(INST_ID)
        except Exception:  # noqa: BLE001 — офлайн: типовые параметры XRP-USDT-SWAP
            pass
        return self.inst

    @property
    def _p(self) -> dict | None:
        return self.st.meta.get("paper_pos")

    def prepare(self) -> None:
        return None

    def position(self) -> dict | None:
        p = self._p
        return dict(p) if p else None

    def equity(self) -> float:
        return self.s["deposit"] + float(self.st.meta.get("paper_realized", 0.0))

    def open(self, side: int, contracts: float, sl: float, tp: float | None, price: float) -> dict:
        self.st.meta["paper_pos"] = {"side": "long" if side > 0 else "short", "contracts": contracts, "avg_px": price,
                                     "sl": sl, "tp": tp, "upl": 0.0, "pos_side": "net"}
        return {"order_id": f"paper{int(time.time())}", "cl_ord_id": None, "sl_confirmed": True}

    def close(self, price: float, reason: str) -> float:
        p = self._p
        if not p:
            return 0.0
        pnl = self._pnl(p, price)
        self.st.meta["paper_realized"] = float(self.st.meta.get("paper_realized", 0.0)) + pnl
        self.st.meta["paper_pos"] = None
        self.st.meta["paper_last_exit"] = {"price": price, "pnl": pnl, "reason": reason}
        return pnl

    def _pnl(self, p: dict, price: float) -> float:
        d = 1 if p["side"] == "long" else -1
        q = p["contracts"] * self.inst["ctVal"]
        return (price - p["avg_px"]) * q * d - (p["avg_px"] + price) * q * self.fee

    def unrealized(self, price: float) -> float:
        p = self._p
        return self._pnl(p, price) if p else 0.0

    def amend(self, sl: float, tp: float | None) -> None:
        if self._p:
            self._p["sl"] = sl
            if tp:
                self._p["tp"] = tp

    def simulate_exits(self, bars: list, price: float) -> None:
        """«Биржевые» SL/TP: бары (high, low) после входа + текущая цена. SL проверяется первым (консервативно)."""
        p = self._p
        if not p:
            return
        d = 1 if p["side"] == "long" else -1
        for hi, lo in list(bars) + [(price, price)]:
            if p["sl"] and ((d > 0 and lo <= p["sl"]) or (d < 0 and hi >= p["sl"])):
                self.close(p["sl"], "SL (биржа)")
                return
            if p.get("tp") and ((d > 0 and hi >= p["tp"]) or (d < 0 and lo <= p["tp"])):
                self.close(p["tp"], "TP (биржа)")
                return

    def last_exit(self, since_ms: int | None = None) -> dict | None:
        return self.st.meta.pop("paper_last_exit", None)


class LiveBackend:
    """Реальные ордера OKX. Создаётся только после проверки трёх условий LIVE (см. main())."""
    mode = "live"

    def __init__(self, settings: dict, creds: dict, okx_module=None):
        if okx_module is None:
            from app.exchanges import okx as okx_module  # noqa: PLC0415
        self.okx = okx_module
        self.s = settings
        self._k = (creds["api_key"], creds["api_secret"], creds.get("passphrase"))  # не логируется
        self.inst = None
        self.pos_mode = None

    def instrument(self) -> dict:
        self.inst = self.okx.get_instrument(INST_ID)
        return self.inst

    def prepare(self) -> None:
        k = self._k
        self.pos_mode = self.okx.get_pos_mode(*k)
        self.okx.set_leverage(k[0], k[1], INST_ID, self.s["leverage"], k[2], mgn_mode="isolated",
                              pos_mode=self.pos_mode)

    def position(self) -> dict | None:
        return self.okx.fetch_position(*self._k, INST_ID)

    def equity(self) -> float | None:
        return self.okx.fetch_balance_usdt(*self._k).get("equity")

    def open(self, side: int, contracts: float, sl: float, tp: float | None, price: float) -> dict:
        k = self._k
        res = self.okx.place_order(k[0], k[1], INST_ID, "buy" if side > 0 else "sell", 0.0, sl, take_profit=tp,
                                   passphrase=k[2], contracts=contracts, td_mode="isolated", pos_mode=self.pos_mode,
                                   cl_ord_id=self.okx.new_cl_ord_id("cxrp"),
                                   sl_trigger_px_type=self.s["sl_trigger_px_type"])
        res["sl_confirmed"] = self._confirm_sl(res["order_id"])
        return res

    def _confirm_sl(self, ord_id: str, tries: int = 4, pause: float = 1.0) -> bool:
        """(b) SL должен быть виден на бирже: в attachAlgoOrds ордера или в closeOrderAlgo позиции."""
        for _ in range(tries):
            try:
                o = self.okx.fetch_order(*self._k, INST_ID, ord_id)
                if any(a.get("slTriggerPx") for a in (o.get("attachAlgoOrds") or [])):
                    return True
                p = self.position()
                if p and p.get("sl"):
                    return True
            except Exception as exc:  # noqa: BLE001
                log.warning("SL check: %s", exc)
            time.sleep(pause)
        return False

    def close(self, price: float, reason: str) -> float | None:
        p = self.position()
        if not p:
            return None
        self.okx.close_position(*self._k, INST_ID, mgn_mode=p.get("mgn_mode") or "isolated",
                                pos_side=p.get("pos_side"))
        return None

    def unrealized(self, price: float) -> float:
        p = self.position()
        return float(p["upl"]) if p else 0.0

    def amend(self, sl: float, tp: float | None) -> None:
        p = self.position()
        k = self._k
        self.okx.amend_stop_loss(k[0], k[1], INST_ID, sl, k[2], algo_id=(p or {}).get("sl_algo_id"),
                                 take_profit=tp, sl_trigger_px_type=self.s["sl_trigger_px_type"])

    def simulate_exits(self, bars, price) -> None:
        return None

    def last_exit(self, since_ms: int | None = None) -> dict | None:
        try:
            df = self.okx.fetch_closed_trades(*self._k, lookback_days=2, limit=20)
            df = df[df["symbol"] == SYMBOL]
            if since_ms is not None and len(df):
                import pandas as pd  # noqa: PLC0415
                df = df[df["updated_time"] >= pd.Timestamp(int(since_ms), unit="ms", tz="UTC")]
            if len(df):
                r = df.iloc[-1]
                return {"price": float(r["avg_exit_price"]), "pnl": float(r["closed_pnl"]), "reason": "SL/TP (биржа)"}
        except Exception as exc:  # noqa: BLE001
            log.warning("last_exit: %s", exc)
        return None


# ---------------------------------------------------------------- bot core --
class ComboXrpBot:
    def __init__(self, settings: dict, backend, state: StateFile, notify, cfg, trades_csv: Path = TRADES_CSV,
                 now_fn=None):
        self.s, self.be, self.st, self.notify, self.cfg = settings, backend, state, notify, cfg
        self.csv = trades_csv
        self.now = now_fn or (lambda: int(time.time() * 1000))
        self.inst = backend.instrument()
        m = self.st.meta
        now = self.now()
        if m.get("mode") != backend.mode or not m.get("started_ms"):
            m.update({"mode": backend.mode, "started_ms": now})
        m["launch_ms"] = now
        m["launch_realized"] = float(m.get("realized_total", 0.0))
        eq = backend.equity()
        m["launch_equity"] = eq
        m.setdefault("realized_total", 0.0)
        self.st.save()

    # -- helpers
    def _day_pnl_add(self, pnl: float) -> None:
        m = self.st.meta
        today = utc_day(self.now())
        if m.get("day") != today:
            m["day"], m["day_realized"] = today, 0.0
        m["day_realized"] = float(m.get("day_realized", 0.0)) + pnl
        m["realized_total"] = float(m.get("realized_total", 0.0)) + pnl

    def _record_close(self, exit_price: float, reason: str, pnl: float | None) -> None:
        d = self.st.deal
        side = 1 if d.get("side") == "long" else -1
        q = float(d.get("qty_coins") or 0)
        entry = float(d.get("base_price") or 0)
        if pnl is None:
            pnl = (exit_price - entry) * q * side
        pct = (exit_price - entry) / entry * 100 * side if entry else 0.0
        now = self.now()
        log_trade({"symbol": SYMBOL, "entry_time": d.get("entry_time"), "exit_time": iso(now), "orders_filled": 1,
                   "filled_pct": 100, "avg_entry_price": entry, "exit_price": exit_price, "reason": reason,
                   "bars_held": int((now - int(d.get("entry_ms") or now)) // H1), "gross_pnl_pct": round(pct, 4),
                   "side": d.get("side"), "contracts": d.get("contracts"), "qty_coins": q, "pnl_usd": round(pnl, 4),
                   "mode": self.be.mode}, self.csv)
        self._day_pnl_add(pnl)
        self.notify(f"{'✅' if pnl > 0 else '❌'} #XRP {('ЛОНГ' if side > 0 else 'ШОРТ')} закрыта — {reason}\n"
                    f"Вход {entry:.4f} → выход {exit_price:.4f}\nPnL {pnl:+.2f} $ ({pct:+.2f}%)")
        self.st.data[SYMBOL] = {"in_deal": False}

    def _close_now(self, price: float, reason: str) -> None:
        pnl = self.be.close(price, reason)
        if self.be.mode == "live":
            time.sleep(1.0)
            ex = self.be.last_exit(self.st.deal.get("entry_ms")) or {}
            self._record_close(ex.get("price", price), reason, ex.get("pnl"))
        else:
            ex = self.be.last_exit() or {}
            self._record_close(ex.get("price", price), reason, pnl)

    def _kill(self, why: str, price: float) -> None:
        if self.st.deal.get("in_deal") or self.be.position():
            try:
                self._close_now(price, f"Kill-switch: {why}")
            except Exception as exc:  # noqa: BLE001
                self.notify(f"🚨 Kill-switch: НЕ удалось закрыть позицию XRP ({exc}). ЗАКРОЙ ВРУЧНУЮ на OKX!")
        self.st.meta["killed_day"] = utc_day(self.now())
        self.st.meta["killed_reason"] = why
        self.st.save()
        self.notify(f"🛑 KILL-SWITCH: {why}\nПозиция закрыта, бот остановлен до конца суток UTC.")
        raise StopBot(why)

    # -- (d) reconcile
    def reconcile(self, price: float) -> bool:
        """True = можно торговать дальше в этом цикле."""
        pos = self.be.position()
        d, m = self.st.deal, self.st.meta
        if d.get("in_deal"):
            if pos is None:
                ex = self.be.last_exit(d.get("entry_ms")) or {}
                self._record_close(float(ex.get("price") or price), ex.get("reason") or "SL/TP (биржа)",
                                   ex.get("pnl"))
                return True
            same = pos["side"] == d.get("side") and abs(float(pos["contracts"]) - float(d.get("contracts") or 0)) < 1e-9
            if not same:
                if not m.get("paused"):
                    self.notify(f"⚠️ Позиция XRP на OKX ({pos['side']}, {pos['contracts']} конт.) не совпадает с ботом "
                                f"({d.get('side')}, {d.get('contracts')}). Бот на паузе, ничего не трогает.")
                m["paused"] = "mismatch"
                return False
        else:
            if pos is not None:
                if not m.get("paused"):
                    self.notify(f"⚠️ На OKX есть позиция XRP ({pos['side']}, {pos['contracts']} конт.), открытая НЕ ботом. "
                                "Бот её не трогает и стоит на паузе, пока она не будет закрыта.")
                m["paused"] = "foreign"
                return False
        if m.get("paused"):
            self.notify("▶️ Позиция XRP на OKX сверена — бот снова работает.")
            m["paused"] = None
        return True

    # -- (c) kill-switch
    def check_kill(self, price: float) -> None:
        m = self.st.meta
        upl = self.be.unrealized(price) if self.st.deal.get("in_deal") else 0.0
        since = float(m.get("realized_total", 0.0)) - float(m.get("launch_realized", 0.0)) + upl
        today = utc_day(self.now())
        day = (float(m.get("day_realized", 0.0)) if m.get("day") == today else 0.0) + upl
        lim = self.s["daily_loss_stop"]
        if since <= -lim:
            self._kill(f"PnL с запуска {since:+.2f} $ ≤ −{lim:.0f} $", price)
        if day <= -lim:
            self._kill(f"PnL за сутки {day:+.2f} $ ≤ −{lim:.0f} $", price)
        # 2026-10-18: счёт OKX общий с GinArea — просадка ВСЕГО баланса больше не останавливает бота.
        # Kill-switch выше считает только сделки самого бота. Проверка всего счёта — по желанию:
        # "account_drop_stop": N (> 0) в combo_xrp_live_settings.json; по умолчанию 0 = выкл.
        acc_lim = float(self.s.get("account_drop_stop", 0) or 0)
        eq0 = m.get("launch_equity")
        if acc_lim > 0 and eq0 is not None:
            eq = self.be.equity()
            if eq is not None and float(eq0) - float(eq) > acc_lim:
                self._kill(f"баланс счёта упал на {float(eq0) - float(eq):.2f} $ (> {acc_lim:.0f} $)", price)

    # -- main step
    def step(self, df, ref_df, price: float) -> str:
        m, d = self.st.meta, self.st.deal
        now = self.now()
        if m.get("killed_day") == utc_day(now):
            raise StopBot(f"kill-switch сработал сегодня ({m.get('killed_reason')})")
        # paper: «биржевые» SL/TP по барам после входа
        if d.get("in_deal") and self.be.mode == "paper":
            em = int(d.get("entry_ms") or now)
            bars = [(float(r.high), float(r.low)) for ts, r in df.iterrows() if int(ts.value // 1_000_000) >= em - 1]
            self.be.simulate_exits(bars, price)
        if not self.reconcile(price):
            return "paused"
        self.check_kill(price)
        d = self.st.deal
        soft = d.get("soft_sl")   # 2026-10-31: запасной стоп бота, когда биржевой не удалось перенести
        if d.get("in_deal") and soft and ((price <= soft) if d.get("side") == "long" else (price >= soft)):
            self._close_now(price, f"Стоп стратегии {float(soft):.4f} (биржевой не перенёсся)")
            return "close"
        last_bar = int(df.index[-1].value // 1_000_000)
        if last_bar == m.get("last_bar"):
            return "same_bar"
        target, syn_ms = engine_target(df, ref_df, self.cfg, m["started_ms"], price)
        m["last_bar"] = last_bar
        action = "hold"
        d = self.st.deal
        if d.get("in_deal"):
            tside = None if target is None else ("long" if target["side"] > 0 else "short")
            if target is None or tside != d.get("side") or target["entry_ts"] != d.get("engine_entry_ts"):
                self._close_now(price, "Сигнал стратегии (выход)")
                action = "close"
            else:
                self._sync_levels(target)
        d = self.st.deal
        if not d.get("in_deal") and target is not None and target["entry_ts"] == syn_ms:
            if now - syn_ms > self.s["max_entry_delay_min"] * 60_000:
                self.notify(f"⏭ Сигнал Combo XRP пропущен: опоздание {(now - syn_ms) / 60000:.0f} мин "
                            f"(> {self.s['max_entry_delay_min']}).")
            else:
                action = self._open(target, price, syn_ms) or action
        m["last_run"] = now
        self.st.save()
        return action

    def _sync_levels(self, target: dict) -> None:
        d = self.st.deal
        tick = self.inst.get("tickSz") or 0.0001
        new_sl, new_tp = target["sl"], target["tp"]
        if new_sl and abs(new_sl - float(d.get("sl") or 0)) >= tick or (new_tp and abs(new_tp - float(d.get("tp") or 0)) >= tick):
            try:
                self.be.amend(new_sl, new_tp)
                d.pop("soft_sl", None)
                d["sl"], d["tp"] = new_sl, new_tp
                d["stop_synced_price"] = new_sl
                self.notify(f"🔧 #XRP стоп/тейк обновлены по стратегии: SL {new_sl:.4f} · TP {new_tp or 0:.4f}")
            except Exception as exc:  # noqa: BLE001
                # 2026-10-31: биржевой стоп не перенёсся — бот сам следит за новым стопом и закроет по рынку
                d["soft_sl"] = new_sl
                if d.get("soft_note_sl") != new_sl:
                    d["soft_note_sl"] = new_sl
                    self.notify(f"⚠️ Не удалось перенести SL/TP XRP на бирже: {exc}. Старый SL на бирже остаётся, "
                                f"а бот сам закроет по рынку, если цена дойдёт до нового стопа {new_sl:.4f}.")

    def _open(self, target: dict, price: float, syn_ms: int) -> str | None:
        side = target["side"]
        sl, tp = target["sl"], target["tp"]
        if not sl or (side > 0 and sl >= price) or (side < 0 and sl <= price):
            self.notify(f"⏭ Вход XRP пропущен: некорректный стоп {sl} при цене {price:.4f}.")
            return None
        if self.st.deal.get("in_deal") or self.be.position() is not None:   # (d) никогда двух позиций
            return None
        plan = plan_size(self.s, self.be.equity(), price, self.inst)
        if plan["contracts"] <= 0:
            self.notify(f"⏭ Вход XRP пропущен: нотионал {plan['notional']:.2f} $ меньше минимального лота OKX "
                        f"({self.inst['minSz']} конт. × {self.inst['ctVal']} XRP).")
            return None
        res = self.be.open(side, plan["contracts"], sl, tp, price)
        sname = "long" if side > 0 else "short"
        self.st.data[SYMBOL] = {"in_deal": True, "side": sname, "contracts": plan["contracts"],
                                "qty_coins": plan["qty_coins"], "base_price": price, "entry_ms": syn_ms,
                                "entry_time": iso(syn_ms), "engine_entry_ts": target["entry_ts"], "sl": sl, "tp": tp,
                                "stop_synced_price": sl, "order_id": res.get("order_id"),
                                "orders": [{"qty": plan["qty_coins"], "price": price}], "mode": self.be.mode}
        self.st.save()
        if not res.get("sl_confirmed"):
            try:
                self.be.close(price, "нет SL")
            finally:
                self.st.data[SYMBOL] = {"in_deal": False}
                self.st.meta["killed_day"] = utc_day(self.now())
                self.st.meta["killed_reason"] = "SL не подтверждён биржей"
                self.st.save()
            self.notify("🚨 OKX не подтвердила стоп-лосс по новой позиции XRP — позиция сразу закрыта, бот ОСТАНОВЛЕН. "
                        "Проверь позиции на OKX вручную.")
            raise StopBot("SL не подтверждён биржей")
        self.notify(f"{'🟢 ЛОНГ' if side > 0 else '🔴 ШОРТ'} #XRP открыт · 1h · Combo OTM\n"
                    f"Вход ≈{price:.4f} · Стоп {sl:.4f} · Тейк {(tp or 0):.4f}\n"
                    f"Размер {plan['contracts']:g} конт. ({plan['qty_coins']:g} XRP) ≈ {plan['notional']:.2f} $ · "
                    f"плечо x{self.s['leverage']} · маржа ≈ {plan['margin']:.2f} $")
        return "open"


# ---------------------------------------------------------------- live gate (a) --
def live_confirmed(args, settings: dict, confirm_file: Path = CONFIRM_FILE, env=None) -> tuple:
    env = os.environ if env is None else env
    if not args.live:
        return False, "нет флага --live"
    if settings.get("mode") != "live":
        return False, 'в combo_xrp_live_settings.json "mode" не "live"'
    token = env.get(CONFIRM_ENV)
    try:
        data = json.loads(confirm_file.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return False, "нет подтверждения LIVE из панели"
    finally:
        try:
            confirm_file.unlink()          # одноразовый
        except OSError:
            pass
    if not token or data.get("token") != token:
        return False, "токен подтверждения LIVE не совпал"
    if time.time() - float(data.get("created", 0)) > CONFIRM_MAX_AGE:
        return False, "подтверждение LIVE устарело"
    return True, "ok"


def load_creds() -> dict | None:
    from app.config import TRADE_KEYS_FILE  # noqa: PLC0415
    from app.trade_keys_store import TradeKeysStore  # noqa: PLC0415
    c = TradeKeysStore(TRADE_KEYS_FILE).get_for_strategy(STRATEGY_ID, "okx")
    if not c or not c.get("api_key") or not c.get("api_secret") or not c.get("passphrase"):
        return None
    return c


def setup_logging() -> None:
    LOG_FILE.parent.mkdir(exist_ok=True)
    fmt = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
    fh = logging.FileHandler(LOG_FILE, encoding="utf-8")
    fh.setFormatter(fmt)
    sh = logging.StreamHandler(sys.stdout)
    sh.setFormatter(fmt)
    log.handlers[:] = [fh, sh]
    log.setLevel(logging.INFO)


_MK: dict = {}


def fetch_market(now_ms: int):
    """2026-10-20: свечи кешируются. Раньше каждые 30 с качалось 2×1000 часовых свечей (~20 запросов к
    history-candles) — отсюда таймауты OKX. Теперь полная история один раз, дальше — только последние 100
    свечей и только когда закрылся новый час (или раз в 10 мин). Цена — каждый цикл, один лёгкий запрос."""
    import pandas as pd  # noqa: PLC0415
    from app.exchanges import okx  # noqa: PLC0415
    hour = now_ms // H1
    last_ok = "df" in _MK and int(_MK["df"].index[-1].value // 1_000_000) + 2 * H1 > now_ms   # есть последняя закрытая свеча
    need = (not _MK) or _MK.get("hour") != hour or not last_ok or now_ms - _MK.get("at", 0) > 600_000
    if need:
        for key, inst in (("df", INST_ID), ("ref", REF_INST)):
            try:
                new = candles_df(okx.fetch_candles(inst, "1H", 100 if key in _MK else 1000), now_ms)
                old = _MK.get(key)
                _MK[key] = new if old is None else pd.concat([old, new])[lambda x: ~x.index.duplicated(keep="last")].sort_index().tail(1000)
            except Exception as exc:  # noqa: BLE001
                if key == "df" and "df" not in _MK:
                    raise
                log.warning("свечи %s: %s (беру из кеша)", inst, exc)
        _MK.update(hour=hour, at=now_ms)
    price = okx.get_last_price(INST_ID)
    return _MK["df"], _MK.get("ref"), price


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=LABEL)
    ap.add_argument("--live", action="store_true")
    ap.add_argument("--once", action="store_true", help="один цикл и выход")
    args = ap.parse_args(argv)
    setup_logging()
    from app import single_instance  # noqa: PLC0415
    single_instance.acquire_or_exit("combo_xrp_live")          # (e)

    settings = load_settings()
    ok, why = live_confirmed(args, settings)
    mode = "live" if ok else "paper"
    notify = make_notifier(bool(settings.get("telegram", True)), mode)
    if args.live and not ok:
        notify(f"⚠️ LIVE не включён ({why}) — работаю в PAPER (без реальных ордеров).")
    import combo_full as cf  # noqa: PLC0415
    cfg = cf.load_settings_csv(str(BASE / "combo_sub2.csv"))[0]

    state = StateFile(STATE_FILE if mode == "live" else PAPER_STATE_FILE)
    try:
        if mode == "live":
            creds = load_creds()
            if creds is None:
                notify("🚫 Нет торгового ключа OKX (/tradekey comboxrp okx … или /tradekey okx …). Бот остановлен.")
                return 2
            backend = LiveBackend(settings, creds)
            backend.prepare()
        else:
            backend = PaperBackend(settings, state)
        bot = ComboXrpBot(settings, backend, state, notify, cfg)
    except StopBot as exc:
        notify(f"🛑 Бот не запущен: {exc}")
        return 1
    except Exception as exc:  # noqa: BLE001
        notify(f"🛑 Ошибка запуска: {exc}")
        log.error(traceback.format_exc())
        return 1
    notify(f"🚀 Запущен. Депозит {settings['deposit']:.0f} $, плечо x{settings['leverage']}, "
           f"kill-switch −{settings['daily_loss_stop']:.0f} $. Только {INST_ID}.")

    errors = 0
    while True:
        try:
            now = int(time.time() * 1000)
            df, ref, price = fetch_market(now)
            act = bot.step(df, ref, price)
            if act != "same_bar":
                log.info("step: %s price=%.4f", act, price)
            if errors >= 3:
                notify("✅ Связь восстановлена, бот работает.")
            errors = 0
            state.meta["last_error"] = None
            state.save()
            if args.once:
                return 0
            time.sleep(settings["poll_seconds"])
        except StopBot as exc:
            log.error("STOP: %s", exc)
            state.save()
            return 3
        except KeyboardInterrupt:
            state.save()
            return 0
        except Exception as exc:  # noqa: BLE001  (f)
            errors += 1
            log.error("ошибка цикла #%d: %s\n%s", errors, exc, traceback.format_exc())
            state.meta["last_error"] = str(exc)[:300]
            try:
                state.save()
            except Exception:  # noqa: BLE001
                pass
            # 2026-10-20: одиночные таймауты OKX — обычное дело, бот сам повторяет. В Telegram — только если
            # связи нет 3 цикла подряд (≈ 4–7 мин), дальше раз в 20 циклов.
            if errors == 3 or errors % 20 == 0:
                notify(f"⚠️ Нет связи с OKX {errors} цикла подряд: {str(exc)[:200]}. Бот повторяет сам; стоп и тейк стоят на бирже.")
            if args.once:
                return 4
            time.sleep(min(30 * 2 ** min(errors, 5), 900))


if __name__ == "__main__":
    raise SystemExit(main())
