# -*- coding: utf-8 -*-
"""
Combo OTM 7.1 — надстройка над combo_full.py (порт v3.2).

Отличия 7.1 от v3.2 (по diff Pine-исходников):
  1. Новый фильтр входа «Premium Discount» (10 новых input + "Shadow: Premium Discount"):
     канал из последних N (Max Pivots, деф. 15) ПОДТВЕРЖДЁННЫХ pivot high / pivot low
     (свои Left/Right Bars, деф. 3/3). Resistance = max(pivot highs), Support = min(pivot lows),
     позиция close: (close - mid) / ((R - S)/2) * 100  (−100 = Support, 0 = середина, +100 = Resistance).
     Long разрешён при LongMin <= pos <= LongMax (деф. −50..150), Short при ShortMin..ShortMax (−150..50).
     Если канал не готов (нет пивотов или R <= S) — при включённом фильтре вход запрещён.
     Фильтр участвует в общей «quality» (под мастер-свитчем) и, по флагу, в Shadow Lock.
     По умолчанию оба флага Use Premium Discount Long/Short = false → без них 7.1 == 3.2.
  2. Вход дополнительно требует barstate.isconfirmed и в strategy() добавлен calc_on_every_tick=true.
     На бэктесте по закрытым барам это НИЧЕГО не меняет (каждый исторический бар подтверждён),
     поэтому в порте не моделируется.
  3. Остальное (все 23 фильтра, Shadow Lock, выходы, дефолты) — без изменений.

Использование:
    import combo71 as c71
    cfg, applied, unmatched = c71.load_settings_csv(path)      # дефолты 7.1 + CSV
    tr, dd, fin, st = c71.run(df, cfg, ref_df, start, end, ...)  # тот же интерфейс, что combo_full.run
"""
from __future__ import annotations

import os
import shutil
from pathlib import Path

import numpy as np

_H = Path(__file__).resolve().parent
_FILES = _H / "combo_okx" / "ChatExport_2026-10-17" / "files"
PINE71 = _FILES / "Combo OTM 7.1.txt"
PINE32_TXT = _FILES / "Combo_OTM_v3.2.txt"

# combo_full читает strategies/Combo_OTM_v3.2.pine при импорте — подстрахуемся копией из чата.
_p32 = _H / "strategies" / "Combo_OTM_v3.2.pine"
if not _p32.exists() and not os.path.exists("/mnt/user-data/uploads/VANTORIX/bot/strategies/Combo_OTM_v3.2.pine") and PINE32_TXT.exists():
    _p32.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(PINE32_TXT, _p32)

import combo_full as cf  # noqa: E402

# Англоязычный экспорт TradingView (CSV ZEC от автора) — добавим названия источников/ТФ.
cf.SOURCE_RU.update({"(h + l)/2": "hl2", "(h + l + c)/3": "hlc3", "(o + h + l + c)/4": "ohlc4",
                     "(h + l + c + c)/4": "hlcc4", "(h+l)/2": "hl2", "(h+l+c)/3": "hlc3"})
cf.TF_RU.update({"1 hour": "60", "2 hours": "120", "4 hours": "240", "1 day": "1D", "15 minutes": "15",
                 "30 minutes": "30", "5 minutes": "5", "1 minute": "1"})
cf.TITLE_ALIAS.setdefault("source", "zSrc")

INPUTS32 = cf.INPUTS
INPUTS71 = cf.parse_pine_inputs(str(PINE71))
NEW_KEYS = [k for k in INPUTS71 if k not in INPUTS32]


def default_config():
    return {k: v["default"] for k, v in INPUTS71.items()}


# Локализованные значения строковых опций (TV экспортирует перевод, Pine сравнивает с английским)
STR_RU = {"диапазон": "Range", "направление": "Direction", "нулевая линия": "Zero Line",
          "диапазон + направление": "Range + Direction"}


def _norm_strings(cfg, inputs):
    for k, meta in inputs.items():
        if meta["type"] == "string" and isinstance(cfg.get(k), str):
            cfg[k] = STR_RU.get(cfg[k].strip().lower(), cfg[k])
    return cfg


def load_settings_csv(path, cfg=None):
    """Как cf.load_settings_csv, но по списку input 7.1 (новые настройки — дефолты 7.1)."""
    old = cf.INPUTS
    try:
        cf.INPUTS = INPUTS71
        c, a, u = cf.load_settings_csv(path, default_config() if cfg is None else cfg)
    finally:
        cf.INPUTS = old
    return _norm_strings(c, INPUTS71), a, u


def load_settings_csv32(path):
    """Загрузка той же сборки для движка v3.2 (combo_full), с той же нормализацией строк."""
    c, a, u = cf.load_settings_csv(path)
    return _norm_strings(c, INPUTS32), a, u


def premium_discount_position(high, low, close, left, right, max_piv):
    """Позиция close в канале из подтверждённых пивотов (без заглядывания вперёд)."""
    vh, vl = cf.pivots(high, low, left, right)   # значение видно на баре подтверждения (t-right)
    n = len(close)
    pos = np.full(n, np.nan)
    hs, ls = [], []
    for t in range(n):
        if not np.isnan(vh[t]):
            hs.append(vh[t])
            if len(hs) > max_piv:
                hs.pop(0)
        if not np.isnan(vl[t]):
            ls.append(vl[t])
            if len(ls) > max_piv:
                ls.pop(0)
        if hs and ls:
            r, s = max(hs), min(ls)
            if r > s:
                pos[t] = (close[t] - (r + s) / 2.0) / ((r - s) / 2.0) * 100.0
    return pos


_orig_compute = cf.compute_conditions


def compute_conditions71(df, cfg, ref_df=None):
    P = cfg
    R = _orig_compute(df, cfg, ref_df)
    if not (P.get("pivotMatrixActiveLong") or P.get("pivotMatrixActiveShort")):
        return R
    h, l, c = (df[k].to_numpy(float) for k in ("high", "low", "close"))
    pos = premium_discount_position(h, l, c, int(P["pivotMatrixLeftBars"]), int(P["pivotMatrixRightBars"]),
                                    int(P["pivotMatrixMaxPivots"]))
    ok = ~np.isnan(pos)
    T = np.ones(len(c), bool)
    pL = T if not P["pivotMatrixActiveLong"] else ok & (np.nan_to_num(pos, nan=-1e18) >= P["pivotMatrixLongMin"]) & (np.nan_to_num(pos, nan=1e18) <= P["pivotMatrixLongMax"])
    pS = T if not P["pivotMatrixActiveShort"] else ok & (np.nan_to_num(pos, nan=-1e18) >= P["pivotMatrixShortMin"]) & (np.nan_to_num(pos, nan=1e18) <= P["pivotMatrixShortMax"])
    R["qualL"] = R["qualL"] & pL
    R["qualS"] = R["qualS"] & pS
    if P.get("shadowIncludePivotMatrix"):
        R["shadowFailL"] = R["shadowFailL"] | ~pL
        R["shadowFailS"] = R["shadowFailS"] | ~pS
    R["conds"]["PremiumDiscount"] = (pL, pS)
    R["pdPos"] = pos
    return R


def run(df, cfg, ref_df=None, start=None, end=None, **kw):
    """Движок combo_full.run с подменённым compute_conditions (фильтр Premium Discount)."""
    cf.compute_conditions = compute_conditions71
    try:
        return cf.run(df, cfg, ref_df, start, end, **kw)
    finally:
        cf.compute_conditions = _orig_compute


summarize = cf.summarize
