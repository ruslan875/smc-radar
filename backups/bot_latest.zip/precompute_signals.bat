@echo off
cd /d "%~dp0"
set N=%1
if "%N%"=="" set N=25
echo Precompute indicator signals for autopick, top %N% coins. LOW priority: backtests in the panel stay fast.
start "" /low /wait venv\Scripts\python.exe download_all_candles.py %N% --signals
pause
