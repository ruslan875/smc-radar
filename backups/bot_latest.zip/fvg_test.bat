@echo off
cd /d %~dp0
if exist venv\Scripts\python.exe (venv\Scripts\python.exe fvg_test.py) else (python fvg_test.py)
