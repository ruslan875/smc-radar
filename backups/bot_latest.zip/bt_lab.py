"""Лаборатория бэктестов для вкладки терминала «Бэктест» (как в Veles). 2026-09-26.

Запускается панелью фоном:
    python bt_lab.py --job ID --params '{"strategy":"dca", ...}'
Прогресс -> bt_lab_out/<ID>.progress, результат -> bt_lab_out/<ID>.json
(свечи для графика, сделки с каждым добором сетки, кривая счёта, статистика).

Стратегии:
  dca      — клон Veles DCA (фильтры входа DOGE-бота, сетка/объёмы/тейк/стоп
             редактируются в терминале), LONG, свечи 1m.
  eth_rsi  — ETH RSI Trend Filter 4h (как eth_rsi_paper.py), LONG+SHORT.
Все расчёты — на закрытых свечах, комиссия 0.055% за сторону, ликвидация
останавливает торговлю (дальше не считаем выдуманную прибыль).
"""
from __future__ import annotations

import argparse
import json
import math
import sys
import time
import traceback
from pathlib import Path

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import veles_doge_dca_bt as V  # noqa: E402  индикаторы (rsi, cci, adx, cmo, rvi, supersmoother, htf)

OUT = BASE / "bt_lab_out"
CACHE = BASE / "market_cache"
FEE = 0.00055
VIEW_RULE = {"5m": "5min", "15m": "15min", "30m": "30min", "1h": "1h", "2h": "2h", "4h": "4h", "1d": "1D"}


class Progress:
    def __init__(self, job):
        self.p = OUT / f"{job}.progress"

    def __call__(self, pct, text):
        try:
            self.p.write_text(json.dumps({"pct": round(pct), "text": text}, ensure_ascii=False), encoding="utf-8")
        except OSError:
            pass


# ---------- свечи ----------
def load_1m(symbol: str, start_ms: int, prog) -> pd.DataFrame:
    """Минутки со склада candle_store (parquet/pkl, быстро); докачивает только недостающее."""
    import candle_store as CS
    start = pd.to_datetime(start_ms, unit="ms").strftime("%Y-%m-%d")
    prog(2, f"склад свечей {symbol}…")
    return CS.update(symbol, start=start,
                     log=lambda s, t: prog(20, f"качаю минутки {s}: {pd.to_datetime(t, unit='ms'):%Y-%m-%d}"))


def resample(df1: pd.DataFrame, rule: str) -> pd.DataFrame:
    g = df1.set_index(pd.to_datetime(df1.t, unit="ms")).resample(rule, label="left", closed="left").agg(
        {"t": "first", "open": "first", "high": "max", "low": "min", "close": "last", "volume": "sum"}).dropna()
    g["t"] = ((g.index - pd.Timestamp(0)) // pd.Timedelta("1ms")).astype("int64")
    return g.reset_index(drop=True)


# ---------- стратегии ----------
def sim_dca(df, p, prog):
    """Клон Veles DCA LONG. Все цены — закрытые минутки."""
    c = df.close.to_numpy(); lo = df.low.to_numpy(); hi = df.high.to_numpy(); t = df.t.to_numpy()
    prog(45, "индикаторы входа…")
    rsi1 = V.rsi(df.close).to_numpy()
    entry = np.logical_and.reduce([
        rsi1 < 55,
        V.htf(df, "5min", lambda g: V.rsi(g.close)) < 55,
        V.htf(df, "30min", lambda g: V.rsi(g.close)) < 65,
        V.htf(df, "1h", V.cci) < 85,
        V.htf(df, "4h", V.cci) < 70,
        V.htf(df, "5min", V.cci) < -100,
        V.htf(df, "1h", lambda g: V.rma(V.tr(g), 14) / g.close * 100) > 1.2,
        V.htf(df, "1h", V.adx) > 20,
    ]) if p.get("filters", True) else np.ones(len(c), bool)
    prog(60, "фильтры ордеров и тейк…")
    o5 = (rsi1 > 0) & (V.htf(df, "5min", lambda g: V.cmo(g.close)) < -80) & (V.htf(df, "5min", lambda g: V.rvi(g.close)) < 20)
    grid = [(float(o), float(v)) for o, v in p["grid"]]
    use_of = p.get("order_filters", True)
    ok = [np.ones(len(c), bool)] + [(o5 if k == 4 else rsi1 < 30) if use_of else np.ones(len(c), bool)
                                    for k in range(1, len(grid))]
    hl = ((df.high + df.low + df.close) / 3).to_numpy()
    up = V.supersmoother(hl, 200) + V.supersmoother(V.tr(df).fillna(0).to_numpy(), 200) * math.pi
    dep0, lev, reinv = float(p["deposit"]), float(p["leverage"]), float(p["reinvest"]) / 100
    min_pnl, sl = float(p["min_pnl"]), float(p.get("sl") or 0)
    vsum = sum(v for _, v in grid) or 1
    eq = dep0; pos = None; trades = []; liq = None
    mpu = (0.0, None); fees_total = 0.0; bars_in = 0
    prog(70, "симуляция…")
    n = len(c); step = max(n // 20, 1)
    for i in range(300, n):
        if i % step == 0:
            prog(70 + 25 * i / n, f"симуляция {pd.to_datetime(t[i], unit='ms'):%Y-%m-%d}")
        if pos is None:
            if not entry[i]:
                continue
            dep = min(dep0 + reinv * max(eq - dep0, 0), eq)
            b = c[i]
            lv = [(b * (1 - o / 100), dep * lev * v / vsum) for o, v in grid]
            u = lv[0][1]
            pos = {"i": i, "q": u / b, "cost": u, "fee": u * FEE, "f": 1, "lv": lv, "b": b, "mpu": 0.0,
                   "fills": [{"t": int(t[i]), "px": float(b), "usd": round(u, 2), "n": 1}]}
            continue
        bars_in += 1
        while pos["f"] < len(grid) and c[i] <= pos["lv"][pos["f"]][0] and ok[pos["f"]][i]:
            u = pos["lv"][pos["f"]][1]
            pos["q"] += u / c[i]; pos["cost"] += u; pos["fee"] += u * FEE; pos["f"] += 1
            pos["fills"].append({"t": int(t[i]), "px": float(c[i]), "usd": round(u, 2), "n": pos["f"]})
        un = pos["q"] * lo[i] - pos["cost"] - pos["fee"]
        pos["mpu"] = min(pos["mpu"], un)
        if un < mpu[0]:
            mpu = (un, int(t[i]))
        ex = why = None
        if un <= -eq:
            ex, why, liq = float(lo[i]), "ликвидация", int(t[i])
        elif sl and lo[i] <= pos["b"] * (1 - sl / 100):
            ex, why = pos["b"] * (1 - sl / 100), "стоп"
        elif (c[i] / (pos["cost"] / pos["q"]) - 1) * 100 >= min_pnl and c[i] >= up[i]:
            ex, why = float(c[i]), "тейк"
        if ex is not None:
            fee_out = pos["q"] * ex * FEE
            net = pos["q"] * ex - pos["cost"] - pos["fee"] - fee_out
            if why == "ликвидация":
                net = -eq
            fees_total += pos["fee"] + fee_out
            eq += net
            trades.append(_trade(pos, "LONG", int(t[i]), ex, net, why, eq))
            pos = None
            if liq:
                break
    open_pos = None
    if pos:
        un = pos["q"] * c[-1] - pos["cost"] - pos["fee"]
        open_pos = {"open_t": int(t[pos["i"]]), "orders": pos["f"], "avg": pos["cost"] / pos["q"], "unreal": un,
                    "fills": pos["fills"]}
    return trades, eq, liq, mpu, fees_total, bars_in, open_pos


def _trade(pos, side, close_t, ex, net, why, eq):
    return {"side": side, "open_t": pos["fills"][0]["t"], "close_t": close_t, "entry": float(pos["b"]),
            "avg": float(pos["cost"] / pos["q"]), "exit": float(ex), "orders": pos["f"], "volume": round(pos["cost"], 2),
            "net": round(float(net), 4), "pnl_pct": round(float(net) / pos["cost"] * 100, 3), "why": why,
            "eq": round(float(eq), 4), "mpu": round(float(pos["mpu"]), 4), "fills": pos["fills"]}


def sim_eth_rsi(df1, p, prog):
    """ETH RSI Trend Filter 4h (как eth_rsi_paper.py), стоп 2 ATR, трейлинг 1.5 ATR после +2 ATR, выход RSI 50."""
    d = resample(df1, "4h")
    rsi, ma, atr = V.rsi(d.close), d.close.rolling(20).mean(), V.rma(V.tr(d), 14)
    c, h, lo, o, t = d.close.to_numpy(), d.high.to_numpy(), d.low.to_numpy(), d.open.to_numpy(), d.t.to_numpy()
    r, m, a = rsi.to_numpy(), ma.to_numpy(), atr.to_numpy()
    dep0, lev = float(p["deposit"]), float(p["leverage"])
    eq = dep0; pos = None; trades = []; liq = None; mpu = (0.0, None); fees_total = 0.0; bars_in = 0
    for i in range(30, len(c)):
        if pos:
            bars_in += 1
            s, sl = pos["s"], pos["sl"]
            un = s * (lo[i] if s > 0 else h[i]) * pos["q"] - s * pos["cost"] - pos["fee"]
            pos["mpu"] = min(pos["mpu"], un)
            if un < mpu[0]:
                mpu = (un, int(t[i]))
            ex = why = None
            if s > 0 and lo[i] <= sl: ex, why = min(sl, o[i]), "стоп"
            elif s < 0 and h[i] >= sl: ex, why = max(sl, o[i]), "стоп"
            elif s > 0 and r[i] < 50 <= r[i - 1]: ex, why = c[i], "RSI<50"
            elif s < 0 and r[i] > 50 >= r[i - 1]: ex, why = c[i], "RSI>50"
            if ex is not None:
                fee_out = pos["q"] * ex * FEE
                net = s * (pos["q"] * ex - pos["cost"]) - pos["fee"] - fee_out
                fees_total += pos["fee"] + fee_out; eq += net
                trades.append(_trade({**pos, "b": pos["b"]}, "LONG" if s > 0 else "SHORT", int(t[i]), ex, net, why, eq))
                pos = None
                if eq <= 0:
                    liq = int(t[i]); break
            else:
                if s > 0 and h[i] >= pos["b"] + 2 * a[i]: pos["sl"] = max(sl, h[i] - 1.5 * a[i])
                if s < 0 and lo[i] <= pos["b"] - 2 * a[i]: pos["sl"] = min(sl, lo[i] + 1.5 * a[i])
        if pos is None and i < len(c) - 1:
            s = 1 if (r[i] > 70 >= r[i - 1] and c[i] > m[i]) else (-1 if (r[i] < 30 <= r[i - 1] and c[i] < m[i]) else 0)
            if s:
                u = eq * lev
                pos = {"s": s, "b": c[i], "sl": c[i] - s * 2 * a[i], "q": u / c[i], "cost": u, "fee": u * FEE,
                       "f": 1, "mpu": 0.0, "fills": [{"t": int(t[i]), "px": float(c[i]), "usd": round(u, 2), "n": 1}]}
    return trades, eq, liq, mpu, fees_total, bars_in, None


# ---------- общий конвертер «сделки стратегии» → сделки вкладки ----------
def deals_to_trades(rows, dtf, p, prog=None):
    """rows: список dict(side ±1, t_in, t_out мс, px_in, px_out, pct — чистый % на номинал,
    orders, why, fills?). dtf — свечи сигнального ТФ (для МПУ). Размер: депозит×плечо
    (+реинвест), позиции по очереди, ликвидация останавливает счёт."""
    dep0, lev, reinv = float(p["deposit"]), float(p["leverage"]), float(p.get("reinvest") or 0) / 100
    ts = dtf.t.to_numpy(); hi = dtf.high.to_numpy(); lo = dtf.low.to_numpy()
    eq = dep0; trades = []; liq = None; mpu = (0.0, None); fees = 0.0; busy_until = -1
    for r in sorted(rows, key=lambda x: x["t_in"]):
        if r["t_in"] < busy_until:        # стратегия открыла вторую позицию, пока первая жива — пропускаем
            continue
        busy_until = r["t_out"]
        alloc = min(dep0 + reinv * max(eq - dep0, 0), eq)
        notional = alloc * lev * float(r.get("fill_frac", 1.0))
        a, b = np.searchsorted(ts, r["t_in"], side="right"), np.searchsorted(ts, r["t_out"], side="left")
        side = r["side"]
        if b > a:
            worst = lo[a:b].min() if side > 0 else hi[a:b].max()
            adverse = side * (worst / r["px_in"] - 1) * notional - notional * FEE * 2
        else:
            adverse = 0.0
        adverse = min(adverse, 0.0)
        net = notional * r["pct"] / 100
        why = r.get("why", "")
        t_mpu = int(ts[min(a + int(np.argmin(lo[a:b]) if side > 0 else np.argmax(hi[a:b])), len(ts) - 1)]) if b > a else r["t_in"]
        if adverse < mpu[0]:
            mpu = (adverse, t_mpu)
        if adverse <= -eq:
            net, why, liq = -eq, "ликвидация", t_mpu
        fees += notional * FEE * 2
        eq += net
        fills = r.get("fills") or [{"t": int(r["t_in"]), "px": float(r["px_in"]), "usd": round(notional, 2), "n": 1}]
        trades.append({"side": "LONG" if side > 0 else "SHORT", "open_t": int(r["t_in"]), "close_t": int(liq or r["t_out"]),
                       "entry": float(r["px_in"]), "avg": float(r.get("avg", r["px_in"])), "exit": float(r["px_out"]),
                       "orders": int(r.get("orders", 1)), "volume": round(notional, 2), "net": round(float(net), 4),
                       "pnl_pct": round(float(r["pct"]), 3), "why": why, "eq": round(float(eq), 4),
                       "mpu": round(float(adverse), 4), "fills": fills})
        if liq:
            break
    return trades, eq, liq, mpu, fees, 0, None


def _ms(x):
    return int(pd.Timestamp(x).tz_localize("UTC").timestamp() * 1000) if pd.Timestamp(x).tzinfo is None \
        else int(pd.Timestamp(x).timestamp() * 1000)


def _tf_frame(df1, tf):
    d = resample(df1, VIEW_RULE.get(tf, tf))
    d.index = pd.to_datetime(d.t, unit="ms")
    return d


# ---------- стратегии из проверки 25 стратегий (lab_strategies.py) ----------
def sim_bt(df1, p, prog):
    import lab_engine as E
    import lab_strategies as S
    name = p["strategy"].split(":", 1)[1]
    fn = getattr(S, name)
    prog(50, f"сигналы {name} на {p['tf']}…")
    d = _tf_frame(df1, p["tf"])
    dd = d[["open", "high", "low", "close", "volume"]]
    t = E.simulate(dd, fn(dd))
    cost = 2 * (E.FEE + E.SLIP)
    rows = []
    for r in t.itertuples():
        px_in = float(dd.close.loc[r.entry]); side = int(r.side)
        px_out = px_in * (1 + side * (r.pnl + cost))
        rows.append({"side": side, "t_in": _ms(r.entry), "t_out": _ms(r.exit), "px_in": px_in, "px_out": px_out,
                     "pct": r.pnl * 100, "why": "выход"})
    prog(90, "считаю счёт…")
    return deals_to_trades(rows, df1, p)


# ---------- стратегии paper10 (paper_live.STRATEGIES — родной код каждой) ----------
def sim_paper(df1, p, prog):
    import paper_live as PL
    name = p["strategy"].split(":", 1)[1]
    adapter = {n: f for n, _m, f, _s in PL.STRATEGIES}[name]
    prog(50, f"{name} на {p['tf']}…")
    d = _tf_frame(df1, p["tf"])
    d.index = d.index.tz_localize("UTC")
    d["time"] = d.index
    dd = d[["time", "open", "high", "low", "close", "volume"]]
    deals = adapter(dd, 0.055, 0.03, f"{p['symbol']}/USDT") if name == "HYPE R4" else adapter(dd, 0.055, 0.03)
    rows = []
    for r in (deals.to_dict("records") if deals is not None and len(deals) else []):
        reason = str(r.get("reason", "")).lower()
        if reason in PL.OPEN_REASONS or pd.isna(r.get("exit_time")):
            continue
        side = 1 if str(r.get("side", "")).lower().startswith("l") else -1
        rows.append({"side": side, "t_in": _ms(r["entry_time"]), "t_out": _ms(r["exit_time"]),
                     "px_in": float(r["entry_price"]), "px_out": float(r["exit_price"]),
                     "pct": float(r["gross_pnl_pct"]), "why": str(r.get("reason", ""))})
    prog(90, "считаю счёт…")
    return deals_to_trades(rows, df1, p)


# ---------- Veles TAO BB (veles_tao_bb.compute_signals) ----------
def sim_tao(df1, p, prog):
    import veles_tao_bb as T
    ns = argparse.Namespace(stop_pct=float(p.get("sl") or 2.0), min_pnl=float(p.get("min_pnl") or 0.3), rsi_exit=50.0,
                            mrc_len=200, mrc_inner=1.0, bb_len=20, bb_mult=2.0, roc_len=9, roc_max=-0.3, atr_min=0.3)
    prog(50, "сигналы TAO BB…")
    d1 = df1.set_index(pd.to_datetime(df1.t, unit="ms"))[["open", "high", "low", "close", "volume"]]
    d = T.compute_signals(d1, ns)
    c, lo, o, r, ent, t = d.close.to_numpy(), d.low.to_numpy(), d.open.to_numpy(), d.rsi.to_numpy(), d.entry.to_numpy(), df1.t.to_numpy()
    rows = []; pos = None
    body = p.get("stop_mode", "body") == "body"
    prog(75, "симуляция…")
    for i in range(len(c)):
        if pos:
            stop = pos["px"] * (1 - ns.stop_pct / 100)
            ex = why = None
            low_i = min(o[i], c[i]) if body else lo[i]          # Veles проверяет стоп по телу свечи
            if low_i <= stop: ex, why = (o[i] if o[i] < stop else (c[i] if body else stop)), "стоп"
            elif r[i] > ns.rsi_exit and (c[i] / pos["px"] - 1) * 100 >= ns.min_pnl: ex, why = c[i], "тейк RSI"
            if ex is not None:
                rows.append({"side": 1, "t_in": pos["t"], "t_out": int(t[i]), "px_in": pos["px"], "px_out": float(ex),
                             "pct": ((ex / pos["px"] - 1) - 2 * FEE) * 100, "why": why})
                pos = None
            continue
        if ent[i]:
            pos = {"px": float(c[i]), "t": int(t[i])}
    prog(90, "считаю счёт…")
    return deals_to_trades(rows, df1, p)


# ---------- KC-ROC-CCI-WT grid (kc_roc_cci_wt_grid_backtest.simulate_symbol) ----------
def sim_kcroc(df1, p, prog):
    import kc_roc_cci_wt_grid_backtest as K
    grid = [(float(o), float(v)) for o, v in p["grid"]]
    prm = K.Params(grid=grid, kc_length=20, kc_mult=2.0, roc_length=14, roc_threshold=-1.0, htf1_minutes=15,
                   atr_length=14, atr_min=0.05, atr_max=5.0, htf2_minutes=30, cci_length=20, cci_threshold=-100.0,
                   wt_n1=10, wt_n2=21, wt_avg_len=4, tp_min_pnl_pct=float(p.get("min_pnl") or 0.5),
                   stop_loss_pct=float(p.get("sl") or 4.0), max_deal_bars=20000)
    prog(50, "KC-ROC grid: минутный проход (1–3 мин)…")
    d = df1.copy()
    d["open_time"] = pd.to_datetime(d.t, unit="ms", utc=True)
    deals = K.simulate_symbol(d[["open_time", "open", "high", "low", "close", "volume"]].reset_index(drop=True), p["symbol"], prm)
    rows = []
    for x in deals:
        if x.exit_time is None or x.gross_pnl_pct is None or x.reason == "OPEN_AT_CUTOFF":
            continue
        rows.append({"side": 1, "t_in": _ms(x.entry_time), "t_out": _ms(x.exit_time), "px_in": float(x.avg_entry_price),
                     "avg": float(x.avg_entry_price), "px_out": float(x.exit_price), "orders": x.orders_filled,
                     "fill_frac": x.filled_pct / 100, "pct": x.gross_pnl_pct - 2 * FEE * 100, "why": x.reason})
    prog(90, "считаю счёт…")
    return deals_to_trades(rows, df1, p)


# ---------- Откуп пролива 1m: %-падение + Кельтнер, добор по Кельтнеру 5m, тейк WaveTrend ----------
SLIP = 0.0002          # проскальзывание рыночного ордера за сторону (входы на проливах, стопы)


def _keltner_lower(d, n=20, mult=2.0):
    basis = d.close.ewm(span=n, adjust=False).mean()
    return (basis - mult * V.rma(V.tr(d), n)).to_numpy()


def _wt_sell(d, n1=10, n2=21, avg=4):
    hlc3 = (d.high + d.low + d.close) / 3
    esa = hlc3.ewm(span=n1, adjust=False).mean()
    dd = (hlc3 - esa).abs().ewm(span=n1, adjust=False).mean()
    wt1 = ((hlc3 - esa) / (0.015 * dd.replace(0, np.nan))).ewm(span=n2, adjust=False).mean()
    wt2 = wt1.rolling(avg).mean()
    return ((wt1.shift(1) >= wt2.shift(1)) & (wt1 < wt2)).fillna(False).to_numpy()


def sim_flush(df, p, prog):
    """LONG: минутка упала сильнее drop% и закрылась под нижним Кельтнером 1m -> вход.
    Доборы сетки — по отступу от входа, 2-й и далее только если закрытая 5m под нижним Кельтнером 5m.
    Тейк: WaveTrend 1m пересёк вниз и прибыль от средней >= min_pnl. Стоп: sl% от средней.
    Стоп по телу (закрытие минутки) или по тени (stop_mode=wick). Изолированная маржа:
    убыток больше выделенной маржи = ликвидация сделки (счёт не обнуляется, если маржа < счёта)."""
    c = df.close.to_numpy(); o = df.open.to_numpy(); lo = df.low.to_numpy(); t = df.t.to_numpy()
    prog(45, "Кельтнер 1m/5m и WaveTrend…")
    drop = float(p.get("drop") or 0.5)
    atr_mode = bool(p.get("atr"))
    if atr_mode:
        # пролив в ATR минуток (до этой свечи), отступ/стоп/мин.PnL — в ATR 1h (последний закрытый час)
        a1 = V.rma(V.tr(df), 14).shift(1).to_numpy()
        entry = (np.r_[np.nan, c[:-1] - c[1:]] >= drop * a1) & (c <= _keltner_lower(df))
        ah = V.htf(df, "1h", lambda g: V.rma(V.tr(g), 14) / g.close * 100)
    else:
        roc = np.r_[np.nan, c[1:] / c[:-1] - 1] * 100
        entry = (roc < -drop) & (c <= _keltner_lower(df))
        ah = np.ones(len(c))
    if p.get("trend"):
        entry &= V.htf(df, "4h", lambda g: g.close - g.close.ewm(span=200, adjust=False).mean()) > 0
    ah = np.nan_to_num(np.asarray(ah, float), nan=0.0)
    d5 = resample(df, "5min")
    k5 = d5.close.to_numpy() <= _keltner_lower(d5)
    # 5m бар доступен минутке i, если закрылся к закрытию минутки: t5 + 5m <= t_i + 1m
    j = np.searchsorted(d5.t.to_numpy() + 300_000, t + 60_000, side="right") - 1
    ok5 = np.where(j >= 0, k5[np.clip(j, 0, None)], False)
    tp_sig = _wt_sell(df)
    grid = [(float(a), float(v)) for a, v in p["grid"]]
    vsum = sum(v for _, v in grid) or 1
    fee = (0.0002 if p.get("fees") == "maker" else FEE)
    dep0, lev, reinv = float(p["deposit"]), float(p["leverage"]), float(p["reinvest"]) / 100
    min_pnl, sl = float(p.get("min_pnl") or 0.8), float(p.get("sl") or 0)
    wick = p.get("stop_mode") == "wick"
    eq = dep0; pos = None; trades = []; liq = None; mpu = (0.0, None); fees_total = 0.0; bars_in = 0
    n = len(c); step = max(n // 20, 1)
    prog(60, "симуляция…")
    for i in range(100, n):
        if i % step == 0:
            prog(60 + 35 * i / n, f"симуляция {pd.to_datetime(t[i], unit='ms'):%Y-%m-%d}")
        if pos is None:
            if not entry[i] or eq <= 1:
                continue
            dep = min(dep0 + reinv * max(eq - dep0, 0), eq)
            b = c[i]; px = b * (1 + SLIP)
            m = ah[i]
            if m <= 0:
                continue
            lv = [(b * (1 - a * m / 100), dep * lev * v / vsum) for a, v in grid]
            u = lv[0][1]
            pos = {"i": i, "q": u / px, "cost": u, "fee": u * FEE, "f": 1, "lv": lv, "b": b, "mpu": 0.0, "dep": dep, "m": m,
                   "fills": [{"t": int(t[i]), "px": float(px), "usd": round(u, 2), "n": 1}]}
            continue
        bars_in += 1
        while pos["f"] < len(grid) and c[i] <= pos["lv"][pos["f"]][0] and ok5[i]:
            u = pos["lv"][pos["f"]][1]; px = c[i]
            pos["q"] += u / px; pos["cost"] += u; pos["fee"] += u * fee; pos["f"] += 1
            pos["fills"].append({"t": int(t[i]), "px": float(px), "usd": round(u, 2), "n": pos["f"]})
        avg = pos["cost"] / pos["q"]
        margin = pos["dep"] * sum(v for _, v in grid[:pos["f"]]) / vsum
        un = pos["q"] * lo[i] - pos["cost"] - pos["fee"]
        pos["mpu"] = min(pos["mpu"], un)
        if un < mpu[0]:
            mpu = (un, int(t[i]))
        ex = why = None
        stop = avg * (1 - sl * pos["m"] / 100) if sl else None
        if un <= -margin:
            ex, why = float(lo[i]), "ликвидация"
        elif stop and (lo[i] <= stop if wick else c[i] <= stop):
            ex = (min(o[i], stop) if wick else c[i]) * (1 - SLIP); why = "стоп"
        elif tp_sig[i] and (c[i] / avg - 1) * 100 >= min_pnl * pos["m"]:
            ex, why = float(c[i]) * (1 - SLIP), "тейк WT"
        if ex is not None:
            fee_out = pos["q"] * ex * FEE
            net = pos["q"] * ex - pos["cost"] - pos["fee"] - fee_out
            if why == "ликвидация":
                net = -margin
                liq = liq or int(t[i])
            fees_total += pos["fee"] + fee_out
            eq += net
            trades.append(_trade(pos, "LONG", int(t[i]), ex, net, why, eq))
            pos = None
            if eq <= 1:
                liq = int(t[i]); break
    open_pos = None
    if pos:
        un = pos["q"] * c[-1] - pos["cost"] - pos["fee"]
        open_pos = {"open_t": int(t[pos["i"]]), "orders": pos["f"], "avg": pos["cost"] / pos["q"], "unreal": un,
                    "fills": pos["fills"]}
    return trades, eq, liq, mpu, fees_total, bars_in, open_pos


# ---------- Мульти-DCA: MRC + ATR% + MACD, сетка от предыдущего ордера, частичные тейки, б/у после 1-го ----------
MDCA_COINS = ["XMR", "ADA", "XRP", "XLM", "DOGE", "LINK"]


def _mrc_lower(d, mult, n=200):
    hl = ((d.high + d.low + d.close) / 3).to_numpy()
    mean = V.supersmoother(hl, n); rng = V.supersmoother(V.tr(d).fillna(0).to_numpy(), n)
    return pd.Series(mean - math.pi * mult * rng, index=d.index)


def _macd_hist(close):
    m = close.ewm(span=12, adjust=False).mean() - close.ewm(span=26, adjust=False).mean()
    return (m - m.ewm(span=9, adjust=False).mean()).to_numpy()


def sim_mdca(df, p, prog):
    """LONG DCA. Вход: ATR% 15m > a0, закрытая 5m ниже слабого уровня MRC, гистограмма MACD 1m растёт.
    Доборы (отступ от предыдущего ордера): 2й — MRC слабый + ATR% 5m>0.2, 3й — MRC средний + ATR% 5m>0.4,
    4й — MRC сильный + ATR% 15m>0.6; у всех — разворот гистограммы MACD 1m вверх.
    Тейки частями от средней (по 25%), после первого тейка стоп в безубыток, доборы отменяются. Стопа нет."""
    c = df.close.to_numpy(); hi = df.high.to_numpy(); lo = df.low.to_numpy(); t = df.t.to_numpy()
    prog(40, "MRC 5m, ATR%, MACD…")
    atrp = lambda g: V.rma(V.tr(g), 14) / g.close * 100
    a15 = V.htf(df, "15min", atrp); a5 = V.htf(df, "5min", atrp)
    mrc = {k: V.htf(df, "5min", lambda g, k=k: g.close - _mrc_lower(g, k)) < 0 for k in (1.0, 1.7075, 2.415)}
    h = _macd_hist(df.close)
    up = np.r_[False, h[1:] > h[:-1]]
    turn = np.r_[False, False, (h[2:] > h[1:-1]) & (h[1:-1] <= h[:-2])]
    entry = (a15 > float(p.get("atr0") or 0.5)) & mrc[1.0] & up
    okf = [None, mrc[1.0] & (a5 > 0.2) & turn, mrc[1.7075] & (a5 > 0.4) & turn, mrc[2.415] & (a15 > 0.6) & turn]
    grid = [(float(a), float(v)) for a, v in p["grid"]]
    lvl, k = [], 1.0
    for a, _ in grid:                                   # отступ от предыдущего ордера
        k *= 1 - a / 100; lvl.append(k)
    tps = [(float(a), float(v)) for a, v in (p.get("tps") or [[0.9, 25], [3.2, 25], [6.4, 25], [12.5, 25]])]
    tsum = sum(v for _, v in tps) or 1
    vsum = sum(v for _, v in grid) or 1
    esl = float(p.get("sl") or 0)       # аварийный стоп от средней, % (0 — нет)
    dep0, lev, reinv = float(p["deposit"]), float(p["leverage"]), float(p["reinvest"]) / 100
    eq = dep0; pos = None; trades = []; liq = None; mpu = (0.0, None); fees_total = 0.0; bars_in = 0
    n = len(c); step = max(n // 20, 1)
    prog(60, "симуляция…")
    for i in range(300, n):
        if i % step == 0:
            prog(60 + 35 * i / n, f"симуляция {pd.to_datetime(t[i], unit='ms'):%Y-%m-%d}")
        if pos is None:
            if not entry[i] or eq <= 1:
                continue
            dep = min(dep0 + reinv * max(eq - dep0, 0), eq)
            b = c[i]; px = b * (1 + SLIP); u = dep * lev * grid[0][1] / vsum
            pos = {"i": i, "q": u / px, "cost": u, "fee": u * FEE, "f": 1, "b": b, "mpu": 0.0, "dep": dep,
                   "tp": 0, "q0": 0.0, "real": 0.0, "be": False,
                   "fills": [{"t": int(t[i]), "px": float(px), "usd": round(u, 2), "n": 1}]}
            continue
        bars_in += 1
        while not pos["be"] and pos["f"] < len(grid) and c[i] <= pos["b"] * lvl[pos["f"]] and okf[min(pos["f"], 3)][i]:
            u = pos["dep"] * lev * grid[pos["f"]][1] / vsum
            pos["q"] += u / c[i]; pos["cost"] += u; pos["fee"] += u * FEE; pos["f"] += 1
            pos["fills"].append({"t": int(t[i]), "px": float(c[i]), "usd": round(u, 2), "n": pos["f"]})
        avg = pos["cost"] / pos["q"]
        un = pos["real"] + pos["q"] * (lo[i] - avg) - pos["fee"]
        pos["mpu"] = min(pos["mpu"], un)
        if un < mpu[0]:
            mpu = (un, int(t[i]))
        why = None
        if un <= -eq:
            why, ex = "ликвидация", float(lo[i])
        elif esl and c[i] <= avg * (1 - esl / 100):
            why, ex = "стоп", float(c[i]) * (1 - SLIP)
        elif pos["be"] and lo[i] <= avg:
            why, ex = "безубыток", avg * (1 - SLIP)
        else:
            while pos["tp"] < len(tps) and hi[i] >= avg * (1 + tps[pos["tp"]][0] / 100):
                tpx = avg * (1 + tps[pos["tp"]][0] / 100)
                if not pos["tp"]:
                    pos["q0"] = pos["q"]                    # объём позиции на момент первого тейка
                qq = min(pos["q0"] * tps[pos["tp"]][1] / tsum, pos["q"])
                pos["fee"] += qq * tpx * 0.0002            # тейки — лимитки (maker)
                pos["real"] += qq * (tpx - avg)
                pos["q"] -= qq; pos["cost"] -= qq * avg; pos["tp"] += 1; pos["be"] = True
            if pos["q"] <= 1e-12 or pos["tp"] >= len(tps):
                why, ex = "тейки", avg * (1 + tps[-1][0] / 100)
        if why:
            q = pos["q"]
            fee_out = q * ex * FEE if q > 0 else 0.0
            net = pos["real"] + q * (ex - avg) - pos["fee"] - fee_out
            if why == "ликвидация":
                net = -eq; liq = int(t[i])
            fees_total += pos["fee"] + fee_out
            eq += net
            tr = _trade({**pos, "q": 1.0, "cost": float(avg)}, "LONG", int(t[i]), ex, net, why, eq)
            tr["volume"] = round(sum(f["usd"] for f in pos["fills"]), 2); tr["avg"] = float(avg)
            tr["pnl_pct"] = round(net / max(tr["volume"], 1e-9) * 100, 3); tr["tps"] = pos["tp"]
            trades.append(tr)
            pos = None
            if liq or eq <= 1:
                break
    open_pos = None
    if pos:
        avg = pos["cost"] / pos["q"] if pos["q"] > 0 else c[-1]
        open_pos = {"open_t": int(t[pos["i"]]), "orders": pos["f"], "avg": avg,
                    "unreal": pos["real"] + pos["q"] * (c[-1] - avg) - pos["fee"], "fills": pos["fills"]}
    return trades, eq, liq, mpu, fees_total, bars_in, open_pos


# ---------- Лента EMA (скальп): быстрая группа 2..15 × медленная 44..74, откаты к ленте ----------
def sim_ribbon(df1, p, prog):
    """Исправленная версия статьи «Скальпинговая стратегия с EMA».
    Вход LONG: средняя быстрых EMA (2..15) пересекла снизу вверх среднюю медленных (44..74);
    повторный вход: лента вверх, low коснулся средних EMA (17..41), свеча закрылась выше быстрой группы.
    SHORT — зеркально. Выход: тейк/стоп в ATR(14) сигнального ТФ (в статье тейк ≈ полстопа),
    для повторных входов тейк меньше. Входы по закрытию свечи, комиссия + проскальзывание."""
    tf = p.get("tf", "5m")
    d = (df1 if tf == "1m" else _tf_frame(df1, tf)).reset_index(drop=True)
    c, h, l, t = d.close.to_numpy(), d.high.to_numpy(), d.low.to_numpy(), d.t.to_numpy()
    prog(40, "лента EMA…")
    ema = lambda n: d.close.ewm(span=n, adjust=False).mean().to_numpy()  # noqa: E731
    fast = np.mean([ema(n) for n in range(2, 16)], axis=0)
    mid = np.mean([ema(n) for n in range(17, 42, 2)], axis=0)
    slow = np.mean([ema(n) for n in (44, 47, 50, 53, 56, 59, 62, 65, 68, 71, 74)], axis=0)
    atr = V.rma(V.tr(d), 14).to_numpy()
    tp_m, sl_m = float(p.get("min_pnl") or 1.0), float(p.get("sl") or 2.0)   # в ATR
    tp_re = tp_m * 0.6
    only = p.get("side_only")                   # None | 1 | -1
    cost = 2 * (FEE + 0.0002) * 100
    rows = []; pos = None
    prog(60, "симуляция…")
    for i in range(80, len(c)):
        if pos:
            s, e, tp, sl = pos["side"], pos["px"], pos["tp"], pos["sl"]
            hit_sl = (l[i] <= sl) if s > 0 else (h[i] >= sl)
            hit_tp = (h[i] >= tp) if s > 0 else (l[i] <= tp)
            if hit_sl or hit_tp:
                ex = sl if hit_sl else tp                 # обе в одной свече — считаем стоп (пессимистично)
                rows.append({"side": s, "t_in": pos["t"], "t_out": int(t[i]), "px_in": e, "px_out": float(ex),
                             "pct": s * (ex / e - 1) * 100 - cost, "why": "стоп" if hit_sl else ("тейк" if not pos["re"] else "тейк отката")})
                pos = None
            continue
        up_x = fast[i - 1] <= slow[i - 1] and fast[i] > slow[i]
        dn_x = fast[i - 1] >= slow[i - 1] and fast[i] < slow[i]
        up_tr = fast[i] > mid[i] > slow[i]; dn_tr = fast[i] < mid[i] < slow[i]
        re_up = up_tr and l[i] <= mid[i] and c[i] > fast[i]
        re_dn = dn_tr and h[i] >= mid[i] and c[i] < fast[i]
        side = 1 if (up_x or re_up) else (-1 if (dn_x or re_dn) else 0)
        if not side or (only and side != only) or not atr[i] > 0:
            continue
        re = not (up_x or dn_x)
        k = tp_re if re else tp_m
        e = float(c[i])
        pos = {"side": side, "px": e, "t": int(t[i]), "re": re,
               "tp": e + side * k * atr[i], "sl": e - side * sl_m * atr[i]}
    prog(90, "считаю счёт…")
    return deals_to_trades(rows, d, p)


def sim_combo(df1, p, prog):
    import lab_builder as LB
    d = _tf_frame(df1, p["tf"]).reset_index(drop=True)
    uses_engine = p["spec"]["trigger"][:1] in "⚙🧠" or any(f[:1] in "⚙🧠" for f in p["spec"].get("filters", []))
    eng, names = LB.engine_signals(d, p["symbol"], p["tf"], lambda t: prog(50, t)) if uses_engine else (None, [])
    prog(60, "сделки собранной стратегии…")
    return deals_to_trades(LB.run_spec(d, p["spec"], eng, names), df1, p)


def run_build(df1, p, prog):
    import lab_builder as LB
    frames, engines = {}, {}
    tfs = ("5m",) if p.get("scalp") else ("4h", "1h", "15m")
    if not p.get("scalp") and p.get("tf") in tfs:  # 2026-10-10: ищем только на выбранном «ТФ стратегии»
        tfs = (p["tf"],)
    for k, tf in enumerate(tfs):
        frames[tf] = _tf_frame(df1, tf).reset_index(drop=True)
        engines[tf] = LB.engine_signals(frames[tf], p["symbol"], tf, lambda t, k=k: prog(5 + 10 * k, t))
    cost = LB.COST_MAKER if p.get("fees") == "maker" else LB.COST
    rows = LB.search(frames, lambda f, txt: prog(40 + 58 * f, txt), engines=engines, cost=cost)
    return _honest_verdicts(rows, p, prog)


def _honest_verdicts(rows, p, prog, max_check=12, n_coins=9):
    """2026-10-10: честный вердикт. Отложенные 25% истории (подбор их не видел) + та же сборка на других монетах.
    ✅ — в плюсе на отложенной истории И на ≥70% других монет; иначе ❌/⚠️. Сортировка: ✅ сверху."""
    import numpy as np
    import candle_store as CS
    import lab_builder as LB
    sym = str(p.get("symbol", "")).upper().replace("USDT", "")
    start_ms = int(pd.Timestamp(p["start"], tz="UTC").timestamp() * 1000) if p.get("start") else None
    end_ms = int(pd.Timestamp(p["end"], tz="UTC").timestamp() * 1000) + 86_400_000 if p.get("end") else None
    others, cache = [c for c in POOL_COINS if c != sym][:n_coins], {}

    def frame(coin, tf):
        if (coin, tf) not in cache:
            try:
                df = CS.load(coin)
                if df is not None:
                    if start_ms: df = df[df.t >= start_ms]
                    if end_ms: df = df[df.t < end_ms]
                    df = df.reset_index(drop=True)
                cache[(coin, tf)] = _tf_frame(df, tf).reset_index(drop=True) if df is not None and len(df) > 60 * 24 * 60 else None
            except Exception:  # noqa: BLE001
                cache[(coin, tf)] = None
        return cache[(coin, tf)]

    checked = 0
    for r in rows:
        r["verdict"], r["verdict_note"] = LB.verdict(r.get("pf_hold", 0.0), r.get("n_hold", 0))
        if not r["verdict"].startswith("✅") or checked >= max_check:
            continue
        checked += 1
        prog(98, f"проверка сборки на других монетах ({checked}/{max_check})…")
        spec = {k: r[k] for k in ("trigger", "filters", "side", "sl", "tp", "hold", "cost", "tf")}
        ok = n = 0
        for coin in others:
            d = frame(coin, r["tf"])
            if d is None:
                continue
            try:
                tr = LB.run_spec(d, spec)
            except Exception:  # noqa: BLE001 -- индикатор ⚙/🧠 на этой монете недоступен
                continue
            if len(tr) < 5:
                continue
            x = np.array([t["pct"] for t in tr])
            n += 1; ok += int(x[x > 0].sum() > -x[x < 0].sum())
        share = ok / n if n else None
        r["coins_check"] = f"{ok}/{n}" if n else "—"
        r["verdict"], r["verdict_note"] = LB.verdict(r["pf_hold"], r["n_hold"], share if n >= 3 else None)
    rank = {"✅": 0, "⚠": 1, "❌": 2}
    rows.sort(key=lambda x: (rank.get(x.get("verdict", "❌")[:1], 2), -x.get("score", 0)))
    return rows


POOL_COINS = ["BTC", "ETH", "SOL", "XRP", "DOGE", "ADA", "LINK", "AVAX", "SUI", "HYPE", "BNB", "LTC",
              "DOT", "NEAR", "APT", "ARB", "OP", "TIA", "INJ", "AAVE", "ENA", "1000PEPE", "WIF", "ONDO", "TAO"]


def run_build_pool(p, prog):
    """Портфельный автоподбор: одна сборка ищется сразу на ~20–25 ликвидных монетах."""
    import candle_store as CS
    import lab_builder as LB
    coins = [c.upper() for c in (p.get("coins") or [])] or POOL_COINS
    start_ms = int(pd.Timestamp(p["start"], tz="UTC").timestamp() * 1000)
    end_ms = int(pd.Timestamp(p["end"], tz="UTC").timestamp() * 1000) + 86_400_000 if p.get("end") else None
    tfs = ("1h", "15m")
    frames, engines, used = {}, {}, []
    for k, sym in enumerate(coins):
        prog(1 + 20 * k / len(coins), f"{sym}: свечи и 34 индикатора ({k + 1}/{len(coins)})")
        try:
            df = CS.load(sym)
            if df is None:
                continue
            df = df[df.t >= start_ms]
            if end_ms:
                df = df[df.t < end_ms]
            df = df.reset_index(drop=True)
            if len(df) < 60 * 24 * 90:                       # меньше 3 месяцев — не берём
                continue
            frames[sym], engines[sym] = {}, {}
            for tf in tfs:
                d = _tf_frame(df, tf).reset_index(drop=True)
                frames[sym][tf] = d
                try:
                    engines[sym][tf] = LB.engine_signals(d, sym, tf)
                except Exception:  # noqa: BLE001 -- без 34 индикаторов ищем на классических
                    engines[sym][tf] = (None, [])
            used.append(sym)
        except Exception:  # noqa: BLE001
            continue
    if len(used) < 5:
        raise RuntimeError(f"на складе мало монет для портфеля ({len(used)}). Скачай: download_all_candles.bat")
    cost = LB.COST_MAKER if p.get("fees") == "maker" else LB.COST
    rows = LB.search_pooled(frames, lambda f, t: prog(21 + 77 * f, t), engines=engines, cost=cost,
                            min_month=float(p.get("min_month") or 20))
    for r in rows:   # 2026-10-10: вердикт по отложенным 25% истории всех монет портфеля
        r["verdict"], r["verdict_note"] = LB.verdict(r.get("pf_hold", 0.0), r.get("n_hold", 0), r.get("hold_coins_share"))
    rank = {"✅": 0, "⚠": 1, "❌": 2}
    rows.sort(key=lambda x: (rank.get(x["verdict"][:1], 2), -x.get("score", 0)))
    return rows, used


def run_multi(p, prog):
    """Одна собранная стратегия на всех монетах склада (x1, без реинвеста)."""
    import candle_store as CS
    coins = [c.upper() for c in (p.get("coins") or [])] or sorted(
        {f.stem.upper() for f in CS.DIR.glob("*") if f.suffix in (".parquet", ".pkl")})
    start_ms = int(pd.Timestamp(p["start"], tz="UTC").timestamp() * 1000)
    end_ms = int(pd.Timestamp(p["end"], tz="UTC").timestamp() * 1000) + 86_400_000 if p.get("end") else None
    rows = []
    lim = 60 if (p.get("inner") or "combo") != "combo" else 30
    for k, sym in enumerate(coins[:lim]):
        prog(5 + 90 * k / max(len(coins), 1), f"{sym}: {k + 1}/{len(coins)} " + (" (новая монета — сначала 34 индикатора, пару минут)" if (p.get("inner") or "combo") == "combo" else ""))
        try:
            df = CS.load(sym)
            if df is None:
                raise RuntimeError("нет свечей на складе")
            df = df[df.t >= start_ms]
            if end_ms:
                df = df[df.t < end_ms]
            df = df.reset_index(drop=True)
            if len(df) < 20000:
                raise RuntimeError("мало истории")
            inner = p.get("inner") or "combo"
            q = {**p, "symbol": sym, "strategy": inner, "leverage": 1 if inner == "combo" else p["leverage"],
                 "reinvest": 0, "deposit": 100.0}
            tr, eq, liq, mpu, *_ = pick(inner)(df, q, lambda *_a: None)
            mid = int(df.t.iloc[len(df) // 2])
            a = [x for x in tr if x["open_t"] < mid]; b = [x for x in tr if x["open_t"] >= mid]
            rows.append({"symbol": sym, "trades": len(tr), "roi": round(eq - 100, 1), "pf": _pf(tr), "pf1": _pf(a),
                         "pf2": _pf(b), "mpu": round(mpu[0], 1), "liq": liq,
                         "win": round(sum(x["net"] > 0 for x in tr) / len(tr) * 100, 1) if tr else 0})
        except Exception as exc:  # noqa: BLE001
            rows.append({"symbol": sym, "error": str(exc)[:120]})
    return rows



# ---------- 2026-10-18: OKX (свечи 1h с биржи OKX, комиссия taker 0.05%) ----------
FEES = {"bybit": 0.00055, "okx": 0.0005}


def load_okx_1h(symbol: str, start_ms: int, prog) -> pd.DataFrame:
    """Часовые свечи OKX SWAP (только закрытые), кеш market_cache/okx_<SYM>_1H.pkl, докачка только нового."""
    import requests
    CACHE.mkdir(exist_ok=True)
    path = CACHE / f"okx_{symbol}_1H.pkl"
    inst = f"{symbol}-USDT-SWAP"
    old = pd.read_pickle(path) if path.exists() else pd.DataFrame(columns=["t", "open", "high", "low", "close", "volume"])

    def pull(after=None, stop_ms=None):
        rows, k = [], 0
        while True:
            q = {"instId": inst, "bar": "1H", "limit": 100}
            if after:
                q["after"] = after
            j = None
            for tr in range(5):
                try:
                    j = requests.get("https://www.okx.com/api/v5/market/history-candles", params=q, timeout=20).json()
                    if j.get("code") == "0":
                        break
                except requests.RequestException:
                    pass
                time.sleep(1.5 * (tr + 1))
            lst = (j or {}).get("data") or []
            if not lst:
                break
            rows += [r for r in lst if len(r) < 9 or r[8] == "1"]
            after = lst[-1][0]
            k += 1
            if k % 20 == 0:
                prog(10, f"OKX {symbol} 1h: {pd.to_datetime(int(after), unit='ms'):%Y-%m-%d}")
            if int(after) <= (stop_ms or 0) or len(lst) < 100:
                break
            time.sleep(0.11)
        return rows

    have_new = int(old.t.max()) if len(old) else 0
    have_old = int(old.t.min()) if len(old) else None
    rows = pull(stop_ms=have_new or start_ms)                      # новое (и всё, если кеша нет)
    if have_old is not None and have_old > start_ms + 3_600_000:
        rows += pull(after=str(have_old), stop_ms=start_ms)        # история раньше кеша
    if rows:
        a = pd.DataFrame([[int(r[0])] + [float(x) for x in r[1:6]] for r in rows],
                         columns=["t", "open", "high", "low", "close", "volume"])
        old = pd.concat([old, a]).drop_duplicates("t").sort_values("t").reset_index(drop=True)
        old["t"] = old["t"].astype("int64")
        old.to_pickle(path)
    if not len(old):
        raise RuntimeError(f"OKX не отдал свечи {inst}")
    return old[old.t >= start_ms].reset_index(drop=True)


def _hourly(df1, p, sym, prog):
    """Часовые свечи монеты (индекс — время) с выбранной биржи."""
    if p.get("exchange") == "okx" and sym != p["symbol"]:
        d = load_okx_1h(sym, int(df1.t.iloc[0]), prog)
    elif sym != p["symbol"]:
        d = load_1m(sym, int(df1.t.iloc[0]), prog)
    else:
        d = df1
    d = resample(d[(d.t >= df1.t.iloc[0]) & (d.t <= df1.t.iloc[-1])], "1h")
    d.index = pd.to_datetime(d.t, unit="ms")
    return d[["open", "high", "low", "close", "volume"]]


COMBO_CSV = {"combo_live": "combo_sub2.csv"}


def sim_combo_live(df1, p, prog):
    """Combo OTM — ровно та сборка, которой торгует бот combo_xrp (combo_full.py + combo_sub2.csv, 1h, BTC как опорная)."""
    import combo_full as cf
    cfg = cf.load_settings_csv(str(BASE / COMBO_CSV[p["strategy"]]))[0]
    prog(30, "часовые свечи монеты и BTC…")
    d = _hourly(df1, p, p["symbol"], prog)
    try:
        ref = _hourly(df1, p, "BTC", prog)
    except Exception:  # noqa: BLE001
        ref = None
    prog(60, "Combo OTM: 23 фильтра…")
    tr, _dd, _eq, _st = cf.run(d, cfg, ref, initial_capital=500.0, commission_pct=FEE * 100)
    rows = []
    for r in (tr.to_dict("records") if hasattr(tr, "to_dict") else tr):
        side = 1 if r["side"] == "long" else -1
        rows.append({"side": side, "t_in": _ms(r["entry_time"]), "t_out": _ms(r["exit_time"]),
                     "px_in": float(r["entry"]), "px_out": float(r["exit"]), "pct": float(r["ret_pct"]),
                     "why": str(r.get("reason") or "выход")})
    prog(90, "считаю счёт…")
    return deals_to_trades(rows, df1, p)


def _combo_info(p):
    import combo_full as cf
    c = cf.load_settings_csv(str(BASE / COMBO_CSV[p["strategy"]]))[0]
    g = lambda k, d="—": c.get(k, d)  # noqa: E731

    def side(L, name):
        sl = (f"ATR({g(L+'AtrLength')})×{g(L+'AtrMultiplier')}, не больше {g(L+'AtrMaxStopPercent')}%"
              if "ATR" in str(g(L + "StopLossMode")) else f"{g(L+'FixedStopLossPercent', g(L+'FixedStopPercent'))}%")
        tp = g(L + "TakeProfit2Mode")
        tpv = f"{g(L+'TakeProfit2Percent')}%" if "Fixed" in str(tp) else f"ATR×{g(L+'TakeProfit2AtrMultiplier')}"
        return f"{name}: стоп {sl}; тейк {tpv}"
    on = sorted(k for k, v in c.items() if isinstance(v, bool) and v and (k.startswith("use") or k.endswith("Active")))
    return {
        "title": "Combo OTM XRP — боевая сборка подписчика №2 (combo_sub2.csv)",
        "rules": [
            "Вход: сигнал на закрытии часовой свечи → рыночный ордер по открытию следующей; лонг и шорт.",
            "Сигнал = пивот-разворот (пивоты 1/3) + все включённые фильтры ниже (Trend Catcher, MFI, ADX, CVD, RSI, NATR, BTC и др.).",
            side("long", "Лонг"), side("short", "Шорт"),
            f"Структура тейков: {g('takeProfitStructure')}. Пауза после убытка: лонг {g('cooldownBarsAfterLossLong')} св., шорт {g('cooldownBarsAfterLossShort')} св.",
            "В боте на OKX: маржа 50% депозита × плечо, стоп и тейк стоят на бирже сразу при входе, kill-switch по своим сделкам.",
        ],
        "params": [[k, str(c[k])] for k in on][:40],
    }


INFO = {
    "dca": ["LONG-сетка DOGE: вход по фильтрам Veles (RSI/CCI/ADX), доборы по сетке ниже, тейк от средней (мин. PnL), стоп — если задан."],
    "tao_bb": ["1m: вход при выходе цены за нижнюю MRC/BB с разворотом ROC, тейк — мин. PnL, стоп от входа."],
    "flush": ["1m: откуп пролива ниже Кельтнера при развороте WaveTrend, добор по сетке, тейк от средней, стоп от средней."],
    "mdca": ["1m: вход у нижней MRC при ATR% и развороте MACD, доборы, тейки частями (лимитки), аварийный стоп."],
    "ribbon": ["Лента EMA: пересечение быстрых (2–15) и медленных (44–74) EMA, стоп и тейк в ATR."],
    "kc_roc": ["1m сетка: Кельтнер + ROC + CCI + WaveTrend, 2 ордера, тейк мин. PnL, стоп от средней."],
    "eth_rsi": ["4h: RSI-тренд-фильтр, лонг и шорт, стоп 2 ATR, выход по обратному сигналу."],
    "combo": ["Собранная автоподбором: триггер + до 3 фильтров, стоп/тейк в ATR, макс. удержание."],
}


def strategy_info(p):
    try:
        if p["strategy"] in COMBO_CSV:
            info = _combo_info(p)
        else:
            st = p["strategy"]
            rules = ([HONEST[st][0], "Прошла перепроверку 29.10: плюс за всю историю, в обеих половинах, за 180 и 90 дней, на большинстве из 12 монет."]
                     if st in HONEST else None) or INFO.get(st) or ([f"Родной код стратегии «{st.split(':', 1)[1]}» с настройками по умолчанию автора."]
                                     if ":" in st else [])
            if st == "paper:Combo OTM":
                rules = rules + ["⚠ Это исходный Combo OTM с настройками по умолчанию — НЕ боевая сборка бота combo_xrp."]
            if st == "combo" and p.get("spec"):
                sp = p["spec"]
                rules = rules + [f"{'LONG' if sp['side'] > 0 else 'SHORT'} · {sp['trigger']} + {', '.join(sp['filters']) or 'без фильтров'} · "
                                 f"стоп {sp['sl']} ATR · тейк {sp['tp']} ATR · удержание до {sp['hold']} св."]
            info = {"title": st, "rules": rules, "params": []}
        common = [["Биржа", "OKX (1h)" if p.get("exchange") == "okx" else "Bybit (минутки)"],
                  ["Комиссия", f"{FEE * 100:.3f}% за сторону"], ["ТФ стратегии", p.get("tf")],
                  ["Депозит", p.get("deposit")], ["Плечо", p.get("leverage")], ["Реинвест, %", p.get("reinvest")]]
        if p.get("sl"):
            common.append(["Стоп", p["sl"]])
        if p["strategy"] in ("dca", "tao_bb", "flush", "kc_roc", "ribbon") and p.get("min_pnl"):
            common.append(["Мин. PnL / тейк", p["min_pnl"]])
        if p["strategy"] in ("dca", "flush", "mdca", "kc_roc") and p.get("grid"):
            common.append(["Сетка (отступ %, объём %)", "; ".join(f"{a}/{b}" for a, b in p["grid"])])
        info["params"] = common + info["params"]
        return info
    except Exception as exc:  # noqa: BLE001
        return {"title": p.get("strategy"), "rules": [f"описание недоступно: {exc}"], "params": []}

# ---------- 2026-10-31: стратегии, прошедшие перепроверку 29.10 (strat_batch6, recheck_recent) ----------
HONEST = {
    "honest:turtle_4h": ("Черепахи: вход пробой 40, выход обратный пробой 30, стоп 2 ATR, без тейка", "4h"),
    "honest:turtle_2h": ("Черепахи: вход пробой 55, выход обратный пробой 30, стоп 2 ATR, без тейка", "2h"),
    "honest:chan": ("Пробой канала регрессии 100 ±2σ, стоп центр канала, тейк 2R, до 100 свечей", "2h"),
    "honest:donch": ("Donchian 20 по тренду EMA200, стоп середина канала, тейк 3R, до 300 свечей", "4h"),
    "honest:bos4h": ("BOS структура: свинги 20/20, вход по тренду EMA50/200 BTC-стиля (своей монеты), ATR растёт, стоп 2 ATR ≤4.5%, выход обратный BOS", "4h"),
    "honest:bos1h": ("BOS структура 1h: как 4h, стоп 2 ATR, выход обратный BOS", "1h"),
    "honest:atrfib": ("ATR Fib: RMA100 ± 3×ATR100, только лонг, стоп 2.6 ATR, выход обратная смена тренда", "4h"),
    "honest:bosrt": ("BOS ретест: после BOS ждём ретест пробитого уровня 20 свечей, стоп 2 ATR, выход обратный BOS", "4h"),
    "honest:ut": ("UT Bot как в боте: линия ATR-трейла, вход на пересечении по EMA50, стоп за линией UT, выход обратный сигнал UT", "4h"),
    "honest:ha18": ("Хейкен-Аши старшего ТФ ×18, переворот (всегда в рынке, стопа нет)", "2h"),
}


def sim_honest(df1, p, prog):
    import recheck_recent as RR  # noqa: PLC0415
    st = p["strategy"]
    prog(50, f"{HONEST[st][0]} на {p['tf']}…")
    d0 = _tf_frame(df1, p["tf"]).reset_index(drop=True)
    d = pd.DataFrame({"t": d0.t.values, "o": d0.open.values, "h": d0.high.values, "l": d0.low.values, "c": d0.close.values})
    h, l, c, t = d.h.values, d.l.values, d.c.values, d.t.values
    pc = np.r_[c[0], c[:-1]]
    atr = pd.Series(np.maximum(h - l, np.maximum(abs(h - pc), abs(l - pc)))).ewm(alpha=1 / 14, adjust=False).mean().values
    rows = []

    def add(i, j, side, px_out, why):
        # 2026-11-08 (ChatGPT ТЗ): + проскальзывание 0.02% на вход и выход + funding ~0.01% за каждые 8 ч в позиции (как издержка)
        pct = side * (px_out / c[i] - 1) * 100 - FEE * 2 * 100 - 0.04 - 0.01 * max(0, (int(t[j]) - int(t[i])) / 28_800_000)
        rows.append({"side": side, "t_in": int(t[i]), "t_out": int(t[j]), "px_in": float(c[i]), "px_out": float(px_out),
                     "pct": float(pct), "why": why})
    if st.startswith("honest:turtle"):
        N, M = (40, 30) if st.endswith("4h") else (55, 30)
        hhN = d.h.rolling(N).max().shift(1).values; llN = d.l.rolling(N).min().shift(1).values
        hhM = d.h.rolling(M).max().shift(1).values; llM = d.l.rolling(M).min().shift(1).values
        i = 210
        while i < len(c) - 1:
            s = 1 if c[i] > hhN[i] else -1 if c[i] < llN[i] else 0
            if not s or not atr[i] > 0:
                i += 1; continue
            stp = c[i] - s * 2 * atr[i]; out = None
            for j in range(i + 1, min(len(c), i + 400)):
                if (l[j] <= stp) if s > 0 else (h[j] >= stp):
                    out = (j, stp, "стоп"); break
                if (c[j] < llM[j]) if s > 0 else (c[j] > hhM[j]):
                    out = (j, c[j], "обратный пробой"); break
            if out is None:
                j = min(len(c) - 1, i + 400); out = (j, c[j], "по времени")
            add(i, out[0], s, out[1], out[2]); i = out[0] + 1
    elif st in ("honest:bos4h", "honest:bos1h", "honest:atrfib", "honest:bosrt"):
        from windows_app import afbos_paper as AB  # noqa: PLC0415
        H, Lw, Cc = h.tolist(), l.tolist(), c.tolist()
        bs = AB.bos_signals(H, Lw, Cc)
        ent = {"honest:atrfib": [x if x > 0 else 0 for x in AB.af_signals(H, Lw, Cc)],
               "honest:bosrt": AB.bos_retest_signals(H, Lw, Cc)}.get(st, bs)
        ext = AB.af_signals(H, Lw, Cc) if st == "honest:atrfib" else bs
        mult = 2.6 if st == "honest:atrfib" else 2.0
        e50 = pd.Series(c).ewm(span=50, adjust=False).mean().values; e200 = pd.Series(c).ewm(span=200, adjust=False).mean().values
        lb = 80 if st == "honest:bos1h" else 20
        i = 250
        while i < len(c) - 1:
            s = ent[i]; tr = 1 if e50[i] > e200[i] else -1
            if not s or s != tr or not atr[i] > atr[i - lb] or (st != "honest:atrfib" and mult * atr[i] > c[i] * 0.045):
                i += 1; continue
            stp = c[i] - s * mult * atr[i]; out = None
            for j in range(i + 1, len(c)):
                if (l[j] <= stp) if s > 0 else (h[j] >= stp):
                    out = (j, stp, "стоп"); break
                if ext[j] == -s:
                    out = (j, c[j], "обратный сигнал"); break
            if out is None:
                out = (len(c) - 1, c[-1], "открыта")
            add(i, out[0], s, out[1], out[2]); i = out[0] + 1
    elif st == "honest:ut":
        from windows_app import ut_paper as UT  # noqa: PLC0415
        H, Lw, Cc = h.tolist(), l.tolist(), c.tolist()
        ut = UT.ut_line(H, Lw, Cc); e50 = UT._ema(Cc, UT.N_EMA); i = 60
        sg = [0] + [1 if c[k] > ut[k] and c[k - 1] <= ut[k - 1] else -1 if c[k] < ut[k] and c[k - 1] >= ut[k - 1] else 0 for k in range(1, len(c))]
        while i < len(c) - 1:
            s = sg[i]
            if not s or not ((s > 0 and c[i] > e50[i]) or (s < 0 and c[i] < e50[i])) or abs(c[i] - ut[i]) <= c[i] * 0.0005:
                i += 1; continue
            stp = ut[i]; out = None
            for j in range(i + 1, len(c)):
                if (l[j] <= stp) if s > 0 else (h[j] >= stp):
                    out = (j, stp, "стоп"); break
                if sg[j] == -s:
                    out = (j, c[j], "обратный сигнал UT"); break
            if out is None:
                out = (len(c) - 1, c[-1], "открыта")
            add(i, out[0], s, out[1], out[2]); i = out[0] + 1
    elif st == "honest:ha18":
        import levando_test as L  # noqa: PLC0415
        ms = int(pd.Series(t).diff().median())
        (_a, _b), (ho, hc) = L.ha_htf(d, ms)
        up, dn = L.sig(ho, hc); pos = 0; i0 = None
        for i in range(len(c)):
            s = 1 if up[i] else -1 if dn[i] else 0
            if s and s != pos:
                if pos:
                    add(i0, i, pos, c[i], "переворот")
                pos, i0 = s, i
    else:
        sigs = []
        if st == "honest:chan":
            mid, sd = RR.rolling_reg(c); up_, lo_ = mid + 2 * sd, mid - 2 * sd; rr, hold = 2.0, 100
            for i in range(101, len(c)):
                if c[i] > up_[i] and c[i - 1] <= up_[i - 1]:
                    sigs.append((i, 1, mid[i]))
                elif c[i] < lo_[i] and c[i - 1] >= lo_[i - 1]:
                    sigs.append((i, -1, mid[i]))
        else:
            e = pd.Series(c).ewm(span=200, adjust=False).mean().values
            hh = d.h.rolling(20).max().shift(1).values; ll = d.l.rolling(20).min().shift(1).values; rr, hold = 3.0, 300
            for i in range(201, len(c)):
                if c[i] > hh[i] and c[i] > e[i]:
                    sigs.append((i, 1, (hh[i] + ll[i]) / 2))
                elif c[i] < ll[i] and c[i] < e[i]:
                    sigs.append((i, -1, (hh[i] + ll[i]) / 2))
        nxt = 0
        for i, s, stp in sigs:
            if i < nxt or i >= len(c) - 1 or abs(c[i] - stp) <= 0:
                continue
            risk = abs(c[i] - stp); tp = c[i] + s * rr * risk; out = None
            for j in range(i + 1, min(len(c), i + hold + 1)):
                if (l[j] <= stp) if s > 0 else (h[j] >= stp):
                    out = (j, stp, "стоп"); break
                if (h[j] >= tp) if s > 0 else (l[j] <= tp):
                    out = (j, tp, "тейк"); break
            if out is None:
                j = min(len(c) - 1, i + hold); out = (j, c[j], "по времени")
            add(i, out[0], s, out[1], out[2]); nxt = out[0] + 1
    prog(90, "считаю счёт…")
    return deals_to_trades(rows, df1, p)


def pick(strategy):
    if strategy.startswith("honest:"): return sim_honest
    if strategy == "combo": return sim_combo
    if strategy in COMBO_CSV: return sim_combo_live
    if strategy == "dca": return sim_dca
    if strategy == "flush": return sim_flush
    if strategy == "ribbon": return sim_ribbon
    if strategy == "mdca": return sim_mdca
    if strategy == "eth_rsi": return sim_eth_rsi
    if strategy == "tao_bb": return sim_tao
    if strategy == "kc_roc": return sim_kcroc
    if strategy.startswith("bt:"): return sim_bt
    if strategy.startswith("paper:"): return sim_paper
    raise RuntimeError(f"неизвестная стратегия {strategy}")


# ---------- статистика ----------
def stats(trades, eq, liq, mpu, fees, bars_in, df, p, view_bars):
    dep0 = float(p["deposit"])
    tr = pd.DataFrame(trades)
    days = (df.t.iloc[-1] - df.t.iloc[0]) / 86_400_000
    s = {"deposit": dep0, "final": round(eq, 2), "profit": round(eq - dep0, 2), "roi": round((eq / dep0 - 1) * 100, 2),
         "fees": round(fees, 2), "trades": len(tr), "liquidation": liq,
         "mpu_usdt": round(mpu[0], 2), "mpu_pct": round(mpu[0] / dep0 * 100, 2), "mpu_t": mpu[1],
         "bars": len(df), "days": round(days, 1),
         "buyhold_pct": round((df.close.iloc[-1] / df.close.iloc[0] - 1) * 100, 2),
         "per_day": round((eq - dep0) / max(days, 1), 3)}
    if len(tr):
        wins, losses = tr[tr.net > 0], tr[tr.net <= 0]
        dur = (tr.close_t - tr.open_t) / 1000
        s.update({
            "wins": len(wins), "losses": len(losses), "winrate": round(len(wins) / len(tr) * 100, 2),
            "pf": round(wins.net.sum() / -losses.net.sum(), 2) if len(losses) and losses.net.sum() < 0 else None,
            "avg_trade": round(tr.net.mean(), 3), "max_trade": round(tr.net.max(), 3), "min_trade": round(tr.net.min(), 3),
            "volume": round(tr.volume.sum(), 2),
            "avg_time_s": int(dur.mean()), "max_time_s": int(dur.max()), "min_time_s": int(dur.min()),
            "in_market_pct": round(dur.sum() / max(days * 86400, 1) * 100, 1),
            "orders_hist": {str(k): int(v) for k, v in tr.orders.value_counts().sort_index().items()},
            "by_year": [{"year": int(y), "trades": len(g), "profit": round(g.net.sum(), 2), "eq_end": round(g["eq"].iloc[-1], 2)}
                        for y, g in tr.groupby(pd.to_datetime(tr.close_t, unit="ms").dt.year)],
            "stops": int((tr.why == "стоп").sum()),
        })
        peak = dep0; dd = 0.0
        for e in tr["eq"]:
            peak = max(peak, e); dd = max(dd, (peak - e) / peak * 100)
        s["closed_dd_pct"] = round(dd, 2)
        # 2026-09-28: стабильность по 6 равным периодам (упрощённый walk-forward: правила не
        # переподбираются, проверяется, что сборка зарабатывает в разных режимах рынка, а не в одном)
        t0, t1 = int(df.t.iloc[0]), int(df.t.iloc[-1])
        edges = [t0 + (t1 - t0) * k // 6 for k in range(7)]
        wf = []
        for k in range(6):
            g = tr[(tr.close_t >= edges[k]) & (tr.close_t < edges[k + 1] + (1 if k == 5 else 0))]
            w_, l_ = g[g.net > 0].net.sum(), -g[g.net <= 0].net.sum()
            wf.append({"from": edges[k], "to": edges[k + 1], "trades": int(len(g)), "profit": round(float(g.net.sum()), 2),
                       "pf": (round(float(w_ / l_), 2) if l_ > 0 else (99.0 if w_ > 0 else None))})
        s["wf"] = wf
        s["wf_ok"] = sum(1 for x in wf if x["trades"] >= 3 and (x["pf"] or 0) > 1)
        s["calmar"] = round(s["roi"] / max(dd, abs(s["mpu_pct"]), 1e-9), 2)
    return s


# ---------- автоподбор: все стратегии × ТФ на одной монете ----------
SCAN_LIST = (["bt:" + n for n in ("larry_v4", "gaussian", "ce_zlsma", "hl_cloud", "ichimoku", "sr_power", "sr_power_full",
                                  "eth_rsi", "vsa", "ats_multi", "levando_core")]
             + ["paper:" + n for n in ("Gaussian Channel", "High-Low Cloud", "Third Eye", "Combo OTM", "Pavlova",
                                       "CE ZLSMA", "Order Block", "RSI Connors")])
SCAN_TFS = ["15m", "1h", "4h"]


def _pf(tr):
    w = sum(x["net"] for x in tr if x["net"] > 0); l = -sum(x["net"] for x in tr if x["net"] <= 0)
    return round(w / l, 2) if l > 0 else (99.0 if w > 0 else 0.0)


def run_scan(df, p, prog):
    """Прогоняет каждую стратегию на каждом ТФ (x1, без реинвеста) и делит период пополам:
    стратегия годится, только если PF > 1 и в первой, и во второй половине."""
    mid = int(df.t.iloc[len(df) // 2])
    base = {**p, "leverage": 1, "reinvest": 0}
    jobs = [(s, tf) for s in SCAN_LIST for tf in SCAN_TFS] + [("tao_bb", "1m"), ("dca", "1m"), ("eth_rsi", "4h")]
    rows = []
    for k, (s, tf) in enumerate(jobs):
        prog(40 + 58 * k / len(jobs), f"подбор {k + 1}/{len(jobs)}: {s} {tf}")
        q = {**base, "strategy": s, "tf": tf}
        if s == "dca":
            q.update(grid=[[0, 3.22], [3.75, 6.45], [7.5, 13], [11.25, 25], [15, 52.33]], min_pnl=1, sl=0,
                     filters=True, order_filters=True)
        if s == "tao_bb":
            q.update(sl=2, min_pnl=0.3, stop_mode="wick")
        try:
            tr, eq, liq, mpu, *_ = pick(s)(df, q, lambda *_a: None)
        except Exception as exc:  # noqa: BLE001
            rows.append({"strategy": s, "tf": tf, "error": str(exc)[:120]}); continue
        a = [x for x in tr if x["open_t"] < mid]; b = [x for x in tr if x["open_t"] >= mid]
        rows.append({"strategy": s, "tf": tf, "trades": len(tr), "roi": round(eq - 100, 1), "pf": _pf(tr),
                     "pf1": _pf(a), "pf2": _pf(b), "mpu": round(mpu[0], 1),
                     "win": round(sum(x["net"] > 0 for x in tr) / len(tr) * 100, 1) if tr else 0,
                     "robust": bool(len(a) >= 10 and len(b) >= 10 and _pf(a) > 1.05 and _pf(b) > 1.05)})
    rows.sort(key=lambda r: (not r.get("robust"), -(min(r.get("pf1", 0), r.get("pf2", 0)))))
    return rows


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--job", required=True)
    ap.add_argument("--params", required=True)
    a = ap.parse_args()
    OUT.mkdir(exist_ok=True)
    prog = Progress(a.job)
    res_path = OUT / f"{a.job}.json"
    try:
        p = json.loads(a.params)
        sym = p["symbol"].upper().replace("USDT", "")
        start_ms = int(pd.Timestamp(p["start"], tz="UTC").timestamp() * 1000)
        end_ms = int(pd.Timestamp(p["end"], tz="UTC").timestamp() * 1000) + 86_400_000 if p.get("end") else None
        global FEE
        exch = "okx" if p.get("exchange") == "okx" else "bybit"
        p["exchange"] = exch
        FEE = FEES[exch]
        if p.get("fees") == "maker":
            pass
        prog(1, "загружаю свечи…")
        if exch == "okx":
            if p["strategy"] in ("dca", "tao_bb", "flush", "mdca", "kc_roc", "ribbon", "scan", "build", "buildp", "multi") \
                    or p.get("tf") in ("1m", "5m", "15m", "30m"):
                raise RuntimeError("на OKX бэктест считается по часовым свечам — выбери стратегию с ТФ от 1h "
                                   "(минутные сетки и скальп — только Bybit)")
            try:
                import lab_engine as _E
                _E.FEE = FEE
            except Exception:  # noqa: BLE001
                pass
            df = load_okx_1h(sym, start_ms, prog)
        else:
            df = load_1m(sym, start_ms, prog)
        df = df[df.t >= start_ms]
        if end_ms:
            df = df[df.t < end_ms]
        df = df.reset_index(drop=True)
        if len(df) < (300 if exch == "okx" else 2000):
            raise RuntimeError("мало свечей за выбранный период" + (" (история OKX по этой монете короче)" if exch == "okx" else ""))
        if p["strategy"] == "multi":
            rows = run_multi(p, prog)
            res_path.write_text(json.dumps({"params": p, "symbol": sym, "multi": rows}, ensure_ascii=False, default=float),
                                encoding="utf-8")
            prog(100, "готово")
            return
        if p["strategy"] == "buildp":
            rows, used = run_build_pool(p, prog)
            res_path.write_text(json.dumps({"params": {**p, "coins": used}, "symbol": f"портфель {len(used)} монет",
                                            "build": rows, "pool": True}, ensure_ascii=False, default=float), encoding="utf-8")
            prog(100, "готово")
            return
        if p["strategy"] == "build":
            rows = run_build(df, p, prog)
            res_path.write_text(json.dumps({"params": p, "symbol": sym, "build": rows}, ensure_ascii=False, default=float),
                                encoding="utf-8")
            prog(100, "готово")
            return
        if p["strategy"] == "scan":
            p["deposit"] = 100.0
            rows = run_scan(df, p, prog)
            res_path.write_text(json.dumps({"params": p, "symbol": sym, "scan": rows}, ensure_ascii=False, default=float),
                                encoding="utf-8")
            prog(100, "готово")
            return
        fn = pick(p["strategy"])
        trades, eq, liq, mpu, fees, bars_in, open_pos = fn(df, p, prog)
        prog(96, "готовлю график…")
        view = resample(df, VIEW_RULE.get(p.get("view", "1h"), "1h"))
        st = stats(trades, eq, liq, mpu, fees, bars_in, df, p, len(view))
        out = {"params": p, "symbol": sym, "stats": st, "trades": trades, "open": open_pos, "info": strategy_info(p),
               "candles": [[int(r.t // 1000), r.open, r.high, r.low, r.close] for r in view.itertuples()],
               "equity": [[int(df.t.iloc[0] // 1000), float(p["deposit"])]] + [[int(x["close_t"] // 1000), x["eq"]] for x in trades]}
        res_path.write_text(json.dumps(out, ensure_ascii=False, default=float), encoding="utf-8")
        prog(100, "готово")
    except Exception as exc:  # noqa: BLE001
        res_path.write_text(json.dumps({"error": str(exc), "trace": traceback.format_exc()[-1500:]}, ensure_ascii=False),
                            encoding="utf-8")
        prog(100, f"ошибка: {exc}")


if __name__ == "__main__":
    main()
