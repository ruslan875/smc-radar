"""ginarea_hype_tune.py — 2026-10-29. Варианты бота «HYPE DCA 0,20_c_c»: что уменьшает зависание при той же прибыли.
Берёт кэш свечей из ginarea_hype_test.py (сначала запустите его). Комиссия 0.03%. Отдельно — первая и вторая половина года.
Запуск: ginarea_hype_tune.bat → bt_lab_bots/ginarea_hype_tune.txt
"""
from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import ginarea_hype_test as G  # noqa: E402

BASEP = dict(G.P)
VARIANTS = [
    ("как сейчас", {}),
    ("стоп −100 $", {"sl": -100}), ("стоп −150 $", {"sl": -150}), ("стоп −200 $", {"sl": -200}),
    ("30 ордеров", {"n_orders": 30}), ("40 ордеров", {"n_orders": 40}),
    ("шаг 0.3%", {"step": 0.003}), ("шаг 0.5%", {"step": 0.005}),
    ("RSI < 35", {"rsi_lvl": 35}), ("RSI < 50", {"rsi_lvl": 50}),
    ("шаг 0.3% + стоп −150", {"step": 0.003, "sl": -150}),
    ("шаг 0.5% + 40 орд.", {"step": 0.005, "n_orders": 40}),
    ("RSI<35 + шаг 0.3% + стоп −150", {"rsi_lvl": 35, "step": 0.003, "sl": -150}),
    ("цель 1.0%", {"target": 0.01}), ("цель 1.0% + шаг 0.3%", {"target": 0.01, "step": 0.003}),
]


def one(d, extra):
    G.P.clear(); G.P.update(BASEP); G.P.update(extra)
    gate = G.rsi_gate(d)
    r = G.run(d, 0.0003, gate)
    net = r["total"] + r["open_un"]
    return r, net


def main():
    d = G.okx_1m(365)
    mid = len(d) // 2
    halves = (d.iloc[:mid].reset_index(drop=True), d.iloc[mid:].reset_index(drop=True))
    lines = [f"HYPE DCA — варианты · {pd.to_datetime(d.t.iloc[0], unit='ms'):%Y-%m-%d} → {pd.to_datetime(d.t.iloc[-1], unit='ms'):%Y-%m-%d} · комиссия 0.03%",
             "итог = закрытые + открытая на конец. Половины — тот же бот отдельно на 1-й и 2-й половине года.", ""]
    hdr = f"{'вариант':<32}{'итог $':>9}{'закр.':>8}{'откр.':>8}{'худшая':>9}{'дольше ч':>9}{'стопов':>7}{'1-я пол.':>10}{'2-я пол.':>10}"
    lines.append(hdr); print(hdr)
    for name, extra in VARIANTS:
        r, net = one(d, extra)
        hn = [one(h, extra)[1] for h in halves]
        row = (f"{name:<32}{net:>+9.0f}{r['total']:>+8.0f}{r['open_un']:>+8.0f}{r['worst_unreal']:>+9.0f}{r['longest_h']:>9.0f}"
               f"{r.get('bot_sl', 0):>7}{hn[0]:>+10.0f}{hn[1]:>+10.0f}")
        lines.append(row); print(row, flush=True)
    lines += ["", "Хороший вариант: итог близок к «как сейчас», худшая просадка и зависание (часы) заметно меньше, обе половины ≥ 0.",
              "Приближение: инстоп и точный алгоритм GinArea не повторены — лучший вариант проверьте бэктестом в самой GinArea."]
    out = BASE / "bt_lab_bots" / "ginarea_hype_tune.txt"
    out.write_text("\n".join(lines), encoding="utf-8")
    print("\n".join(lines[-2:])); print(f"\nОтчёт: {out}")
    input("Enter — закрыть")


if __name__ == "__main__":
    main()
