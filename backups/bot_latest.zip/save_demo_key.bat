@echo off
cd /d D:\VANTORIX\bot
venv\Scripts\python.exe save_demo_key.py
pause
