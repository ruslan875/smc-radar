// Сигналы всех 34 индикаторов терминала на КАЖДОЙ закрытой свече (окно W свечей, как в «Мозге»).
// node lab_signals.js in.csv out.json W startIdx
//   in.csv: t,open,high,low,close,volume (t в мс)  out.json: {ids,names,t:[...],sig:[[...34 int8]...]}
// Считает в несколько потоков (worker_threads).
const { Worker, isMainThread, parentPort, workerData } = require("worker_threads");
const os = require("os");
const fs = require("fs");
const path = require("path");
const E = require("./indicatorEngine.js");

function evalRange(c, W, a, b) {
  const out = [];
  for (let i = a; i < b; i++) {
    const res = E.evaluateAllIndicators(c.slice(Math.max(0, i + 1 - W), i + 1));
    out.push(res.map((r) => (r.signal === "LONG" ? 1 : r.signal === "SHORT" ? -1 : 0)));
  }
  return out;
}

if (!isMainThread) {
  const { c, W, a, b } = workerData;
  parentPort.postMessage(evalRange(c, W, a, b));
} else {
  const [inp, outp, Ws, startS] = process.argv.slice(2);
  const W = +Ws || 600, start = Math.max(+startS || 0, 60);
  const c = fs.readFileSync(inp, "utf8").trim().split("\n").slice(1).map((l) => {
    const r = l.split(","); return { start: +r[0], open: +r[1], high: +r[2], low: +r[3], close: +r[4], volume: +r[5] };
  });
  const n = c.length;
  const threads = Math.max(1, Math.min(os.cpus().length, 16));
  const chunk = Math.ceil((n - start) / threads);
  const jobs = [];
  for (let k = 0; k < threads; k++) {
    const a = start + k * chunk, b = Math.min(n, a + chunk);
    if (a >= b) continue;
    const lo = Math.max(0, a - W);
    jobs.push(new Promise((res, rej) => {
      const w = new Worker(__filename, { workerData: { c: c.slice(lo, b), W, a: a - lo, b: b - lo } });
      w.on("message", res); w.on("error", rej);
    }));
  }
  Promise.all(jobs).then((parts) => {
    const sig = [].concat(...parts);
    fs.writeFileSync(outp, JSON.stringify({
      ids: E.INDICATOR_DEFINITIONS.map((d) => d.id), names: E.INDICATOR_DEFINITIONS.map((d) => d.name),
      t: c.slice(start).map((x) => x.start), sig,
    }));
  }).catch((e) => { console.error(e); process.exit(1); });
}
