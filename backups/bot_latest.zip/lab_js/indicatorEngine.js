// СКОМПИЛИРОВАНО из terminal/src/indicatorEngine.ts (2026-09-26) — тот же движок 34 индикаторов, что в терминале.
// Если движок в терминале поменяется — пересобрать: tsc indicatorEngine.ts --module commonjs --target es2020
"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.INDICATOR_DEFINITION_COUNT = exports.INDICATOR_DEFINITIONS = void 0;
exports.getIndicatorDefinition = getIndicatorDefinition;
exports.evaluateIndicator = evaluateIndicator;
exports.evaluateAllIndicators = evaluateAllIndicators;
const EPS = 1e-12;
function isFiniteNumber(value) {
    return Number.isFinite(value);
}
function lastValue(values) {
    return values.length > 0
        ? values[values.length - 1]
        : undefined;
}
function previousValue(values) {
    return values.length > 1
        ? values[values.length - 2]
        : undefined;
}
function closes(candles) {
    return candles.map((candle) => candle.close);
}
function point(candle, value) {
    return {
        start: candle.start,
        value,
    };
}
function toSeries(candles, values) {
    const result = [];
    for (let index = 0; index < candles.length; index += 1) {
        const value = values[index];
        if (isFiniteNumber(value)) {
            result.push(point(candles[index], value));
        }
    }
    return result;
}
function sma(values, period) {
    const result = new Array(values.length).fill(NaN);
    if (period <= 0 ||
        values.length < period) {
        return result;
    }
    // 24.09.2026: раньше NaN в начале ряда (у стохастика первые 13 значений,
    // у WaveTrend — разогрев) попадал в бегущую сумму и делал NaN ВСЕ
    // последующие значения: «Стохастик, уровни/пересечение» (4 шт.) и
    // «VMC Wave Trend» не голосовали никогда. Теперь NaN в окне считаем и
    // среднее выдаём только по полностью заполненному окну.
    let sum = 0;
    let nans = 0;
    for (let index = 0; index < values.length; index += 1) {
        const v = values[index];
        if (Number.isFinite(v))
            sum += v;
        else
            nans += 1;
        if (index >= period) {
            const old = values[index - period];
            if (Number.isFinite(old))
                sum -= old;
            else
                nans -= 1;
        }
        if (index >= period - 1 && nans === 0) {
            result[index] =
                sum / period;
        }
    }
    return result;
}
function ema(values, period) {
    const result = new Array(values.length).fill(NaN);
    if (period <= 0 ||
        values.length < period) {
        return result;
    }
    let seed = 0;
    for (let index = 0; index < period; index += 1) {
        seed += values[index];
    }
    let current = seed / period;
    result[period - 1] = current;
    const alpha = 2 / (period + 1);
    for (let index = period; index < values.length; index += 1) {
        current =
            current +
                alpha *
                    (values[index] -
                        current);
        result[index] =
            current;
    }
    return result;
}
function wma(values, period) {
    const result = new Array(values.length).fill(NaN);
    if (period <= 0 ||
        values.length < period) {
        return result;
    }
    const denominator = (period * (period + 1)) /
        2;
    for (let index = period - 1; index < values.length; index += 1) {
        let weighted = 0;
        for (let offset = 0; offset < period; offset += 1) {
            weighted +=
                values[index - offset] *
                    (period - offset);
        }
        result[index] =
            weighted / denominator;
    }
    return result;
}
function hma(values, period) {
    const halfPeriod = Math.max(1, Math.floor(period / 2));
    const sqrtPeriod = Math.max(1, Math.floor(Math.sqrt(period)));
    const half = wma(values, halfPeriod);
    const full = wma(values, period);
    const diff = values.map((_value, index) => {
        if (!isFiniteNumber(half[index]) ||
            !isFiniteNumber(full[index])) {
            return NaN;
        }
        return (2 * half[index] -
            full[index]);
    });
    return wma(diff, sqrtPeriod);
}
function trueRange(candles) {
    return candles.map((candle, index) => {
        if (index === 0) {
            return (candle.high -
                candle.low);
        }
        const previousClose = candles[index - 1]
            .close;
        return Math.max(candle.high -
            candle.low, Math.abs(candle.high -
            previousClose), Math.abs(candle.low -
            previousClose));
    });
}
function atr(candles, period) {
    return sma(trueRange(candles), period);
}
function stdDev(values, period) {
    const result = new Array(values.length).fill(NaN);
    if (period <= 0 ||
        values.length < period) {
        return result;
    }
    for (let index = period - 1; index < values.length; index += 1) {
        const mean = values
            .slice(index - period + 1, index + 1)
            .reduce((sum, value) => sum + value, 0) / period;
        const variance = values
            .slice(index - period + 1, index + 1)
            .reduce((sum, value) => sum +
            (value - mean) ** 2, 0) / period;
        result[index] =
            Math.sqrt(variance);
    }
    return result;
}
function rsi(values, period = 14) {
    const result = new Array(values.length).fill(NaN);
    if (values.length <= period ||
        period <= 0) {
        return result;
    }
    let gain = 0;
    let loss = 0;
    for (let index = 1; index <= period; index += 1) {
        const change = values[index] -
            values[index - 1];
        if (change >= 0) {
            gain += change;
        }
        else {
            loss -= change;
        }
    }
    let averageGain = gain / period;
    let averageLoss = loss / period;
    result[period] =
        averageLoss <= EPS
            ? 100
            : 100 -
                100 /
                    (1 +
                        averageGain /
                            averageLoss);
    for (let index = period + 1; index < values.length; index += 1) {
        const change = values[index] -
            values[index - 1];
        const currentGain = Math.max(change, 0);
        const currentLoss = Math.max(-change, 0);
        averageGain =
            (averageGain *
                (period - 1) +
                currentGain) /
                period;
        averageLoss =
            (averageLoss *
                (period - 1) +
                currentLoss) /
                period;
        result[index] =
            averageLoss <= EPS
                ? 100
                : 100 -
                    100 /
                        (1 +
                            averageGain /
                                averageLoss);
    }
    return result;
}
function cci(candles, period = 20) {
    const typical = candles.map((candle) => (candle.high +
        candle.low +
        candle.close) /
        3);
    const average = sma(typical, period);
    const result = new Array(candles.length).fill(NaN);
    for (let index = period - 1; index < candles.length; index += 1) {
        if (!isFiniteNumber(average[index])) {
            continue;
        }
        let deviation = 0;
        for (let offset = 0; offset < period; offset += 1) {
            deviation += Math.abs(typical[index - offset] -
                average[index]);
        }
        deviation /= period;
        result[index] =
            deviation <= EPS
                ? 0
                : (typical[index] -
                    average[index]) /
                    (0.015 * deviation);
    }
    return result;
}
function cmo(values, period = 14) {
    const result = new Array(values.length).fill(NaN);
    for (let index = period; index < values.length; index += 1) {
        let up = 0;
        let down = 0;
        for (let offset = 0; offset < period; offset += 1) {
            const change = values[index - offset] -
                values[index - offset - 1];
            if (change > 0) {
                up += change;
            }
            else {
                down -= change;
            }
        }
        const denominator = up + down;
        result[index] =
            denominator <= EPS
                ? 0
                : ((up - down) /
                    denominator) *
                    100;
    }
    return result;
}
function stochastic(candles, period = 14, smoothK = 3, smoothD = 3) {
    const rawK = new Array(candles.length).fill(NaN);
    for (let index = period - 1; index < candles.length; index += 1) {
        let high = -Infinity;
        let low = Infinity;
        for (let offset = 0; offset < period; offset += 1) {
            high = Math.max(high, candles[index - offset]
                .high);
            low = Math.min(low, candles[index - offset]
                .low);
        }
        const range = high - low;
        rawK[index] =
            range <= EPS
                ? 50
                : ((candles[index].close -
                    low) /
                    range) *
                    100;
    }
    return {
        k: sma(rawK, smoothK),
        d: sma(sma(rawK, smoothK), smoothD),
    };
}
function macd(values, fast = 12, slow = 26, signal = 9) {
    const fastLine = ema(values, fast);
    const slowLine = ema(values, slow);
    const macdLine = values.map((_value, index) => isFiniteNumber(fastLine[index]) &&
        isFiniteNumber(slowLine[index])
        ? fastLine[index] -
            slowLine[index]
        : NaN);
    const compact = macdLine.filter(Number.isFinite);
    const compactSignal = ema(compact, signal);
    const signalLine = new Array(values.length).fill(NaN);
    let compactIndex = 0;
    for (let index = 0; index < macdLine.length; index += 1) {
        if (!isFiniteNumber(macdLine[index])) {
            continue;
        }
        signalLine[index] =
            compactSignal[compactIndex];
        compactIndex += 1;
    }
    const histogram = macdLine.map((value, index) => isFiniteNumber(value) &&
        isFiniteNumber(signalLine[index])
        ? value -
            signalLine[index]
        : NaN);
    return {
        macd: macdLine,
        signal: signalLine,
        histogram,
    };
}
function bollingerBands(values, period = 20, multiplier = 2) {
    const middle = sma(values, period);
    const deviation = stdDev(values, period);
    const upper = middle.map((value, index) => isFiniteNumber(value) &&
        isFiniteNumber(deviation[index])
        ? value +
            multiplier *
                deviation[index]
        : NaN);
    const lower = middle.map((value, index) => isFiniteNumber(value) &&
        isFiniteNumber(deviation[index])
        ? value -
            multiplier *
                deviation[index]
        : NaN);
    return {
        middle,
        upper,
        lower,
    };
}
function donchian(candles, period = 20) {
    const upper = new Array(candles.length).fill(NaN);
    const middle = new Array(candles.length).fill(NaN);
    const lower = new Array(candles.length).fill(NaN);
    for (let index = period - 1; index < candles.length; index += 1) {
        let high = -Infinity;
        let low = Infinity;
        for (let offset = 0; offset < period; offset += 1) {
            high = Math.max(high, candles[index - offset]
                .high);
            low = Math.min(low, candles[index - offset]
                .low);
        }
        upper[index] = high;
        lower[index] = low;
        middle[index] =
            (high + low) / 2;
    }
    return {
        upper,
        middle,
        lower,
    };
}
function mfi(candles, period = 14) {
    const typical = candles.map((candle) => (candle.high +
        candle.low +
        candle.close) /
        3);
    const result = new Array(candles.length).fill(NaN);
    for (let index = period; index < candles.length; index += 1) {
        let positive = 0;
        let negative = 0;
        for (let offset = 0; offset < period; offset += 1) {
            const current = index - offset;
            const previousIndex = current - 1;
            const flow = typical[current] *
                candles[current].volume;
            if (typical[current] >
                typical[previousIndex]) {
                positive += flow;
            }
            else if (typical[current] <
                typical[previousIndex]) {
                negative += flow;
            }
        }
        result[index] =
            negative <= EPS
                ? 100
                : 100 -
                    100 /
                        (1 +
                            positive /
                                negative);
    }
    return result;
}
function roc(values, period = 12) {
    const result = new Array(values.length).fill(NaN);
    for (let index = period; index < values.length; index += 1) {
        const base = values[index - period];
        result[index] =
            Math.abs(base) <= EPS
                ? 0
                : ((values[index] -
                    base) /
                    base) *
                    100;
    }
    return result;
}
function williamsR(candles, period = 14) {
    const result = new Array(candles.length).fill(NaN);
    for (let index = period - 1; index < candles.length; index += 1) {
        let high = -Infinity;
        let low = Infinity;
        for (let offset = 0; offset < period; offset += 1) {
            high = Math.max(high, candles[index - offset]
                .high);
            low = Math.min(low, candles[index - offset]
                .low);
        }
        const range = high - low;
        result[index] =
            range <= EPS
                ? -50
                : ((high -
                    candles[index].close) /
                    range) *
                    -100;
    }
    return result;
}
function bop(candles) {
    return candles.map((candle) => {
        const range = candle.high -
            candle.low;
        return range <= EPS
            ? 0
            : (candle.close -
                candle.open) /
                range;
    });
}
function rvi(candles, period = 10) {
    const numerator = candles.map((candle) => candle.close -
        candle.open);
    const denominator = candles.map((candle) => candle.high -
        candle.low);
    const numeratorAverage = sma(numerator, period);
    const denominatorAverage = sma(denominator, period);
    return numerator.map((_value, index) => isFiniteNumber(numeratorAverage[index]) &&
        isFiniteNumber(denominatorAverage[index]) &&
        Math.abs(denominatorAverage[index]) > EPS
        ? (numeratorAverage[index] /
            denominatorAverage[index]) *
            100
        : NaN);
}
function chaikin(candles, fast = 3, slow = 10) {
    const adl = new Array(candles.length).fill(0);
    for (let index = 0; index < candles.length; index += 1) {
        const range = candles[index].high -
            candles[index].low;
        const multiplier = range <= EPS
            ? 0
            : ((2 *
                candles[index].close -
                candles[index].high -
                candles[index].low) /
                range);
        adl[index] =
            (index > 0
                ? adl[index - 1]
                : 0) +
                multiplier *
                    candles[index].volume;
    }
    const fastLine = ema(adl, fast);
    const slowLine = ema(adl, slow);
    return adl.map((_value, index) => isFiniteNumber(fastLine[index]) &&
        isFiniteNumber(slowLine[index])
        ? fastLine[index] -
            slowLine[index]
        : NaN);
}
function keltner(candles, emaPeriod = 20, atrPeriod = 10, multiplier = 2) {
    const middle = ema(closes(candles), emaPeriod);
    const volatility = atr(candles, atrPeriod);
    return {
        middle,
        upper: middle.map((value, index) => isFiniteNumber(value) &&
            isFiniteNumber(volatility[index])
            ? value +
                multiplier *
                    volatility[index]
            : NaN),
        lower: middle.map((value, index) => isFiniteNumber(value) &&
            isFiniteNumber(volatility[index])
            ? value -
                multiplier *
                    volatility[index]
            : NaN),
    };
}
function psar(candles) {
    const value = new Array(candles.length).fill(NaN);
    const trend = new Array(candles.length).fill(0);
    if (!candles.length) {
        return {
            value,
            trend,
        };
    }
    let bullish = true;
    let acceleration = 0.02;
    let extreme = candles[0].high;
    let current = candles[0].low;
    value[0] = current;
    trend[0] = 1;
    for (let index = 1; index < candles.length; index += 1) {
        let next = current +
            acceleration *
                (extreme - current);
        if (bullish) {
            next = Math.min(next, candles[index - 1]
                .low);
            if (index > 1) {
                next = Math.min(next, candles[index - 2]
                    .low);
            }
            if (candles[index].low <
                next) {
                bullish = false;
                next = extreme;
                extreme =
                    candles[index].low;
                acceleration = 0.02;
            }
            else if (candles[index].high >
                extreme) {
                extreme =
                    candles[index].high;
                acceleration =
                    Math.min(0.2, acceleration + 0.02);
            }
        }
        else {
            next = Math.max(next, candles[index - 1]
                .high);
            if (index > 1) {
                next = Math.max(next, candles[index - 2]
                    .high);
            }
            if (candles[index].high >
                next) {
                bullish = true;
                next = extreme;
                extreme =
                    candles[index].high;
                acceleration = 0.02;
            }
            else if (candles[index].low <
                extreme) {
                extreme =
                    candles[index].low;
                acceleration =
                    Math.min(0.2, acceleration + 0.02);
            }
        }
        current = next;
        value[index] =
            current;
        trend[index] =
            bullish ? 1 : -1;
    }
    return {
        value,
        trend,
    };
}
function supertrend(candles, period = 10, multiplier = 3) {
    const volatility = atr(candles, period);
    const value = new Array(candles.length).fill(NaN);
    const trend = new Array(candles.length).fill(0);
    const upper = new Array(candles.length).fill(NaN);
    const lower = new Array(candles.length).fill(NaN);
    for (let index = 0; index < candles.length; index += 1) {
        if (!isFiniteNumber(volatility[index])) {
            continue;
        }
        const middle = (candles[index].high +
            candles[index].low) /
            2;
        upper[index] =
            middle +
                multiplier *
                    volatility[index];
        lower[index] =
            middle -
                multiplier *
                    volatility[index];
        if (index === 0) {
            trend[index] = 1;
            value[index] =
                lower[index];
            continue;
        }
        if (isFiniteNumber(upper[index - 1]) &&
            candles[index - 1]
                .close <=
                upper[index - 1]) {
            upper[index] =
                Math.min(upper[index], upper[index - 1]);
        }
        if (isFiniteNumber(lower[index - 1]) &&
            candles[index - 1]
                .close >=
                lower[index - 1]) {
            lower[index] =
                Math.max(lower[index], lower[index - 1]);
        }
        const previousTrend = trend[index - 1];
        if (previousTrend >= 0 &&
            candles[index].close <
                lower[index]) {
            trend[index] = -1;
        }
        else if (previousTrend <= 0 &&
            candles[index].close >
                upper[index]) {
            trend[index] = 1;
        }
        else {
            trend[index] =
                previousTrend || 1;
        }
        value[index] =
            trend[index] > 0
                ? lower[index]
                : upper[index];
    }
    return {
        value,
        trend,
    };
}
function signalFromLevel(values, upper, lower) {
    const current = lastValue(values);
    if (current === undefined ||
        !isFiniteNumber(current)) {
        return "NEUTRAL";
    }
    if (current >= upper) {
        return "SHORT";
    }
    if (current <= lower) {
        return "LONG";
    }
    return "NEUTRAL";
}
function crossover(first, second) {
    const currentFirst = lastValue(first);
    const previousFirst = previousValue(first);
    const currentSecond = lastValue(second);
    const previousSecond = previousValue(second);
    if (currentFirst === undefined ||
        previousFirst === undefined ||
        currentSecond === undefined ||
        previousSecond === undefined ||
        !isFiniteNumber(currentFirst) ||
        !isFiniteNumber(previousFirst) ||
        !isFiniteNumber(currentSecond) ||
        !isFiniteNumber(previousSecond)) {
        return "NEUTRAL";
    }
    if (currentFirst > currentSecond &&
        previousFirst <= previousSecond) {
        return "LONG";
    }
    if (currentFirst < currentSecond &&
        previousFirst >= previousSecond) {
        return "SHORT";
    }
    return "NEUTRAL";
}
function directionalTrend(values) {
    const current = lastValue(values);
    const previousTrend = previousValue(values);
    if (!isFiniteNumber(current) ||
        !isFiniteNumber(previousTrend)) {
        return "NEUTRAL";
    }
    if (current >
        previousTrend) {
        return "LONG";
    }
    if (current <
        previousTrend) {
        return "SHORT";
    }
    return "NEUTRAL";
}
function makeResult(id, name, group, candles, signal, seriesMap, metadata) {
    return {
        id,
        name,
        group,
        signal,
        values: Object.entries(seriesMap).map(([seriesName, values]) => ({
            name: seriesName,
            values: toSeries(candles, values),
        })),
        metadata,
    };
}
function normalize(candles) {
    const unique = new Map();
    for (const candle of candles) {
        if (!isFiniteNumber(candle.start) ||
            !isFiniteNumber(candle.open) ||
            !isFiniteNumber(candle.high) ||
            !isFiniteNumber(candle.low) ||
            !isFiniteNumber(candle.close) ||
            !isFiniteNumber(candle.volume)) {
            continue;
        }
        unique.set(candle.start, candle);
    }
    return [...unique.values()]
        .sort((a, b) => a.start - b.start)
        .slice(-1500);
}
function rsiDivergence(candles, period = 14, lookback = 20) {
    const price = closes(candles);
    const oscillator = rsi(price, period);
    const result = new Array(candles.length).fill(0);
    for (let index = lookback; index < candles.length; index += 1) {
        if (!isFiniteNumber(oscillator[index]) ||
            !isFiniteNumber(oscillator[index - lookback])) {
            continue;
        }
        if (price[index] >
            price[index - lookback] &&
            oscillator[index] <
                oscillator[index - lookback]) {
            result[index] = -1;
        }
        else if (price[index] <
            price[index - lookback] &&
            oscillator[index] >
                oscillator[index - lookback]) {
            result[index] = 1;
        }
    }
    return result;
}
function waveTrend(candles, channelLength = 10, averageLength = 21) {
    const typical = candles.map((candle) => (candle.high +
        candle.low +
        candle.close) /
        3);
    const esa = ema(typical, channelLength);
    const deviation = ema(typical.map((value, index) => isFiniteNumber(esa[index])
        ? Math.abs(value -
            esa[index])
        : 0), channelLength);
    const ci = typical.map((value, index) => isFiniteNumber(esa[index]) &&
        isFiniteNumber(deviation[index]) &&
        Math.abs(deviation[index]) > EPS
        ? (value -
            esa[index]) /
            (0.015 *
                deviation[index])
        : NaN);
    const wt1 = ema(ci.map((value) => isFiniteNumber(value)
        ? value
        : 0), averageLength);
    const wt2 = sma(wt1, 4);
    return {
        wt1,
        wt2,
    };
}
function meanReversionChannel(candles, period = 20, multiplier = 2) {
    const price = closes(candles);
    const middle = ema(price, period);
    const deviation = stdDev(price, period);
    return {
        middle,
        upper: middle.map((value, index) => isFiniteNumber(value) &&
            isFiniteNumber(deviation[index])
            ? value +
                multiplier *
                    deviation[index]
            : NaN),
        lower: middle.map((value, index) => isFiniteNumber(value) &&
            isFiniteNumber(deviation[index])
            ? value -
                multiplier *
                    deviation[index]
            : NaN),
    };
}
function definitions() {
    return [
        {
            id: "bop",
            name: "Баланс сил",
            group: "momentum",
            description: "Balance of Power.",
            evaluate(candles) {
                const values = bop(candles);
                return makeResult(this.id, this.name, this.group, candles, directionalTrend(values), { bop: values });
            },
        },
        {
            id: "bb",
            name: "Полосы Боллинджера",
            group: "channel",
            description: "SMA 20 / K 2.",
            evaluate(candles) {
                const bands = bollingerBands(closes(candles), 20, 2);
                const close = lastValue(closes(candles));
                const upper = lastValue(bands.upper);
                const lower = lastValue(bands.lower);
                const signal = isFiniteNumber(close) &&
                    isFiniteNumber(upper) &&
                    close >
                        upper
                    ? "SHORT"
                    : isFiniteNumber(close) &&
                        isFiniteNumber(lower) &&
                        close <
                            lower
                        ? "LONG"
                        : "NEUTRAL";
                return makeResult(this.id, this.name, this.group, candles, signal, bands, {
                    period: 20,
                    multiplier: 2,
                });
            },
        },
        {
            id: "cci",
            name: "Уровни CCI",
            group: "momentum",
            description: "Commodity Channel Index 20.",
            evaluate(candles) {
                const values = cci(candles, 20);
                return makeResult(this.id, this.name, this.group, candles, signalFromLevel(values, 100, -100), { cci: values });
            },
        },
        {
            id: "chaikin",
            name: "Осциллятор Чайкина",
            group: "volume",
            description: "Chaikin 3/10.",
            evaluate(candles) {
                const values = chaikin(candles, 3, 10);
                return makeResult(this.id, this.name, this.group, candles, directionalTrend(values), { chaikin: values });
            },
        },
        {
            id: "cmo",
            name: "Уровни CMO",
            group: "momentum",
            description: "Chande Momentum Oscillator 14.",
            evaluate(candles) {
                const values = cmo(closes(candles), 14);
                return makeResult(this.id, this.name, this.group, candles, signalFromLevel(values, 50, -50), { cmo: values });
            },
        },
        {
            id: "donchian",
            name: "Канал Дончиана",
            group: "channel",
            description: "Donchian 20.",
            evaluate(candles) {
                const channel = donchian(candles, 20);
                const close = lastValue(closes(candles));
                const upper = previousValue(channel.upper);
                const lower = previousValue(channel.lower);
                const signal = isFiniteNumber(close) &&
                    isFiniteNumber(upper) &&
                    close >=
                        upper
                    ? "LONG"
                    : isFiniteNumber(close) &&
                        isFiniteNumber(lower) &&
                        close <=
                            lower
                        ? "SHORT"
                        : "NEUTRAL";
                return makeResult(this.id, this.name, this.group, candles, signal, channel);
            },
        },
        {
            id: "ema-500-cross-100",
            name: "EMA 500 пересечение EMA 100",
            group: "trend",
            description: "EMA 100 / EMA 500.",
            evaluate(candles) {
                const values = closes(candles);
                const fast = ema(values, 100);
                const slow = ema(values, 500);
                return makeResult(this.id, this.name, this.group, candles, crossover(fast, slow), {
                    ema100: fast,
                    ema500: slow,
                });
            },
        },
        {
            id: "stochastic-fast-cross",
            name: "Быстрый стохастик, пересечение линий",
            group: "oscillator",
            description: "Fast stochastic.",
            evaluate(candles) {
                const value = stochastic(candles, 14, 1, 3);
                return makeResult(this.id, this.name, this.group, candles, crossover(value.k, value.d), {
                    k: value.k,
                    d: value.d,
                });
            },
        },
        {
            id: "stochastic-fast-levels",
            name: "Быстрый стохастик, уровни",
            group: "oscillator",
            description: "Fast stochastic levels.",
            evaluate(candles) {
                const value = stochastic(candles, 14, 1, 3);
                return makeResult(this.id, this.name, this.group, candles, signalFromLevel(value.k, 80, 20), {
                    k: value.k,
                    d: value.d,
                });
            },
        },
        {
            id: "stochastic-slow-cross",
            name: "Стохастик, пересечение линий (медленный)",
            group: "oscillator",
            description: "Slow stochastic.",
            evaluate(candles) {
                const value = stochastic(candles, 14, 3, 3);
                return makeResult(this.id, this.name, this.group, candles, crossover(value.k, value.d), {
                    k: value.k,
                    d: value.d,
                });
            },
        },
        {
            id: "stochastic-slow-levels",
            name: "Стохастик, уровни (медленный)",
            group: "oscillator",
            description: "Slow stochastic levels.",
            evaluate(candles) {
                const value = stochastic(candles, 14, 3, 3);
                return makeResult(this.id, this.name, this.group, candles, signalFromLevel(value.k, 80, 20), {
                    k: value.k,
                    d: value.d,
                });
            },
        },
        {
            id: "hma",
            name: "Скользящая средняя Халла",
            group: "trend",
            description: "HMA 20.",
            evaluate(candles) {
                const values = hma(closes(candles), 20);
                return makeResult(this.id, this.name, this.group, candles, crossover(closes(candles), values), { hma: values });
            },
        },
        {
            id: "keltner",
            name: "Канал Кельтнера",
            group: "channel",
            description: "EMA 20 / ATR 10 x 2.",
            evaluate(candles) {
                const channel = (() => {
                    const close = closes(candles);
                    const middle = ema(close, 20);
                    const volatility = atr(candles, 10);
                    return {
                        middle,
                        upper: middle.map((value, index) => isFiniteNumber(value) &&
                            isFiniteNumber(volatility[index])
                            ? value +
                                2 *
                                    volatility[index]
                            : NaN),
                        lower: middle.map((value, index) => isFiniteNumber(value) &&
                            isFiniteNumber(volatility[index])
                            ? value -
                                2 *
                                    volatility[index]
                            : NaN),
                    };
                })();
                const close = lastValue(closes(candles));
                const upper = lastValue(channel.upper);
                const lower = lastValue(channel.lower);
                const signal = isFiniteNumber(close) &&
                    isFiniteNumber(upper) &&
                    close >
                        upper
                    ? "LONG"
                    : isFiniteNumber(close) &&
                        isFiniteNumber(lower) &&
                        close <
                            lower
                        ? "SHORT"
                        : "NEUTRAL";
                return makeResult(this.id, this.name, this.group, candles, signal, channel);
            },
        },
        {
            id: "macd-signal-cross",
            name: "Пересечение MACD и сигнальной линии",
            group: "oscillator",
            description: "MACD 12/26/9.",
            evaluate(candles) {
                const value = macd(closes(candles), 12, 26, 9);
                return makeResult(this.id, this.name, this.group, candles, crossover(value.macd, value.signal), value);
            },
        },
        {
            id: "macd-zero-cross",
            name: "Пересечение MACD и нулевого уровня",
            group: "oscillator",
            description: "MACD zero line.",
            evaluate(candles) {
                const value = macd(closes(candles), 12, 26, 9);
                return makeResult(this.id, this.name, this.group, candles, signalFromLevel(value.macd, 0, 0), value);
            },
        },
        {
            id: "macd-histogram-trend",
            name: "Тренд по гистограмме MACD",
            group: "oscillator",
            description: "MACD histogram direction.",
            evaluate(candles) {
                const value = macd(closes(candles), 12, 26, 9);
                return makeResult(this.id, this.name, this.group, candles, directionalTrend(value.histogram), value);
            },
        },
        {
            id: "mrc-middle",
            name: "Mean Reversion Channel: Средние уровни",
            group: "channel",
            description: "Mean reversion middle.",
            evaluate(candles) {
                const channel = meanReversionChannel(candles, 20, 1);
                return makeResult(this.id, this.name, this.group, candles, crossover(closes(candles), channel.middle), channel);
            },
        },
        {
            id: "mrc-strong",
            name: "Mean Reversion Channel: Сильные уровни",
            group: "channel",
            description: "Mean reversion strong.",
            evaluate(candles) {
                const channel = meanReversionChannel(candles, 20, 2);
                const close = lastValue(closes(candles));
                const upper = lastValue(channel.upper);
                const lower = lastValue(channel.lower);
                return makeResult(this.id, this.name, this.group, candles, isFiniteNumber(close) &&
                    isFiniteNumber(lower) &&
                    close <
                        lower
                    ? "LONG"
                    : isFiniteNumber(close) &&
                        isFiniteNumber(upper) &&
                        close >
                            upper
                        ? "SHORT"
                        : "NEUTRAL", channel);
            },
        },
        {
            id: "mrc-weak",
            name: "Mean Reversion Channel: Слабые уровни",
            group: "channel",
            description: "Mean reversion weak.",
            evaluate(candles) {
                const channel = meanReversionChannel(candles, 20, 0.75);
                return makeResult(this.id, this.name, this.group, candles, crossover(closes(candles), channel.middle), channel);
            },
        },
        {
            id: "mfi-mid-cross",
            name: "MFI пересечение середины диапазона",
            group: "volume",
            description: "MFI 14 crossing 50.",
            evaluate(candles) {
                const values = mfi(candles, 14);
                return makeResult(this.id, this.name, this.group, candles, crossover(values, values.map(() => 50)), {
                    mfi: values,
                });
            },
        },
        {
            id: "mfi-levels",
            name: "Уровни MFI",
            group: "volume",
            description: "MFI 14.",
            evaluate(candles) {
                const values = mfi(candles, 14);
                return makeResult(this.id, this.name, this.group, candles, signalFromLevel(values, 80, 20), {
                    mfi: values,
                });
            },
        },
        {
            id: "psar-reversal",
            name: "Смена тренда SAR",
            group: "trend",
            description: "Parabolic SAR reversal.",
            evaluate(candles) {
                const value = psar(candles);
                const current = lastValue(value.trend);
                const previous = previousValue(value.trend);
                return makeResult(this.id, this.name, this.group, candles, current === 1 &&
                    previous === -1
                    ? "LONG"
                    : current === -1 &&
                        previous === 1
                        ? "SHORT"
                        : "NEUTRAL", value);
            },
        },
        {
            id: "psar-trend",
            name: "Тренд SAR",
            group: "trend",
            description: "Parabolic SAR trend.",
            evaluate(candles) {
                const value = psar(candles);
                const current = lastValue(value.trend);
                return makeResult(this.id, this.name, this.group, candles, current === 1
                    ? "LONG"
                    : current === -1
                        ? "SHORT"
                        : "NEUTRAL", value);
            },
        },
        {
            id: "roc-zero-cross",
            name: "Пересечение RoC и нулевого уровня",
            group: "momentum",
            description: "ROC 12 crossing zero.",
            evaluate(candles) {
                const values = roc(closes(candles), 12);
                return makeResult(this.id, this.name, this.group, candles, signalFromLevel(values, 0, 0), {
                    roc: values,
                });
            },
        },
        {
            id: "rsi-levels",
            name: "Уровни RSI",
            group: "oscillator",
            description: "RSI 14, 30/70.",
            evaluate(candles) {
                const values = rsi(closes(candles), 14);
                return makeResult(this.id, this.name, this.group, candles, signalFromLevel(values, 70, 30), {
                    rsi: values,
                }, {
                    period: 14,
                    oversold: 30,
                    overbought: 70,
                });
            },
        },
        {
            id: "rvi-levels",
            name: "Уровни RVI",
            group: "oscillator",
            description: "Relative Volatility Index.",
            evaluate(candles) {
                const values = rvi(candles, 10);
                return makeResult(this.id, this.name, this.group, candles, signalFromLevel(values, 0, 0), {
                    rvi: values,
                });
            },
        },
        {
            id: "srgart-diverx",
            name: "SrgArt DiverX",
            group: "advanced",
            description: "Divergence adapter based on RSI and price.",
            evaluate(candles) {
                const values = rsiDivergence(candles, 14, 20);
                return makeResult(this.id, this.name, this.group, candles, lastValue(values) === 1
                    ? "LONG"
                    : lastValue(values) ===
                        -1
                        ? "SHORT"
                        : "NEUTRAL", {
                    divergence: values,
                });
            },
        },
        {
            id: "supertrend-reversal",
            name: "Смена тренда SuperTrend",
            group: "trend",
            description: "SuperTrend 10/3 reversal.",
            evaluate(candles) {
                const value = supertrend(candles, 10, 3);
                const current = lastValue(value.trend);
                const previous = previousValue(value.trend);
                return makeResult(this.id, this.name, this.group, candles, current === 1 &&
                    previous === -1
                    ? "LONG"
                    : current === -1 &&
                        previous === 1
                        ? "SHORT"
                        : "NEUTRAL", value);
            },
        },
        {
            id: "supertrend-trend",
            name: "Тренд SuperTrend",
            group: "trend",
            description: "SuperTrend 10/3 trend.",
            evaluate(candles) {
                const value = supertrend(candles, 10, 3);
                const current = lastValue(value.trend);
                return makeResult(this.id, this.name, this.group, candles, current === 1
                    ? "LONG"
                    : current === -1
                        ? "SHORT"
                        : "NEUTRAL", value);
            },
        },
        {
            id: "turtle-zone",
            name: "Turtle Zone",
            group: "channel",
            description: "Donchian-based zone.",
            evaluate(candles) {
                const zone = donchian(candles, 20);
                const close = lastValue(closes(candles));
                const upper = previousValue(zone.upper);
                const lower = previousValue(zone.lower);
                return makeResult(this.id, this.name, this.group, candles, isFiniteNumber(close) &&
                    isFiniteNumber(upper) &&
                    close >=
                        upper
                    ? "LONG"
                    : isFiniteNumber(close) &&
                        isFiniteNumber(lower) &&
                        close <=
                            lower
                        ? "SHORT"
                        : "NEUTRAL", zone);
            },
        },
        {
            id: "vmc-divergence",
            name: "VMC Divergence",
            group: "advanced",
            description: "WaveTrend divergence adapter.",
            evaluate(candles) {
                const wave = waveTrend(candles);
                const divergence = rsiDivergence(candles, 14, 20);
                return makeResult(this.id, this.name, this.group, candles, lastValue(divergence) === 1
                    ? "LONG"
                    : lastValue(divergence) === -1
                        ? "SHORT"
                        : "NEUTRAL", {
                    wt1: wave.wt1,
                    wt2: wave.wt2,
                    divergence,
                });
            },
        },
        {
            id: "vmc-money-flow",
            name: "VMC Money Flow",
            group: "volume",
            description: "Volume-weighted flow adapter.",
            evaluate(candles) {
                const typical = candles.map((candle) => (candle.high +
                    candle.low +
                    candle.close) /
                    3);
                const money = typical.map((value, index) => value *
                    candles[index]
                        .volume);
                const values = sma(money, 20);
                return makeResult(this.id, this.name, this.group, candles, directionalTrend(values), {
                    moneyFlow: values,
                });
            },
        },
        {
            id: "vmc-wave-trend",
            name: "VMC Wave Trend",
            group: "advanced",
            description: "WaveTrend 10/21.",
            evaluate(candles) {
                const wave = waveTrend(candles, 10, 21);
                return makeResult(this.id, this.name, this.group, candles, crossover(wave.wt1, wave.wt2), wave);
            },
        },
        {
            id: "williams-r",
            name: "Уровни %R",
            group: "oscillator",
            description: "Williams %R 14.",
            evaluate(candles) {
                const values = williamsR(candles, 14);
                return makeResult(this.id, this.name, this.group, candles, signalFromLevel(values, -20, -80), {
                    williamsR: values,
                });
            },
        },
    ];
}
exports.INDICATOR_DEFINITIONS = definitions();
exports.INDICATOR_DEFINITION_COUNT = exports.INDICATOR_DEFINITIONS.length;
function getIndicatorDefinition(id) {
    return exports.INDICATOR_DEFINITIONS.find((definition) => definition.id === id);
}
function evaluateIndicator(id, candles) {
    const definition = getIndicatorDefinition(id);
    if (!definition) {
        throw new Error(`Unknown indicator: ${id}`);
    }
    return definition.evaluate(normalize(candles));
}
function evaluateAllIndicators(candles) {
    const normalized = normalize(candles);
    return exports.INDICATOR_DEFINITIONS.map((definition) => definition.evaluate(normalized));
}
