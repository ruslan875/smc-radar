#!/usr/bin/env python3
"""
Confluence backtest: combines several ALREADY-PORTED, independently
evaluated indicator modules into one signal, firing only when N or more
of them agree on direction within a short window -- the standard
technical-analysis "confluence" idea (this is literally the same logic
that gave the SMC bot's own OB+FVG confluence filter its best-standing
result, see smc-bot-backtest doc Run 10).

WHY THIS EXISTS: the user asked for a single combined indicator hitting
>=70% win rate. Across everything tested in this project so far (SMC bot
+ 49 ported third-party indicators, 4 batches, documented in
pine-indicators-python-port doc), NOTHING has shown a real, fee-surviving,
out-of-sample edge -- and the one time a raw win rate looked great (57.1%,
liquidity_sweep_mss_fvg) it turned out to be an artifact of assuming free
instant fills; the real, fill-checked number was 30.9% and the trade was
net-negative. Win rate alone says nothing about profitability -- what
matters is net R after fees, validated out-of-sample (same split-sample
discipline used everywhere else in this project). So this script does NOT
target 70% as a design constraint (that would just be curve-fitting to
this specific historical window) -- it builds a legitimate confluence
signal and reports whatever the real numbers are: win rate AND gross/net R
AND a split-sample check, exactly like every other indicator in this
collection.

Component selection (`--components`, defaults below): 5 signal families
chosen for being conceptually DIFFERENT from each other (not just
variations on the same construct, which would just correlate and add
nothing) -- mean-reversion (RSI extreme, composite z-score divergence,
wick-cluster rejection) and trend-following (PSAR flip, EMA cross). All
five were previously tested standalone; none passed on their own, but
confluence explicitly tests whether AGREEMENT between different signal
types filters out the false positives that sink each one alone -- exactly
analogous to how "exclude BOS" and "OB+FVG only" alone did nothing for the
SMC bot, but combined they produced the closest-to-breakeven result in the
whole project (still losing, but real and split-validated).

    mopeda_zscore_divergence   -- composite RSI+StochRSI+MACD z-score divergence
    mopeda_wick_pressure_sidd  -- 3-candle wick-rejection cluster
    rsi_extreme_reversal       -- plain RSI(14) 70/30 fade
    psar_flip                  -- Parabolic SAR flip (trend-following, native stop)
    ema_cross_small            -- EMA(10)/EMA(21) cross (trend-following)

A component's signal counts as an active "vote" for `--window` bars after
it fires (default 8) -- i.e. if it fired anywhere in the last 8 bars in a
given direction, it's still "on the board" when counting votes at the
current bar. A confluence signal fires when at least `--min-votes`
(default 2) DISTINCT components are simultaneously voting the same
direction, subject to a `--cooldown` (default 15 bars) to avoid firing on
every bar while several components stay active at once. No native stop
(heterogeneous components, no single shared risk level) -- synthetic
ATR(14) stop + default 1R/2R/3R ladder, same convention as every other
synthetic-stop module in this collection.

Needs Bybit network access -- run on your own machine:

    python confluence_backtest.py --bars 3000
    python confluence_backtest.py --bars 3000 --min-votes 3
    python confluence_backtest.py --bars 17520          # once bars=3000 looks worth it
"""
from __future__ import annotations

import argparse
import importlib
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import pandas as pd

from app.config import Settings
from app.data import DataError
from app.indicators.common import Signal, atr, synthetic_stop, SYNTHETIC_ATR_LEN, SYNTHETIC_ATR_MULT
from generic_backtest import fetch_history, net_r, save_csv, simulate_outcome, summarize

DEFAULT_COMPONENTS = [
    "mopeda_zscore_divergence",
    "mopeda_wick_pressure_sidd",
    "rsi_extreme_reversal",
    "psar_flip",
    "ema_cross_small",
]


def compute_votes(df: pd.DataFrame, component_names: list[str], window: int):
    n = len(df)
    long_active = pd.DataFrame(0, index=range(n), columns=component_names)
    short_active = pd.DataFrame(0, index=range(n), columns=component_names)
    per_component_counts: dict[str, int] = {}

    for name in component_names:
        mod = importlib.import_module(f"app.indicators.{name}")
        sigs = mod.generate_signals(df)
        per_component_counts[name] = len(sigs)

        long_flags = pd.Series(0, index=range(n))
        short_flags = pd.Series(0, index=range(n))
        for s in sigs:
            idx = s.trigger_index
            if 0 <= idx < n:
                if s.direction == "long":
                    long_flags.iat[idx] = 1
                else:
                    short_flags.iat[idx] = 1
        long_active[name] = long_flags.rolling(window, min_periods=1).max()
        short_active[name] = short_flags.rolling(window, min_periods=1).max()

    long_votes = long_active.sum(axis=1).to_numpy()
    short_votes = short_active.sum(axis=1).to_numpy()
    return long_votes, short_votes, per_component_counts


def generate_confluence_signals(df: pd.DataFrame, component_names: list[str], window: int,
                                 min_votes: int, cooldown: int) -> tuple[list[Signal], dict[str, int]]:
    n = len(df)
    long_votes, short_votes, per_component_counts = compute_votes(df, component_names, window)
    close = df["close"].to_numpy()
    atr_synth = atr(df, SYNTHETIC_ATR_LEN).to_numpy()

    signals: list[Signal] = []
    last_fire_bar = -10 ** 9
    for i in range(n):
        lv, sv = long_votes[i], short_votes[i]
        direction = None
        if lv >= min_votes and lv > sv and (i - last_fire_bar) >= cooldown:
            direction = "long"
        elif sv >= min_votes and sv > lv and (i - last_fire_bar) >= cooldown:
            direction = "short"
        if direction is None:
            continue

        a_synth = atr_synth[i]
        if a_synth != a_synth:
            continue

        last_fire_bar = i
        entry = float(close[i])
        sl = synthetic_stop(entry, float(a_synth), direction, SYNTHETIC_ATR_MULT)
        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=sl,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="confluence", synthetic_stop=True,
            meta={"votes": int(max(lv, sv))},
        ))

    return signals, per_component_counts


def main() -> None:
    settings = Settings.load()
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--symbol", nargs="+", default=settings.watchlist)
    parser.add_argument("--timeframe", default=settings.timeframe)
    parser.add_argument("--bars", type=int, default=3000)
    parser.add_argument("--max-forward", type=int, default=200)
    parser.add_argument("--components", nargs="+", default=DEFAULT_COMPONENTS,
                         help="Module names under app/indicators/ to combine (default: 5 diverse families)")
    parser.add_argument("--window", type=int, default=8,
                         help="Bars a component's signal stays 'active' (counted as a vote) after firing")
    parser.add_argument("--min-votes", type=int, default=2,
                         help="Distinct components required to agree on direction to fire a confluence signal")
    parser.add_argument("--cooldown", type=int, default=15,
                         help="Min bars between confluence signals")
    parser.add_argument("--out", default="generic_backtest_out")
    args = parser.parse_args()

    print(f"Components: {', '.join(args.components)}")
    print(f"window={args.window}  min_votes={args.min_votes}  cooldown={args.cooldown}\n")

    out_dir = Path(args.out) / "confluence"
    all_trades: list[dict] = []
    totals_per_component: dict[str, int] = {name: 0 for name in args.components}

    for symbol in [s.upper() for s in args.symbol]:
        print(f"Fetching + simulating {symbol} ({args.bars} bars of {args.timeframe})...")
        try:
            df = fetch_history(symbol, args.timeframe, args.bars)
        except DataError as exc:
            print(f"  [SKIP] {symbol}: {exc}")
            continue

        signals, per_component_counts = generate_confluence_signals(
            df, args.components, args.window, args.min_votes, args.cooldown)
        for name, cnt in per_component_counts.items():
            totals_per_component[name] += cnt

        trades: list[dict] = []
        for sig in signals:
            outcome = simulate_outcome(df, sig, args.max_forward)
            trades.append({
                "symbol": symbol, "label": sig.label, "direction": sig.direction,
                "entry": sig.entry, "stop_loss": sig.stop_loss,
                "synthetic_stop": sig.synthetic_stop, "time": sig.trigger_time,
                "votes": sig.meta.get("votes"), **outcome,
            })
        summarize(trades, symbol)
        save_csv(trades, out_dir / f"{symbol}_trades.csv")
        all_trades.extend(trades)

    print("\n" + "=" * 78)
    print("Per-component signal counts (standalone, before confluence filtering)")
    print("=" * 78)
    for name, cnt in totals_per_component.items():
        print(f"  {name:28s} {cnt}")

    summarize(all_trades, "=== COMBINED (confluence, all symbols) ===")

    resolved = [t for t in all_trades if t["r"] is not None]
    times = sorted(t["time"] for t in resolved)
    if len(times) >= 20:
        cutoff = times[len(times) // 2]
        early = [t for t in all_trades if t["time"] < cutoff]
        late = [t for t in all_trades if t["time"] >= cutoff]
        print(f"\n{'=' * 78}\nSPLIT-SAMPLE (split at {cutoff})\n{'=' * 78}")
        summarize(early, "Earlier half")
        summarize(late, "Later half")
        print(
            "\nReading this: only treat the confluence signal as a real, worth-pursuing "
            "result if BOTH halves are net-positive independently on at least the "
            "maker+maker fee scenario, with >=20 resolved trades each. Positive in only "
            "one half, or only on the combined/unsplit number, is curve-fitting -- the "
            "same trap that already produced false positives elsewhere in this project "
            "(parad_wt/parad_rsi, liquidity_sweep_mss_fvg before its fill-check)."
        )
    else:
        print(f"\nOnly {len(times)} resolved trades total -- too few for a meaningful split-sample check "
              f"(need >=20 per half). Try a longer --bars window or a lower --min-votes before drawing "
              f"any conclusion.")

    print(f"\nPer-trade CSVs written to {out_dir.resolve()}")


if __name__ == "__main__":
    main()
