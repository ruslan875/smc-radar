# -*- coding: utf-8 -*-
"""Партия 2 (2026-10-08): индикаторы с сигналами. Единый выход: стоп 1.5 ATR, тейк 2R (ICT — свой стоп за свип, 2R)."""
import os, sys, glob
import numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from new_ind_test import load, atr, rsi, ema, rma, sim_r, summarize

def S(x): return pd.Series(x)
def wma(x, n):
    w = np.arange(1, n + 1); return S(x).rolling(n).apply(lambda a: (a * w).sum() / w.sum(), raw=True).values
def hma(x, n): return wma(2 * wma(x, n // 2) - wma(x, n), int(round(np.sqrt(n))))
def cross_up(a, b, i): return a[i] > b[i] and a[i - 1] <= b[i - 1]
def stops(d, sides, k=1.5):
    A = atr(d); C = d.c.values
    return [(i, s, C[i] - s * k * A[i]) for i, s in sides if not np.isnan(A[i])]

def atrpro(d):   # поглощение + устойчивая свеча + RSI<50 + падение за 5 свечей
    O, H, L, C = d.o.values, d.h.values, d.l.values, d.c.values
    tr = np.maximum(H - L, np.maximum(abs(H - np.roll(C, 1)), abs(L - np.roll(C, 1))))
    R = rsi(C); out = []
    for i in range(6, len(C)):
        st = tr[i] > 0 and abs(C[i] - O[i]) / tr[i] > 0.5
        if C[i-1] < O[i-1] and C[i] > O[i] and C[i] > O[i-1] and st and R[i] < 50 and C[i] < C[i-5]: out.append((i, 1))
        elif C[i-1] > O[i-1] and C[i] < O[i] and C[i] < O[i-1] and st and R[i] > 50 and C[i] > C[i-5]: out.append((i, -1))
    return out

def ewa(d):      # Willy(21)/EMA13 кросс + SSL-выход HMA15 кросс на той же свече
    H, L, C = d.h.values, d.l.values, d.c.values
    up = S(C).rolling(21).max().values; lo = S(C).rolling(21).min().values
    w = 100 * (C - up) / np.where(up - lo == 0, np.nan, up - lo); we = ema(np.nan_to_num(w), 13)
    eh, el = hma(H, 15), hma(L, 15); hl = np.zeros(len(C)); ssl = np.full(len(C), np.nan)
    for i in range(1, len(C)):
        hl[i] = 1 if C[i] > eh[i] else -1 if C[i] < el[i] else hl[i-1]
        ssl[i] = eh[i] if hl[i] < 0 else el[i]
    out = []
    for i in range(30, len(C)):
        if cross_up(w, we, i) and C[i] > ssl[i] and C[i-1] <= ssl[i-1]: out.append((i, 1))
        elif cross_up(we, w, i) and C[i] < ssl[i] and C[i-1] >= ssl[i-1]: out.append((i, -1))
    return out

def gtrend(d):   # G-Channel флип + фильтр CCI(20)
    C = d.c.values; n = len(C); a = np.zeros(n); b = np.zeros(n)
    for i in range(n):
        pa, pb = (a[i-1], b[i-1]) if i else (0, 0)
        a[i] = max(C[i], pa) - (pa - pb) / 100; b[i] = min(C[i], pb) + (pa - pb) / 100
    tp = (d.h + d.l + d.c) / 3; cci = ((tp - tp.rolling(20).mean()) / (0.015 * tp.rolling(20).apply(lambda x: abs(x - x.mean()).mean(), raw=True))).values
    cu = cd = -1; bull = np.zeros(n, bool); out = []
    for i in range(1, n):
        if b[i-1] < C[i-1] and b[i] > C[i]: cu = i
        if a[i-1] < C[i-1] and a[i] > C[i]: cd = i
        bull[i] = (i - cd) <= (i - cu) if cd >= 0 and cu >= 0 else cd < 0 and cu >= 0
        if i > 120 and bull[i] != bull[i-1]:
            if bull[i] and cci[i] >= 0: out.append((i, 1))
            elif not bull[i] and cci[i] < 0: out.append((i, -1))
    return out

def zerolag(d, length=50):
    C = d.c.values; lag = (length - 1) // 2
    zl = ema(C + (C - np.roll(C, lag)), length); A = atr(d, length)
    vol = S(A).rolling(length * 3).max().values * 1.5; tr = 0; out = []
    for i in range(length * 3 + 70, len(C)):
        sc = sum(1 if zl[i] > zl[i-k] else -1 for k in range(1, 71))
        nt = 1 if (sc > 5 and C[i] > zl[i] + vol[i]) else -1 if (sc < -5 and C[i] < zl[i] - vol[i]) else tr
        if nt != tr and tr != 0: out.append((i, nt))
        tr = nt
    return out

def twinrange(d):
    C = d.c.values
    def smr(t, m): return ema(ema(np.abs(np.diff(C, prepend=C[0])), t), 2 * t - 1) * m
    r = (smr(27, 1.6) + smr(55, 2.0)) / 2; f = np.zeros(len(C)); f[0] = C[0]
    for i in range(1, len(C)):
        p = f[i-1]; f[i] = (p if C[i] - r[i] < p else C[i] - r[i]) if C[i] > p else (p if C[i] + r[i] > p else C[i] + r[i])
    up = dn = 0; ci = 0; out = []
    for i in range(1, len(C)):
        up = up + 1 if f[i] > f[i-1] else 0 if f[i] < f[i-1] else up
        dn = dn + 1 if f[i] < f[i-1] else 0 if f[i] > f[i-1] else dn
        lc = C[i] > f[i] and up > 0; sc = C[i] < f[i] and dn > 0
        if i > 120 and lc and ci == -1: out.append((i, 1))
        elif i > 120 and sc and ci == 1: out.append((i, -1))
        ci = 1 if lc else -1 if sc else ci
    return out

def hema_cross(d):   # Gradient Trend: HEMA20/40 кросс + цена по ту же сторону от фильтра
    C = d.c.values
    def hema(n): return ema(2 * ema(C, max(1, round(n / 2))) - ema(C, n), max(1, round(np.sqrt(n))))
    h1, h2 = hema(20), hema(40); base = ema(ema(ema(C, 25), 25), 25); out = []
    for i in range(60, len(C)):
        if cross_up(h1, h2, i) and C[i] > base[i]: out.append((i, 1))
        elif cross_up(h2, h1, i) and C[i] < base[i]: out.append((i, -1))
    return out

def vol_revert(d):   # возврат в зону EMA14 ± 1.5 ATR
    C = d.c.values; A = atr(d); b = ema(C, 14); lo = ema(b - 1.5 * A, 3); hi = ema(b + 1.5 * A, 3); out = []
    for i in range(30, len(C)):
        if cross_up(C, lo, i): out.append((i, 1))
        elif cross_up(hi, C, i): out.append((i, -1))
    return out

def dvortex(d):   # RSI7 выход из 30/70 + закрытие за серединой свечи (объём — только крипта)
    C, H, L = d.c.values, d.h.values, d.l.values; R = rsi(C, 7); m = (H + L) / 2
    v = d["v"].values if "v" in d else None
    vok = (v > S(v).rolling(100).mean().values) if v is not None else np.ones(len(C), bool)
    out = []
    for i in range(110, len(C)):
        if R[i] > 30 and R[i-1] <= 30 and vok[i] and C[i] > m[i]: out.append((i, 1))
        elif R[i] < 70 and R[i-1] >= 70 and vok[i] and C[i] < m[i]: out.append((i, -1))
    return out

def supertrend_flip(d, f=3.0, n=10):   # Wave Confluence: смена направления Supertrend
    H, L, C = d.h.values, d.l.values, d.c.values; A = atr(d, n); hl = (H + L) / 2
    up = hl - f * A; dn = hl + f * A; fu = up.copy(); fd = dn.copy(); dr = np.ones(len(C)); out = []
    for i in range(1, len(C)):
        fu[i] = max(up[i], fu[i-1]) if C[i-1] > fu[i-1] else up[i]
        fd[i] = min(dn[i], fd[i-1]) if C[i-1] < fd[i-1] else dn[i]
        dr[i] = 1 if C[i] > fd[i-1] else -1 if C[i] < fu[i-1] else dr[i-1]
        if i > 30 and dr[i] != dr[i-1]: out.append((i, int(dr[i])))
    return out

def fib_env(d):   # AI_Vanga ATR Fibonacci Envelopes: смена тренда при пробое RMA100 ± 3 ATR100
    C = d.c.values; b = rma(C, 100); A = atr(d, 100); u = b + 3 * A; l = b - 3 * A; t = 0; out = []
    for i in range(101, len(C)):
        nt = 1 if (C[i] > u[i] and C[i-1] <= u[i-1]) else -1 if (C[i] < l[i] and C[i-1] >= l[i-1]) else t
        if nt != t: out.append((i, nt))
        t = nt
    return out

def ict(d, piv=8, intl=3, maxw=20):   # Liquidity Sweep -> MSS -> FVG, стоп за свип, 2R
    O, H, L, C = d.o.values, d.h.values, d.l.values, d.c.values; A = atr(d); n = len(C)
    sh = sl = ih = il = np.nan; ht = lt = False; st = 0; sigs = []
    def piv_at(arr, i, k, hi):
        j = i - k
        if j - k < 0: return False
        w = arr[j - k:i + 1]; return arr[j] == (w.max() if hi else w.min())
    for i in range(n):
        if piv_at(H, i, piv, True): sh, ht = H[i - piv], False
        if piv_at(L, i, piv, False): sl, lt = L[i - piv], False
        if piv_at(H, i, intl, True): ih = H[i - intl]
        if piv_at(L, i, intl, False): il = L[i - intl]
        if st == 1:
            wt += 1
            if wt > maxw: st = 0
            elif (dr == 1 and C[i] > mss) or (dr == -1 and C[i] < mss):
                e = mss
                for j in range(0, min(wt + 4, 18) + 1):
                    if i - j - 2 < 0: break
                    if dr == 1 and L[i-j] > H[i-j-2]: e = L[i-j]; break
                    if dr == -1 and H[i-j] < L[i-j-2]: e = H[i-j]; break
                if abs(e - ext) > 0.2 * A[i] and (e - ext) * dr > 0:
                    sigs.append((i, dr, ext, e))
                st = 0
            continue
        if not np.isnan(sl) and not lt and L[i] < sl and C[i] > sl and not np.isnan(ih) and ih > C[i]:
            lt = True; st, dr, ext, mss, wt = 1, 1, L[i], ih, 0
        elif not np.isnan(sh) and not ht and H[i] > sh and C[i] < sh and not np.isnan(il) and il < C[i]:
            ht = True; st, dr, ext, mss, wt = 1, -1, H[i], il, 0
    return sigs

def sim_limit(d, sigs, rr, fee, wait=10):   # лимит на краю FVG, ждём заполнения до 10 свечей
    H, L, C = d.h.values, d.l.values, d.c.values; out = []; busy = -1
    for i, s, stp, e in sigs:
        if i <= busy: continue
        f = next((j for j in range(i + 1, min(i + 1 + wait, len(C))) if (L[j] <= e if s > 0 else H[j] >= e)), None)
        if f is None: continue
        risk = abs(e - stp); tp = e + s * rr * risk; r = None
        for j in range(f, len(C)):
            if (L[j] <= stp) if s > 0 else (H[j] >= stp): r = -1.0; break
            if j > f and ((H[j] >= tp) if s > 0 else (L[j] <= tp)): r = rr; break
        if r is None: r = s * (C[-1] - e) / risk; j = len(C) - 1
        out.append((d.index[i], r - 2 * fee * e / risk)); busy = j
    return out

def main():
    CACHE = sys.argv[1]; Y = os.path.join(CACHE, "yahoo"); B = os.path.join(CACHE, "binance")
    gf = [os.path.join(Y, f) for f in ("GC_F_1h.csv", "EURUSD_X_1h.csv")]
    sets = [("TradFi 1h", gf, "raw", 0.00005), ("TradFi 4h", gf, "4h", 0.00005),
            ("TradFi 1D", sorted(glob.glob(os.path.join(Y, "*_1d.csv"))), "raw", 0.00005),
            ("Крипта 4h", sorted(glob.glob(os.path.join(B, "*_1h.csv"))), "4h", 0.00055),
            ("Крипта 1h", sorted(glob.glob(os.path.join(B, "*_1h.csv"))), "raw", 0.00055)]
    systems = [("ATrPro: поглощение", atrpro), ("EWA Profit Day: Willy+SSL", ewa), ("G-Trend + CCI", gtrend),
               ("Zero Lag: смена тренда", zerolag), ("Twin Range", twinrange), ("Gradient: HEMA 20/40", hema_cross),
               ("Volatility Reversion Zones", vol_revert), ("Double Vortex RSI7", dvortex),
               ("Wave Confluence (Supertrend)", supertrend_flip), ("AI_Vanga ATR-Fib конверт", fib_env)]
    rows = []
    for gname, files, tf, fee in sets:
        data = {}
        for f in files:
            if os.path.exists(f):
                dd = pd.read_csv(f); dd.index = pd.to_datetime(dd.t.astype("int64"), unit="ms")
                dd = dd[["o", "h", "l", "c", "v"]].astype(float); dd = dd[(dd.h > 0) & (dd.l > 0)]
                if tf != "raw": dd = dd.resample(tf).agg({"o": "first", "h": "max", "l": "min", "c": "last", "v": "sum"}).dropna()
                if "yahoo" in f: dd = dd.drop(columns="v")
                if len(dd) > 400: data[os.path.basename(f).split("_")[0].replace("USDT", "")] = dd
        allsys = [(n, (lambda fn: lambda d: sim_r(d, stops(d, fn(d)), 2, fee))(fn)) for n, fn in systems]
        allsys.append(("ICT: свип→MSS→FVG (лимит), 2R", lambda d: sim_limit(d, ict(d), 2, fee)))
        for sname, fn in allsys:
            per = []
            for sym, d in data.items():
                t = pd.DataFrame(fn(d), columns=["t", "r"])
                if t.empty: continue
                mid = d.index[0] + (d.index[-1] - d.index[0]) / 2
                per.append((sym, len(t), t.r.sum(), t[t.t < mid].r.sum(), t[t.t >= mid].r.sum(), t.r[t.r > 0].sum(), -t.r[t.r < 0].sum()))
            s = summarize(sname, gname, per)
            if s:
                rows.append(s)
                print(f"{s['вердикт']} {gname:10} {sname:34} сд {s['сделок']:5} PF {s['PF']:5} R {s['итог']:+8.1f} ({s['на_сделку']:+.3f}) H1 {s['половина1']:+7.1f} H2 {s['половина2']:+7.1f} ок {s['инстр_ok']} [{s['лучшие']}]", flush=True)
    pd.DataFrame(rows).to_csv(os.path.join(os.path.dirname(os.path.abspath(__file__)), "new_indicators_test2.csv"), index=False, encoding="utf-8-sig")

if __name__ == "__main__":
    main()
