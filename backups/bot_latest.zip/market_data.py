#!/usr/bin/env python3
"""
Shared OHLCV loader for every backtest in this project
=======================================================

Written 20.09.2026 after two failures in one session, both caused by the
loader that had been copy-pasted into each backtest script separately.

WHAT WENT WRONG, AND WHY IT MATTERS
-----------------------------------
1. WRONG MARKET. ccxt's bybit defaults to the SPOT market, so every run up
   to now silently fetched spot candles:

       api.bybit.com/v5/market/kline?symbol=ETHUSDT&...&category=spot

   The bots trade USDT-margined PERPETUALS. Spot and perp OHLC track each
   other closely on liquid pairs, so earlier conclusions are unlikely to
   flip, but the instrument under test was simply not the instrument being
   traded. This module defaults to `swap` and prints which market it used,
   so the mistake cannot be silent again.

2. NO RATE LIMIT, NO RETRY. A year of 15m candles is ~35,000 bars, i.e.
   ~117 sequential requests per symbol. Fired back-to-back with ccxt's
   10-second timeout and no retry, Bybit stops answering partway through
   and the whole run dies with RequestTimeout. Here: rate limiting on,
   30-second timeout, and retries with exponential backoff.

3. PAGINATION THAT STOPPED EARLY. The old loop did `if len(batch) < limit:
   break`. Exchanges routinely return a short page mid-history, so a run
   could end quietly on partial data and report metrics computed from a
   fraction of the requested period, with nothing in the output saying so.
   This loop stops only on an empty page or a cursor that stops advancing,
   and it tells you how many bars it actually got.

4. NO CACHE. Every strategy re-downloaded the same candles. Now each
   (exchange, market, symbol, timeframe) is cached to CSV under
   `market_cache/` and re-used whenever the requested window is covered.
   Re-running a backtest after a code change is then instant and puts zero
   load on the exchange.

USAGE

    from market_data import load_ohlcv

    df = load_ohlcv("BTC/USDT", "1h", "2024-01-01", "2025-12-31",
                    exchange_id="bybit", market="swap")

Returns a DataFrame indexed by UTC timestamp with open/high/low/close/volume.
"""

from __future__ import annotations

import sys
import time
from pathlib import Path

import pandas as pd

CACHE_DIR = Path(__file__).resolve().parent / "market_cache"

# ccxt timeframe -> milliseconds, for gap detection and cursor stepping
_TF_MS = {
    "1m": 60_000, "3m": 180_000, "5m": 300_000, "15m": 900_000,
    "30m": 1_800_000, "1h": 3_600_000, "2h": 7_200_000, "4h": 14_400_000,
    "6h": 21_600_000, "12h": 43_200_000, "1d": 86_400_000,
}


def _cache_path(exchange_id: str, market: str, symbol: str, timeframe: str) -> Path:
    safe = symbol.replace("/", "").replace(":", "")
    return CACHE_DIR / f"{exchange_id}_{market}_{safe}_{timeframe}.csv"


def _read_cache(path: Path) -> pd.DataFrame | None:
    if not path.exists():
        return None
    try:
        df = pd.read_csv(path, parse_dates=["timestamp"])
        return df.set_index("timestamp").sort_index()
    except Exception as exc:  # a corrupt cache must never kill a run
        print(f"  cache unreadable ({exc}); refetching", file=sys.stderr)
        return None


def _write_cache(path: Path, df: pd.DataFrame) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    df.reset_index().rename(columns={"index": "timestamp"}).to_csv(path, index=False)


def _make_exchange(exchange_id: str, market: str):
    try:
        import ccxt
    except ImportError:
        print("ERROR: ccxt not installed. Run: pip install ccxt", file=sys.stderr)
        sys.exit(1)

    return getattr(ccxt, exchange_id)({
        "enableRateLimit": True,   # ccxt then paces requests for us
        "timeout": 30_000,         # 10s default is too tight for long pulls
        "options": {"defaultType": market},   # swap = USDT perpetual
    })


def _fetch_range(exchange, symbol: str, timeframe: str,
                 since_ms: int, end_ms: int, max_retries: int = 5) -> list:
    """Page through OHLCV, retrying each page instead of losing the run."""
    step = _TF_MS.get(timeframe, 3_600_000)
    rows, cursor, limit = [], since_ms, 1000
    stall_guard = 0

    while cursor < end_ms:
        batch = None
        for attempt in range(max_retries):
            try:
                batch = exchange.fetch_ohlcv(symbol, timeframe=timeframe,
                                             since=cursor, limit=limit)
                break
            except Exception as exc:
                wait = 2 ** attempt
                name = type(exc).__name__
                print(f"    {name} on page at {pd.to_datetime(cursor, unit='ms')}, "
                      f"retry {attempt + 1}/{max_retries} in {wait}s", file=sys.stderr)
                time.sleep(wait)
        if batch is None:
            raise RuntimeError(
                f"{symbol}: {max_retries} consecutive failures fetching the page "
                f"starting {pd.to_datetime(cursor, unit='ms')}. Partial data is NOT "
                f"returned - rerun and the cache will resume from what succeeded."
            )
        if not batch:
            break

        rows.extend(batch)
        last_ts = batch[-1][0]
        # Short pages are normal; only a cursor that refuses to advance means
        # we are done (or stuck).
        new_cursor = last_ts + step
        if new_cursor <= cursor:
            stall_guard += 1
            if stall_guard >= 3:
                break
            new_cursor = cursor + step * limit
        else:
            stall_guard = 0
        cursor = new_cursor

    return rows


def load_ohlcv(symbol: str, timeframe: str, start: str, end: str,
               exchange_id: str = "bybit", market: str = "swap",
               use_cache: bool = True) -> pd.DataFrame:
    """Load OHLCV for [start, end], from cache when possible."""
    start_ts = pd.Timestamp(start)
    end_ts = pd.Timestamp(end) + pd.Timedelta(days=1)  # inclusive end date

    path = _cache_path(exchange_id, market, symbol, timeframe)
    cached = _read_cache(path) if use_cache else None

    if cached is not None and len(cached) > 0:
        if cached.index.min() <= start_ts and cached.index.max() >= end_ts - pd.Timedelta(_TF_MS.get(timeframe, 3_600_000), unit="ms"):
            sel = cached[(cached.index >= start_ts) & (cached.index < end_ts)]
            print(f"  {symbol} {timeframe} [{market}]: {len(sel)} bars from cache")
            return sel[["open", "high", "low", "close", "volume"]]

    exchange = _make_exchange(exchange_id, market)
    since_ms = int(start_ts.timestamp() * 1000)
    end_ms = int(end_ts.timestamp() * 1000)

    # Widen the pull to cover what the cache already holds, so the file stays
    # one contiguous block rather than a set of islands.
    if cached is not None and len(cached) > 0:
        since_ms = min(since_ms, int(cached.index.min().timestamp() * 1000))
        end_ms = max(end_ms, int(cached.index.max().timestamp() * 1000) + 1)

    print(f"  {symbol} {timeframe} [{market}]: downloading from {exchange_id}...")
    rows = _fetch_range(exchange, symbol, timeframe, since_ms, end_ms)
    if not rows:
        raise RuntimeError(
            f"No OHLCV returned for {symbol} ({market}) on {exchange_id}. "
            f"Check the symbol exists on that market - perpetuals may need "
            f"the '{symbol}:USDT' form on some exchanges."
        )

    df = pd.DataFrame(rows, columns=["timestamp", "open", "high", "low", "close", "volume"])
    df["timestamp"] = pd.to_datetime(df["timestamp"], unit="ms")
    df = df.set_index("timestamp").sort_index()
    df = df[~df.index.duplicated(keep="first")]

    if cached is not None and len(cached) > 0:
        df = pd.concat([cached, df])
        df = df[~df.index.duplicated(keep="last")].sort_index()

    if use_cache:
        _write_cache(path, df)

    sel = df[(df.index >= start_ts) & (df.index < end_ts)]
    span = f"{sel.index.min()} -> {sel.index.max()}" if len(sel) else "empty"
    print(f"  {symbol} {timeframe} [{market}]: {len(sel)} bars  ({span})")

    # A run on a third of the requested window should not look like a success.
    expected = (end_ts - start_ts).total_seconds() * 1000 / _TF_MS.get(timeframe, 3_600_000)
    if len(sel) < expected * 0.8:
        print(f"    WARNING: got {len(sel)} bars, expected roughly {int(expected)}. "
              f"History may not reach that far back on this market.", file=sys.stderr)

    return sel[["open", "high", "low", "close", "volume"]]
