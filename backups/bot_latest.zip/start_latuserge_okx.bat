@echo off
REM Latuserge на OKX. Двойной клик = БУМАГА (без реальных ордеров, цены OKX для размеров).
REM Реальные ордера: из терминала  .\start_latuserge_okx.bat --live --capital-per-deal 100 --leverage 5
REM Нужен ОТДЕЛЬНЫЙ ключ OKX: в Telegram /tradekey latuserge okx KEY SECRET PASSPHRASE
cd /d "%~dp0"
venv\Scripts\python.exe latuserge_okx.py %*
echo.
pause >nul
