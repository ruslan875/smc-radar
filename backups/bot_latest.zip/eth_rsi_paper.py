"""ETH_H4 RSI Trend Filter (с исправленным стопом) — paper-тест. 2026-09-26.

Оригинальный Pine ставил `stop=` в strategy.entry — это стоп-ВХОД, стоп-лосса
не было. Здесь (как в бэктесте /home/claude/bt/strategies.py::eth_rsi):
  вход LONG:  RSI(14) пересёк 70 вверх и close > SMA(20)
  вход SHORT: RSI(14) пересёк 30 вниз и close < SMA(20)
  стоп 2·ATR(14) от входа; трейлинг 1.5·ATR от экстремума после хода +2·ATR;
  выход: RSI пересёк 50 против позиции.
Бэктест 2024 → 2025-26 (PF): BTC 1.10→1.12, ETH 1.44→1.59, SOL 0.85→1.11, DOGE 1.63→1.35.

Только бумага: ни одного ордера на бирже. Свечи Bybit USDT-perp, 4h, решения
на закрытой свече; стоп/тейк проверяются по high/low закрытой свечи (оба в одной
свече → стоп), как в бэктесте.

Запуск:  venv\\Scripts\\python.exe eth_rsi_paper.py
         (--deposit 100 --leverage 2 --symbols BTC,ETH,SOL,DOGE)
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))
STATE = BASE_DIR / "eth_rsi_paper_state.json"
TRADES = BASE_DIR / "eth_rsi_paper_trades.csv"
FEE = 0.00055


def rma(s, n):
    return s.ewm(alpha=1 / n, adjust=False).mean()


def indicators(df):
    d = df.close.diff()
    rsi = 100 - 100 / (1 + rma(d.clip(lower=0), 14) / rma(-d.clip(upper=0), 14))
    pc = df.close.shift()
    tr = pd.concat([df.high - df.low, (df.high - pc).abs(), (df.low - pc).abs()], axis=1).max(axis=1)
    return rsi, df.close.rolling(20).mean(), rma(tr, 14)


def _notifier():
    try:
        from dotenv import load_dotenv
        load_dotenv(BASE_DIR / ".env")
        from app.config import Settings
        from app.telegram_client import TelegramClient
        from app import notify_prefs
        s = Settings.load()
        if not s.telegram_token or not s.telegram_chat_id:
            return None
        tg = TelegramClient(s.telegram_token, s.telegram_chat_id)

        def send(text):
            if not notify_prefs.is_enabled("paper"):
                return
            try:
                tg.send_message(text)
            except Exception as exc:  # noqa: BLE001
                import re as _re   # не печатаем токен бота из URL ошибки
                print("[TG] " + _re.sub(r"bot\d{6,}:[A-Za-z0-9_-]{20,}", "bot***", str(exc))[:200], file=sys.stderr)
        return send
    except Exception as exc:  # noqa: BLE001
        print(f"[TG] уведомления выключены: {exc}", file=sys.stderr)
        return None


def log_trade(row):
    new = not TRADES.exists()
    with TRADES.open("a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(row))
        if new:
            w.writeheader()
        w.writerow(row)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--symbols", default="BTC,ETH,SOL,DOGE")
    ap.add_argument("--deposit", type=float, default=100.0)
    ap.add_argument("--leverage", type=float, default=2.0)
    p = ap.parse_args()
    import ccxt
    ex = ccxt.bybit({"enableRateLimit": True, "timeout": 30_000, "options": {"defaultType": "swap"}})
    notify = _notifier()
    syms = [s.strip().upper() for s in p.symbols.split(",") if s.strip()]
    st = json.loads(STATE.read_text(encoding="utf-8")) if STATE.exists() else {}
    st.setdefault("equity", p.deposit); st.setdefault("started", datetime.now(timezone.utc).isoformat())
    st.setdefault("pos", {}); st.setdefault("last_bar", {})
    per_sym = p.deposit * p.leverage / len(syms)       # номинал позиции на монету

    def save():
        STATE.write_text(json.dumps(st, ensure_ascii=False, indent=1), encoding="utf-8")

    print(f"[ETH-RSI paper] {syms} 4h · депозит {p.deposit} · x{p.leverage} · {per_sym:.1f} USDT на монету")
    if notify:
        notify(f"🧪 <b>Paper-тест запущен</b>: ETH RSI Trend Filter 4h\n{', '.join(syms)} · депозит {p.deposit} USDT · x{p.leverage}")
    save()
    while True:
        for sym in syms:
            try:
                raw = ex.fetch_ohlcv(f"{sym}/USDT:USDT", "4h", limit=200)
                df = pd.DataFrame(raw, columns=["t", "open", "high", "low", "close", "volume"])
                df = df.iloc[:-1]                           # только закрытые свечи
                last_t = int(df.t.iloc[-1])
                if st["last_bar"].get(sym) == last_t:
                    continue
                st["last_bar"][sym] = last_t
                rsi, ma, atr = indicators(df)
                bar = df.iloc[-1]; r0, r1 = rsi.iloc[-1], rsi.iloc[-2]; a = atr.iloc[-1]
                when = datetime.fromtimestamp(last_t / 1000, timezone.utc).strftime("%Y-%m-%d %H:%M")
                pos = st["pos"].get(sym)
                if pos:
                    side, ep, sl = pos["side"], pos["entry"], pos["sl"]
                    exit_px, why = None, None
                    if side == 1 and bar.low <= sl: exit_px, why = min(sl, bar.open), "стоп"
                    elif side == -1 and bar.high >= sl: exit_px, why = max(sl, bar.open), "стоп"
                    elif side == 1 and r0 < 50 <= r1: exit_px, why = bar.close, "RSI<50"
                    elif side == -1 and r0 > 50 >= r1: exit_px, why = bar.close, "RSI>50"
                    if exit_px:
                        pnl_pct = side * (exit_px / ep - 1) - 2 * FEE
                        usdt = pnl_pct * per_sym
                        st["equity"] += usdt
                        log_trade({"symbol": sym, "side": "LONG" if side == 1 else "SHORT", "entry_time": pos["time"],
                                   "entry": ep, "exit_time": when, "exit": exit_px, "reason": why,
                                   "pnl_pct": round(pnl_pct * 100, 3), "pnl_usdt": round(usdt, 3), "equity": round(st["equity"], 2)})
                        st["pos"][sym] = None; pos = None
                        msg = (f"{'✅' if usdt > 0 else '❌'} <b>{sym} {'LONG' if side == 1 else 'SHORT'}</b> "
                               f"{pnl_pct*100:+.2f}% ({usdt:+.2f}$) · {why}\nETH RSI 4h · paper · баланс {st['equity']:.2f}")
                        print(msg.replace("<b>", "").replace("</b>", ""))
                        if notify: notify(msg)
                    else:                                    # трейлинг после +2 ATR
                        if side == 1 and bar.high >= ep + 2 * a: pos["sl"] = max(sl, bar.high - 1.5 * a)
                        if side == -1 and bar.low <= ep - 2 * a: pos["sl"] = min(sl, bar.low + 1.5 * a)
                if not pos:
                    side = 1 if (r0 > 70 >= r1 and bar.close > ma.iloc[-1]) else (-1 if (r0 < 30 <= r1 and bar.close < ma.iloc[-1]) else 0)
                    if side:
                        sl = bar.close - 2 * a if side == 1 else bar.close + 2 * a
                        st["pos"][sym] = {"side": side, "entry": float(bar.close), "sl": float(sl), "time": when}
                        msg = (f"{'🟢' if side == 1 else '🔴'} <b>{sym} — вход {'LONG' if side == 1 else 'SHORT'}</b> "
                               f"{bar.close:.6g}\nстоп {sl:.6g} · ETH RSI 4h · paper")
                        print(msg.replace("<b>", "").replace("</b>", ""))
                        if notify: notify(msg)
                save()
            except Exception as exc:  # noqa: BLE001 -- сеть/биржа: пробуем в следующий круг
                print(f"[{sym}] {exc}", file=sys.stderr)
        time.sleep(60)


if __name__ == "__main__":
    main()
