# -*- coding: utf-8 -*-
"""Pavlova Combo(OB+TC+MF) — порт Pine + настройки PAVLOVA_BTC_1H_OKX.csv. Вход по закрытию (process_orders_on_close),
выход стоп 1.8% / тейк 4.6% от входа со следующей свечи. 100% депозита, компаунд. nOI: OI нет -> фильтр пропускает."""
import sys, numpy as np, pandas as pd
P = dict(tc=9, mfi=9, mfi_ob=75, mfi_os=14, adxL=(15, 75), adxS=(16, 75), impS=0.02, cvd_len=300, cvd_sm=20,
         cvdL=(0, 99), cvdS=(0, 96), rsi_len=15, rsiL=(38, 74), rsiS=(20, 63), chopS=65, kc=6.4, natrL=(0.3, 1.09), natrS=(0.42, 1.2),
         sl=1.8, tp=4.6)
def rma(x, n):
    x = pd.Series(x); out = np.full(len(x), np.nan); v = x.values; s = None
    for i in range(len(v)):
        if np.isnan(v[i]): continue
        if s is None:
            if i >= n - 1 and not np.isnan(v[i-n+1:i+1]).any(): s = v[i-n+1:i+1].mean()
            else: continue
        else: s = (s * (n - 1) + v[i]) / n
        out[i] = s
    return out
def ema(x, n):
    x = pd.Series(x).values; out = np.full(len(x), np.nan); a = 2 / (n + 1); s = None
    for i in range(len(x)):
        if s is None:
            if i >= n - 1: s = x[i-n+1:i+1].mean()
            else: continue
        else: s = a * x[i] + (1 - a) * s
        out[i] = s
    return out
def run(d, fee):
    O, H, L, C, V = [d[k].values for k in "ohlcv"]; n = len(C); pc = np.r_[np.nan, C[:-1]]
    tr = np.nanmax(np.vstack([H - L, abs(H - pc), abs(L - pc)]), axis=0); tr[0] = H[0] - L[0]
    up = H - np.r_[np.nan, H[:-1]]; dn = np.r_[np.nan, L[:-1]] - L
    pdm = np.where((up > dn) & (up > 0), up, 0.); mdm = np.where((dn > up) & (dn > 0), dn, 0.)
    trs = rma(tr, 14); pdi = 100 * rma(pdm, 14) / trs; mdi = 100 * rma(mdm, 14) / trs
    adx = rma(np.where(pdi + mdi != 0, 100 * abs(pdi - mdi) / (pdi + mdi), 0), 14)
    etc = ema(C, P["tc"]); tcup = etc > np.r_[np.nan, etc[:-1]]
    tp = (H + L + C) / 3; mf = tp * V; ch = np.diff(tp, prepend=np.nan)
    pos = pd.Series(np.where(ch > 0, mf, 0)).rolling(P["mfi"]).sum().values; neg = pd.Series(np.where(ch < 0, mf, 0)).rolling(P["mfi"]).sum().values
    mfi = 100 - 100 / (1 + pos / np.where(neg == 0, np.nan, neg)); mfi = np.where(neg == 0, 100, mfi)
    delta = np.where(C > O, V, np.where(C < O, -V, 0.)); cum = np.cumsum(delta)
    roll = cum - pd.Series(cum).shift(P["cvd_len"]).fillna(0).values; sm = ema(roll, P["cvd_sm"])
    am = np.maximum(abs(pd.Series(sm).rolling(P["cvd_len"]).max().values), abs(pd.Series(sm).rolling(P["cvd_len"]).min().values))
    cvd = (np.where(am != 0, sm / am, 0) + 1) * 50
    chg = np.diff(C, prepend=np.nan); r = 100 - 100 / (1 + rma(np.maximum(chg, 0), P["rsi_len"]) / rma(np.maximum(-chg, 0), P["rsi_len"]))
    pcl = np.r_[np.nan, C[:-1]]; trt = np.nanmax(np.vstack([H - L, abs(H - pcl), abs(L - pcl)]), axis=0)
    lo = pd.Series(np.where(L <= pcl, L, pcl)).rolling(14).min().values; hi = pd.Series(np.where(H >= pcl, H, pcl)).rolling(14).max().values
    chop = 100 * np.log10(pd.Series(trt).rolling(14).sum().values / (hi - lo)) / np.log10(14); chop = pd.Series(chop).rolling(4).mean().values
    bbm = pd.Series(C).rolling(20).mean().values; bbd = pd.Series(C).rolling(20).std(ddof=0).values
    kcm = ema(C, 20); kca = rma(tr, 20); sq = (bbm + 2 * bbd < kcm + P["kc"] * kca) & (bbm - 2 * bbd > kcm - P["kc"] * kca)
    natr = 100 * rma(tr, 14) / C
    body = abs(C - O); ab = pd.Series(body).rolling(20).mean().values
    inr = lambda x, a, b: (not np.isnan(x)) and a <= x <= b
    trades = []; i = 3; run.open = None
    while i < n - 1:
        bs = L[i] > L[i-1] and L[i-1] < L[i-2]; ss = H[i] < H[i-1] and H[i-1] > H[i-2]
        side = 0
        if bs and tcup[i] and mfi[i] < P["mfi_ob"] and inr(adx[i], *P["adxL"]) and inr(cvd[i], *P["cvdL"]) and inr(r[i], *P["rsiL"]) and sq[i] and inr(natr[i], *P["natrL"]): side = 1
        elif ss and not tcup[i] and mfi[i] > P["mfi_os"] and inr(adx[i], *P["adxS"]) and body[i] > ab[i] * P["impS"] and not np.isnan(chop[i]) and chop[i] < P["chopS"] \
             and inr(cvd[i], *P["cvdS"]) and inr(r[i], *P["rsiS"]) and sq[i] and inr(natr[i], *P["natrS"]): side = -1
        if not side: i += 1; continue
        e = C[i]; sl = e * (1 - side * P["sl"] / 100); tpp = e * (1 + side * P["tp"] / 100); res = None
        for j in range(i + 1, n):
            if side > 0:
                if O[j] <= sl: res = O[j]; break
                if O[j] >= tpp: res = O[j]; break
                if L[j] <= sl: res = sl; break
                if H[j] >= tpp: res = tpp; break
            else:
                if O[j] >= sl: res = O[j]; break
                if O[j] <= tpp: res = O[j]; break
                if H[j] >= sl: res = sl; break
                if L[j] <= tpp: res = tpp; break
        if res is None:
            run.open = dict(t=d.index[i], side=side, e=e, sl=sl, tp=tpp); break
        trades.append((d.index[i], side * (res - e) / e - 2 * fee)); i = j   # Pine: вход возможен уже на свече выхода
    return pd.DataFrame(trades, columns=["t", "r"])
def stats(t, start):
    t = t[t.t >= start]
    if t.empty: return "нет сделок"
    eq = (1 + t.r).cumprod(); dd = (1 - eq / eq.cummax()).max()
    pf = t.r[t.r > 0].sum() / -t.r[t.r < 0].sum()
    yrs = {y: f"{((1 + g.r).prod() - 1) * 100:+.0f}%" for y, g in t.groupby(t.t.dt.year)}
    return f"сделок {len(t)} win {100 * (t.r > 0).mean():.1f}% PF {pf:.2f} итог {(eq.iloc[-1] - 1) * 100:+.0f}% DD {dd * 100:.1f}% по годам {yrs}"
if __name__ == "__main__":
    for f in sys.argv[1:]:
        d = pd.read_csv(f); d.index = pd.to_datetime(d.t.astype("int64"), unit="ms"); d = d[["o", "h", "l", "c", "v"]].astype(float)
        name = f.split("/")[-1]
        for fee, lab in ((0.0, "без комиссии (как на скрине: 0.05 USDT за ордер)"), (0.0005, "комиссия 0.05% за сторону (OKX taker)"), (0.0002, "комиссия 0.02% (maker)")):
            t = run(d, fee)
            print(f"{name} | {lab}\n   2024-01→: {stats(t, '2024-01-01')}\n   2020-2023: {stats(t[t.t < '2024-01-01'], '2020-01-01')}")
