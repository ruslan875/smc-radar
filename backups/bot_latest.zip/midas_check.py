"""midas_check.py — 2026-10-04. Проверка 28 демо-сигналов Midas (из экспорта чата с ботом) на реальных свечах Bybit.
Для каждого сигнала берём 5-минутные свечи после времени сигнала (до 3 суток) и смотрим, что цена задела раньше:
стоп или цели. Ключи не нужны — публичные данные. Запуск: midas_check.bat. Итог — в консоли и в midas_check.csv.
"""
import csv, json, time
from datetime import datetime, timedelta, timezone
import requests

SIGNALS = json.loads(r'''[{"time": "06.09.2026 15:50:44", "tz": "+03:00", "symbol": "1000000BOBUSDT", "side": "sell", "entry": 0.02205, "tp": [0.01899, 0.01859, 0.01815], "sl": 0.02442}, {"time": "07.09.2026 14:10:10", "tz": "+03:00", "symbol": "USELESSUSDT", "side": "sell", "entry": 0.22803, "tp": [0.22027, 0.20545, 0.19912], "sl": 0.23884}, {"time": "08.09.2026 14:45:52", "tz": "+03:00", "symbol": "FFUSDT", "side": "sell", "entry": 0.13021, "tp": [0.12084, 0.11847, 0.11556], "sl": 0.14264}, {"time": "09.09.2026 11:39:41", "tz": "+03:00", "symbol": "RAYUSDT", "side": "sell", "entry": 1.403, "tp": [1.3804, 1.3358, 1.3126], "sl": 1.5466}, {"time": "10.09.2026 11:02:14", "tz": "+03:00", "symbol": "ANIMEUSDT", "side": "sell", "entry": 0.003523, "tp": [0.003472, 0.003233, 0.003183], "sl": 0.003778}, {"time": "11.09.2026 12:22:34", "tz": "+03:00", "symbol": "LSKUSDT", "side": "sell", "entry": 0.13644, "tp": [0.13601, 0.12842, 0.1168], "sl": 0.14613}, {"time": "13.09.2026 13:50:04", "tz": "+03:00", "symbol": "FLOCKUSDT", "side": "sell", "entry": 0.08319, "tp": [0.08103, 0.07598, 0.06809], "sl": 0.08508}, {"time": "14.09.2026 14:30:07", "tz": "+03:00", "symbol": "POWERUSDT", "side": "sell", "entry": 0.11965, "tp": [0.10467, 0.0999, 0.09835], "sl": 0.12682}, {"time": "15.09.2026 12:45:10", "tz": "+03:00", "symbol": "POWERUSDT", "side": "sell", "entry": 0.15815, "tp": [0.12829, 0.12448, 0.11765], "sl": 0.17465}, {"time": "16.09.2026 14:21:04", "tz": "+03:00", "symbol": "BRUSDT", "side": "sell", "entry": 0.38667, "tp": [0.36673, 0.34108, 0.32252], "sl": 0.41198}, {"time": "17.09.2026 12:06:53", "tz": "+03:00", "symbol": "SAGAUSDT", "side": "sell", "entry": 0.02213, "tp": [0.02172, 0.02067, 0.01981], "sl": 0.02313}, {"time": "18.09.2026 12:51:03", "tz": "+03:00", "symbol": "STGUSDT", "side": "sell", "entry": 0.1323, "tp": [0.131, 0.1151, 0.1063], "sl": 0.1411}, {"time": "19.09.2026 11:40:33", "tz": "+03:00", "symbol": "ESPUSDT", "side": "sell", "entry": 0.09996, "tp": [0.09493, 0.09228, 0.08923], "sl": 0.11951}, {"time": "20.09.2026 13:06:09", "tz": "+03:00", "symbol": "GUNUSDT", "side": "sell", "entry": 0.003545, "tp": [0.003189, 0.002961, 0.002882], "sl": 0.003762}, {"time": "21.09.2026 11:09:12", "tz": "+03:00", "symbol": "PTBUSDT", "side": "sell", "entry": 0.0011059, "tp": [0.0009569, 0.0009098, 0.000836], "sl": 0.0011895}, {"time": "22.09.2026 15:11:11", "tz": "+03:00", "symbol": "FLOCKUSDT", "side": "sell", "entry": 0.08432, "tp": [0.08259, 0.07661, 0.07507], "sl": 0.08687}, {"time": "23.09.2026 11:13:48", "tz": "+03:00", "symbol": "BBUSDT", "side": "sell", "entry": 0.01059, "tp": [0.01049, 0.00982, 0.0095], "sl": 0.01099}, {"time": "24.09.2026 17:01:53", "tz": "+03:00", "symbol": "LONGXIAUSDT", "side": "sell", "entry": 0.14144, "tp": [0.12413, 0.11736, 0.1084], "sl": 0.1504}, {"time": "25.09.2026 14:06:25", "tz": "+03:00", "symbol": "SAGAUSDT", "side": "sell", "entry": 0.04002, "tp": [0.03855, 0.03676, 0.03097], "sl": 0.04175}, {"time": "26.09.2026 13:07:36", "tz": "+03:00", "symbol": "RAREUSDT", "side": "sell", "entry": 0.02208, "tp": [0.01932, 0.01764, 0.0162], "sl": 0.0236}, {"time": "27.09.2026 17:46:17", "tz": "+03:00", "symbol": "MAGICUSDT", "side": "sell", "entry": 0.06024, "tp": [0.0595, 0.0554, 0.05387], "sl": 0.06719}, {"time": "28.09.2026 16:54:24", "tz": "+03:00", "symbol": "NMRUSDT", "side": "sell", "entry": 11.317, "tp": [11.083, 10.704, 10.221], "sl": 11.679}, {"time": "29.09.2026 10:07:11", "tz": "+03:00", "symbol": "ALICEUSDT", "side": "sell", "entry": 0.1662, "tp": [0.1636, 0.1564, 0.1523], "sl": 0.1734}, {"time": "30.09.2026 11:35:36", "tz": "+03:00", "symbol": "ARKUSDT", "side": "sell", "entry": 0.2903, "tp": [0.285, 0.2795, 0.2764], "sl": 0.3011}, {"time": "01.10.2026 16:17:34", "tz": "+03:00", "symbol": "PROMPTUSDT", "side": "sell", "entry": 0.02337, "tp": [0.02179, 0.02154, 0.02004], "sl": 0.02593}, {"time": "02.10.2026 17:01:46", "tz": "+03:00", "symbol": "LONGXIAUSDT", "side": "sell", "entry": 0.03679, "tp": [0.0298, 0.02855, 0.02756], "sl": 0.04}, {"time": "03.10.2026 15:57:44", "tz": "+03:00", "symbol": "PUMPBTCUSDT", "side": "sell", "entry": 0.01023, "tp": [0.00983, 0.00918, 0.00883], "sl": 0.01175}, {"time": "04.10.2026 10:31:18", "tz": "+03:00", "symbol": "PUMPBTCUSDT", "side": "sell", "entry": 0.00873, "tp": [0.00802, 0.0073, 0.00659], "sl": 0.00944}]''')


def klines(sym, start_ms):
    out = []
    t = start_ms
    for _ in range(4):                       # 4 × 1000 свечей ≈ 13 суток максимум; берём 3 суток
        r = requests.get("https://api.bybit.com/v5/market/kline", params={"category": "linear", "symbol": sym,
                         "interval": "5", "start": t, "limit": 1000}, timeout=20).json()
        lst = r.get("result", {}).get("list") or []
        if not lst:
            break
        lst = sorted(lst, key=lambda x: int(x[0]))
        out += [(int(x[0]), float(x[2]), float(x[3]), float(x[4])) for x in lst if int(x[0]) >= t]
        t = int(lst[-1][0]) + 300000
        if t - start_ms > 3 * 86400000:
            break
    return [k for k in out if k[0] - start_ms <= 3 * 86400000]


def main():
    res = []
    for s in SIGNALS:
        dt = datetime.strptime(s["time"], "%d.%m.%Y %H:%M:%S")
        sign = 1 if s["tz"][0] == "+" else -1
        off = timedelta(hours=int(s["tz"][1:3]), minutes=int(s["tz"][4:6])) * sign
        ms = int((dt - off).replace(tzinfo=timezone.utc).timestamp() * 1000)
        try:
            ks = klines(s["symbol"], ms)
        except Exception as exc:  # noqa: BLE001
            ks = []; print(s["symbol"], "ошибка", exc)
        row = {"time": s["time"], "symbol": s["symbol"], "entry": s["entry"], "sl": s["sl"], "tp1": s["tp"][0], "tp2": s["tp"][1],
               "tp3": s["tp"][2], "bybit": "да" if ks else "нет монеты на Bybit"}
        if ks:
            first_close = ks[0][3]
            hit = {"tp1": None, "tp2": None, "tp3": None, "sl": None}
            for t, hi, lo, _c in ks:
                if hit["sl"] is None and hi >= s["sl"]:
                    hit["sl"] = t
                for k, p in (("tp1", s["tp"][0]), ("tp2", s["tp"][1]), ("tp3", s["tp"][2])):
                    if hit[k] is None and lo <= p and (hit["sl"] is None or hit["sl"] >= t):
                        hit[k] = t
                if hit["sl"] is not None or hit["tp3"] is not None:
                    break
            got = [k for k in ("tp1", "tp2", "tp3") if hit[k] is not None]
            res_txt = ("TP3" if "tp3" in got else ("TP2 потом стоп" if "tp2" in got else ("TP1 потом стоп" if "tp1" in got else "стоп")))
            if hit["sl"] is None and "tp3" not in got:
                res_txt = (got[-1].upper() + ", дальше не дошла за 3 суток") if got else "ни цели, ни стопа за 3 суток"
            # результат по их же схеме: 1/3 позиции на каждой цели, после TP1 стоп в безубыток
            e = s["entry"]; pnl = 0.0; left = 1.0
            for k in got:
                pnl += (e - s[k if k == "sl" else "tp"][int(k[-1]) - 1]) / e / 3 if k != "sl" else 0; left -= 1 / 3
            if hit["sl"] is not None and not got:
                pnl = -(s["sl"] - e) / e
            row.update(result=res_txt, pnl_pct=round(pnl * 100, 2), entry_gap_pct=round((first_close / e - 1) * 100, 2))
        # вариант «наоборот»: ЛОНГ на продолжение пампа в ту же минуту, стоп под минимумом 30 свечей, цели 1R/2R/3R
        try:
            kp = klines(s["symbol"], ms - 30 * 300000) if ks else []
        except Exception:  # noqa: BLE001
            kp = []
        if kp:
            before = [k for k in kp if k[0] < ms][-30:]
            after = [k for k in kp if k[0] >= ms]
            if before and after:
                e = s["entry"]; sl = min(k[2] for k in before) * 0.997; risk = e - sl
                tps = [e + risk, e + 2 * risk, e + 3 * risk]; pnl = 0.0; stop = sl; got = 0; out = None
                for t, hi, lo, cl in after:
                    if lo <= stop:
                        out = pnl + (1 - got / 3) * (stop - e) / e; break
                    while got < 3 and hi >= tps[got]:
                        pnl += (tps[got] - e) / e / 3; got += 1
                        if got == 1:
                            stop = e
                    if got == 3:
                        out = pnl; break
                if out is None:
                    out = pnl + (1 - got / 3) * (after[-1][3] - e) / e
                row["long_pnl_pct"] = round(out * 100, 2)
        res.append(row)
        print(f"{row['time']}  {row['symbol']:<16} {row.get('result', row['bybit']):<34} {row.get('pnl_pct', '')}   лонг: {row.get('long_pnl_pct', '')}")
        time.sleep(0.2)
    ok = [r for r in res if "result" in r]
    if ok:
        n = len(ok)
        tp1 = sum(1 for r in ok if r["result"] != "стоп" and not r["result"].startswith("ни "))
        sl = sum(1 for r in ok if r["result"] == "стоп")
        print(f"\nПроверено на Bybit: {n} из {len(res)}. Дошли хотя бы до TP1: {tp1} ({tp1/n*100:.0f}%), "
              f"сразу стоп: {sl} ({sl/n*100:.0f}%), итог по схеме 1/3 на цель: {sum(r['pnl_pct'] for r in ok):+.1f}% "
              f"(без комиссий, на одну и ту же сумму в каждой сделке)")
    lg = [r["long_pnl_pct"] for r in res if "long_pnl_pct" in r]
    if lg:
        print(f"Вариант НАОБОРОТ (лонг на продолжение): сделок {len(lg)}, в плюс {sum(1 for x in lg if x > 0)}, итог {sum(lg):+.1f}%")
    with open("midas_check.csv", "w", newline="", encoding="utf-8-sig") as fh:
        w = csv.DictWriter(fh, fieldnames=sorted({k for r in res for k in r}), delimiter=";")
        w.writeheader(); w.writerows(res)
    print("Подробно: midas_check.csv")
    input("\nEnter — закрыть")


main()
