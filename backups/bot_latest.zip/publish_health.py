#!/usr/bin/env python3
"""
Computes "discipline health" metrics and publishes them as health.json to
the bot's GitHub Pages repo, so the client-side-only Mini App can show a
"Здоровье" tab -- inspired by the loss-streak / risk-budget / position-size
dashboard in a third-party bot the user found (2026-08-23).

Two data sources, picked automatically by build_health() (see below):

  1. Exchange auto-import (added 2026-08-23; started Bybit-only, redesigned
     the same day into a multi-exchange pipeline once the user said they
     trade on several): for every exchange in settings.exchange_credentials
     (i.e. every exchange whose <PREFIX>_API_KEY/_SECRET(/_PASSPHRASE) are
     all set in .env -- see app/exchanges/ and .env.example), real closed
     trades are pulled straight from that account (read-only keys only)
     and merged into one timeline via compute_health_from_exchange_trades().
     A trade opened on Bybit and one opened on OKX both just show up --
     no manual entry, no per-exchange toggle to remember.
  2. live_trade_journal.csv (original, still supported): the same
     manually-kept journal analyze_live_journal.py uses, via
     compute_health(). Used whenever no exchange is configured at all, or
     falls back to it if every configured exchange's fetch fails (see
     build_health()) -- one broken exchange key should never blank the
     tab.

2026-09-06: a THIRD kind of source, always layered on top of whichever of
the two above wins -- see compute_health_from_live_bot_logs() and
_live_bot_health_sources() below. `long_strategy15_latuserge_live.py` and
`kc_roc_cci_wt_grid_live.py` are separate standalone processes (not part
of this bot/main.py at all) that both place real orders on the SAME Bybit
account as everything else -- so the exchange-auto-import source above
already includes their trades, but blended into one undifferentiated
"Bybit" timeline with no way to tell which bot did what. The user asked
for each bot's own status to be visible on its own, so these two extra
sources read each script's OWN per-symbol state JSON (for "what's open
right now") and OWN CSV trade log (for win rate/trade count) directly --
the only place strategy-level attribution still exists. They're added to
`sources` unconditionally (regardless of which of the two paths above won)
whenever at least one of a bot's own files exists on disk, so the Mini
App's existing source-switcher (see mini_app/index.html's renderHealth(),
already generic over `sources` keys -- no Mini App changes needed) and
`/report` in main.py (already generic over `health["sources"]`) both just
pick these two up automatically as extra chips/sections.

Either way, main.py now calls build_health() automatically every ~15min
while the bot is running (see main.py's _maybe_publish_health()) -- this
script itself is no longer the only way to refresh the tab, but still
works standalone for an immediate manual run:
    python publish_health.py
    python publish_health.py --journal live_trade_journal.csv --recent 10
(CLI flags only affect the CSV path; any configured exchange wins over it.)
"""
from __future__ import annotations

import argparse
import json
import statistics
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pandas as pd

from analyze_live_journal import load_journal, compute_stats

from app.config import EXCHANGE_KEYS_FILE, LIVE_JOURNAL_FILE, Settings
from app.exchange_keys_store import ExchangeKeysStore
from app.exchanges import REGISTRY as EXCHANGE_REGISTRY
from app.github_sync import GitHubSyncError, push_json_file

# 2026-09-06: per-strategy live-bot status sources (see module docstring
# above). Hardcoded rather than imported from the two live scripts
# themselves -- importing long_strategy15_latuserge_live.py/
# kc_roc_cci_wt_grid_live.py at module level would pull in their exchange-
# client/trade-key setup for no benefit here, since all this needs is two
# filenames. Deliberately kept in sync with each script's own
# DEFAULT_STATE_FILE/DEFAULT_LOG_CSV constants BY VALUE -- if either live
# script is ever renamed or moved, these two lines need updating too, they
# won't pick it up automatically.
BASE_DIR = Path(__file__).resolve().parent
LATUSERGE_STATE_FILE = BASE_DIR / "long_strategy15_latuserge_live_state.json"
LATUSERGE_TRADES_CSV = BASE_DIR / "long_strategy15_latuserge_live_trades.csv"
KC_GRID_STATE_FILE = BASE_DIR / "kc_roc_cci_wt_grid_live_state.json"
KC_GRID_TRADES_CSV = BASE_DIR / "kc_roc_cci_wt_grid_live_trades.csv"

# Same 4-tier naming as the reference app (Оптимум / Стабильность / Риск /
# Критическое состояние). Thresholds below are a starting point -- once you
# have a few weeks of real journal data, revisit them; there's nothing
# scientific about "3 losses in a row = critical", it's just a reasonable
# first guess at a tilt-detector.
STATE_LABELS = {
    "optimum": "Оптимум",
    "stable": "Стабильность",
    "risk": "Риск",
    "critical": "Критическое состояние",
}


def week_start(dt: datetime) -> datetime:
    """Monday 00:00 of dt's week (naive -- same clock as the journal's own timestamps)."""
    d = dt.replace(hour=0, minute=0, second=0, microsecond=0)
    return d - timedelta(days=d.weekday())


def day_start(dt: datetime) -> datetime:
    """Midnight of dt's own day -- 2026-08-23, round 9 ("Вера"), the daily
    cousin of week_start() above, for Settings.daily_risk_limit_usdt."""
    return dt.replace(hour=0, minute=0, second=0, microsecond=0)


def compute_health(df, risk_budget_usdt: float, recent_n: int, daily_budget_usdt: float = 0.0) -> dict:
    n = len(df)
    if n == 0:
        return {
            "trades_total": 0,
            "losing_streak": 0,
            "risk_budget_usdt": risk_budget_usdt,
            "risk_used_usdt_week": 0.0,
            "risk_used_pct": 0.0,
            "daily_risk_limit_usdt": daily_budget_usdt,
            "risk_used_usdt_today": 0.0,
            "daily_risk_used_pct": 0.0,
            "median_risk_recent_usdt": None,
            "last_risk_usdt": None,
            "position_size_ratio": None,
            "win_rate_pct": None,
            "avg_net_r": None,
            "state": "optimum",
            "state_label": STATE_LABELS["optimum"],
            "note": "Нет сделок в журнале -- заполни live_trade_journal.csv.",
        }

    dsorted = df.sort_values("date_opened").reset_index(drop=True)

    # Losing streak: consecutive losses trailing from the most recent trade.
    streak = 0
    for pnl in dsorted["net_pnl_usdt"].iloc[::-1]:
        if pnl <= 0:
            streak += 1
        else:
            break

    # Risk actually put at stake this week (Mon 00:00 -> now), regardless
    # of outcome -- this tracks risk TAKEN, not just realized losses.
    now = datetime.now()
    this_week = dsorted[dsorted["date_opened"] >= week_start(now)]
    risk_used_week = float(this_week["risk_usdt"].sum())
    risk_used_pct = (risk_used_week / risk_budget_usdt * 100) if risk_budget_usdt > 0 else 0.0

    # 2026-08-23, round 9 ("Вера"): same "risk actually put at stake"
    # philosophy as the weekly figure above, just scoped to today instead
    # of this week -- see Settings.daily_risk_limit_usdt's own docstring
    # for why this is a flat USDT figure rather than a %-of-equity one.
    today = dsorted[dsorted["date_opened"] >= day_start(now)]
    risk_used_today = float(today["risk_usdt"].sum())
    daily_risk_used_pct = (risk_used_today / daily_budget_usdt * 100) if daily_budget_usdt > 0 else 0.0

    recent = dsorted.tail(recent_n)
    recent_risks = recent["risk_usdt"].dropna()
    recent_risks = recent_risks[recent_risks > 0]
    median_risk = float(statistics.median(recent_risks)) if len(recent_risks) else None
    last_risk = float(dsorted["risk_usdt"].iloc[-1])
    position_ratio = (last_risk / median_risk) if median_risk else None

    win_rate = float((dsorted["net_pnl_usdt"] > 0).mean() * 100)
    valid_r = dsorted["net_r"].dropna()
    avg_r = float(valid_r.mean()) if len(valid_r) else None

    # critical: 3+ losses in a row, OR week's OR today's risk budget fully spent
    # risk:     2 losses in a row, OR 70%+ of either budget spent, OR last
    #           position 2x+ your recent median size
    # stable:   1 loss in a row, OR 40%+ of either budget spent
    # optimum:  none of the above
    if streak >= 3 or risk_used_pct >= 100 or daily_risk_used_pct >= 100:
        state = "critical"
    elif streak == 2 or risk_used_pct >= 70 or daily_risk_used_pct >= 70 or (position_ratio is not None and position_ratio >= 2):
        state = "risk"
    elif streak == 1 or risk_used_pct >= 40 or daily_risk_used_pct >= 40:
        state = "stable"
    else:
        state = "optimum"

    return {
        "trades_total": n,
        "losing_streak": streak,
        "risk_budget_usdt": risk_budget_usdt,
        "risk_used_usdt_week": round(risk_used_week, 2),
        "risk_used_pct": round(risk_used_pct, 1),
        "daily_risk_limit_usdt": daily_budget_usdt,
        "risk_used_usdt_today": round(risk_used_today, 2),
        "daily_risk_used_pct": round(daily_risk_used_pct, 1),
        "median_risk_recent_usdt": round(median_risk, 2) if median_risk else None,
        "last_risk_usdt": round(last_risk, 2),
        "position_size_ratio": round(position_ratio, 2) if position_ratio else None,
        "win_rate_pct": round(win_rate, 1),
        "avg_net_r": round(avg_r, 3) if avg_r is not None else None,
        "state": state,
        "state_label": STATE_LABELS[state],
    }


def compute_health_from_exchange_trades(trades: pd.DataFrame, risk_budget_usdt: float, recent_n: int,
                                         open_positions: pd.DataFrame | None = None,
                                         daily_budget_usdt: float = 0.0) -> dict:
    """Same 4-tier state derivation as compute_health(), but for trades
    auto-imported from one or more exchanges' closed-position history (see
    app/exchanges/) instead of the hand-filled CSV. `trades` may combine
    rows from several exchanges at once (build_health() concatenates them
    before calling this, tagged with an `exchange` column this function
    doesn't need to look at). Originally written Bybit-only on 2026-08-23
    (as compute_health_from_bybit_trades); generalized the same day once
    the user said they trade on several exchanges and wanted this to just
    work across all of them without duplicating the logic per exchange.

    Two of the numbers necessarily mean something different here than in
    compute_health(), because closed-position history has no concept of
    what your PLANNED stop-loss was -- only what actually happened:

      - "risk used this week" tracks REALIZED LOSSES only (sum of
        negative closed_pnl for trades closed this week, wins don't
        subtract from it) -- not planned risk-at-stake like the CSV
        path's qty*|entry-stop|. There's no "how much I exposed myself
        to" figure available without a stop price.
      - "position size ratio" compares each trade's notional value at
        entry (cum_entry_value = price * qty) against your recent median
        notional, instead of comparing dollar-risk. Still answers the
        same underlying question ("is this trade bigger than my usual?"),
        just via position size instead of stop-distance risk. Reuses the
        `median_risk_recent_usdt`/`last_risk_usdt` field NAMES from
        compute_health() for schema consistency even though they hold
        notional size here, not risk -- neither is currently rendered in
        the Mini App tab directly (only position_size_ratio is), so this
        doesn't change what's displayed, just what's in the raw JSON.
      - avg_net_r is left None -- an R-multiple needs a risk denominator
        this data source doesn't have; see the returned "note" field.

    Thresholds (streak/pct/ratio cutoffs for optimum/stable/risk/critical)
    are identical to compute_health() on purpose, so the two sources
    produce comparable-feeling states even though the inputs differ.

    2026-08-23, round 7: gained an `open_positions` param (a DataFrame in
    app/exchanges/base.py's OPEN_POSITION_COLUMNS shape, or None/empty if
    the exchange module doesn't implement fetch_open_positions() yet --
    see that module's docstring). The user opened a real position live to
    test the Bybit integration and found the tab showed nothing for it --
    reasonably, since everything above is CLOSED-trade history only, and
    an open position has no closed_pnl yet. Two things now happen with
    open positions, layered on AFTER the closed-trade numbers above are
    computed (both when there are 0 closed trades and when there are
    many -- open positions are never gated behind having closed trades
    first):

      1. Each one is listed under the returned "open_positions" key
         (symbol/side/qty/entry/mark/unrealized_pnl/leverage) so the Mini
         App can show a live "what's open right now" block.
      2. Any open position currently showing an unrealized LOSS adds to
         the risk-budget figure the same way a realized loss would --
         losing money on a trade that hasn't closed yet is still real
         risk you're carrying, not nothing. This is intentionally NOT
         scoped to "opened this week" the way the closed-trade figure is
         (an exchange's position-list endpoint doesn't reliably expose
         open time in a way worth trusting for that boundary) -- it's
         simply "how much am I down on open positions right now",
         added on top of "how much did I actually lose closing trades
         this week". The split is kept visible via two separate fields
         (risk_used_closed_usdt / risk_used_open_now_usdt) so this
         blending is never silently hidden even though risk_used_pct and
         the derived state use the combined total.

    2026-08-23, round 9 ("Вера"): gained `daily_budget_usdt`, the
    day-scoped cousin of `risk_budget_usdt` (see Settings.
    daily_risk_limit_usdt's own docstring for why this is a flat USDT
    figure). Tracks REALIZED LOSSES for trades closed today (same
    "realized losses only" philosophy as risk_used_usdt_week above, not
    planned risk -- this data source has no stop-loss concept), then the
    open-positions overlay below blends in today's unrealized losses on
    open positions too, mirroring exactly how the weekly figure already
    works."""
    n = len(trades)
    if n == 0:
        result = {
            "trades_total": 0,
            "losing_streak": 0,
            "risk_budget_usdt": risk_budget_usdt,
            "risk_used_usdt_week": 0.0,
            "risk_used_pct": 0.0,
            "daily_risk_limit_usdt": daily_budget_usdt,
            "risk_used_usdt_today": 0.0,
            "daily_risk_used_pct": 0.0,
            "median_risk_recent_usdt": None,
            "last_risk_usdt": None,
            "position_size_ratio": None,
            "win_rate_pct": None,
            "avg_net_r": None,
            "state": "optimum",
            "state_label": STATE_LABELS["optimum"],
            "note": "Подключённые биржи не вернули закрытых сделок за этот период.",
        }
    else:
        dsorted = trades.sort_values("created_time").reset_index(drop=True)
        pnl = dsorted["closed_pnl"]

        streak = 0
        for p in pnl.iloc[::-1]:
            if p <= 0:
                streak += 1
            else:
                break

        now = datetime.now(timezone.utc)
        d = now.replace(hour=0, minute=0, second=0, microsecond=0)
        wk_start = d - timedelta(days=d.weekday())
        this_week = dsorted[dsorted["created_time"] >= wk_start]
        risk_used_week = float(this_week["closed_pnl"].apply(lambda x: max(0.0, -x)).sum())

        # 2026-08-23, round 9: same realized-losses-only figure, scoped to
        # today (UTC) instead of this week.
        day_start_utc = d
        today = dsorted[dsorted["created_time"] >= day_start_utc]
        risk_used_today = float(today["closed_pnl"].apply(lambda x: max(0.0, -x)).sum())

        recent = dsorted.tail(recent_n)
        recent_sizes = recent["cum_entry_value"].dropna()
        recent_sizes = recent_sizes[recent_sizes > 0]
        median_size = float(statistics.median(recent_sizes)) if len(recent_sizes) else None
        last_size_series = dsorted["cum_entry_value"].dropna()
        last_size = float(last_size_series.iloc[-1]) if len(last_size_series) else None
        position_ratio = (last_size / median_size) if (median_size and last_size is not None) else None

        win_rate = float((pnl > 0).mean() * 100)

        result = {
            "trades_total": n,
            "losing_streak": streak,
            "risk_budget_usdt": risk_budget_usdt,
            "risk_used_usdt_week": round(risk_used_week, 2),
            "daily_risk_limit_usdt": daily_budget_usdt,
            "risk_used_usdt_today": round(risk_used_today, 2),
            "median_risk_recent_usdt": round(median_size, 2) if median_size else None,
            "last_risk_usdt": round(last_size, 2) if last_size is not None else None,
            "position_size_ratio": round(position_ratio, 2) if position_ratio else None,
            "win_rate_pct": round(win_rate, 1),
            "avg_net_r": None,
            "note": "R не считается для авто-импорта с бирж -- нет данных о твоём плановом стопе, "
                    "только факт входа/выхода.",
        }

    # ---- round 7: overlay currently-open positions (see docstring above) ----
    open_list = []
    open_risk_usdt = 0.0
    if open_positions is not None and len(open_positions):
        for _, row in open_positions.iterrows():
            upnl = row.get("unrealized_pnl")
            has_upnl = upnl is not None and not pd.isna(upnl)
            if has_upnl:
                open_risk_usdt += max(0.0, -float(upnl))

            def _num(val):
                return None if val is None or pd.isna(val) else float(val)

            open_list.append({
                "symbol": row.get("symbol"),
                "side": row.get("side"),
                "qty": _num(row.get("qty")),
                "avg_entry_price": _num(row.get("avg_entry_price")),
                "mark_price": _num(row.get("mark_price")),
                "unrealized_pnl": round(float(upnl), 2) if has_upnl else None,
                "position_value": (lambda v: round(v, 2) if v is not None else None)(_num(row.get("position_value"))),
                "leverage": _num(row.get("leverage")),
                # 2026-08-23, round 9: display-only in this JSON (the
                # breakeven-autopilot loop reads these straight from
                # fetch_open_positions() itself, not from health.json) --
                # included here so the Mini App's open-positions card can
                # show whether a stop/take is already set.
                "stop_loss": _num(row.get("stop_loss")),
                "take_profit": _num(row.get("take_profit")),
            })

    result["open_positions"] = open_list
    result["risk_used_closed_usdt"] = result["risk_used_usdt_week"]
    result["risk_used_open_now_usdt"] = round(open_risk_usdt, 2)
    total_risk_used = result["risk_used_usdt_week"] + open_risk_usdt
    result["risk_used_usdt_week"] = round(total_risk_used, 2)
    result["risk_used_pct"] = round((total_risk_used / risk_budget_usdt * 100) if risk_budget_usdt > 0 else 0.0, 1)

    # 2026-08-23, round 9: same open-position blend as the weekly figure
    # above, applied to the daily figure too -- an open loss counts
    # against "today" the same way it counts against "this week".
    total_risk_used_today = result["risk_used_usdt_today"] + open_risk_usdt
    result["risk_used_usdt_today"] = round(total_risk_used_today, 2)
    result["daily_risk_used_pct"] = round(
        (total_risk_used_today / daily_budget_usdt * 100) if daily_budget_usdt > 0 else 0.0, 1)

    streak = result["losing_streak"]
    position_ratio = result["position_size_ratio"]
    risk_used_pct = result["risk_used_pct"]
    daily_risk_used_pct = result["daily_risk_used_pct"]
    if streak >= 3 or risk_used_pct >= 100 or daily_risk_used_pct >= 100:
        state = "critical"
    elif streak == 2 or risk_used_pct >= 70 or daily_risk_used_pct >= 70 or (position_ratio is not None and position_ratio >= 2):
        state = "risk"
    elif streak == 1 or risk_used_pct >= 40 or daily_risk_used_pct >= 40:
        state = "stable"
    else:
        state = "optimum"
    result["state"] = state
    result["state_label"] = STATE_LABELS[state]

    if open_list:
        extra_note = f"Учтено открытых позиций: {len(open_list)} (риск сейчас: {round(open_risk_usdt, 2)} USDT)."
        result["note"] = f"{result['note']} {extra_note}" if result.get("note") else extra_note

    return result


def compute_health_from_live_bot_logs(display_name: str, state_path: Path, trades_csv_path: Path,
                                       recent_n: int = 10) -> dict:
    """2026-09-06: per-strategy status for one of the two standalone DCA-
    grid live scripts (long_strategy15_latuserge_live.py,
    kc_roc_cci_wt_grid_live.py) -- see module docstring for why this exists
    alongside the exchange-blended source above. Returns the SAME dict
    shape compute_health()/compute_health_from_exchange_trades() do, so
    both main.py's /report and mini_app/index.html's renderHealth() need
    zero new code to pick this up as just another entry in `sources`.

    Two things are honestly degraded here rather than guessed at, per this
    project's standing "never fabricate a specific numeric parameter" rule:

      - risk_budget_usdt/risk_used_usdt_week/risk_used_pct/
        daily_risk_limit_usdt/risk_used_usdt_today/daily_risk_used_pct are
        always 0.0 (not None -- renderHealth() calls .toFixed() on the
        first three unconditionally, so None would throw). These scripts'
        CSV logs only carry `gross_pnl_pct` (a %), never a dollar P&L or a
        planned risk-per-trade, and the actual --capital-per-deal used for
        each historical row isn't persisted anywhere (it's a CLI arg, and
        both scripts have been re-launched with different values -- see
        claude/dca-bot-reverse-engineering-2026-09-04.md's 2026-09-06
        section). Backing into a $ figure from an assumed capital-per-deal
        would be exactly the kind of invented number this project avoids.
      - avg_net_r/position_size_ratio/median_risk_recent_usdt/
        last_risk_usdt are None -- no stop-distance risk unit exists for a
        DCA grid (same reason compute_health_from_exchange_trades() leaves
        avg_net_r None), and there's no per-trade dollar size to rank
        against a median either.

    What IS real and shown: win_rate_pct and losing_streak, both computed
    directly from the CSV's own `reason` column (TP = win; SL/SL_ASSUMED =
    loss -- confirmed against both scripts' own finalize_deal() call sites),
    and open_positions, read from the state file's own `in_deal`/
    `base_price` per symbol (side is always "long" -- neither script ever
    shorts). qty/mark_price/unrealized_pnl/leverage/stop_loss/take_profit
    are left None: computing a live unrealized P&L would need a live price
    fetch this function doesn't do, and per-symbol leverage isn't stored in
    the state file (it's also a CLI arg, not persisted)."""
    open_positions: list[dict] = []
    if state_path.exists():
        try:
            raw_state = json.loads(state_path.read_text(encoding="utf-8"))
        except Exception:
            raw_state = {}
        for symbol, sym_state in raw_state.items():
            if not isinstance(sym_state, dict) or not sym_state.get("in_deal"):
                continue
            base_price = sym_state.get("base_price")
            open_positions.append({
                "symbol": symbol,
                "side": "long",
                "qty": None,
                "avg_entry_price": float(base_price) if base_price else None,
                "mark_price": None,
                "unrealized_pnl": None,
                "position_value": None,
                "leverage": None,
                "stop_loss": None,
                "take_profit": None,
            })

    trades_total = 0
    win_rate_pct = None
    losing_streak = 0
    if trades_csv_path.exists():
        try:
            df = pd.read_csv(trades_csv_path)
        except Exception:
            df = pd.DataFrame()
        if len(df) and "reason" in df.columns:
            if "exit_time" in df.columns:
                df = df.sort_values("exit_time")
            trades_total = len(df)
            is_win = df["reason"] == "TP"
            win_rate_pct = round(float(is_win.mean() * 100), 1)
            for won in is_win.iloc[::-1]:
                if won:
                    break
                losing_streak += 1

    # Same streak-based tiering as compute_health() -- see its own comment
    # for the reasoning; kept identical so states feel comparable across
    # every source, even though the inputs differ.
    if losing_streak >= 3:
        state = "critical"
    elif losing_streak == 2:
        state = "risk"
    elif losing_streak == 1:
        state = "stable"
    else:
        state = "optimum"

    note_parts = []
    note_parts.append(f"Win rate: {win_rate_pct}% ({trades_total} закрытых сделок)."
                       if trades_total else "Закрытых сделок пока нет.")
    if open_positions:
        note_parts.append(f"Сейчас открыто: {len(open_positions)}.")
    note_parts.append("Риск-бюджет в USDT для этого источника не считается -- скрипт логирует "
                       "только % P&L по сделке, а не сумму в деньгах.")

    return {
        "trades_total": trades_total,
        "losing_streak": losing_streak,
        "risk_budget_usdt": 0.0,
        "risk_used_usdt_week": 0.0,
        "risk_used_pct": 0.0,
        "daily_risk_limit_usdt": 0.0,
        "risk_used_usdt_today": 0.0,
        "daily_risk_used_pct": 0.0,
        "median_risk_recent_usdt": None,
        "last_risk_usdt": None,
        "position_size_ratio": None,
        "win_rate_pct": win_rate_pct,
        "avg_net_r": None,
        "state": state,
        "state_label": STATE_LABELS[state],
        "note": " ".join(note_parts),
        "open_positions": open_positions,
        "risk_used_open_now_usdt": 0.0,
        "display_name": display_name,
    }


# ---------------------------------------------------------------------------
# 2026-09-23: данные для Mini App TRADEOS — баланс, закрытые сделки, P&L по
# периодам, кривая доходности. Раньше в health.json были только агрегаты
# (winrate, риск), поэтому разделы «Портфель», «История сделок», «P&L» и
# статистика ботов показывали прочерки. Все суммы — реальные, из API биржи
# или из CSV-логов ботов; ничего не досчитывается «на глаз».
# ---------------------------------------------------------------------------
CLOSED_TRADES_LIMIT = 100


def _ts(v):
    """Время -> UTC Timestamp или None (никогда NaT: он попал бы в JSON как "NaT")."""
    try:
        if v is None or pd.isna(v):
            return None
        t = pd.Timestamp(v)
        if pd.isna(t):
            return None
        if t.tzinfo is None:
            t = t.tz_localize("UTC")
        return t
    except Exception:
        return None


def _iso(v):
    t = _ts(v)
    return t.isoformat() if t is not None else None


def _s(v):
    """Строка для JSON: NaN/None -> None (NaN в health.json сломал бы JSON.parse в Mini App)."""
    try:
        return None if v is None or pd.isna(v) else str(v)
    except (TypeError, ValueError):
        return str(v)


def _pnl_summary(values: list[float], times: list, unit: str) -> dict:
    """values — результат сделок (USDT или %), times — время закрытия (UTC)."""
    now = pd.Timestamp.now(tz="UTC")
    day0 = now.normalize()
    week0 = day0 - pd.Timedelta(days=day0.weekday())
    month0 = day0.replace(day=1)

    def _sum(since):
        return round(sum(v for v, t in zip(values, times) if t is not None and t >= since), 2)

    wins = [v for v in values if v > 0]
    losses = [v for v in values if v < 0]
    gross_loss = -sum(losses)
    return {
        "unit": unit,
        "today": _sum(day0),
        "week": _sum(week0),
        "month": _sum(month0),
        "all": round(sum(values), 2),
        "trades": len(values),
        "wins": len(wins),
        "losses": len(losses),
        "profit_factor": round(sum(wins) / gross_loss, 2) if gross_loss > 0 else None,
        "avg": round(sum(values) / len(values), 3) if values else None,
        "best": round(max(values), 3) if values else None,
        "worst": round(min(values), 3) if values else None,
    }


def _equity_curve(values: list[float], times: list) -> list:
    pts, cum = [], 0.0
    for v, t in sorted(zip(values, times), key=lambda x: (x[1] is None, x[1])):
        cum += v
        pts.append([t.isoformat() if t is not None else None, round(cum, 3)])
    # 2026-09-24: было pts[-200:] — у OKX (2600 сделок сетки) кривая
    # показывала только последние 200 и выглядела прямой линией. Теперь
    # равномерная выборка по всей истории + обязательно последняя точка.
    if len(pts) <= 200:
        return pts
    step = len(pts) / 199
    return [pts[int(i * step)] for i in range(199)] + [pts[-1]]


def _exchange_trade_extras(df: pd.DataFrame) -> dict:
    if df is None or not len(df):
        return {"closed_trades": [], "pnl_summary": _pnl_summary([], [], "USDT"), "equity_curve": []}
    d = df.copy()
    d["_t"] = d["updated_time"].map(_ts) if "updated_time" in d.columns else None
    d = d.sort_values("_t", ascending=False, na_position="last")

    def _n(v, k=6):
        try:
            return None if v is None or pd.isna(v) else round(float(v), k)
        except (TypeError, ValueError):
            return None

    trades = []
    for _, r in d.head(CLOSED_TRADES_LIMIT).iterrows():
        entry_val = _n(r.get("cum_entry_value"), 2)
        pnl = _n(r.get("closed_pnl"), 4)
        trades.append({
            "symbol": _s(r.get("symbol")),
            "side": _s(r.get("side")),
            "qty": _n(r.get("qty")),
            "entry": _n(r.get("avg_entry_price")),
            "exit": _n(r.get("avg_exit_price")),
            "notional": entry_val,
            "pnl": pnl,
            "roi_pct": round(pnl / entry_val * 100, 2) if pnl is not None and entry_val else None,
            "opened": _iso(r.get("created_time")),
            "closed": _iso(r["_t"]),
        })
    vals = [float(v) for v in d["closed_pnl"].fillna(0)]
    times = [_ts(x) for x in d["_t"]]
    return {"closed_trades": trades, "pnl_summary": _pnl_summary(vals, times, "USDT"),
            "equity_curve": _equity_curve(vals, times)}


def _live_bot_trade_extras(trades_csv_path: Path) -> dict:
    """CSV живых DCA-ботов содержит только % результата (gross_pnl_pct),
    поэтому их сводка и кривая — в процентах, а не в USDT."""
    empty = {"closed_trades": [], "pnl_summary": _pnl_summary([], [], "%"), "equity_curve": []}
    if not trades_csv_path.exists():
        return empty
    try:
        df = pd.read_csv(trades_csv_path)
    except Exception:
        return empty
    if not len(df) or "gross_pnl_pct" not in df.columns:
        return empty
    df["_t"] = df["exit_time"].map(_ts) if "exit_time" in df.columns else None
    df = df.sort_values("_t", ascending=False, na_position="last")
    trades = []
    for _, r in df.head(CLOSED_TRADES_LIMIT).iterrows():
        def _n(v, k=6):
            try:
                return None if v is None or pd.isna(v) else round(float(v), k)
            except (TypeError, ValueError):
                return None
        trades.append({
            "symbol": _s(r.get("symbol")), "side": "long",
            "entry": _n(r.get("avg_entry_price")), "exit": _n(r.get("exit_price")),
            "pnl_pct": _n(r.get("gross_pnl_pct"), 3), "reason": _s(r.get("reason")),
            "orders": _n(r.get("orders_filled"), 0), "filled_pct": _n(r.get("filled_pct"), 2),
            "opened": _iso(r.get("entry_time")),
            "closed": _iso(r["_t"]),
        })
    vals = [float(v) for v in df["gross_pnl_pct"].fillna(0)]
    times = [_ts(x) for x in df["_t"]]
    return {"closed_trades": trades, "pnl_summary": _pnl_summary(vals, times, "%"),
            "equity_curve": _equity_curve(vals, times)}


def _live_bot_health_sources(recent_n: int = 10) -> dict:
    """Builds 0-2 extra `sources` entries for the standalone DCA-grid live
    scripts (see compute_health_from_live_bot_logs() above). A bot is only
    included once it's actually been launched at least once (state file or
    CSV log present) -- otherwise it would show up as a permanent empty
    chip for a script nobody's running yet."""
    candidates = [
        ("latuserge", "Latuserge (LONG_STRATEGY 15)", LATUSERGE_STATE_FILE, LATUSERGE_TRADES_CSV),
        ("kc_roc_grid", "KC/ROC/CCI/WT грид", KC_GRID_STATE_FILE, KC_GRID_TRADES_CSV),
    ]
    sources: dict = {}
    for key, display_name, state_path, trades_path in candidates:
        if not state_path.exists() and not trades_path.exists():
            continue
        sources[key] = compute_health_from_live_bot_logs(display_name, state_path, trades_path, recent_n)
        sources[key].update(_live_bot_trade_extras(trades_path))
    return sources


def build_health(settings: Settings, journal_path: Path | None = None, recent_n: int = 10) -> dict:
    """Single entry point both main.py's auto-publish loop and this
    script's own CLI call -- keeps the "which data source(s) win" decision
    in exactly one place.

    2026-08-23, same day, round 2: originally Bybit-only ("if
    BYBIT_API_KEY/SECRET set, use Bybit, else CSV"); redesigned the same
    day into a multi-exchange loop once the user said they trade on
    several exchanges (OKX/Bitget/MEXC/KuCoin/Gate.io added alongside
    Bybit -- see app/exchanges/).

    2026-08-23, same day, round 4: that redesign originally MERGED every
    exchange's trades into one combined timeline before computing a single
    health state -- the user said that was confusing ("нужно что бы
    показывало как то раздельно"): a losing streak split across two
    unrelated accounts isn't really a losing streak in the sense the tab
    is trying to capture, and one blended risk-budget % hides which
    account is actually the problem. Redesigned again, same day, to keep
    each source's numbers SEPARATE all the way through: every configured
    exchange gets its own compute_health_from_exchange_trades() call, and
    the return shape changed from one flat health dict to
    {"mode": "exchanges"|"journal", "sources": {key: <health dict>, ...},
    "exchanges_failed": [...]} -- the Mini App renders a switcher over
    `sources` and shows exactly one at a time (see mini_app/index.html's
    renderHealth()), never a blended total.

    2026-08-23, same day, round 5: credentials can now also arrive via
    /setkey (a Mini App Settings-tab form -> Telegram deep link -> bot
    command, see app/exchange_keys_store.py) instead of only .env. Every
    call here re-reads ExchangeKeysStore fresh and overlays it on top of
    settings.exchange_credentials (store entries win on a key collision,
    since they're the more-recently-set ones) -- this is deliberately
    NOT cached anywhere, so a key added via /setkey takes effect on the
    very next auto-publish cycle (~15min, see main.py) with no restart.

    For every exchange in the merged credential set, fetch its closed
    trades independently. A
    failure on ONE exchange (bad key, permission error, network blip,
    unexpected response shape) is logged and that exchange is simply
    absent from `sources` for this run -- it does NOT take down the
    others or force a fallback to the CSV, so e.g. a typo'd MEXC key
    doesn't blank out otherwise-good Bybit/OKX data. Falls back to the
    CSV path (as a single `sources: {"journal": ...}` entry) only if no
    exchange is configured at all, or every configured exchange's fetch
    failed outright. Each per-source dict keeps the same shape
    compute_health()/compute_health_from_exchange_trades() have always
    returned (including the empty-state shape for 0 trades), so nothing
    downstream needs new special-casing for "no data yet" -- that's just
    a source whose own trades_total is 0."""
    journal_path = journal_path or LIVE_JOURNAL_FILE

    # 2026-09-06: computed once up front, merged into `sources` below
    # regardless of which of the two branches below wins -- see module
    # docstring and _live_bot_health_sources()'s own docstring.
    live_bot_sources = _live_bot_health_sources(recent_n)

    all_credentials = {**settings.exchange_credentials, **ExchangeKeysStore(EXCHANGE_KEYS_FILE).get_all()}

    if all_credentials:
        sources: dict = {}
        failed: list[str] = []
        for exch_key, creds in all_credentials.items():
            module = EXCHANGE_REGISTRY.get(exch_key)
            if module is None:
                continue
            try:
                df = module.fetch_closed_trades(
                    creds["api_key"], creds["api_secret"], creds.get("passphrase"))
            except Exception as exc:
                print(f"[HEALTH] {module.DISPLAY_NAME} auto-import failed ({exc}) -- "
                      f"skipping this exchange for this run.", file=sys.stderr)
                failed.append(exch_key)
                continue

            # 2026-08-23, round 7: OPTIONAL open-positions fetch (see
            # app/exchanges/base.py's module docstring) -- only some
            # modules implement this yet, so check with hasattr rather
            # than assuming every exchange has it. A failure here is
            # logged but doesn't drop the exchange's closed-trade data
            # (unlike the fetch_closed_trades failure above) -- an open-
            # positions hiccup shouldn't blank out otherwise-good history.
            open_positions_df = None
            if hasattr(module, "fetch_open_positions"):
                try:
                    open_positions_df = module.fetch_open_positions(
                        creds["api_key"], creds["api_secret"], creds.get("passphrase"))
                except Exception as exc:
                    print(f"[HEALTH] {module.DISPLAY_NAME} open-positions fetch failed ({exc}) -- "
                          f"continuing without live open positions for this source.", file=sys.stderr)

            health = compute_health_from_exchange_trades(
                df, risk_budget_usdt=settings.weekly_risk_budget_usdt, recent_n=recent_n,
                open_positions=open_positions_df, daily_budget_usdt=settings.daily_risk_limit_usdt)
            health["display_name"] = module.DISPLAY_NAME
            health.update(_exchange_trade_extras(df))
            # 2026-09-23: баланс счёта — опционально, как open positions.
            if hasattr(module, "fetch_balance"):
                try:
                    health["balance"] = module.fetch_balance(
                        creds["api_key"], creds["api_secret"], creds.get("passphrase"))
                except Exception as exc:
                    print(f"[HEALTH] {module.DISPLAY_NAME} balance fetch failed ({exc}) -- "
                          f"publishing without balance for this source.", file=sys.stderr)
            sources[exch_key] = health

        if sources:
            sources.update(live_bot_sources)
            result = {"mode": "exchanges", "sources": sources}
            if failed:
                result["exchanges_failed"] = failed
            return result
        # every configured exchange failed outright -- fall through to CSV below.

    if not journal_path.exists():
        empty = pd.DataFrame(columns=["date_opened", "net_pnl_usdt", "risk_usdt", "net_r"])
        health = compute_health(empty, risk_budget_usdt=settings.weekly_risk_budget_usdt, recent_n=recent_n,
                                 daily_budget_usdt=settings.daily_risk_limit_usdt)
    else:
        raw = load_journal(journal_path)
        df = compute_stats(raw)
        health = compute_health(df, risk_budget_usdt=settings.weekly_risk_budget_usdt, recent_n=recent_n,
                                 daily_budget_usdt=settings.daily_risk_limit_usdt)
    health["display_name"] = "Журнал"
    sources = {"journal": health}
    sources.update(live_bot_sources)
    return {"mode": "journal", "sources": sources}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--journal", default="live_trade_journal.csv",
                         help="Ignored if any exchange is configured in .env -- exchange auto-import wins then.")
    parser.add_argument("--recent", type=int, default=10,
                         help="Trade window for the 'recent median position size' metric")
    args = parser.parse_args()

    settings = Settings.load()
    if not settings.github_token:
        print("[note] GITHUB_TOKEN не задан в .env -- health.json посчитается локально, "
              "но НЕ будет опубликован на сайт (см. app/github_sync.py).")
    all_credentials = {**settings.exchange_credentials, **ExchangeKeysStore(EXCHANGE_KEYS_FILE).get_all()}
    if all_credentials:
        names = ", ".join(EXCHANGE_REGISTRY[k].DISPLAY_NAME for k in all_credentials
                           if k in EXCHANGE_REGISTRY)
        print(f"[note] Настроены ключи для: {names} -- считаю из реальных сделок, --journal игнорируется.")

    health = build_health(settings, journal_path=Path(args.journal), recent_n=args.recent)
    health["generated_at"] = datetime.now().isoformat(timespec="seconds")

    print("=" * 60)
    print(f"  mode: {health['mode']}")
    if health.get("exchanges_failed"):
        print(f"  exchanges_failed: {health['exchanges_failed']}")
    for key, h in health["sources"].items():
        print("-" * 60)
        print(f"  source: {key} ({h.get('display_name', key)})")
        if not h["trades_total"]:
            print(f"  {h.get('note') or 'Нет сделок -- нечего публиковать пока.'}")
        for k, v in h.items():
            if k in ("display_name", "closed_trades", "equity_curve"):
                continue
            print(f"    {k}: {v}")
    print("-" * 60)
    print(f"  generated_at: {health['generated_at']}")
    print("=" * 60)

    if settings.github_token:
        try:
            push_json_file(settings.github_token, settings.github_repo, "health.json", health,
                            message="Update health.json")
            print("Опубликовано в health.json -- вкладка «Здоровье» в Mini App подхватит это в течение минуты.")
        except GitHubSyncError as e:
            print(f"Ошибка публикации: {e}")


if __name__ == "__main__":
    main()
