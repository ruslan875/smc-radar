@echo off
REM ============================================
REM VANTORIX Strategy Automated Testing
REM  Автоматизированное тестирование стратегий
REM ============================================

setlocal enabledelayedexpansion

cd /d "D:\VANTORIX\bot"

cls
echo.
echo ===============================================
echo      VANTORIX AUTO STRATEGY TESTER v1.0
echo      Автоматизированное тестирование
echo ===============================================
echo.

REM Проверяем наличие файлов
echo [CHECK] Checking file structure...

if not exist "strategies\" (
    echo [ERROR] Directory 'strategies' not found!
    pause
    exit /b 1
)

if not exist "strategies\CE_ZLSMA.pine" (
    echo [ERROR] Strategy CE_ZLSMA.pine not found!
    pause
    exit /b 1
)

echo [OK] All required files found
echo.

REM Создаём папку для результатов
if not exist "backtest_results\" (
    mkdir backtest_results
    echo [CREATED] backtest_results folder
)

echo.
echo ===============================================
echo      TIER 1: SIMPLE STRATEGIES
echo ===============================================
echo.

echo Test 1/2: CE_ZLSMA on XRPUSDT 1H
echo -----------
echo Starting TradingView...
start https://www.tradingview.com/chart/?symbol=OKX%3AXRPUSDT&interval=60

timeout /t 3 /nobreak

echo.
echo [INSTRUCTIONS]
echo 1. In TradingView, press Alt+E to open Pine Editor
echo 2. Open file: D:\VANTORIX\bot\strategies\CE_ZLSMA.pine
echo 3. Click "Add to Chart"
echo 4. Click on Strategy -> Strategy Tester
echo 5. Set dates: Last 6 months
echo 6. Click "Run Backtest"
echo.
echo Press ENTER once the backtest completes...
pause

echo.
echo Test 2/2: High_Low_cloud_trend on XRPUSDT 1H
echo -----------
echo Starting TradingView...
start https://www.tradingview.com/chart/?symbol=OKX%3AXRPUSDT&interval=60

timeout /t 3 /nobreak

echo.
echo [INSTRUCTIONS]
echo 1. In TradingView, press Alt+E to open Pine Editor
echo 2. Open file: D:\VANTORIX\bot\strategies\High_Low_cloud_trend.pine
echo 3. Click "Add to Chart"
echo 4. Click on Strategy -> Strategy Tester
echo 5. Set dates: Last 6 months
echo 6. Click "Run Backtest"
echo.
echo Press ENTER once the backtest completes...
pause

echo.
echo ===============================================
echo ✓ TESTING COMPLETED
echo ===============================================
echo.
echo [NEXT STEPS]
echo 1. Review results in: D:\VANTORIX\bot\backtest_results\
echo 2. Fill metrics in: STRATEGY_TESTING_CHECKLIST.md
echo 3. Select top-3 strategies for paper trading
echo.
echo [RESULTS FILES]
echo - CE_ZLSMA_results.txt
echo - High_Low_cloud_trend_results.txt
echo.

pause
