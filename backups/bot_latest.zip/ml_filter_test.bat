@echo off
cd /d %~dp0
if exist venv\Scripts\python.exe (venv\Scripts\python.exe ml_filter_test.py) else (python ml_filter_test.py)
