#!/usr/bin/env python3
"""
Live (real-money-capable) executor for the Veles Finance-style DCA/grid
replica validated in kc_roc_cci_wt_grid_backtest.py -- see
pine-indicators-python-port-2026-08-18.md's "Полный вотчлист (5/5 монет) и
финальная сплит-валидация" section (2026-08-31) for the backtest result
this is acting on: all 5 watchlist symbols (ETH/SOL/ARB/INJ/TIA), both
calendar halves net-positive on all three fee scenarios, n=527. That
validation is entirely retrospective (one continuous 2026-03..2026-08
window, split in half) -- this script exists to get a GENUINE forward
result, on data that didn't exist when the backtest was built.

SAFETY DEFAULT -- READ THIS BEFORE ANYTHING ELSE: without --live, this
script places ZERO real orders. It polls real live Bybit prices and
simulates every fill/exit in software using the EXACT SAME bar-by-bar
logic as kc_roc_cci_wt_grid_backtest.py (imported directly from there, not
reimplemented -- see the import block below for why). This is a genuine
paper/forward test: real market data, zero financial risk. Only pass
--live once you've watched it run in dry-run for a while and the logged
deals in --log-csv look sane next to kc_roc_cci_wt_grid_backtest_out/*.csv.

WHAT --live ACTUALLY DOES (chosen with the user 2026-08-31: 20 USDT
notional per deal, all 5 watchlist symbols at once, 5x leverage):
  - Reuses the SAME Bybit trade key already saved via /tradekey in the
    main bot (trade_keys.json) -- no new key setup needed.
  - Base order: real Market buy, 65% of --capital-per-deal (a NOTIONAL
    figure, matching the backtest's "% of invested capital" convention --
    NOT the margin; margin used = notional / leverage). Stop-loss is
    attached to this very first order, so the position is never even
    briefly unprotected.
  - One grid leg: a real resting GTC Limit buy order (35% of
    capital-per-deal) at the same %% offset from the base fill price as
    the backtest, matching Veles' "safety orders" mechanic. (2026-09-01:
    rebalanced from the original 55/35/10 three-leg grid to 65/35 two-leg
    -- see the 2026-09-01 note further down for why.)
  - The stop-loss is Bybit's own native position stop (an exchange-side
    conditional order) -- it protects the position even if this script
    crashes or the machine loses power. It is re-synced to the new
    average price every time a grid leg fills.
  - The take-profit (WaveTrend sell-cross + P&L% floor) is NOT an
    exchange-native order -- Bybit has no such conditional type -- so it
    can ONLY fire while this script is running. If the stop-loss fires
    natively while the script is down, the position still closes safely;
    it just won't be logged until the script restarts and notices the
    position is gone (see handle_external_close()).
  - On take-profit: closes with a reduce-only market order, then cancels
    any still-resting grid legs so they can never fill later against a
    position that no longer exists.

Usage:
    python kc_roc_cci_wt_grid_live.py                       # dry-run (paper), all 5 watchlist symbols, default params
    python kc_roc_cci_wt_grid_live.py --live                 # REAL Bybit orders -- read the safety section above first
    python kc_roc_cci_wt_grid_live.py --symbol ARBUSDT --live --capital-per-deal 20 --leverage 5

Ctrl+C stops the polling loop. It does NOT flatten open positions or
cancel resting orders -- an open deal's exchange-side stop-loss keeps
protecting it either way, but the WaveTrend take-profit exit stops firing
until the script runs again. Restart with the same --state-file to resume
exactly where it left off (state is reconciled against the real exchange
position on every cycle, not blindly trusted from disk).
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
import time
import traceback
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import pandas as pd

from app import state_notices
from app import single_instance
from app.config import BASE_DIR, KC_GRID_MAX_DEALS_FILE, TRADE_KEYS_FILE
from app.data import DataError, get_klines
from app.live_bot_settings import MaxConcurrentDealsSettings
from app.trade_keys_store import TradeKeysStore
from app.trading_guard import check_leverage
from app.exchanges import bybit as bx
from app import chart

# Deliberately imported, not duplicated -- every other backtest/live pair
# in this project duplicates fetch_history for standalone-ness (see
# kc_roc_cci_wt_grid_backtest.py's own "identical pattern .. duplicated rather than
# imported" note), but for a live-MONEY script that trade-off flips: what
# matters most here is that the entry/exit DECISION is byte-identical to
# what was actually split-validated. Importing directly means any future
# fix to compute_indicators() in the backtest automatically applies here
# too, instead of silently drifting apart.
from kc_roc_cci_wt_grid_backtest import Params, compute_indicators, parse_grid, fetch_history

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

import os

DEFAULT_WATCHLIST = ["ETHUSDT", "SOLUSDT", "ARBUSDT", "INJUSDT", "TIAUSDT", "HYPEUSDT"]  # HYPEUSDT added
# 2026-08-31 after its own --bars 260000 split-validation passed on all
# three fee scenarios, same bar the original 5 were held to.
CATEGORY = "linear"
DEFAULT_STATE_FILE = BASE_DIR / "kc_roc_cci_wt_grid_live_state.json"


# 2026-09-24: оба живых бота торгуют на ОДНОМ счёте Bybit и пересекаются по
# монетам (ETH/SOL/ARB/INJ/TIA). Раньше позиция соседнего бота выглядела для
# этого скрипта как «неизвестная» -> тревога в Telegram. Теперь перед тревогой
# сверяемся с файлом состояния соседа: если монету держит он, тихо пропускаем
# (без Telegram). Настоящая неизвестная позиция (ручная сделка, потерянная
# после сброса состояния) по-прежнему вызывает тревогу.
SIBLING_STATE_FILE = BASE_DIR / "long_strategy15_latuserge_live_state.json"
SIBLING_LABEL = "Latuserge"
_sibling_busy_logged: set = set()


def sibling_holds(symbol: str) -> bool:
    try:
        if "--demo" in sys.argv:      # 2026-10-25: на демо проверяем именно одновременную торговлю одной монетой
            return False
        data = json.loads(SIBLING_STATE_FILE.read_text(encoding="utf-8"))
        return bool((data.get(symbol) or {}).get("in_deal"))
    except Exception:
        return False
DEFAULT_LOG_CSV = BASE_DIR / "kc_roc_cci_wt_grid_live_trades.csv"

# 2026-09-12: paper mode gets its OWN state/journal files. Same change, same
# reason, as long_strategy15_latuserge_live.py -- see the longer note there.
# Short version: paper and live used to share these files (nothing ever
# passed --state-file/--log-csv), so a paper instance and a live instance
# running at the same time overwrote each other's state and produced
# fabricated journal rows. Separate files make that impossible. An explicit
# --state-file/--log-csv still wins over both defaults.
DEFAULT_PAPER_STATE_FILE = BASE_DIR / "kc_roc_cci_wt_grid_paper_state.json"
DEFAULT_PAPER_LOG_CSV = BASE_DIR / "kc_roc_cci_wt_grid_paper_trades.csv"


# --------------------------------------------------------------- state --

@dataclass
class DealState:
    in_deal: bool = False
    entry_time: str | None = None            # ISO 8601, UTC
    base_price: float = 0.0
    orders: list = field(default_factory=list)     # [{"price":.., "vol_pct":.., "qty":.., "order_id":..}]
    pending: list = field(default_factory=list)    # [{"limit_price":.., "vol_pct":.., "qty":.., "order_id":..}]
    stop_synced_price: float | None = None   # last stop-loss price actually sent to Bybit (live mode only)


class StateFile:
    """Plain-JSON per-symbol deal state -- same house pattern as
    AccessStore/ScanSettings/TradeKeysStore: read whole file, mutate in
    memory, write whole file back after every change so a crash mid-cycle
    loses at most the in-flight step, never earlier history."""

    def __init__(self, path: Path):
        self.path = path
        if path.exists():
            raw = json.loads(path.read_text())
        else:
            raw = {}
        self.deals: dict[str, DealState] = {sym: DealState(**d) for sym, d in raw.items()}

    def save(self) -> None:
        raw = {sym: asdict(d) for sym, d in self.deals.items()}
        self.path.write_text(json.dumps(raw, indent=2, ensure_ascii=False))

    def get(self, symbol: str) -> DealState:
        return self.deals.setdefault(symbol, DealState())


# ---------------------------------------------------------------- sizing --

def round_qty(raw_qty: float, step: float, min_qty: float) -> float:
    if step <= 0:
        return max(raw_qty, min_qty)
    steps = int(raw_qty / step + 1e-9)
    rounded = steps * step
    rounded = round(rounded, 10)  # kill float noise like 0.30000000000000004
    return max(rounded, min_qty)


# -------------------------------------------------------------- logging --

CSV_FIELDS = ["symbol", "entry_time", "exit_time", "orders_filled", "filled_pct",
              "avg_entry_price", "exit_price", "reason", "bars_held", "gross_pnl_pct"]


def log_deal(csv_path: Path, symbol: str, entry_time, exit_time, orders_filled: int,
             filled_pct: float, avg_entry_price: float, exit_price: float, reason: str,
             gross_pnl_pct: float) -> None:
    """Same fieldnames as kc_roc_cci_wt_grid_backtest.py's save_csv() on purpose --
    lets live results be compared directly against
    kc_roc_cci_wt_grid_backtest_out/<symbol>_deals.csv, apples to apples."""
    entry_ts = pd.Timestamp(entry_time)
    exit_ts = pd.Timestamp(exit_time)
    bars_held = int((exit_ts - entry_ts).total_seconds() // 60)
    is_new = not csv_path.exists()
    with csv_path.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=CSV_FIELDS)
        if is_new:
            writer.writeheader()
        writer.writerow({
            "symbol": symbol, "entry_time": entry_ts.isoformat(), "exit_time": exit_ts.isoformat(),
            "orders_filled": orders_filled, "filled_pct": filled_pct,
            "avg_entry_price": avg_entry_price, "exit_price": exit_price,
            "reason": reason, "bars_held": bars_held, "gross_pnl_pct": gross_pnl_pct,
        })


# ------------------------------------------------------------- telegram --

# 2026-09-06, user request: latuserge and kc_roc_cci_wt_grid share several
# watchlist symbols (ETH/SOL/ARB/INJ/TIA in both) -- every notify() call
# EXCEPT the deal-open message used to say only "{symbol}: ...", with no way
# to tell which of the two bots a leg-fill/close/warning message about, say,
# ETHUSDT actually came from. Fixed by tagging every message here, not just
# deal-open, with the same STRATEGY_LABEL used for this bot's health.json
# source and /report section (see publish_health.py's
# "KC/ROC/CCI/WT грид" display_name) -- one consistent name across
# Telegram, /report, and the Mini App's "Здоровье" tab.
STRATEGY_LABEL = "KC/ROC/CCI/WT грид"


def make_notifier(enabled: bool, strategy_label: str = STRATEGY_LABEL):
    # 2026-09-06, user request: same as long_strategy15_latuserge_live.py
    # this same day -- send the entry/SL/TP picture the Mini App's
    # "Торговля"/"Здоровье" tabs already show (app/chart.py's
    # render_position_chart()) as a Telegram PHOTO too, right when a deal
    # opens, attached as `notify.send_photo` on the same callable so every
    # existing `notify(...)` call site is unaffected. No-op version
    # attached in the disabled/misconfigured branches too, so calling
    # `.send_photo` is always safe.
    def _noop(msg: str) -> None:
        return None

    def _noop_photo(photo_bytes: bytes, caption: str) -> None:
        return None

    if not enabled:
        _noop.send_photo = _noop_photo
        return _noop
    token = os.environ.get("TELEGRAM_BOT_TOKEN")
    chat_id = os.environ.get("TELEGRAM_CHAT_ID")
    if not token or not chat_id:
        print("[TELEGRAM] alerts requested but TELEGRAM_BOT_TOKEN/TELEGRAM_CHAT_ID not set -- disabled.")
        _noop.send_photo = _noop_photo
        return _noop
    from app.telegram_client import TelegramClient, TelegramError
    import requests as _requests
    client = TelegramClient(token, chat_id)
    from app import notify_prefs
    _last_allowed = [True]

    def notify(msg: str) -> None:
        # 2026-09-14: было f"[{strategy_label}] {msg}" -- длинный ярлык
        # "[KC/ROC/CCI/WT грид · 🔴 LIVE (реальный ордер)]" лепился В НАЧАЛО
        # каждого сообщения и съедал первую строку, из-за которой в списке
        # чатов и в уведомлении на телефоне не было видно САМОГО главного:
        # монеты и что с ней произошло. Теперь ярлык уходит в конец
        # отдельной строкой курсивом: он нужен, но не важнее события.
        # 2026-09-24: типы уведомлений включаются/выключаются в Telegram
        # (/notify). Фото идёт сразу за текстом — оно следует его решению.
        allowed = notify_prefs.allowed_bot_message(msg) and (
            "paper" not in strategy_label.lower() or notify_prefs.is_enabled("paper"))
        _last_allowed[0] = allowed
        if not allowed:
            print(f"[TELEGRAM] muted ({notify_prefs.classify_bot_message(msg)}): {msg.splitlines()[0][:80]}")
            return
        try:
            client.send_message(f"{msg}\n<i>{strategy_label}</i>")
        except (TelegramError, _requests.exceptions.RequestException) as exc:
            print(f"[TELEGRAM] notify failed (non-fatal): {exc}", file=sys.stderr)

    def notify_photo(photo_bytes: bytes, caption: str) -> None:
        # Подпись под картинкой БЕЗ ярлыка стратегии: картинка идёт сразу за
        # текстовым сообщением, где всё это уже сказано. Раньше получался
        # дубль в две строки под каждым графиком.
        if not _last_allowed[0]:
            return
        try:
            client.send_photo(photo_bytes, caption)
        except (TelegramError, _requests.exceptions.RequestException) as exc:
            print(f"[TELEGRAM] notify_photo failed (non-fatal): {exc}", file=sys.stderr)

    notify.send_photo = notify_photo

    return notify


# ------------------------------------------------------------- backends --

class PaperBackend:
    """Zero real orders -- every "fill" is simulated against the just-
    polled real bar's low/close, IDENTICAL math to
    kc_roc_cci_wt_grid_backtest.py's simulate_symbol(). This is the default and
    the only mode until --live is passed."""
    live = False

    def open_base(self, symbol, qty, stop_price):
        return {"order_id": None}

    def place_grid_leg(self, symbol, limit_price, qty, stop_price):
        return {"order_id": None}

    def sync_stop(self, symbol, stop_price):
        pass

    def close_market(self, symbol, qty):
        pass

    def cancel_all(self, symbol):
        pass

    def get_position(self, symbol):
        return None  # paper mode never consults a real exchange position


class LiveBackend:
    """Places REAL orders on Bybit. Reuses the SAME trade key already
    saved via /tradekey in the main bot (trade_keys.json) -- see
    app/trade_keys_store.py."""
    live = True

    def __init__(self, api_key: str, api_secret: str, leverage: int):
        self.api_key = api_key
        self.api_secret = api_secret
        self.leverage = leverage
        self._leverage_set: set[str] = set()

    def _ensure_leverage(self, symbol: str) -> None:
        if symbol in self._leverage_set:
            return
        bx.set_leverage(self.api_key, self.api_secret, symbol, self.leverage)
        self._leverage_set.add(symbol)

    def open_base(self, symbol, qty, stop_price):
        self._ensure_leverage(symbol)
        return bx.place_order(self.api_key, self.api_secret, symbol, "buy", qty, stop_price)

    def place_grid_leg(self, symbol, limit_price, qty, stop_price):
        return bx.place_order(self.api_key, self.api_secret, symbol, "buy", qty, stop_price,
                               entry_price=limit_price)

    def sync_stop(self, symbol, stop_price):
        bx.amend_stop_loss(self.api_key, self.api_secret, symbol, stop_price, side="long")

    def close_market(self, symbol, qty):
        bx.close_position(self.api_key, self.api_secret, symbol, "buy", qty)

    def cancel_all(self, symbol):
        bx.cancel_all_open_orders(self.api_key, self.api_secret, symbol)

    def get_position(self, symbol) -> dict | None:
        df = bx.fetch_open_positions(self.api_key, self.api_secret)
        if df.empty:
            return None
        row = df[df["symbol"] == symbol]
        if row.empty:
            return None
        r = row.iloc[0]
        return {"qty": float(r["qty"]), "avg_entry_price": float(r["avg_entry_price"])}

    def last_closed_exit(self, symbol: str) -> float | None:
        """Best-effort exit price for a deal that closed OUTSIDE this
        script's own close_market() call (i.e. Bybit's native stop-loss
        fired, or the position was closed by hand) -- used only for
        accurate CSV logging, never for a trading decision."""
        try:
            closed = bx.fetch_closed_trades(self.api_key, self.api_secret, lookback_days=2)
        except DataError:
            return None
        rows = closed[closed["symbol"] == symbol]
        if rows.empty:
            return None
        return float(rows.iloc[-1]["avg_exit_price"])


# ---------------------------------------------------------------- core --

_REASON_RU = {
    "TP": "тейк-профит",
    "SL": "стоп-лосс",
    "SL_ASSUMED": "стоп-лосс (предположительно, см. лог)",
}


def resolve_io_paths(args) -> None:
    """Picks the state/journal files for THIS run's mode, in place. Paper and
    live keep separate books (see DEFAULT_PAPER_* above); an explicitly
    passed --state-file/--log-csv always wins."""
    if getattr(args, "demo", False):   # 2026-10-25: демо-копия — свои файлы, реальные не трогаем
        args.state_file = args.state_file or str(BASE_DIR / "kc_roc_cci_wt_grid_live_demo_state.json")
        args.log_csv = args.log_csv or str(BASE_DIR / "kc_roc_cci_wt_grid_live_demo_trades.csv")
    if args.state_file is None:
        args.state_file = str(DEFAULT_STATE_FILE if args.live else DEFAULT_PAPER_STATE_FILE)
    if args.log_csv is None:
        args.log_csv = str(DEFAULT_LOG_CSV if args.live else DEFAULT_PAPER_LOG_CSV)


def reset_deal(state: DealState) -> None:
    """Clears a deal from local state. 2026-09-12: extracted from
    finalize_deal() so the "closed, but unconfirmed" path resets exactly the
    same fields -- note this bot also has `pending` (resting grid legs),
    which a hand-copied second reset would be easy to forget."""
    state.in_deal = False
    state.entry_time = None
    state.base_price = 0.0
    state.orders = []
    state.pending = []
    state.stop_synced_price = None


def finalize_deal(symbol: str, state: DealState, exit_time, avg_entry: float, exit_price: float,
                   reason: str, filled_pct: float, csv_path: Path, notify) -> None:
    gross = (exit_price - avg_entry) / avg_entry * 100.0
    log_deal(csv_path, symbol, state.entry_time, exit_time, len(state.orders), filled_pct,
              avg_entry, exit_price, reason, gross)
    emoji = "✅" if gross > 0 else "🛑"
    reason_ru = _REASON_RU.get(reason, reason)
    # 2026-09-01, user request: старое однострочное уведомление ("сделка
    # закрыта (TP), gross P&L +0.67%, avg_entry=0.10508, exit=0.10578")
    # мешало смесью EN-обозначений (avg_entry=/exit=) внутри русского
    # текста и не показывало ни длительность сделки, ни сколько ордеров
    # сетки реально исполнилось -- заменено на многострочный формат в духе
    # уведомлений основного SMC-бота.
    try:
        held_seconds = int((pd.Timestamp(exit_time) - pd.Timestamp(state.entry_time)).total_seconds())
        days, rem = divmod(held_seconds, 86400)
        hours, rem = divmod(rem, 3600)
        minutes, seconds = divmod(rem, 60)
        held_str = (f"{days}д " if days else "") + f"{hours:02d}:{minutes:02d}:{seconds:02d}"
    except Exception:
        held_str = "н/д"
    # 2026-09-14: тот же разбор, что и у сообщения об открытии. Результат
    # сделки -- первое, что человек хочет увидеть, поэтому P&L жирным сразу
    # под заголовком, а вход и выход сжаты в одну строку со стрелкой.
    notify("\n".join([
        f"{emoji} <b>{symbol}</b> — закрыта, {reason_ru}",
        "",
        f"P&L: <b>{gross:+.2f}%</b> (без учёта комиссии)",
        f"Вход {avg_entry:.6g} → выход {exit_price:.6g}",
        f"Ордеров: {len(state.orders)} ({filled_pct:g}% объёма) · {held_str}",
    ]))
    print(f"[{symbol}] deal closed: reason={reason} gross={gross:+.2f}% "
          f"avg_entry={avg_entry:.6g} exit={exit_price:.6g}")
    reset_deal(state)


# 2026-09-12: consecutive "Bybit reports no position" answers required before
# believing a deal really closed. Same change, same incident, as
# long_strategy15_latuserge_live.py -- see the longer note there. Short
# version: a single empty position response is indistinguishable from an API
# hiccup, and treating the first one as proof fabricated two -75% losses.
MISSING_POSITION_STRIKES = 3

_missing_position_streak: dict[str, int] = {}


def note_position_present(symbol: str) -> None:
    _missing_position_streak.pop(symbol, None)


def note_position_missing(symbol: str) -> int:
    _missing_position_streak[symbol] = _missing_position_streak.get(symbol, 0) + 1
    return _missing_position_streak[symbol]


# 2026-09-12: дедупликация повторяющихся предупреждений в Telegram -- та же
# правка, что и в long_strategy15_latuserge_live.py (там подробный комментарий).
# Коротко: сообщения вида "лимит одновременных сделок исчерпан" описывают
# СОСТОЯНИЕ, живущее много циклов, и при опросе раз в 60с улетали владельцу
# каждую минуту, топя в себе одноразовые сообщения о реальных сделках.
# Теперь -- один раз на эпизод, до снятия условия. В консоль по-прежнему
# пишется каждый цикл: это лог.
# 2026-09-13: отметки переехали из памяти процесса в файл (app/state_notices.py).
# Набор в оперативке честно не повторялся ВНУТРИ одного запуска, но у этих
# ботов перезапусков много, и каждый старт заново рассылал все всё ещё
# верные предупреждения. Две стратегии следят за одними монетами, поэтому
# каждое такое событие приходило в чат дважды. Теперь отметка переживает
# перезапуск, а повтор возможен не чаще, чем раз в REMIND_AFTER_SECONDS --
# совсем замолчать про нерешённую проблему тоже нельзя.
_BOT_ID = "kc_roc"


def notify_state_once(notify, symbol: str, kind: str, message: str) -> None:
    state_notices.notify_once(notify, _BOT_ID, symbol, kind, message)


def clear_state_notice(symbol: str, kind: str) -> None:
    state_notices.clear(_BOT_ID, symbol, kind)


def handle_external_close(symbol: str, state: DealState, params: Params, backend: LiveBackend,
                           csv_path: Path, notify, now_iso: str) -> None:
    """Live mode only: local state says a deal is open, and Bybit has now
    reported no position MISSING_POSITION_STRIKES cycles in a row.

    2026-09-12: no longer invents an exit price when the exchange cannot
    confirm one. The old fallback logged the stop level as if it were a real
    fill; on the sister bot that wrote two -75% losses for deals the exchange
    had never opened. An invented number is worse than a missing one -- it
    corrupts win-rate, profit factor and P&L totals, and reads exactly like a
    real disaster afterwards."""
    total_vol = sum(o.get("vol_pct", 0.0) for o in state.orders) or 100.0
    weighted = sum(o.get("vol_pct", 0.0) * o.get("price", state.base_price) for o in state.orders)
    avg_entry = (weighted / total_vol) if total_vol else state.base_price
    exit_price = backend.last_closed_exit(symbol)

    if exit_price is None:
        notify("\n".join([
            f"⚠️ {symbol}: позиция пропала с биржи, но подтверждения закрытия НЕТ",
            f"Биржа не вернула ни открытой позиции ({MISSING_POSITION_STRIKES} проверки подряд), "
            f"ни записи о закрытой сделке.",
            f"Сделка снята с локального учёта, но в журнал НЕ записана — "
            f"настоящий результат неизвестен, а выдуманный был бы хуже пустого.",
            f"Цена входа (средняя): {avg_entry:.6g}",
            f"Проверь эту монету на бирже вручную.",
        ]))
        print(f"[{symbol}] external close UNCONFIRMED: no position and no closed-trade record "
              f"after {MISSING_POSITION_STRIKES} consecutive checks -- clearing local deal WITHOUT "
              f"journaling it (avg_entry={avg_entry:.6g}). Orders deliberately NOT cancelled.",
              file=sys.stderr)
        reset_deal(state)
        return

    finalize_deal(symbol, state, now_iso, avg_entry, exit_price, "SL", total_vol, csv_path, notify)
    try:
        backend.cancel_all(symbol)
    except DataError as exc:
        print(f"[{symbol}] warning: cancel_all after external close failed (non-fatal): {exc}", file=sys.stderr)


def process_symbol(symbol: str, df: pd.DataFrame, params: Params, grid: list[tuple[float, float]],
                    state: DealState, backend, capital_per_deal: float, instrument: dict,
                    csv_path: Path, notify, all_deals: dict[str, DealState] | None = None,
                    max_concurrent_deals: int | None = None) -> None:
    ind = compute_indicators(df, params)
    i = len(df) - 1
    if not bool(ind["defined"].iloc[i]):
        return  # not enough history yet for every indicator to be defined
    row = df.iloc[i]
    now_time = row["open_time"]
    now_iso = pd.Timestamp(now_time).isoformat()
    step, min_qty = instrument["qty_step"], instrument["min_order_qty"]

    # ----- not currently in a deal: only decision is whether to open one --
    if not state.in_deal:
        if backend.live:
            # Safety check added 2026-08-31: if the state file was ever
            # lost, reset, or restored from an older snapshot while a real
            # position was still open on the exchange, state.in_deal=False
            # would otherwise be trusted blindly here and this could stack
            # a SECOND, unintended deal on top of an already-open one the
            # instant a fresh entry signal fires. Bybit is the source of
            # truth: if it reports a position that local state doesn't
            # know about, stop and wait for a human rather than guess.
            existing = backend.get_position(symbol)
            if existing is not None and sibling_holds(symbol):
                # позиция соседнего бота на том же счёте -- не тревога
                if symbol not in _sibling_busy_logged:
                    print(f"[{symbol}] занята {SIBLING_LABEL} (позиция соседнего бота на том же счёте) -- "
                          f"новые сделки по этой монете пропускаются, пока он её держит.")
                    _sibling_busy_logged.add(symbol)
                clear_state_notice(symbol, "unknown_position")
                return
            _sibling_busy_logged.discard(symbol)
            if existing is not None:
                print(f"[{symbol}] WARNING: local state says no open deal, but Bybit reports an open "
                      f"position (qty={existing['qty']}, avg_entry={existing['avg_entry_price']}) -- "
                      f"NOT opening a new deal until this is resolved. Check the position manually; if "
                      f"it's a leftover from before a state-file reset, either close it by hand or edit "
                      f"the state file to mark this symbol in_deal=true with the right avg price so the "
                      f"stop-loss stays synced and the take-profit exit can fire on it again.")
                # состояние, а не событие -- шлём один раз (см. notify_state_once)
                notify_state_once(notify, symbol, "unknown_position",
                                   f"⚠️ {symbol}: на бирже есть открытая позиция, о которой скрипт не знает -- "
                                   f"новые сделки по этой монете приостановлены, проверь вручную.")
                return
            clear_state_notice(symbol, "unknown_position")
        if not bool(ind["entry_signal"].iloc[i]):
            # сигнала нет -- эпизод "лимит исчерпан" закончился
            clear_state_notice(symbol, "deal_limit")
        if bool(ind["entry_signal"].iloc[i]) and max_concurrent_deals is not None and all_deals is not None:
            # 2026-08-31, user request: with 6 correlated crypto symbols on
            # the SAME dip-buying entry logic, a broad market-wide selloff
            # can plausibly fire the entry signal on several of them within
            # the same poll cycle -- opening every one of them at once would
            # commit capital_per_deal x N all at the worst possible moment
            # (exactly when correlated drawdown risk is highest), the
            # opposite of what "minimal deposit" live testing is for. Caps
            # how many deals can be open across ALL tracked symbols at
            # once; a signal beyond the cap is simply skipped (logged +
            # notified), not queued -- it may or may not still be valid
            # once a slot frees up, same as the backtest never queues a
            # missed entry either.
            open_count = sum(1 for s in all_deals.values() if s.in_deal)
            if open_count >= max_concurrent_deals:
                print(f"[{symbol}] entry signal fired, but max-concurrent-deals ({max_concurrent_deals}) "
                      f"already reached ({open_count} open) -- skipping.")
                notify_state_once(notify, symbol, "deal_limit",
                                   f"⏸ {symbol}: сигнал входа сработал, но лимит одновременных сделок "
                                   f"({max_concurrent_deals}) уже исчерпан -- пропущено. "
                                   f"Повторно об этом не пишу, пока лимит не освободится.")
                return
            clear_state_notice(symbol, "deal_limit")
        if bool(ind["entry_signal"].iloc[i]):
            price = float(row["close"])
            stop_price = price * (1 - params.stop_loss_pct / 100.0)
            qty_base = round_qty(capital_per_deal * grid[0][1] / 100.0 / price, step, min_qty)
            backend.open_base(symbol, qty_base, stop_price)
            state.in_deal = True
            state.entry_time = now_iso
            state.base_price = price
            state.orders = [{"price": price, "vol_pct": grid[0][1], "qty": qty_base}]
            state.pending = []
            for off, vol in grid[1:]:
                limit_price = price * (1 - off / 100.0)
                qty_leg = round_qty(capital_per_deal * vol / 100.0 / limit_price, step, min_qty)
                # 2026-09-01: real bug found in production -- with the
                # default --capital-per-deal 20 and the ORIGINAL 55/35/10
                # grid split, the smallest leg (10% = 2 USDT notional) was
                # BELOW Bybit's ~5 USDT minimum order value for every
                # symbol, unconditionally (it's a fixed dollar amount,
                # not price-dependent). Before this fix, that raised
                # DataError straight out of this loop: the base order
                # (already filled for real) and any earlier legs stayed
                # open, but state.stop_synced_price and the "deal
                # opened" notification never got set/sent, and the
                # exception surfaced as a scary top-level "[SKIP this
                # cycle]" line even though most of the deal had already
                # gone through. Catching it here lets the deal continue
                # with whatever legs the exchange actually accepted --
                # same "graceful, no leg queued for a silent retry"
                # trade-off backend.place_grid_leg() already has no
                # retry path for either.
                #
                # Separately (same day): the default grid was rebalanced
                # from 55/35/10 (three legs) to 65/35 (two legs) so the
                # remaining leg clears the 5 USDT minimum on its own at
                # --capital-per-deal 20 (35% = 7 USDT), instead of relying
                # on this try/except to paper over a leg that would be
                # rejected on every single deal. A fresh backtest on all 6
                # live symbols (20000 1m bars, ~2 weeks) showed 65/35 is
                # statistically indistinguishable from 55/35/10 -- net P&L%
                # +0.61/+0.65/+0.68% (three fee scenarios) vs the old
                # grid's +0.58/+0.61/+0.65%, same 96.4% win rate, n=55 vs
                # n=56 deals -- because the dropped -3.5% leg rarely filled
                # anyway (avg orders filled/deal dropped from 1.39 to 1.20).
                # This try/except stays as a safety net for any OTHER
                # exchange-side rejection (not just undersized legs), but
                # it should no longer trigger on the min-order-value case
                # specifically.
                try:
                    backend.place_grid_leg(symbol, limit_price, qty_leg, stop_price)
                except DataError as exc:
                    print(f"[{symbol}] WARNING: grid leg ({vol:g}% @ -{off:g}%, ~{capital_per_deal * vol / 100.0:.2f} "
                          f"USDT notional) rejected by the exchange -- skipping this leg only, the deal "
                          f"continues with the orders that did place: {exc}")
                    notify(f"⚠️ {symbol}: сеточный ордер ({vol:g}% @ -{off:g}%) отклонён биржей (вероятно, "
                           f"ниже минимального объёма ордера) -- пропущен, сделка продолжается с "
                           f"остальными ордерами.")
                    continue
                state.pending.append({"limit_price": limit_price, "vol_pct": vol, "qty": qty_leg})
            state.stop_synced_price = stop_price
            # 2026-09-01, user request: старое уведомление ("открыта
            # DCA-сделка, база @ ..., стоп @ ...") тащило устаревшее
            # название стратегии (DCA -- от Veles, переименовано в
            # kc_roc_cci_wt_grid ещё 2026-08-31) и не показывало ни ногу
            # сетки, ни капитал, ни условие тейка -- заменено на
            # многострочный формат с деталями по каждому ордеру.
            capital_base = capital_per_deal * grid[0][1] / 100.0
            # 2026-09-14: формат переписан. Было шесть длинных строк, каждая
            # со своим словом-подписью ("База:", "Нога сетки:",
            # "Стоп-лосс:"...), и первую строку съедал ярлык стратегии.
            # Стало: событие и монета в первой строке жирным (именно её
            # показывает телефон в уведомлении), дальше короткие строки, где
            # цена стоит первой -- читают всегда её, а не количество.
            lines = [
                f"🟢 <b>{symbol}</b> — сделка открыта",
                "",
                f"Вход: <b>{price:.6g}</b> × {qty_base:g} ({capital_base:.2f} USDT)",
            ]
            for leg in state.pending:
                leg_usdt = capital_per_deal * leg["vol_pct"] / 100.0
                off_pct = (1 - leg["limit_price"] / price) * 100.0
                lines.append(
                    f"Докупка: {leg['limit_price']:.6g} × {leg['qty']:g} "
                    f"(−{off_pct:.2f}%, {leg_usdt:.2f} USDT)"
                )
            lines.append(f"Стоп: <b>{stop_price:.6g}</b> (−{params.stop_loss_pct:g}%)")
            lines.append(f"Тейк: WaveTrend SELL + P&L ≥ {params.tp_min_pnl_pct:g}%")
            lines.append(f"Объём сделки: {capital_per_deal:g} USDT")
            notify("\n".join(lines))
            print(f"[{symbol}] deal opened @ {price:.6g}, stop @ {stop_price:.6g}")
            # 2026-09-06, user request: same as long_strategy15_latuserge_live.py
            # this same day -- also send the entry/SL/TP picture as a
            # Telegram photo (same renderer + same 15m/150-bar style as the
            # Mini App's "Торговля"/"Здоровье" tabs). Fresh 15m fetch,
            # separate from this strategy's own 1m `df`, purely for a
            # nicer-looking chart. take_profit omitted -- this bot's
            # take-profit is a dynamic WaveTrend-SELL+P&L condition, not a
            # fixed price, so there's no single line to draw for it.
            # Wrapped so a bad kline fetch or a Telegram hiccup here can
            # NEVER block the deal itself, which has already fully opened
            # above.
            try:
                chart_df = get_klines(symbol, "15m", limit=150)
                png = chart.render_position_chart(
                    df=chart_df, symbol_label=symbol.replace("USDT", ""), timeframe="15m",
                    side="buy", entry=price, stop_loss=stop_price,
                )
                notify.send_photo(png, f"{symbol} · вход {price:.6g}, стоп {stop_price:.6g}")
            except Exception as exc:
                print(f"[{symbol}] warning: couldn't render/send position-open chart (non-fatal): {exc}", file=sys.stderr)
        return

    # ----- already in a deal -----------------------------------------
    if backend.live:
        pos = backend.get_position(symbol)
        if pos is None:
            # 2026-09-12: one empty answer is not proof the deal closed.
            strikes = note_position_missing(symbol)
            if strikes < MISSING_POSITION_STRIKES:
                print(f"[{symbol}] Bybit reports no position ({strikes}/{MISSING_POSITION_STRIKES}) "
                      f"while local state says the deal is open -- not acting yet, re-checking next cycle.",
                      file=sys.stderr)
                return
            handle_external_close(symbol, state, params, backend, csv_path, notify, now_iso)
            note_position_present(symbol)
            return
        note_position_present(symbol)
        avg_entry = pos["avg_entry_price"]
        filled_pct = sum(o.get("vol_pct", 0.0) for o in state.orders)
        # A pending leg filled if the exchange qty grew past what we last
        # recorded -- move it from pending to orders for bookkeeping (best
        # effort; the actual P&L math below always uses Bybit's own
        # avg_entry_price, never this local reconstruction).
        known_qty = sum(o.get("qty", 0.0) for o in state.orders)
        if pos["qty"] > known_qty * 1.0005 and state.pending:
            leg = state.pending.pop(0)
            state.orders.append({"price": leg["limit_price"], "vol_pct": leg["vol_pct"], "qty": leg["qty"]})
            filled_pct = sum(o.get("vol_pct", 0.0) for o in state.orders)
        stop_price = avg_entry * (1 - params.stop_loss_pct / 100.0)
        if state.stop_synced_price is None or abs(stop_price - state.stop_synced_price) / stop_price > 0.0005:
            try:
                backend.sync_stop(symbol, stop_price)
                state.stop_synced_price = stop_price
            except DataError as exc:
                print(f"[{symbol}] warning: stop-loss sync failed (will retry next cycle): {exc}", file=sys.stderr)
    else:
        # paper: simulate the exact same fill logic as the backtest engine
        still_pending = []
        for order in state.pending:
            if row["low"] <= order["limit_price"]:
                state.orders.append({"price": order["limit_price"], "vol_pct": order["vol_pct"]})
            else:
                still_pending.append(order)
        state.pending = still_pending
        total_vol = sum(o["vol_pct"] for o in state.orders)
        avg_entry = sum(o["vol_pct"] * o["price"] for o in state.orders) / total_vol
        filled_pct = total_vol
        stop_price = avg_entry * (1 - params.stop_loss_pct / 100.0)

    if not backend.live and row["low"] <= stop_price:
        # Paper mode has to simulate the stop itself; live mode's stop is
        # a real exchange order and is detected next cycle via
        # handle_external_close() once the position actually disappears.
        finalize_deal(symbol, state, now_time, avg_entry, stop_price, "SL", filled_pct, csv_path, notify)
        return

    pnl_now = (float(row["close"]) - avg_entry) / avg_entry * 100.0
    if bool(ind["sell_cross"].iloc[i]) and pnl_now >= params.tp_min_pnl_pct:
        if backend.live:
            pos = backend.get_position(symbol)  # re-check right before acting
            if pos is not None:
                backend.close_market(symbol, pos["qty"])
                try:
                    backend.cancel_all(symbol)
                except DataError as exc:
                    print(f"[{symbol}] warning: cancel_all after TP failed (non-fatal): {exc}", file=sys.stderr)
        finalize_deal(symbol, state, now_time, avg_entry, float(row["close"]), "TP", filled_pct, csv_path, notify)


# ----------------------------------------------------------------- cli --

def build_params(args) -> Params:
    grid = parse_grid(args.grid_offsets, args.grid_volumes)
    return Params(
        grid=grid, kc_length=args.kc_length, kc_mult=args.kc_mult,
        roc_length=args.roc_length, roc_threshold=args.roc_threshold,
        htf1_minutes=args.htf1, atr_length=args.atr_length,
        atr_min=args.atr_min, atr_max=args.atr_max,
        htf2_minutes=args.htf2, cci_length=args.cci_length, cci_threshold=args.cci_threshold,
        wt_n1=args.wt_n1, wt_n2=args.wt_n2, wt_avg_len=args.wt_avg_len,
        tp_min_pnl_pct=args.tp_min_pnl_pct, stop_loss_pct=args.stop_loss_pct,
        max_deal_bars=10**9,  # no timeout in live mode -- a deal stays open until SL/TP, period
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--symbol", nargs="+", default=DEFAULT_WATCHLIST)
    parser.add_argument("--demo", action="store_true",
                        help="2026-10-25: ДЕМО-счёт Bybit (нужен BYBIT_TRADE_BASE=api-demo), свой учёт объёма (app/ledger_backend.py), "
                             "свои файлы *_demo_*, ключ из слота bybit_demo. Реальный счёт не трогает.")
    parser.add_argument("--live", action="store_true", help="Place REAL orders on Bybit. Default: dry-run/paper.")
    parser.add_argument("--capital-per-deal", type=float, default=20.0,
                         help="Total NOTIONAL (not margin) per deal in USDT, split across the grid legs.")
    parser.add_argument("--leverage", type=int, default=5)
    parser.add_argument("--max-trade-leverage", type=int, default=5, help="Hard cap, same guard as main.py's /trade")
    parser.add_argument("--max-concurrent-deals", type=int, default=2,
                         help="Max deals open at once across ALL tracked symbols (default 2 of 6) -- caps "
                              "total committed capital during a correlated market-wide move instead of "
                              "letting every symbol's entry fire at once. 0 = unlimited (old behavior).")
    parser.add_argument("--poll-seconds", type=int, default=60)
    parser.add_argument("--lookback-bars", type=int, default=3000,
                         help="1m bars of history fetched each cycle for indicator warmup (~2 days by default)")
    # 2026-09-12: default resolved after parsing (see main()) because it now
    # depends on --live vs paper. Explicit path still wins in both modes.
    parser.add_argument("--state-file", default=None,
                         help=f"default: {DEFAULT_STATE_FILE.name} with --live, "
                              f"{DEFAULT_PAPER_STATE_FILE.name} in paper mode")
    parser.add_argument("--log-csv", default=None,
                         help=f"default: {DEFAULT_LOG_CSV.name} with --live, "
                              f"{DEFAULT_PAPER_LOG_CSV.name} in paper mode")
    parser.add_argument("--telegram-alerts", action="store_true", default=True)
    parser.add_argument("--no-telegram-alerts", dest="telegram_alerts", action="store_false")

    parser.add_argument("--grid-offsets", default="0,3")
    parser.add_argument("--grid-volumes", default="65,35")
    parser.add_argument("--kc-length", type=int, default=20)
    parser.add_argument("--kc-mult", type=float, default=2.0)
    parser.add_argument("--roc-length", type=int, default=14)
    parser.add_argument("--roc-threshold", type=float, default=-1.0)
    parser.add_argument("--htf1", type=int, default=15)
    parser.add_argument("--atr-length", type=int, default=14)
    parser.add_argument("--atr-min", type=float, default=0.05)
    parser.add_argument("--atr-max", type=float, default=5.0)
    parser.add_argument("--htf2", type=int, default=30)
    parser.add_argument("--cci-length", type=int, default=20)
    parser.add_argument("--cci-threshold", type=float, default=-100.0)
    parser.add_argument("--wt-n1", type=int, default=10)
    parser.add_argument("--wt-n2", type=int, default=21)
    parser.add_argument("--wt-avg-len", type=int, default=4)
    parser.add_argument("--tp-min-pnl-pct", type=float, default=0.5)
    parser.add_argument("--stop-loss-pct", type=float, default=4.0)

    args = parser.parse_args()

    # 2026-09-13: одна копия на стратегию. 13.09 на машине владельца
    # одновременно жили ЧЕТЫРЕ копии этого скрипта (--live, настоящие
    # ордера): restart_grid_bot.bat старые копии убивает, а запуск
    # "python <скрипт> --live" руками из PowerShell -- нет.
    # В журнале сделок остался след: ARBUSDT, две отдельные сделки с
    # ОДНИМ временем входа 2026-09-08T16:54:00+00:00 -- обе копии
    # увидели один сигнал и обе поставили ордер.
    # Ставится ПОСЛЕ parse_args, чтобы --help работал всегда.
    single_instance.acquire_or_exit("kc_roc_demo" if args.demo else "kc_roc")   # 2026-10-25: демо-копия — свой замок
    params = build_params(args)
    grid = params.grid
    symbols = [s.upper() for s in args.symbol]

    # 2026-09-01: Bybit rejects ANY order below ~5 USDT notional
    # (retCode=110094, "Order does not meet minimum order value 5USDT")
    # on its linear USDT perpetuals -- this is a flat exchange-wide
    # floor, not something get_instrument_info() exposes, so it can't be
    # checked live per-symbol; hardcoded here from the real error seen in
    # production. A grid leg's dollar size is capital_per_deal * vol% and
    # does NOT depend on price, so this is either always fine or always
    # broken for a given --capital-per-deal -- worth telling the user
    # up front instead of letting it surface only as a confusing
    # per-cycle error on the first real entry signal (see the try/except
    # around backend.place_grid_leg() in process_symbol(), which now
    # skips a rejected leg gracefully instead of aborting the whole
    # deal-open, but a leg that never places is still capital that never
    # gets put to work).
    _MIN_ORDER_VALUE_USDT = 5.0
    for off, vol in grid[1:]:
        leg_usdt = args.capital_per_deal * vol / 100.0
        if leg_usdt < _MIN_ORDER_VALUE_USDT:
            min_capital_needed = _MIN_ORDER_VALUE_USDT * 100.0 / vol
            print(f"WARNING: grid leg {vol:g}% @ -{off:g}% is {leg_usdt:.2f} USDT notional at "
                  f"--capital-per-deal {args.capital_per_deal:g} -- below Bybit's ~{_MIN_ORDER_VALUE_USDT:g} "
                  f"USDT minimum order value. This leg will be rejected and skipped on EVERY deal open "
                  f"(the deal still opens fine with the remaining legs). Raise --capital-per-deal to at "
                  f"least {min_capital_needed:.2f} to let this leg place.", file=sys.stderr)

    ok, reason = check_leverage(args.leverage, args.max_trade_leverage)
    if not ok:
        print(f"REFUSING TO START: {reason}", file=sys.stderr)
        sys.exit(1)

    resolve_io_paths(args)

    state_file = StateFile(Path(args.state_file))
    csv_path = Path(args.log_csv)
    # 2026-09-06: tag every notify() message with paper/live mode -- same
    # fix as long_strategy15_latuserge_live.py this same day, after a
    # dry-run "deal opened" message for that bot's ARBUSDT looked
    # indistinguishable from a real trade (see
    # telegram-notifications-diagnosis-2026-09-06.md).
    # 2026-09-14: скобки укорочены. Различие paper/live терять нельзя (из-за
    # его отсутствия 06.09 бумажная сделка выглядела как настоящая), но
    # "(симуляция, без реальных денег)" занимало пол-строки в каждом
    # сообщении. Смысл сохранён, длина втрое меньше.
    mode_tag = "🔴 LIVE · реальные ордера" if args.live else "🧪 PAPER · симуляция"
    notify = make_notifier(args.telegram_alerts, strategy_label=f"{STRATEGY_LABEL} · {mode_tag}")

    # 2026-09-06, user request: --max-concurrent-deals used to be read once
    # here and baked into every process_symbol() call for the life of the
    # process -- changing it meant stopping and restarting the bot. Now
    # seeds a live-editable settings file (own JSON, same pattern as
    # scan_settings.json) with the CLI value on first run, then re-reads it
    # fresh every poll cycle below via MaxConcurrentDealsSettings.read_live()
    # -- so /maxdeals in main.py (or hand-editing the file) takes effect on
    # the very next cycle, no restart needed. 0 keeps meaning "no cap",
    # same as the old `(args.max_concurrent_deals or None)` behavior.
    if getattr(args, "demo", False):   # 2026-10-25: на демо свой лимит сделок (без ограничений реала), файл отдельный
        globals()["KC_GRID_MAX_DEALS_FILE"] = BASE_DIR / "kc_roc_demo_max_deals.json"
        MaxConcurrentDealsSettings(BASE_DIR / "kc_roc_demo_max_deals.json", default=args.max_concurrent_deals).set(args.max_concurrent_deals)
    if not KC_GRID_MAX_DEALS_FILE.exists():
        MaxConcurrentDealsSettings(KC_GRID_MAX_DEALS_FILE, default=args.max_concurrent_deals).set(
            args.max_concurrent_deals)

    if args.live:
        # 2026-09-06, user request: per-strategy keys -- get_for_strategy()
        # returns this bot's OWN dedicated Bybit key if one was set via
        # /tradekey kcroc bybit ..., otherwise falls back to the shared
        # default key (same key every strategy used before this feature
        # existed), so nothing changes for a user who never sets a
        # dedicated key. See app/trade_keys_store.py's module docstring.
        if args.demo:
            from app.exchanges import bybit as _bxd  # noqa: PLC0415
            if "api-demo" not in _bxd.TRADE_BASE:
                print("REFUSING --demo: BYBIT_TRADE_BASE не указывает на api-demo.bybit.com — запускай через start_demo_bots.bat",
                      file=sys.stderr); sys.exit(1)
            creds = TradeKeysStore(TRADE_KEYS_FILE).get_for_strategy("bybit_demo", "bybit")
        else:
            creds = TradeKeysStore(TRADE_KEYS_FILE).get_for_strategy("kc_roc", "bybit")
        if creds is None:
            print("REFUSING TO START --live: no Bybit trade key saved in trade_keys.json "
                  "(set one up via /tradekey bybit ... for the shared default, or "
                  "/tradekey kcroc bybit ... for a key dedicated to this bot).", file=sys.stderr)
            sys.exit(1)
        if args.demo:
            from app.ledger_backend import LedgerBackend  # noqa: PLC0415
            backend = LedgerBackend(creds["api_key"], creds["api_secret"], args.leverage, "KCR",
                                    BASE_DIR / "kc_roc_cci_wt_grid_live_demo_ledger.json")
        else:
            backend = LiveBackend(creds["api_key"], creds["api_secret"], args.leverage)
        print(("*** DEMO MODE -- Bybit DEMO account (api-demo), own-volume ledger, NO real money. " if args.demo else "*** LIVE MODE -- REAL ORDERS on Bybit. ") + f"{len(symbols)} symbols, "
              f"{args.capital_per_deal} USDT notional/deal, {args.leverage}x leverage. ***")
    else:
        backend = PaperBackend()
        print(f"Dry-run (paper) mode -- no real orders. {len(symbols)} symbols, "
              f"simulating {args.capital_per_deal} USDT notional/deal.")

    instruments: dict[str, dict] = {}
    for symbol in symbols:
        try:
            instruments[symbol] = bx.get_instrument_info(symbol, category=CATEGORY)
        except DataError as exc:
            print(f"[{symbol}] couldn't fetch instrument info, skipping this symbol: {exc}", file=sys.stderr)

    active_symbols = [s for s in symbols if s in instruments]
    if not active_symbols:
        print("No symbols left after instrument-info lookup -- nothing to do.", file=sys.stderr)
        sys.exit(1)

    # 2026-09-01: real finding from a running --live deal on ETHUSDT --
    # round_qty() floors a leg's raw quantity to a whole multiple of
    # qtyStep, then floors AGAIN to min_order_qty if that's larger. For a
    # cheap coin (ARBUSDT @ ~$0.10, qtyStep tiny relative to capital) this
    # barely matters. For a pricier coin (ETHUSDT @ ~$2400, qtyStep/
    # minOrderQty = 0.01 ETH = ~$24 notional on its own) BOTH the 65% base
    # leg (target ~$13) and the 35% safety leg (target ~$7) round up to
    # the SAME minimum tradable quantity -- the intended weighting
    # collapses to two equal legs, and if both fill the real position on
    # that one deal ends up close to 2x --capital-per-deal instead of
    # matching it. This already happened live: ETHUSDT's base order
    # filled at ~$23.89 instead of the intended ~$13. Unlike the earlier
    # $5-minimum-order-value bug, the exchange does NOT reject this --
    # the order is valid and fills fine, so nothing prints an error; it
    # just silently trades a bigger notional than requested. Checked here
    # at startup (one extra get_last_price() call per symbol, same
    # amortized cost as the instrument-info lookup above) so it shows up
    # as a visible warning instead of only being discoverable by reading
    # the state file after the fact.
    _QTY_FLOOR_WARN_RATIO = 1.5  # warn if a leg's actual notional is >=1.5x its intended target
    for symbol in active_symbols:
        step, min_qty = instruments[symbol]["qty_step"], instruments[symbol]["min_order_qty"]
        try:
            last_price = bx.get_last_price(symbol, category=CATEGORY)
        except DataError as exc:
            print(f"[{symbol}] couldn't fetch last price for the qty-floor sanity check, skipping it: {exc}",
                  file=sys.stderr)
            continue
        for off, vol in grid:
            # same price convention process_symbol() itself uses: the base
            # leg (off==0) trades at the live price, every other leg is a
            # resting limit order at off% below the base fill price.
            leg_price = last_price * (1 - off / 100.0)
            target_usdt = args.capital_per_deal * vol / 100.0
            raw_qty = target_usdt / leg_price
            actual_qty = round_qty(raw_qty, step, min_qty)
            actual_usdt = actual_qty * leg_price
            if target_usdt > 0 and actual_usdt / target_usdt >= _QTY_FLOOR_WARN_RATIO:
                leg_label = "base order" if off == grid[0][0] else f"grid leg @ -{off:g}%"
                print(f"WARNING: [{symbol}] {leg_label} ({vol:g}% of --capital-per-deal "
                      f"{args.capital_per_deal:g} = {target_usdt:.2f} USDT target) rounds up to "
                      f"{actual_qty:g} {symbol.replace('USDT', '')} (~{actual_usdt:.2f} USDT, "
                      f"{actual_usdt / target_usdt:.1f}x the target) because the exchange's minimum "
                      f"tradable size for this symbol ({min_qty:g}, step {step:g}) is large relative to "
                      f"this deal's capital at the current price (~{last_price:g}). Raise "
                      f"--capital-per-deal for this symbol (or drop it from --symbol) if this much "
                      f"real exposure per deal isn't intended.", file=sys.stderr)

    print(f"Tracking: {', '.join(active_symbols)}. Poll every {args.poll_seconds}s. "
          f"State: {args.state_file}  Log: {args.log_csv}  Max concurrent deals: "
          f"{args.max_concurrent_deals:g} (live-editable via /maxdeals in Telegram or by editing "
          f"{KC_GRID_MAX_DEALS_FILE.name} directly -- takes effect next poll cycle, no restart needed).")

    while True:
        cycle_start = time.time()
        current_max_concurrent = MaxConcurrentDealsSettings.read_live(
            KC_GRID_MAX_DEALS_FILE, args.max_concurrent_deals)
        for symbol in active_symbols:
            state = state_file.get(symbol)
            try:
                df = fetch_history(symbol, "1m", args.lookback_bars)
                now_utc = datetime.now(timezone.utc)
                df = df[df["open_time"] + pd.Timedelta(minutes=1) <= now_utc].reset_index(drop=True)
                if df.empty:
                    continue
                process_symbol(symbol, df, params, grid, state, backend,
                                args.capital_per_deal, instruments[symbol], csv_path, notify,
                                all_deals=state_file.deals,
                                max_concurrent_deals=(current_max_concurrent or None))
            except DataError as exc:
                print(f"[{symbol}] [SKIP this cycle] {exc}", file=sys.stderr)
            except Exception:
                print(f"[{symbol}] unexpected error this cycle (continuing):", file=sys.stderr)
                traceback.print_exc()
            finally:
                state_file.save()
        elapsed = time.time() - cycle_start
        time.sleep(max(1.0, args.poll_seconds - elapsed))


if __name__ == "__main__":
    main()
