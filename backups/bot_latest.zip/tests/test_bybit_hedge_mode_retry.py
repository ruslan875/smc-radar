"""
2026-08-25, round 15: regression test for a REAL live failure -- the
user's own account hit "Bybit order-create error: position idx not match
position mode (retCode=10001)" on a genuine /trade attempt. Root cause
(confirmed against Bybit's own v5 docs, not guessed): app/exchanges/
bybit.py always omitted `positionIdx` (equivalent to sending 0, i.e.
assuming One-Way Mode) in both place_order() and amend_stop_loss() --
correct for a One-Way account, but Bybit rejects that outright with
retCode 10001 the instant the account is actually in Hedge Mode, since
Hedge Mode requires positionIdx 1 (Buy/long side) or 2 (Sell/short side)
instead. The fix retries ONCE, automatically, with the correct
side-appropriate positionIdx -- safe because retCode 10001 is a
synchronous parameter-validation rejection (nothing was created/changed
by the first attempt), unlike the network-ambiguous failures this module
deliberately never auto-retries (see place_order()'s own docstring).

Run: python tests/test_bybit_hedge_mode_retry.py
"""
import sys
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.data import DataError
from app.exchanges import bybit


def _payload(ret_code, ret_msg="", order_id="OID-1"):
    return {"retCode": ret_code, "retMsg": ret_msg, "result": {"orderId": order_id, "orderLinkId": "LINK-1"}}


def test_place_order_one_way_success_never_retries():
    """The common/original case -- a One-Way Mode account -- must behave
    exactly as before this round: one call, positionIdx never sent."""
    with patch("app.exchanges.bybit._signed_post", return_value=_payload(0)) as mock_post:
        result = bybit.place_order("k", "s", "BTCUSDT", "buy", 1.0, 90.0)
    assert result == {"order_id": "OID-1", "order_link_id": "LINK-1"}
    mock_post.assert_called_once()
    assert "positionIdx" not in mock_post.call_args[0][3]
    print("OK: a One-Way-Mode success places the order in a single call, no positionIdx sent.")


def test_place_order_retries_with_hedge_position_idx_on_10001_and_succeeds():
    responses = [
        _payload(10001, "position idx not match position mode"),
        _payload(0, order_id="OID-2"),
    ]
    with patch("app.exchanges.bybit._signed_post", side_effect=responses) as mock_post:
        result = bybit.place_order("k", "s", "BTCUSDT", "buy", 1.0, 90.0)
    assert result["order_id"] == "OID-2"
    assert mock_post.call_count == 2
    first_params, second_params = mock_post.call_args_list[0][0][3], mock_post.call_args_list[1][0][3]
    assert "positionIdx" not in first_params
    assert second_params["positionIdx"] == 1  # buy -> hedge-mode Buy/long side
    print("OK: a Hedge-Mode account's 'position idx not match position mode' rejection is "
          "automatically retried once with positionIdx=1 for a buy order, and succeeds.")


def test_place_order_sell_side_retries_with_positionidx_2():
    responses = [
        _payload(10001, "position idx not match position mode"),
        _payload(0, order_id="OID-3"),
    ]
    with patch("app.exchanges.bybit._signed_post", side_effect=responses) as mock_post:
        result = bybit.place_order("k", "s", "BTCUSDT", "sell", 1.0, 110.0)
    assert result["order_id"] == "OID-3"
    assert mock_post.call_args_list[1][0][3]["positionIdx"] == 2  # sell -> hedge-mode Sell/short side
    print("OK: the same retry correctly uses positionIdx=2 for a sell order.")


def test_place_order_does_not_retry_on_unrelated_10001_error():
    """retCode 10001 is Bybit's generic parameter-error code, not
    exclusive to the position-idx case -- a different retMsg must NOT
    trigger the hedge-mode retry (which wouldn't fix it and could mask
    the real problem)."""
    with patch("app.exchanges.bybit._signed_post", return_value=_payload(10001, "qty invalid")) as mock_post:
        try:
            bybit.place_order("k", "s", "BTCUSDT", "buy", 1.0, 90.0)
            assert False, "an unrelated parameter error must not be silently swallowed"
        except DataError as exc:
            assert "qty invalid" in str(exc)
    mock_post.assert_called_once()
    print("OK: a retCode 10001 for an unrelated reason (not position idx) is NOT retried and "
          "still raises with the original message.")


def test_place_order_does_not_retry_on_other_error_codes():
    with patch("app.exchanges.bybit._signed_post", return_value=_payload(30208, "risk limit exceeded")) as mock_post:
        try:
            bybit.place_order("k", "s", "BTCUSDT", "buy", 1.0, 90.0)
            assert False
        except DataError as exc:
            assert "risk limit exceeded" in str(exc)
    mock_post.assert_called_once()
    print("OK: a completely different error code is raised immediately, no retry attempted.")


def test_place_order_gives_up_after_a_failed_retry():
    responses = [
        _payload(10001, "position idx not match position mode"),
        _payload(10001, "position idx not match position mode"),  # still wrong, e.g. some other misconfiguration
    ]
    with patch("app.exchanges.bybit._signed_post", side_effect=responses) as mock_post:
        try:
            bybit.place_order("k", "s", "BTCUSDT", "buy", 1.0, 90.0)
            assert False
        except DataError as exc:
            assert "position idx" in str(exc)
    assert mock_post.call_count == 2  # exactly one retry, never loops
    print("OK: if the retry ALSO fails, the error is surfaced (exactly one retry attempt, no loop).")


def test_amend_stop_loss_one_way_success_never_retries():
    with patch("app.exchanges.bybit._signed_post", return_value=_payload(0)) as mock_post:
        bybit.amend_stop_loss("k", "s", "BTCUSDT", 95.0)
    mock_post.assert_called_once()
    assert mock_post.call_args[0][3]["positionIdx"] == 0
    print("OK: amend_stop_loss's One-Way-Mode success is unchanged -- one call, positionIdx=0.")


def test_amend_stop_loss_retries_with_hedge_position_idx_when_side_given():
    responses = [
        _payload(10001, "position idx not match position mode"),
        _payload(0),
    ]
    with patch("app.exchanges.bybit._signed_post", side_effect=responses) as mock_post:
        bybit.amend_stop_loss("k", "s", "BTCUSDT", 95.0, side="long")
    assert mock_post.call_count == 2
    assert mock_post.call_args_list[1][0][3]["positionIdx"] == 1
    print("OK: amend_stop_loss retries with the correct hedge positionIdx when the autopilot "
          "passes the position's side.")


def test_amend_stop_loss_without_side_does_not_guess():
    """No `side` was passed (the autopilot always passes one, but a
    caller that doesn't have it must not get a silently-guessed retry) --
    the original error surfaces exactly as it did before this round."""
    with patch("app.exchanges.bybit._signed_post",
               return_value=_payload(10001, "position idx not match position mode")) as mock_post:
        try:
            bybit.amend_stop_loss("k", "s", "BTCUSDT", 95.0)
            assert False
        except DataError as exc:
            assert "position idx" in str(exc)
    mock_post.assert_called_once()
    print("OK: without a `side` hint, amend_stop_loss does not guess a positionIdx and raises "
          "the original error, same as before this round.")


def test_amend_stop_loss_short_side_uses_positionidx_2():
    responses = [
        _payload(10001, "position idx not match position mode"),
        _payload(0),
    ]
    with patch("app.exchanges.bybit._signed_post", side_effect=responses) as mock_post:
        bybit.amend_stop_loss("k", "s", "BTCUSDT", 95.0, side="short")
    assert mock_post.call_args_list[1][0][3]["positionIdx"] == 2
    print("OK: a short position retries with positionIdx=2.")


if __name__ == "__main__":
    test_place_order_one_way_success_never_retries()
    test_place_order_retries_with_hedge_position_idx_on_10001_and_succeeds()
    test_place_order_sell_side_retries_with_positionidx_2()
    test_place_order_does_not_retry_on_unrelated_10001_error()
    test_place_order_does_not_retry_on_other_error_codes()
    test_place_order_gives_up_after_a_failed_retry()
    test_amend_stop_loss_one_way_success_never_retries()
    test_amend_stop_loss_retries_with_hedge_position_idx_when_side_given()
    test_amend_stop_loss_without_side_does_not_guess()
    test_amend_stop_loss_short_side_uses_positionidx_2()
    print("\nAll Bybit Hedge-Mode positionIdx retry checks passed.")
