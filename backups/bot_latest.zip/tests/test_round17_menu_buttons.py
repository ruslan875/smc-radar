"""
2026-08-26, round 17: Telegram button-menu regression tests.

The user asked to stop having to type slash-commands and get "buttons for
all commands at once" instead -- a persistent reply keyboard (BTN_REPORT/
BTN_IDEAS/BTN_NEWCODE/BTN_SCAN/BTN_AUTOPILOT/BTN_INSTANTTRADE/BTN_OTHER,
see main.py's _main_menu_keyboard) plus inline keyboards for the two
choices that need a sub-selection (autopilot on/off, instanttrade on/off,
plus the pre-existing scan-universe picker).

Every button/callback in this feature is a THIN routing alias onto code
that already existed before this round -- nothing here is a second,
parallel implementation of report/ideas/newcode/scan/autopilot/
instanttrade. These tests are specifically about proving that: a button
tap and its slash-command equivalent must reach the exact same handler
function with the exact same arguments, not just "not crash".

Covers:
  1. Reply-keyboard button labels route to the SAME handler as their
     slash-command equivalent (report/ideas/newcode/scan).
  2. The autopilot/instanttrade inline-keyboard callbacks call the exact
     same underlying command handler (hence the exact same toggle logic)
     as typing "/autopilot on|off" / "/instanttrade on|off" would.
  3. The scan-universe inline callback maps to the right underlying
     ScanSettings.set_mode() call.
  4. answer_callback_query is actually called for every callback_query
     update this bot now handles (scan/autopilot/instanttrade/unknown) --
     no tap should ever leave an infinite spinner.
  5. last_update_id advances correctly for a callback_query-type update,
     not just message-type ones.
  6. An unrecognized/malformed callback `data` string is handled
     gracefully -- no crash, no silent wrong action, and it's still
     acknowledged.

Run: python tests/test_round17_menu_buttons.py
"""
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.config import Settings


def _settings(**overrides):
    kwargs = dict(
        telegram_token="t", telegram_chat_id="555", timeframe="15m", swing_left=3, swing_right=3,
        poll_seconds=60, watchlist=["BTCUSDT"], use_htf_filter=True, show_rsi=False,
        github_token="", github_repo="", weekly_risk_budget_usdt=50.0,
    )
    kwargs.update(overrides)
    return Settings(**kwargs)


def _owner_message(text, chat_id="555"):
    return {"chat": {"id": chat_id}, "text": text, "from": {"username": "ruslan"}, "message_id": 1}


# ---------------------------------------------------------------------
# 1. Reply-keyboard buttons route to the SAME handler as their slash
#    command -- report / ideas / newcode / scan.
# ---------------------------------------------------------------------

def test_report_button_calls_same_handler_as_slash_command():
    import main
    telegram = MagicMock()
    access = MagicMock()
    access.is_owner.return_value = True
    scan = MagicMock()
    settings = _settings()
    state = MagicMock()

    with patch("main._handle_report_command") as mock_handler:
        main._handle_access_message(telegram, access, scan, settings, state, _owner_message("/report"))
        call_via_slash = mock_handler.call_args

    mock_handler.reset_mock()
    with patch("main._handle_report_command") as mock_handler:
        main._handle_access_message(telegram, access, scan, settings, state, _owner_message(main.BTN_REPORT))
        call_via_button = mock_handler.call_args

    assert call_via_slash == call_via_button == ((telegram, "555", settings),)
    print("OK: the '📊 Отчёт' button calls _handle_report_command with the exact same "
          "arguments as typing /report.")


def test_ideas_button_calls_same_handler_as_slash_command():
    import main
    telegram = MagicMock()
    access = MagicMock()
    access.is_owner.return_value = True
    scan = MagicMock()
    settings = _settings()
    state = MagicMock()

    with patch("main._handle_ideas_command") as mock_handler:
        main._handle_access_message(telegram, access, scan, settings, state, _owner_message("/ideas"))
        call_via_slash = mock_handler.call_args

    mock_handler.reset_mock()
    with patch("main._handle_ideas_command") as mock_handler:
        main._handle_access_message(telegram, access, scan, settings, state, _owner_message(main.BTN_IDEAS))
        call_via_button = mock_handler.call_args

    assert call_via_slash == call_via_button == ((telegram, "555", settings, scan, state),)
    print("OK: the '💡 Идеи' button calls _handle_ideas_command with the exact same "
          "arguments as typing /ideas.")


def test_newcode_button_produces_identical_reply_to_slash_command():
    import main
    scan = MagicMock()
    settings = _settings()
    state = MagicMock()

    def _run(text):
        telegram = MagicMock()
        access = MagicMock()
        access.is_owner.return_value = True
        access.create_code.return_value = "ABCDEF"
        main._handle_access_message(telegram, access, scan, settings, state, _owner_message(text))
        access.create_code.assert_called_once()
        return telegram.send_message.call_args

    call_via_slash = _run("/newcode")
    call_via_button = _run(main.BTN_NEWCODE)
    assert call_via_slash == call_via_button
    print("OK: the '🔑 Новый код' button produces the exact same access.create_code() call "
          "and the exact same confirmation text as typing /newcode.")


def test_scan_button_produces_identical_reply_to_slash_command():
    import main
    settings = _settings()
    state = MagicMock()

    def _run(text):
        telegram = MagicMock()
        access = MagicMock()
        access.is_owner.return_value = True
        scan = MagicMock()
        scan.mode = "top25"
        main._handle_access_message(telegram, access, scan, settings, state, _owner_message(text))
        return telegram.send_message.call_args

    call_via_slash = _run("/scan")
    call_via_button = _run(main.BTN_SCAN)
    assert call_via_slash == call_via_button
    assert call_via_slash.kwargs["reply_markup"] == main._scan_menu_keyboard("top25")
    print("OK: the '⚙️ Сканирование' button shows the exact same inline scan-mode keyboard "
          "as typing /scan.")


def test_autopilot_button_calls_same_handler_with_no_arg_status_text():
    """Tapping the persistent-keyboard '🛡 Автопилот' button must land on
    _handle_autopilot_command's existing no-argument status branch (which,
    as of this round, also carries the on/off inline keyboard) -- NOT a
    separate implementation."""
    import main
    telegram = MagicMock()
    access = MagicMock()
    access.is_owner.return_value = True
    scan = MagicMock()
    settings = _settings()
    state = MagicMock()

    with patch("main._handle_autopilot_command") as mock_handler:
        main._handle_access_message(telegram, access, scan, settings, state, _owner_message(main.BTN_AUTOPILOT))
    mock_handler.assert_called_once_with(telegram, "555", "/autopilot", settings)
    print("OK: the '🛡 Автопилот' button calls _handle_autopilot_command with a synthetic "
          "'/autopilot' (no argument) -- the same status/inline-keyboard branch a bare "
          "/autopilot command hits.")


def test_instanttrade_button_calls_same_handler_with_no_arg_status_text():
    import main
    telegram = MagicMock()
    access = MagicMock()
    access.is_owner.return_value = True
    scan = MagicMock()
    settings = _settings()
    state = MagicMock()

    with patch("main._handle_instanttrade_command") as mock_handler:
        main._handle_access_message(telegram, access, scan, settings, state, _owner_message(main.BTN_INSTANTTRADE))
    mock_handler.assert_called_once_with(telegram, "555", "/instanttrade", settings)
    print("OK: the '⚡ Мгновенная торговля' button calls _handle_instanttrade_command with a "
          "synthetic '/instanttrade' (no argument), same as the '🛡 Автопилот' button above.")


def test_menu_and_owner_start_send_the_persistent_keyboard():
    import main
    for text in ("/menu", "меню", "/start"):
        telegram = MagicMock()
        access = MagicMock()
        access.is_owner.return_value = True
        scan = MagicMock()
        settings = _settings()
        state = MagicMock()
        main._handle_access_message(telegram, access, scan, settings, state, _owner_message(text))
        telegram.send_message.assert_called_once()
        assert telegram.send_message.call_args.kwargs["reply_markup"] == main._main_menu_keyboard()
    print("OK: /menu, 'меню', and the owner's own /start all (re)send the persistent reply "
          "keyboard -- so it can always be brought back if dismissed.")


def test_guest_start_is_unaffected_by_the_owner_menu_branch():
    """A non-owner chat's /start must still get the original invite-code
    prompt, with NO reply keyboard attached -- the button menu is
    owner-only."""
    import main
    telegram = MagicMock()
    access = MagicMock()
    access.is_owner.return_value = False
    access.is_authorized.return_value = False
    scan = MagicMock()
    settings = _settings()
    state = MagicMock()
    main._handle_access_message(telegram, access, scan, settings, state, _owner_message("/start", chat_id="999"))
    telegram.send_message.assert_called_once()
    call = telegram.send_message.call_args
    assert "код-приглашение" in call.args[0]
    assert "reply_markup" not in call.kwargs
    print("OK: a guest's /start is unaffected -- still the invite-code prompt, no reply keyboard.")


def test_other_commands_button_sends_a_reference_message_and_changes_nothing():
    import main
    telegram = MagicMock()
    access = MagicMock()
    access.is_owner.return_value = True
    scan = MagicMock()
    settings = _settings()
    state = MagicMock()
    main._handle_access_message(telegram, access, scan, settings, state, _owner_message(main.BTN_OTHER))
    telegram.send_message.assert_called_once()
    text = telegram.send_message.call_args.args[0]
    for cmd in ("/ai ", "/aiidea", "/trade ", "/tradekey", "/setkey", "/setaikey"):
        assert cmd in text, f"expected {cmd!r} to be mentioned in the 'other commands' reference message"
    print("OK: 'ℹ️ Другие команды' sends a reference message listing /ai, /aiidea, /trade, "
          "/tradekey, /setkey, /setaikey -- purely informational, no state change.")


# ---------------------------------------------------------------------
# 2 & 3. Inline-keyboard callbacks call the exact same underlying command
#    handler / ScanSettings.set_mode() as their text-command equivalent.
# ---------------------------------------------------------------------

def _cq(data, chat_id="555", cq_id="cbid1"):
    return {"id": cq_id, "data": data, "message": {"chat": {"id": chat_id}}}


def test_autopilot_callback_on_calls_exact_same_command_handler():
    import main
    telegram = MagicMock()
    access = MagicMock()
    access.is_owner.return_value = True
    settings = _settings()

    with patch("main._handle_autopilot_command") as mock_handler:
        main._handle_autopilot_callback(telegram, access, settings, _cq("autopilot:on"))
    mock_handler.assert_called_once_with(telegram, "555", "/autopilot on", settings)
    telegram.answer_callback_query.assert_called_once_with("cbid1", text=None)
    print("OK: the autopilot:on inline callback calls _handle_autopilot_command with the "
          "exact same '/autopilot on' text the typed command uses -- no parallel toggle logic.")


def test_autopilot_callback_off_calls_exact_same_command_handler():
    import main
    telegram = MagicMock()
    access = MagicMock()
    access.is_owner.return_value = True
    settings = _settings()

    with patch("main._handle_autopilot_command") as mock_handler:
        main._handle_autopilot_callback(telegram, access, settings, _cq("autopilot:off"))
    mock_handler.assert_called_once_with(telegram, "555", "/autopilot off", settings)
    print("OK: the autopilot:off inline callback calls _handle_autopilot_command with "
          "'/autopilot off', same as typing it.")


def test_instanttrade_callback_on_and_off_call_exact_same_command_handler():
    import main
    settings = _settings()
    for arg in ("on", "off"):
        telegram = MagicMock()
        access = MagicMock()
        access.is_owner.return_value = True
        with patch("main._handle_instanttrade_command") as mock_handler:
            main._handle_instanttrade_callback(telegram, access, settings, _cq(f"instanttrade:{arg}"))
        mock_handler.assert_called_once_with(telegram, "555", f"/instanttrade {arg}", settings)
    print("OK: the instanttrade:on/off inline callbacks call _handle_instanttrade_command "
          "with the exact same '/instanttrade on'/'off' text the typed command uses.")


def test_autopilot_toggle_actually_flips_the_same_underlying_setting():
    """End-to-end (not just 'the right function was called'): drive the
    real _handle_autopilot_command through the callback path and confirm
    AutopilotSettings.set_enabled() -- the actual real-money switch -- is
    called with the value the tapped button meant, exactly as it would be
    for a typed /autopilot on|off."""
    import main
    telegram = MagicMock()
    access = MagicMock()
    access.is_owner.return_value = True
    settings = _settings()

    with patch("main.AutopilotSettings") as MockAutopilotSettings:
        instance = MockAutopilotSettings.return_value
        instance.is_enabled.return_value = False
        main._handle_autopilot_callback(telegram, access, settings, _cq("autopilot:on"))
        instance.set_enabled.assert_called_once_with(True)

    with patch("main.AutopilotSettings") as MockAutopilotSettings:
        instance = MockAutopilotSettings.return_value
        instance.is_enabled.return_value = True
        main._handle_autopilot_callback(telegram, access, settings, _cq("autopilot:off"))
        instance.set_enabled.assert_called_once_with(False)
    print("OK: tapping the autopilot inline buttons actually flips AutopilotSettings.set_enabled() "
          "to True/False, via the same code path /autopilot on|off already used.")


def test_instanttrade_toggle_actually_flips_the_same_underlying_setting():
    import main
    telegram = MagicMock()
    access = MagicMock()
    access.is_owner.return_value = True
    settings = _settings()

    with patch("main.InstantTradeSettings") as MockSettings:
        instance = MockSettings.return_value
        instance.is_enabled.return_value = False
        main._handle_instanttrade_callback(telegram, access, settings, _cq("instanttrade:on"))
        instance.set_enabled.assert_called_once_with(True)
    print("OK: tapping the instant-trade inline button actually flips "
          "InstantTradeSettings.set_enabled(True), via the same code path /instanttrade on already used.")


def test_scan_callback_maps_to_the_right_scan_settings_call():
    import main
    telegram = MagicMock()
    access = MagicMock()
    access.is_owner.return_value = True
    scan = MagicMock()

    main._handle_scan_callback(telegram, access, scan, _cq("scan:top50"))
    scan.set_mode.assert_called_once_with("top50")
    telegram.answer_callback_query.assert_called_once()
    print("OK: the scan:top50 inline callback calls ScanSettings.set_mode('top50') -- the "
          "same call the /scan text-menu's button already made before this round.")


def test_non_owner_callback_taps_are_acknowledged_but_ignored():
    """Anyone else's tap on any of these inline keyboards must be
    acknowledged (clear their spinner) but never actually change state --
    same posture as every other owner-only action in this bot."""
    import main
    settings = _settings()

    telegram = MagicMock()
    access = MagicMock()
    access.is_owner.return_value = False
    with patch("main._handle_autopilot_command") as mock_handler:
        main._handle_autopilot_callback(telegram, access, settings, _cq("autopilot:on", chat_id="999"))
    mock_handler.assert_not_called()
    telegram.answer_callback_query.assert_called_once()

    telegram = MagicMock()
    access = MagicMock()
    access.is_owner.return_value = False
    scan = MagicMock()
    main._handle_scan_callback(telegram, access, scan, _cq("scan:top50", chat_id="999"))
    scan.set_mode.assert_not_called()
    telegram.answer_callback_query.assert_called_once()
    print("OK: a non-owner's button tap on the autopilot or scan inline keyboards is "
          "acknowledged but does not toggle/change anything.")


# ---------------------------------------------------------------------
# 4, 5, 6: answer_callback_query is always called, last_update_id
#    advances for callback_query updates too, and malformed data is
#    handled gracefully.
# ---------------------------------------------------------------------

def test_every_kind_of_callback_query_gets_acknowledged():
    import main
    telegram = MagicMock()
    telegram.get_updates.return_value = [
        {"update_id": 10, "callback_query": {"id": "a", "data": "scan:top25", "message": {"chat": {"id": "555"}}}},
        {"update_id": 11, "callback_query": {"id": "b", "data": "autopilot:on", "message": {"chat": {"id": "555"}}}},
        {"update_id": 12, "callback_query": {"id": "c", "data": "instanttrade:off", "message": {"chat": {"id": "555"}}}},
        {"update_id": 13, "callback_query": {"id": "d", "data": "something:unexpected", "message": {"chat": {"id": "555"}}}},
        {"update_id": 14, "callback_query": {"id": "e", "data": "", "message": {"chat": {"id": "555"}}}},
    ]
    access = MagicMock()
    access.last_update_id = None
    access.is_owner.return_value = True
    scan = MagicMock()
    scan.mode = "watchlist"
    settings = _settings()
    state = MagicMock()

    with patch("main._handle_autopilot_command"), patch("main._handle_instanttrade_command"):
        main._handle_access_updates(telegram, access, scan, settings, state)

    acked_ids = [c.args[0] for c in telegram.answer_callback_query.call_args_list]
    assert acked_ids == ["a", "b", "c", "d", "e"], acked_ids
    print("OK: every callback_query update (scan/autopilot/instanttrade/unrecognized/empty data) "
          "gets answer_callback_query called on it -- no tap can leave an infinite spinner.")


def test_update_id_advances_for_callback_query_type_updates_too():
    import main
    telegram = MagicMock()
    telegram.get_updates.return_value = [
        {"update_id": 100, "callback_query": {"id": "cb1", "data": "scan:top25", "message": {"chat": {"id": "555"}}}},
        {"update_id": 101, "message": {"chat": {"id": "555"}, "text": "/report", "from": {}}},
    ]
    access = MagicMock()
    access.last_update_id = None
    access.is_owner.return_value = True
    scan = MagicMock()
    scan.mode = "watchlist"
    settings = _settings()
    state = MagicMock()

    with patch("main._handle_report_command"):
        main._handle_access_updates(telegram, access, scan, settings, state)

    recorded_ids = [c.args[0] for c in access.set_last_update_id.call_args_list]
    assert recorded_ids == [100, 101], recorded_ids
    print("OK: last_update_id advances for a callback_query-type update (100) exactly like a "
          "message-type one (101) -- neither kind risks being redelivered forever.")


def test_malformed_callback_data_is_handled_gracefully_not_silently_wrong():
    """An unrecognized data string at the dispatch level is acked and
    ignored (see test above); an in-range prefix with a bad suffix (e.g.
    'autopilot:frobnicate') must ALSO be rejected cleanly by the specific
    handler -- never silently treated as 'on' or 'off'."""
    import main
    telegram = MagicMock()
    access = MagicMock()
    access.is_owner.return_value = True
    settings = _settings()

    with patch("main._handle_autopilot_command") as mock_handler:
        main._handle_autopilot_callback(telegram, access, settings, _cq("autopilot:frobnicate"))
    mock_handler.assert_not_called()
    telegram.answer_callback_query.assert_called_once_with("cbid1", text="Неизвестное действие")

    telegram = MagicMock()
    with patch("main._handle_instanttrade_command") as mock_handler:
        main._handle_instanttrade_callback(telegram, access, settings, _cq("instanttrade:frobnicate"))
    mock_handler.assert_not_called()
    telegram.answer_callback_query.assert_called_once_with("cbid1", text="Неизвестное действие")
    print("OK: a malformed suffix on a recognized callback prefix (e.g. 'autopilot:frobnicate') "
          "never calls the toggle handler and is acknowledged with an explicit error, not "
          "silently treated as on or off.")


def test_answer_callback_query_failure_never_crashes_the_dispatcher():
    """If Telegram itself rejects the acknowledgment (e.g. a stale/expired
    callback, the exact real bug already fixed for the scan menu -- see
    main.py's _handle_scan_callback docstring), the callback handler must
    still run the underlying action rather than raising."""
    import main
    from app.telegram_client import TelegramError
    telegram = MagicMock()
    telegram.answer_callback_query.side_effect = TelegramError("too old")
    access = MagicMock()
    access.is_owner.return_value = True
    settings = _settings()

    with patch("main._handle_autopilot_command") as mock_handler:
        main._handle_autopilot_callback(telegram, access, settings, _cq("autopilot:on"))
    mock_handler.assert_called_once_with(telegram, "555", "/autopilot on", settings)
    print("OK: a failed/expired answer_callback_query call is swallowed and logged, and never "
          "prevents the actual autopilot toggle from running.")


if __name__ == "__main__":
    test_report_button_calls_same_handler_as_slash_command()
    test_ideas_button_calls_same_handler_as_slash_command()
    test_newcode_button_produces_identical_reply_to_slash_command()
    test_scan_button_produces_identical_reply_to_slash_command()
    test_autopilot_button_calls_same_handler_with_no_arg_status_text()
    test_instanttrade_button_calls_same_handler_with_no_arg_status_text()
    test_menu_and_owner_start_send_the_persistent_keyboard()
    test_guest_start_is_unaffected_by_the_owner_menu_branch()
    test_other_commands_button_sends_a_reference_message_and_changes_nothing()
    test_autopilot_callback_on_calls_exact_same_command_handler()
    test_autopilot_callback_off_calls_exact_same_command_handler()
    test_instanttrade_callback_on_and_off_call_exact_same_command_handler()
    test_autopilot_toggle_actually_flips_the_same_underlying_setting()
    test_instanttrade_toggle_actually_flips_the_same_underlying_setting()
    test_scan_callback_maps_to_the_right_scan_settings_call()
    test_non_owner_callback_taps_are_acknowledged_but_ignored()
    test_every_kind_of_callback_query_gets_acknowledged()
    test_update_id_advances_for_callback_query_type_updates_too()
    test_malformed_callback_data_is_handled_gracefully_not_silently_wrong()
    test_answer_callback_query_failure_never_crashes_the_dispatcher()
    print("\nAll round-17 menu/button checks passed.")
