"""
2026-08-25, round 16 follow-up #2: regression test for a real live bug --
the user's `/ai` kept failing ("ИИ сейчас недоступен") even after the
model-name fix (see the previous follow-up), because the key they'd
actually added via `/setaikey` came from a third-party Anthropic-API-
compatible reseller/proxy (confirmed from their own screenshot: the exact
same key prefix appeared on that service's own dashboard, which told them
to set their OWN "ANTHROPIC_BASE_URL" for Claude Code, not
api.anthropic.com). app/ai_assistant.py's _call_ai() always POSTed to the
real Anthropic API regardless of where the key actually came from -- a
key that's only valid at a different host will always fail there, no
matter how correct the model name or the request shape is.

Fix: `Settings.ai_base_url` (ANTHROPIC_BASE_URL, defaults to the real
`https://api.anthropic.com`) now controls which host `_call_ai()` POSTs
`/v1/messages` to. This test locks in: the request goes to the configured
base URL (not a hardcoded one), the default preserves the original real-
Anthropic behavior, and `Settings.load()` strips a trailing slash from a
user-supplied `ANTHROPIC_BASE_URL` so `.../v1/messages` never ends up
double-slashed.

Run: python tests/test_ai_base_url.py
"""
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.ai_assistant import _call_ai
from app.config import Settings


def _settings(**overrides) -> Settings:
    base = dict(
        telegram_token="t", telegram_chat_id="c", timeframe="15m", swing_left=3, swing_right=3,
        poll_seconds=60, watchlist=["BTCUSDT"], use_htf_filter=True, show_rsi=False,
        github_token="", github_repo="ruslan875/smc-radar", weekly_risk_budget_usdt=50.0,
        anthropic_api_key="sk-test-key",
    )
    base.update(overrides)
    return Settings(**base)


def _fake_ok_response():
    return MagicMock(status_code=200, json=lambda: {"content": [{"type": "text", "text": "hi"}]})


def test_call_ai_uses_default_anthropic_url_when_unset():
    settings = _settings()  # ai_base_url uses its dataclass default
    assert settings.ai_base_url == "https://api.anthropic.com"
    with patch("app.ai_assistant.requests.post", return_value=_fake_ok_response()) as mock_post:
        result = _call_ai("system", "user", settings)
    assert result == "hi"
    called_url = mock_post.call_args[0][0]
    assert called_url == "https://api.anthropic.com/v1/messages"
    print("OK: with no override, _call_ai() posts to the real Anthropic API, unchanged from before "
          "this fix.")


def test_call_ai_uses_custom_base_url_when_configured():
    """The actual bug this round found: a key from a reseller/proxy is
    only valid at THEIR host -- this confirms _call_ai() now respects
    that instead of always hitting api.anthropic.com."""
    settings = _settings(ai_base_url="https://hadsai.com")
    with patch("app.ai_assistant.requests.post", return_value=_fake_ok_response()) as mock_post:
        result = _call_ai("system", "user", settings)
    assert result == "hi"
    called_url = mock_post.call_args[0][0]
    assert called_url == "https://hadsai.com/v1/messages"
    print("OK: with ANTHROPIC_BASE_URL overridden, _call_ai() posts /v1/messages to that host instead "
          "of the real Anthropic API -- this is what a reseller-issued key actually needs.")


def test_settings_load_strips_trailing_slash_from_base_url(monkeypatch):
    """A user might paste 'https://hadsai.com/' (trailing slash, as shown
    in some setup instructions) -- must not produce a double slash before
    '/v1/messages'."""
    monkeypatch.setenv("ANTHROPIC_BASE_URL", "https://hadsai.com/")
    monkeypatch.setenv("TELEGRAM_BOT_TOKEN", "t")
    monkeypatch.setenv("TELEGRAM_CHAT_ID", "c")
    settings = Settings.load()
    assert settings.ai_base_url == "https://hadsai.com"
    print("OK: Settings.load() strips a trailing slash from ANTHROPIC_BASE_URL so '/v1/messages' "
          "never ends up double-slashed.")


if __name__ == "__main__":
    test_call_ai_uses_default_anthropic_url_when_unset()
    test_call_ai_uses_custom_base_url_when_configured()

    class _Monkeypatch:
        def __init__(self):
            self._saved = {}
        def setenv(self, key, value):
            import os
            self._saved.setdefault(key, os.environ.get(key))
            os.environ[key] = value
        def undo(self):
            import os
            for k, v in self._saved.items():
                if v is None:
                    os.environ.pop(k, None)
                else:
                    os.environ[k] = v
    mp = _Monkeypatch()
    try:
        test_settings_load_strips_trailing_slash_from_base_url(mp)
    finally:
        mp.undo()
    print("\nAll ANTHROPIC_BASE_URL checks passed.")
