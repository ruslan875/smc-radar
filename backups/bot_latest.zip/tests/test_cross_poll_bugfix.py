"""
2026-08-24: regression test for the cross-poll armed_index bug.

The live bot (main.py's run_once -> process_symbol) fetches a BRAND NEW
DataFrame every single poll (see _prefetch_klines / df_cache = {} each
run_once call) -- each fetch is its own 0-based positional index, not a
continuation of the previous poll's DataFrame. The original
check_zone_reaction/zone_expired compared zone.armed_index (a position in
the DataFrame that existed at arm() time) against a position in whatever
DataFrame happened to be passed in later -- meaningless once that's a
totally independent fetch, since both are always ~248 (limit=250, "second
to last row"), regardless of how much real time actually passed.

This test builds two INDEPENDENT DataFrames (simulating two separate
polls, exactly like main.py does) instead of one continuously-growing one
(which is what tests/test_two_stage.py and backtest.py both use, and
neither of those exercises this bug -- that's exactly why it shipped
unnoticed). It confirms:
  1. check_zone_reaction now correctly fires on a later, independently
     re-fetched DataFrame's genuine reaction candle (would NOT have fired
     under the old positional check -- reproduced manually below for
     comparison).
  2. zone_expired now correctly expires a zone once real time has passed
     its expires_after_bars window, even across independent re-fetches
     (would NEVER have expired under the old positional check).

Run: python tests/test_cross_poll_bugfix.py
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd

from app.smc import PendingZone, check_zone_reaction, zone_expired


def _flat_bars(start, n, price=100.0, step_minutes=15):
    """n boring, flat-ish bars starting at `start`, so ATR stays small and
    doesn't drown out the deliberately oversized reaction candle below."""
    times = pd.date_range(start, periods=n, freq=f"{step_minutes}min", tz="UTC")
    rows = []
    for t in times:
        rows.append({"open_time": t, "open": price, "high": price + 0.05,
                      "low": price - 0.05, "close": price, "volume": 1000.0})
    return pd.DataFrame(rows)


def old_buggy_check_idx_guard(check_idx: int, zone: PendingZone) -> bool:
    """Reproduces the ORIGINAL (buggy) guard from check_zone_reaction,
    before the 2026-08-24 fix -- for side-by-side comparison only."""
    return check_idx <= zone.armed_index


def old_buggy_zone_expired(df: pd.DataFrame, zone: PendingZone) -> bool:
    """Reproduces the ORIGINAL (buggy) zone_expired, before the fix."""
    check_idx = len(df) - 2
    return (check_idx - zone.armed_index) > zone.expires_after_bars


def test_reaction_fires_on_independently_refetched_df():
    armed_time = pd.Timestamp("2026-08-17T12:00:00", tz="UTC")

    # The zone as it would have been persisted to state.json after
    # Stage 1 fired on SOME earlier poll's own DataFrame (armed_index=248
    # is realistic -- structure breaks are always detected near the end
    # of whatever window was fetched that poll).
    zone = PendingZone(
        symbol="TESTUSDT", timeframe="15m", direction="long",
        top=100.10, bottom=99.90, zone_kind="OB+FVG", structure_event="CHoCH",
        armed_index=248, armed_time=armed_time, swing_broken=101.0,
        expires_after_bars=60,
    )

    # Poll #N+1, three hours later (12 bars @ 15m) -- a COMPLETELY
    # INDEPENDENT 250-bar fetch, exactly like main.py's df_cache each
    # run_once() call. Its own index starts at 0 again.
    poll_start = armed_time + pd.Timedelta(minutes=15)
    df_poll = _flat_bars(poll_start, 250, price=100.30)  # sits above the zone, unrelated chop
    # Overwrite the second-to-last bar (check_idx = len-2 = 248) with a
    # real, obvious bullish reaction: taps the zone, closes back above
    # the midpoint with a big directional body.
    check_idx = len(df_poll) - 2
    df_poll.loc[check_idx, ["open", "high", "low", "close"]] = [99.95, 100.15, 99.85, 100.08]
    reaction_time = df_poll.loc[check_idx, "open_time"]
    assert reaction_time > armed_time, "sanity: the reaction bar really is later in real time"

    # --- old (buggy) behavior: positional comparison across two
    # independent DataFrames is nonsense -- armed_index (248, from the
    # arming poll) vs check_idx (248, from THIS poll) -- always blocks.
    assert old_buggy_check_idx_guard(check_idx, zone) is True, (
        "demonstrates the bug: the old guard blocks a perfectly valid, "
        "much-later reaction just because both DataFrames happen to be "
        "the same length"
    )

    # --- new (fixed) behavior: keyed off real elapsed time, correctly
    # recognizes this bar as later than the zone's arming time and fires.
    sig = check_zone_reaction(df_poll, zone)
    assert sig is not None, "fixed check_zone_reaction should fire on a genuine later reaction"
    assert sig.direction == "long"
    assert sig.entry == 100.08
    print("OK: check_zone_reaction fires correctly across independent re-fetched polls "
          f"(entry={sig.entry}, stop={sig.stop_loss:.3f}); "
          "old positional guard would have blocked it (confirmed above).")


def test_zone_expires_across_independent_refetches():
    armed_time = pd.Timestamp("2026-08-17T12:00:00", tz="UTC")
    zone = PendingZone(
        symbol="TESTUSDT", timeframe="15m", direction="long",
        top=100.10, bottom=99.90, zone_kind="OB", structure_event="CHoCH",
        armed_index=248, armed_time=armed_time, swing_broken=101.0,
        expires_after_bars=60,  # 60 * 15min = 15h
    )

    # A poll happening a week later (matches the real state.json evidence:
    # zones armed 2026-08-17 were still sitting un-expired on 2026-08-24).
    much_later_start = armed_time + pd.Timedelta(days=7)
    df_much_later = _flat_bars(much_later_start, 250, price=105.0)

    # --- old (buggy) behavior: never expires, no matter how much real
    # time has passed, because both DataFrames are ~250 bars long so the
    # positional difference stays ~0.
    assert old_buggy_zone_expired(df_much_later, zone) is False, (
        "demonstrates the bug: a zone armed a week ago never expires "
        "under the old positional check"
    )

    # --- new (fixed) behavior: correctly recognizes 7 days >> 15h expiry.
    assert zone_expired(df_much_later, zone) is True, (
        "fixed zone_expired should expire a week-old zone (limit 15h)"
    )
    print("OK: zone_expired correctly expires a week-old zone across independent "
          "re-fetched polls; old positional check would have kept it alive forever "
          "(confirmed above) -- matches the real stuck zones found in the user's "
          "live state.json.")

    # --- sanity: a genuinely recent zone (well within its window) must
    # NOT be expired. df_recent's *last* bar (check_idx = len-2 = 248) is
    # what zone_expired looks at, so anchor the fetch so THAT bar lands
    # only 2 bars after armed_time, not the fetch's first bar.
    recent_start = armed_time - pd.Timedelta(minutes=15 * 246)
    df_recent = _flat_bars(recent_start, 250, price=100.0)
    check_bar_time = df_recent.iloc[len(df_recent) - 2]["open_time"]
    assert check_bar_time == armed_time + pd.Timedelta(minutes=30), "sanity: check bar is 2 bars after armed_time"
    assert zone_expired(df_recent, zone) is False, "a 2-bar-old zone (limit 60 bars) must not expire yet"
    print("OK: a genuinely recent zone is correctly NOT expired.")


if __name__ == "__main__":
    test_reaction_fires_on_independently_refetched_df()
    test_zone_expires_across_independent_refetches()
    print("\nAll cross-poll bug-fix checks passed.")
