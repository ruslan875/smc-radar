"""
2026-08-25, round 16: regression tests for the entry-price / limit-order
feature the user asked for ("нужно добавить функцию по какой цене входить
в сделку" -- need a way to say what price to enter a trade at).

Covers two layers:
  1. app/exchanges/bybit.py's place_order() -- entry_price=None must stay
     a byte-identical Market order to every round before this one;
     entry_price=<number> must switch to a GTC Limit order at that price
     and nothing else about the request should change.
  2. app/trade_executor.py's execute_trade() -- when entry_price is given,
     it (not the live market price) must be the reference price used for
     the stop-loss-direction guard and the risk-budget calculation, since
     that's the economically correct number for a resting limit order.
     When entry_price is None, behavior must be identical to before this
     round (live price used everywhere). Reuses the exact same
     _settings()/_fake_module()/_call() harness as test_trade_executor.py
     so these tests exercise execute_trade() the same way its own
     existing suite does.

Run: python tests/test_round16_entry_price.py
"""
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.config import Settings
from app.exchanges import bybit
from app.trade_executor import execute_trade


def _payload(ret_code=0, ret_msg="", order_id="OID-1"):
    return {"retCode": ret_code, "retMsg": ret_msg, "result": {"orderId": order_id, "orderLinkId": "LINK-1"}}


# ---------------------------------------------------------------------
# Layer 1: app/exchanges/bybit.py place_order()
# ---------------------------------------------------------------------

def test_place_order_no_entry_price_is_market_order_unchanged():
    with patch("app.exchanges.bybit._signed_post", return_value=_payload()) as mock_post:
        bybit.place_order("k", "s", "BTCUSDT", "buy", 1.0, 90.0)
    params = mock_post.call_args[0][3]
    assert params["orderType"] == "Market"
    assert "price" not in params
    assert "timeInForce" not in params
    print("OK: entry_price=None (the default) still sends a plain Market order, no price/timeInForce fields.")


def test_place_order_with_entry_price_is_limit_order():
    with patch("app.exchanges.bybit._signed_post", return_value=_payload()) as mock_post:
        bybit.place_order("k", "s", "BTCUSDT", "buy", 1.0, 90.0, entry_price=95.5)
    params = mock_post.call_args[0][3]
    assert params["orderType"] == "Limit"
    assert params["price"] == "95.5"
    assert params["timeInForce"] == "GTC"
    print("OK: a given entry_price switches to a GTC Limit order at that exact price.")


def test_place_order_entry_price_does_not_disturb_other_fields():
    with patch("app.exchanges.bybit._signed_post", return_value=_payload()) as mock_post:
        bybit.place_order("k", "s", "ETHUSDT", "sell", 2.0, 3500.0, take_profit=3000.0, entry_price=3200.0)
    params = mock_post.call_args[0][3]
    assert params["symbol"] == "ETHUSDT"
    assert params["side"] == "Sell"
    assert params["qty"] == "2.0"
    assert params["stopLoss"] == "3500.0"
    assert params["takeProfit"] == "3000.0"
    print("OK: symbol/side/qty/stopLoss/takeProfit are unaffected by adding entry_price.")


def test_place_order_hedge_retry_still_works_with_entry_price():
    """Round 15's positionIdx hedge-mode retry must keep working for
    Limit orders too -- the retry rebuilds params from the SAME dict,
    which now includes orderType/price/timeInForce when entry_price is
    given, so this checks nothing about that retry path broke."""
    responses = [
        _payload(10001, "position idx not match position mode"),
        _payload(0, order_id="OID-9"),
    ]
    with patch("app.exchanges.bybit._signed_post", side_effect=responses) as mock_post:
        result = bybit.place_order("k", "s", "BTCUSDT", "buy", 1.0, 90.0, entry_price=95.0)
    assert result["order_id"] == "OID-9"
    retry_params = mock_post.call_args_list[1][0][3]
    assert retry_params["positionIdx"] == 1
    assert retry_params["orderType"] == "Limit"
    assert retry_params["price"] == "95.0"
    print("OK: the round-15 hedge-mode retry still carries orderType/price/timeInForce for a Limit order.")


# ---------------------------------------------------------------------
# Layer 2: app/trade_executor.py execute_trade() -- reference-price choice
# ---------------------------------------------------------------------
# Same harness style as tests/test_trade_executor.py, duplicated here
# (rather than imported) so this file stays runnable standalone and
# doesn't create a cross-test-file coupling for a couple of helpers.

def _settings(**overrides) -> Settings:
    base = dict(
        telegram_token="tok", telegram_chat_id="1", timeframe="15m", swing_left=3, swing_right=3,
        poll_seconds=60, watchlist=["BTCUSDT"], use_htf_filter=True, show_rsi=False,
        github_token="", github_repo="ruslan875/smc-radar", weekly_risk_budget_usdt=50.0,
        max_trade_leverage=5, signal_gate_max_age_minutes=60.0,
    )
    base.update(overrides)
    return Settings(**base)


def _fake_module(place_order_return=None):
    module = MagicMock()
    module.DISPLAY_NAME = "FakeExchange"
    module.set_leverage = MagicMock()
    module.place_order = MagicMock(return_value=place_order_return or {"order_id": "ORDER-1"})
    return module


def _call(module=None, get_last_price_return=100.0, build_health_return=None, **kwargs):
    module = module if module is not None else _fake_module()
    registry = {"fake": module}
    state = MagicMock()
    state.latest_active_signal = MagicMock(return_value=None)
    trade_keys_all = {"fake": {"api_key": "key", "api_secret": "secret", "passphrase": None}}

    args = dict(
        exch_key="fake", symbol="btcusdt", side="buy", qty=1.0, leverage=3,
        stop_loss=90.0, take_profit=None, gate_requested=False,
        settings=_settings(), state=state,
    )
    args.update(kwargs)

    with patch("app.trade_executor.EXCHANGE_REGISTRY", registry), \
         patch("app.trade_executor.TradeKeysStore") as MockStore, \
         patch("app.trade_executor.get_last_price") as mock_price, \
         patch("app.trade_executor.publish_health") as mock_health:
        MockStore.return_value.get_all.return_value = trade_keys_all
        mock_price.return_value = get_last_price_return
        mock_health.build_health.return_value = build_health_return or {"sources": {"fake": {"risk_used_usdt_week": 0.0}}}
        result = execute_trade(**args)
    return result, module, state


def test_execute_trade_uses_live_price_when_no_entry_price():
    """Unchanged-behavior guarantee: omitting entry_price must use the
    live market price for both the stop-loss guard and the risk-budget
    math, exactly as every round before this one, and must pass
    entry_price=None straight through to place_order()."""
    result, module, state = _call(stop_loss=90.0, get_last_price_return=100.0)
    assert result["ok"] is True
    assert result["entry_price"] is None
    assert module.place_order.call_args.kwargs["entry_price"] is None
    print("OK: with no entry_price, execute_trade() uses the live price for guards and passes "
          "entry_price=None through to place_order() (Market order, unchanged behavior).")


def test_execute_trade_uses_entry_price_as_reference_when_given():
    """The core round-16 guarantee: a bad stop-loss relative to the
    ENTRY price must be caught even when the live price would have
    looked fine -- because a resting limit order's real risk is relative
    to where it will actually fill, not today's live price. Live price
    is 100 (a buy stop-loss of 95 would pass a live-price check), but
    the limit entry price is 90 -- a stop-loss of 95 is ABOVE a buy's own
    entry, which check_stop_loss() must reject when given 90 as the
    reference."""
    result, module, state = _call(stop_loss=95.0, get_last_price_return=100.0, entry_price=90.0)
    assert result["ok"] is False, f"expected the entry-price-relative stop-loss check to reject this, got: {result}"
    module.place_order.assert_not_called()
    print("OK: a stop-loss that's fine relative to the LIVE price but invalid relative to the LIMIT "
          "entry price is correctly rejected before ever reaching the exchange -- entry_price is used "
          "as the guard reference, not the live price.")


def test_execute_trade_passes_entry_price_through_and_returns_it():
    result, module, state = _call(stop_loss=85.0, get_last_price_return=100.0, entry_price=90.0)
    assert result["ok"] is True
    assert result["entry_price"] == 90.0
    assert module.place_order.call_args.kwargs["entry_price"] == 90.0
    print("OK: a valid limit order passes entry_price through to place_order() and reports it back "
          "in the result dict for the caller to format (Telegram reply / Mini App result box).")


def test_execute_trade_risk_budget_uses_entry_price_distance():
    """new_risk_usdt = qty * abs(reference_price - stop_loss) must use
    entry_price, not the live price, when given -- verified indirectly by
    forcing the risk budget so tight that only the entry-price-based
    distance (10) fits, while the live-price-based distance (5, since
    live=100 vs stop=95) would NOT have been correctly rejected/accepted
    the same way if the code still used live price."""
    # entry_price=90, stop_loss=80 -> risk distance = 10 -> risk = qty(1) * 10 = 10 USDT
    # live price = 100 -> if wrongly used, distance would be 20 -> risk = 20 USDT
    result, module, state = _call(
        stop_loss=80.0, get_last_price_return=100.0, entry_price=90.0,
        build_health_return={"sources": {"fake": {"risk_used_usdt_week": 40.0}}},
    )
    # weekly_risk_budget_usdt=50.0 (from _settings), already_used=40.0 -> only 10 USDT of headroom left.
    # Correct (entry-price-based) risk of 10 fits exactly; the wrong (live-price-based) risk of 20 would not.
    assert result["ok"] is True, f"expected the entry-price-based 10 USDT risk to fit the 10 USDT headroom, got: {result}"
    print("OK: the risk-budget calculation uses |entry_price - stop_loss|, not |live_price - stop_loss|, "
          "confirmed by a budget that only the correct distance fits.")


if __name__ == "__main__":
    test_place_order_no_entry_price_is_market_order_unchanged()
    test_place_order_with_entry_price_is_limit_order()
    test_place_order_entry_price_does_not_disturb_other_fields()
    test_place_order_hedge_retry_still_works_with_entry_price()
    test_execute_trade_uses_live_price_when_no_entry_price()
    test_execute_trade_uses_entry_price_as_reference_when_given()
    test_execute_trade_passes_entry_price_through_and_returns_it()
    test_execute_trade_risk_budget_uses_entry_price_distance()
    print("\nAll round-16 entry-price/limit-order checks passed.")
