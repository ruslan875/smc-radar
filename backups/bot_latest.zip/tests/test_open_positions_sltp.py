"""
2026-08-24, round 13: regression test for stop_loss/take_profit on open
positions -- written while wiring up their DISPLAY in the Здоровье tab
and /report (they were already being fetched since round 9 for the
breakeven-autopilot's own internal use, just never shown to the owner).

Note on how this test came to exist: while writing it, an earlier local
sandbox copy of app/exchanges/bybit.py turned out to be stale (missing
round 9's amend_stop_loss() and the stop_loss/take_profit extraction in
fetch_open_positions() entirely) -- a recurring failure mode already
documented in this project's own "Known limitations" section. Re-staging
the real file from the user's machine confirmed the live code was already
correct; nothing needed fixing there. This test exists purely to lock in
that correctness now that the UI actually depends on it being right.

Run: python tests/test_open_positions_sltp.py
"""
import sys
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd

from app.exchanges import bybit


def _fake_response(list_payload):
    class _Resp:
        def raise_for_status(self):
            pass

        def json(self):
            return {"retCode": 0, "retMsg": "OK", "result": {"list": list_payload}}
    return _Resp()


def test_fetch_open_positions_extracts_stop_loss_take_profit():
    rows = [
        {
            "symbol": "BTCUSDT", "side": "Buy", "size": "0.001",
            "avgPrice": "60000", "markPrice": "60500", "unrealisedPnl": "0.5",
            "positionValue": "60.5", "leverage": "5", "createdTime": "1700000000000",
            "stopLoss": "59000", "takeProfit": "64000",
        },
        {
            # a position with no stop/take set -- Bybit represents this as
            # an empty string, not a missing field or null.
            "symbol": "ETHUSDT", "side": "Sell", "size": "0.05",
            "avgPrice": "3000", "markPrice": "2950", "unrealisedPnl": "2.5",
            "positionValue": "147.5", "leverage": "3", "createdTime": "1700000001000",
            "stopLoss": "", "takeProfit": "",
        },
    ]

    with patch("app.exchanges.bybit.requests.get", return_value=_fake_response(rows)):
        df = bybit.fetch_open_positions("fake_key", "fake_secret")

    assert list(df["symbol"]) == ["BTCUSDT", "ETHUSDT"]
    assert "stop_loss" in df.columns and "take_profit" in df.columns

    btc = df.iloc[0]
    assert btc["stop_loss"] == 59000.0
    assert btc["take_profit"] == 64000.0

    # pandas coerces a mixed column's None entries to float('nan') once the
    # SAME column also holds a real number in another row (this is exactly
    # the failure mode app/autopilot.py's own _missing() helper exists to
    # handle -- see that module's docstring) -- check via pd.isna, not
    # `is None`, same as the production code (publish_health.py's _num())
    # already does downstream.
    eth = df.iloc[1]
    assert pd.isna(eth["stop_loss"])
    assert pd.isna(eth["take_profit"])

    print("OK: fetch_open_positions correctly extracts stop_loss/take_profit "
          "(real value -> float, Bybit's \"\" -> None/NaN).")


def test_missing_stop_loss_key_is_safely_skipped_by_autopilot():
    """Confirms app/autopilot.py's decide_breakeven_moves() correctly
    distinguishes a position with a real stop_loss from one where the key
    is genuinely absent (e.g. an exchange module that doesn't implement
    stop_loss/take_profit at all) -- the latter must be skipped, not
    treated as "no risk"/acted on."""
    from app.autopilot import decide_breakeven_moves

    no_stop_position = {
        "symbol": "BTCUSDT", "side": "long",
        "avg_entry_price": 60000.0, "mark_price": 61000.0,
        # no "stop_loss" key at all
    }
    moves = decide_breakeven_moves([no_stop_position], trigger_r=1.0)
    assert moves == [], "a position with no stop_loss data must be skipped, never acted on"

    with_stop_position = dict(no_stop_position, stop_loss=59000.0)
    moves = decide_breakeven_moves([with_stop_position], trigger_r=1.0)
    assert len(moves) == 1 and moves[0]["symbol"] == "BTCUSDT", (
        "a position with a real stop_loss and +1R reached should produce a breakeven move"
    )
    print("OK: decide_breakeven_moves correctly skips a position with no stop_loss data "
          "and correctly evaluates one that has it.")


if __name__ == "__main__":
    test_fetch_open_positions_extracts_stop_loss_take_profit()
    test_missing_stop_loss_key_is_safely_skipped_by_autopilot()
    print("\nAll open-positions stop/take checks passed.")
