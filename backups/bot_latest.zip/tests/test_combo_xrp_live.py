"""Офлайн-тесты Combo OTM XRP · OKX (без сети; HTTP подменяется).
Запуск из папки bot:  python -m unittest tests.test_combo_xrp_live -v"""
from __future__ import annotations

import json
import sys
import tempfile
import time
import types
import unittest
from pathlib import Path
from unittest import mock

BASE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE))

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from app.exchanges import okx  # noqa: E402
import combo_xrp_live as cx  # noqa: E402

INST = {"instId": "XRP-USDT-SWAP", "ctVal": 100.0, "lotSz": 0.01, "minSz": 0.01, "tickSz": 0.0001, "maxMktSz": None}
FAKE = ("k", "s", "p")


class Resp:
    def __init__(self, payload):
        self._p = payload

    def json(self):
        return self._p

    def raise_for_status(self):
        return None


# ------------------------------------------------------------------ okx payloads --
class OkxPayloadTests(unittest.TestCase):
    def setUp(self):
        okx._INSTRUMENT_CACHE.clear()
        okx._INSTRUMENT_CACHE["XRP-USDT-SWAP"] = dict(INST)

    def test_inst_id(self):
        self.assertEqual(okx.to_inst_id("XRPUSDT"), "XRP-USDT-SWAP")
        self.assertEqual(okx.to_inst_id("xrp-usdt"), "XRP-USDT-SWAP")
        self.assertEqual(okx.to_inst_id("XRP-USDT-SWAP"), "XRP-USDT-SWAP")

    def test_sizes_rounding(self):
        # $75 при цене 2.5 -> 75/(2.5*100)=0.3 конт.
        self.assertEqual(okx.contracts_for_notional(75, 2.5, INST), 0.3)
        self.assertEqual(okx.contracts_for_notional(75, 2.3456, INST), 0.31)   # 0.3197 -> 0.31 (вниз)
        self.assertEqual(okx.contracts_for_notional(0.5, 2.5, INST), 0.0)       # меньше minSz
        inst1 = dict(INST, lotSz=1.0, minSz=1.0)
        self.assertEqual(okx.contracts_for_notional(75, 0.5, inst1), 1.0)
        self.assertEqual(okx.round_price(2.123456, 0.0001), "2.1235")

    def test_body_net_mode(self):
        b = okx.build_order_body("XRP-USDT-SWAP", "buy", 0.31, 2.1, 2.3, 0.0001, "net_mode", cl_ord_id="cxrp1")
        self.assertEqual(b["tdMode"], "isolated")
        self.assertEqual(b["ordType"], "market")
        self.assertNotIn("posSide", b)
        self.assertEqual(b["sz"], "0.31")
        a = b["attachAlgoOrds"][0]
        self.assertEqual(a, {"slTriggerPx": "2.1000", "slOrdPx": "-1", "slTriggerPxType": "mark",
                             "tpTriggerPx": "2.3000", "tpOrdPx": "-1", "tpTriggerPxType": "mark"})
        self.assertTrue(b["clOrdId"].startswith("cxrp"))

    def test_body_long_short_mode(self):
        b = okx.build_order_body("XRP-USDT-SWAP", "sell", 1, 2.6, None, 0.0001, "long_short_mode")
        self.assertEqual(b["posSide"], "short")
        self.assertNotIn("tpTriggerPx", b["attachAlgoOrds"][0])
        b = okx.build_order_body("XRP-USDT-SWAP", "buy", 1, 2.4, None, 0.0001, "long_short_mode")
        self.assertEqual(b["posSide"], "long")

    def test_sl_required(self):
        with self.assertRaises(ValueError):
            okx.build_order_body("XRP-USDT-SWAP", "buy", 1, None, None, 0.0001, "net_mode")

    def test_place_order_http(self):
        sent = {}

        def fake_post(url, data=None, headers=None, timeout=None):
            sent["url"], sent["body"], sent["headers"] = url, json.loads(data), headers
            return Resp({"code": "0", "data": [{"ordId": "123", "clOrdId": sent["body"]["clOrdId"], "sCode": "0"}]})
        with mock.patch.object(okx.requests, "post", fake_post):
            r = okx.place_order(*FAKE[:2], "XRPUSDT", "buy", 0.0, 2.0, take_profit=2.5, passphrase="p",
                                contracts=0.3, pos_mode="net_mode", cl_ord_id="cxrptest")
        self.assertEqual(r["order_id"], "123")
        self.assertTrue(sent["url"].endswith("/api/v5/trade/order"))
        self.assertEqual(sent["body"]["attachAlgoOrds"][0]["slTriggerPx"], "2.0000")
        self.assertIn("OK-ACCESS-SIGN", sent["headers"])

    def test_place_order_coin_qty_contract(self):
        """Совместимость с /trade: qty в монетах -> контракты."""
        with mock.patch.object(okx.requests, "post",
                               lambda *a, **k: Resp({"code": "0", "data": [{"ordId": "9", "sCode": "0"}]})):
            r = okx.place_order("k", "s", "XRPUSDT", "sell", 35.0, 3.0, passphrase="p", pos_mode="net_mode")
        self.assertEqual(r["sz"], 0.35)

    def test_error_no_secret_in_message(self):
        with mock.patch.object(okx.requests, "post", lambda *a, **k: Resp(
                {"code": "1", "msg": "All operations failed", "data": [{"sCode": "51008", "sMsg": "Insufficient"}]})):
            with self.assertRaises(okx.DataError) as cm:
                okx.place_order("KEYXYZ", "SECRETXYZ", "XRPUSDT", "buy", 0, 2.0, passphrase="PASSXYZ",
                                contracts=0.3, pos_mode="net_mode")
        msg = str(cm.exception)
        self.assertIn("51008", msg)
        for secret in ("KEYXYZ", "SECRETXYZ", "PASSXYZ"):
            self.assertNotIn(secret, msg)

    def test_set_leverage_long_short_two_calls(self):
        bodies = []
        with mock.patch.object(okx.requests, "post",
                               lambda url, data=None, **k: bodies.append(json.loads(data)) or Resp({"code": "0", "data": []})):
            okx.set_leverage("k", "s", "XRPUSDT", 3, "p", pos_mode="long_short_mode")
            okx.set_leverage("k", "s", "XRPUSDT", 3, "p", pos_mode="net_mode")
        self.assertEqual([b.get("posSide") for b in bodies], ["long", "short", None])
        self.assertTrue(all(b["lever"] == "3" and b["mgnMode"] == "isolated" for b in bodies))

    def test_close_and_amend_bodies(self):
        bodies = []
        with mock.patch.object(okx.requests, "post",
                               lambda url, data=None, **k: bodies.append((url, json.loads(data))) or Resp({"code": "0", "data": [{}]})):
            okx.close_position("k", "s", "p", "XRPUSDT", "isolated", "net")
            okx.close_position("k", "s", "p", "XRPUSDT", "isolated", "short")
            okx.amend_stop_loss("k", "s", "XRPUSDT", 2.05, "p", algo_id="A1", take_profit=2.4)
        self.assertNotIn("posSide", bodies[0][1])
        self.assertEqual(bodies[1][1]["posSide"], "short")
        self.assertTrue(bodies[2][0].endswith("/api/v5/trade/amend-algos"))
        self.assertEqual(bodies[2][1]["newSlTriggerPx"], "2.0500")

    def test_fetch_position_parsing(self):
        payload = {"code": "0", "data": [{"pos": "-0.3", "posSide": "net", "avgPx": "2.5", "upl": "-0.4",
                                          "mgnMode": "isolated", "closeOrderAlgo": [{"algoId": "A7", "slTriggerPx": "2.6"}]}]}
        with mock.patch.object(okx.requests, "get", lambda *a, **k: Resp(payload)):
            p = okx.fetch_position("k", "s", "p", "XRPUSDT")
        self.assertEqual((p["side"], p["contracts"], p["sl"], p["sl_algo_id"]), ("short", 0.3, 2.6, "A7"))


# ------------------------------------------------------------------ bot fixtures --
SETTINGS = dict(cx.DEFAULT_SETTINGS, telegram=False)


class FakeLiveOkx:
    """Подмена модуля okx для LiveBackend."""

    def __init__(self, attach_sl=True, position=None, equity=50.0):
        self.attach_sl, self.pos, self.eq = attach_sl, position, equity
        self.calls = []

    contracts_for_notional = staticmethod(okx.contracts_for_notional)
    new_cl_ord_id = staticmethod(okx.new_cl_ord_id)

    def get_instrument(self, i):
        return dict(INST)

    def get_pos_mode(self, *k):
        return "net_mode"

    def set_leverage(self, *a, **k):
        self.calls.append("lev")

    def fetch_position(self, *a):
        return dict(self.pos) if self.pos else None

    def fetch_balance_usdt(self, *a):
        return {"equity": self.eq, "available": self.eq}

    def place_order(self, k, s, inst, side, qty, sl, take_profit=None, passphrase=None, contracts=None, **kw):
        self.calls.append(("order", side, contracts, sl, take_profit))
        self.pos = {"side": "long" if side == "buy" else "short", "contracts": contracts, "avg_px": 2.5, "upl": 0.0,
                    "mgn_mode": "isolated", "pos_side": "net", "sl": sl if self.attach_sl else None,
                    "tp": take_profit, "sl_algo_id": "A1" if self.attach_sl else None}
        return {"order_id": "1", "cl_ord_id": "cxrp1", "sz": contracts}

    def fetch_order(self, *a):
        return {"attachAlgoOrds": [{"slTriggerPx": "2.4"}] if self.attach_sl else []}

    def close_position(self, *a, **k):
        self.calls.append("close")
        self.pos = None

    def amend_stop_loss(self, *a, **k):
        self.calls.append("amend")

    def fetch_closed_trades(self, *a, **k):
        return pd.DataFrame(columns=["symbol", "avg_exit_price", "closed_pnl", "updated_time"])


def make_bot(tmp: Path, backend_kind="paper", fake=None, now=None):
    st = cx.StateFile(tmp / "state.json")
    notes = []
    s = dict(SETTINGS)
    if backend_kind == "paper":
        be = cx.PaperBackend(s, st)
        be.instrument = lambda: dict(INST)
    else:
        be = cx.LiveBackend(s, {"api_key": "k", "api_secret": "s", "passphrase": "p"}, okx_module=fake)
        be._confirm_sl = types.MethodType(lambda self, oid, tries=1, pause=0: cx.LiveBackend._confirm_sl(self, oid, 1, 0), be)
    clock = {"t": now or int(time.time() * 1000)}
    bot = cx.ComboXrpBot(s, be, st, notes.append, cfg={}, trades_csv=tmp / "trades.csv", now_fn=lambda: clock["t"])
    return bot, notes, clock


def bars_df(n=50, start_ms=None, price=2.5):
    start_ms = start_ms or (int(time.time() * 1000) // cx.H1 - n) * cx.H1
    idx = pd.to_datetime([start_ms + i * cx.H1 for i in range(n)], unit="ms")
    return pd.DataFrame({"open": price, "high": price * 1.002, "low": price * 0.998, "close": price, "volume": 1e6},
                        index=idx)


class BotSafetyTests(unittest.TestCase):
    def setUp(self):
        self.tmp = Path(tempfile.mkdtemp())
        self._log_trade = cx.log_trade

    def test_plan_size(self):
        p = cx.plan_size(SETTINGS, 50.0, 2.5, INST)
        self.assertEqual((p["margin"], p["notional"], p["contracts"]), (25.0, 75.0, 0.3))
        p = cx.plan_size(SETTINGS, 20.0, 2.5, INST)          # баланс меньше депозита -> от баланса
        self.assertEqual(p["notional"], 30.0)
        p = cx.plan_size(dict(SETTINGS, deposit=1000, leverage=5), 1000, 2.5, INST)
        self.assertEqual(p["notional"], 150.0)                 # потолок max_notional

    def test_settings_hard_limits(self):
        f = self.tmp / "s.json"
        f.write_text(json.dumps({"leverage": 20}))
        with self.assertRaises(cx.StopBot):
            cx.load_settings(f)
        f.write_text(json.dumps({"max_notional": 10000, "max_open": 5}))
        s = cx.load_settings(f)
        self.assertEqual((s["max_notional"], s["max_open"]), (cx.HARD_MAX_NOTIONAL, 1))

    def _target(self, bot, df, side=1, sl=2.4, tp=2.7):
        syn = int(df.index[-1].value // 1_000_000) + cx.H1
        return {"side": side, "sl": sl, "tp": tp, "avg": 2.5, "entry_ts": syn}, syn

    def test_open_then_engine_exit_paper(self):
        now = (int(time.time() * 1000) // cx.H1) * cx.H1 + 60_000
        bot, notes, clock = make_bot(self.tmp, now=now)
        df = bars_df(start_ms=now - 60_000 - 50 * cx.H1)
        tgt = self._target(bot, df)
        with mock.patch.object(cx, "engine_target", lambda *a, **k: tgt):
            self.assertEqual(bot.step(df, None, 2.5), "open")
        d = bot.st.deal
        self.assertTrue(d["in_deal"]) ; self.assertEqual(d["contracts"], 0.3)
        self.assertEqual(bot.step(df, None, 2.5), "same_bar")          # не доливает
        df2 = pd.concat([df, bars_df(1, start_ms=tgt[1])])
        clock["t"] += cx.H1
        with mock.patch.object(cx, "engine_target", lambda *a, **k: (None, tgt[1] + cx.H1)):
            self.assertEqual(bot.step(df2, None, 2.55), "close")
        self.assertFalse(bot.st.deal["in_deal"])
        rows = (self.tmp / "trades.csv").read_text(encoding="utf-8").splitlines()
        self.assertEqual(len(rows), 2)
        self.assertIn("paper", rows[1])

    def test_paper_exchange_sl_hit(self):
        now = (int(time.time() * 1000) // cx.H1) * cx.H1 + 60_000
        bot, notes, clock = make_bot(self.tmp, now=now)
        df = bars_df(start_ms=now - 60_000 - 50 * cx.H1)
        tgt = self._target(bot, df)
        with mock.patch.object(cx, "engine_target", lambda *a, **k: tgt):
            bot.step(df, None, 2.5)
        clock["t"] += 600_000
        with mock.patch.object(cx, "engine_target", lambda *a, **k: tgt):
            bot.step(df, None, 2.39)                                   # цена ниже стопа 2.4
        self.assertFalse(bot.st.deal["in_deal"])
        self.assertIn("SL", (self.tmp / "trades.csv").read_text(encoding="utf-8"))

    def test_late_signal_skipped(self):
        now = (int(time.time() * 1000) // cx.H1) * cx.H1 + 40 * 60_000
        bot, notes, _ = make_bot(self.tmp, now=now)
        df = bars_df(start_ms=now - 40 * 60_000 - 50 * cx.H1)
        tgt = self._target(bot, df)
        with mock.patch.object(cx, "engine_target", lambda *a, **k: tgt):
            self.assertEqual(bot.step(df, None, 2.5), "hold")
        self.assertTrue(any("пропущен" in n for n in notes))

    def test_kill_switch_paper(self):
        now = (int(time.time() * 1000) // cx.H1) * cx.H1 + 60_000
        bot, notes, clock = make_bot(self.tmp, now=now)
        bot.s["daily_loss_stop"] = 5.0
        df = bars_df(start_ms=now - 60_000 - 50 * cx.H1)
        tgt = self._target(bot, df, side=1, sl=1.0)                    # далёкий стоп
        with mock.patch.object(cx, "engine_target", lambda *a, **k: tgt):
            bot.step(df, None, 2.5)
        clock["t"] += 60_000
        with self.assertRaises(cx.StopBot):
            bot.step(df, None, 2.0)                                     # 30 XRP × −0.5 = −15 $
        self.assertFalse(bot.st.deal["in_deal"])
        self.assertTrue(bot.st.meta["killed_day"])
        with self.assertRaises(cx.StopBot):                             # повторный запуск в тот же день
            bot.step(df, None, 2.5)

    def test_kill_switch_balance_drop_live(self):
        fake = FakeLiveOkx(equity=50.0)
        bot, notes, _ = make_bot(self.tmp, "live", fake)
        fake.eq = 34.0
        with self.assertRaises(cx.StopBot):
            bot.check_kill(2.5)
        self.assertTrue(any("KILL" in n for n in notes))

    def test_missing_sl_closes_and_stops(self):
        now = (int(time.time() * 1000) // cx.H1) * cx.H1 + 60_000
        fake = FakeLiveOkx(attach_sl=False)
        bot, notes, _ = make_bot(self.tmp, "live", fake, now=now)
        df = bars_df(start_ms=now - 60_000 - 50 * cx.H1)
        tgt = self._target(bot, df)
        with mock.patch.object(cx, "engine_target", lambda *a, **k: tgt), self.assertRaises(cx.StopBot):
            bot.step(df, None, 2.5)
        self.assertIn("close", fake.calls)
        self.assertIsNone(fake.pos)
        self.assertFalse(bot.st.deal["in_deal"])
        self.assertTrue(any("стоп-лосс" in n for n in notes))

    def test_live_open_with_sl(self):
        now = (int(time.time() * 1000) // cx.H1) * cx.H1 + 60_000
        fake = FakeLiveOkx(attach_sl=True)
        bot, notes, _ = make_bot(self.tmp, "live", fake, now=now)
        df = bars_df(start_ms=now - 60_000 - 50 * cx.H1)
        tgt = self._target(bot, df, side=-1, sl=2.6, tp=2.3)
        with mock.patch.object(cx, "engine_target", lambda *a, **k: tgt):
            self.assertEqual(bot.step(df, None, 2.5), "open")
        self.assertEqual(fake.calls[-1], ("order", "sell", 0.3, 2.6, 2.3))

    def test_reconcile_foreign_position(self):
        fake = FakeLiveOkx(position={"side": "long", "contracts": 5.0, "upl": 0, "pos_side": "net"})
        bot, notes, _ = make_bot(self.tmp, "live", fake)
        df = bars_df()
        self.assertEqual(bot.step(df, None, 2.5), "paused")
        self.assertEqual(bot.step(df, None, 2.5), "paused")
        self.assertEqual(sum("НЕ ботом" in n for n in notes), 1)        # одна тревога
        self.assertNotIn("close", fake.calls)                           # чужое не трогаем
        fake.pos = None
        with mock.patch.object(cx, "engine_target", lambda *a, **k: (None, 0)):
            bot.step(df, None, 2.5)
        self.assertFalse(bot.st.meta.get("paused"))

    def test_reconcile_exchange_closed(self):
        fake = FakeLiveOkx()
        bot, notes, _ = make_bot(self.tmp, "live", fake)
        bot.st.data[cx.SYMBOL] = {"in_deal": True, "side": "long", "contracts": 0.3, "qty_coins": 30,
                                  "base_price": 2.5, "entry_ms": bot.now() - cx.H1}
        self.assertTrue(bot.reconcile(2.4))
        self.assertFalse(bot.st.deal["in_deal"])

    def test_live_gate(self):
        f = self.tmp / "c.json"
        ns = types.SimpleNamespace(live=True)
        live = dict(SETTINGS, mode="live")
        self.assertFalse(cx.live_confirmed(types.SimpleNamespace(live=False), live, f, {})[0])
        self.assertFalse(cx.live_confirmed(ns, dict(SETTINGS, mode="paper"), f, {})[0])
        self.assertFalse(cx.live_confirmed(ns, live, f, {cx.CONFIRM_ENV: "x"})[0])        # нет файла
        f.write_text(json.dumps({"token": "abc", "created": time.time()}))
        self.assertFalse(cx.live_confirmed(ns, live, f, {cx.CONFIRM_ENV: "zzz"})[0])      # не тот токен
        f.write_text(json.dumps({"token": "abc", "created": time.time() - 3600}))
        self.assertFalse(cx.live_confirmed(ns, live, f, {cx.CONFIRM_ENV: "abc"})[0])      # устарел
        f.write_text(json.dumps({"token": "abc", "created": time.time()}))
        self.assertTrue(cx.live_confirmed(ns, live, f, {cx.CONFIRM_ENV: "abc"})[0])
        self.assertFalse(f.exists())                                                       # одноразовый

    def test_state_file_server_compatible(self):
        bot, _, _ = make_bot(self.tmp)
        bot.st.save()
        raw = json.loads((self.tmp / "state.json").read_text(encoding="utf-8"))
        self.assertTrue(all(isinstance(v, dict) for v in raw.values()))


class SupervisorTests(unittest.TestCase):
    def test_registered_and_argv(self):
        from windows_app import process_supervisor as ps
        self.assertIn("combo_xrp", ps.STRATEGIES)
        self.assertEqual(ps.STRATEGIES["combo_xrp"]["label"], "Combo OTM XRP · OKX")
        with mock.patch.object(ps, "resolve_python_executable", lambda: "python"):
            self.assertTrue(ps.build_argv("combo_xrp", "paper")[1].endswith("combo_xrp_live.py"))
            self.assertNotIn("--live", ps.build_argv("combo_xrp", "paper"))
            self.assertEqual(ps.build_argv("combo_xrp", "live")[-1], "--live")
        from app.live_bot_settings import LiveBotParamsStore
        meta = ps.STRATEGIES["combo_xrp"]
        self.assertEqual(LiveBotParamsStore(Path(tempfile.mkdtemp()) / "x.json", "combo_xrp").get()["symbols"], ["XRPUSDT"])
        with self.assertRaises(PermissionError):
            ps.ProcessSupervisor().start("combo_xrp", "live", confirm_live=False)
        self.assertTrue(str(meta["script"]).endswith("combo_xrp_live.py"))

    def test_live_start_passes_one_time_token(self):
        from windows_app import process_supervisor as ps
        tmp = Path(tempfile.mkdtemp())
        meta = dict(ps.STRATEGIES["combo_xrp"], live_confirm_file=tmp / "confirm.json")
        seen = {}

        class P:
            pid = 1

            def poll(self):
                return None

        def fake_popen(argv, **kw):
            seen["argv"], seen["env"] = argv, kw.get("env")
            return P()
        with mock.patch.dict(ps.STRATEGIES, {"combo_xrp": meta}), \
                mock.patch.object(ps, "detect_external_run", lambda sid: None), \
                mock.patch.object(ps, "resolve_python_executable", lambda: "python"), \
                mock.patch.object(ps, "LOG_DIR", tmp), \
                mock.patch.object(ps.subprocess, "Popen", fake_popen):
            sup = ps.ProcessSupervisor()
            sup.start("combo_xrp", "live", confirm_live=True)
            data = json.loads((tmp / "confirm.json").read_text())
            self.assertEqual(seen["env"]["COMBO_XRP_CONFIRM_TOKEN"], data["token"])
            self.assertNotIn(data["token"], " ".join(seen["argv"]))
            self.assertIn("--live", seen["argv"])
            sup._procs.clear()
            sup.start("combo_xrp", "paper")
            self.assertFalse((tmp / "confirm.json").exists())
            self.assertIsNone(seen["env"])


class PaperDryRun(unittest.TestCase):
    """Сквозной прогон с настоящим движком combo_full и синтетическими свечами (PAPER)."""

    def test_dry_run_real_engine(self):
        """Реальные часовые свечи XRP/BTC из market_cache/binance (последние 1300 баров, время сдвинуто к «сейчас»).
        Бот идёт бар за баром, как в жизни; сделки бота сравниваются с бэктестом движка на том же окне."""
        import combo_full as cf
        fx, fb = BASE / "market_cache/binance/XRPUSDT_1h.csv", BASE / "market_cache/binance/BTCUSDT_1h.csv"
        if not fx.exists() or not fb.exists():
            self.skipTest("нет market_cache/binance/XRPUSDT_1h.csv / BTCUSDT_1h.csv")
        cfg = cf.load_settings_csv(str(BASE / "combo_sub2.csv"))[0]
        x = pd.read_csv(fx).tail(1300).reset_index(drop=True)
        b = pd.read_csv(fb)
        b = b[b["t"].isin(x["t"])].set_index("t").reindex(x["t"]).ffill().reset_index()
        n_hist, n = 900, len(x)
        shift = (int(time.time() * 1000) // cx.H1 - n - 2) * cx.H1 - int(x["t"].iloc[0])

        def rows(df):
            return [[int(r.t) + shift, r.o, r.h, r.l, r.c, r.v, True] for r in df.itertuples()]
        X, B = rows(x), rows(b)
        tmp = Path(tempfile.mkdtemp())
        st = cx.StateFile(tmp / "paper_state.json")
        s = dict(SETTINGS)
        be = cx.PaperBackend(s, st)
        be.instrument = lambda: dict(INST)
        start_ms = X[n_hist][0]
        clock = {"t": start_ms + 60_000}
        notes = []
        bot = cx.ComboXrpBot(s, be, st, notes.append, cfg, trades_csv=tmp / "trades.csv", now_fn=lambda: clock["t"])
        bot.st.meta["started_ms"] = start_ms
        acts = []
        for k in range(n_hist, n):
            clock["t"] = X[k][0] + 60_000
            df = cx.candles_df(X[:k], clock["t"])
            ref = cx.candles_df(B[:k], clock["t"])
            acts.append(bot.step(df, ref, float(X[k][1])))
        opens, closes = acts.count("open"), acts.count("close")
        trades = (tmp / "trades.csv").read_text(encoding="utf-8").splitlines()[1:] if (tmp / "trades.csv").exists() else []
        full = cx.candles_df(X[:n], X[n - 1][0] + 2 * cx.H1)
        ref_full = cx.candles_df(B[:n], X[n - 1][0] + 2 * cx.H1)
        tr, _dd, _eq, _s = cf.run(full, cfg, ref_full, start=str(pd.Timestamp(start_ms, unit="ms")))
        print(f"\n[dry-run] баров {len(acts)}, входов бота {opens}, выходов по сигналу {closes}, сделок в CSV {len(trades)}, "
              f"сделок у бэктеста движка {len(tr)}, paper equity {be.equity():.2f} $")
        self.assertEqual(len(trades) + int(bool(bot.st.deal.get("in_deal"))), opens)
        self.assertGreater(opens, 0)
        self.assertLessEqual(abs(opens - len(tr)), max(2, len(tr) // 5))
        self.assertNotIn("paused", acts)

if __name__ == "__main__":
    unittest.main(verbosity=2)
