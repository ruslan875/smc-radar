"""tests/test_core.py — 2026-11-08 (ChatGPT ТЗ, фаза 15): автотесты ядра. Запуск: python -m pytest tests -q (из папки bot)."""
import sys, json, time
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
try:
    import pytest  # noqa: F401
except ImportError:
    pytest = None


# ---------- размер позиции: Decimal, вниз до шага ----------
def test_round_qty_step_and_no_float_error():
    from windows_app.mobile_gateway import round_qty
    assert round_qty(100, 3, 0.1) == 33.3            # 33.333.. → вниз до 0.1
    assert round_qty(0.3, 0.1, 0.1) == 3.0           # float дал бы 2.9999999
    assert round_qty(50, 75000, 0.001) == 0.0        # меньше шага → 0 (ордер не уйдёт)
    assert round_qty(1000, 75000, 0.001) == 0.013
    assert round_qty(10, 0, 0.1) == 0.0              # защита от деления на 0


# ---------- сигналы без заглядывания в будущее ----------
def _series(n=400):
    import math
    c = [100 + 10 * math.sin(i / 15) + i * 0.05 for i in range(n)]
    return [x + 1 for x in c], [x - 1 for x in c], c


def test_bos_signals_no_lookahead():
    from windows_app import afbos_paper as A
    h, l, c = _series()
    full = A.bos_signals(h, l, c)
    for cut in (150, 250, 399):                      # сигнал на баре i не меняется, если будущих баров нет
        part = A.bos_signals(h[:cut], l[:cut], c[:cut])
        assert part == full[:cut]


def test_retest_signals_no_lookahead():
    from windows_app import afbos_paper as A
    h, l, c = _series()
    full = A.bos_retest_signals(h, l, c)
    assert A.bos_retest_signals(h[:300], l[:300], c[:300]) == full[:300]


# ---------- фильтр входа (тренд BTC + ATR растёт) ----------
def test_entry_gate(monkeypatch, tmp_path):
    from windows_app import challenge_guard as cg
    monkeypatch.setattr(cg, "BASE", tmp_path)
    monkeypatch.setattr(cg, "btc_trend", lambda: 1)
    monkeypatch.setattr(cg, "atr_rising", lambda s: True)
    st = {}
    assert cg.entry_gate("SOLUSDT", 1, st) is True
    assert cg.entry_gate("SOLUSDT", -1, st) is False             # против тренда BTC
    monkeypatch.setattr(cg, "atr_rising", lambda s: False)
    assert cg.entry_gate("SOLUSDT", 1, st) is False              # ATR падает
    monkeypatch.setattr(cg, "atr_rising", lambda s: None)
    assert cg.entry_gate("SOLUSDT", 1, st) is True               # нет данных — не блокирует
    assert len(st["filtered"]) == 2
    log = (tmp_path / "logs" / "signal_decisions.jsonl").read_text(encoding="utf-8").splitlines()
    assert len(log) == 4 and sum(1 for x in log if json.loads(x)["ok"]) == 2


# ---------- риск после серии стопов на демо ----------
def test_streak_k(monkeypatch):
    from windows_app import demo_mirror as dm
    def mk(rs):
        monkeypatch.setattr(dm, "_load", lambda: {"closed": [{"tag": "T", "r": r} for r in rs]})
    mk([-1] * 4); assert dm.streak_k("T") == 1.0
    mk([-1] * 5); assert dm.streak_k("T") == 0.5
    mk([-1] * 10); assert dm.streak_k("T") == 0.25
    mk([-1] * 10 + [2.5] + [-1] * 2); assert dm.streak_k("T") == 1.0   # после +2R — полный риск
    mk([-1] * 6 + [0.5]); assert dm.streak_k("T") == 0.5              # маленький плюс серию не сбрасывает


# ---------- сверка демо: не закрывать сделку, пока позиция на бирже есть ----------
def test_reconcile_keeps_open_position(monkeypatch):
    from windows_app import demo_mirror as dm
    rec = {"open": {"X:SOLUSDT": {"tag": "X", "symbol": "SOLUSDT", "side": 1, "since": 0, "entry": 1, "sl": 0.9}}, "closed": []}
    monkeypatch.setattr(dm, "_load", lambda: rec)
    finished = []
    monkeypatch.setattr(dm, "_finish", lambda c, k, d, w: finished.append(k))
    monkeypatch.setattr(dm, "_own", lambda *a: (0.0, None))         # исполнение «не видно» — как в ошибке 07.11
    monkeypatch.setattr(dm, "_my_orders", lambda *a: [])
    monkeypatch.setattr(dm, "_cancel_mine", lambda *a: None)
    monkeypatch.setattr(dm.bd, "call", lambda c, m, p, q=None: {"list": [{"size": "5"}]} if "position" in p else {})
    dm._reconcile({}); assert finished == []                         # позиция есть → не трогаем
    monkeypatch.setattr(dm.bd, "call", lambda c, m, p, q=None: {"list": []} if "position" in p else {})
    dm._reconcile({}); assert finished == ["X:SOLUSDT"]              # позиции нет → закрываем запись
    rec["open"]["X:SOLUSDT"]["since"] = time.time() * 1000; finished.clear()
    dm._reconcile({}); assert finished == []                         # первые 10 минут не трогаем


# ---------- запуск без pytest: python tests/test_core.py ----------
class _MP:
    def __init__(self): self.undo = []
    def setattr(self, obj, name, val):
        self.undo.append((obj, name, getattr(obj, name))); setattr(obj, name, val)
    def restore(self):
        for o, n, v in reversed(self.undo): setattr(o, n, v)


if __name__ == "__main__":
    import inspect, tempfile, traceback
    ok = bad = 0
    for name, fn in list(globals().items()):
        if not name.startswith("test_") or not callable(fn): continue
        mp = _MP(); args = {"monkeypatch": mp, "tmp_path": Path(tempfile.mkdtemp())}
        try:
            fn(**{k: args[k] for k in inspect.signature(fn).parameters}); ok += 1; print("OK  ", name)
        except Exception:  # noqa: BLE001
            bad += 1; print("FAIL", name); traceback.print_exc()
        finally:
            mp.restore()
    print(f"\nитого: {ok} прошли, {bad} упали"); raise SystemExit(1 if bad else 0)
