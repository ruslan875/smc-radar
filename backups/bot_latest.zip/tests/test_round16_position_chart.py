"""
2026-08-25, round 16 follow-up: regression tests for the "show my open
position ON the chart, with real lines" feature the user asked for a
SECOND time after the round-16 text-only info card didn't satisfy them
("на графике нет снова ничего" -- there's nothing on the chart, again).
This round finally does draw real lines on real candles, by reusing the
bot's OWN chart-drawing code (app/chart.py's render_signal_card, already
used for every signal alert) instead of fighting TradingView's free
embed widget's real limitation (no JS drawing API -- see the project
doc's round-16 write-up).

Covers three layers:
  1. app/github_sync.py's new push_binary_file() -- the generic binary
     counterpart to the existing push_json_file(), used to publish the
     rendered PNGs to the same GitHub Pages repo.
  2. app/chart.py's new render_position_chart() -- must produce a real
     PNG, must not crash when stop_loss/take_profit/mark_price are
     missing (a genuinely possible real-world shape, e.g. an autopilot-
     managed position with no take_profit), and must handle both buy/sell
     sides.
  3. main.py's new _maybe_publish_position_charts() -- must skip a
     position with no symbol/entry, must publish a correctly-named PNG
     for a valid one, must not let one bad position's failure block
     another's, and must no-op entirely when GITHUB_TOKEN isn't set.

Run: python tests/test_round16_position_chart.py
"""
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd

from app import chart
from app.github_sync import push_binary_file


def _fake_klines(n=60, start=100.0):
    rows = []
    price = start
    for i in range(n):
        o = price
        c = price + (0.5 if i % 2 == 0 else -0.3)
        h = max(o, c) + 0.4
        l = min(o, c) - 0.4
        rows.append({"open": o, "high": h, "low": l, "close": c, "volume": 10.0})
        price = c
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------
# Layer 1: app/github_sync.py push_binary_file()
# ---------------------------------------------------------------------

def test_push_binary_file_creates_when_no_existing_sha():
    fake_get = MagicMock(status_code=404, json=lambda: {})
    fake_put = MagicMock(status_code=201)
    with patch("app.github_sync.requests.get", return_value=fake_get), \
         patch("app.github_sync.requests.put", return_value=fake_put) as mock_put:
        push_binary_file("tok", "owner/repo", "position_charts/bybit_BTCUSDT.png", b"\x89PNGfakebytes", "msg")
    put_kwargs = mock_put.call_args
    payload = put_kwargs.kwargs["json"] if "json" in put_kwargs.kwargs else put_kwargs[1]["json"]
    assert "sha" not in payload
    import base64
    assert base64.b64decode(payload["content"]) == b"\x89PNGfakebytes"
    print("OK: push_binary_file() creates a new file (no sha) with correctly base64-encoded raw bytes.")


def test_push_binary_file_updates_with_existing_sha():
    fake_get = MagicMock(status_code=200, json=lambda: {"sha": "abc123"})
    fake_put = MagicMock(status_code=200)
    with patch("app.github_sync.requests.get", return_value=fake_get), \
         patch("app.github_sync.requests.put", return_value=fake_put) as mock_put:
        push_binary_file("tok", "owner/repo", "position_charts/bybit_BTCUSDT.png", b"newbytes", "msg")
    payload = mock_put.call_args.kwargs["json"]
    assert payload["sha"] == "abc123"
    print("OK: push_binary_file() includes the existing file's sha when updating (required by GitHub's API).")


def test_push_binary_file_raises_on_failure_status():
    from app.github_sync import GitHubSyncError
    fake_get = MagicMock(status_code=404, json=lambda: {})
    fake_put = MagicMock(status_code=422, text="Validation Failed")
    with patch("app.github_sync.requests.get", return_value=fake_get), \
         patch("app.github_sync.requests.put", return_value=fake_put):
        try:
            push_binary_file("tok", "owner/repo", "x.png", b"x", "msg")
            assert False, "expected GitHubSyncError"
        except GitHubSyncError as exc:
            assert "422" in str(exc)
    print("OK: a non-200/201 PUT response raises GitHubSyncError, same contract as push_json_file().")


# ---------------------------------------------------------------------
# Layer 2: app/chart.py render_position_chart()
# ---------------------------------------------------------------------

def test_render_position_chart_produces_a_real_png_with_all_fields():
    df = _fake_klines()
    png = chart.render_position_chart(
        df=df, symbol_label="BTC", timeframe="15m", side="buy",
        entry=105.0, stop_loss=95.0, take_profit=130.0, mark_price=110.0,
    )
    assert isinstance(png, bytes) and len(png) > 100
    assert png[:8] == b"\x89PNG\r\n\x1a\n"
    print("OK: render_position_chart() with every field given produces a real PNG (correct magic bytes).")


def test_render_position_chart_handles_missing_stop_take_mark():
    """A real open position can genuinely have no take_profit (e.g. never
    set), and this function must never invent a line to draw -- just
    render_position_chart(..., stop_loss=None, take_profit=None,
    mark_price=None) shouldn't crash or draw anything for the missing
    ones."""
    df = _fake_klines()
    png = chart.render_position_chart(
        df=df, symbol_label="ETH", timeframe="15m", side="sell",
        entry=100.0, stop_loss=None, take_profit=None, mark_price=None,
    )
    assert isinstance(png, bytes) and png[:8] == b"\x89PNG\r\n\x1a\n"
    print("OK: render_position_chart() doesn't crash and still produces a valid PNG when stop_loss/"
          "take_profit/mark_price are all None (a genuinely possible real position shape).")


def test_render_position_chart_handles_both_sides():
    df = _fake_klines()
    for side in ("buy", "sell", "long", "short"):
        png = chart.render_position_chart(df=df, symbol_label="X", timeframe="15m", side=side,
                                           entry=100.0, stop_loss=90.0)
        assert png[:8] == b"\x89PNG\r\n\x1a\n"
    print("OK: render_position_chart() handles buy/sell/long/short side values without crashing.")


# ---------------------------------------------------------------------
# Layer 3: main.py _maybe_publish_position_charts()
# ---------------------------------------------------------------------

def _settings(github_token="tok"):
    from app.config import Settings
    return Settings(
        telegram_token="t", telegram_chat_id="c", timeframe="15m", swing_left=3, swing_right=3,
        poll_seconds=60, watchlist=["BTCUSDT"], use_htf_filter=True, show_rsi=False,
        github_token=github_token, github_repo="ruslan875/smc-radar", weekly_risk_budget_usdt=50.0,
    )


def test_publish_position_charts_noop_without_github_token():
    import main
    health = {"sources": {"bybit": {"open_positions": [
        {"symbol": "BTCUSDT", "side": "buy", "avg_entry_price": 100.0, "stop_loss": 90.0},
    ]}}}
    with patch("main.get_klines") as mock_klines, patch("main.push_binary_file") as mock_push:
        main._maybe_publish_position_charts(_settings(github_token=""), health)
    mock_klines.assert_not_called()
    mock_push.assert_not_called()
    print("OK: _maybe_publish_position_charts() does nothing at all when GITHUB_TOKEN isn't set -- "
          "not even a kline fetch.")


def test_publish_position_charts_skips_position_with_no_symbol_or_entry():
    import main
    health = {"sources": {"bybit": {"open_positions": [
        {"symbol": None, "side": "buy", "avg_entry_price": 100.0},
        {"symbol": "ETHUSDT", "side": "buy", "avg_entry_price": None},
    ]}}}
    with patch("main.get_klines") as mock_klines, patch("main.push_binary_file") as mock_push:
        main._maybe_publish_position_charts(_settings(), health)
    mock_klines.assert_not_called()
    mock_push.assert_not_called()
    print("OK: a position missing a symbol or an entry price is skipped -- nothing meaningful to draw.")


def test_publish_position_charts_publishes_a_valid_position_with_correct_path():
    import main
    health = {"sources": {"bybit": {"open_positions": [
        {"symbol": "BTCUSDT", "side": "buy", "avg_entry_price": 100.0, "stop_loss": 90.0,
         "take_profit": 130.0, "mark_price": 105.0},
    ]}}}
    fake_df = _fake_klines()
    with patch("main.get_klines", return_value=fake_df) as mock_klines, \
         patch("main.chart.render_position_chart", return_value=b"FAKEPNG") as mock_render, \
         patch("main.push_binary_file") as mock_push:
        main._maybe_publish_position_charts(_settings(), health)
    mock_klines.assert_called_once_with("BTCUSDT", "15m", limit=150)
    mock_render.assert_called_once()
    render_kwargs = mock_render.call_args.kwargs
    assert render_kwargs["entry"] == 100.0
    assert render_kwargs["stop_loss"] == 90.0
    assert render_kwargs["take_profit"] == 130.0
    assert render_kwargs["mark_price"] == 105.0
    mock_push.assert_called_once()
    push_args = mock_push.call_args[0]
    assert push_args[0] == "tok" and push_args[1] == "ruslan875/smc-radar"
    assert push_args[2] == "position_charts/bybit_BTCUSDT.png"
    assert push_args[3] == b"FAKEPNG"
    print("OK: a valid open position is rendered and published to the exact expected "
          "'position_charts/<exchange>_<symbol>.png' path.")


def test_publish_position_charts_one_bad_position_does_not_block_another():
    import main
    from app.data import DataError
    health = {"sources": {"bybit": {"open_positions": [
        {"symbol": "BADUSDT", "side": "buy", "avg_entry_price": 50.0},
        {"symbol": "GOODUSDT", "side": "buy", "avg_entry_price": 100.0, "stop_loss": 90.0},
    ]}}}

    def klines_side_effect(symbol, *a, **k):
        if symbol == "BADUSDT":
            raise DataError("boom")
        return _fake_klines()

    with patch("main.get_klines", side_effect=klines_side_effect), \
         patch("main.chart.render_position_chart", return_value=b"FAKEPNG") as mock_render, \
         patch("main.push_binary_file") as mock_push:
        main._maybe_publish_position_charts(_settings(), health)
    mock_render.assert_called_once()  # only for GOODUSDT
    mock_push.assert_called_once()
    published_symbol_path = mock_push.call_args[0][2]
    assert "GOODUSDT" in published_symbol_path
    print("OK: a kline-fetch failure for one position is logged and skipped, without blocking "
          "another position in the same publish pass.")


if __name__ == "__main__":
    test_push_binary_file_creates_when_no_existing_sha()
    test_push_binary_file_updates_with_existing_sha()
    test_push_binary_file_raises_on_failure_status()
    test_render_position_chart_produces_a_real_png_with_all_fields()
    test_render_position_chart_handles_missing_stop_take_mark()
    test_render_position_chart_handles_both_sides()
    test_publish_position_charts_noop_without_github_token()
    test_publish_position_charts_skips_position_with_no_symbol_or_entry()
    test_publish_position_charts_publishes_a_valid_position_with_correct_path()
    test_publish_position_charts_one_bad_position_does_not_block_another()
    print("\nAll round-16-follow-up position-chart checks passed.")
