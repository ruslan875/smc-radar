"""
2026-08-26/29, round 18: regression tests for /aichart -- the user asked
for Vera (the AI persona) to "analyze the chart and mark the entry point,
take-profit, stop-loss with labels, and mark the support/resistance
zones." Scoped via AskUserQuestion into "both at once": ALWAYS show the
bot's own REAL, already-computed zones/levels (order-block/FVG zones from
the deterministic detector, plus a real active signal's real entry/stop/
take if one exists) as the base layer, PLUS a separately and clearly
labeled EXPERIMENTAL AI-generated hypothesis layer on the SAME chart
image, carrying the same "not a signal, not a guarantee" framing the
existing /aiidea text command already uses.

This is the FIRST time this project lets an LLM's own generated price
levels get drawn onto an image instead of staying as hedged prose -- so
this test file is specifically about the safety contract around that:

  - app/ai_assistant.py's generate_chart_annotation() must return a clean,
    validated dict on a well-formed response, and None (never raise) on
    ANY problem: malformed/missing JSON, insufficient_data=true (even
    with other fields populated), a stop-loss on the wrong side of entry
    for the stated direction, or a level wildly outside a sane
    order-of-magnitude band of the real current price.
  - app/chart.py's render_ai_annotated_chart() must always draw the real
    bot-zone layer, and must never crash regardless of what real/AI data
    is or isn't present (no real zones, no active signal, ai_annotation
    None) -- and must produce a valid PNG either way.
  - main.py's /aichart command handler must be the ONLY place
    generate_chart_annotation() is ever called from -- never a poll loop
    (_autopilot_worker, _maybe_publish_health, etc.) -- matching this
    project's existing "AI calls are on-demand only" cost discipline
    (see app/ai_assistant.py's own module docstring).

Run: python tests/test_round18_ai_chart.py
"""
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd

from app import chart
from app.ai_assistant import generate_chart_annotation
from app.config import Settings
from app.data import DataError
from app.smc import PendingZone

PNG_MAGIC = b"\x89PNG\r\n\x1a\n"


def _settings(**overrides) -> Settings:
    base = dict(
        telegram_token="t", telegram_chat_id="555", timeframe="15m", swing_left=3, swing_right=3,
        poll_seconds=60, watchlist=["BTCUSDT"], use_htf_filter=True, show_rsi=False,
        github_token="", github_repo="ruslan875/smc-radar", weekly_risk_budget_usdt=50.0,
        anthropic_api_key="sk-test-key",
    )
    base.update(overrides)
    return Settings(**base)


def _fake_ai_text_response(text: str):
    return MagicMock(status_code=200, json=lambda: {"content": [{"type": "text", "text": text}]})


def _fake_klines(n=60, start=100.0):
    rows = []
    price = start
    for i in range(n):
        o = price
        c = price + (0.5 if i % 2 == 0 else -0.3)
        h = max(o, c) + 0.4
        l = min(o, c) - 0.4
        rows.append({"open": o, "high": h, "low": l, "close": c, "volume": 10.0})
        price = c
    return pd.DataFrame(rows)


def _valid_json_text(current_price=100.0):
    return (
        '{"insufficient_data": false, "direction": "long", "entry": %g, "stop_loss": %g, '
        '"take_profit": %g, "support_resistance": [{"price": %g, "kind": "resistance", '
        '"label": "прошлый хай"}], "note": "просто гипотеза"}'
    ) % (current_price * 0.995, current_price * 0.98, current_price * 1.03, current_price * 1.02)


def _pending_zone(symbol="BTCUSDT", direction="long", bottom=99.0, top=100.0):
    return PendingZone(
        symbol=symbol, timeframe="15m", direction=direction, top=top, bottom=bottom,
        zone_kind="OB+FVG", structure_event="CHoCH", armed_index=100,
        armed_time=pd.Timestamp("2026-08-26T00:00:00", tz="UTC"), swing_broken=top + 1,
    )


# ---------------------------------------------------------------------
# 1. generate_chart_annotation() -- valid response parses correctly
# ---------------------------------------------------------------------

def test_valid_annotation_parses_correctly():
    settings = _settings()
    text = _valid_json_text(100.0)
    with patch("app.ai_assistant.requests.post", return_value=_fake_ai_text_response(text)):
        result = generate_chart_annotation("BTCUSDT", "context", 100.0, settings)
    assert result is not None
    assert result["direction"] == "long"
    assert result["entry"] == pytest_approx(99.5)
    assert result["stop_loss"] == pytest_approx(98.0)
    assert result["take_profit"] == pytest_approx(103.0)
    assert len(result["support_resistance"]) == 1
    assert result["support_resistance"][0]["kind"] == "resistance"
    assert result["note"] == "просто гипотеза"
    print("OK: a well-formed JSON annotation parses into a clean, validated dict.")


def pytest_approx(x, tol=1e-6):
    class _Approx:
        def __eq__(self, other):
            return abs(other - x) < tol
    return _Approx()


# ---------------------------------------------------------------------
# 2. Malformed / missing JSON returns None
# ---------------------------------------------------------------------

def test_malformed_json_returns_none():
    settings = _settings()
    with patch("app.ai_assistant.requests.post", return_value=_fake_ai_text_response("this is not json at all")):
        result = generate_chart_annotation("BTCUSDT", "context", 100.0, settings)
    assert result is None
    print("OK: a non-JSON response from the model returns None, never raises.")


def test_json_missing_required_field_returns_none():
    settings = _settings()
    # Valid JSON, but "stop_loss" is entirely absent.
    text = '{"insufficient_data": false, "direction": "long", "entry": 99.5, "take_profit": 103.0, "note": "x"}'
    with patch("app.ai_assistant.requests.post", return_value=_fake_ai_text_response(text)):
        result = generate_chart_annotation("BTCUSDT", "context", 100.0, settings)
    assert result is None
    print("OK: JSON missing a required numeric field (stop_loss) returns None.")


def test_json_wrapped_in_markdown_fence_still_parses():
    """Models don't always follow "no markdown fences" perfectly -- the
    fence-stripping should be a defensive nicety, not required for
    correctness, but it must not itself cause a crash or false rejection."""
    settings = _settings()
    text = "```json\n" + _valid_json_text(100.0) + "\n```"
    with patch("app.ai_assistant.requests.post", return_value=_fake_ai_text_response(text)):
        result = generate_chart_annotation("BTCUSDT", "context", 100.0, settings)
    assert result is not None
    print("OK: a JSON response wrapped in a markdown code fence is still parsed correctly.")


# ---------------------------------------------------------------------
# 3. insufficient_data: true returns None even with other fields populated
# ---------------------------------------------------------------------

def test_insufficient_data_true_returns_none_even_with_populated_fields():
    settings = _settings()
    text = (
        '{"insufficient_data": true, "direction": "long", "entry": 99.5, "stop_loss": 98.0, '
        '"take_profit": 103.0, "support_resistance": [], "note": "мало данных"}'
    )
    with patch("app.ai_assistant.requests.post", return_value=_fake_ai_text_response(text)):
        result = generate_chart_annotation("BTCUSDT", "context", 100.0, settings)
    assert result is None
    print("OK: insufficient_data=true returns None even though every other field looks populated -- "
          "the model can't hedge AND hallucinate numbers at the same time.")


# ---------------------------------------------------------------------
# 4. Wrong-side stop-loss (and take-profit) rejected
# ---------------------------------------------------------------------

def test_wrong_side_stop_loss_rejected_for_long():
    settings = _settings()
    # direction=long but stop_loss is ABOVE entry -- backwards.
    text = (
        '{"insufficient_data": false, "direction": "long", "entry": 99.5, "stop_loss": 101.0, '
        '"take_profit": 103.0, "support_resistance": [], "note": "x"}'
    )
    with patch("app.ai_assistant.requests.post", return_value=_fake_ai_text_response(text)):
        result = generate_chart_annotation("BTCUSDT", "context", 100.0, settings)
    assert result is None
    print("OK: a long with a stop-loss ABOVE entry (wrong side) is rejected.")


def test_wrong_side_take_profit_rejected_for_short():
    settings = _settings()
    # direction=short but take_profit is ABOVE entry -- backwards.
    text = (
        '{"insufficient_data": false, "direction": "short", "entry": 100.5, "stop_loss": 102.0, '
        '"take_profit": 103.0, "support_resistance": [], "note": "x"}'
    )
    with patch("app.ai_assistant.requests.post", return_value=_fake_ai_text_response(text)):
        result = generate_chart_annotation("BTCUSDT", "context", 100.0, settings)
    assert result is None
    print("OK: a short with a take-profit ABOVE entry (wrong side) is rejected.")


# ---------------------------------------------------------------------
# 5. Wildly-out-of-range price rejected
# ---------------------------------------------------------------------

def test_wildly_out_of_range_entry_rejected():
    settings = _settings()
    # current_price is 100, but entry is 5000 -- 50x off, a plausible
    # "hallucinated wrong symbol / wrong decimal place" failure mode.
    text = (
        '{"insufficient_data": false, "direction": "long", "entry": 5000.0, "stop_loss": 4900.0, '
        '"take_profit": 5200.0, "support_resistance": [], "note": "x"}'
    )
    with patch("app.ai_assistant.requests.post", return_value=_fake_ai_text_response(text)):
        result = generate_chart_annotation("BTCUSDT", "context", 100.0, settings)
    assert result is None
    print("OK: a hallucinated entry 50x away from the real current price is rejected.")


def test_nan_and_infinite_and_bool_numbers_rejected():
    settings = _settings()
    for bad_entry_json in ('NaN', 'Infinity', 'true', '"99.5"'):
        text = (
            '{"insufficient_data": false, "direction": "long", "entry": %s, "stop_loss": 98.0, '
            '"take_profit": 103.0, "support_resistance": [], "note": "x"}'
        ) % bad_entry_json
        with patch("app.ai_assistant.requests.post", return_value=_fake_ai_text_response(text)):
            result = generate_chart_annotation("BTCUSDT", "context", 100.0, settings)
        assert result is None, f"expected None for entry={bad_entry_json!r}"
    print("OK: NaN/Infinity/bool/string values for a numeric field are all rejected (Python's json "
          "module accepts NaN/Infinity literals by default -- these must still be caught).")


def test_call_ai_failure_returns_none():
    """No key configured at all -- generate_chart_annotation must degrade
    to None without ever attempting a network call, same contract as
    every other function in this module."""
    settings = _settings(anthropic_api_key="")
    with patch("app.ai_assistant.requests.post") as mock_post:
        result = generate_chart_annotation("BTCUSDT", "context", 100.0, settings)
    assert result is None
    mock_post.assert_not_called()
    print("OK: with no AI key configured, generate_chart_annotation() returns None without making "
          "any network call.")


# ---------------------------------------------------------------------
# 6-8. render_ai_annotated_chart() -- always renders a valid PNG, real
#      layer always drawn, AI layer only when given, never crashes.
# ---------------------------------------------------------------------

def test_render_real_zones_only_produces_valid_png_when_ai_annotation_none():
    df = _fake_klines()
    zones = [_pending_zone()]
    png = chart.render_ai_annotated_chart(
        df=df, symbol_label="BTC", timeframe="15m", real_zones=zones,
        real_entry=100.0, real_stop=98.0, real_take=105.0, ai_annotation=None,
    )
    assert isinstance(png, bytes) and png[:8] == PNG_MAGIC
    print("OK: with ai_annotation=None, render_ai_annotated_chart() still produces a valid PNG "
          "showing only the real bot zones/levels.")


def test_render_with_both_layers_produces_valid_png():
    df = _fake_klines()
    zones = [_pending_zone(), _pending_zone(direction="short", bottom=104.0, top=105.0)]
    ai_annotation = {
        "direction": "long", "entry": 99.5, "stop_loss": 98.0, "take_profit": 103.0,
        "support_resistance": [{"price": 102.0, "kind": "resistance", "label": "прошлый хай"}],
        "note": "гипотеза",
    }
    png = chart.render_ai_annotated_chart(
        df=df, symbol_label="BTC", timeframe="15m", real_zones=zones,
        real_entry=100.0, real_stop=98.5, real_take=104.0, ai_annotation=ai_annotation,
    )
    assert isinstance(png, bytes) and png[:8] == PNG_MAGIC
    print("OK: with a valid ai_annotation given alongside real zones/levels, render_ai_annotated_chart() "
          "produces a valid PNG with both layers drawn.")


def test_render_never_crashes_with_no_real_zones_and_no_ai_annotation():
    """The minimal, most-degraded case: no armed zones for this symbol, no
    active signal, and no AI hypothesis available either -- must still
    render a plain candles-only chart, not crash."""
    df = _fake_klines()
    png = chart.render_ai_annotated_chart(
        df=df, symbol_label="BTC", timeframe="15m", real_zones=None,
        real_entry=None, real_stop=None, real_take=None, ai_annotation=None,
    )
    assert isinstance(png, bytes) and png[:8] == PNG_MAGIC
    print("OK: with no real zones, no real entry/stop/take, and no AI annotation, "
          "render_ai_annotated_chart() still renders a valid (candles-only) PNG without crashing.")


def test_render_never_crashes_with_malformed_zone_objects():
    """A zone-like object missing expected attributes must be skipped, not
    crash the whole chart -- the real-zone layer must never be corrupted
    or blocked by one bad entry."""
    df = _fake_klines()

    class _BrokenZone:
        pass

    png = chart.render_ai_annotated_chart(
        df=df, symbol_label="BTC", timeframe="15m", real_zones=[_BrokenZone(), _pending_zone()],
        real_entry=100.0, ai_annotation=None,
    )
    assert isinstance(png, bytes) and png[:8] == PNG_MAGIC
    print("OK: a malformed zone object in real_zones is skipped rather than crashing the chart.")


# ---------------------------------------------------------------------
# 9. The command handler is the ONLY caller of generate_chart_annotation
#    -- never a poll loop.
# ---------------------------------------------------------------------

def test_generate_chart_annotation_only_called_from_command_handler_source():
    """Source-level guard against a future regression: generate_chart_
    annotation must be called from exactly one place in main.py --
    _handle_aichart_command -- and never from a background poll loop
    (_autopilot_worker, _maybe_publish_health, _maybe_check_psycho_alerts,
    etc). This matches app/ai_assistant.py's own module docstring
    ("every function here is called ONLY on-demand ... NEVER from a poll
    loop") and this project's explicit round-18 cost-discipline
    requirement."""
    main_py = (Path(__file__).resolve().parent.parent / "main.py").read_text(encoding="utf-8")

    # A real invocation is NOT immediately preceded by "." -- the only
    # other mention of this name in the file is a docstring's module-path
    # style reference ("app/ai_assistant.generate_chart_annotation()"),
    # which this excludes.
    needle = "generate_chart_annotation("
    call_sites = []
    start = 0
    while True:
        idx = main_py.find(needle, start)
        if idx == -1:
            break
        if idx == 0 or main_py[idx - 1] != ".":
            call_sites.append(idx)
        start = idx + 1
    assert len(call_sites) == 1, f"expected exactly 1 real call site, found {len(call_sites)}"

    call_index = call_sites[0]
    handler_start = main_py.index("def _handle_aichart_command(")
    next_def = main_py.index("\ndef ", handler_start + 1)
    assert handler_start < call_index < next_def, (
        "generate_chart_annotation( must be called from inside _handle_aichart_command, "
        "not from a poll loop or any other function"
    )

    # Belt-and-suspenders: confirm it's genuinely absent from the two
    # known background-poll functions by name, in case either is ever
    # refactored to span a wider byte range than expected above.
    for poll_fn in ("_autopilot_worker", "_maybe_publish_health", "_maybe_check_psycho_alerts",
                    "_maybe_publish_position_charts"):
        fn_start = main_py.index(f"def {poll_fn}(")
        fn_end = main_py.index("\ndef ", fn_start + 1)
        assert "generate_chart_annotation(" not in main_py[fn_start:fn_end], (
            f"{poll_fn} must never call generate_chart_annotation -- AI calls are on-demand only"
        )
    print("OK: generate_chart_annotation() is called from exactly one place in main.py -- inside "
          "_handle_aichart_command -- and never from any poll-loop function.")


def test_aichart_command_dispatches_from_slash_command():
    import main
    telegram = MagicMock()
    access = MagicMock()
    access.is_owner.return_value = True
    scan = MagicMock()
    settings = _settings()
    state = MagicMock()

    with patch("main._handle_aichart_command") as mock_handler:
        main._handle_access_message(
            telegram, access, scan, settings, state,
            {"chat": {"id": "555"}, "text": "/aichart BTCUSDT", "from": {"username": "ruslan"}, "message_id": 1},
        )
    mock_handler.assert_called_once_with(telegram, "555", "/aichart BTCUSDT", settings, state)
    print("OK: '/aichart BTCUSDT' dispatches to _handle_aichart_command with the exact expected arguments.")


def test_aichart_handler_falls_back_gracefully_when_ai_not_configured():
    """No AI key configured -- must still send a chart (real zones only)
    plus a plain-text explanation, never block on the missing AI layer."""
    import main
    telegram = MagicMock()
    settings = _settings()
    state = MagicMock()
    state.all_pending_zones.return_value = [_pending_zone()]
    state.latest_active_signal.return_value = None

    with patch("main.get_last_price", return_value=100.0), \
         patch("main.get_klines", return_value=_fake_klines()), \
         patch("main.resolve_api_key", return_value=""), \
         patch("main.generate_chart_annotation") as mock_generate, \
         patch("main.chart.render_ai_annotated_chart", return_value=b"\x89PNGfake") as mock_render:
        main._handle_aichart_command(telegram, "555", "/aichart BTCUSDT", settings, state)

    mock_generate.assert_not_called()
    render_kwargs = mock_render.call_args.kwargs
    assert render_kwargs["ai_annotation"] is None
    assert len(render_kwargs["real_zones"]) == 1
    telegram.send_photo.assert_called_once()
    caption = telegram.send_photo.call_args[0][1]
    assert "не настроен" in caption
    print("OK: with no AI key configured, /aichart sends a real-zones-only chart plus a plain-text "
          "note, and never calls generate_chart_annotation at all.")


def test_aichart_handler_falls_back_gracefully_when_annotation_invalid():
    """AI IS configured but returns nothing usable (None, e.g. failed
    validation) -- must still send the real-zones-only chart, never crash
    or block on it."""
    import main
    telegram = MagicMock()
    settings = _settings()
    state = MagicMock()
    state.all_pending_zones.return_value = []
    state.latest_active_signal.return_value = None

    with patch("main.get_last_price", return_value=100.0), \
         patch("main.get_klines", return_value=_fake_klines()), \
         patch("main.resolve_api_key", return_value="sk-test"), \
         patch("main.generate_chart_annotation", return_value=None) as mock_generate, \
         patch("main.chart.render_ai_annotated_chart", return_value=b"\x89PNGfake") as mock_render:
        main._handle_aichart_command(telegram, "555", "/aichart BTCUSDT", settings, state)

    mock_generate.assert_called_once()
    render_kwargs = mock_render.call_args.kwargs
    assert render_kwargs["ai_annotation"] is None
    telegram.send_photo.assert_called_once()
    caption = telegram.send_photo.call_args[0][1]
    assert "не дал пригодную гипотезу" in caption
    print("OK: when the AI is configured but generate_chart_annotation() returns None, /aichart still "
          "sends the real-zones-only chart with an explanatory note, never crashing or blocking on it.")


def test_aichart_handler_draws_both_layers_when_annotation_valid():
    import main
    telegram = MagicMock()
    settings = _settings()
    state = MagicMock()
    zone = _pending_zone()
    state.all_pending_zones.return_value = [zone]
    state.latest_active_signal.return_value = {"entry": 100.0, "stop_loss": 98.0, "nearest_target": 104.0,
                                                "direction": "long"}
    annotation = {
        "direction": "long", "entry": 99.5, "stop_loss": 98.2, "take_profit": 103.0,
        "support_resistance": [], "note": "гипотеза",
    }

    with patch("main.get_last_price", return_value=100.0), \
         patch("main.get_klines", return_value=_fake_klines()), \
         patch("main.resolve_api_key", return_value="sk-test"), \
         patch("main.generate_chart_annotation", return_value=annotation), \
         patch("main.chart.render_ai_annotated_chart", return_value=b"\x89PNGfake") as mock_render:
        main._handle_aichart_command(telegram, "555", "/aichart BTCUSDT", settings, state)

    render_kwargs = mock_render.call_args.kwargs
    assert render_kwargs["ai_annotation"] == annotation
    assert render_kwargs["real_entry"] == 100.0
    assert render_kwargs["real_stop"] == 98.0
    assert render_kwargs["real_take"] == 104.0
    caption = telegram.send_photo.call_args[0][1]
    assert "ИИ-гипотеза" in caption
    print("OK: with a valid AI annotation and a real active signal both present, /aichart passes the "
          "real signal's entry/stop/take AND the AI annotation through to the chart renderer, and the "
          "caption clearly flags the AI hypothesis layer.")


def test_aichart_handler_never_calls_trading_guard_or_executor():
    """This feature is purely advisory/visual -- confirm the handler
    module-level imports in main.py don't wire /aichart into
    trading_guard/trade_executor/autopilot in any way (source-level
    check, since the handler itself has no code path to any of those
    modules by construction)."""
    main_py = (Path(__file__).resolve().parent.parent / "main.py").read_text(encoding="utf-8")
    handler_start = main_py.index("def _handle_aichart_command(")
    next_def = main_py.index("\ndef ", handler_start + 1)
    handler_body = main_py[handler_start:next_def]
    # Strip the function's own docstring first -- it deliberately explains
    # in prose that this command never touches trading_guard/trade_executor/
    # autopilot, which would otherwise make a naive substring check on the
    # whole function body false-positive on its own explanation.
    doc_start = handler_body.index('"""')
    doc_end = handler_body.index('"""', doc_start + 3) + 3
    handler_code = handler_body[:doc_start] + handler_body[doc_end:]
    for forbidden in ("trading_guard", "trade_executor", "execute_trade", "autopilot"):
        assert forbidden not in handler_code, f"_handle_aichart_command must never reference {forbidden}"
    print("OK: _handle_aichart_command never references trading_guard/trade_executor/autopilot -- "
          "purely advisory/visual, exactly as required.")


if __name__ == "__main__":
    test_valid_annotation_parses_correctly()
    test_malformed_json_returns_none()
    test_json_missing_required_field_returns_none()
    test_json_wrapped_in_markdown_fence_still_parses()
    test_insufficient_data_true_returns_none_even_with_populated_fields()
    test_wrong_side_stop_loss_rejected_for_long()
    test_wrong_side_take_profit_rejected_for_short()
    test_wildly_out_of_range_entry_rejected()
    test_nan_and_infinite_and_bool_numbers_rejected()
    test_call_ai_failure_returns_none()
    test_render_real_zones_only_produces_valid_png_when_ai_annotation_none()
    test_render_with_both_layers_produces_valid_png()
    test_render_never_crashes_with_no_real_zones_and_no_ai_annotation()
    test_render_never_crashes_with_malformed_zone_objects()
    test_generate_chart_annotation_only_called_from_command_handler_source()
    test_aichart_command_dispatches_from_slash_command()
    test_aichart_handler_falls_back_gracefully_when_ai_not_configured()
    test_aichart_handler_falls_back_gracefully_when_annotation_invalid()
    test_aichart_handler_draws_both_layers_when_annotation_valid()
    test_aichart_handler_never_calls_trading_guard_or_executor()
    print("\nAll round-18 /aichart checks passed.")
