#!/usr/bin/env python3
"""
Combines the three highest-priority "genuinely new" candidates from
next-gen-indicator-research doc into one signal and tests it with an
ABLATION (each filter's incremental contribution reported separately, not
just one black-box combined number -- same discipline as
exit_variant_sweep.py's variant sweep):

  1. CORE SIGNAL (new mechanism family): `squeeze_momentum_breakout.py` --
     LazyBear's Squeeze Momentum (BB-inside-KC squeeze release). Buys
     volatility EXPANSION, unlike every mean-reversion module already
     tested in this project.
  2. SESSION FILTER (new dimension: time, not price): only allow signals
     whose UTC hour falls in the London/NY overlap killzone (default
     12:00-16:00 UTC -- a commonly cited ICT overlap window; DST is NOT
     modeled, this is a fixed UTC-hour approximation, flagged as such).
  3. FUNDING/OI FILTER (new data source: crypto derivatives positioning,
     not price-derived TA): vetoes a breakout signal when it points in
     the SAME direction as an already-crowded trade -- extreme funding
     rate (z-score beyond +/-`--funding-z-thresh` over the recent window)
     combined with rising open interest (`--oi-change-thresh` over
     `--oi-lookback` bars) in that direction. Research (Presto Research,
     BIS WP1087 -- see next-gen-indicator-research doc) found funding
     rate has little standalone single-asset predictive power, which is
     exactly why this is wired as a VETO/confluence filter on top of a
     real entry signal, not a standalone trigger.

Ablation variants tested, each independently:
  - baseline           : squeeze breakout alone, no filters
  - +session            : squeeze breakout + killzone time filter only
  - +funding_oi         : squeeze breakout + funding/OI veto only
  - +both               : squeeze breakout + both filters

This tells you which piece (if any) is actually pulling weight, rather
than reporting one combined number that could hide a filter that's doing
nothing (or hurting).

Needs Bybit network access -- run on your own machine. Uses BOTH
`fetch_history` (klines) AND the new `app/derivatives_data.py`
(funding rate + open interest) -- run
`python app/derivatives_data.py --symbol ETHUSDT --smoke-test` FIRST if
you haven't already, to confirm those two endpoints actually return data
in the shape this script expects (they were written against Bybit's
documented API but never exercised against a live response -- this
sandbox has no outbound network access to verify).

    python next_gen_combo.py --bars 3000
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np
import pandas as pd

from app.config import Settings
from app.data import DataError
from app.derivatives_data import align_funding_to_bars, align_oi_to_bars, \
    fetch_funding_rate_history, fetch_open_interest_history
from app.indicators.squeeze_momentum_breakout import generate_signals as generate_breakout_signals
from generic_backtest import fetch_history, save_csv, simulate_outcome, summarize

VARIANTS = ["baseline", "+session", "+funding_oi", "+both"]


def compute_session_ok(times: pd.Series, start_hour: int, end_hour: int) -> np.ndarray:
    hours = times.dt.hour.to_numpy()
    if start_hour <= end_hour:
        return (hours >= start_hour) & (hours < end_hour)
    return (hours >= start_hour) | (hours < end_hour)  # wraps past midnight UTC


def compute_funding_oi_veto(df: pd.DataFrame, symbol: str, timeframe: str,
                             funding_records: int, oi_records: int,
                             funding_z_thresh: float, oi_lookback: int,
                             oi_change_thresh: float, funding_z_events: int = 90) -> tuple[np.ndarray, np.ndarray]:
    """Returns (crowded_long, crowded_short) boolean arrays aligned to df's
    bars -- True where a long/short signal at that bar should be vetoed
    as already-crowded. On any fetch failure, returns all-False (i.e. the
    filter becomes a no-op rather than silently dropping every signal --
    printed as a warning so it's not mistaken for a real result).

    IMPORTANT: the funding z-score is computed on the raw funding EVENTS
    (funding_df, one row per actual funding settlement -- typically every
    1-8h depending on the symbol), using a rolling window measured in
    events (`funding_z_events`, default 90), THEN forward-filled onto
    bars. Computing it on the already-forward-filled per-bar series
    instead would badly distort the mean/std, since each funding event
    gets duplicated across many 15m bars and would dominate the sample by
    calendar-time-held rather than by actual occurrence."""
    n = len(df)
    try:
        funding_df = fetch_funding_rate_history(symbol, total_records=funding_records)
        oi_df = fetch_open_interest_history(symbol, timeframe, total_records=oi_records)
    except DataError as exc:
        print(f"  [WARN] funding/OI fetch failed for {symbol}: {exc} -- funding_oi filter is a no-op for this symbol.")
        return np.zeros(n, dtype=bool), np.zeros(n, dtype=bool)

    fr_mean = funding_df["funding_rate"].rolling(funding_z_events, min_periods=30).mean()
    fr_std = funding_df["funding_rate"].rolling(funding_z_events, min_periods=30).std(ddof=0).replace(0, np.nan)
    funding_df = funding_df.assign(funding_z=(funding_df["funding_rate"] - fr_mean) / fr_std)

    merged = pd.merge_asof(
        df[["open_time"]].sort_values("open_time"),
        funding_df[["funding_time", "funding_z"]].sort_values("funding_time"),
        left_on="open_time", right_on="funding_time", direction="backward",
    )
    funding_z = merged["funding_z"]
    open_interest = align_oi_to_bars(df, oi_df)
    oi_change = open_interest.pct_change(oi_lookback)

    crowded_long = ((funding_z > funding_z_thresh) & (oi_change > oi_change_thresh)).fillna(False).to_numpy()
    crowded_short = ((funding_z < -funding_z_thresh) & (oi_change > oi_change_thresh)).fillna(False).to_numpy()
    return crowded_long, crowded_short


def filter_signals(signals, session_ok, crowded_long, crowded_short, use_session, use_funding_oi):
    out = []
    for sig in signals:
        i = sig.trigger_index
        if use_session and not session_ok[i]:
            continue
        if use_funding_oi:
            if sig.direction == "long" and crowded_long[i]:
                continue
            if sig.direction == "short" and crowded_short[i]:
                continue
        out.append(sig)
    return out


def main() -> None:
    settings = Settings.load()
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--symbol", nargs="+", default=settings.watchlist)
    parser.add_argument("--timeframe", default=settings.timeframe)
    parser.add_argument("--bars", type=int, default=3000)
    parser.add_argument("--max-forward", type=int, default=200)
    parser.add_argument("--session-start-utc", type=int, default=12, help="Killzone window start hour, UTC")
    parser.add_argument("--session-end-utc", type=int, default=16, help="Killzone window end hour, UTC")
    parser.add_argument("--funding-z-thresh", type=float, default=1.5)
    parser.add_argument("--funding-z-events", type=int, default=90,
                         help="Rolling window, in actual funding EVENTS (not bars), for the funding z-score")
    parser.add_argument("--oi-lookback", type=int, default=20, help="Bars back for OI %% change")
    parser.add_argument("--oi-change-thresh", type=float, default=0.02)
    parser.add_argument("--out", default="generic_backtest_out")
    args = parser.parse_args()

    print(f"Session filter: {args.session_start_utc:02d}:00-{args.session_end_utc:02d}:00 UTC")
    print(f"Funding/OI veto: |z| > {args.funding_z_thresh}, OI change > {args.oi_change_thresh:.1%} "
          f"over {args.oi_lookback} bars\n")

    out_dir = Path(args.out) / "next_gen_combo"
    trades_by_variant: dict[str, list[dict]] = {v: [] for v in VARIANTS}

    for symbol in [s.upper() for s in args.symbol]:
        print(f"Fetching + simulating {symbol} ({args.bars} bars of {args.timeframe})...")
        try:
            df = fetch_history(symbol, args.timeframe, args.bars)
        except DataError as exc:
            print(f"  [SKIP] {symbol}: {exc}")
            continue

        raw_signals = generate_breakout_signals(df)
        session_ok = compute_session_ok(df["open_time"], args.session_start_utc, args.session_end_utc)
        crowded_long, crowded_short = compute_funding_oi_veto(
            df, symbol, args.timeframe, args.bars, args.bars,
            args.funding_z_thresh, args.oi_lookback, args.oi_change_thresh, args.funding_z_events)

        variant_signals = {
            "baseline": raw_signals,
            "+session": filter_signals(raw_signals, session_ok, crowded_long, crowded_short, True, False),
            "+funding_oi": filter_signals(raw_signals, session_ok, crowded_long, crowded_short, False, True),
            "+both": filter_signals(raw_signals, session_ok, crowded_long, crowded_short, True, True),
        }

        for variant, sigs in variant_signals.items():
            trades = []
            for sig in sigs:
                outcome = simulate_outcome(df, sig, args.max_forward)
                trades.append({
                    "symbol": symbol, "label": f"squeeze_{variant}", "direction": sig.direction,
                    "entry": sig.entry, "stop_loss": sig.stop_loss,
                    "synthetic_stop": sig.synthetic_stop, "time": sig.trigger_time,
                    **outcome,
                })
            summarize(trades, f"{symbol} [{variant}]")
            save_csv(trades, out_dir / variant / f"{symbol}_trades.csv")
            trades_by_variant[variant].extend(trades)

    print("\n" + "=" * 78)
    print("ABLATION SUMMARY (combined, all symbols)")
    print("=" * 78)
    for variant in VARIANTS:
        summarize(trades_by_variant[variant], f"=== {variant} ===")

    print("\n" + "=" * 78)
    print("SPLIT-SAMPLE per variant")
    print("=" * 78)
    for variant in VARIANTS:
        trades = trades_by_variant[variant]
        resolved = [t for t in trades if t["r"] is not None]
        if len(resolved) < 20:
            print(f"\n{variant}: only {len(resolved)} resolved trades -- too few to split, skipping.")
            continue
        times = sorted(t["time"] for t in resolved)
        cutoff = times[len(times) // 2]
        early = [t for t in trades if t["time"] < cutoff]
        late = [t for t in trades if t["time"] >= cutoff]
        print(f"\n--- {variant} (split at {cutoff}) ---")
        summarize(early, "Earlier half")
        summarize(late, "Later half")

    print(
        "\nReading this: only treat a variant as a real, worth-pursuing improvement over baseline if "
        "it is net-positive (at maker+maker or better) in BOTH split halves independently, not just on "
        "the combined number -- same discipline as everywhere else in this project. If '+session' or "
        "'+funding_oi' don't change much vs baseline, the filter isn't adding real information here."
    )


if __name__ == "__main__":
    main()
