#!/usr/bin/env python3
"""
Combo OTM v3.2 - Standalone Backtest Runner
===========================================

Hand-ported from strategies/Combo_OTM_v3.2.pine (Pine v6, 1302 lines, 174 KB).

WHY HAND-PORTED: the bulk of the Pine file is drawing code (lines, labels,
boxes, a diagnostics table) and 23 optional entry filters that are ALL OFF by
default. The part that actually trades is small, but it is built on `var`
cross-bar state (streak counters, cooldown bars, loss-pause latch, the
max-favourable-excursion tracker, break-even latch) that no vector translation
survives. This is a direct bar-by-bar re-implementation.

--------------------------------------------------------------------------
WHAT IS PORTED / WHAT IS NOT  - READ THIS BEFORE QUOTING ANY NUMBER
--------------------------------------------------------------------------
PORTED (trading logic):
  * Base signal: ta.pivotlow / ta.pivothigh (left=1, right=2), counter-trend:
    confirmed pivot low -> LONG, confirmed pivot high -> SHORT.
  * Entry only from flat (the Pine guard is `strategy.position_size == 0`,
    so pyramiding never matters and reversals never happen - see PARITY).
  * Fill timing: signal bar -> order -> fill at the NEXT bar's open.
  * Stop: "Fixed %" 2.0% or "ATR Bands" ATR(14)*2 capped at 3%.
  * TP structure "1 TP" (TP2 only, +3%, 100%) and "2 TP" (TP1 +1.5% on 50%,
    then TP2 +3% on the rest). Fixed % and ATR modes for both TPs.
  * Progress Break Even (Fixed % activation, or on TP1 fill in 2 TP mode).
  * Three timer exits: Early Failure, No Progress Stop,
    Maximum Bars Without Progress.
  * Entry Control: cooldown after loss (per side), loss-streak pause,
    consecutive-trades-per-direction limit, per-weekday hourly session
    window including the Pine overnight-carry rule, opposite-signal blocking,
    the "Enable All Entry Filters" master switch, Use First Trade.

FILTERS PORTED (6 of 23, each OFF by default exactly as in the Pine):
    ADX, RSI, CCI, EMA Direction, EMA Slope, NATR.

FILTERS **NOT** PORTED (17) - if you need them, this file is NOT full Combo:
    Trend Catcher, Money Flow (MFI), Extreme Distance, Late Entry,
    Impulse Candle, Volume Spike, ATR Extension From Pivot, CVD, nOI
    (needs open-interest feed), Z-Score vs reference asset (needs a second
    symbol), Choppiness, Williams %R, Relative Volume (MTF request.security),
    Kaufman Efficiency, WaveTrend, Awesome Oscillator, Bollinger Bands.
    In this port each of those is hard-wired to "pass", which is exactly what
    the Pine does while its toggle is false - so the DEFAULT configuration is
    reproduced faithfully. Only non-default runs of those 17 are unavailable.

NOT PORTED (non-trading): every plot/line/label/box, the API diagnostics
    table, and the whole "Shadow Trade Lock" subsystem (shadowLockActive is
    false by default; when off it cannot change a single real order - the
    only way it touches the real path is the `not shadowTradeActive and not
    shadowTradePending` guard on strategy.entry, which is vacuous when the
    lock is off).

--------------------------------------------------------------------------
PARITY NOTES
--------------------------------------------------------------------------
FAITHFUL, LINE FOR LINE:
  - SIGNAL DELAY. ta.pivotlow(low, 1, 2) at bar t describes bar t-2 and is
    only non-na at bar t. `baseCandidateLong` reads it at bar t, so the order
    is placed at bar t and - the Pine has NO process_orders_on_close - fills
    at the OPEN of bar t+1. Net: a pivot low printed on bar p is entered at
    the open of bar p+3. This port reproduces that chain exactly; nothing
    ever reads a value the bar did not yet have.
  - Stop/TP levels are computed on the FILL bar from
    `strategy.position_avg_price` and that bar's ATR, not on the signal bar.
  - The exit orders are placed at the end of the fill bar, so they are live
    from the bar AFTER the fill. The fill bar itself can never stop out.
    (Pine places strategy.exit on the same bar the position opens, but a
    broker order issued during bar N is only workable from bar N+1.)
  - strategy.close() from the three timer exits is a MARKET order: it fills
    at the OPEN of the following bar, and it fills BEFORE that bar's stop /
    limit can trade. Reproduced.
  - MFE (`activeTradeMaximumFavorablePercent`) is updated from the fill bar
    onward (barsInTrade == 0 included) using that bar's high/low against the
    average entry price, and it is what Early Failure / No Progress / Max
    Bars / Break Even all read - all four are transcribed with their Pine
    comparison operators (>= vs <) intact.
  - Break even raises (long) / lowers (short) the stop via math.max/math.min,
    fires once, and in "TP1" mode only in 2 TP structure after TP1 filled.
  - Streak state: longStreak += 1 and shortStreak := 0 on a long fill (and
    mirrored), so `maxConsecutiveLong` counts longs since the last short -
    it is NOT reset by time or by a winning trade. Faithful, including the
    consequence that hitting the cap blocks that side until the other side
    trades.
  - Loss bookkeeping runs off the CLOSED trade's total P&L, exactly like the
    Pine `realPositionAccumulatedProfit` accumulator, so in 2 TP mode a trade
    whose TP1 filled and whose remainder stopped out counts as a loss only if
    the COMBINED result is negative.
  - Loss-streak pause locks BOTH sides at once, resets consecutiveLosses to
    zero when it fires, and each side unlocks on its own bar budget with the
    Pine's `>` (not `>=`) comparison.
  - The session filter reproduces isCurrentDayHourAllowed /
    isPreviousDayOvernightAllowed verbatim, including the special-cases
    (start == end, and 0..24 meaning "all day") and the overnight carry from
    the previous weekday.
  - `enableAllEntryFilters` (default TRUE) gates Entry Control and the
    quality filters together, as in the Pine.

SIMPLIFIED / DELIBERATELY DIFFERENT - each of these is a judgement call:
  - INTRABAR AMBIGUITY: when one bar touches both the stop and a take
    profit, this port always takes the STOP. It cannot be resolved from OHLC.
    NOTE: the Pine's own shadow-trade simulator guesses instead, with
    `shadowHighFirst = math.abs(open - high) <= math.abs(open - low)`. That
    heuristic is NOT used here; the pessimistic rule is used for every trade,
    so these specific bars are a lower bound on the equity curve.
  - 2 TP ACCOUNTING. In 2 TP mode the Pine leaves TWO strategy.exit orders
    live from one entry: "Long TP1" (stop + limit, qty_percent=50) and
    "Long TP2" (stop + limit, no qty => the whole remaining position). Both
    carry the SAME stop price. What that means in practice: TP1 takes 50% off
    at +1.5%, and from then on the TP2 order alone governs the remainder -
    a stop fill closes 100% of whatever is left, never 50%. So a trade can
    end as (a) stop on the full size, (b) TP1 then stop on the rest, (c) TP1
    then TP2, (d) TP2 straight on full size (the TP1 limit is skipped only if
    the bar gapped through both, in which case the Pine marks TP1 filled too
    - reproduced). It also means the qty_percent=50 exit is re-placed on
    every bar until it fills, which is a no-op re-issue, not a second lot.
    ONE CSV ROW IS WRITTEN PER POSITION, with gross_pnl_pct = the
    size-weighted blend of the legs (0.5*TP1 leg + 0.5*final leg by default),
    minus one round-trip commission on the full notional. `reason` names how
    the LAST leg closed, so a "stop_loss" row in 2 TP mode may still be
    profitable if TP1 had filled. The alternative - two rows per trade -
    would break the project analyzer's per-deal statistics.
  - Timer-exit priority: Early Failure, No Progress and Max Bars Without
    Progress can all trigger on the same bar and the Pine issues three
    strategy.close() calls with the same id - which collapse into one order
    whose comment is undefined. This port takes the FIRST one in the Pine's
    own evaluation order (early_failure -> no_progress ->
    max_bars_no_progress) and records that as `reason`.
  - `reason` value "opposite_signal" exists for schema compatibility but is
    NEVER emitted: the Pine gate `strategy.position_size == 0` on both
    strategy.entry calls means an opposite signal is simply dropped while a
    position is open, it does not reverse. (The separate
    "Block Opposite Signals While Position Open" input is therefore almost a
    no-op in the default configuration; it is ported anyway.)
  - ta.pivothigh/ta.pivotlow are implemented as STRICTLY greater/less than
    every bar in the left and right windows. Pine's exact tie handling is
    unpublished; exact ties are rare on real prices but common on rounded or
    synthetic data.
  - dayofweek / hour come from the UTC index of the data. Pine evaluates them
    in the chart's exchange timezone. For a 24/7 crypto perp on UTC data this
    matches; it will not match a TradingView chart set to another timezone.
  - `useFirstTrade` is ported as --first-trade; the Pine default is off.
  - Slippage is applied to the FILL price only. Stop/TP levels stay derived
    from the raw open, exactly as Pine derives them from
    strategy.position_avg_price with zero slippage, so changing --slippage-pct
    changes the P&L of the trades but not WHICH trades are taken.
  - The Pine sets commission_value = 0.055 (Bybit taker). Kept as the
    default, charged as a round trip inside gross_pnl_pct.
  - ta.rma / ta.ema / ta.rsi / ta.cci / ta.atr are re-implemented with Pine's
    SMA seeding, so the first `length` bars match TradingView rather than
    pandas' adjust=True warm-up.
  - A position still open on the last bar is dropped, not marked to market -
    same as the other ports in this folder.

USAGE
    python combo_otm_backtest.py --symbol BTC/USDT --timeframe 1h \
        --start 2023-01-01 --end 2025-12-31 --out backtest_out_combo
    python combo_otm_backtest.py --csv synth.csv --tp-structure "2 TP"
    python combo_otm_backtest.py --csv synth.csv --use-adx --adx-long-min 20

Output: <out>/<SYMBOL>_deals.csv
        (entry_time, exit_time, side, entry_price, exit_price,
         gross_pnl_pct, reason)  - read by analyze_external_strategies.py
        plus <out>/_run.json, the manifest of EFFECTIVE run conditions.
"""

from __future__ import annotations

import argparse
import datetime as _dt
import json as _json
from pathlib import Path

import numpy as np
import pandas as pd

# ============================================================================
# CONFIG - every value is the Pine input's own default
# ============================================================================

CONFIG = {
    # --- Base Settings ---
    "enable_all_entry_filters": True,   # Pine: input.bool(true)
    "use_first_trade": False,
    "first_trade": "2024-09-01T00:00:00",
    "pivot_left_bars": 1,
    "pivot_right_bars": 2,
    "tp_structure": "1 TP",             # "1 TP" | "2 TP"

    # --- Risk (the Pine has separate long/short blocks with identical
    #     defaults; this port exposes one set per side) ---
    "long_sl_mode": "Fixed %",          # "Fixed %" | "ATR Bands"
    "long_sl_pct": 2.0,
    "long_atr_length": 14,
    "long_atr_mult": 2.0,
    "long_atr_max_stop_pct": 3.0,
    "long_tp_atr_length": 14,
    "long_tp1_mode": "Fixed %",         # "Fixed %" | "ATR"
    "long_tp1_pct": 1.5,
    "long_tp1_atr_mult": 1.5,
    "long_tp1_atr_max_pct": 3.0,
    "long_tp1_position_pct": 50.0,
    "long_tp2_mode": "Fixed %",
    "long_tp2_pct": 3.0,
    "long_tp2_atr_mult": 3.0,
    "long_tp2_atr_max_pct": 3.0,

    "short_sl_mode": "Fixed %",
    "short_sl_pct": 2.0,
    "short_atr_length": 14,
    "short_atr_mult": 2.0,
    "short_atr_max_stop_pct": 3.0,
    "short_tp_atr_length": 14,
    "short_tp1_mode": "Fixed %",
    "short_tp1_pct": 1.5,
    "short_tp1_atr_mult": 1.5,
    "short_tp1_atr_max_pct": 3.0,
    "short_tp1_position_pct": 50.0,
    "short_tp2_mode": "Fixed %",
    "short_tp2_pct": 3.0,
    "short_tp2_atr_mult": 3.0,
    "short_tp2_atr_max_pct": 3.0,

    # --- Entry Control: Cooldown & Streak ---
    "cooldown_after_loss_long": False,
    "cooldown_bars_long": 1,
    "cooldown_after_loss_short": False,
    "cooldown_bars_short": 1,
    "loss_streak_pause": False,
    "losses_before_pause": 3,
    "loss_pause_bars_long": 5,
    "loss_pause_bars_short": 5,
    "streak_control_long": False,
    "streak_control_short": False,
    "max_consecutive_long": 3,
    "max_consecutive_short": 3,
    "block_opposite_signals": False,

    # --- Trade management (all three timers OFF by default in the Pine) ---
    "early_failure_long": False,
    "early_failure_short": False,
    "early_failure_bars_long": 4,
    "early_failure_bars_short": 4,
    "early_failure_min_move_long": 0.5,
    "early_failure_min_move_short": 0.5,

    "no_progress_long": False,
    "no_progress_short": False,
    "no_progress_max_fav_long": 0.3,
    "no_progress_max_fav_short": 0.3,
    "no_progress_adverse_long": 0.8,
    "no_progress_adverse_short": 0.8,

    "max_bars_no_progress_long": False,
    "max_bars_no_progress_short": False,
    "max_bars_long": 6,
    "max_bars_short": 6,
    "required_progress_long": 0.5,
    "required_progress_short": 0.5,

    "break_even_long": False,
    "break_even_short": False,
    "break_even_mode_long": "Fixed %",   # "Fixed %" | "TP1"
    "break_even_mode_short": "Fixed %",
    "break_even_activation_long": 0.7,
    "break_even_activation_short": 0.7,
    "break_even_offset_long": 0.0,
    "break_even_offset_short": 0.0,

    # --- Session: Monday..Sunday, (enabled, start_hour, end_hour) ---
    "session": {
        0: (True, 0, 24), 1: (True, 0, 24), 2: (True, 0, 24), 3: (True, 0, 24),
        4: (True, 0, 24), 5: (True, 0, 24), 6: (True, 0, 24),
    },

    # --- The 6 ported filters (all OFF, Pine defaults for the thresholds) ---
    "use_adx": False,
    "adx_length_long": 14, "adx_length_short": 14,
    "adx_long_min": 5.0, "adx_long_max": 80.0,
    "adx_short_min": 5.0, "adx_short_max": 80.0,

    "use_rsi": False,
    "rsi_length": 15,
    "rsi_long_block_above": 100.0, "rsi_long_block_below": 40.0,
    "rsi_short_block_above": 60.0, "rsi_short_block_below": 0.0,

    "use_cci": False,
    "cci_length": 20,
    "cci_long_block_above": 500.0, "cci_long_block_below": -500.0,
    "cci_short_block_above": 500.0, "cci_short_block_below": -500.0,

    "use_ema_direction": False,
    "ema_direction_length_long": 144, "ema_direction_length_short": 144,

    "use_ema_slope": False,
    "ema_slope_length_long": 144, "ema_slope_length_short": 144,
    "ema_slope_lookback_long": 5, "ema_slope_lookback_short": 5,
    "ema_slope_min_long": 0.001, "ema_slope_min_short": 0.001,

    "use_natr": False,
    "natr_length": 14,
    "natr_long_min": 0.0, "natr_long_max": 20.0,
    "natr_short_min": 0.0, "natr_short_max": 20.0,
}

DAY_NAMES = ["mon", "tue", "wed", "thu", "fri", "sat", "sun"]


# ============================================================================
# PINE TA PRIMITIVES
# Pine seeds ta.rma and ta.ema with an SMA of the first `length` values; the
# naive pandas ewm does not. The warm-up matters for ATR-based stops, so it is
# reproduced.
# ============================================================================

def _sma(x: np.ndarray, n: int) -> np.ndarray:
    return pd.Series(x).rolling(n).mean().to_numpy()


def _seeded_smooth(x: np.ndarray, n: int, alpha: float) -> np.ndarray:
    out = np.full(len(x), np.nan)
    if len(x) < n:
        return out
    start = None
    for i in range(n - 1, len(x)):
        if not np.isnan(x[i - n + 1:i + 1]).any():
            start = i
            break
    if start is None:
        return out
    out[start] = float(np.mean(x[start - n + 1:start + 1]))
    for i in range(start + 1, len(x)):
        v = x[i]
        out[i] = out[i - 1] if np.isnan(v) else alpha * v + (1 - alpha) * out[i - 1]
    return out


def _rma(x: np.ndarray, n: int) -> np.ndarray:
    """ta.rma: Wilder smoothing, seeded with the SMA of the first n values."""
    return _seeded_smooth(x, n, 1.0 / n)


def _ema(x: np.ndarray, n: int) -> np.ndarray:
    """ta.ema: alpha = 2/(n+1), seeded with the SMA of the first n values."""
    return _seeded_smooth(x, n, 2.0 / (n + 1.0))


def _true_range(h, l, c) -> np.ndarray:
    tr = np.empty(len(c))
    tr[0] = h[0] - l[0]                       # Pine's ta.tr on bar 0
    prev = c[:-1]
    tr[1:] = np.maximum(h[1:] - l[1:],
                        np.maximum(np.abs(h[1:] - prev), np.abs(l[1:] - prev)))
    return tr


def _atr(h, l, c, n: int) -> np.ndarray:
    return _rma(_true_range(h, l, c), n)


def _rsi(src: np.ndarray, n: int) -> np.ndarray:
    d = np.diff(src)
    up = np.maximum(d, 0.0)
    dn = np.maximum(-d, 0.0)
    ru = np.concatenate([[np.nan], _rma(up, n)])
    rd = np.concatenate([[np.nan], _rma(dn, n)])
    with np.errstate(divide="ignore", invalid="ignore"):
        rs = ru / rd
        out = 100.0 - 100.0 / (1.0 + rs)
    out = np.where(rd == 0, 100.0, out)
    out = np.where(ru == 0, 0.0, out)
    return out


def _cci(src: np.ndarray, n: int) -> np.ndarray:
    s = pd.Series(src)
    ma = s.rolling(n).mean()
    md = s.rolling(n).apply(lambda w: np.abs(w - w.mean()).mean(), raw=True)
    with np.errstate(divide="ignore", invalid="ignore"):
        out = (s - ma) / (0.015 * md)
    return out.to_numpy()


def _adx(h, l, c, n: int) -> np.ndarray:
    """Transcribed from the Pine calcADX() helper (lines 414-426)."""
    up_move = np.diff(h, prepend=np.nan)
    down_move = -np.diff(l, prepend=np.nan)
    plus_dm = np.where((up_move > down_move) & (up_move > 0), up_move, 0.0)
    minus_dm = np.where((down_move > up_move) & (down_move > 0), down_move, 0.0)
    plus_dm[0] = minus_dm[0] = 0.0
    tr = _true_range(h, l, c)
    tr_s, p_s, m_s = _rma(tr, n), _rma(plus_dm, n), _rma(minus_dm, n)
    with np.errstate(divide="ignore", invalid="ignore"):
        plus_di = 100.0 * p_s / tr_s
        minus_di = 100.0 * m_s / tr_s
        dx = 100.0 * np.abs(plus_di - minus_di) / (plus_di + minus_di)
    return _rma(dx, n)


def pivot_flags(high: np.ndarray, low: np.ndarray, left: int, right: int):
    """ta.pivothigh(high, left, right) / ta.pivotlow(low, left, right).

    Returns boolean arrays indexed by the PIVOT bar. Pine only makes the value
    visible `right` bars later; the caller applies that shift.
    STRICT comparison on both sides - see PARITY NOTES on ties.
    """
    n = len(high)
    is_ph = np.zeros(n, dtype=bool)
    is_pl = np.zeros(n, dtype=bool)
    for p in range(left, n - right):
        hv, lv = high[p], low[p]
        ok_h = ok_l = True
        for k in range(p - left, p + right + 1):
            if k == p:
                continue
            if high[k] >= hv:
                ok_h = False
            if low[k] <= lv:
                ok_l = False
            if not ok_h and not ok_l:
                break
        is_ph[p] = ok_h
        is_pl[p] = ok_l
    return is_ph, is_pl


# ============================================================================
# FILTER FRAMEWORK
# A filter is one function (df, cfg) -> (pass_long, pass_short) as boolean
# arrays over the bars, registered here. Adding a filter = writing one
# function + one registry entry + one CLI flag. Every filter defaults to OFF,
# exactly like its Pine toggle, and returns all-True when off.
# ============================================================================

FILTERS = {}


def register_filter(name, flag_key):
    def deco(fn):
        FILTERS[name] = (flag_key, fn)
        return fn
    return deco


def _all_true(n):
    t = np.ones(n, dtype=bool)
    return t, t.copy()


@register_filter("adx", "use_adx")
def filter_adx(df, cfg):
    """Pine: adxConditionLong = not active or (adx >= min and adx <= max)."""
    h, l, c = df["high"].to_numpy(), df["low"].to_numpy(), df["close"].to_numpy()
    al = _adx(h, l, c, cfg["adx_length_long"])
    ash = _adx(h, l, c, cfg["adx_length_short"])
    pl = (al >= cfg["adx_long_min"]) & (al <= cfg["adx_long_max"])
    ps = (ash >= cfg["adx_short_min"]) & (ash <= cfg["adx_short_max"])
    # na compares false in Pine -> a na ADX blocks the entry while the filter
    # is on. numpy comparisons on nan already give False, so this matches.
    return pl, ps


@register_filter("rsi", "use_rsi")
def filter_rsi(df, cfg):
    """Pine: rsiConditionLong = not useRSIFilter or (rsi <= gt_th and rsi >= lt_th).
    Note the Pine naming is inverted from what it does: `rsiL_gt_th` is an
    UPPER bound (block LONG if RSI above it) and `rsiL_lt_th` a LOWER bound."""
    v = _rsi(df["close"].to_numpy(), cfg["rsi_length"])
    pl = (v <= cfg["rsi_long_block_above"]) & (v >= cfg["rsi_long_block_below"])
    ps = (v <= cfg["rsi_short_block_above"]) & (v >= cfg["rsi_short_block_below"])
    return pl, ps


@register_filter("cci", "use_cci")
def filter_cci(df, cfg):
    """Pine source for CCI is hlc3, not close."""
    hlc3 = (df["high"] + df["low"] + df["close"]).to_numpy() / 3.0
    v = _cci(hlc3, cfg["cci_length"])
    pl = (v <= cfg["cci_long_block_above"]) & (v >= cfg["cci_long_block_below"])
    ps = (v <= cfg["cci_short_block_above"]) & (v >= cfg["cci_short_block_below"])
    return pl, ps


@register_filter("ema_direction", "use_ema_direction")
def filter_ema_direction(df, cfg):
    """Pine: close >= ema (long) / close <= ema (short)."""
    c = df["close"].to_numpy()
    el = _ema(c, cfg["ema_direction_length_long"])
    es = _ema(c, cfg["ema_direction_length_short"])
    return (c >= el), (c <= es)


@register_filter("ema_slope", "use_ema_slope")
def filter_ema_slope(df, cfg):
    """Pine: slope% over `lookback` bars >= min (long) / <= -min (short)."""
    c = df["close"].to_numpy()
    n = len(c)
    el = _ema(c, cfg["ema_slope_length_long"])
    es = _ema(c, cfg["ema_slope_length_short"])
    kl, ks = cfg["ema_slope_lookback_long"], cfg["ema_slope_lookback_short"]

    def slope_pct(e, k):
        if k >= n:
            return np.full(n, np.nan)
        base = np.concatenate([np.full(k, np.nan), e[:-k]])
        with np.errstate(divide="ignore", invalid="ignore"):
            return np.where((~np.isnan(base)) & (base != 0.0),
                            (e - base) / base * 100.0, np.nan)

    sl, ss = slope_pct(el, kl), slope_pct(es, ks)
    return (sl >= cfg["ema_slope_min_long"]), (ss <= -cfg["ema_slope_min_short"])


@register_filter("natr", "use_natr")
def filter_natr(df, cfg):
    """Pine: natr = 100 * atr(len) / close, inside [min, max]."""
    h, l, c = df["high"].to_numpy(), df["low"].to_numpy(), df["close"].to_numpy()
    with np.errstate(divide="ignore", invalid="ignore"):
        v = 100.0 * _atr(h, l, c, cfg["natr_length"]) / c
    pl = (v >= cfg["natr_long_min"]) & (v <= cfg["natr_long_max"])
    ps = (v >= cfg["natr_short_min"]) & (v <= cfg["natr_short_max"])
    return pl, ps


def build_quality_conditions(df, cfg):
    """AND of every ENABLED ported filter. Disabled -> all True, which is what
    the Pine's `not active or ...` produces. The 17 unported filters are
    likewise all-True, i.e. their Pine default state."""
    n = len(df)
    ql, qs = _all_true(n)
    active = []
    for name, (flag, fn) in FILTERS.items():
        if not cfg.get(flag, False):
            continue
        pl, ps = fn(df, cfg)
        ql = ql & np.nan_to_num(pl, nan=False).astype(bool)
        qs = qs & np.nan_to_num(ps, nan=False).astype(bool)
        active.append(name)
    return ql, qs, active


# ============================================================================
# SESSION (Pine lines 632-645)
# ============================================================================

def _current_day_hour_allowed(enabled, start_h, end_h, hour):
    if not enabled:
        return False
    if start_h == end_h or (start_h == 0 and end_h == 24):
        return True
    if start_h < end_h:
        return start_h <= hour < end_h
    return hour >= start_h            # start > end: the evening leg


def _prev_day_overnight_allowed(enabled, start_h, end_h, hour):
    return bool(enabled and start_h > end_h and hour < end_h)


def session_allowed(cfg, weekday: int, hour: int) -> bool:
    """weekday: 0 = Monday .. 6 = Sunday (pandas convention)."""
    sess = cfg["session"]
    en, sh, eh = sess[weekday]
    prev = sess[(weekday - 1) % 7]
    return (_current_day_hour_allowed(en, sh, eh, hour)
            or _prev_day_overnight_allowed(prev[0], prev[1], prev[2], hour))


# ============================================================================
# THE BACKTEST
# ============================================================================

def run_backtest(df: pd.DataFrame, cfg: dict = CONFIG,
                 commission_pct: float = 0.055,
                 slippage_pct: float = 0.0) -> pd.DataFrame:
    commission = commission_pct / 100.0
    slip = slippage_pct / 100.0

    o = df["open"].to_numpy(dtype=float)
    h = df["high"].to_numpy(dtype=float)
    l = df["low"].to_numpy(dtype=float)
    c = df["close"].to_numpy(dtype=float)
    idx = df.index
    times = idx.to_numpy()
    n = len(df)

    left, right = cfg["pivot_left_bars"], cfg["pivot_right_bars"]
    is_ph, is_pl = pivot_flags(h, l, left, right)

    # ta.pivotlow(...) is non-na at bar t iff bar t-right was a pivot.
    pivot_low_visible = np.zeros(n, dtype=bool)
    pivot_high_visible = np.zeros(n, dtype=bool)
    if right < n:
        pivot_low_visible[right:] = is_pl[:n - right]
        pivot_high_visible[right:] = is_ph[:n - right]

    atr_sl_long = _atr(h, l, c, cfg["long_atr_length"])
    atr_sl_short = _atr(h, l, c, cfg["short_atr_length"])
    atr_tp_long = _atr(h, l, c, cfg["long_tp_atr_length"])
    atr_tp_short = _atr(h, l, c, cfg["short_tp_atr_length"])

    # longTakeProfitAtrReady: only required when a TP leg actually uses ATR.
    two_tp = cfg["tp_structure"] == "2 TP"
    long_tp_atr_required = (cfg["long_tp2_mode"] == "ATR"
                            or (two_tp and cfg["long_tp1_mode"] == "ATR"))
    short_tp_atr_required = (cfg["short_tp2_mode"] == "ATR"
                             or (two_tp and cfg["short_tp1_mode"] == "ATR"))

    q_long, q_short, _active = build_quality_conditions(df, cfg)

    master = cfg["enable_all_entry_filters"]
    first_trade_ts = pd.Timestamp(cfg["first_trade"]) if cfg["use_first_trade"] else None

    # Intraday? sessionCondition is bypassed on non-intraday timeframes.
    if n > 2:
        step = pd.Series(idx).diff().median()
        intraday = bool(step < pd.Timedelta(days=1))
    else:
        intraday = True

    weekdays = idx.weekday.to_numpy()
    hours = idx.hour.to_numpy()

    # ---------------- Pine `var` state ----------------
    last_long_loss_bar = None
    last_short_loss_bar = None
    long_streak = 0
    short_streak = 0
    consecutive_losses = 0
    loss_pause_long = False
    loss_pause_short = False
    loss_pause_start_bar = None

    position = None          # dict, or None when flat
    pending_entry = None     # ("long"|"short", signal_bar)
    pending_close = None     # (reason, signal_bar)

    deals = []

    def close_position(pos, ts, final_price, reason):
        """Blend the TP1 leg (if it filled) with the final leg, charge one
        round-trip commission on the full notional, and book the result."""
        entry = pos["fill_price"]
        frac = pos["tp1_frac"] if pos["tp1_filled"] else 0.0

        def leg(px):
            if pos["side"] == "long":
                return (px / entry - 1.0) * 100.0
            return (entry / px - 1.0) * 100.0

        pnl = 0.0
        if frac > 0.0:
            pnl += frac * leg(pos["tp1_fill_price"])
        pnl += (1.0 - frac) * leg(final_price)
        pnl -= commission * 200.0

        deals.append({
            "entry_time": pos["entry_time"],
            "exit_time": ts,
            "side": pos["side"],
            "entry_price": entry,
            "exit_price": final_price,
            "gross_pnl_pct": pnl,
            "reason": reason,
        })
        return pnl

    def register_result(pnl, side, bar):
        """Pine's closed-trade bookkeeping (lines 646-671): loss streak,
        loss pause latch, per-side cooldown anchor."""
        nonlocal consecutive_losses, loss_pause_long, loss_pause_short
        nonlocal loss_pause_start_bar, last_long_loss_bar, last_short_loss_bar
        if pnl < 0.0:
            consecutive_losses += 1
            if cfg["loss_streak_pause"] and consecutive_losses >= cfg["losses_before_pause"]:
                loss_pause_long = True
                loss_pause_short = True
                loss_pause_start_bar = bar
                consecutive_losses = 0
            if side == "long":
                last_long_loss_bar = bar
            else:
                last_short_loss_bar = bar
        else:
            consecutive_losses = 0

    for t in range(n):
        ts = times[t]

        # ------------------------------------------------------------------
        # 1. Pending MARKET close from a timer exit on the previous bar.
        #    strategy.close() fills at this bar's OPEN, ahead of any stop or
        #    limit that could also trade on this bar.
        # ------------------------------------------------------------------
        if pending_close is not None and position is not None:
            reason, sig_bar = pending_close
            if t > sig_bar:
                px = o[t] * (1 - slip) if position["side"] == "long" else o[t] * (1 + slip)
                pnl = close_position(position, ts, px, reason)
                register_result(pnl, position["side"], t)
                position = None
                pending_close = None
        if position is None:
            pending_close = None

        # ------------------------------------------------------------------
        # 2. Pending ENTRY from the previous bar's signal: fills at this
        #    bar's OPEN (the Pine has no process_orders_on_close).
        #    Pyramiding is 0 and the Pine guards entries with
        #    position_size == 0, so a fill that would land on top of an open
        #    position is simply dropped.
        # ------------------------------------------------------------------
        if pending_entry is not None:
            side, sig_bar = pending_entry
            if t > sig_bar:
                pending_entry = None
                if position is None:
                    avg = o[t]                      # strategy.position_avg_price
                    fill = avg * (1 + slip) if side == "long" else avg * (1 - slip)
                    if side == "long":
                        fixed_d = avg * cfg["long_sl_pct"] / 100.0
                        atr_d = min(np.nan_to_num(atr_sl_long[t], nan=0.0) * cfg["long_atr_mult"],
                                    avg * cfg["long_atr_max_stop_pct"] / 100.0)
                        stop = avg - (fixed_d if cfg["long_sl_mode"] == "Fixed %" else atr_d)
                        a = np.nan_to_num(atr_tp_long[t], nan=0.0)
                        tp1_atr = min(a * cfg["long_tp1_atr_mult"],
                                      avg * cfg["long_tp1_atr_max_pct"] / 100.0)
                        tp2_atr = min(a * cfg["long_tp2_atr_mult"],
                                      avg * cfg["long_tp2_atr_max_pct"] / 100.0)
                        tp1 = (avg * (1 + cfg["long_tp1_pct"] / 100.0)
                               if cfg["long_tp1_mode"] == "Fixed %" else avg + tp1_atr)
                        tp2 = (avg * (1 + cfg["long_tp2_pct"] / 100.0)
                               if cfg["long_tp2_mode"] == "Fixed %" else avg + tp2_atr)
                        tp1_frac = cfg["long_tp1_position_pct"] / 100.0
                        long_streak += 1
                        short_streak = 0
                    else:
                        fixed_d = avg * cfg["short_sl_pct"] / 100.0
                        atr_d = min(np.nan_to_num(atr_sl_short[t], nan=0.0) * cfg["short_atr_mult"],
                                    avg * cfg["short_atr_max_stop_pct"] / 100.0)
                        stop = avg + (fixed_d if cfg["short_sl_mode"] == "Fixed %" else atr_d)
                        a = np.nan_to_num(atr_tp_short[t], nan=0.0)
                        tp1_atr = min(a * cfg["short_tp1_atr_mult"],
                                      avg * cfg["short_tp1_atr_max_pct"] / 100.0)
                        tp2_atr = min(a * cfg["short_tp2_atr_mult"],
                                      avg * cfg["short_tp2_atr_max_pct"] / 100.0)
                        tp1 = (avg * (1 - cfg["short_tp1_pct"] / 100.0)
                               if cfg["short_tp1_mode"] == "Fixed %" else avg - tp1_atr)
                        tp2 = (avg * (1 - cfg["short_tp2_pct"] / 100.0)
                               if cfg["short_tp2_mode"] == "Fixed %" else avg - tp2_atr)
                        tp1_frac = cfg["short_tp1_position_pct"] / 100.0
                        short_streak += 1
                        long_streak = 0

                    position = {
                        "side": side,
                        "entry_time": ts,
                        "entry_bar": t,
                        "avg_price": avg,
                        "fill_price": fill,
                        "stop": stop,
                        "tp1": tp1,
                        "tp2": tp2,
                        "tp1_frac": tp1_frac if two_tp else 0.0,
                        "tp1_filled": False,
                        "tp1_fill_price": np.nan,
                        "max_fav_pct": 0.0,
                        "be_done": False,
                    }

        # ------------------------------------------------------------------
        # 3. Broker: the stop / limit orders placed at the end of the previous
        #    bar trade during this one. Never on the fill bar itself.
        #    INTRABAR AMBIGUITY: stop and target on the same bar -> STOP.
        # ------------------------------------------------------------------
        if position is not None and t > position["entry_bar"]:
            side = position["side"]
            stop, tp1, tp2 = position["stop"], position["tp1"], position["tp2"]
            if side == "long":
                stop_hit = l[t] <= stop
                tp2_hit = h[t] >= tp2
                tp1_hit = two_tp and (not position["tp1_filled"]) and h[t] >= tp1
            else:
                stop_hit = h[t] >= stop
                tp2_hit = l[t] <= tp2
                tp1_hit = two_tp and (not position["tp1_filled"]) and l[t] <= tp1

            if stop_hit:
                # Pessimistic: even if TP1/TP2 were also touched, the stop wins.
                px = stop * (1 - slip) if side == "long" else stop * (1 + slip)
                pnl = close_position(position, ts, px, "stop_loss")
                register_result(pnl, side, t)
                position = None
                pending_close = None
            else:
                if tp1_hit:
                    position["tp1_filled"] = True
                    position["tp1_fill_price"] = tp1
                    # Break Even in "TP1" mode fires on the TP1 fill.
                    be_on = cfg["break_even_long"] if side == "long" else cfg["break_even_short"]
                    be_mode = (cfg["break_even_mode_long"] if side == "long"
                               else cfg["break_even_mode_short"])
                    if be_on and be_mode == "TP1" and not position["be_done"]:
                        off = (cfg["break_even_offset_long"] if side == "long"
                               else cfg["break_even_offset_short"])
                        if side == "long":
                            position["stop"] = max(position["stop"],
                                                   position["avg_price"] * (1 + off / 100.0))
                        else:
                            position["stop"] = min(position["stop"],
                                                   position["avg_price"] * (1 - off / 100.0))
                        position["be_done"] = True
                if tp2_hit:
                    if two_tp and not position["tp1_filled"]:
                        # A bar that gaps through both limits fills TP1 too.
                        position["tp1_filled"] = True
                        position["tp1_fill_price"] = tp1
                    px = tp2 * (1 - slip) if side == "long" else tp2 * (1 + slip)
                    pnl = close_position(position, ts, px, "take_profit")
                    register_result(pnl, side, t)
                    position = None
                    pending_close = None

        # ------------------------------------------------------------------
        # 4. Trade management: MFE, break even, the three timer exits.
        #    Runs from the fill bar onward (barsInTrade == 0 included).
        # ------------------------------------------------------------------
        if position is not None and pending_close is None:
            side = position["side"]
            avg = position["avg_price"]
            bars_in = t - position["entry_bar"]
            if side == "long":
                fav = max(h[t] - avg, 0.0) / avg * 100.0
                adv = max(avg - l[t], 0.0) / avg * 100.0
            else:
                fav = max(avg - l[t], 0.0) / avg * 100.0
                adv = max(h[t] - avg, 0.0) / avg * 100.0
            position["max_fav_pct"] = max(position["max_fav_pct"], fav)
            mfe = position["max_fav_pct"]

            if side == "long":
                be_on, be_mode = cfg["break_even_long"], cfg["break_even_mode_long"]
                be_act, be_off = cfg["break_even_activation_long"], cfg["break_even_offset_long"]
                ef_on, ef_bars, ef_min = (cfg["early_failure_long"],
                                          cfg["early_failure_bars_long"],
                                          cfg["early_failure_min_move_long"])
                np_on, np_fav, np_adv = (cfg["no_progress_long"],
                                         cfg["no_progress_max_fav_long"],
                                         cfg["no_progress_adverse_long"])
                mb_on, mb_bars, mb_req = (cfg["max_bars_no_progress_long"],
                                          cfg["max_bars_long"],
                                          cfg["required_progress_long"])
            else:
                be_on, be_mode = cfg["break_even_short"], cfg["break_even_mode_short"]
                be_act, be_off = cfg["break_even_activation_short"], cfg["break_even_offset_short"]
                ef_on, ef_bars, ef_min = (cfg["early_failure_short"],
                                          cfg["early_failure_bars_short"],
                                          cfg["early_failure_min_move_short"])
                np_on, np_fav, np_adv = (cfg["no_progress_short"],
                                         cfg["no_progress_max_fav_short"],
                                         cfg["no_progress_adverse_short"])
                mb_on, mb_bars, mb_req = (cfg["max_bars_no_progress_short"],
                                          cfg["max_bars_short"],
                                          cfg["required_progress_short"])

            be_cond = (mfe >= be_act) if be_mode == "Fixed %" else (two_tp and position["tp1_filled"])
            if be_on and not position["be_done"] and be_cond:
                if side == "long":
                    position["stop"] = max(position["stop"], avg * (1 + be_off / 100.0))
                else:
                    position["stop"] = min(position["stop"], avg * (1 - be_off / 100.0))
                position["be_done"] = True

            # Pine evaluation order; the first hit names the reason.
            if ef_on and bars_in >= ef_bars and mfe < ef_min:
                pending_close = ("early_failure", t)
            elif np_on and mfe < np_fav and adv >= np_adv:
                pending_close = ("no_progress", t)
            elif mb_on and bars_in >= mb_bars and mfe < mb_req:
                pending_close = ("max_bars_no_progress", t)

        # ------------------------------------------------------------------
        # 5. Loss-pause expiry (Pine lines 673-677), then the entry signal.
        # ------------------------------------------------------------------
        if cfg["loss_streak_pause"] and loss_pause_start_bar is not None and t > loss_pause_start_bar:
            if loss_pause_long and t - loss_pause_start_bar > cfg["loss_pause_bars_long"]:
                loss_pause_long = False
            if loss_pause_short and t - loss_pause_start_bar > cfg["loss_pause_bars_short"]:
                loss_pause_short = False

        pos_size = 0 if position is None else (1 if position["side"] == "long" else -1)

        time_ok = first_trade_ts is None or idx[t] >= first_trade_ts
        base_long = bool(time_ok and pivot_low_visible[t] and (
            not long_tp_atr_required or not np.isnan(atr_tp_long[t])))
        base_short = bool(time_ok and pivot_high_visible[t] and (
            not short_tp_atr_required or not np.isnan(atr_tp_short[t])))

        if master:
            sess_ok = (not intraday) or session_allowed(cfg, int(weekdays[t]), int(hours[t]))
            ctrl_long = (
                (not cfg["loss_streak_pause"] or not loss_pause_long)
                and (not cfg["block_opposite_signals"] or pos_size >= 0)
                and (not cfg["cooldown_after_loss_long"] or last_long_loss_bar is None
                     or t - last_long_loss_bar > cfg["cooldown_bars_long"])
                and (not cfg["streak_control_long"] or long_streak < cfg["max_consecutive_long"])
                and sess_ok)
            ctrl_short = (
                (not cfg["loss_streak_pause"] or not loss_pause_short)
                and (not cfg["block_opposite_signals"] or pos_size <= 0)
                and (not cfg["cooldown_after_loss_short"] or last_short_loss_bar is None
                     or t - last_short_loss_bar > cfg["cooldown_bars_short"])
                and (not cfg["streak_control_short"] or short_streak < cfg["max_consecutive_short"])
                and sess_ok)
            qual_long = bool(q_long[t])
            qual_short = bool(q_short[t])
        else:
            ctrl_long = ctrl_short = qual_long = qual_short = True

        long_signal = base_long and ctrl_long and qual_long
        short_signal = base_short and ctrl_short and qual_short

        # Pine: entries only from flat. A signal while in a position is
        # dropped, it does not reverse - hence no "opposite_signal" exits.
        if position is None and pending_entry is None:
            if long_signal:
                pending_entry = ("long", t)
            elif short_signal:
                pending_entry = ("short", t)

    return pd.DataFrame(deals, columns=["entry_time", "exit_time", "side",
                                        "entry_price", "exit_price",
                                        "gross_pnl_pct", "reason"])


# ============================================================================
# DATA LOADING
# ============================================================================

def load_from_csv(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    df.columns = [x.lower() for x in df.columns]
    ts_col = "timestamp" if "timestamp" in df.columns else df.columns[0]
    df[ts_col] = pd.to_datetime(df[ts_col], errors="coerce")
    df = df.set_index(ts_col).sort_index()
    return df[["open", "high", "low", "close", "volume"]]


def load_from_ccxt(symbol: str, timeframe: str, start: str, end: str,
                   exchange_id: str = "bybit", market: str = "swap") -> pd.DataFrame:
    """Delegates to the shared loader in market_data.py - perpetuals by
    default, rate limited, retried, paged properly and cached to disk."""
    from market_data import load_ohlcv
    return load_ohlcv(symbol, timeframe, start, end,
                      exchange_id=exchange_id, market=market)


def print_summary(symbol: str, deals: pd.DataFrame):
    if deals.empty:
        print(f"  {symbol:14s}: 0 trades")
        return
    n = len(deals)
    wins = deals[deals["gross_pnl_pct"] > 0]
    losses = deals[deals["gross_pnl_pct"] <= 0]
    win_rate = len(wins) / n * 100
    avg = deals["gross_pnl_pct"].mean()
    gp, gl = wins["gross_pnl_pct"].sum(), abs(losses["gross_pnl_pct"].sum())
    pf = (gp / gl) if gl > 0 else float("inf")
    print(f"  {symbol:14s}: {n:4d} trades | avg P&L {avg:+6.2f}% | "
          f"win rate {win_rate:5.1f}% | PF {pf:6.2f} | "
          f"total {deals['gross_pnl_pct'].sum():+8.2f}%")
    print(f"                  exits: {deals['reason'].value_counts().to_dict()}")


def _manifest_symbols(args) -> list:
    syms = list(getattr(args, "symbols", None) or [])
    if not syms and getattr(args, "symbol", None):
        syms = [args.symbol]
    if not syms and getattr(args, "csv", None):
        syms = [Path(args.csv).stem]
    return syms


def _parse_session(specs, cfg):
    """--session mon=0-24 tue=off ... ; days not named keep the Pine default."""
    if not specs:
        return
    for spec in specs:
        if "=" not in spec:
            raise SystemExit(f"--session expects day=start-end, got {spec!r}")
        day, rng = spec.split("=", 1)
        day = day.strip().lower()[:3]
        if day not in DAY_NAMES:
            raise SystemExit(f"--session: unknown day {day!r}")
        i = DAY_NAMES.index(day)
        if rng.strip().lower() in ("off", "none", "no"):
            cfg["session"][i] = (False, 0, 24)
            continue
        a, _, b = rng.partition("-")
        cfg["session"][i] = (True, int(a), int(b))


def main():
    p = argparse.ArgumentParser(
        description="Combo OTM v3.2 standalone backtester (6 of 23 filters ported)")
    p.add_argument("--symbol")
    p.add_argument("--symbols", nargs="+")
    p.add_argument("--csv")
    p.add_argument("--exchange", default="bybit")
    p.add_argument("--market", default="swap", choices=["swap", "spot"],
                   help="swap = USDT perpetual (what the bots trade)")
    p.add_argument("--timeframe", default="1h")
    p.add_argument("--start", default="2023-01-01")
    p.add_argument("--end", default="2025-12-31")
    p.add_argument("--out", default="backtest_out_combo")
    p.add_argument("--commission", type=float, default=0.055,
                   help="Per-side commission %% (Pine sets 0.055 = Bybit taker)")
    p.add_argument("--slippage-pct", type=float, default=0.0)

    # --- base ---
    p.add_argument("--pivot-left", type=int, default=CONFIG["pivot_left_bars"])
    p.add_argument("--pivot-right", type=int, default=CONFIG["pivot_right_bars"])
    p.add_argument("--tp-structure", default=CONFIG["tp_structure"], choices=["1 TP", "2 TP"])
    p.add_argument("--first-trade", default=None,
                   help="ISO timestamp; enables the Pine 'Use First Trade' gate")
    p.add_argument("--no-entry-filters", action="store_true",
                   help="Pine 'Enable All Entry Filters' = false (bypasses Entry Control too)")

    # --- risk ---
    p.add_argument("--sl-mode", default=CONFIG["long_sl_mode"], choices=["Fixed %", "ATR Bands"])
    p.add_argument("--sl-pct", type=float, default=CONFIG["long_sl_pct"])
    p.add_argument("--atr-length", type=int, default=CONFIG["long_atr_length"])
    p.add_argument("--atr-mult", type=float, default=CONFIG["long_atr_mult"])
    p.add_argument("--atr-max-stop-pct", type=float, default=CONFIG["long_atr_max_stop_pct"])
    p.add_argument("--tp1-mode", default=CONFIG["long_tp1_mode"], choices=["Fixed %", "ATR"])
    p.add_argument("--tp1-pct", type=float, default=CONFIG["long_tp1_pct"])
    p.add_argument("--tp1-position-pct", type=float, default=CONFIG["long_tp1_position_pct"])
    p.add_argument("--tp2-mode", default=CONFIG["long_tp2_mode"], choices=["Fixed %", "ATR"])
    p.add_argument("--tp2-pct", type=float, default=CONFIG["long_tp2_pct"])

    # --- entry control ---
    p.add_argument("--cooldown-after-loss", action="store_true")
    p.add_argument("--cooldown-bars", type=int, default=CONFIG["cooldown_bars_long"])
    p.add_argument("--loss-streak-pause", action="store_true")
    p.add_argument("--losses-before-pause", type=int, default=CONFIG["losses_before_pause"])
    p.add_argument("--loss-pause-bars", type=int, default=CONFIG["loss_pause_bars_long"])
    p.add_argument("--streak-control", action="store_true")
    p.add_argument("--max-consecutive", type=int, default=CONFIG["max_consecutive_long"])
    p.add_argument("--block-opposite-signals", action="store_true")
    p.add_argument("--session", nargs="+", default=None,
                   help="e.g. --session mon=8-20 sat=off  (unnamed days keep 0-24)")

    # --- trade management ---
    p.add_argument("--early-failure", action="store_true")
    p.add_argument("--early-failure-bars", type=int, default=CONFIG["early_failure_bars_long"])
    p.add_argument("--early-failure-min-move", type=float,
                   default=CONFIG["early_failure_min_move_long"])
    p.add_argument("--no-progress-stop", action="store_true")
    p.add_argument("--no-progress-max-fav", type=float, default=CONFIG["no_progress_max_fav_long"])
    p.add_argument("--no-progress-adverse", type=float, default=CONFIG["no_progress_adverse_long"])
    p.add_argument("--max-bars-no-progress", action="store_true")
    p.add_argument("--max-bars", type=int, default=CONFIG["max_bars_long"])
    p.add_argument("--required-progress", type=float, default=CONFIG["required_progress_long"])
    p.add_argument("--break-even", action="store_true")
    p.add_argument("--break-even-mode", default=CONFIG["break_even_mode_long"],
                   choices=["Fixed %", "TP1"])
    p.add_argument("--break-even-activation", type=float,
                   default=CONFIG["break_even_activation_long"])
    p.add_argument("--break-even-offset", type=float, default=CONFIG["break_even_offset_long"])

    # --- the 6 ported filters, every one OFF by default like its Pine input ---
    p.add_argument("--use-adx", action="store_true")
    p.add_argument("--adx-length", type=int, default=CONFIG["adx_length_long"])
    p.add_argument("--adx-long-min", type=float, default=CONFIG["adx_long_min"])
    p.add_argument("--adx-long-max", type=float, default=CONFIG["adx_long_max"])
    p.add_argument("--adx-short-min", type=float, default=CONFIG["adx_short_min"])
    p.add_argument("--adx-short-max", type=float, default=CONFIG["adx_short_max"])

    p.add_argument("--use-rsi", action="store_true")
    p.add_argument("--rsi-length", type=int, default=CONFIG["rsi_length"])
    p.add_argument("--rsi-long-block-above", type=float, default=CONFIG["rsi_long_block_above"])
    p.add_argument("--rsi-long-block-below", type=float, default=CONFIG["rsi_long_block_below"])
    p.add_argument("--rsi-short-block-above", type=float, default=CONFIG["rsi_short_block_above"])
    p.add_argument("--rsi-short-block-below", type=float, default=CONFIG["rsi_short_block_below"])

    p.add_argument("--use-cci", action="store_true")
    p.add_argument("--cci-length", type=int, default=CONFIG["cci_length"])
    p.add_argument("--cci-long-block-above", type=float, default=CONFIG["cci_long_block_above"])
    p.add_argument("--cci-long-block-below", type=float, default=CONFIG["cci_long_block_below"])
    p.add_argument("--cci-short-block-above", type=float, default=CONFIG["cci_short_block_above"])
    p.add_argument("--cci-short-block-below", type=float, default=CONFIG["cci_short_block_below"])

    p.add_argument("--use-ema-direction", action="store_true")
    p.add_argument("--ema-direction-length", type=int,
                   default=CONFIG["ema_direction_length_long"])

    p.add_argument("--use-ema-slope", action="store_true")
    p.add_argument("--ema-slope-length", type=int, default=CONFIG["ema_slope_length_long"])
    p.add_argument("--ema-slope-lookback", type=int, default=CONFIG["ema_slope_lookback_long"])
    p.add_argument("--ema-slope-min", type=float, default=CONFIG["ema_slope_min_long"])

    p.add_argument("--use-natr", action="store_true")
    p.add_argument("--natr-length", type=int, default=CONFIG["natr_length"])
    p.add_argument("--natr-long-min", type=float, default=CONFIG["natr_long_min"])
    p.add_argument("--natr-long-max", type=float, default=CONFIG["natr_long_max"])
    p.add_argument("--natr-short-min", type=float, default=CONFIG["natr_short_min"])
    p.add_argument("--natr-short-max", type=float, default=CONFIG["natr_short_max"])

    args = p.parse_args()

    # ---- effective config (what actually runs; this is what the manifest gets)
    cfg = dict(CONFIG)
    cfg["session"] = dict(CONFIG["session"])
    cfg["enable_all_entry_filters"] = not args.no_entry_filters
    cfg["use_first_trade"] = args.first_trade is not None
    if args.first_trade:
        cfg["first_trade"] = args.first_trade
    cfg["pivot_left_bars"] = args.pivot_left
    cfg["pivot_right_bars"] = args.pivot_right
    cfg["tp_structure"] = args.tp_structure

    for side in ("long", "short"):
        cfg[f"{side}_sl_mode"] = args.sl_mode
        cfg[f"{side}_sl_pct"] = args.sl_pct
        cfg[f"{side}_atr_length"] = args.atr_length
        cfg[f"{side}_atr_mult"] = args.atr_mult
        cfg[f"{side}_atr_max_stop_pct"] = args.atr_max_stop_pct
        cfg[f"{side}_tp1_mode"] = args.tp1_mode
        cfg[f"{side}_tp1_pct"] = args.tp1_pct
        cfg[f"{side}_tp1_position_pct"] = args.tp1_position_pct
        cfg[f"{side}_tp2_mode"] = args.tp2_mode
        cfg[f"{side}_tp2_pct"] = args.tp2_pct
        cfg[f"cooldown_after_loss_{side}"] = args.cooldown_after_loss
        cfg[f"cooldown_bars_{side}"] = args.cooldown_bars
        cfg[f"loss_pause_bars_{side}"] = args.loss_pause_bars
        cfg[f"streak_control_{side}"] = args.streak_control
        cfg[f"max_consecutive_{side}"] = args.max_consecutive
        cfg[f"early_failure_{side}"] = args.early_failure
        cfg[f"early_failure_bars_{side}"] = args.early_failure_bars
        cfg[f"early_failure_min_move_{side}"] = args.early_failure_min_move
        cfg[f"no_progress_{side}"] = args.no_progress_stop
        cfg[f"no_progress_max_fav_{side}"] = args.no_progress_max_fav
        cfg[f"no_progress_adverse_{side}"] = args.no_progress_adverse
        cfg[f"max_bars_no_progress_{side}"] = args.max_bars_no_progress
        cfg[f"max_bars_{side}"] = args.max_bars
        cfg[f"required_progress_{side}"] = args.required_progress
        cfg[f"break_even_{side}"] = args.break_even
        cfg[f"break_even_mode_{side}"] = args.break_even_mode
        cfg[f"break_even_activation_{side}"] = args.break_even_activation
        cfg[f"break_even_offset_{side}"] = args.break_even_offset
        cfg[f"adx_length_{side}"] = args.adx_length
        cfg[f"ema_direction_length_{side}"] = args.ema_direction_length
        cfg[f"ema_slope_length_{side}"] = args.ema_slope_length
        cfg[f"ema_slope_lookback_{side}"] = args.ema_slope_lookback
        cfg[f"ema_slope_min_{side}"] = args.ema_slope_min

    cfg["loss_streak_pause"] = args.loss_streak_pause
    cfg["losses_before_pause"] = args.losses_before_pause
    cfg["block_opposite_signals"] = args.block_opposite_signals
    _parse_session(args.session, cfg)

    cfg["use_adx"] = args.use_adx
    cfg["adx_long_min"], cfg["adx_long_max"] = args.adx_long_min, args.adx_long_max
    cfg["adx_short_min"], cfg["adx_short_max"] = args.adx_short_min, args.adx_short_max
    cfg["use_rsi"] = args.use_rsi
    cfg["rsi_length"] = args.rsi_length
    cfg["rsi_long_block_above"] = args.rsi_long_block_above
    cfg["rsi_long_block_below"] = args.rsi_long_block_below
    cfg["rsi_short_block_above"] = args.rsi_short_block_above
    cfg["rsi_short_block_below"] = args.rsi_short_block_below
    cfg["use_cci"] = args.use_cci
    cfg["cci_length"] = args.cci_length
    cfg["cci_long_block_above"] = args.cci_long_block_above
    cfg["cci_long_block_below"] = args.cci_long_block_below
    cfg["cci_short_block_above"] = args.cci_short_block_above
    cfg["cci_short_block_below"] = args.cci_short_block_below
    cfg["use_ema_direction"] = args.use_ema_direction
    cfg["use_ema_slope"] = args.use_ema_slope
    cfg["use_natr"] = args.use_natr
    cfg["natr_length"] = args.natr_length
    cfg["natr_long_min"], cfg["natr_long_max"] = args.natr_long_min, args.natr_long_max
    cfg["natr_short_min"], cfg["natr_short_max"] = args.natr_short_min, args.natr_short_max

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    enabled_filters = [name for name, (flag, _) in FILTERS.items() if cfg.get(flag)]

    # ---- MANIFEST: EFFECTIVE values, not raw argv ------------------------
    manifest = {
        "strategy": Path(__file__).stem,
        "source_pine": "strategies/Combo_OTM_v3.2.pine",
        "run_at": _dt.datetime.now().astimezone().isoformat(timespec="seconds"),
        "symbols": _manifest_symbols(args),
        "timeframe": args.timeframe,
        "start": args.start,
        "end": args.end,
        "exchange": args.exchange,
        "market": args.market,
        "source": "csv" if args.csv else "exchange",
        "commission_pct": args.commission,
        "slippage_pct": args.slippage_pct,
        "params": {
            "enable_all_entry_filters": cfg["enable_all_entry_filters"],
            "use_first_trade": cfg["use_first_trade"],
            "first_trade": cfg["first_trade"] if cfg["use_first_trade"] else None,
            "pivot_left_bars": cfg["pivot_left_bars"],
            "pivot_right_bars": cfg["pivot_right_bars"],
            "tp_structure": cfg["tp_structure"],
            "sl_mode": cfg["long_sl_mode"],
            "sl_pct": cfg["long_sl_pct"],
            "atr_length": cfg["long_atr_length"],
            "atr_mult": cfg["long_atr_mult"],
            "atr_max_stop_pct": cfg["long_atr_max_stop_pct"],
            "tp1_mode": cfg["long_tp1_mode"],
            "tp1_pct": cfg["long_tp1_pct"],
            "tp1_position_pct": cfg["long_tp1_position_pct"],
            "tp2_mode": cfg["long_tp2_mode"],
            "tp2_pct": cfg["long_tp2_pct"],
            "cooldown_after_loss": cfg["cooldown_after_loss_long"],
            "cooldown_bars": cfg["cooldown_bars_long"],
            "loss_streak_pause": cfg["loss_streak_pause"],
            "losses_before_pause": cfg["losses_before_pause"],
            "loss_pause_bars": cfg["loss_pause_bars_long"],
            "streak_control": cfg["streak_control_long"],
            "max_consecutive": cfg["max_consecutive_long"],
            "block_opposite_signals": cfg["block_opposite_signals"],
            "session": {DAY_NAMES[i]: list(cfg["session"][i]) for i in range(7)},
            "early_failure": cfg["early_failure_long"],
            "early_failure_bars": cfg["early_failure_bars_long"],
            "early_failure_min_move": cfg["early_failure_min_move_long"],
            "no_progress_stop": cfg["no_progress_long"],
            "no_progress_max_fav": cfg["no_progress_max_fav_long"],
            "no_progress_adverse": cfg["no_progress_adverse_long"],
            "max_bars_no_progress": cfg["max_bars_no_progress_long"],
            "max_bars": cfg["max_bars_long"],
            "required_progress": cfg["required_progress_long"],
            "break_even": cfg["break_even_long"],
            "break_even_mode": cfg["break_even_mode_long"],
            "break_even_activation": cfg["break_even_activation_long"],
            "break_even_offset": cfg["break_even_offset_long"],
        },
        "filters_enabled": enabled_filters,
        "filters_ported": sorted(FILTERS.keys()),
        "filters_not_ported": [
            "trend_catcher", "money_flow", "extreme_distance", "late_entry",
            "impulse_candle", "volume_spike", "atr_extension", "cvd", "noi",
            "z_score", "choppiness", "williams_r", "relative_volume",
            "kaufman_efficiency", "wavetrend", "awesome_oscillator",
            "bollinger_bands",
        ],
        "intrabar_ambiguity": "stop wins when a bar touches both stop and target",
    }
    (out_dir / "_run.json").write_text(_json.dumps(manifest, indent=2), encoding="utf-8")

    if args.csv:
        symbols = [Path(args.csv).stem]
        sources = {symbols[0]: load_from_csv(args.csv)}
    else:
        symbols = args.symbols or ([args.symbol] if args.symbol else None)
        if not symbols:
            p.error("Provide --symbol, --symbols, or --csv")
        sources = {}
        for sym in symbols:
            print(f"Fetching {sym} {args.timeframe} from {args.exchange} "
                  f"({args.start} -> {args.end})...")
            sources[sym] = load_from_ccxt(sym, args.timeframe, args.start, args.end,
                                          args.exchange, args.market)

    print("\n" + "=" * 100)
    print("COMBO OTM v3.2 - BACKTEST RESULTS")
    print(f"pivot={cfg['pivot_left_bars']}/{cfg['pivot_right_bars']} | "
          f"TP structure={cfg['tp_structure']} | SL={cfg['long_sl_mode']} "
          f"{cfg['long_sl_pct']}% | TP2={cfg['long_tp2_pct']}% | "
          f"commission={args.commission}%/side | slippage={args.slippage_pct}%")
    print(f"filters enabled: {enabled_filters or 'none (Pine default)'} | "
          f"17 of 23 Pine filters are NOT ported - see the file header")
    print("NOTE: a pivot printed on bar p is entered at the OPEN of bar p+3 "
          "(confirm + order delay).")
    print("=" * 100)

    min_bars = 60
    for sym, ohlcv in sources.items():
        if len(ohlcv) < min_bars:
            print(f"  {sym:14s}: insufficient data ({len(ohlcv)} bars)")
            continue
        deals = run_backtest(ohlcv, cfg, commission_pct=args.commission,
                             slippage_pct=args.slippage_pct)
        safe = sym.replace("/", "").replace(":", "")
        deals.to_csv(out_dir / f"{safe}_deals.csv", index=False)
        print_summary(sym, deals)

    print("=" * 100)
    print(f"\nDeal logs + _run.json written to: {out_dir}/  "
          f"(compatible with analyze_external_strategies.py)")


if __name__ == "__main__":
    main()
