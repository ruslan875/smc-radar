"""cs_port.py — 2026-11-01. Перенос 1-в-1 двух индикаторов [Crypto-Scalping] (их пользователь прислал, на них сделаны стратегии CryptoFORA):
  • Forecasting MACD Twin Range HL(+): Twin Range Filter (27/1.6, 55/2) + HH/LL пивоты 3/4 + MACD 12/26/9.
      tr_long/tr_short — метки Long/Short Twin Range; buy/sell — BuyAlert/SellAlert версии «+» (x_long и MACD>0 и пробой res).
  • G-RSI Heiken Ashi: Premier RSI (50/35/10), сглаженный HA (10/10), G-Channel 25; сигнал — bbb/sss (подтверждение после смены G-канала).
Без заглядывания вперёд: пивоты известны через 4 бара (как ta.pivothigh), всё считается на закрытии бара."""
from __future__ import annotations
import math
import numpy as np
import pandas as pd


def _ema(x, n):
    return pd.Series(x).ewm(span=n, adjust=False).mean().values


def _rsi(c, n):
    d = np.diff(c, prepend=c[0]); u = pd.Series(np.clip(d, 0, None)).ewm(alpha=1 / n, adjust=False).mean()
    w = pd.Series(np.clip(-d, 0, None)).ewm(alpha=1 / n, adjust=False).mean()
    return (100 - 100 / (1 + u / w.replace(0, 1e-12))).values


def forecasting(d):
    c, h, l = d.c.values.astype(float), d.h.values.astype(float), d.l.values.astype(float); n = len(c)
    # --- Twin Range Filter
    def smoothrng(t, m):
        av = _ema(np.abs(np.diff(c, prepend=c[0])), t); return _ema(av, t * 2 - 1) * m
    rng = (smoothrng(27, 1.6) + smoothrng(55, 2.0)) / 2
    filt = np.zeros(n); up = np.zeros(n); dn = np.zeros(n); ci = np.zeros(n)
    tr_long = np.zeros(n, bool); tr_short = np.zeros(n, bool)
    for i in range(n):
        pf = filt[i - 1] if i else 0.0; x = c[i]; r = rng[i]
        filt[i] = (pf if x - r < pf else x - r) if x > pf else (pf if x + r > pf else x + r)
        if i:
            up[i] = up[i - 1] + 1 if filt[i] > filt[i - 1] else (0 if filt[i] < filt[i - 1] else up[i - 1])
            dn[i] = dn[i - 1] + 1 if filt[i] < filt[i - 1] else (0 if filt[i] > filt[i - 1] else dn[i - 1])
        lc = x > filt[i] and up[i] > 0 and i > 0 and c[i] != c[i - 1]
        sc = x < filt[i] and dn[i] > 0 and i > 0 and c[i] != c[i - 1]
        ci[i] = 1 if lc else (-1 if sc else (ci[i - 1] if i else 0))
        tr_long[i] = lc and i > 0 and ci[i - 1] == -1
        tr_short[i] = sc and i > 0 and ci[i - 1] == 1
    # --- MACD
    macd = _ema(c, 12) - _ema(c, 26)
    # --- HH/LL пивоты 3/4 (значение известно на баре i для пивота на i-4)
    LB, RB = 3, 4
    hlF = [None] * n; zzF = [None] * n          # окончательные значения рядов hlHL / zzHL
    histH = []; histZ = []                       # индексы баров с не-na hl / z (окончательные)
    def vw(hist, arr, now):                      # ta.valuewhen(cond, src, 1)
        if now is not None:
            return arr[hist[-1]] if hist else None
        return arr[hist[-2]] if len(hist) >= 2 else None
    res = np.full(n, np.nan); sup = np.full(n, np.nan); trend = np.zeros(n)
    buy = np.zeros(n, bool); sell = np.zeros(n, bool); x_long = x_short = False
    for i in range(n):
        ph = pl = None
        j = i - RB
        if j - LB >= 0:
            win = h[j - LB:i + 1]
            if h[j] == win.max() and (h[j - LB:j] < h[j]).all(): ph = h[j]
            win = l[j - LB:i + 1]
            if l[j] == win.min() and (l[j - LB:j] > l[j]).all(): pl = l[j]
        hl = 1 if ph is not None else (-1 if pl is not None else None)
        zz = ph if ph is not None else pl
        v1 = vw(histH, hlF, hl); v2 = vw(histZ, zzF, zz)
        if pl is not None and hl == -1 and v1 == -1 and v2 is not None and pl > v2: zz = None
        v3 = vw(histH, hlF, hl); v4 = vw(histZ, zzF, zz)
        if ph is not None and hl == 1 and v3 == 1 and v4 is not None and ph < v4: zz = None
        v5 = vw(histH, hlF, hl); v6 = vw(histZ, zzF, zz)
        if hl == -1 and v5 == 1 and zz is not None and v6 is not None and zz > v6: hl = None
        v7 = vw(histH, hlF, hl); v8 = vw(histZ, zzF, zz)
        if hl == 1 and v7 == -1 and zz is not None and v8 is not None and zz < v8: hl = None
        if hl is None: zz = None
        hlF[i] = hl; zzF[i] = zz
        _hh = _ll = _hl = _lh = False
        if hl is not None and zz:
            pts = []; ehl = -hl; k = len(histH) - 1   # ищем b,c,d,e в прошлом (окончательные значения)
            for want in (ehl, hl, ehl, hl):
                while k >= 0 and not (hlF[histH[k]] == want and zzF[histH[k]] is not None):
                    k -= 1
                pts.append(zzF[histH[k]] if k >= 0 else 0.0); k -= 1
            a = zz; b, cc, dd, e = pts
            _hh = a > b and a > cc and cc > b and cc > dd
            _ll = a < b and a < cc and cc < b and cc < dd
            _hl = (a >= cc and b > cc and b > dd and dd > cc and dd > e) or (a < b and a > cc and b < dd)
            _lh = (a <= cc and b < cc and b < dd and dd < cc and dd < e) or (a > b and a < cc and b > dd)
        if hl is not None: histH.append(i)
        if zz is not None: histZ.append(i)
        pr = res[i - 1] if i else np.nan; ps = sup[i - 1] if i else np.nan
        r_ = zz if _lh else pr; s_ = zz if _hl else ps
        t_ = 1 if (not np.isnan(r_) and c[i] > r_) else (-1 if (not np.isnan(s_) and c[i] < s_) else (trend[i - 1] if i else 0))
        trend[i] = t_
        if (t_ == 1 and _hh) or (t_ == -1 and _lh): r_ = zz
        if (t_ == 1 and _hl) or (t_ == -1 and _ll): s_ = zz
        res[i] = r_; sup[i] = s_
        # --- версия «+»: BuyAlert / SellAlert
        if tr_long[i]: x_long, x_short = True, False
        if tr_short[i]: x_short, x_long = True, False
        if i and not np.isnan(res[i]) and not np.isnan(res[i - 1]):
            buy[i] = x_long and macd[i] > 0 and c[i] > res[i] and c[i - 1] <= res[i - 1]
        if i and not np.isnan(sup[i]) and not np.isnan(sup[i - 1]):
            sell[i] = x_short and macd[i] < 0 and c[i] < sup[i] and c[i - 1] >= sup[i - 1]
        if buy[i] or sell[i]: x_long = x_short = False
    return {"tr_long": tr_long, "tr_short": tr_short, "buy": buy, "sell": sell, "res": res, "sup": sup}


def grsi(d):
    o, c, h, l = (d[k].values.astype(float) for k in ("o", "c", "h", "l")); n = len(c)
    r = _rsi(c, 50); rs = pd.Series(r)
    lo, hi = rs.rolling(35).min().values, rs.rolling(35).max().values
    sk = np.where(hi > lo, 100 * (r - lo) / np.where(hi > lo, hi - lo, 1), np.nan)
    L = round(math.sqrt(10)); ss = _ema(_ema(np.nan_to_num(0.1 * (sk - 50)), L), L); pro = np.tanh(ss / 2)
    os_, cs, hs, ls = _ema(o, 10), _ema(c, 10), _ema(h, 10), _ema(l, 10)
    hac = (os_ + hs + ls + cs) / 4; hao = np.zeros(n); hao[0] = (os_[0] + cs[0]) / 2
    for i in range(1, n):
        hao[i] = (hao[i - 1] + hac[i - 1]) / 2
    o2, c2 = _ema(hao, 10), _ema(hac, 10)
    ag = np.zeros(n); bg = np.zeros(n)
    for i in range(n):
        pa = ag[i - 1] if i else 0.0; pb = bg[i - 1] if i else 0.0
        ag[i] = max(c[i], pa) - (pa - pb) / 25; bg[i] = min(c[i], pb) + (pa - pb) / 25
    lu = ld = None; bull = np.zeros(n, bool)
    for i in range(1, n):
        if bg[i - 1] < c[i - 1] and bg[i] > c[i]: lu = i
        if ag[i - 1] < c[i - 1] and ag[i] > c[i]: ld = i
        bull[i] = ld is not None and (lu is None or ld >= lu)   # barssince(crossdn) <= barssince(crossup)
    buyNow = sellNow = False; long_ = np.zeros(n, bool); short_ = np.zeros(n, bool)
    for i in range(1, n):
        if bull[i] and not bull[i - 1] and o2[i] < c2[i] and pro[i] > 0 and not buyNow:
            buyNow, sellNow = True, False
        if not bull[i] and bull[i - 1] and o2[i] > c2[i] and pro[i] < 0 and not sellNow:
            sellNow, buyNow = True, False
        if buyNow and o2[i] < c2[i] and c[i] > c[i - 1]:
            long_[i] = True; buyNow = False
        if sellNow and o2[i] > c2[i] and c[i] < c[i - 1]:
            short_[i] = True; sellNow = False
    return {"long": long_, "short": short_}
