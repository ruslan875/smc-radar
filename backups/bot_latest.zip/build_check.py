"""build_check.py — 2026-11-15: проверочная сборка терминала в отдельную папку dist_check (панель НЕ трогает)."""
import subprocess, time
from pathlib import Path
T = Path(r"D:\VANTORIX\terminal")
LOG = Path(__file__).resolve().parent / "logs" / "build_check.log"
with open(LOG, "w", encoding="utf-8", errors="replace") as lg:
    lg.write(time.strftime("%H:%M:%S start\n")); lg.flush()
    r = subprocess.run("npx tsc -b && npx vite build --outDir dist_check --emptyOutDir", cwd=str(T), shell=True, stdout=lg, stderr=subprocess.STDOUT, timeout=600)
    lg.write(time.strftime("\n%H:%M:%S ") + f"exit {r.returncode}\n")
