"""hyro_test.py — 2026-11-14. Прогон бота Hyro на истории по его правилам (запуск на ПК).

Сделки — тем же кодом, что боты (bt_lab.sim_honest), 1h-свечи Bybit за ~3 года (кеш market_cache/big).
Стратегии бота Hyro: черепахи 2h/4h (лонг), Donchian 4h (лонг), пробой канала 2h, BOS 4h, ATR Fib 4h. Монеты: 10 крупных.
Фильтр входа (как в живых ботах): по тренду BTC 4h (EMA50 vs EMA200) и ATR 4h монеты растёт.
Портфель: риск 0.5% от старта (×0.5 после 5 стопов подряд у стратегии, ×0.25 после 10), макс. 2 сделки,
одна сделка на группу (BTC / ETH-SOL-BNB / XRP-DOGE-ADA-AVAX / прочие по паре), дневной стоп −3%, общий −7%.
Челленджи с каждого 1-го числа месяца: One-Step (цель +10%, макс. убыток −8%, день −4%), Two-Step этап 1 (+10% / −10% / −5%),
Core (+10% / −5% / −3%). Итог: hyro_test.txt
"""
from __future__ import annotations

import pickle
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import bt_lab as B  # noqa: E402
import big_coins_test as BC  # noqa: E402

COINS = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT", "BNBUSDT", "DOGEUSDT", "ADAUSDT", "AVAXUSDT", "LINKUSDT", "LTCUSDT"]
STRATS = {"honest:turtle_4h": ("TU4h", True), "honest:turtle_2h": ("TU2h", True), "honest:donch": ("DC4h", True),
          "honest:chan": ("CH2h", False), "honest:bos4h": ("BOS4h", False), "honest:atrfib": ("AF4h", False)}
GR = {"ETH": "big", "SOL": "big", "BNB": "big", "XRP": "alt", "DOGE": "alt", "ADA": "alt", "AVAX": "alt"}
OUT = BASE / "hyro_test.txt"
RISK = 0.005


def to4h(df):
    d = df.copy(); d["g"] = d.t // (4 * 3600_000)
    return d.groupby("g").agg(t=("t", "first"), high=("high", "max"), low=("low", "min"), close=("close", "last")).reset_index(drop=True)


def atr(d, n=14):
    pc = d.close.shift(1).fillna(d.close)
    tr = np.maximum(d.high - d.low, np.maximum((d.high - pc).abs(), (d.low - pc).abs()))
    return tr.ewm(alpha=1 / n, adjust=False).mean()


def r_of(q, losses_med):
    for k in ("r", "R"):
        if k in q and q[k] is not None:
            return float(q[k])
    for a, b in (("p_in", "sl"), ("entry", "sl"), ("price_in", "stop")):
        if a in q and b in q and q[b]:
            risk = abs(q[a] - q[b]) / q[a] * 100
            if risk > 0:
                return float(q["pct"]) / risk
    return float(q["pct"]) / losses_med


def main() -> None:
    B.deals_to_trades = lambda rows, df, p, prog=None: rows
    btc4 = None; trades = []; keys_shown = False
    for s in COINS:
        try:
            df = BC.load_1h(s, 1100)
        except Exception:  # noqa: BLE001  -- кеш записан другим Python (pyarrow) → перекачать
            import os  # noqa: PLC0415
            f_ = BC.CACHE / f"{s}_1h.pkl"; os.utime(f_, (0, 0)); df = BC.load_1h(s, 1100)
        if df is None:
            print(s, "нет данных", flush=True); continue
        d4 = to4h(df); d4["atr"] = atr(d4); d4["up"] = d4.atr > d4.atr.shift(6)
        if s == "BTCUSDT":
            btc4 = d4.copy(); c = btc4.close
            btc4["tr"] = np.where(c.ewm(span=50, adjust=False).mean() > c.ewm(span=200, adjust=False).mean(), 1, -1)
        for st, (tag, lo) in STRATS.items():
            if st not in B.HONEST:
                print("нет стратегии", st, flush=True); continue
            rows = B.sim_honest(df, {"strategy": st, "tf": B.HONEST[st][1]}, lambda *x: None)
            if not keys_shown and rows:
                print("поля сделки:", sorted(rows[0].keys()), flush=True); keys_shown = True
            if lo:
                rows = [q for q in rows if q["side"] > 0]
            if not rows:
                continue
            lm = float(np.median([-q["pct"] for q in rows if q["pct"] < 0] or [1.0]))
            for q in rows:
                i = int(np.searchsorted(d4.t.values, q["t_in"], side="right") - 1)
                trades.append({"sym": s, "tag": tag, "side": q["side"], "t_in": int(q["t_in"]),
                               "t_out": int(q.get("t_out") or q.get("t_exit") or q["t_in"] + 3 * 86400_000),
                               "r": r_of(q, lm), "atr_up": bool(d4.up.iat[max(0, i)])})
        print(s, "ok", len(trades), flush=True)
    T = pd.DataFrame(trades).sort_values("t_in").reset_index(drop=True)
    j = np.searchsorted(btc4.t.values, T.t_in.values, side="right") - 1
    T["btc"] = btc4.tr.values[np.clip(j, 0, None)]
    T["gate"] = (T.btc == T.side) & T.atr_up
    lines = [f"Тест бота Hyro {time.strftime('%Y-%m-%d %H:%M')} · сделок всего {len(T)}, прошли фильтр {int(T.gate.sum())}", ""]
    for tag, g in T[T.gate].groupby("tag"):
        lines.append(f"  {tag:6s} сделок {len(g):4d} · в плюс {(g.r > 0).mean() * 100:3.0f}% · средняя {g.r.mean():+.2f}R · сумма {g.r.sum():+.1f}R")
    G = T[T.gate].reset_index(drop=True)
    import os
    global RISK
    RISK = float(os.environ.get("HYRO_RISK", "0.005")); lines.append(f"  РИСК: {RISK * 100:.2f}% на сделку")
    EX = [x for x in os.environ.get("HYRO_EXCL", "").split(",") if x]
    if EX:
        G = G[~G.tag.isin(EX)].reset_index(drop=True); lines.append(f"  БЕЗ стратегий: {', '.join(EX)}")
    if os.environ.get("HYRO_TF") == "1":   # 2026-11-14: + акции/металлы/нефть (как в боте Hyro)
        from windows_app import hh_tradfi_paper as H  # noqa: PLC0415
        from windows_app import bos_tradfi_paper as BOS, fvg_tradfi_paper as FVG, fb2_tradfi_paper as FB2  # noqa: PLC0415
        REP = {"bos": BOS.replay, "vol": H.vol_replay, "fvg": FVG.replay, "fb2": FB2.replay}
        TF = []
        for name, strats in H.HYRO_TF.items():
            sym = H.INST[name][0]
            try:
                d = H._yahoo(sym)
            except Exception as e:  # noqa: BLE001
                print(name, "нет данных", e, flush=True); continue
            for sk in strats:
                for x in REP[sk](d):
                    if x.get("status") == "closed" and x.get("r") is not None:
                        TF.append({"sym": name + "USDT", "tag": "TF" + sk, "side": x["side"], "t_in": int(x["in_t"]),
                                   "t_out": int(x.get("out_t") or x["in_t"] + 5 * 86400_000), "r": float(x["r"]) - 0.03})
            time.sleep(1.5)
        TFd = pd.DataFrame(TF); TFd = TFd[TFd.t_in >= G.t_in.min()]
        G = pd.concat([G[["sym", "tag", "side", "t_in", "t_out", "r"]], TFd], ignore_index=True).sort_values("t_in").reset_index(drop=True)
        lines.append(f"  + акции/металлы/нефть: {len(TFd)} сделок в том же периоде")
    MAXO = int(os.environ.get("HYRO_MAXOPEN", "2"))
    AIMODE = os.environ.get("HYRO_AI", "")   # 2026-11-14: "" | "all" | "skipweak" — проверка фильтра «свой ИИ» без подглядывания
    if AIMODE:
        import own_ai2 as O  # noqa: PLC0415
        from sklearn.ensemble import HistGradientBoostingClassifier  # noqa: PLC0415
        cut = int(G.t_in.quantile(0.65))
        Hs = pd.DataFrame(O.hist_samples(True)).replace([np.inf, -np.inf], np.nan).fillna(0)
        cols = [c for c in Hs.columns if c not in ("t", "r", "w", "src", "sym")]
        tr = Hs[Hs.t < cut]
        mdl = HistGradientBoostingClassifier(max_depth=3, learning_rate=0.05, max_iter=250, l2_regularization=1.0,
                                             min_samples_leaf=40, random_state=1).fit(tr[cols].values, (tr.r > 0).astype(int).values)
        lo = float(np.quantile(mdl.predict_proba(tr[cols].values)[:, 1], 0.3))
        cache = {}; P = []
        for _, x in G.iterrows():
            p = np.nan
            if x.t_in >= cut and not str(x.tag).startswith("TF"):
                if x.sym not in cache:
                    d = O._candles(x.sym, True); cache[x.sym] = (d, O._feat_table(d)) if d is not None else (None, None)
                d, f = cache[x.sym]
                if d is not None:
                    i = int(np.searchsorted(d.t.values, x.t_in - O.H4, side="right")) - 1
                    if i >= 260:
                        z = O._row(f, i, int(x.side), O._strat_of(x.tag))
                        p = float(mdl.predict_proba(np.array([[float(z.get(c, 0.0)) for c in cols]]))[0, 1])
            P.append(p)
        G["p"] = P; G = G[G.t_in >= cut].reset_index(drop=True)
        cr = G[~G.tag.str.startswith("TF") & G.p.notna()]
        wk = cr[cr.p < lo]; ok = cr[cr.p >= lo]
        lines.append(f"  ИИ (обучен только на истории до {time.strftime('%Y-%m-%d', time.gmtime(cut / 1000))}, проверка ПОСЛЕ):")
        lines.append(f"    крипто-сделок {len(cr)} · «слабые» {len(wk)}: {wk.r.mean() if len(wk) else 0:+.2f}R/сд · остальные {len(ok)}: {ok.r.mean() if len(ok) else 0:+.2f}R/сд")
        if AIMODE == "skipweak":
            G = G[~(G.p.notna() & (G.p < lo))].reset_index(drop=True)
            lines.append(f"    РЕЖИМ: слабые пропущены, осталось сделок {len(G)}")
        else:
            lines.append(f"    РЕЖИМ: все сделки ({len(G)})")

    def run(start_ms, end_ms, target, maxloss, dayloss, halt=0.07):
        """Событийно: результат сделки учитывается в момент ВЫХОДА. Возврат: (итог, дней, сделок, баланс, макс.просадка)."""
        bal = 1.0; peak = 1.0; mdd = 0.0; opn = []; streak = {}; day = None; day0 = 1.0; n = 0
        def settle(upto):
            nonlocal bal, peak, mdd
            for o in sorted([o for o in opn if o["t_out"] <= upto], key=lambda o: o["t_out"]):
                opn.remove(o); bal += o["pnl"]
                streak[o["tag"]] = 0 if o["r"] >= 2 else streak.get(o["tag"], 0) + 1 if o["r"] < 0 else streak.get(o["tag"], 0)
                peak = max(peak, bal); mdd = max(mdd, (peak - bal) / peak)
                if bal - 1 >= target: return ("pass", o["t_out"])
                if 1 - bal >= maxloss or day0 - bal >= dayloss: return ("fail", o["t_out"])
            return None
        for _, x in G[(G.t_in >= start_ms) & (G.t_in < end_ms)].iterrows():
            ev = settle(x.t_in)
            if ev:
                return ev[0], (ev[1] - start_ms) / 86400e3, n, bal, mdd
            dd = time.strftime("%Y-%m-%d", time.gmtime(x.t_in / 1000))
            if dd != day:
                day, day0 = dd, bal
            if bal <= day0 * (1 - 0.03) or bal <= 1 - halt or len(opn) >= MAXO:
                continue
            gk = GR.get(x.sym.replace("USDT", ""), x.sym)
            if any(o["g"] == gk for o in opn):
                continue
            k = streak.get(x.tag, 0); mult = 0.25 if k >= 10 else 0.5 if k >= 5 else 1.0
            opn.append({"t_out": x.t_out, "g": gk, "tag": x.tag, "r": x.r, "pnl": RISK * mult * x.r}); n += 1
        ev = settle(10 ** 15)
        if ev:
            return ev[0], (ev[1] - start_ms) / 86400e3, n, bal, mdd
        return "open", None, n, bal, mdd

    t0, t1 = int(G.t_in.min()), int(G.t_in.max())
    res = run(t0, t1 + 1, 99, 99, 99, halt=99)
    lines += ["", f"Весь период ({(t1 - t0) / 86400e3:.0f} дн), риск 0.5%: итог {(res[3] - 1) * 100:+.1f}% за {res[2]} сделок "
                  f"(≈{res[2] / ((t1 - t0) / 86400e3 / 30):.1f} в мес) · макс. просадка {res[4] * 100:.1f}%"]
    for nm, tg, ml, dl in (("One-Step  (+10% / −8% / день −4%)", .10, .08, .04), ("Two-Step э.1 (+10% / −10% / −5%)", .10, .10, .05),
                           ("Core      (+10% / −5% / день −3%)", .10, .05, .03), ("Two-Step э.2 (+5% / −10% / −5%)", .05, .10, .05)):
        starts = pd.date_range(pd.to_datetime(t0, unit="ms").normalize() + pd.offsets.MonthBegin(1), pd.to_datetime(t1, unit="ms") - pd.Timedelta(days=60), freq="MS")
        R = [run(int(s.value // 1e6), t1 + 1, tg, ml, dl) for s in starts]
        p = [r for r in R if r[0] == "pass"]; f = [r for r in R if r[0] == "fail"]; o = [r for r in R if r[0] == "open"]
        lines.append(f"  {nm}: стартов {len(R)} · прошли {len(p)} ({len(p) / max(1, len(R)) * 100:.0f}%) · провал {len(f)} · не дошли {len(o)}"
                     + (f" · медиана до цели {np.median([r[1] for r in p]):.0f} дн" if p else ""))
    lines += ["", "Внимание: фильтр в тесте — приближение живого (тренд BTC 4h + ATR 4h растёт за 24 ч); BOS/ATR Fib в живых ботах свои фильтры."]
    OUT.write_text("\n".join(lines), encoding="utf-8")
    print("\n".join(lines), flush=True)


if __name__ == "__main__":
    main()
