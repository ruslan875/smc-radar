@echo off
cd /d D:\VANTORIX\bot
venv\Scripts\python.exe ginarea_ind_test.py 300
pause
