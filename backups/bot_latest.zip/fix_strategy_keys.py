"""Убирает персональные (по-стратегийные) ключи Bybit, чтобы обе стратегии
брали ОБЩИЙ ключ — тот, у которого есть права на торговлю.

Зачем: TradeKeysStore.get_for_strategy() сначала ищет ключ конкретной
стратегии и только потом падает на общий. Сейчас у обеих стратегий в личном
слоте лежит ключ «только чтение», поэтому торговый ключ из общего слота не
используется никогда, и каждый ордер отклоняется с ошибкой 10005.

Что делает скрипт:
  1. делает резервную копию trade_keys.json рядом (с датой в имени);
  2. удаляет ТОЛЬКО персональные записи bybit у latuserge и kc_roc
     (общий ключ не трогает, другие биржи не трогает);
  3. спрашивает у биржи права того ключа, который теперь достанется каждой
     стратегии, и показывает результат.

Чего НЕ делает: не создаёт ключи, не меняет их права, не ставит ордера.
Ни один секрет на экран не выводится — только первые 6 символов публичной
части ключа.

Запуск из папки проекта:
    venv\\Scripts\\python.exe fix_strategy_keys.py
"""
from __future__ import annotations

import shutil
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from app.config import TRADE_KEYS_FILE
from app.trade_keys_store import TradeKeysStore
from app.exchanges.bybit import _signed_get
from app.data import DataError

STRATEGIES = ["latuserge", "kc_roc"]
EXCH = "bybit"


def mask(api_key: str) -> str:
    return (api_key[:6] + "…") if api_key else "(пусто)"


def read_only_state(api_key: str, api_secret: str) -> str:
    try:
        payload = _signed_get("/v5/user/query-api", api_key, api_secret, {})
    except DataError as exc:
        return f"не удалось спросить биржу: {exc}"
    except Exception as exc:                       # noqa: BLE001
        return f"не удалось спросить биржу: {exc.__class__.__name__}: {exc}"
    ro = (payload.get("result") or {}).get("readOnly")
    return {0: "МОЖНО ТОРГОВАТЬ", 1: "ТОЛЬКО ЧТЕНИЕ"}.get(ro, f"неизвестно ({ro!r})")


def show(store: TradeKeysStore, title: str) -> None:
    print("\n" + "-" * 66)
    print(title)
    print("-" * 66)
    shared = store.get_all().get(EXCH)
    print(f"  общий ключ: {mask(shared.get('api_key', '')) if shared else '(не задан)'}")
    for sid in STRATEGIES:
        own = store.has_dedicated_key(sid, EXCH)
        creds = store.get_for_strategy(sid, EXCH)
        if creds is None:
            print(f"  {sid}: ключа нет вообще")
            continue
        src = "СВОЙ" if own else "общий"
        print(f"  {sid}: возьмёт {mask(creds.get('api_key', ''))} ({src}) — "
              f"{read_only_state(creds['api_key'], creds['api_secret'])}")


def main() -> int:
    path = Path(TRADE_KEYS_FILE)
    if not path.exists():
        print(f"НЕ НАЙДЕН файл ключей: {path}")
        return 1

    print(f"Файл ключей: {path}")
    store = TradeKeysStore(path)
    show(store, "БЫЛО")

    shared = store.get_all().get(EXCH)
    if not shared:
        print("\nОСТАНОВЛЕНО: общий ключ bybit не задан. Если удалить персональные,"
              "\nстратегии останутся вообще без ключа. Сначала сохрани общий ключ в панели.")
        return 1

    to_remove = [sid for sid in STRATEGIES if store.has_dedicated_key(sid, EXCH)]
    if not to_remove:
        print("\nПерсональных ключей bybit нет ни у одной стратегии — менять нечего.")
        return 0

    backup = path.with_name(f"{path.name}.БЭКАП-{datetime.now():%Y-%m-%d_%H%M%S}")
    shutil.copy2(path, backup)
    print(f"\nРезервная копия: {backup.name}")

    for sid in to_remove:
        store.remove_key_for_strategy(sid, EXCH)
        print(f"  удалён персональный ключ bybit у стратегии {sid}")

    show(TradeKeysStore(path), "СТАЛО (перечитано с диска)")

    print("\n" + "=" * 66)
    print("Если у обеих стратегий теперь «МОЖНО ТОРГОВАТЬ» — готово.")
    print("ВАЖНО: боты читают ключ ОДИН раз при запуске, поэтому перезапусти")
    print("обе стратегии в панели, иначе они продолжат работать со старым.")
    print("=" * 66)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
