# HYPE R4 OKX AI EXECUTION

## INSTRUMENT AND TIMEFRAME
- Instrument: `HYPE-USDT-SWAP`
- Timeframe: `15m`
- Run strictly once on the close of each 15-minute candle
- Use only closed candles
- Do not make intrabar decisions

## STATE TO PERSIST BETWEEN RUNS
- `positionSide` = `FLAT | LONG | SHORT`
- `isBullishTrend` = `true | false`
- `isBearishTrend` = `true | false`
- `breakEvenTriggered` = `true | false`
- `entryPrice`
- `stopLoss`
- `tp1`
- `tp2`
- `tp3`
- `tp4`
- `firstTradeTimestamp = 2024-09-11 00:00:00 UTC`

## HARD CONSTANTS
- `analysisWindow = 88`
- `highTrendPerc = 14.6`
- `lowTrendPerc = 78.6`
- `maxBarsAfterCross = 7`

- `longStopLossPct = 0.029`
- `shortStopLossPct = 0.054`

- `longBETriggerPct = 0.018`
- `shortBETriggerPct = 0.023`
- `longBEOffsetPct = 0.001`
- `shortBEOffsetPct = 0.001`

- `longTrailStartPct = 0.042`
- `shortTrailStartPct = 0.040`
- `longTrailOffsetPct = 0.040`
- `shortTrailOffsetPct = 0.038`

- `mirrorAtrLen = 21`
- `mirrorStopMult = 7.6`
- `mirrorSpacing = 1.3`
- `mirrorOffsetMult = 0.30`

- `tp1Fraction = 10%`
- `tp2Fraction = 20%`
- `tp3Fraction = 30%`
- `tp4Fraction = 40%`

- `resetBullishTrendAfterTP4 = true`
- `resetBearishTrendAfterTP4 = true`
- `resetBullishTrendAfterSL = false`
- `resetBearishTrendAfterSL = true`

- Delay module disabled:
  - `useDelayLong = false`
  - `useDelayShort = false`

- Trading days:
  - Monday = true
  - Tuesday = true
  - Wednesday = true
  - Thursday = true
  - Friday = true
  - Saturday = true
  - Sunday = true

## POSITION SIZE
- Contest base equity: `500 USDT`
- Use the agent's working leverage, but cap final position notional by the rules below
- Allowed entry notionals:
  - `3000 USDT` — only when confidence is high
  - `1500 USDT` — when confidence is medium
- Do not use any other size
- Hold only one position at a time
- Do not hedge

## REQUIRED DATA ON EVERY RUN
1. Get at least `400` latest `15m` candles for `HYPE-USDT-SWAP`
2. Get OHLCV data for `HYPE-USDT-SWAP`
3. Get BTC data for Layer 2:
   - `BTC-USDT-SWAP` on `1h`
   - `BTC-USDT-SWAP` on `4h`
4. Get for `HYPE-USDT-SWAP`:
   - funding
   - open interest
   - liquidation / order-book imbalance / volume delta summaries if available from OKX skills
5. Get news and event risk through the available OKX news skill

## PRIMARY TRIGGER LINE CALCULATION
On the latest closed 15m candle calculate:

- `highestHigh = highest(high, 88)`
- `lowestLow = lowest(low, 88)`
- `priceRange = highestHigh - lowestLow`
- `highTrendLevel = highestHigh - priceRange * 0.146`
- `trendLine = highestHigh - priceRange * 0.5`
- `lowTrendLevel = highestHigh - priceRange * 0.786`

## MIRROR FIBO CALCULATION
### True Range
For each candle:
- `TR = max(high - low, abs(high - prevClose), abs(low - prevClose))`

### ATR trail
- `zhts_atrTrail = EMA(TR, 21)`
- `zhts_stopOffset = 7.6 * zhts_atrTrail`
- `zhts_bullStop = high - zhts_stopOffset`
- `zhts_bearStop = low + zhts_stopOffset`

### Persistent trail state
Initialize and update sequentially candle by candle:
- `zhts_trendUp = if prevClose > prev_zhts_trendUp then max(zhts_bullStop, prev_zhts_trendUp) else zhts_bullStop`
- `zhts_trendDown = if prevClose < prev_zhts_trendDown then min(zhts_bearStop, prev_zhts_trendDown) else zhts_bearStop`
- `zhts_trendDir = 1 if close > prev_zhts_trendDown`
- `zhts_trendDir = -1 if close < prev_zhts_trendUp`
- otherwise keep previous `zhts_trendDir`
- `zhts_trail = zhts_trendUp` if `zhts_trendDir = 1`, else `zhts_trendDown`

### Extreme point
- if the trend direction changed on the current candle:
  - `zhts_ex = high` if the new trend is up
  - `zhts_ex = low` if the new trend is down
- otherwise:
  - if trend is up: `zhts_ex = max(prev_zhts_ex, high)`
  - if trend is down: `zhts_ex = min(prev_zhts_ex, low)`

### Base fib levels
- `zhts_fib1 = zhts_ex + (zhts_trail - zhts_ex) * 0.618`
- `zhts_fib2 = zhts_ex + (zhts_trail - zhts_ex) * 0.786`
- `zhts_fib3 = zhts_ex + (zhts_trail - zhts_ex) * 0.886`
- `zhts_l100 = zhts_trail`

### Mirrored levels
- `base_fib1_m = zhts_ex + (zhts_ex - zhts_fib1)`
- `base_fib2_m = zhts_ex + (zhts_ex - zhts_fib2)`
- `base_fib3_m = zhts_ex + (zhts_ex - zhts_fib3)`
- `base_l100_m = zhts_ex + (zhts_ex - zhts_l100)`
- `pivot_m = base_fib1_m`
- `offset_amount = abs(zhts_ex - zhts_trail) * 0.30 * zhts_trendDir`

Final mirrored targets:
- `zhts_fib1_m = pivot_m + offset_amount`
- `zhts_fib2_m = pivot_m + (base_fib2_m - pivot_m) * 1.3 + offset_amount`
- `zhts_fib3_m = pivot_m + (base_fib3_m - pivot_m) * 1.3 + offset_amount`
- `zhts_l100_m = pivot_m + (base_l100_m - pivot_m) * 1.3 + offset_amount`

## CROSS TRIGGER CALCULATION
On the current closed candle:
- `bullCross = (prevLow < highTrendLevel) and (close >= highTrendLevel)`
- `bearCross = (prevHigh > lowTrendLevel) and (close <= lowTrendLevel)`
- `bullBars = barsSince(bullCross)`
- `bearBars = barsSince(bearCross)`
- `recentBullCross = bullBars >= 0 and bullBars <= 7`
- `recentBearCross = bearBars >= 0 and bearBars <= 7`

`barsSince(x)` = number of candles since the most recent true value of `x`, using standard series `barssince` behavior.

## BASE STRATEGY SIGNAL
### Long base trigger
Long base trigger exists only if all conditions below are true at the same time:
- current time >= `firstTradeTimestamp`
- trading day is allowed
- `positionSide = FLAT`
- `close >= trendLine`
- `close >= highTrendLevel`
- `isBullishTrend = false`
- `recentBullCross = true`

### Short base trigger
Short base trigger exists only if all conditions below are true at the same time:
- current time >= `firstTradeTimestamp`
- trading day is allowed
- `positionSide = FLAT`
- `close <= trendLine`
- `close <= lowTrendLevel`
- `isBearishTrend = false`
- `recentBearCross = true`

## SIGNAL MEANING THAT AI MUST VALIDATE
This signal is valid only if it indicates the beginning or continuation of a short-term impulse trend.

For LONG, a valid signal is not just a touch above a level. It is a situation where the market has likely started an upside expansion and can continue moving further.

For SHORT, a valid signal is not just a touch below a level. It is a situation where the market has likely started a downside expansion and can continue moving further.

AI MUST NOT confirm the signal if it sees:
- exhausted momentum
- late entry into an already stretched candle structure
- sharp wick without stable follow-through
- likely return into the range
- countertrend setup against higher-timeframe regime
- elevated event risk
- behavior similar to a false breakout

## LAYER 2: MANDATORY AI REGIME VALIDATION
After a base trigger appears, call OKX skills in this order.

### 1) `Technical Analysis Master`
Pass:
- `HYPE-USDT-SWAP 15m`
- `HYPE-USDT-SWAP 1h`
- `HYPE-USDT-SWAP 4h`

Require output covering:
- regime direction on 15m
- regime direction on 1h
- regime direction on 4h
- whether momentum is expanding or already exhausted
- whether structure is continuation or exhaustion
- whether mean reversion risk is present
- follow-through quality after the signal
- final `trend_continuation_score` from `0` to `100`

### 2) `The CMC & OKX dual-engine market analysis king`
Pass:
- `BTC-USDT-SWAP 1h`
- `BTC-USDT-SWAP 4h`
- `HYPE-USDT-SWAP funding`
- `HYPE-USDT-SWAP open interest`

Require output covering:
- whether BTC supports the signal direction or works against it
- market state: risk-on / neutral / risk-off
- whether funding is normal or overheated
- whether OI confirms continuation or indicates a crowded move
- final `macro_support_score` from `0` to `100`

### 3) `Market Intelligence Master`
Pass:
- `HYPE`
- `Hyperliquid`
- current crypto market

Require output covering:
- whether there are news or events that can break the impulse
- whether there is abnormal headline risk in the next few hours
- final `event_risk_score` from `0` to `100`, where higher = more dangerous

## REGIME CLASSIFICATION RULE
After the three AI skill responses, classify the regime strictly as follows:

### `ALLOW`
Use only if all conditions below are true:
- `trend_continuation_score >= 75`
- `macro_support_score >= 60`
- `event_risk_score <= 35`
- AI explicitly describes the setup as early-trend continuation or clean momentum continuation
- AI does NOT describe the setup as exhaustion / late chase / blow-off / fake breakout

### `ALLOW_WITH_CAUTION`
Use only if all conditions below are true:
- `trend_continuation_score >= 60`
- `event_risk_score <= 50`
- there is no direct rejection from BTC and no direct news block
- AI sees impulse, but continuation quality is only moderate or there is moderate overheating

### `BLOCK`
Use in all other cases

If at least one AI skill explicitly says the move looks like exhaustion, late breakout, news trap, or false breakout, final regime = `BLOCK`.

## POSITION SIZE BY CONFIDENCE
After regime classification call:

### 4) `Position Risk Control Calculator`
Pass:
- account equity = `500`
- instrument = `HYPE-USDT-SWAP`
- candidate notional = `3000` or `1500`
- stop distance = `3.3%` for long or `3.1%` for short
- agent leverage plan

Size selection rules:
- if regime = `ALLOW` and risk calculator approves `3000`, use `3000`
- if regime = `ALLOW` but `3000` is not approved, use `1500` if approved
- if regime = `ALLOW_WITH_CAUTION`, attempt only `1500`
- if `1500` is not approved, do not enter

## LAYER 3: ENTRY EXECUTION
Use:
- `Maker automatic order placement`

### Execution rules
- AI may choose the entry execution technique
- AI may not change the base trigger math
- AI may not change TP/SL/BE math
- AI may not open a position without both a base trigger and an allowed regime

### Allowed execution behavior
- for `ALLOW`: more aggressive execution is allowed
- for `ALLOW_WITH_CAUTION`: use only a more conservative entry method
- if the limit entry is not filled before the next 15m close, cancel it and recalculate the full system again

## LONG ENTRY
Execute only if:
- `Long base trigger` exists
- regime = `ALLOW` or `ALLOW_WITH_CAUTION`
- risk calculator approved size
- `positionSide = FLAT`

Actions:
1. `entryPrice = close` of the latest closed 15m candle
2. `stopLoss = entryPrice * (1 - 0.029)`
3. `rawTP1 = zhts_fib1_m`
4. `rawTP2 = zhts_fib2_m`
5. `rawTP3 = zhts_fib3_m`
6. `rawTP4 = zhts_l100_m`
7. Apply reflection to each target:
   - if `rawTP <= entryPrice`, then
   - `fixedTP = entryPrice + (entryPrice - rawTP)`
8. Apply safety floor:
   - `tp = max(fixedTP, entryPrice * 1.0000001)`
9. Open long through `Maker automatic order placement`
10. Immediately place reduce-only limit take profits:
   - `10%` at `tp1`
   - `20%` at `tp2`
   - `30%` at `tp3`
   - `40%` at `tp4`
11. Immediately place a protective stop-loss for the remaining position at `stopLoss`
12. Update state:
   - `positionSide = LONG`
   - `isBullishTrend = true`
   - `isBearishTrend = false`
   - `breakEvenTriggered = false`

## SHORT ENTRY
Execute only if:
- `Short base trigger` exists
- regime = `ALLOW` or `ALLOW_WITH_CAUTION`
- risk calculator approved size
- `positionSide = FLAT`

Actions:
1. `entryPrice = close` of the latest closed 15m candle
2. `stopLoss = entryPrice * (1 + 0.054)`
3. `rawTP1 = zhts_fib1_m`
4. `rawTP2 = zhts_fib2_m`
5. `rawTP3 = zhts_fib3_m`
6. `rawTP4 = zhts_l100_m`
7. Apply reflection to each target:
   - if `rawTP >= entryPrice`, then
   - `fixedTP = entryPrice - (rawTP - entryPrice)`
8. Apply safety ceiling:
   - `tp = min(fixedTP, entryPrice * 0.9999999)`
9. Open short through `Maker automatic order placement`
10. Immediately place reduce-only limit take profits:
   - `10%` at `tp1`
   - `20%` at `tp2`
   - `30%` at `tp3`
   - `40%` at `tp4`
11. Immediately place a protective stop-loss for the remaining position at `stopLoss`
12. Update state:
   - `positionSide = SHORT`
   - `isBearishTrend = true`
   - `isBullishTrend = false`
   - `breakEvenTriggered = false`

## POSITION MANAGEMENT ON EVERY NEW 15M CLOSE
If `positionSide = FLAT`, only scan for a new signal and write the log.

### Break-even long
If all conditions below are true:
- `positionSide = LONG`
- `breakEvenTriggered = false`
- `close >= entryPrice * 1.018`

Then:
- `stopLoss = entryPrice * 1.001`
- update the stop order
- `breakEvenTriggered = true`

### Break-even short
If all conditions below are true:
- `positionSide = SHORT`
- `breakEvenTriggered = false`
- `close <= entryPrice * (1 - 0.023)`

Then:
- `stopLoss = entryPrice * 0.999`
- update the stop order
- `breakEvenTriggered = true`

### Trailing long
If all conditions below are true:
- `positionSide = LONG`
- `close >= entryPrice * 1.042`

Then:
- `newStop = close * (1 - 0.040)`
- if `newStop > stopLoss`, update stop to `newStop`

### Trailing short
If all conditions below are true:
- `positionSide = SHORT`
- `close <= entryPrice * (1 - 0.040)`

Then:
- `newStop = close * (1 + 0.038)`
- if `newStop < stopLoss`, update stop to `newStop`

## STATE RESET AFTER POSITION CLOSE
### After full LONG close
- `positionSide = FLAT`
- if close reason is `TP4`, set `isBullishTrend = false`
- if close reason is `SL`, do not change `isBullishTrend`
- `breakEvenTriggered = false`
- clear `entryPrice`, `stopLoss`, `tp1`, `tp2`, `tp3`, `tp4`

### After full SHORT close
- `positionSide = FLAT`
- if close reason is `TP4`, set `isBearishTrend = false`
- if close reason is `SL`, set `isBearishTrend = false`
- `breakEvenTriggered = false`
- clear `entryPrice`, `stopLoss`, `tp1`, `tp2`, `tp3`, `tp4`

## POSITION REVERSAL
If a position is already open, you must still evaluate a new opposite-direction base trigger on each closed 15m candle.

### Reverse LONG -> SHORT
If all conditions below are true:
- `positionSide = LONG`
- a new valid SHORT base trigger exists
- all delay rules for SHORT are fully completed
- Layer 2 verdict for this SHORT trigger is exactly `ALLOW`

Then:
1. cancel all existing LONG TP and SL resting orders
2. close the current LONG position at market
3. log that the previous LONG thesis is invalidated by a confirmed opposite impulse
4. recalculate allowed USD size through the Layer 3 risk sizing logic
5. open a new SHORT position immediately at market
6. place the new SHORT stop-loss and all 4 SHORT take-profit orders
7. reset all SHORT state variables exactly as for a fresh SHORT entry

If the opposite SHORT trigger exists but Layer 2 returns `ALLOW_WITH_CAUTION` or `BLOCK`, do not reverse immediately. Keep managing the existing LONG position with its current TP / SL / BE / trailing logic.

### Reverse SHORT -> LONG
If all conditions below are true:
- `positionSide = SHORT`
- a new valid LONG base trigger exists
- all delay rules for LONG are fully completed
- Layer 2 verdict for this LONG trigger is exactly `ALLOW`

Then:
1. cancel all existing SHORT TP and SL resting orders
2. close the current SHORT position at market
3. log that the previous SHORT thesis is invalidated by a confirmed opposite impulse
4. recalculate allowed USD size through the Layer 3 risk sizing logic
5. open a new LONG position immediately at market
6. place the new LONG stop-loss and all 4 LONG take-profit orders
7. reset all LONG state variables exactly as for a fresh LONG entry

If the opposite LONG trigger exists but Layer 2 returns `ALLOW_WITH_CAUTION` or `BLOCK`, do not reverse immediately. Keep managing the existing SHORT position with its current TP / SL / BE / trailing logic.

## LOGS EVERY 15 MINUTES
On each run write exactly one main structured log.

### If no trigger exists
`[HYPE-R4][15m] No trigger. close=<value> trendLine=<value> highBand=<value> lowBand=<value> recentBullCross=<true/false> recentBearCross=<true/false>`

### If a base trigger exists but delay is still active
`[HYPE-R4][15m] Trigger detected: <LONG/SHORT>. Delay active: <currentDelayBar>/<requiredDelayBars>. Waiting.`

### If a base trigger exists but AI blocked it
`[HYPE-R4][15m] Trigger detected: <LONG/SHORT>. AI regime=BLOCK. Reason=<short reason>. No trade.`

### If a trigger exists and regime is cautious
`[HYPE-R4][15m] Trigger detected: <LONG/SHORT>. AI regime=ALLOW_WITH_CAUTION. Size=1500. Proceeding.`

### If a trigger exists and regime is strong
`[HYPE-R4][15m] Trigger detected: <LONG/SHORT>. AI regime=ALLOW. Size=3000. Proceeding.`

### If an opposite trigger exists during an active position but reversal is not allowed
`[HYPE-R4][15m] Opposite trigger detected during active position. CurrentSide=<LONG/SHORT>. OppositeSide=<SHORT/LONG>. AI regime=<ALLOW_WITH_CAUTION/BLOCK>. No reversal.`

### If an opposite trigger exists during an active position and reversal is allowed
`[HYPE-R4][15m] Reversal executed. Closed=<LONG/SHORT>. Opened=<SHORT/LONG>. AI regime=ALLOW. Reason=confirmed opposite impulse.`

### If position is active
`[HYPE-R4][15m] Position active: side=<LONG/SHORT> entry=<value> stop=<value> tp1=<value> tp2=<value> tp3=<value> tp4=<value> BE=<true/false>`

### If break-even was updated
`[HYPE-R4][15m] Break-even updated: side=<LONG/SHORT> newStop=<value>`

### If trailing was updated
`[HYPE-R4][15m] Trailing updated: side=<LONG/SHORT> newStop=<value>`

### If position was closed
`[HYPE-R4][15m] Position closed: side=<LONG/SHORT> reason=<TP1/TP2/TP3/TP4/SL/MANUAL>`

## PROHIBITIONS
- Do not trade before candle close
- Do not open a position without a base trigger
- Do not replace strategy math with discretionary AI opinion
- Do not change the timeframe
- Do not change the instrument
- Do not exceed the allowed position size
- Do not leave a position without a protective stop
- Do not place take profits without reduce-only
- Do not hold more than one position at the same time

## EXECUTION ORDER ON EVERY RUN
1. wait for the 15m candle to close
2. load fresh HYPE 15m data and higher-timeframe context
3. calculate all deterministic Layer 1 values
4. detect fresh LONG and SHORT base triggers
5. update delay counters and determine whether LONG and/or SHORT are eligible right now
6. if a position is already open, first manage TP / SL / BE / trailing state
7. if a position is already open and a fully eligible opposite-direction trigger exists, run Layer 2 on that opposite trigger
8. if Layer 2 verdict for the opposite trigger is exactly `ALLOW`, execute full reversal immediately
9. if no reversal is executed, keep the current position alive and continue normal management
10. if no position is open and a fully eligible trigger exists, run Layer 2 AI validation
11. use Layer 3 to choose position size:
   - `ALLOW` -> 3000 USD nominal
   - `ALLOW_WITH_CAUTION` -> 1500 USD nominal
   - `BLOCK` -> no trade
12. if allowed, open market position
13. immediately place stop-loss and 4 take-profit limit orders
14. on every next 15m close, re-check break-even and trailing logic
15. write the structured log entry

