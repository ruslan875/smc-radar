#!/usr/bin/env python3
"""
Fee-aware, no-lookahead backtester for Влад's real Veles Finance bot
(share code XWvCF, SOL/USDT, 15m chart shown in the UI but base execution
timeframe 1m -- see below), reconstructed from the user's own screenshots
of the actual "Создание бота" wizard (not a guess from a plain-text recap
this time -- these are the real UI panels). This is a THIRD, separate
engine from kc_roc_cci_wt_grid_backtest.py (cabinet/bot/4467479) and
macd_zerocross_diverx_backtest.py (the other, non-Vlad bot) -- do not
confuse the three.

READ THIS BEFORE TRUSTING ANY NUMBER THIS SCRIPT PRINTS. Every parameter
below is marked CONFIRMED (read directly off a screenshot) or ASSUMED
(not visible in any screenshot the user sent -- filled with a stated,
overridable default so the backtest can run at all). Nothing here is
presented as fact when it isn't.

CONFIRMED from screenshots:
  - Direction: LONG only ("Покупка"/Buy marker on the chart).
  - Условия открытия сделки (4 filters, ALL must be true, edge-triggered):
      Filter 1: CCI,  5m, на закрытии бара, Меньше <threshold UNCONFIRMED>
      Filter 2: RSI,  5m, на закрытии бара, Меньше 70
      Filter 3: RSI, 15m, на закрытии бара, Меньше 70
      Filter 4: RSI,  5m, на закрытии бара, Больше 30
  - Ордера сделки: режим "Сигнал" (not "Свой"!) -- every safety order
    needs its price offset floor AND 2 attached filters to all be true,
    not just a price level. "Отступ от предыдущего ордера" = ON (each
    order's %-offset is measured from the PREVIOUS order's fill, not the
    base price -- but Veles displays the resulting cumulative distance
    from entry directly, so this script uses those displayed numbers
    as-is rather than re-deriving the compounding formula):
      order 1 (base):        0% offset,          5% volume
      order 2:  мин.отступ 5%,  7% volume, effective 5.00% from entry
      order 3:  мин.отступ 5%,  8% volume, effective 9.75% from entry
      order 4:  мин.отступ 5%, 10% volume, effective 14.26% from entry
      order 5:  мин.отступ 5%, 15% volume, effective 18.55% from entry
      order 6:  мин.отступ 5%, 20% volume, effective 22.82% from entry
      order 7:  мин.отступ 10%, 35% volume, effective 30.36% from entry
    Volumes sum to 100% (5+7+8+10+15+20+35), matches the "7/40 orders,
    0% remaining" checkmark shown in the UI.
  - Two of the six safety orders' attached filter pairs were read
    directly off expanded "ФИЛЬТРЫ: 2" panels:
      order 4: CCI 5m Меньше -100  AND  Williams %R 1m Меньше -80
      order 6: CCI 5m Меньше -150  AND  Williams %R 1m Меньше -80
    (A third sample showed CCI 1m Меньше -150 + the same Williams %R --
    which order that belongs to was not confirmed, and it's the only
    1-minute-interval CCI sample seen; treated as inconclusive rather
    than force-fit anywhere -- see ASSUMED below.)
  - Подтяжка сетки ордеров: 0.1%. Bot does NOT stop after a deal and
    does NOT stop after a stop-loss (moot -- no stop-loss exists at all,
    see below).
  - Выход из сделки: Тейк-профит режим "Сигнал", Filter 1 = Williams %R,
    5m, на закрытии бара (threshold/operator UNCONFIRMED). Валюта
    профита USDT. Минимальный P&L: 5% (deal only closes once the
    Williams %R signal fires AND unrealized P&L >= 5%).
  - SТОП-ЛОСС and SТОП-ЛОСС ПО СИГНАЛУ: both OFF. No price-based stop
    anywhere in this bot.

ASSUMED (not visible in any screenshot -- override via CLI flags the
moment the real value is confirmed):
  - Entry Filter 1's CCI threshold: defaults to -100 (--entry-cci-threshold),
    the most common threshold actually seen among the confirmed
    per-order CCI filters. Could easily be wrong -- Веles never showed us
    this specific number.
  - CCI length (--cci-length, default 20), RSI length (--rsi-length,
    default 14), Williams %R length (--wr-length, default 14): Veles'
    UI never exposed a period field in any screenshot, only interval +
    threshold. These are the standard/TradingView-default periods for
    each indicator, not confirmed Veles-specific values.
  - Orders 2, 3, 5, 7's CCI thresholds (order 4 and 6 ARE confirmed --
    see above): linearly interpolated/extrapolated at a constant -25
    step between the two confirmed points (order4=-100, order6=-150),
    giving order2=-50, order3=-75, order5=-125, order7=-175, all at the
    same 5-minute interval as the two confirmed samples (the one 1-minute
    CCI sample seen is NOT used here -- see above). This is a plausible
    pattern, not a confirmed fact.
  - Williams %R gate on orders 2,3,5,7: same as the two confirmed orders
    (1m, Меньше -80) -- no counter-evidence against this being uniform
    across all six safety orders.
  - Take-profit Williams %R operator + threshold: defaults to "Больше -20"
    (--tp-wr-threshold, --tp-wr-op), a symmetric overbought mirror of the
    -80 oversold reading used everywhere else in this bot. Purely a
    guess at the shape -- the real screenshot value was never captured.
  - "Подтяжка сетки" (grid pull-up) mechanics themselves are only
    described at a conceptual level in Veles' own docs ("cancels pending
    orders if price moves away favorably by this %% before they fill").
    This script cancels only the REMAINING UNFILLED safety orders when
    price closes >= pullup_pct above the most recently filled order's
    price -- the deal stays open with whatever filled so far and still
    exits normally on the TP signal. Whether the real bot instead closes
    the whole deal immediately on a pull-up is not confirmed either way;
    --pullup-pct 0 disables this mechanic entirely for comparison.

Fees, split-sample validation: same conventions as every other backtest
in this project (see FEE_SCENARIOS below).

Needs network access to Bybit's public API -- run on your own machine:

    python cci_rsi_wr_signal_grid_backtest.py --symbol SOLUSDT --bars 200000
"""
from __future__ import annotations

import argparse
import csv
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np
import pandas as pd
import requests

from app.data import BYBIT_BASE, INTERVAL_MAP, DataError
from app.indicators.common import cci, rsi
from app.indicators.veles_style import htf_closed_series

# CONFIRMED 2026-09-04 from real account fee screenshots (both exchanges,
# futures only -- this account does not trade spot). Round-trip rates
# (entry+exit combined), replacing the old generic placeholder guess.
# Bybit futures, "Обычный пользователь" tier, 10% MNT discount currently
# ACTIVE: maker 0.0324%, taker 0.0900% per fill.
# OKX futures, "Обычные пользователи" tier, no discount toggle shown:
# maker 0.0200%, taker 0.0500% per fill.
FEE_SCENARIOS = {
    "bybit_taker+taker": 0.0018,
    "bybit_taker+maker": 0.001224,
    "bybit_maker+maker": 0.000648,
    "okx_taker+taker": 0.0010,
    "okx_taker+maker": 0.0007,
    "okx_maker+maker": 0.0004,
}


# --------------------------------------------------------------- data --

def _fetch_page(params: dict, symbol: str, retries: int = 4, timeout: float = 15.0) -> dict:
    # Hardened 2026-09-05 after a real incident: running a heavy multi-symbol
    # backtest at the same time as the live bot on the same API key hit
    # Bybit's rate limit ("Too many visits. Exceeded the API Rate Limit."),
    # which comes back as a normal HTTP 200 with retCode != 0 -- the original
    # code only retried on network exceptions, so a rate-limit hit raised
    # DataError immediately with zero retries. Now retries on retCode != 0
    # too, with the same backoff as network errors.
    last_exc: Exception | None = None
    for attempt in range(retries):
        try:
            resp = requests.get(f"{BYBIT_BASE}/v5/market/kline", params=params, timeout=timeout)
            resp.raise_for_status()
            payload = resp.json()
            if payload.get("retCode") == 0:
                return payload
            last_exc = RuntimeError(f"retCode={payload.get('retCode')} {payload.get('retMsg')}")
        except requests.RequestException as exc:
            last_exc = exc
        if attempt < retries - 1:
            time.sleep(1.5 * (attempt + 1))
    raise DataError(f"Bybit request failed for {symbol} after {retries} attempts: {last_exc}")


def fetch_history(symbol: str, timeframe: str, total_bars: int, category: str = "linear") -> pd.DataFrame:
    interval = INTERVAL_MAP[timeframe]
    all_rows: list = []
    end = None
    while len(all_rows) < total_bars:
        params = {"category": category, "symbol": symbol, "interval": interval, "limit": 1000}
        if end is not None:
            params["end"] = end
        payload = _fetch_page(params, symbol)
        if payload.get("retCode") != 0:
            raise DataError(f"Bybit API error for {symbol}: {payload.get('retMsg')}")
        rows = payload["result"]["list"]
        if not rows:
            break
        all_rows.extend(rows)
        oldest_ts = int(rows[-1][0])
        end = oldest_ts - 1
        if len(rows) < 1000:
            break
        time.sleep(0.6)

    if not all_rows:
        raise DataError(f"No kline data returned for {symbol} {timeframe}")

    df = pd.DataFrame(all_rows, columns=["open_time", "open", "high", "low", "close", "volume", "turnover"])
    df["open_time"] = df["open_time"].astype("int64")
    df = df.drop_duplicates(subset="open_time")
    for col in ("open", "high", "low", "close", "volume", "turnover"):
        df[col] = df[col].astype(float)
    df["open_time"] = pd.to_datetime(df["open_time"], unit="ms", utc=True)
    df = df.sort_values("open_time").reset_index(drop=True)
    if len(df) > total_bars:
        df = df.tail(total_bars).reset_index(drop=True)

    # Diagnostic added 2026-09-04: surface the real fetched date range and
    # flag any gaps in the candle series. Triggered by a real finding --
    # a run requesting the same --bars 200000 for six symbols produced a
    # ~139-day span for three (SUI/INJ/TIA, newer listings) but a ~345-day
    # span for the other three (ETH/SOL/ARB, deep history) despite an
    # identical bar count, implying non-contiguous/gappy data rather than
    # a genuine 200000-consecutive-minute window for the latter three.
    if len(df) > 1:
        step_seconds = df["open_time"].diff().dt.total_seconds()
        expected_step = step_seconds.median()
        max_gap = step_seconds.max()
        max_gap_idx = step_seconds.idxmax()
        span_days = (df["open_time"].iloc[-1] - df["open_time"].iloc[0]).days
        print(f"  [fetch_history] {symbol}: {len(df)} bars, "
              f"{df['open_time'].iloc[0]} -> {df['open_time'].iloc[-1]} "
              f"({span_days} days)")
        if pd.notna(max_gap) and max_gap > expected_step * 3:
            print(f"  [fetch_history] WARNING: {symbol} has a gap of "
                  f"{max_gap/60:.1f} min (expected ~{expected_step/60:.1f} min "
                  f"between bars) right before "
                  f"{df['open_time'].iloc[max_gap_idx]} -- data is likely "
                  f"NON-CONTIGUOUS, treat this run's results as unreliable "
                  f"until re-fetched.")
    return df


def williams_r(df: pd.DataFrame, length: int) -> pd.Series:
    """Larry Williams %R: (highest_high(N) - close) / (highest_high(N) -
    lowest_low(N)) * -100. Not in app/indicators/common.py yet -- added
    here rather than there since its exact Veles length is UNCONFIRMED
    (see module docstring); promote to common.py once/if verified."""
    hh = df["high"].rolling(length, min_periods=length).max()
    ll = df["low"].rolling(length, min_periods=length).min()
    return (hh - df["close"]) / (hh - ll).replace(0, np.nan) * -100.0


# ------------------------------------------------------------- params --

# (мин.отступ%, объём%, effective %-offset-from-entry AS DISPLAYED BY VELES)
GRID = [
    (0.0, 5.0, 0.0),
    (5.0, 7.0, 5.00),
    (5.0, 8.0, 9.75),
    (5.0, 10.0, 14.26),
    (5.0, 15.0, 18.55),
    (5.0, 20.0, 22.82),
    (10.0, 35.0, 30.36),
]

# order index (1=base..7) -> (cci_interval_minutes, cci_threshold, confirmed?)
ORDER_CCI_DEFAULT = {
    2: (5, -50.0, False),
    3: (5, -75.0, False),
    4: (5, -100.0, True),
    5: (5, -125.0, False),
    6: (5, -150.0, True),
    7: (5, -175.0, False),
}
ORDER_WR_INTERVAL = 1     # minutes, confirmed uniform across sampled orders
ORDER_WR_THRESHOLD = -80.0  # confirmed uniform across sampled orders


@dataclass
class Params:
    entry_cci_length: int
    entry_cci_threshold: float
    rsi_length: int
    wr_length: int
    tp_wr_op: str          # "gt" | "lt"
    tp_wr_threshold: float
    min_pnl_pct: float
    pullup_pct: float
    max_deal_bars: int


@dataclass
class Deal:
    symbol: str
    entry_time: pd.Timestamp
    exit_time: pd.Timestamp | None
    orders_filled: int
    filled_pct: float
    avg_entry_price: float
    exit_price: float | None
    reason: str  # "TP" | "TIMEOUT" | "OPEN_AT_CUTOFF"
    bars_held: int
    gross_pnl_pct: float | None
    meta: dict = field(default_factory=dict)


def compute_indicators(df: pd.DataFrame, p: Params) -> dict:
    cci_5m = htf_closed_series(df, 5, lambda h: cci((h["high"] + h["low"] + h["close"]) / 3, p.entry_cci_length))
    rsi_5m = htf_closed_series(df, 5, lambda h: rsi(h["close"], p.rsi_length))
    rsi_15m = htf_closed_series(df, 15, lambda h: rsi(h["close"], p.rsi_length))

    entry_raw = (cci_5m < p.entry_cci_threshold) & (rsi_5m < 70) & (rsi_15m < 70) & (rsi_5m > 30)
    entry_raw = entry_raw.fillna(False)
    entry_signal = entry_raw & ~entry_raw.shift(1).fillna(False)
    entry_defined = cci_5m.notna() & rsi_5m.notna() & rsi_15m.notna()

    # per-order CCI series, cached by (interval, length) so identical
    # intervals aren't resampled twice
    order_cci_cache: dict[int, pd.Series] = {}

    def cci_at(interval_minutes: int) -> pd.Series:
        if interval_minutes not in order_cci_cache:
            if interval_minutes == 1:
                order_cci_cache[interval_minutes] = cci(
                    (df["high"] + df["low"] + df["close"]) / 3, p.entry_cci_length)
            else:
                order_cci_cache[interval_minutes] = htf_closed_series(
                    df, interval_minutes,
                    lambda h: cci((h["high"] + h["low"] + h["close"]) / 3, p.entry_cci_length))
        return order_cci_cache[interval_minutes]

    wr_1m = williams_r(df, p.wr_length)
    wr_5m = htf_closed_series(df, 5, lambda h: williams_r(h, p.wr_length))

    order_conditions: dict[int, pd.Series] = {}
    for order_idx, (interval, threshold, _confirmed) in ORDER_CCI_DEFAULT.items():
        cci_series = cci_at(interval)
        wr_series = wr_1m if ORDER_WR_INTERVAL == 1 else wr_5m
        cond = (cci_series < threshold) & (wr_series < ORDER_WR_THRESHOLD)
        order_conditions[order_idx] = cond.fillna(False)

    if p.tp_wr_op == "gt":
        tp_signal = wr_5m > p.tp_wr_threshold
    else:
        tp_signal = wr_5m < p.tp_wr_threshold
    tp_signal = tp_signal.fillna(False)

    return {
        "entry_signal": entry_signal, "entry_defined": entry_defined,
        "order_conditions": order_conditions, "tp_signal": tp_signal,
    }


# --------------------------------------------------------- walk-forward --

def simulate_symbol(df: pd.DataFrame, symbol: str, p: Params) -> list[Deal]:
    ind = compute_indicators(df, p)
    entry_signal = ind["entry_signal"]
    entry_defined = ind["entry_defined"]
    order_conditions = ind["order_conditions"]
    tp_signal = ind["tp_signal"]

    n = len(df)
    first_valid = entry_defined.idxmax() if entry_defined.any() else None
    if first_valid is None:
        return []

    close = df["close"].to_numpy()
    low = df["low"].to_numpy()

    deals: list[Deal] = []
    i = int(first_valid)
    in_deal = False
    orders: list[dict] = []
    next_order_idx = 2  # 1 = base, already filled on entry
    base_price = 0.0
    last_fill_price = 0.0
    deal_start_bar = -1

    def avg_entry_and_filled_pct():
        total_vol = sum(o["vol_pct"] for o in orders)
        weighted = sum(o["vol_pct"] * o["price"] for o in orders)
        return (weighted / total_vol), total_vol

    while i < n:
        if not in_deal:
            if bool(entry_signal.iloc[i]):
                base_price = close[i]
                orders = [{"price": base_price, "vol_pct": GRID[0][1]}]
                next_order_idx = 2
                last_fill_price = base_price
                deal_start_bar = i
                in_deal = True
            i += 1
            continue

        # pull-up: cancel remaining grid if price closed pullup_pct% above
        # the last filled order's price before the next one fills
        if p.pullup_pct > 0 and next_order_idx <= len(GRID) and close[i] >= last_fill_price * (1 + p.pullup_pct / 100.0):
            next_order_idx = len(GRID) + 1  # no more safety orders this deal

        # try to fill the next pending safety order
        if next_order_idx <= len(GRID):
            _, vol_pct, eff_offset = GRID[next_order_idx - 1]
            limit_price = base_price * (1 - eff_offset / 100.0)
            cond = order_conditions.get(next_order_idx)
            cond_true = bool(cond.iloc[i]) if cond is not None else True
            if low[i] <= limit_price and cond_true:
                orders.append({"price": limit_price, "vol_pct": vol_pct})
                last_fill_price = limit_price
                next_order_idx += 1

        avg_entry, filled_pct = avg_entry_and_filled_pct()
        pnl_now = (close[i] - avg_entry) / avg_entry * 100.0

        closed = False
        if bool(tp_signal.iloc[i]) and pnl_now >= p.min_pnl_pct:
            deals.append(Deal(
                symbol=symbol, entry_time=df["open_time"].iloc[deal_start_bar],
                exit_time=df["open_time"].iloc[i], orders_filled=len(orders),
                filled_pct=filled_pct, avg_entry_price=avg_entry, exit_price=close[i],
                reason="TP", bars_held=i - deal_start_bar, gross_pnl_pct=pnl_now,
            ))
            closed = True
        elif (i - deal_start_bar) >= p.max_deal_bars:
            deals.append(Deal(
                symbol=symbol, entry_time=df["open_time"].iloc[deal_start_bar],
                exit_time=df["open_time"].iloc[i], orders_filled=len(orders),
                filled_pct=filled_pct, avg_entry_price=avg_entry, exit_price=close[i],
                reason="TIMEOUT", bars_held=i - deal_start_bar, gross_pnl_pct=pnl_now,
            ))
            closed = True

        if closed:
            in_deal = False
            orders = []
        i += 1

    if in_deal:
        avg_entry, filled_pct = avg_entry_and_filled_pct()
        last_close = close[-1]
        gross = (last_close - avg_entry) / avg_entry * 100.0
        deals.append(Deal(
            symbol=symbol, entry_time=df["open_time"].iloc[deal_start_bar],
            exit_time=df["open_time"].iloc[-1], orders_filled=len(orders),
            filled_pct=filled_pct, avg_entry_price=avg_entry, exit_price=last_close,
            reason="OPEN_AT_CUTOFF", bars_held=(n - 1) - deal_start_bar, gross_pnl_pct=gross,
        ))

    return deals


# --------------------------------------------------------------- report --

def net_pnl_pct(deal: Deal, fee_rate: float) -> float | None:
    if deal.gross_pnl_pct is None:
        return None
    return deal.gross_pnl_pct - fee_rate * 100.0


def summarize(deals: list[Deal], label: str) -> None:
    if not deals:
        print(f"\n{label}: no deals opened in this window.")
        return
    resolved = [d for d in deals if d.reason in ("TP", "TIMEOUT")]
    still_open = [d for d in deals if d.reason == "OPEN_AT_CUTOFF"]
    wins = [d for d in resolved if d.gross_pnl_pct is not None and d.gross_pnl_pct > 0]
    win_rate = (len(wins) / len(resolved) * 100) if resolved else float("nan")
    avg_gross = (sum(d.gross_pnl_pct for d in resolved) / len(resolved)) if resolved else float("nan")
    avg_orders = (sum(d.orders_filled for d in deals) / len(deals)) if deals else float("nan")

    print(f"\n{label}")
    print(f"  Total deals opened:      {len(deals)}")
    print(f"  Resolved (TP/timeout):   {len(resolved)}   Still open at cutoff: {len(still_open)}")
    print(f"  Avg orders filled/deal:  {avg_orders:.2f}")
    print(f"  Gross win rate:          {win_rate:.1f}%")
    print(f"  Gross avg P&L% (invested):{avg_gross:+.2f}%")
    reasons = {}
    for d in resolved:
        reasons[d.reason] = reasons.get(d.reason, 0) + 1
    print(f"  Exit reasons: {reasons}")

    for label_fee, fee_rate in FEE_SCENARIOS.items():
        nets = [net_pnl_pct(d, fee_rate) for d in resolved]
        nets = [x for x in nets if x is not None]
        if not nets:
            continue
        net_wins = sum(1 for x in nets if x > 0)
        print(f"    net P&L% after {label_fee:12s} fees: {sum(nets)/len(nets):+.2f}%  "
              f"win rate {net_wins/len(nets)*100:.1f}%")


def save_csv(deals: list[Deal], path: Path) -> None:
    if not deals:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = ["symbol", "entry_time", "exit_time", "orders_filled", "filled_pct",
                  "avg_entry_price", "exit_price", "reason", "bars_held", "gross_pnl_pct"]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for d in deals:
            writer.writerow({k: getattr(d, k) for k in fieldnames})


def split_sample(deals: list[Deal]) -> tuple[list[Deal], list[Deal]]:
    resolved = sorted([d for d in deals if d.reason in ("TP", "TIMEOUT")], key=lambda d: d.entry_time)
    if len(resolved) < 4:
        return resolved, []
    mid = len(resolved) // 2
    return resolved[:mid], resolved[mid:]


# -------------------------------------------------------------------- --

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--symbol", nargs="+", default=["SOLUSDT"])
    parser.add_argument("--timeframe", default="1m", help="base execution timeframe (Veles' own bar-by-bar order-fill granularity)")
    parser.add_argument("--bars", type=int, default=200000)
    parser.add_argument("--out", default="cci_rsi_wr_signal_grid_backtest_out")

    parser.add_argument("--entry-cci-threshold", type=float, default=-100.0, help="ASSUMED -- see module docstring")
    parser.add_argument("--cci-length", type=int, default=20, help="ASSUMED")
    parser.add_argument("--rsi-length", type=int, default=14, help="ASSUMED")
    parser.add_argument("--wr-length", type=int, default=14, help="ASSUMED")

    parser.add_argument("--tp-wr-op", choices=["gt", "lt"], default="gt", help="ASSUMED direction of the take-profit Williams %%R condition")
    parser.add_argument("--tp-wr-threshold", type=float, default=-20.0, help="ASSUMED")
    parser.add_argument("--min-pnl-pct", type=float, default=5.0, help="CONFIRMED from screenshot")
    parser.add_argument("--pullup-pct", type=float, default=0.1, help="CONFIRMED value, APPROXIMATED mechanic -- see module docstring; 0 disables")
    parser.add_argument("--max-deal-bars", type=int, default=50000, help="safety timeout only, not part of the real bot")

    args = parser.parse_args()
    p = Params(
        entry_cci_length=args.cci_length, entry_cci_threshold=args.entry_cci_threshold,
        rsi_length=args.rsi_length, wr_length=args.wr_length,
        tp_wr_op=args.tp_wr_op, tp_wr_threshold=args.tp_wr_threshold,
        min_pnl_pct=args.min_pnl_pct, pullup_pct=args.pullup_pct,
        max_deal_bars=args.max_deal_bars,
    )

    print(__doc__)
    print("=" * 78)

    out_dir = Path(args.out)
    all_deals: list[Deal] = []
    for symbol in args.symbol:
        symbol = symbol.upper()
        print(f"\nFetching + simulating {symbol} ({args.bars} bars of {args.timeframe})...")
        try:
            df = fetch_history(symbol, args.timeframe, args.bars)
            deals = simulate_symbol(df, symbol, p)
        except DataError as exc:
            print(f"  [SKIP] {symbol}: {exc}")
            continue
        print(f"  {len(df)} bars, {df['open_time'].iloc[0]} .. {df['open_time'].iloc[-1]}")
        summarize(deals, symbol)
        save_csv(deals, out_dir / f"{symbol}_deals.csv")

        early, late = split_sample(deals)
        if early and late:
            summarize(early, f"  {symbol} -- EARLY half (split-sample)")
            summarize(late, f"  {symbol} -- LATE half (split-sample)")

        all_deals.extend(deals)
        time.sleep(2.0)  # 2026-09-05: avoid a rate-limit collision with the live bot on the same API key

    summarize(all_deals, "=== COMBINED (all symbols) ===")
    print(f"\nPer-deal CSVs written to {out_dir.resolve()}")


if __name__ == "__main__":
    main()
