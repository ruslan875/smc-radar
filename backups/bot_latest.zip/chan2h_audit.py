"""chan2h_audit.py — 2026-10-31. Почему бумажный «Пробой канала 2h» в минусе: сверка сделок бумаги с тестом
на тех же свечах (Bybit, 1h → 2h) с момента запуска бумаги. Тот же расчёт, что recheck_recent.chan (стоп центр, тейк 2R)."""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import pandas as pd  # noqa: E402
import recheck_recent as RR  # noqa: E402


def frame(sym):
    from app.data import get_klines  # noqa: PLC0415
    d = get_klines(sym, "1h", 1000).reset_index()
    ot = d["open_time"] if "open_time" in d else d[d.columns[0]]
    if pd.api.types.is_numeric_dtype(ot):
        tt = ot.astype("int64"); d["t"] = tt * 1000 if tt.max() < 1e11 else tt     # секунды или мс
    else:
        d["t"] = pd.to_datetime(ot, utc=True).dt.tz_convert(None).astype("datetime64[ms]").astype("int64")   # мс при любой точности pandas
    for k in ("open", "high", "low", "close"):
        d[k] = d[k].astype(float)
    ms = 7_200_000
    g = d.assign(b=d.t // ms * ms).groupby("b")
    x = pd.DataFrame({"t": g.t.first().index.values, "o": g.open.first().values.astype(float), "h": g.high.max().values.astype(float),
                      "l": g.low.min().values.astype(float), "c": g.close.last().values.astype(float)})
    if len(x) < 150:
        print(f"  {sym}: свечей 2h {len(x)}; колонки {list(d.columns)[:6]}; пример {d.iloc[0].to_dict()}", flush=True)
    return x[x.t + ms <= int(time.time() * 1000)].reset_index(drop=True)


def main():
    st = json.loads((BASE / "bt_lab_bots" / "chan_paper_2h.json").read_text(encoding="utf-8"))
    t0 = int(st["started"]); paper = st["trades"]
    syms = sorted({x["sym"] for x in paper} | {s.strip() + "USDT" for s in st["params"]["symbol"].split(",")})
    tot_t = tot_p = 0.0; nt = npp = match = 0
    for s in syms:
        try:
            d = frame(s)
        except Exception as e:  # noqa: BLE001
            print(s, "нет свечей:", str(e)[:80]); continue
        c = d.c.values; mid, sd = RR.rolling_reg(c); up, lo = mid + 2 * sd, mid - 2 * sd; sigs = []
        for i in range(101, len(c)):
            if c[i] > up[i] and c[i - 1] <= up[i - 1]:
                sigs.append((i, 1, mid[i]))
            elif c[i] < lo[i] and c[i - 1] >= lo[i - 1]:
                sigs.append((i, -1, mid[i]))
        tr = [(tt, r) for tt, r in RR.sim_fixed(d, sigs, 2.0, 100)]
        # сделки теста, открытые после запуска бумаги: восстанавливаем время входа
        test = []
        nxt = 0
        for i, sd_, stp in sigs:
            if i < nxt or i >= len(c) - 1:
                continue
            one = RR.sim_fixed(d, [(i, sd_, stp)], 2.0, 100)
            if not one:
                continue
            ct = one[0][0]; j = int(d.index[d.t == ct][0]); nxt = j + 1
            if int(d.t.iloc[i]) >= t0:
                test.append((int(d.t.iloc[i]), sd_, round(one[0][1], 2)))
        pp = [x for x in paper if x["sym"] == s]
        pin = {(x["open_t"], 1 if x["side"] == "LONG" else -1) for x in pp}
        m = sum(1 for tt, sd_, _r in test if (tt, sd_) in pin)
        rt = sum(r for *_x, r in test); rp = sum(x["r"] for x in pp)
        tot_t += rt; tot_p += rp; nt += len(test); npp += len(pp); match += m
        print(f"{s:<14} тест {len(test):>2} сд {rt:+6.1f}R · бумага {len(pp):>2} сд {rp:+6.1f}R · совпало входов {m}")
    print(f"\nИТОГО с {time.strftime('%d.%m %H:%M', time.gmtime(t0 / 1000))} UTC: тест {nt} сд {tot_t:+.1f}R · бумага {npp} сд {tot_p:+.1f}R · совпало входов {match}")
    print("готово")


if __name__ == "__main__":
    main()
