"""pump_dump_test.py — 2026-10-27. Честная проверка стратегий «памп / дамп» на свечах Bybit (1h, ~200 дней, все USDT-перпы с оборотом).
Памп = рост за 24 ч ≥ 18% (как в сканере). Дамп = падение за 24 ч ≥ 15%.
Варианты (комиссия+проскальзывание 0.13% на круг, вход по закрытию свечи, стоп проверяется раньше тейка):
  A  ЛОНГ продолжение пампа (как бумажный бот): стоп — минимум 12 свечей, цели 1/2/3R по трети, после TP1 стоп в БУ.
  B  ШОРТ отката после пампа: ждём первую свечу, закрывшуюся ниже минимума предыдущей; стоп — над максимумом пампа +0.2%,
     цели 1/2/3R по трети, после TP1 БУ, максимум 72 ч.
  C  то же, что B, но тейк — откат 50% всего пампа (одна цель), стоп над максимумом.
  D  ЛОНГ отскока после дампа: первая свеча, закрывшаяся выше максимума предыдущей; стоп под минимумом дампа, цели 1/2/3R.
  E  ШОРТ продолжения дампа: вход сразу, стоп — максимум 12 свечей, цели 1/2/3R.
Проверка: результат в R на сделку, по половинам периода (обе должны быть в плюсе) и число монет в плюсе.
Только чтение публичных данных. Ничего не торгует.
"""
from __future__ import annotations

import sys
import json
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass

API = "https://api.bybit.com/v5/market"
FEE = 0.0013
DAYS = 200


def get(url: str):
    for k in range(3):
        try:
            with urllib.request.urlopen(url, timeout=20) as r:
                return json.loads(r.read().decode())
        except Exception:  # noqa: BLE001
            time.sleep(1 + k)
    return {}


def coins() -> list[str]:
    j = get(f"{API}/tickers?category=linear")
    out = [(x["symbol"], float(x.get("turnover24h") or 0)) for x in j.get("result", {}).get("list", [])
           if x["symbol"].endswith("USDT")]
    out = [s for s, t in sorted(out, key=lambda z: -z[1]) if t > 3e6]
    return out[:220]


def klines(sym: str) -> list[tuple]:
    end = int(time.time() * 1000); start = end - DAYS * 86400_000; rows: dict[int, tuple] = {}
    cur = end
    while cur > start:
        j = get(f"{API}/kline?category=linear&symbol={sym}&interval=60&end={cur}&limit=1000")
        lst = j.get("result", {}).get("list", [])
        if not lst:
            break
        for x in lst:
            rows[int(x[0])] = (int(x[0]), float(x[1]), float(x[2]), float(x[3]), float(x[4]))
        cur = int(lst[-1][0]) - 1
        if len(lst) < 1000:
            break
    return [rows[k] for k in sorted(rows) if k >= start]


def run_trade(c, i0, side, entry, stop, targets, max_bars=72):
    """targets: list of (price, share). Возвращает R (после комиссии)."""
    risk = abs(entry - stop)
    if risk <= 0 or risk / entry > 0.5:
        return None
    left, r_sum, sl = 1.0, 0.0, stop
    tps = list(targets)
    for j in range(i0 + 1, min(len(c), i0 + 1 + max_bars)):
        _t, _o, h, l, cl = c[j]
        hit_sl = (l <= sl) if side > 0 else (h >= sl)
        if hit_sl:
            r_sum += left * side * (sl - entry) / risk; left = 0; break
        while tps:
            p, sh = tps[0]
            if (h >= p) if side > 0 else (l <= p):
                r_sum += sh * side * (p - entry) / risk; left -= sh; tps.pop(0)
                sl = entry   # после первой цели — безубыток
            else:
                break
        if left <= 1e-9:
            break
    if left > 1e-9:
        cl = c[min(len(c) - 1, i0 + max_bars)][4]
        r_sum += left * side * (cl - entry) / risk
    return r_sum - FEE * entry / risk


def test_coin(sym: str) -> dict:
    c = klines(sym)
    res = {k: [] for k in "ABCDE"}
    if len(c) < 300:
        return {"sym": sym, "res": res}
    busy = {k: -1 for k in "ABCDE"}
    for i in range(24, len(c) - 2):
        ch = c[i][4] / c[i - 24][4] - 1
        t = c[i][0]
        if ch >= 0.18:
            # A: лонг продолжение
            if i > busy["A"]:
                e = c[i][4]; s = min(x[3] for x in c[i - 12:i + 1]); r = e - s
                v = run_trade(c, i, 1, e, s, [(e + r, 1 / 3), (e + 2 * r, 1 / 3), (e + 3 * r, 1 / 3)])
                if v is not None:
                    res["A"].append((t, v)); busy["A"] = i + 24
            # B/C: шорт отката — ждём до 12 свечей первую свечу ниже минимума предыдущей
            if i > busy["B"]:
                lo24 = min(x[3] for x in c[i - 24:i + 1])
                for k in range(i + 1, min(len(c) - 1, i + 13)):
                    if c[k][4] < c[k - 1][3]:
                        hi = max(x[2] for x in c[i - 24:k + 1]); e = c[k][4]; s = hi * 1.002; r = s - e
                        v = run_trade(c, k, -1, e, s, [(e - r, 1 / 3), (e - 2 * r, 1 / 3), (e - 3 * r, 1 / 3)])
                        if v is not None:
                            res["B"].append((t, v))
                        tgt = hi - 0.5 * (hi - lo24)
                        if tgt < e:
                            v2 = run_trade(c, k, -1, e, s, [(tgt, 1.0)])
                            if v2 is not None:
                                res["C"].append((t, v2))
                        busy["B"] = k + 24
                        break
        if ch <= -0.15:
            if i > busy["D"]:
                for k in range(i + 1, min(len(c) - 1, i + 13)):
                    if c[k][4] > c[k - 1][2]:
                        lo = min(x[3] for x in c[i - 24:k + 1]); e = c[k][4]; s = lo * 0.998; r = e - s
                        v = run_trade(c, k, 1, e, s, [(e + r, 1 / 3), (e + 2 * r, 1 / 3), (e + 3 * r, 1 / 3)])
                        if v is not None:
                            res["D"].append((t, v))
                        busy["D"] = k + 24
                        break
            if i > busy["E"]:
                e = c[i][4]; s = max(x[2] for x in c[i - 12:i + 1]); r = s - e
                v = run_trade(c, i, -1, e, s, [(e - r, 1 / 3), (e - 2 * r, 1 / 3), (e - 3 * r, 1 / 3)])
                if v is not None:
                    res["E"].append((t, v)); busy["E"] = i + 24
    return {"sym": sym, "res": res}


NAMES = {"A": "ЛОНГ продолжение пампа (как бумажный бот)", "B": "ШОРТ отката после пампа, цели 1/2/3R",
         "C": "ШОРТ отката после пампа, тейк 50% пампа", "D": "ЛОНГ отскока после дампа",
         "E": "ШОРТ продолжения дампа"}

if __name__ == "__main__":
    cs = coins()
    print(f"монет: {len(cs)}, свечи 1h за {DAYS} дней Bybit… (несколько минут)")
    out = []
    with ThreadPoolExecutor(6) as ex:
        for n, r in enumerate(ex.map(test_coin, cs), 1):
            out.append(r)
            if n % 20 == 0:
                print(f"  {n}/{len(cs)}")
    mid = int(time.time() * 1000) - DAYS * 86400_000 // 2
    lines = []
    for k, nm in NAMES.items():
        all_ = [v for r in out for _t, v in r["res"][k]]
        if not all_:
            lines.append(f"{k} {nm}: сделок нет"); continue
        h1 = [v for r in out for t, v in r["res"][k] if t < mid]; h2 = [v for r in out for t, v in r["res"][k] if t >= mid]
        per = [sum(v for _t, v in r["res"][k]) for r in out if r["res"][k]]
        wr = sum(1 for v in all_ if v > 0) / len(all_) * 100
        ok = sum(all_) > 0 and sum(h1) > 0 and sum(h2) > 0 and len(all_) >= 60
        lines.append(f"{'✅' if ok else '❌'} {k} {nm}: {len(all_)} сд, итог {sum(all_):+.1f}R, {sum(all_) / len(all_):+.3f}R/сд, WR {wr:.0f}% | "
                     f"1-я половина {sum(h1):+.1f}R ({len(h1)}), 2-я {sum(h2):+.1f}R ({len(h2)}) | монет в плюсе {sum(1 for p in per if p > 0)}/{len(per)}")
    txt = "\n".join(lines)
    print("\n" + txt)
    print("\n✅ = плюс в обеих половинах и ≥60 сделок. Только такие варианты можно ставить бумажным ботом.")
    with open("pump_dump_test.txt", "w", encoding="utf-8") as f:
        f.write(txt + "\n")
    input("\nEnter — закрыть")
