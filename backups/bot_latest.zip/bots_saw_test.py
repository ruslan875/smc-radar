"""bots_saw_test.py — 2026-10-21. «Пила» таймфреймов 1m…4h для ВСЕХ бумажных (демо) ботов.
Та же логика стратегий и комиссии, что в okx_current_test.py (OKX мейкер 0.02% / тейкер 0.05%).
Данные: 1h-свечи OKX ~3 года (кеш chan_saw_test) → 1h/2h/4h; минутки OKX (кеш ginarea, 300 дней) → 5m/15m/30m;
1m — последние 60 дней (иначе тест идёт сутки). У минуток OKX нет объёма — стратегии с объёмом там приблизительны.
✅ = средний итог > 0, ≥ 8/12 монет в плюсе (или ≥60% своих монет), обе половины истории > 0.
Ничего не торгует. Запуск: bots_saw_test.bat [часть названия бота] → bt_lab_bots/bots_saw_test.txt
"""
from __future__ import annotations
import pickle, sys, time, traceback
from pathlib import Path
import numpy as np
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import okx_current_test as OC  # noqa: E402
import pack_strats_test as PS  # noqa: E402
import ginarea_op_test as G  # noqa: E402
from chan_saw_test import CACHE, COINS, rs_min  # noqa: E402

OUT = BASE / "bt_lab_bots" / "bots_saw_test.txt"
DAYS_1M = 60
TFS = ["1m", "5m", "15m", "30m", "1h", "2h", "4h"]
BOTS = [  # (название, функция → число, единица, свои монеты или None)
    ("Пробой канала N100 2R", OC.chan, "R", None),
    ("Donchian 20 тренд 3R", OC.donch4h, "R", None),
    ("KVOO волны 2R", OC.kvoo4h, "R", None),
    ("WhiteBox ShiftMA", OC.acct(OC.T3.TESTS["WhiteBox ShiftMA"]), "%", None),
    ("QFL DCA", OC.acct(OC.T3.TESTS["QFL DCA"]), "%", None),
    ("DCA Bot", OC.acct(OC.T4.TESTS["DCA Bot"]), "%", None),
    ("DCA Strategy", OC.acct(OC.T4.TESTS["DCA Strategy"]), "%", None),
    ("Ranged Volume DCA", OC.acct(OC.T4.TESTS["Ranged Volume DCA"]), "%", None),
    ("ChoCh разворот", lambda d: OC.SM.choch(d, 10)[0], "%", None),
    ("RSI+BB лонг стоп −15%", lambda d: OC.SM.rsi_bb(d, 1, 0.15)[0], "%", None),
    ("Liquidity Range MACD", lambda d: PS.run_reverse(d, PS.lrm_signals(d))[0], "%", None),
    ("OKX ETH RSI", OC.eth_rsi, "%", None),
    ("Paper10 High-Low Cloud", OC.paper10("High-Low Cloud"), "%", None),
]
LINES = []
def say(s=""):
    print(s, flush=True); LINES.append(s)
def save():
    OUT.parent.mkdir(exist_ok=True); OUT.write_text("\n".join(LINES), encoding="utf-8")

def load():
    raw = pickle.loads(CACHE.read_bytes()) if CACHE.exists() else {}
    if not raw:
        for s in COINS:
            print(f"  качаю {s} 1h с OKX…", flush=True); raw[s] = OC.okx_klines(s, "60", 3 * 365 * 24)
        CACHE.parent.mkdir(exist_ok=True); CACHE.write_bytes(pickle.dumps(raw))
    hours = {s: d for s, d in raw.items() if len(d["c"]) >= 3000}
    mins = {}
    for s in hours:
        for att in range(3):
            try:
                m = G.okx_1m(s.replace("USDT", "") + "-USDT-SWAP", 300)
                mins[s] = {"t": m.t.to_numpy().astype(np.int64), "o": m.o.to_numpy(float), "h": m.h.to_numpy(float),
                           "l": m.l.to_numpy(float), "c": m.c.to_numpy(float), "v": np.ones(len(m))}
                break
            except Exception as exc:  # noqa: BLE001
                print(f"  {s}: минутки, попытка {att + 1}: {exc}", flush=True); time.sleep(5)
    return hours, mins

def rs_min_v(d, k):
    x = rs_min(d, k)
    if k > 1:
        x["v"] = np.full(len(x["c"]), float(k))
    return x

def series(tf, hours, mins):
    for s in COINS:
        if tf.endswith("h"):
            if s not in hours:
                continue
            k = int(tf[:-1]); d = hours[s] if k == 1 else PS.resample(hours[s], k)
        else:
            if s not in mins:
                continue
            d0 = mins[s]
            if tf == "1m":
                cut = d0["t"] >= d0["t"][-1] - DAYS_1M * 864e5
                d0 = {kk: v[cut] for kk, v in d0.items()}
            d = rs_min_v(d0, int(tf[:-1]))
        if len(d["c"]) >= 600:
            yield s, d

def main():
    flt = " ".join(sys.argv[1:]).lower()
    bots = [b for b in BOTS if flt in b[0].lower()] or BOTS
    t0 = time.time()
    say(f"«Пила» ТФ 1m…4h для демо-ботов · OKX мейкер {OC.MK*100:.2f}% / тейкер {OC.TK*100:.2f}% · {time.strftime('%Y-%m-%d %H:%M')}")
    hours, mins = load()
    say(f"Монет: 1h {len(hours)}, минутки {len(mins)} · 1h–4h ~3 года, 5m–30m 300 дней, 1m {DAYS_1M} дней")
    table = {}
    for name, fn, unit, own in bots:
        say(""); say(f"=== {name} ===")
        say(f"{'ТФ':<5}{'средн.':>9}{'монет +':>9}{'1-я пол.':>10}{'2-я пол.':>10}")
        k = 100 if unit == "%" else 1
        for tf in TFS:
            full, h1, h2 = [], [], []
            for s, d in series(tf, hours, mins):
                if own and s not in own:
                    continue
                try:
                    full.append(fn(d)); h1.append(fn(OC.half(d, 0))); h2.append(fn(OC.half(d, 1)))
                except Exception as exc:  # noqa: BLE001
                    print(f"  {name} {tf} {s}: {type(exc).__name__}: {str(exc)[:80]}", flush=True)
            if len(full) < 3:
                say(f"{tf:<5}  нет данных/ошибка"); table[(name, tf)] = "—"; save(); continue
            avg, a1, a2 = np.mean(full) * k, np.mean(h1) * k, np.mean(h2) * k
            plus = sum(x > 0 for x in full)
            ok = avg > 0 and a1 > 0 and a2 > 0 and plus >= min(8, int(np.ceil(0.6 * len(full))))
            table[(name, tf)] = "✅" if ok else "❌"
            say(f"{tf:<5}{avg:>+8.1f}{unit}{f'{plus}/{len(full)}':>9}{a1:>+10.1f}{a2:>+10.1f}  {'✅' if ok else '❌'}"
                f"   ({time.time() - t0:.0f} с)")
            save()
    say(""); say("СВОДКА (✅ проходит, ❌ нет):")
    say(f"{'бот':<26}" + "".join(f"{tf:>5}" for tf in TFS))
    for name, *_ in bots:
        say(f"{name[:25]:<26}" + "".join(f"{table.get((name, tf), '—'):>5}" for tf in TFS))
    say(""); say("Устойчиво — ✅ на нескольких соседних ТФ подряд. Одиночный ✅ среди ❌ — скорее случайность.")
    save(); print(f"\nОтчёт: {OUT}  · заняло {(time.time() - t0) / 60:.0f} мин")

if __name__ == "__main__":
    try:
        main()
    except Exception:  # noqa: BLE001
        traceback.print_exc(); LINES.append(traceback.format_exc()); save()
