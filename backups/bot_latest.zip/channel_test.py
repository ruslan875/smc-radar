"""channel_test.py — 2026-10-04. Честная проверка торговли по каналу (регрессия, как «Канал» в KVOO).
Свечи берёт тем же загрузчиком, что kvoo_longtest (Binance USDT-фьючерсы с 2019, кэш market_cache/binance/).
Варианты:
  ОТСКОК  — тень коснулась границы канала (±k·sd), закрытие вернулось внутрь → вход по закрытию,
            стоп за тенью −0.3 ATR, тейк: центр канала или противоположная граница. С фильтром «только по наклону» и без.
  ПРОБОЙ  — закрытие за границей канала (была внутри) → вход по закрытию, стоп у центра, тейк 2R. С фильтром объёма ×1.5 и без.
Длина канала 53 и 100, ширина k = 2.0 sd. Одна сделка за раз на монету, лимит 100 свечей, комиссия+проскальзывание 0.11%.
Пересчёт канала на каждой свече только по прошлым данным (без подглядывания).
Итог: по ТФ/варианту — сделки, WR, R за 2019–2023 и отдельно 2024–2026 (проверка вперёд), сколько монет в плюсе.
Запуск: channel_test.bat. Результат также в channel_test.csv.
"""
import csv
import numpy as np
import pandas as pd

COST = 0.0011


def channel(c, n):
    s = pd.Series(c); x = np.arange(len(c), dtype=float); X = pd.Series(x)
    sx = X.rolling(n).sum(); sy = s.rolling(n).sum(); sxy = (X * s).rolling(n).sum(); sxx = (X * X).rolling(n).sum()
    b = (n * sxy - sx * sy) / (n * sxx - sx * sx); a = (sy - b * sx) / n
    mid = (a + b * x).values
    res = s - pd.Series(mid)  # приближение sd остатков: sd цены вокруг линии на окне
    sd = np.sqrt(((s * s).rolling(n).sum() - 2 * a * sy - 2 * b * sxy + n * a * a + 2 * a * b * sx + b * b * sxx).clip(lower=0) / n).values
    del res
    return mid, sd, b.values


def run(d, n, kind, opt):
    o, h, l, c, v, t = (d[k].values for k in "ohlcvt")
    pc = np.r_[c[0], c[:-1]]; tr = np.maximum(h - l, np.maximum(abs(h - pc), abs(l - pc)))
    atr = pd.Series(tr).ewm(alpha=1 / 14, adjust=False).mean().values
    mid, sd, slope = channel(c, n); up, lo = mid + 2 * sd, mid - 2 * sd
    vma = pd.Series(v).rolling(20).mean().values
    out = []; i = n + 1
    while i < len(c) - 1:
        sig = 0
        if kind == "bounce":
            if l[i] <= lo[i] < c[i] and (opt != "trend" or slope[i] > 0): sig, stop = 1, l[i] - 0.3 * atr[i]
            elif h[i] >= up[i] > c[i] and (opt != "trend" or slope[i] < 0): sig, stop = -1, h[i] + 0.3 * atr[i]
            if sig: tp = mid[i] if opt in ("mid", "trend") else (up[i] if sig > 0 else lo[i])
        else:
            vol_ok = opt != "vol" or v[i] > 1.5 * vma[i]
            if c[i] > up[i] and c[i - 1] <= up[i - 1] and vol_ok: sig, stop = 1, mid[i]
            elif c[i] < lo[i] and c[i - 1] >= lo[i - 1] and vol_ok: sig, stop = -1, mid[i]
            if sig: tp = c[i] + sig * 2 * abs(c[i] - stop)
        if not sig:
            i += 1; continue
        e = c[i]; risk = abs(e - stop)
        if risk <= 0 or sig * (tp - e) <= 0:
            i += 1; continue
        r = None
        for j in range(i + 1, min(len(c), i + 101)):
            if (l[j] <= stop) if sig > 0 else (h[j] >= stop): r = -1.0; break
            if (h[j] >= tp) if sig > 0 else (l[j] <= tp): r = abs(tp - e) / risk; break
        else:
            r = sig * (c[j] - e) / risk
        out.append((t[i], r - COST * e / risk)); i = j + 1
    return out


VARS = [("bounce", "mid", "Отскок → центр"), ("bounce", "far", "Отскок → др. граница"), ("bounce", "trend", "Отскок по наклону → центр"),
        ("break", "any", "Пробой 2R"), ("break", "vol", "Пробой + объём×1.5 2R")]
CUT = pd.Timestamp("2024-01-01", tz="UTC").value // 10**6

if __name__ == "__main__":
    import kvoo_longtest as K  # только здесь: иначе импорт запускал весь тест KVOO
    data = {}
    for tf in K.TFS:
        for s in K.COINS:
            print("загрузка", s, tf); d = K.load(s, tf)
            if d is not None and len(d) > 500: data[(s, tf)] = d
    rows = []
    for tf in K.TFS:
        for n in (53, 100):
            for kind, opt, name in VARS:
                old = new = 0.0; nt = wins = 0; plus = 0; per = {}
                for s in K.COINS:
                    if (s, tf) not in data: continue
                    tr = run(data[(s, tf)], n, kind, opt)
                    rs = sum(r for _, r in tr); per[s] = rs; plus += rs > 0
                    for tt, r in tr:
                        nt += 1; wins += r > 0
                        if tt < CUT: old += r
                        else: new += r
                row = {"tf": tf, "len": n, "вариант": name, "сделок": nt, "WR%": round(100 * wins / max(1, nt), 1),
                       "R_2019_23": round(old, 1), "R_2024_26": round(new, 1), "монет_в_плюсе": f"{plus}/{len(per)}",
                       **{k.replace("USDT", ""): round(v, 1) for k, v in per.items()}}
                rows.append(row)
                print(f"{tf} канал {n:3} | {name:28} | сделок {nt:5} WR {row['WR%']:5}% | до 2024 {old:+8.1f}R | 2024–26 {new:+7.1f}R | монет+ {plus}/{len(per)}")
    keys = sorted({k for r in rows for k in r}, key=lambda k: list(rows[0]).index(k) if k in rows[0] else 99)
    with open(K.BASE / "channel_test.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=keys, delimiter=";"); w.writeheader(); w.writerows(rows)
    print("\nГотово. Пришлите скрин этой таблицы или файл channel_test.csv")
    input("Enter — закрыть")
