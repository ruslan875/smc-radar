# -*- coding: utf-8 -*-
"""Прогон «родных» OKX-стратегий на данных OKX (2026-10-08). Запуск на ПК: python okx_native_run.py
Качает OKX swap свечи (history-candles) с 2024-01-01 + Bybit OI 1h, кэш в okx_native_cache/.
Стратегии: Pavlova (PAVLOVA_BTC_1H_OKX.csv), R4 (R4_OKX_HYPE_1H.csv, логика из SKILL_EN.md).
Комиссия 0.05%/сторону (OKX taker). Итог в okx_native_report.txt."""
import os, sys, json, time, urllib.request
import numpy as np, pandas as pd
HERE = os.path.dirname(os.path.abspath(__file__)); CACHE = os.path.join(HERE, "okx_native_cache"); os.makedirs(CACHE, exist_ok=True)
sys.path.insert(0, HERE)
from pavlova_native import run as pav_run, rma, ema
FEE = 0.0005
OUT = None
def say(*a):
    global OUT
    if OUT is None: OUT = open(os.path.join(HERE, "okx_native_report.txt"), "w", encoding="utf-8")
    s = " ".join(str(x) for x in a); print(s, flush=True); OUT.write(s + "\n"); OUT.flush()

def get(url, tries=6):
    for k in range(tries):
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"}), timeout=20) as r:
                return json.loads(r.read())
        except Exception as e:
            time.sleep(2 * (k + 1))
    raise RuntimeError("нет ответа: " + url)

def okx(inst, bar, start="2024-01-01"):
    f = os.path.join(CACHE, f"{inst}_{bar}.csv")
    if os.path.exists(f) and time.time() - os.path.getmtime(f) < 6 * 3600:
        d = pd.read_csv(f)
    else:
        t0 = int(pd.Timestamp(start).timestamp() * 1000); rows = []; after = ""
        while True:
            j = get(f"https://www.okx.com/api/v5/market/history-candles?instId={inst}&bar={bar}&limit=100" + (f"&after={after}" if after else ""))
            data = j.get("data", [])
            if not data: break
            rows += data; after = data[-1][0]
            if int(after) <= t0: break
            if len(rows) % 3000 == 0: print(f"  {inst} {bar}: {len(rows)} свечей...", flush=True)
            time.sleep(0.12)
        d = pd.DataFrame([[int(r[0]), *map(float, r[1:6])] for r in rows], columns=["t", "o", "h", "l", "c", "v"])
        d = d[d.t >= t0].drop_duplicates("t").sort_values("t"); d.to_csv(f, index=False)
    d.index = pd.to_datetime(d.t, unit="ms"); return d[["o", "h", "l", "c", "v"]]

def bybit_oi(sym, start="2024-01-01"):
    f = os.path.join(CACHE, f"{sym}_oi_1h.csv")
    if os.path.exists(f) and time.time() - os.path.getmtime(f) < 6 * 3600:
        d = pd.read_csv(f)
    else:
        t0 = int(pd.Timestamp(start).timestamp() * 1000); end = int(time.time() * 1000); rows = []
        while end > t0:
            j = get(f"https://api.bybit.com/v5/market/open-interest?category=linear&symbol={sym}&intervalTime=1h&limit=200&endTime={end}")
            lst = j.get("result", {}).get("list", [])
            if not lst: break
            rows += [(int(x["timestamp"]), float(x["openInterest"])) for x in lst]
            end = min(int(x["timestamp"]) for x in lst) - 1; time.sleep(0.1)
        d = pd.DataFrame(rows, columns=["t", "oi"]).drop_duplicates("t").sort_values("t"); d.to_csv(f, index=False)
    d.index = pd.to_datetime(d.t, unit="ms"); return d["oi"]

def stats(t):
    if t.empty: return "нет сделок"
    eq = (1 + t.r).cumprod(); dd = (1 - eq / eq.cummax()).max(); pf = t.r[t.r > 0].sum() / max(-t.r[t.r < 0].sum(), 1e-12)
    yrs = ", ".join(f"{y}: {((1 + g.r).prod() - 1) * 100:+.0f}%" for y, g in t.groupby(t.t.dt.year))
    return f"сделок {len(t)}, win {100 * (t.r > 0).mean():.0f}%, PF {pf:.2f}, итог {(eq.iloc[-1] - 1) * 100:+.0f}%, DD {dd * 100:.0f}% | {yrs}"

# ---------------- R4 (логика SKILL_EN.md, параметры R4_OKX_HYPE_1H.csv) ----------------
R4 = dict(win=76, hi=38.2, lo=88.6, maxcross=6, slL=9.0, slS=8.0, m_atr=17, m_mult=2.3, m_sp=1.3, m_off=0.0,
          beL=(2.0, 0.5), beS=(2.4, 0.6), frac=(0.1, 0.2, 0.3, 0.4), atrL=0.27, adxL=(10, 65), adxS=(19, 60),
          slope=(50, 6, 0.0005), impL=0.23, volL=0.35, volS=0.38, chopL=56, cvd_len=300, cvdL=91, cvdS=87,
          rsiL=(39, 85), rsiS=(24, 46), noiL=(1, 100), noiS=(1, 99), z_len=60, zL=-3, zS=1.8, natrL=(0.7, 2.4), natrS=(0.9, 3.3))

def r4_run(d, oi=None, ref=None, filters=True):
    p = R4; O, H, L, C, V = [d[k].values for k in "ohlcv"]; n = len(C)
    pc = np.r_[C[0], C[:-1]]; tr = np.maximum(H - L, np.maximum(abs(H - pc), abs(L - pc)))
    # фибо-канал
    hh = pd.Series(H).rolling(p["win"]).max().values; ll = pd.Series(L).rolling(p["win"]).min().values; rg = hh - ll
    hiT = hh - rg * p["hi"] / 100; mid = hh - rg * 0.5; loT = hh - rg * p["lo"] / 100
    bull = (np.r_[np.nan, L[:-1]] < hiT) & (C >= hiT); bear = (np.r_[np.nan, H[:-1]] > loT) & (C <= loT)
    # mirror fibo
    at = ema(tr, p["m_atr"]); off = p["m_mult"] * at; up = np.zeros(n); dn = np.zeros(n); dr = np.ones(n); ex = np.zeros(n)
    up[0] = H[0] - off[0] if not np.isnan(off[0]) else L[0]; dn[0] = L[0]; ex[0] = H[0]
    for i in range(1, n):
        bs = H[i] - (off[i] if not np.isnan(off[i]) else 0); ss = L[i] + (off[i] if not np.isnan(off[i]) else 0)
        up[i] = max(bs, up[i-1]) if C[i-1] > up[i-1] else bs
        dn[i] = min(ss, dn[i-1]) if C[i-1] < dn[i-1] else ss
        dr[i] = 1 if C[i] > dn[i-1] else -1 if C[i] < up[i-1] else dr[i-1]
        ex[i] = (H[i] if dr[i] == 1 else L[i]) if dr[i] != dr[i-1] else (max(ex[i-1], H[i]) if dr[i] == 1 else min(ex[i-1], L[i]))
    trail = np.where(dr == 1, up, dn)
    def tps(i):
        e, t = ex[i], trail[i]; f1, f2, f3 = (e + (t - e) * k for k in (0.618, 0.786, 0.886))
        b1, b2, b3, b4 = e + (e - f1), e + (e - f2), e + (e - f3), e + (e - t); pv = b1; o = abs(e - t) * p["m_off"] * dr[i]
        return [pv + o, pv + (b2 - pv) * p["m_sp"] + o, pv + (b3 - pv) * p["m_sp"] + o, pv + (b4 - pv) * p["m_sp"] + o]
    # фильтры
    up_ = H - np.r_[np.nan, H[:-1]]; dn_ = np.r_[np.nan, L[:-1]] - L
    pdm = np.where((up_ > dn_) & (up_ > 0), up_, 0.); mdm = np.where((dn_ > up_) & (dn_ > 0), dn_, 0.)
    trs = rma(tr, 14); pdi = 100 * rma(pdm, 14) / trs; mdi = 100 * rma(mdm, 14) / trs
    adx = rma(np.where(pdi + mdi != 0, 100 * abs(pdi - mdi) / (pdi + mdi), 0), 14); atr14 = rma(tr, 14); natr = 100 * atr14 / C
    se = ema(C, p["slope"][0]); sl_ = (se - np.r_[[np.nan] * p["slope"][1], se[:-p["slope"][1]]]) / np.r_[[np.nan] * p["slope"][1], se[:-p["slope"][1]]] * 100
    body = abs(C - O); ab = pd.Series(body).rolling(20).mean().values; av = pd.Series(V).rolling(20).mean().values
    lo14 = pd.Series(np.minimum(L, pc)).rolling(14).min().values; hi14 = pd.Series(np.maximum(H, pc)).rolling(14).max().values
    chop = pd.Series(100 * np.log10(pd.Series(tr).rolling(14).sum().values / (hi14 - lo14)) / np.log10(14)).rolling(4).mean().values
    delta = np.where(C > O, V, np.where(C < O, -V, 0.)); cum = np.cumsum(delta); roll = cum - pd.Series(cum).shift(p["cvd_len"]).fillna(0).values
    sm = ema(roll, 20); am = np.maximum(abs(pd.Series(sm).rolling(p["cvd_len"]).max().values), abs(pd.Series(sm).rolling(p["cvd_len"]).min().values))
    cvd = (np.where(am != 0, sm / am, 0) + 1) * 50
    ch = np.diff(C, prepend=np.nan); rsi = 100 - 100 / (1 + rma(np.maximum(ch, 0), 14) / rma(np.maximum(-ch, 0), 14))
    if oi is not None:
        o_ = oi.reindex(d.index, method="ffill").values; ol = pd.Series(o_).rolling(300).min().values; oh = pd.Series(o_).rolling(300).max().values
        noi = np.where(oh - ol != 0, (o_ - ol) / (oh - ol) * 100, np.nan)
    else: noi = np.full(n, np.nan)
    hl2 = (H + L) / 2; zs = (hl2 - pd.Series(hl2).rolling(p["z_len"]).mean().values) / pd.Series(hl2).rolling(p["z_len"]).std(ddof=0).values
    if ref is not None:
        r_ = ref.reindex(d.index, method="ffill").values; zr = (r_ - pd.Series(r_).rolling(p["z_len"]).mean().values) / pd.Series(r_).rolling(p["z_len"]).std(ddof=0).values; zd = zs - zr
    else: zd = np.full(n, np.nan)
    inr = lambda x, a, b: np.isnan(x) or a <= x <= b
    def okL(i):
        if not filters: return True
        return (atr14[i] >= p["atrL"] * (C[i] / C[i] if True else 1) if False else True) and inr(adx[i], *p["adxL"]) and (sl_[i] >= p["slope"][2]) \
            and body[i] > ab[i] * p["impL"] and V[i] > av[i] * p["volL"] and (not np.isnan(chop[i]) and chop[i] < p["chopL"]) and cvd[i] <= p["cvdL"] \
            and inr(rsi[i], *p["rsiL"]) and inr(noi[i], *p["noiL"]) and (np.isnan(zd[i]) or zd[i] > p["zL"]) and inr(natr[i], *p["natrL"])
    def okS(i):
        if not filters: return True
        return inr(adx[i], *p["adxS"]) and V[i] > av[i] * p["volS"] and cvd[i] <= p["cvdS"] and inr(rsi[i], *p["rsiS"]) \
            and inr(noi[i], *p["noiS"]) and (np.isnan(zd[i]) or zd[i] < p["zS"]) and inr(natr[i], *p["natrS"])
    lastB = lastS = -10 ** 9; isBull = isBear = False; pos = None; out = []
    for i in range(p["win"] + 2, n):
        if bull[i]: lastB = i
        if bear[i]: lastS = i
        if pos:   # управление открытой позицией на свече i
            s = pos["s"]; done = False
            if (L[i] <= pos["sl"]) if s > 0 else (H[i] >= pos["sl"]):
                pos["pnl"] += pos["left"] * (s * (pos["sl"] - pos["e"]) / pos["e"] - FEE); done = True; why = "SL"
            else:
                for k in range(pos["k"], 4):
                    if (H[i] >= pos["tp"][k]) if s > 0 else (L[i] <= pos["tp"][k]):
                        pos["pnl"] += p["frac"][k] * (s * (pos["tp"][k] - pos["e"]) / pos["e"] - FEE); pos["left"] -= p["frac"][k]; pos["k"] = k + 1
                    else: break
                if pos["k"] == 4: done = True; why = "TP4"
            if not done and not pos["be"]:
                trig, offp = p["beL"] if s > 0 else p["beS"]
                if (C[i] >= pos["e"] * (1 + trig / 100)) if s > 0 else (C[i] <= pos["e"] * (1 - trig / 100)):
                    pos["sl"] = pos["e"] * (1 + s * offp / 100); pos["be"] = True
            if done:
                out.append((pos["t"], pos["pnl"] - FEE))
                if s > 0: isBull = False
                else: isBear = False
                pos = None
            continue
        if C[i] >= mid[i] and C[i] >= hiT[i] and not isBull and 0 <= i - lastB <= p["maxcross"] and okL(i): s = 1
        elif C[i] <= mid[i] and C[i] <= loT[i] and not isBear and 0 <= i - lastS <= p["maxcross"] and okS(i): s = -1
        else: continue
        e = C[i]; raw = tps(i); tp = []
        for x in raw:
            if (x <= e) if s > 0 else (x >= e): x = e + (e - x)
            tp.append(max(x, e * 1.0000001) if s > 0 else min(x, e * 0.9999999))
        tp = sorted(tp) if s > 0 else sorted(tp, reverse=True)
        pos = dict(s=s, e=e, t=d.index[i], sl=e * (1 - s * (p["slL"] if s > 0 else p["slS"]) / 100), tp=tp, k=0, left=1.0, pnl=0.0, be=False)
        isBull, isBear = (True, False) if s > 0 else (False, True)
    r4_run.open = dict(t=pos["t"], side=pos["s"], e=pos["e"], sl=pos["sl"], tp=pos["tp"][-1]) if pos else None
    return pd.DataFrame(out, columns=["t", "r"])

def main():
    say("=" * 100); say("OKX — РОДНЫЕ НАСТРОЙКИ, данные OKX swap с 2024-01-01, комиссия 0.05%/сторону"); say("=" * 100)
    btc = okx("BTC-USDT-SWAP", "1H")
    say("\n## Pavlova Combo(OB+TC+MF) — настройки PAVLOVA_BTC_1H_OKX.csv (стоп 1.8% / тейк 4.6%)")
    for c in ("BTC", "ETH", "SOL", "XRP", "DOGE", "HYPE"):
        try:
            d = okx(f"{c}-USDT-SWAP", "1H"); t = pav_run(d, FEE)
            say(f"  {c:5} 1h {'(РОДНАЯ)' if c == 'BTC' else '        '} {stats(t)}")
        except Exception as e: say(f"  {c}: ошибка {e}")
    say("\n## R4 Mirror Fibo — настройки R4_OKX_HYPE_1H.csv, логика из SKILL_EN.md (TP 10/20/30/40%, БУ, nOI = Bybit OI)")
    for c in ("HYPE", "ETH", "BTC", "SOL", "XRP", "DOGE"):
        try:
            d = okx(f"{c}-USDT-SWAP", "1H")
            try: oi = bybit_oi(f"{c}USDT")
            except Exception: oi = None
            for flt in (True, False):
                t = r4_run(d, oi, btc["c"] if c != "BTC" else None, flt)
                say(f"  {c:5} 1h {'(РОДНАЯ)' if c == 'HYPE' else '        '} {'с фильтрами ' if flt else 'без фильтров'} {stats(t)}")
        except Exception as e: say(f"  {c}: ошибка {e}")
    say("\nГОТОВО. Пришлите этот файл.")

if __name__ == "__main__":
    main()
