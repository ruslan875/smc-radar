#!/usr/bin/env python3
"""
Order Block Strategy (OBS.V1) - Python port of order_block_strategy_obs_v1.pine
================================================================================

SOURCE: strategies/order_block_strategy_obs_v1.pine (v6, (c) g79029831521)

WHAT IT DOES

Swing highs and lows are tracked with a LuxAlgo-style state machine over a
13-bar lookback. When price closes through an un-crossed swing high, the
script walks back to the lowest candle body since that swing and records it as
a bullish order block - top and bottom taken from that candle's body, not its
wicks. Mirror image for bearish blocks. A block is discarded once price closes
through its far side.

Entries are retests: price dipping into the newest bullish block and closing
back above it goes long, and the bearish mirror goes short. There is a partial
take when price reaches the opposing block, and a full exit when it goes
through it. Fixed stop 1.1% and target 3.2% from the average entry price.

THREE BUGS IN THE SOURCE, AND WHAT THIS PORT DOES WITH EACH

1. THE OBJECT SINGLETON - fixed here.

       newOB(float t, float b) =>
           var obj = OB.new()       // <- `var`, so ONE object per call site
           obj.top := t
           obj.bottom := b
           obj

   `var` inside a function makes the object persist across bars, so every call
   returns the SAME object and every element pushed into the array is a
   reference to it. Writing a new block silently rewrites all of them. The
   array of zones degenerates into "the latest zone, repeated". This is not a
   subtlety of the strategy - it means the script on TradingView is not doing
   what its own code describes, so reproducing it would measure a typo. Here
   each block is its own object.

2. THE PYRAMID THAT NEVER HAPPENS - reproduced, with a flag.

   The header declares `pyramiding = 1` while the body is written for up to six
   entries, gated by `math.abs(strategy.position_size) < 6`. That compares a
   COIN quantity, not a number of entries: with 100% of a $1000 equity, a BTC
   position is ~0.016 and always passes, while a cheap altcoin position is in
   the thousands and never does. Either way `pyramiding = 1` caps it at one
   entry, so the whole adding-up branch is dead code. The port defaults to one
   entry, which is what TradingView actually runs. --pyramid N enables the
   intended behaviour and counts ENTRIES, which is what the check meant.

3. THE ENTRY CONDITION'S PRECEDENCE - reproduced, with a flag.

       bullishEntryCondition = not na(bullBottom) and not na(bullTop) and
         (low <= bullBottom and close > bullBottom)  or (low <= bullTop and close >= bullTop)

   `and` binds tighter than `or`, so the na-guards only protect the first half.
   The second half stands alone. Comparisons against na are false in Pine so it
   does not error, but it is not what the layout suggests was meant.
   Reproduced as written; --fix-entry-precedence brackets it the way it reads.

WHAT THE STOP REALLY IS

The script does not place stop orders. It checks the level itself and calls
strategy.close, which is a MARKET order - so a stop touched anywhere inside a
bar exits at the NEXT bar's open, not at the stop price. In a gap or a fast
candle that is a materially worse fill than the level suggests, and it is the
honest default here. --true-stop fills at the level instead, and the gap
between the two runs is the cost of implementing a stop this way.

Costs come from --commission and --slippage-pct. The Pine charges 0.022%,
which is below Bybit's taker fee; the runner passes the real one.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

from port_common import (deals_frame, load_sources, net_pnl_pct, print_summary,
                         write_manifest)

DEFAULTS = {
    "length": 13,
    "partial_close_pct": 50.0,
    "stop_loss_pct": 1.1,
    "take_profit_pct": 3.2,
    "enable_sl": True,
    "enable_tp": True,
    "pyramid": 1,
}


# ---------------------------------------------------------------------------
# swings and order blocks
# ---------------------------------------------------------------------------

def build_zones(df: pd.DataFrame, length: int):
    """Walk the bars once, maintaining swings and the two order-block stacks.

    Returns four arrays aligned to df: bull_top, bull_bottom, bear_top,
    bear_bottom - each the newest block of its kind, or NaN when there is none.
    """
    high = df["high"].to_numpy(dtype=float)
    low = df["low"].to_numpy(dtype=float)
    open_ = df["open"].to_numpy(dtype=float)
    close = df["close"].to_numpy(dtype=float)
    n = len(df)

    body_hi = np.maximum(open_, close)
    body_lo = np.minimum(open_, close)

    roll_hi = pd.Series(high).rolling(length, min_periods=length).max().to_numpy()
    roll_lo = pd.Series(low).rolling(length, min_periods=length).min().to_numpy()

    bull_top = np.full(n, np.nan)
    bull_bot = np.full(n, np.nan)
    bear_top = np.full(n, np.nan)
    bear_bot = np.full(n, np.nan)

    os_state = 0
    prev_os = 0
    top_swing = {"price": np.nan, "bar": -1, "crossed": False}
    bot_swing = {"price": np.nan, "bar": -1, "crossed": False}
    bull_obs: list = []      # index 0 = newest, as Pine's array.unshift gives
    bear_obs: list = []

    for i in range(n):
        # --- swing state machine ----------------------------------------
        if i >= length and not np.isnan(roll_hi[i]):
            if high[i - length] > roll_hi[i]:
                os_state = 0
            elif low[i - length] < roll_lo[i]:
                os_state = 1
            if os_state == 0 and prev_os != 0:
                top_swing = {"price": high[i - length], "bar": i - length, "crossed": False}
            if os_state == 1 and prev_os != 1:
                bot_swing = {"price": low[i - length], "bar": i - length, "crossed": False}
            prev_os = os_state

        # --- new bullish block on a close through an un-crossed swing high --
        if (not np.isnan(top_swing["price"]) and close[i] > top_swing["price"]
                and not top_swing["crossed"]):
            top_swing["crossed"] = True
            minima = body_hi[i - 1] if i > 0 else body_hi[i]
            maxima = body_lo[i - 1] if i > 0 else body_lo[i]
            bars_back = i - top_swing["bar"]
            if bars_back > 0:
                for k in range(1, min(bars_back, i) + 1):
                    if body_lo[i - k] <= minima:
                        minima = body_lo[i - k]
                        maxima = body_hi[i - k]
            bull_obs.insert(0, {"top": maxima, "bottom": minima})

        # --- invalidate the first bullish block price closed under ----------
        for k, ob in enumerate(bull_obs):
            if close[i] < ob["bottom"]:
                bull_obs.pop(k)
                break

        # --- bearish mirror -------------------------------------------------
        if (not np.isnan(bot_swing["price"]) and close[i] < bot_swing["price"]
                and not bot_swing["crossed"]):
            bot_swing["crossed"] = True
            minima = body_lo[i - 1] if i > 0 else body_lo[i]
            maxima = body_hi[i - 1] if i > 0 else body_hi[i]
            bars_back = i - bot_swing["bar"]
            if bars_back > 0:
                for k in range(1, min(bars_back, i) + 1):
                    if body_hi[i - k] >= maxima:
                        maxima = body_hi[i - k]
                        minima = body_lo[i - k]
            bear_obs.insert(0, {"top": maxima, "bottom": minima})

        for k, ob in enumerate(bear_obs):
            if close[i] > ob["top"]:
                bear_obs.pop(k)
                break

        if bull_obs:
            bull_top[i], bull_bot[i] = bull_obs[0]["top"], bull_obs[0]["bottom"]
        if bear_obs:
            bear_top[i], bear_bot[i] = bear_obs[0]["top"], bear_obs[0]["bottom"]

    return bull_top, bull_bot, bear_top, bear_bot


def compute_signals(df: pd.DataFrame, cfg: dict, fix_precedence: bool) -> pd.DataFrame:
    out = df.copy()
    bt, bb, rt, rb = build_zones(out, cfg["length"])
    out["bull_top"], out["bull_bottom"] = bt, bb
    out["bear_top"], out["bear_bottom"] = rt, rb

    low, high, close = out["low"], out["high"], out["close"]

    def nn(s):
        return s.notna()

    bull_a = nn(out["bull_bottom"]) & nn(out["bull_top"]) & (low <= out["bull_bottom"]) & (close > out["bull_bottom"])
    bull_b = (low <= out["bull_top"]) & (close >= out["bull_top"])
    bear_a = nn(out["bear_top"]) & nn(out["bear_bottom"]) & (high >= out["bear_top"]) & (close < out["bear_top"])
    bear_b = (high >= out["bear_bottom"]) & (close <= out["bear_bottom"])

    if fix_precedence:
        guard_bull = nn(out["bull_bottom"]) & nn(out["bull_top"])
        guard_bear = nn(out["bear_top"]) & nn(out["bear_bottom"])
        out["long_signal"] = guard_bull & (bull_a | bull_b)
        out["short_signal"] = guard_bear & (bear_a | bear_b)
    else:
        out["long_signal"] = bull_a | bull_b        # precedence exactly as written
        out["short_signal"] = bear_a | bear_b

    out["long_signal"] = out["long_signal"].fillna(False)
    out["short_signal"] = out["short_signal"].fillna(False)
    return out


# ---------------------------------------------------------------------------
# backtest
# ---------------------------------------------------------------------------

def run_backtest(df: pd.DataFrame, cfg: dict, commission_pct: float,
                 slippage_pct: float, true_stop: bool) -> pd.DataFrame:
    """One row per POSITION, not per fill.

    Partial exits are folded into the position's row as a size-weighted average
    exit, so a half-close does not appear in the statistics as a whole extra
    trade. `partials` records how many there were and `entries` how many fills
    built the position.
    """
    deals = []
    pos = None
    pending = None          # (kind, payload) executed at the next bar's open

    idx = df.index
    o, h, l, c = (df[k].to_numpy(dtype=float) for k in ("open", "high", "low", "close"))
    bull_bot = df["bull_bottom"].to_numpy(dtype=float)
    bull_top = df["bull_top"].to_numpy(dtype=float)
    bear_top = df["bear_top"].to_numpy(dtype=float)
    bear_bot = df["bear_bottom"].to_numpy(dtype=float)
    ls = df["long_signal"].to_numpy(dtype=bool)
    ss = df["short_signal"].to_numpy(dtype=bool)

    def book(price, frac, ts, reason):
        """Record a closed fraction against the open position."""
        pos["exit_value"] += frac * price
        pos["closed"] += frac
        pos["last_reason"] = reason
        pos["last_time"] = ts

    def finish():
        nonlocal pos
        avg_exit = pos["exit_value"] / pos["closed"] if pos["closed"] else np.nan
        deals.append({
            "entry_time": pos["entry_time"], "exit_time": pos["last_time"],
            "side": pos["side"], "entry_price": pos["entry_price"],
            "exit_price": avg_exit,
            "gross_pnl_pct": net_pnl_pct(pos["side"], pos["entry_price"], avg_exit,
                                         commission_pct, slippage_pct),
            "reason": pos["last_reason"],
            "entries": pos["entries"], "partials": pos["partials"]})
        pos = None

    def stop_level():
        s = cfg["stop_loss_pct"] / 100
        return pos["entry_price"] * (1 - s) if pos["side"] == "long" \
            else pos["entry_price"] * (1 + s)

    def target_level():
        t = cfg["take_profit_pct"] / 100
        return pos["entry_price"] * (1 + t) if pos["side"] == "long" \
            else pos["entry_price"] * (1 - t)

    for i in range(len(df)):
        ts = idx[i]

        # ---- execute what the previous bar decided, at this open -----------
        if pending is not None:
            kind, payload = pending
            pending = None
            if kind == "entry":
                side = payload
                if pos is None:
                    pos = {"side": side, "entry_time": ts, "entry_price": o[i],
                           "closed": 0.0, "exit_value": 0.0, "entries": 1,
                           "partials": 0, "last_reason": "", "last_time": ts,
                           "first_partial_done": False}
                elif pos["side"] == side and pos["entries"] < cfg["pyramid"]:
                    # average the new fill in, as strategy.entry would
                    k = pos["entries"]
                    pos["entry_price"] = (pos["entry_price"] * k + o[i]) / (k + 1)
                    pos["entries"] = k + 1
            elif kind == "close_all" and pos is not None:
                book(o[i], 1.0 - pos["closed"], ts, payload)
                finish()
            elif kind == "partial" and pos is not None:
                frac = min(payload, 1.0 - pos["closed"])
                book(o[i], frac, ts, "partial")
                pos["partials"] += 1
                if pos["closed"] >= 0.999:
                    finish()
            elif kind == "exit_at" and pos is not None:
                price, reason = payload
                book(price, 1.0 - pos["closed"], ts, reason)
                finish()

        if pos is not None:
            # ---- protective levels: the script TESTS them and sends a
            #      market order, so the fill is the next bar's open unless
            #      --true-stop is set.
            sl, tp = stop_level(), target_level()
            fired = None
            if cfg["enable_sl"]:
                if pos["side"] == "long" and (l[i] <= sl or o[i] <= sl):
                    fired = (sl, "stop_loss")
                elif pos["side"] == "short" and (h[i] >= sl or o[i] >= sl):
                    fired = (sl, "stop_loss")
            if fired is None and cfg["enable_tp"]:
                if pos["side"] == "long" and (h[i] >= tp or o[i] >= tp):
                    fired = (tp, "take_profit")
                elif pos["side"] == "short" and (l[i] <= tp or o[i] <= tp):
                    fired = (tp, "take_profit")
            if fired is not None:
                pending = ("exit_at", fired) if true_stop else ("close_all", fired[1])
                continue

        # ---- entries -------------------------------------------------------
        if pos is None:
            if ls[i]:
                pending = ("entry", "long")
            elif ss[i]:
                pending = ("entry", "short")
            continue

        if pos["entries"] < cfg["pyramid"]:
            if ls[i] and pos["side"] == "long":
                pending = ("entry", "long")
                continue
            if ss[i] and pos["side"] == "short":
                pending = ("entry", "short")
                continue

        # ---- partial take at the opposing block ----------------------------
        partial_long = (pos["side"] == "long" and not np.isnan(bear_bot[i])
                        and h[i] >= bear_bot[i])
        partial_short = (pos["side"] == "short" and not np.isnan(bull_top[i])
                         and l[i] <= bull_top[i])
        if partial_long or partial_short:
            if not pos["first_partial_done"]:
                pos["first_partial_done"] = True
                pending = ("partial", cfg["partial_close_pct"] / 100)
            else:
                pos["first_partial_done"] = False
                pending = ("close_all", "signal_exit")
            continue

        # ---- full exit through the opposing block --------------------------
        full_long = (pos["side"] == "long" and not np.isnan(bull_bot[i])
                     and ((not np.isnan(bear_top[i]) and h[i] >= bear_top[i])
                          or c[i] < bull_bot[i]))
        full_short = (pos["side"] == "short" and not np.isnan(bear_top[i])
                      and ((not np.isnan(bull_bot[i]) and l[i] <= bull_bot[i])
                           or c[i] > bear_top[i]))
        if full_long or full_short:
            pending = ("close_all", "signal_exit")

    if pos is not None:
        book(c[-1], 1.0 - pos["closed"], idx[-1], "end_of_data")
        finish()

    return deals_frame(deals)


def main():
    p = argparse.ArgumentParser(description="Order Block Strategy (OBS.V1) backtester")
    p.add_argument("--symbol")
    p.add_argument("--symbols", nargs="+")
    p.add_argument("--csv")
    p.add_argument("--exchange", default="bybit")
    p.add_argument("--market", default="swap", choices=["swap", "spot"])
    p.add_argument("--timeframe", default="1h")
    p.add_argument("--start", default="2024-01-01")
    p.add_argument("--end", default="2025-12-31")
    p.add_argument("--out", default="backtest_out_order_block")
    p.add_argument("--commission", type=float, default=0.055)
    p.add_argument("--slippage-pct", type=float, default=0.0)
    p.add_argument("--length", type=int, default=DEFAULTS["length"])
    p.add_argument("--stop-loss-pct", type=float, default=DEFAULTS["stop_loss_pct"])
    p.add_argument("--take-profit-pct", type=float, default=DEFAULTS["take_profit_pct"])
    p.add_argument("--partial-close-pct", type=float, default=DEFAULTS["partial_close_pct"])
    p.add_argument("--pyramid", type=int, default=1,
                   help="max entries per position. TradingView runs 1 (pyramiding=1 "
                        "in the header); the body was written for 6")
    p.add_argument("--true-stop", action="store_true",
                   help="fill stops and targets at the level instead of at the next "
                        "bar's open, which is what the script's market orders do")
    p.add_argument("--fix-entry-precedence", action="store_true",
                   help="bracket the entry condition the way its layout reads")
    args = p.parse_args()

    cfg = dict(DEFAULTS)
    cfg.update(length=args.length, stop_loss_pct=args.stop_loss_pct,
               take_profit_pct=args.take_profit_pct,
               partial_close_pct=args.partial_close_pct,
               pyramid=max(1, args.pyramid))

    out_dir = Path(args.out)
    write_manifest(out_dir, Path(__file__).stem, args,
                   extra_keys=("length", "stop_loss_pct", "take_profit_pct",
                               "partial_close_pct", "pyramid", "true_stop",
                               "fix_entry_precedence"))

    sources = load_sources(args, p)

    print("\n" + "=" * 100)
    print("ORDER BLOCK STRATEGY (OBS.V1) - BACKTEST RESULTS")
    print(f"swing {cfg['length']} | SL {cfg['stop_loss_pct']}% | TP {cfg['take_profit_pct']}% | "
          f"partial {cfg['partial_close_pct']}% | max entries {cfg['pyramid']} | "
          f"commission {args.commission}%/side | slippage {args.slippage_pct}%")
    print("FIXED vs Pine: each order block is its own object. In the source `var obj` "
          "made every block in the array a reference to one shared object.")
    print("Exits fill at the NEXT bar's open - the script tests its stop itself and sends "
          "a market order." + ("  [--true-stop: filling at the level instead]" if args.true_stop else ""))
    if not args.fix_entry_precedence:
        print("Entry condition reproduced with the source's operator precedence "
              "(the na-guards cover only its first half).")
    print("=" * 100)

    for sym, ohlcv in sources.items():
        if len(ohlcv) < cfg["length"] * 3 + 10:
            print(f"  {sym:14s}: insufficient data ({len(ohlcv)} bars)")
            continue
        df = compute_signals(ohlcv, cfg, args.fix_entry_precedence)
        deals = run_backtest(df, cfg, args.commission, args.slippage_pct, args.true_stop)
        deals.to_csv(out_dir / f"{sym.replace('/', '')}_deals.csv", index=False)
        note = ""
        if len(deals):
            note = f"partials {int(deals['partials'].sum())}"
        print_summary(sym, deals, note)

    print("=" * 100)
    print(f"\nDeal logs + _run.json written to: {out_dir}/")


if __name__ == "__main__":
    main()
