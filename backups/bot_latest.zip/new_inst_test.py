"""new_inst_test.py — 2026-11-09. Поиск стратегий под TradFi-инструменты HH, которые не прошли / не тестировались:
нефть, газ, палладий, TSM, SK Hynix, Samsung, Nokia, SanDisk, EWJ, EWY, AAOI, AXTI, Circle.
(OpenAI, SpaceX, PayPay — частные/новые, истории котировок нет.)
Все стратегии из stocks_test.py (наши TradFi + объём + RSI2 + крипто-стратегии на дневках) + 4 новых:
  Donchian 55/20 тренд (лонг и шорт), Возврат к EMA20 в тренде, Боллинджер-возврат, Пробой недельного максимума.
Отбор: плюс в обеих половинах, PF > 1.2, сделок ≥ 15. Итог: new_inst_test.txt
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import stocks_test as ST  # noqa: E402

INST = {"Нефть WTI (CLUSDT)": "CL=F", "Нефть Brent (BZUSDT)": "BZ=F", "Газ (NATGASUSDT)": "NG=F", "Палладий (XPDUSDT)": "PA=F",
        "TSM": "TSM", "SK Hynix": "000660.KS", "Samsung": "005930.KS", "Nokia (NOKUSDT)": "NOK", "SanDisk (SNDKUSDT)": "SNDK",
        "Япония EWJ": "EWJ", "Корея EWY": "EWY", "AAOI": "AAOI", "AXTI": "AXTI", "Circle (CRCLUSDT)": "CRCL"}


def _atr(d):
    return ST._atr(d.h.values, d.l.values, d.c.values)


def generic(d, entry, stop_k, exit_fn, sides=(1, -1)):
    c, h, l, t = d.c.values, d.h.values, d.l.values, d.t.values; a = _atr(d); out = []; i = 210
    while i < len(c) - 1:
        s = entry(i)
        if s in sides and a[i] > 0:
            risk = stop_k * a[i]; sl = c[i] - s * risk; j = i + 1; r = None
            for j in range(i + 1, len(c)):
                if (l[j] <= sl) if s > 0 else (h[j] >= sl):
                    r = -1.0; break
                if exit_fn(j, s):
                    r = s * (c[j] - c[i]) / risk; break
            if r is None:
                break
            out.append({"in_t": int(t[i]), "r": r - ST.COST * c[i] / risk}); i = j + 1; continue
        i += 1
    return out


def extra(d):
    c = d.c.values; h, l = d.h.values, d.l.values
    s = pd.Series(c); e20 = s.ewm(span=20, adjust=False).mean().values; e50 = s.ewm(span=50, adjust=False).mean().values
    e200 = s.ewm(span=200, adjust=False).mean().values
    h55 = pd.Series(h).rolling(55).max().shift(1).values; l55 = pd.Series(l).rolling(55).min().shift(1).values
    h20 = pd.Series(h).rolling(20).max().shift(1).values; l20 = pd.Series(l).rolling(20).min().shift(1).values
    m20 = s.rolling(20).mean().values; sd = s.rolling(20).std().values
    wk_h = pd.Series(h).rolling(5).max().shift(1).values
    tr = lambda i: 1 if e50[i] > e200[i] else -1  # noqa: E731
    return {
        "Donchian 55/20 тренд": generic(d, lambda i: 1 if c[i] > h55[i] else -1 if c[i] < l55[i] else 0, 2.0,
                                        lambda j, s: (c[j] < l20[j]) if s > 0 else (c[j] > h20[j])),
        "Возврат к EMA20 в тренде": generic(d, lambda i: tr(i) if (l[i] <= e20[i] <= h[i] and c[i] * tr(i) > e20[i] * tr(i)) else 0, 1.5,
                                            lambda j, s: s * (c[j] - e20[j]) < -0.0 and s * (c[j] - e50[j]) < 0),
        "Боллинджер-возврат": generic(d, lambda i: 1 if c[i] < m20[i] - 2 * sd[i] else -1 if c[i] > m20[i] + 2 * sd[i] else 0, 2.0,
                                      lambda j, s: s * (c[j] - m20[j]) >= 0),
        "Пробой недельного максимума (лонг)": generic(d, lambda i: 1 if c[i] > wk_h[i] and c[i] > e200[i] else 0, 2.0,
                                                      lambda j, s: c[j] < e20[j], sides=(1,)),
    }


def main() -> None:
    import bt_lab as BL  # noqa: PLC0415
    BL.deals_to_trades = lambda rows, df, p, prog=None: rows
    lines = [f"Поиск стратегий для новых TradFi-инструментов HH — {time.strftime('%Y-%m-%d %H:%M')}",
             "✅ = плюс в обеих половинах истории, PF > 1.2, сделок ≥ 15. R — в долях риска; (%) — крипто-стратегии в % хода цены.", ""]
    for name, sym in INST.items():
        d = ST.yahoo(sym)
        if d is None:
            lines.append(f"{name}: нет данных Yahoo"); print(lines[-1], flush=True); continue
        mid = (d.t.iloc[0] + d.t.iloc[-1]) / 2; yrs = (d.t.iloc[-1] - d.t.iloc[0]) / 3.156e10
        res = {"BOS 1D": [x for x in ST.BOS.replay(d) if x.get("status") == "closed"],
               "FVG по тренду 3R": [x for x in ST.FVG.replay(d) if x.get("status") == "closed"],
               "Ложный пробой 2 свечи": [x for x in ST.FB2.replay(d) if x.get("status") == "closed"],
               "RSI(2) возврат": ST.rsi2(d)}
        if d.v.sum() > 0:
            res["Пробой на объёме ×2"] = ST.vol_breakout(d); res["Накопление → пробой"] = ST.accumulation(d)
        res.update(extra(d))
        try:
            dfc = pd.DataFrame({"t": d.t, "open": d.o, "high": d.h, "low": d.l, "close": d.c, "volume": d.v})
            for st in BL.HONEST:
                rr = BL.sim_honest(dfc, {"strategy": st, "tf": "1D"}, lambda *x: None)
                res["крипто " + st.split(":")[1] + " (%)"] = [{"in_t": q["t_in"], "r": q["pct"]} for q in rr]
        except Exception as e:  # noqa: BLE001
            print("  крипто:", e)
        rows = []
        for st, trs in res.items():
            s = ST.stats(trs, mid)
            if s:
                ok = s["h1"] > 0 and s["h2"] > 0 and s["pf"] > 1.2 and s["n"] >= 15
                rows.append((ok, s["pf"], st, s))
        rows.sort(key=lambda x: (-x[0], -x[1]))
        lines.append(f"=== {name} ({sym}), истории {yrs:.1f} лет ===")
        good = [r for r in rows if r[0]]
        for ok, pf, st, s in rows[:8]:
            lines.append(f"  {'✅' if ok else '  '} {st:36s} PF {s['pf']:5.2f} · {s['n']:4d} сд · R/сд {s['rpt']:+.3f} · половины {s['h1']:+.1f}/{s['h2']:+.1f} · 2 года {s['y2']:+.1f}")
        lines.append(f"  → прошли: {', '.join(r[2] for r in good) or 'НИЧЕГО — не торговать'}")
        print("\n".join(lines[-10:]), flush=True)
    (BASE / "new_inst_test.txt").write_text("\n".join(lines), encoding="utf-8")
    print("\nГотово: new_inst_test.txt")


if __name__ == "__main__":
    main()
