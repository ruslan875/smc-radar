"""fib_test.py — 2026-10-12. Откат по Фибоначчи (как на скрине из Hash Hedge: импульс → откат к 0.618 → продолжение).

Правила задаём заранее, без подгонки:
  свинги — подтверждённые пивоты (P свечей слева и справа, без заглядывания вперёд: пивот известен только через P свечей);
  импульс вверх: последний подтверждённый минимум L → следующий подтверждённый максимум H, размах ≥ K·ATR, цена выше EMA200;
  в момент подтверждения H ставим лимитку на покупку на уровне 0.618 отката (H − 0.618·(H−L)), если цена ещё не там.
  Варианты стопа:  «0.786» — под уровнем 0.786;  «L» — под началом импульса L (0.3·ATR запаса).
  Варианты тейка:  «H» — у вершины импульса;  «1.272» — расширение 1.272 от L.
  Лимитка снимается, если цена обновила H или прошло 40 свечей. Шорт — зеркально.
Вход и тейк лимитками, стоп по рынку; комиссии пользователя Bybit (мейкер 0.0324%, тейкер 0.09%).
12 монет, 1h и 4h, 1-я / 2-я половина истории. Ничего не торгует. Запуск: fib_test.bat → bt_lab_bots/fib_test.txt
"""
from __future__ import annotations

import time
from pathlib import Path

import requests

BASE = Path(__file__).resolve().parent
OUT = BASE / "bt_lab_bots" / "fib_test.txt"
COINS = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT", "DOGEUSDT", "ADAUSDT", "SUIUSDT", "LINKUSDT", "AVAXUSDT",
         "BNBUSDT", "NEARUSDT", "HYPEUSDT"]
MK, TK = 0.000324, 0.0009
P, K = 5, 3.0
LINES = []


def say(s=""):
    print(s)
    LINES.append(s)


def klines(sym, interval, total):
    rows, end = [], None
    while len(rows) < total:
        p = {"category": "linear", "symbol": sym, "interval": interval, "limit": 1000}
        if end:
            p["end"] = end
        j = None
        for k in range(4):
            try:
                j = requests.get("https://api.bybit.com/v5/market/kline", params=p, timeout=20).json()
                break
            except requests.RequestException:
                time.sleep(2 * (k + 1))
        lst = (j or {}).get("result", {}).get("list") or []
        if not lst:
            break
        rows += lst
        end = int(lst[-1][0]) - 1
        if len(lst) < 1000:
            break
        time.sleep(0.12)
    rows = sorted({int(r[0]): r for r in rows}.values(), key=lambda r: int(r[0]))
    return [(int(r[0]), float(r[2]), float(r[3]), float(r[4])) for r in rows]   # t, high, low, close


def ema(v, n):
    out, k, e = [], 2 / (n + 1), None
    for x in v:
        e = x if e is None else e + k * (x - e)
        out.append(e)
    return out


def atr(rows, n=14):
    out, a = [], None
    for i, (_, h, l, c) in enumerate(rows):
        pc = rows[i - 1][3] if i else c
        tr = max(h - l, abs(h - pc), abs(l - pc))
        a = tr if a is None else a + (tr - a) / n
        out.append(a)
    return out


def run(rows, stop_mode, tp_mode):
    H = [r[1] for r in rows]; Lw = [r[2] for r in rows]; C = [r[3] for r in rows]
    e200 = ema(C, 200); at = atr(rows)
    last_hi = last_lo = None          # (index, price) подтверждённых пивотов
    order = deal = None
    trades = []
    for i in range(210, len(rows)):
        h, l, c = H[i], Lw[i], C[i]
        # 1) сопровождение сделки
        if deal:
            d = deal["d"]
            if (l <= deal["sl"]) if d > 0 else (h >= deal["sl"]):
                r = -1.0 - (MK + TK) * deal["e"] / deal["risk"]
            elif (h >= deal["tp"]) if d > 0 else (l <= deal["tp"]):
                r = abs(deal["tp"] - deal["e"]) / deal["risk"] - 2 * MK * deal["e"] / deal["risk"]
            elif i - deal["i"] >= 120:
                r = d * (c - deal["e"]) / deal["risk"] - (MK + TK) * deal["e"] / deal["risk"]
            else:
                r = None
            if r is not None:
                trades.append(r); deal = None
        # 2) лимитка
        elif order:
            d = order["d"]
            if (l <= order["e"]) if d > 0 else (h >= order["e"]):
                deal = dict(order, i=i); order = None
                if (l <= deal["sl"]) if d > 0 else (h >= deal["sl"]):       # стоп в ту же свечу — худший случай
                    trades.append(-1.0 - (MK + TK) * deal["e"] / deal["risk"]); deal = None
            elif i - order["i0"] > 40 or ((h > order["ext"]) if d > 0 else (l < order["ext"])):
                order = None
        # 3) новые подтверждённые пивоты (пивот на свече i-P становится известен на свече i)
        j = i - P
        if all(H[j] >= H[k] for k in range(j - P, j + P + 1)):
            last_hi = (j, H[j])
            if not deal and not order and last_lo and last_lo[0] < j and e200[i] < c:
                lo, hi = last_lo[1], H[j]
                if hi - lo >= K * at[i]:
                    rng = hi - lo
                    e = hi - 0.618 * rng
                    sl = (hi - 0.786 * rng - 0.1 * at[i]) if stop_mode == "0.786" else (lo - 0.3 * at[i])
                    tp = hi if tp_mode == "H" else lo + 1.272 * rng
                    if l > e and e - sl > 0:
                        order = {"d": 1, "e": e, "sl": sl, "tp": tp, "risk": e - sl, "ext": hi, "i0": i}
        if all(Lw[j] <= Lw[k] for k in range(j - P, j + P + 1)):
            last_lo = (j, Lw[j])
            if not deal and not order and last_hi and last_hi[0] < j and e200[i] > c:
                hi, lo = last_hi[1], Lw[j]
                if hi - lo >= K * at[i]:
                    rng = hi - lo
                    e = lo + 0.618 * rng
                    sl = (lo + 0.786 * rng + 0.1 * at[i]) if stop_mode == "0.786" else (hi + 0.3 * at[i])
                    tp = lo if tp_mode == "H" else hi - 1.272 * rng
                    if h < e and sl - e > 0:
                        order = {"d": -1, "e": e, "sl": sl, "tp": tp, "risk": sl - e, "ext": lo, "i0": i}
    return trades


def main():
    say(f"Откат Фибоначчи 0.618 — бэктест · {time.strftime('%Y-%m-%d %H:%M')} · пивоты {P}/{P}, импульс ≥ {K} ATR, по тренду EMA200")
    for tf, n in (("60", 12000), ("240", 6000)):
        data = {s: klines(s, tf, n) for s in COINS}
        for stop_mode in ("0.786", "L"):
            for tp_mode in ("H", "1.272"):
                allr, first, second, plus = [], 0.0, 0.0, 0
                per = []
                for s, rows in data.items():
                    if len(rows) < 600:
                        continue
                    rs = run(rows, stop_mode, tp_mode)
                    if not rs:
                        continue
                    h = len(rs) // 2
                    first += sum(rs[:h]); second += sum(rs[h:]); allr += rs; plus += sum(rs) > 0
                    per.append(f"{s[:-4]} {sum(rs):+.1f}")
                if not allr:
                    continue
                ok = sum(allr) > 0 and first > 0 and second > 0 and plus >= 8
                say(f"{'1h' if tf == '60' else '4h'} · стоп {stop_mode:<5} · тейк {tp_mode:<5}: {len(allr):>4} сд · "
                    f"{sum(allr):+7.1f}R · {sum(allr) / len(allr):+.3f}R/сд · в плюсе {sum(r > 0 for r in allr) / len(allr) * 100:.0f}% · "
                    f"1-я {first:+.1f}R · 2-я {second:+.1f}R · монет в плюсе {plus}/12  {'✅' if ok else '❌'}")
                say("      " + " · ".join(per))
    say("")
    say("✅ — итог в плюсе, обе половины в плюсе и в плюсе ≥ 8 из 12 монет.")
    OUT.parent.mkdir(exist_ok=True)
    OUT.write_text("\n".join(LINES), encoding="utf-8")
    print(f"\nОтчёт: {OUT}")


if __name__ == "__main__":
    main()
