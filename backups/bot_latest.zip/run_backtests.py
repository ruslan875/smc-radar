#!/usr/bin/env python3
"""
Run every ported strategy under identical conditions, then compare
===================================================================

Written 20.09.2026, after a session spent hand-typing three long commands
and losing one run to being in the wrong folder.

The point is not convenience. It is that a comparison is only meaningful
when every strategy faced the same symbols, the same period, the same
market and the same costs. Typing those by hand each time guarantees they
will drift apart, and then the ranking measures the settings instead of
the strategies.

USAGE

    python run_backtests.py
        everything, on the defaults below

    python run_backtests.py --only third_eye gaussian
    python run_backtests.py --symbols BTC/USDT ETH/USDT --timeframe 4h
    python run_backtests.py --dry-run
        print the commands without running them

Data is cached by market_data.py, so a second run over the same window
costs nothing and does not touch the exchange.

ADDING A STRATEGY: append an entry to STRATEGIES. `extra` holds arguments
specific to that script; everything in the shared block below is passed to
all of them.
"""

from __future__ import annotations

import argparse
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent

# name -> (script, output folder, strategy-specific args)
STRATEGIES = {
    "third_eye": ("third_eye_backtest.py", "backtest_out_third_eye", []),
    "gaussian": ("gaussian_channel_backtest.py", "backtest_out_gaussian", []),
    "hlcloud": ("high_low_cloud_backtest.py", "backtest_out_hlcloud", []),
    # Aggressive, not the Pine default "Confirmed": in Confirmed mode the
    # retest level is the lowest low of the whole impulse leg, so price has
    # to give the entire move back within 20 bars. Faithful to the source,
    # but it fires roughly 3% as often - 4 trades where Aggressive gives 134
    # - which is too thin a sample to conclude anything from.
    "liqtherm": ("liq_therm_map_backtest.py", "backtest_out_liqtherm",
                 ["--entry-mode", "Aggressive"]),
    # No filter flags: all 23 of Combo OTM's veto filters are off in the Pine
    # defaults too, so this runs what the strategy actually is out of the box -
    # a pivot reversal with fixed exits. The filters are the optimisation
    # surface, and switching them on belongs in a separate, disciplined pass
    # (one or two at a time, split sample), not in the baseline comparison.
    "combo_otm": ("combo_otm_backtest.py", "backtest_out_combo_otm", []),
    # --- added 21.09.2026: the four the audit had parked behind "fix first" ---
    # Those fixes were TradingView fixes. Porting by hand does them anyway:
    # the commission goes in as a percentage, the double exit becomes one
    # exit, the shared-object bug cannot survive being written out, and the
    # toggles with no indicator behind them simply do not get typed.
    "pavlova": ("pavlova_backtest.py", "backtest_out_pavlova", []),
    "ce_zlsma": ("ce_zlsma_backtest.py", "backtest_out_ce_zlsma", []),
    # pyramiding stays at 1 - that is what TradingView runs, whatever the
    # body of the script was written for.
    "order_block": ("order_block_backtest.py", "backtest_out_order_block", []),
    # --no-rsi1 for the same reason liqtherm runs Aggressive: the faithful
    # default produces NO trades at all. A long needs price to cross UP
    # through the EMA on the same bar RSI(14) sits below 30, and those two
    # things do not co-occur. Zero trades measures nothing, so the baseline
    # here is the strategy with that one filter off - which is a setting the
    # Pine itself exposes (use_rsi1), not an invention.
    "rsi_connors": ("rsi_connors_backtest.py", "backtest_out_rsi_connors",
                    ["--no-rsi1"]),
    # 2026-09-22: десятый порт. Свой argparse приведён к общему виду
    # (--out/--exchange/--market), конфиг R4_OKX_HYPE_1H.csv ищется
    # автоматически рядом со скриптом и в strategies/.
    "hype_r4": ("hype_r4_backtest.py", "backtest_out_hype_r4", []),
}

DEFAULTS = {
    "symbols": ["BTC/USDT", "ETH/USDT", "SOL/USDT"],
    "timeframe": "1h",
    "start": "2024-01-01",
    "end": "2025-12-31",
    "exchange": "bybit",
    "market": "swap",        # USDT perpetuals - what the bots actually trade
    "commission": "0.055",   # Bybit taker, per side
    "slippage": "0.03",
}


def main():
    p = argparse.ArgumentParser(description="Run all ported strategy backtests")
    p.add_argument("--only", nargs="+", choices=list(STRATEGIES),
                   help="run a subset (default: all)")
    p.add_argument("--symbols", nargs="+", default=DEFAULTS["symbols"])
    p.add_argument("--timeframe", default=DEFAULTS["timeframe"])
    p.add_argument("--start", default=DEFAULTS["start"])
    p.add_argument("--end", default=DEFAULTS["end"])
    p.add_argument("--exchange", default=DEFAULTS["exchange"])
    p.add_argument("--market", default=DEFAULTS["market"], choices=["swap", "spot"])
    p.add_argument("--commission", default=DEFAULTS["commission"])
    p.add_argument("--slippage-pct", default=DEFAULTS["slippage"])
    p.add_argument("--suffix", default="", help="appended to every output folder name")
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--no-analyze", action="store_true",
                   help="skip the comparison step at the end")
    args = p.parse_args()

    names = args.only or list(STRATEGIES)
    python = sys.executable  # the venv interpreter that launched this file

    print("=" * 104)
    print("  RUNNING BACKTESTS")
    print(f"  {', '.join(args.symbols)}  |  {args.timeframe}  |  "
          f"{args.start} -> {args.end}  |  {args.exchange} {args.market}")
    print(f"  commission {args.commission}% per side, slippage {args.slippage_pct}%")
    print("=" * 104)

    ran, failed, out_dirs = [], [], []

    for name in names:
        script, out_dir, extra = STRATEGIES[name]
        path = HERE / script
        if not path.exists():
            print(f"\n  {name}: {script} not found - skipped")
            failed.append((name, "script missing"))
            continue

        out = f"{out_dir}{args.suffix}"
        cmd = [python, str(path),
               "--symbols", *args.symbols,
               "--exchange", args.exchange,
               "--market", args.market,
               "--timeframe", args.timeframe,
               "--start", args.start,
               "--end", args.end,
               "--commission", str(args.commission),
               "--slippage-pct", str(args.slippage_pct),
               "--out", out, *extra]

        print(f"\n{'-' * 104}\n  {name}\n{'-' * 104}")
        if args.dry_run:
            print("  " + " ".join(cmd))
            continue

        t0 = time.time()
        # Not capturing output: the per-script summaries are worth seeing as
        # they happen, and a long download should not look like a hang.
        result = subprocess.run(cmd, cwd=HERE)
        took = time.time() - t0

        if result.returncode == 0:
            print(f"  done in {took:.0f}s")
            ran.append(name)
            out_dirs.append(out)
        else:
            print(f"  FAILED (exit {result.returncode}) after {took:.0f}s")
            failed.append((name, f"exit {result.returncode}"))

    if args.dry_run:
        return

    print()
    print("=" * 104)
    print(f"  {len(ran)} ok, {len(failed)} failed")
    for name, why in failed:
        print(f"    {name}: {why}")
    print("=" * 104)

    if out_dirs and not args.no_analyze:
        analyzer = HERE / "analyze_external_strategies.py"
        if analyzer.exists():
            subprocess.run([python, str(analyzer), "--dirs", *out_dirs], cwd=HERE)
        else:
            print("  analyze_external_strategies.py not found - skipping comparison")


if __name__ == "__main__":
    main()
