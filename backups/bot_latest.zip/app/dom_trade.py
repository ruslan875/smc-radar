"""dom_trade.py — 2026-10-10. Реальная торговля из стакана (windows_app/static/dom.html), Bybit.

Всё идёт через ключ ручной торговли (manual_trade.manual_creds) и с теми же защитами, что у ручного ордера:
  * стоп обязателен (0.2–10 %), лимит суммы MANUAL_MAX_NOTIONAL_USDT, плечо ≤ MAX_TRADE_LEVERAGE,
    недельный риск-бюджет и прочие проверки app/trade_executor.execute_trade;
  * не чаще одного нового ордера в 10 секунд (общий счётчик с manual_trade);
  * на ОБЩЕМ счёте монеты живых ботов запрещены целиком: нельзя ни открыть, ни снять ордер, ни сдвинуть
    стоп, ни закрыть — иначе стакан мог бы сломать сделку бота;
  * каждое действие, которое меняет что-то на бирже, требует confirm == "LIVE" (окно подтверждения в стакане).
Ничего не делается само — только по клику пользователя.
"""
from __future__ import annotations

import sys

from app import manual_trade as mt
from app.exchanges import bybit as bx


class DomError(Exception):
    pass


def _creds_for(symbol: str) -> tuple[dict, str]:
    symbol = mt.norm_symbol(symbol)
    creds, isolated = mt.manual_creds("bybit")
    if not creds:
        raise DomError("нет торгового ключа Bybit — добавь его в терминале (ручной ордер → ключ)")
    if not isolated:
        bs = mt.bot_symbols().get(symbol)
        if bs:
            raise DomError(f"{symbol} торгует бот «{bs[0]}» на этом же счёте — из стакана им управлять нельзя. "
                           f"Выбери другую монету или подключи ключ субаккаунта.")
    return creds, symbol


def _need_live(body: dict) -> None:
    if body.get("confirm") != "LIVE":
        raise DomError("нужно подтверждение")


def _round(v: float, tick: float) -> float:
    return round(round(v / tick) * tick, 10) if tick else v


def state(symbol: str) -> dict:
    """Позиция, её стоп/тейк и открытые ордера по монете. Только чтение."""
    symbol = mt.norm_symbol(symbol)
    creds, isolated = mt.manual_creds("bybit")
    if not creds:
        return {"ok": False, "error": "нет торгового ключа Bybit", "position": None, "orders": []}
    blocked = None
    if not isolated:
        bs = mt.bot_symbols().get(symbol)
        if bs:
            blocked = f"монету торгует бот «{bs[0]}» — только просмотр"
    pos = None
    try:
        df = bx.fetch_open_positions(creds["api_key"], creds["api_secret"])
        for r in df.to_dict("records"):
            if r.get("symbol") == symbol:
                pos = {"side": "LONG" if str(r["side"]).lower() in ("long", "buy") else "SHORT",
                       "qty": r["qty"], "entry": r["avg_entry_price"], "mark": r["mark_price"],
                       "upnl": r["unrealized_pnl"], "sl": r.get("stop_loss"), "tp": r.get("take_profit"),
                       "leverage": r.get("leverage")}
                break
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "error": f"Bybit: {exc}"[:200], "position": None, "orders": []}
    orders = []
    try:
        p = bx._signed_get("/v5/order/realtime", creds["api_key"], creds["api_secret"],
                           {"category": "linear", "symbol": symbol, "openOnly": 0, "limit": 50})
        for o in p.get("result", {}).get("list", []) or []:
            if o.get("orderType") != "Limit" or o.get("stopOrderType"):
                continue   # стоп/тейк позиции показываем из позиции, не отдельными ордерами
            orders.append({"id": o["orderId"], "side": "LONG" if o["side"] == "Buy" else "SHORT",
                           "price": float(o["price"]), "qty": float(o["qty"]),
                           "reduce": bool(o.get("reduceOnly")),
                           "sl": float(o["stopLoss"]) if o.get("stopLoss") else None,
                           "tp": float(o["takeProfit"]) if o.get("takeProfit") else None})
    except Exception as exc:  # noqa: BLE001
        print(f"[dom] orders: {exc}", file=sys.stderr)
    return {"ok": True, "symbol": symbol, "account": "субаккаунт" if isolated else "общий счёт",
            "blocked": blocked, "position": pos, "orders": orders}


def limit(body: dict, dry_run: bool) -> dict:
    """Лимитный вход по цене клика. Стоп/тейк в % от цены лимита, ставятся вместе с ордером."""
    from app.config import STATE_FILE, Settings  # noqa: PLC0415
    from app.state import StateStore  # noqa: PLC0415
    from app.trade_executor import execute_trade  # noqa: PLC0415
    import time  # noqa: PLC0415
    creds, symbol = _creds_for(str(body.get("symbol") or ""))
    side = str(body.get("side") or "").upper()
    price = float(body.get("price") or 0)
    if side not in ("LONG", "SHORT") or price <= 0:
        raise DomError("нужны направление и цена")
    # все проверки суммы/стопа/плеча — как у ручного ордера (там же запрет монет ботов)
    try:
        p = mt.prepare(symbol, side, body.get("usdt"), body.get("leverage"), body.get("sl_pct"), body.get("tp_pct"))
    except mt.ManualTradeError as exc:
        raise DomError(exc.message) from None
    last = p["price"]
    d = 1 if side == "LONG" else -1
    if d * (price - last) >= 0:
        raise DomError("лимит по эту сторону рынка исполнился бы сразу — для входа сейчас жми «по рынку»")
    info = bx.get_instrument_info(symbol)
    tick, step = info.get("tick_size") or 0, info["qty_step"]
    price = _round(price, tick)
    qty = int((float(body["usdt"]) / price) / step) * step
    qty = float(f"{qty:.10f}".rstrip("0").rstrip(".") or 0)
    if qty < info["min_order_qty"]:
        raise DomError(f"слишком маленькая сумма: минимум {info['min_order_qty']:g}")
    sl = _round(price * (1 - d * p["sl_pct"] / 100), tick)
    tp = _round(price * (1 + d * p["tp_pct"] / 100), tick) if p["tp_pct"] else None
    pv = {"symbol": symbol, "side": side, "price": price, "qty": qty, "notional": round(qty * price, 2),
          "leverage": p["leverage"], "stop_loss": sl, "take_profit": tp, "risk_usdt": round(qty * abs(price - sl), 2),
          "account": p["account"], "type": "лимит"}
    if dry_run:
        return {"ok": True, "dry_run": True, **pv}
    _need_live(body)
    guard_day_limit()
    if time.time() - mt._LAST["at"] < 10:
        raise DomError("ордер уже отправлен — подожди 10 секунд")
    mt._LAST["at"] = time.time()
    s = Settings.load()
    r = execute_trade("bybit", symbol, "buy" if side == "LONG" else "sell", qty, p["leverage"], sl, tp, False, s,
                      StateStore(STATE_FILE), entry_price=price, trade_creds_override=creds)
    print(f"[dom] limit {symbol} {side} {qty}@{price} -> {r}")
    if not r.get("ok"):
        raise DomError(r.get("reason") or "биржа отклонила ордер")
    return {"ok": True, **pv, "order_id": r.get("order_id")}


def cancel(body: dict) -> dict:
    _need_live(body)
    creds, symbol = _creds_for(str(body.get("symbol") or ""))
    oid = str(body.get("id") or "")
    if not oid:
        raise DomError("нет id ордера")
    p = bx._signed_post("/v5/order/cancel", creds["api_key"], creds["api_secret"],
                        {"category": "linear", "symbol": symbol, "orderId": oid})
    if p.get("retCode") != 0:
        raise DomError(f"Bybit: {p.get('retMsg')}")
    print(f"[dom] cancel {symbol} {oid}")
    return {"ok": True}


def tpsl(body: dict) -> dict:
    """Сдвинуть стоп и/или тейк открытой позиции (перетаскивание метки, «в безубыток»)."""
    _need_live(body)
    creds, symbol = _creds_for(str(body.get("symbol") or ""))
    st = state(symbol)
    pos = st.get("position")
    if not pos:
        raise DomError("позиции по этой монете нет")
    d = 1 if pos["side"] == "LONG" else -1
    info = bx.get_instrument_info(symbol)
    tick = info.get("tick_size") or 0
    last = bx.get_last_price(symbol)
    params = {"category": "linear", "symbol": symbol, "positionIdx": 0, "tpslMode": "Full"}
    if body.get("sl") is not None:
        sl = _round(float(body["sl"]), tick)
        if d * (last - sl) <= 0:
            raise DomError("стоп должен быть с другой стороны от текущей цены (для лонга — ниже)")
        params["stopLoss"] = str(sl)
    if body.get("tp") is not None:
        tp = float(body["tp"])
        if tp == 0:
            params["takeProfit"] = "0"          # убрать тейк
        else:
            tp = _round(tp, tick)
            if d * (tp - last) <= 0:
                raise DomError("тейк должен быть по ходу сделки (для лонга — выше цены)")
            params["takeProfit"] = str(tp)
    if "stopLoss" not in params and "takeProfit" not in params:
        raise DomError("нечего менять")
    p = bx._signed_post("/v5/position/trading-stop", creds["api_key"], creds["api_secret"], params)
    if p.get("retCode") not in (0, 34040) and bx._is_position_idx_mismatch(p):
        p = bx._signed_post("/v5/position/trading-stop", creds["api_key"], creds["api_secret"],
                            dict(params, positionIdx=bx._hedge_position_idx(pos["side"].lower())))
    if p.get("retCode") not in (0, 34040):
        raise DomError(f"Bybit: {p.get('retMsg')}")
    print(f"[dom] tpsl {symbol} {params}")
    return {"ok": True}


def close(body: dict) -> dict:
    _need_live(body)
    creds, symbol = _creds_for(str(body.get("symbol") or ""))
    pos = state(symbol).get("position")
    if not pos:
        raise DomError("позиции по этой монете нет")
    r = bx.close_position(creds["api_key"], creds["api_secret"], symbol, pos["side"].lower(), pos["qty"])
    print(f"[dom] close {symbol} {pos['side']} {pos['qty']} -> {r}")
    return {"ok": True, **r}


def trail(body: dict) -> dict:
    """Трейлинг-стоп на стороне Bybit: стоп идёт за ценой на расстоянии dist (в единицах цены)."""
    _need_live(body)
    creds, symbol = _creds_for(str(body.get("symbol") or ""))
    pos = state(symbol).get("position")
    if not pos:
        raise DomError("позиции по этой монете нет")
    dist = float(body.get("dist") or 0)
    if dist <= 0:
        raise DomError("расстояние трейлинга должно быть больше нуля")
    last = bx.get_last_price(symbol)
    bx.set_trailing_stop(creds["api_key"], creds["api_secret"], symbol, dist, last, side=pos["side"].lower())
    print(f"[dom] trail {symbol} {dist}")
    return {"ok": True}


def pnl(hours: int = 24) -> dict:
    """Финансовый результат реального счёта (ключ ручной торговли) за последние N часов. Только чтение."""
    import time  # noqa: PLC0415
    creds, isolated = mt.manual_creds("bybit")
    if not creds:
        return {"ok": False, "error": "нет торгового ключа Bybit", "rows": []}
    end = int(time.time() * 1000); start = end - hours * 3600 * 1000
    p = bx._signed_get("/v5/position/closed-pnl", creds["api_key"], creds["api_secret"],
                       {"category": "linear", "startTime": start, "endTime": end, "limit": 100})
    rows = [{"symbol": r.get("symbol"), "side": "LONG" if r.get("side") == "Sell" else "SHORT",
             "pnl": float(r.get("closedPnl") or 0), "t": int(r.get("updatedTime") or 0),
             "entry": float(r.get("avgEntryPrice") or 0), "exit": float(r.get("avgExitPrice") or 0)}
            for r in p.get("result", {}).get("list", []) or []]
    return {"ok": True, "account": "субаккаунт" if isolated else "общий счёт (вместе с ботами)", "rows": rows}


# ---------- 2026-10-12: дневной лимит убытка (совет из роликов по скальпингу: дошёл до лимита — стоп на сегодня) ----------
import json as _json  # noqa: E402
import time as _time  # noqa: E402
from pathlib import Path as _Path  # noqa: E402

LIMIT_FILE = _Path(__file__).resolve().parent.parent / "bt_lab_bots" / "dom_day_limit.json"


def _lim_load() -> dict:
    try:
        return _json.loads(LIMIT_FILE.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {"loss_usd": 0}


def _today_pnl() -> float:
    lt = _time.localtime()
    midnight = _time.mktime((lt.tm_year, lt.tm_mon, lt.tm_mday, 0, 0, 0, 0, 0, -1)) * 1000
    r = pnl(hours=24)
    return round(sum(x["pnl"] for x in r.get("rows", []) if x["t"] >= midnight), 2) if r.get("ok") else 0.0


def day_limit() -> dict:
    """Настройки лимита и итог сегодняшнего дня (закрытые сделки реального счёта с 00:00)."""
    lim = _lim_load()
    try:
        today = _today_pnl()
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "error": f"Bybit: {exc}"[:150], **lim}
    loss = float(lim.get("loss_usd") or 0)
    return {"ok": True, "loss_usd": loss, "today": today, "locked": bool(loss and today <= -loss)}


def set_day_limit(body: dict) -> dict:
    """Включить/изменить лимит. Пока лимит сегодня уже сработал — ослабить или выключить его нельзя до завтра."""
    new = max(0.0, float(body.get("loss_usd") or 0))
    cur = day_limit()
    old = float(cur.get("loss_usd") or 0)
    if cur.get("locked") and (new == 0 or new > old):
        raise DomError("лимит на сегодня уже сработал — ослабить его можно только завтра")
    LIMIT_FILE.parent.mkdir(parents=True, exist_ok=True)
    LIMIT_FILE.write_text(_json.dumps({"loss_usd": new}), encoding="utf-8")
    return day_limit()


def guard_day_limit() -> None:
    """Вызывается перед каждым НОВЫМ реальным ордером (из стакана и ручного ордера терминала)."""
    st = day_limit()
    if st.get("locked"):
        raise DomError(f"дневной лимит убытка {st['loss_usd']:g}$ достигнут (сегодня {st['today']:+.2f}$) — "
                       f"новые сделки до завтра заблокированы. Закрыть или сдвинуть стоп по открытой позиции можно.")
