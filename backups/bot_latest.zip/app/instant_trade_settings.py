"""
Live on/off switch for the round-14 local trade-server -- the piece that
lets the Торговля tab place a real order the instant you tap the button,
with NO review-before-send step in Telegram. This is a kill switch
separate from TRADE_SERVER_ENABLED in .env: that env var controls whether
the HTTP server + tunnel even start up at process launch, while THIS
toggle (checked on every single incoming request, see app/trade_server.py)
lets the owner turn instant execution off immediately via
/instanttrade off in Telegram -- no restart, no waiting for the next poll
cycle -- if anything about it ever looks wrong live. Defaults to OFF for
the same reason app/autopilot_settings.py defaults to OFF: a fresh
install/restart should never silently place instant real orders.

Same plain-JSON-file, read-whole/write-whole pattern as
app/autopilot_settings.py/app/scan_settings.py -- appropriate at this
scale (one boolean, changed rarely, checked on every request)."""
from __future__ import annotations

import json
from pathlib import Path


class InstantTradeSettings:
    def __init__(self, path: Path):
        self.path = path
        if self.path.exists():
            raw = json.loads(self.path.read_text())
        else:
            raw = {}
        self.enabled: bool = bool(raw.get("enabled", False))

    def set_enabled(self, enabled: bool) -> None:
        self.enabled = enabled
        self.path.write_text(json.dumps({"enabled": enabled}, indent=2))

    def is_enabled(self) -> bool:
        return self.enabled
