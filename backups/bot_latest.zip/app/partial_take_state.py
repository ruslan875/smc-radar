"""
Tiny persisted dedup store for the partial-take-profit ADVISORY messages
main.py's _autopilot_worker sends (see app/autopilot.py's
decide_partial_take_advisories and its module docstring for why this half
of the "Вера" request is advisory-only and never auto-executed, unlike the
breakeven move). Tracks, per "exchange:symbol" key, the highest R-multiple
already advised on, so an open position sitting at +2.3R doesn't get the
same "consider taking partial profit" message every ~20s autopilot pass --
only a NEW, higher R level triggers another message. If the position later
closes and a fresh one opens on the same symbol, the first pass on the new
position naturally starts from R=0 again, so no explicit reset is needed
(a fresh call to decide_partial_take_advisories won't even include it until
it crosses the trigger again). Same plain-JSON-file pattern as
app/psycho_state.py -- one small dict, changed rarely.
"""
from __future__ import annotations

import json
from pathlib import Path


class PartialTakeAlertState:
    def __init__(self, path: Path):
        self.path = path
        if self.path.exists():
            raw = json.loads(self.path.read_text())
        else:
            raw = {}
        self._last_r: dict = raw.get("last_advised_r", {})

    def _save(self) -> None:
        self.path.write_text(json.dumps({"last_advised_r": self._last_r}, indent=2))

    def last_advised_r(self, key: str) -> float:
        return float(self._last_r.get(key, 0.0))

    def set_last_advised_r(self, key: str, r: float) -> None:
        self._last_r[key] = r
        self._save()
