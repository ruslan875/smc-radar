"""
Dynamically-added exchange API keys, 2026-08-23 round 5.

Companion to app.config.EXCHANGE_ENV_PREFIXES: those keys come from .env
and require editing a file + restarting the bot. This store lets the
owner add a key live, from their phone, via the Mini App's Settings tab
-> a /setkey command sent through the Telegram bot chat itself (see
main.py's _handle_access_message and mini_app/index.html's Settings
tab -- Telegram Mini Apps launched from the BotFather menu button can't
call WebApp.sendData(), so a pre-filled deep link into the bot chat is
the only realistic serverless way to get the form's values to the bot).

Storage mirrors AccessStore's plain-JSON-file pattern (app/access.py) --
same directory, same "read whole file, mutate in memory, write whole file
back" approach, appropriate at this scale (a handful of exchange keys,
written rarely, read every ~15min by build_health()).

Security note: this file holds plaintext API secrets, same as .env
already does for the statically-configured exchanges -- this store adds
no new exposure beyond what already existed for .env-configured keys,
it just gives the owner a second, more convenient way to add one. Keys
saved here are always meant to be READ-ONLY exchange keys, exactly like
the .env-configured ones (see .env.example's warnings) -- this module
has no way to enforce that itself, it's a per-exchange dashboard setting
the owner has to set correctly when creating the key.
"""
from __future__ import annotations

import json
from pathlib import Path


class ExchangeKeysStore:
    def __init__(self, path: Path):
        self.path = path
        if self.path.exists():
            raw = json.loads(self.path.read_text())
        else:
            raw = {}
        # exch_key (str, e.g. "okx") -> {"api_key":..., "api_secret":..., "passphrase": ... or None}
        self._keys: dict = raw.get("keys", {})

    def _save(self) -> None:
        self.path.write_text(json.dumps({"keys": self._keys}, indent=2, ensure_ascii=False))

    def set_key(self, exch_key: str, api_key: str, api_secret: str, passphrase: str | None = None) -> None:
        self._keys[exch_key] = {
            "api_key": api_key.strip(),
            "api_secret": api_secret.strip(),
            "passphrase": passphrase.strip() if passphrase else None,
        }
        self._save()

    def remove_key(self, exch_key: str) -> bool:
        """Not currently reachable from any command (no /unsetkey yet) --
        kept as a building block for when that's asked for, so the store
        doesn't need another migration then."""
        if exch_key in self._keys:
            del self._keys[exch_key]
            self._save()
            return True
        return False

    def get_all(self) -> dict:
        """Same shape as Settings.exchange_credentials, so callers can
        merge the two without any special-casing."""
        return dict(self._keys)
