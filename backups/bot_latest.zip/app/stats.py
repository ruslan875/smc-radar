"""
Supporting stats shown on the signal card: daily / average volume,
volatility, and correlation with BTC.
"""
from __future__ import annotations

import numpy as np
import pandas as pd


def daily_volume(df_1d: pd.DataFrame) -> float:
    """Volume of the most recent (possibly still-forming) daily candle, in base units."""
    return float(df_1d["volume"].iloc[-1])


def average_daily_volume(df_1d: pd.DataFrame, lookback: int = 20) -> float:
    """Average of the last `lookback` *completed* daily candles."""
    complete = df_1d.iloc[:-1] if len(df_1d) > 1 else df_1d
    window = complete.tail(lookback)
    return float(window["volume"].mean())


def volatility_pct(df: pd.DataFrame, period: int = 14) -> float:
    """ATR(period) as a percentage of the last close -- a simple, robust
    volatility read on whatever timeframe `df` is (e.g. 15m)."""
    high, low, close = df["high"], df["low"], df["close"]
    prev_close = close.shift(1)
    tr = pd.concat(
        [(high - low).abs(), (high - prev_close).abs(), (low - prev_close).abs()], axis=1
    ).max(axis=1)
    atr = tr.rolling(period, min_periods=period).mean().iloc[-1]
    last_close = close.iloc[-1]
    if pd.isna(atr) or last_close == 0:
        return 0.0
    return float(atr / last_close * 100)


def btc_correlation(df_symbol: pd.DataFrame, df_btc: pd.DataFrame, lookback: int = 100) -> float:
    """Pearson correlation of simple returns between the symbol and BTC,
    aligned on open_time, over the last `lookback` bars."""
    merged = pd.merge(
        df_symbol[["open_time", "close"]].rename(columns={"close": "close_sym"}),
        df_btc[["open_time", "close"]].rename(columns={"close": "close_btc"}),
        on="open_time",
        how="inner",
    ).tail(lookback + 1)
    if len(merged) < 10:
        return float("nan")
    ret_sym = merged["close_sym"].pct_change().dropna()
    ret_btc = merged["close_btc"].pct_change().dropna()
    n = min(len(ret_sym), len(ret_btc))
    if n < 10:
        return float("nan")
    corr = np.corrcoef(ret_sym.values[-n:], ret_btc.values[-n:])[0, 1]
    if np.isnan(corr):
        return float("nan")
    return float(corr)


def format_compact(value: float) -> str:
    """174300000 -> '174.3M', 850000 -> '850.0K'."""
    absval = abs(value)
    if absval >= 1_000_000_000:
        return f"{value / 1_000_000_000:.2f}B"
    if absval >= 1_000_000:
        return f"{value / 1_000_000:.1f}M"
    if absval >= 1_000:
        return f"{value / 1_000:.1f}K"
    return f"{value:.2f}"
