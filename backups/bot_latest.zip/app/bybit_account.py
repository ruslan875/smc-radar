"""Backward-compat shim. The Bybit client that used to live in this file
moved to app/exchanges/bybit.py on 2026-08-23, the same day, as part of a
redesign from Bybit-only to a multi-exchange architecture (the user trades
on several exchanges -- OKX, Bitget, MEXC, KuCoin, Gate.io were added
alongside Bybit; see app/exchanges/).

This file is kept so the command already documented and run once before
(`python app/bybit_account.py --smoke-test`) keeps working without anyone
needing to learn a new path. New code should import from
app.exchanges.bybit directly -- this shim just re-exports it under the
old names."""
from __future__ import annotations

import sys
from pathlib import Path

if __name__ == "__main__":
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from app.exchanges.bybit import (  # noqa: F401
    DISPLAY_NAME,
    REQUIRES_PASSPHRASE,
    BybitAuthError,
    fetch_closed_trades as fetch_closed_pnl,
)

if __name__ == "__main__":
    from app.exchanges._cli import run_smoke_test
    run_smoke_test(DISPLAY_NAME, fetch_closed_pnl, env_prefix="BYBIT", requires_passphrase=REQUIRES_PASSPHRASE)
