"""
Breakeven-autopilot for open positions, 2026-08-23, round 9 ("Вера"
trading-assistant features -- inspired by a third-party bot the user
shared screenshots of). Scoped via AskUserQuestion the same day: of the
several "Вера" features asked about, the user chose to build ALL of them,
and specifically asked for the stop-to-breakeven action to run FULLY
AUTOMATICALLY (no per-action Telegram confirmation) -- unlike /trade
(round 8), which always waits for the owner to review and tap Send.

That is a materially bigger step up in risk than anything shipped so far
in this project, so the design leans hard on making the trigger condition
completely OBJECTIVE and the action itself STRICTLY RISK-REDUCING:

  - The only thing this module ever does is move an EXISTING position's
    stop-loss to its own entry price (breakeven) -- it never opens a new
    position, never changes position size, never touches take-profit, and
    never moves a stop AWAY from breakeven. A stop can only ever end up
    tighter after this runs, never looser -- so even if the trigger fires
    "too early" by the owner's own taste, the worst case is a trade that
    exits at breakeven instead of running further into profit, not a
    trade that loses more than it already risked.
  - The trigger (decide_breakeven_moves below) is a single, deterministic
    number -- how many multiples of the ORIGINAL (entry - stop) distance
    the price has moved into profit (an "R multiple", Settings.
    autopilot_breakeven_trigger_r, default 1.0 = the classic "risk-free
    once +1R" rule) -- computed fresh every pass straight from Bybit's own
    reported avg_entry_price/mark_price/stop_loss for the position (see
    app/exchanges/bybit.py's fetch_open_positions(), round 9 extension).
    No technical-analysis judgment, no "looks like it's stalling" fuzziness
    anywhere in this path -- that kind of judgment call is exactly why the
    PARTIAL-take-profit idea from the same "Вера" request is deliberately
    NOT auto-executed (see decide_partial_take_advisories below and
    main.py's _autopilot_worker) -- only the objectively-triggerable
    breakeven move is.
  - Idempotent by construction, no separate "did we already do this"
    tracking file needed: once a stop has been moved to breakeven,
    stop_loss on the exchange's own position record now sits AT the entry
    price, which the "already at/past breakeven" check below correctly
    recognizes and skips on every subsequent pass -- the exchange's own
    state is the single source of truth, the same philosophy already used
    for set_leverage()'s retCode-110043-is-success handling (round 8).
  - main.py's _autopilot_worker (started unconditionally as a background
    thread, same pattern as _access_poll_worker) only calls decide_
    breakeven_moves + amend_stop_loss (and the partial-take advisory check
    below) when app.autopilot_settings.AutopilotSettings says the owner has
    explicitly turned it on via /autopilot on -- default is OFF (see that
    module) so a fresh clone/install never silently starts moving stops.
    Every successful move sends an immediate, mandatory Telegram
    notification to the owner (this is NOT configurable off).
  - Only ever acts on positions where a stop-loss is ALREADY set on the
    exchange (stop_loss is not None) -- this module never invents a fresh
    stop for a position that doesn't have one; that would be a
    fundamentally different (and riskier) kind of automatic action than
    "tighten a stop that's already there," and isn't what was asked for.
  - Uses the SAME trade-permission key as /trade (app/trade_keys_store.py)
    to both read positions and amend the stop -- deliberately not a
    separate credential, so there's exactly one key store this bot ever
    writes to a live exchange with (see main.py's _autopilot_worker)."""
from __future__ import annotations


def _missing(x) -> bool:
    """True for None OR float NaN. Added 2026-08-23 after catching a real
    bug during review: main.py's _autopilot_worker builds `positions` from
    app/exchanges/bybit.py's fetch_open_positions() DataFrame via
    df.to_dict("records") -- and pandas silently turns a column's None
    entries into float('nan') once that same column also holds a real
    number in another row (exactly the stop_loss/take_profit case: some
    open positions have one set, some don't). A plain `x is None` check
    misses NaN entirely, and NaN is uniquely dangerous here because EVERY
    comparison against it (`>=`, `<=`, `<`) silently evaluates to False --
    so `if stop_loss >= entry: continue` (the "already at breakeven"
    guard) and `if r_achieved < trigger_r: continue` (the trigger guard)
    would BOTH fail to fire, letting a position with no stop_loss at all
    fall through to actually getting one written at breakeven -- exactly
    the "invents a fresh stop where none existed" behavior this module's
    own docstring says it must never do. `x != x` is True only for NaN
    among numeric types, so this catches it without needing a pandas/math
    import in what is otherwise a dependency-free pure-function module."""
    return x is None or x != x


def decide_breakeven_moves(positions: list[dict], trigger_r: float) -> list[dict]:
    """`positions` is a list of dicts shaped like the rows
    app/exchanges/bybit.py's fetch_open_positions() DataFrame produces
    (symbol, side "long"/"short", avg_entry_price, mark_price, stop_loss --
    only these four fields plus symbol/side are read here). Returns one
    entry per position that should have its stop moved right now:
    {symbol, side, old_stop_loss, new_stop_loss, r_achieved}. Pure
    function, no I/O -- callers (main.py's autopilot loop, and this
    module's own tests) are responsible for actually calling
    amend_stop_loss() for each entry returned.

    A position is skipped (not included in the result), rather than
    raising, for every case where acting would be unsafe or pointless:
      - no stop_loss set on the exchange at all (nothing to tighten)
      - stop_loss already at or past breakeven for this side (already
        done, or the owner deliberately set it tighter themselves --
        never loosen it back out)
      - mark_price/avg_entry_price missing (can't compute R)
      - side isn't "long" or "short" (unexpected/malformed row)
      - computed R hasn't reached trigger_r yet"""
    moves: list[dict] = []
    for pos in positions:
        side = pos.get("side")
        entry = pos.get("avg_entry_price")
        mark = pos.get("mark_price")
        stop_loss = pos.get("stop_loss")
        symbol = pos.get("symbol")

        if side not in ("long", "short"):
            continue
        if _missing(entry) or _missing(mark) or _missing(stop_loss):
            continue
        if entry <= 0:
            continue

        if side == "long":
            if stop_loss >= entry:
                continue  # already at/past breakeven
            risk_distance = entry - stop_loss
            profit_distance = mark - entry
        else:
            if stop_loss <= entry:
                continue  # already at/past breakeven
            risk_distance = stop_loss - entry
            profit_distance = entry - mark

        if risk_distance <= 0:
            continue

        r_achieved = profit_distance / risk_distance
        if r_achieved < trigger_r:
            continue

        moves.append({
            "symbol": symbol,
            "side": side,
            "old_stop_loss": stop_loss,
            "new_stop_loss": entry,
            "r_achieved": round(r_achieved, 2),
        })
    return moves


def decide_partial_take_advisories(positions: list[dict], trigger_r: float) -> list[dict]:
    """ADVISORY ONLY -- unlike decide_breakeven_moves above, main.py's
    _autopilot_worker never calls an exchange write based on this
    function's output, only a Telegram message. This is the "частичная
    фиксация прибыли" half of the same AskUserQuestion bundle the user
    answered "Полностью автоматически" to -- but deliberately narrowed
    down to advisory-only, because unlike moving a stop to its own entry
    price (a single objective number, always risk-REDUCING, never
    reversible-for-the-worse), deciding to partially close a position is a
    fuzzier call: WHICH fraction to take, and whether stalling short of
    the take-profit zone means the move is genuinely done or just pausing,
    isn't something a lone R-multiple can safely decide unattended. So
    this stays a suggestion the owner acts on manually, same spirit as
    app/psycho_heuristics.py's alerts -- see the project doc's "Round 9"
    section for this scope decision being called out explicitly rather
    than silently applying "fully automatic" here too.

    `positions` -- same row shape as decide_breakeven_moves, plus
    take_profit here. Returns one entry per position worth flagging:
    {symbol, side, r_achieved, avg_entry_price, mark_price, take_profit}.
    Skipped (not flagged): no take_profit or stop_loss set on the exchange
    (nothing to measure progress against), mark/entry missing, side not
    long/short, R hasn't reached trigger_r yet, or price already reached
    take_profit (the exchange's own TP order handles that case -- nothing
    for an advisory to add)."""
    out: list[dict] = []
    for pos in positions:
        side = pos.get("side")
        entry = pos.get("avg_entry_price")
        mark = pos.get("mark_price")
        take_profit = pos.get("take_profit")
        stop_loss = pos.get("stop_loss")
        symbol = pos.get("symbol")

        if side not in ("long", "short"):
            continue
        if _missing(entry) or _missing(mark) or _missing(take_profit) or _missing(stop_loss):
            continue
        if entry <= 0:
            continue

        if side == "long":
            risk_distance = entry - stop_loss
            profit_distance = mark - entry
            reached_tp = mark >= take_profit
        else:
            risk_distance = stop_loss - entry
            profit_distance = entry - mark
            reached_tp = mark <= take_profit

        if risk_distance <= 0 or reached_tp:
            continue

        r_achieved = profit_distance / risk_distance
        if r_achieved < trigger_r:
            continue

        out.append({
            "symbol": symbol,
            "side": side,
            "r_achieved": round(r_achieved, 2),
            "avg_entry_price": entry,
            "mark_price": mark,
            "take_profit": take_profit,
        })
    return out
