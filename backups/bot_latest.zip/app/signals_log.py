"""signals_log.py — 2026-11-21. Журнал сигналов Mini App с проверкой результата.

ЗАЧЕМ. Mini App считает сигналы на телефоне тем же движком (vantorix-signals.js),
что терминал, и до сих пор нигде централизованно не сохранял, что показал и
сработало ли (на телефоне была только локальная история в localStorage, без
проверки результата и без общей статистики). Здесь ПК раз в цикл
health-публикации (15 мин, вызов из main.py's _maybe_publish_health) считает те
же сигналы через terminal/dist-cli/signal.cjs — тот же indicatorEngine.ts, одна
реализация, расхождение невозможно (см. комментарий в signalCli.ts) — и:

  1. дописывает НОВЫЕ сигналы (LONG/SHORT; NEUTRAL — не сделка, не пишем)
     в bot/signals_log.json (дедупликация по монета+ТФ+закрытая свеча+сторона);
  2. проверяет СТАРЫЕ: через CHECK_CANDLES свечей после сигнальной берёт
     закрытие — цена ушла в сторону сигнала («win», отработал) или против
     («loss»). Публичные свечи Bybit, ключи не нужны;
  3. считает накопительную статистику: всего сигналов, % отработавших, по парам.

ПУБЛИКАЦИЯ. В репозиторий Mini App (GitHub Pages) файл уходит тем же
push_json_file, что health.json/access.json, НО только когда существует
bot/signals_log_publish.flag — владелец запретил публикацию в GitHub без его
явного подтверждения. Без флага журнал просто ведётся локально.

Любой сбой здесь (нет node, нет сети, битый JSON) глотается с записью в stderr:
побочная функция не имеет права уронить рыночный цикл бота.
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
import time
from pathlib import Path

import requests

BASE = Path(__file__).resolve().parent.parent          # D:\VANTORIX\bot
SIGNAL_CLI = BASE.parent / "terminal" / "dist-cli" / "signal.cjs"
LOG_FILE = BASE / "signals_log.json"
PUBLISH_FLAG = BASE / "signals_log_publish.flag"
WATCHLIST_FILE = BASE / "watchlist.json"

TIMEFRAME = "60"           # канонический ТФ журнала = дефолт вкладки «Сигналы» Mini App
CHECK_CANDLES = 24         # через сколько свечей проверяем результат (24 часовые = сутки)
MAX_SIGNALS = 500          # сколько записей держим в журнале
FALLBACK_SYMBOLS = ["BTCUSDT", "ETHUSDT", "SOLUSDT"]


def _symbols() -> list:
    try:
        wl = json.loads(WATCHLIST_FILE.read_text(encoding="utf-8"))
        if isinstance(wl, list) and wl:
            return [str(s).upper() for s in wl][:8]
    except Exception:  # noqa: BLE001
        pass
    return FALLBACK_SYMBOLS


def _node() -> str | None:
    """node.exe: сначала PATH, потом типовые пути установки (у бота свой PATH,
    «C:\\Program Files\\nodejs» в нём не гарантирован — проверено 21.11.2026)."""
    cand = shutil.which("node")
    if cand:
        return cand
    for p in (r"C:\Program Files\nodejs\node.exe", r"C:\Program Files (x86)\nodejs\node.exe"):
        if Path(p).exists():
            return p
    return None


def _signal_for(symbol: str) -> dict | None:
    """Тот же расчёт, что на телефоне: node dist-cli/signal.cjs → один JSON в stdout."""
    node = _node()
    if not node:
        print("[signals_log] node не найден ни в PATH, ни в Program Files", file=sys.stderr)
        return None
    try:
        r = subprocess.run(
            [node, str(SIGNAL_CLI), "--symbol", symbol, "--timeframe", TIMEFRAME],
            capture_output=True, text=True, timeout=60, encoding="utf-8", errors="replace",
        )
        if r.returncode != 0 or not r.stdout.strip():
            return None
        return json.loads(r.stdout)
    except Exception as exc:  # noqa: BLE001
        print(f"[signals_log] {symbol}: {type(exc).__name__}: {exc}", file=sys.stderr)
        return None


def _load() -> dict:
    try:
        d = json.loads(LOG_FILE.read_text(encoding="utf-8"))
        if isinstance(d, dict) and isinstance(d.get("signals"), list):
            return d
    except Exception:  # noqa: BLE001
        pass
    return {"tf": TIMEFRAME, "check_candles": CHECK_CANDLES, "signals": []}


def _klines(symbol: str, limit: int = 60) -> list:
    """Публичные свечи Bybit, новейшие первыми: [[startMs, o, h, l, c, ...], ...]."""
    r = requests.get(
        "https://api.bybit.com/v5/market/kline",
        params={"category": "linear", "symbol": symbol, "interval": TIMEFRAME, "limit": limit},
        timeout=15,
    )
    return (r.json().get("result") or {}).get("list") or []


def _check_outcome(sig: dict) -> None:
    """Заполняет outcome, если прошло >= CHECK_CANDLES свечей. Меняет sig на месте."""
    try:
        kl = _klines(sig["symbol"], limit=CHECK_CANDLES + 40)
        candle_ms = int(sig["candle"])
        idx = next((i for i, k in enumerate(kl) if int(k[0]) == candle_ms), None)
        if idx is None or idx < CHECK_CANDLES:
            return  # свеча не найдена или N свечей ещё не прошло
        close_n = float(kl[idx - CHECK_CANDLES][4])
        entry = float(sig["entry"])
        side = 1 if sig["side"] == "LONG" else -1
        pct = (close_n / entry - 1) * 100 * side
        sig["outcome"] = "win" if pct > 0 else "loss"
        sig["outcome_pct"] = round(pct, 3)
        sig["outcome_close"] = close_n
        sig["outcome_candle"] = int(kl[idx - CHECK_CANDLES][0])
    except Exception as exc:  # noqa: BLE001
        print(f"[signals_log] проверка {sig.get('symbol')}: {type(exc).__name__}: {exc}", file=sys.stderr)


def _stats(signals: list) -> dict:
    checked = [s for s in signals if s.get("outcome") in ("win", "loss")]
    wins = sum(1 for s in checked if s["outcome"] == "win")
    by_symbol: dict = {}
    for s in signals:
        b = by_symbol.setdefault(s["symbol"], {"total": 0, "checked": 0, "wins": 0, "win_pct": None})
        b["total"] += 1
        if s.get("outcome") in ("win", "loss"):
            b["checked"] += 1
            b["wins"] += int(s["outcome"] == "win")
    for b in by_symbol.values():
        b["win_pct"] = round(b["wins"] / b["checked"] * 100, 1) if b["checked"] else None
    return {
        "total": len(signals),
        "pending": len(signals) - len(checked),
        "checked": len(checked),
        "wins": wins,
        "win_pct": round(wins / len(checked) * 100, 1) if checked else None,
        "by_symbol": by_symbol,
    }


def update_and_maybe_publish(settings) -> dict:
    """Вызывается из main.py каждый health-цикл. Возвращает журнал (для отладки)."""
    log = _load()
    have = {s.get("id") for s in log["signals"]}

    added = 0
    for symbol in _symbols():
        d = _signal_for(symbol)
        if not d:
            continue
        conf = d.get("confirmed") or {}
        side = conf.get("signal")
        if side not in ("LONG", "SHORT") or not conf.get("entry"):
            continue
        candle = d.get("lastClosedAt")
        sid = f"{symbol}|{TIMEFRAME}|{candle}|{side}"
        if sid in have:
            continue
        log["signals"].insert(0, {
            "id": sid,
            "ts": int(time.time()),
            "candle": candle,
            "symbol": symbol,
            "side": side,
            "entry": conf["entry"],
            "tp": conf.get("tp"),
            "sl": conf.get("sl"),
            "votes": {"long": conf.get("long"), "short": conf.get("short"), "neutral": conf.get("neutral")},
            "outcome": None,
        })
        have.add(sid)
        added += 1

    log["signals"] = log["signals"][:MAX_SIGNALS]
    for sig in log["signals"]:
        if sig.get("outcome") not in ("win", "loss"):
            _check_outcome(sig)

    log["updated_at"] = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    log["stats"] = _stats(log["signals"])
    tmp = LOG_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(log, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(LOG_FILE)
    if added:
        print(f"[signals_log] +{added} сигналов, всего {len(log['signals'])}")

    if not PUBLISH_FLAG.exists():
        return log
    token = getattr(settings, "github_token", None)
    repo = getattr(settings, "github_repo", None)
    if not (token and repo):
        return log
    try:
        from app.github_sync import push_json_file  # noqa: PLC0415
        push_json_file(token, repo, "signals_log.json", log, message="Update signals_log.json (auto)")
        print(f"[signals_log] опубликован ({len(log['signals'])} сигналов)")
    except Exception as exc:  # noqa: BLE001
        print(f"[signals_log] публикация: {type(exc).__name__}: {exc}", file=sys.stderr)
    return log
