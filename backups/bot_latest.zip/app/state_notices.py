"""app/state_notices.py — «состояние, а не событие»: одно сообщение на проблему.

ЧТО БЫЛО. У каждого торгового скрипта был свой набор в памяти процесса:

    _sent_state_notices: set = set()

Внутри одного запуска он работал правильно — про зависшую позицию писали один
раз. Но набор жил только в оперативке, а перезапусков у этих ботов много:
правка параметров, перезапуск панели, restart_all.bat, обычное закрытие окна.
Каждый старт начинал с чистого листа и заново рассылал все предупреждения,
которые всё ещё верны. Две стратегии следят за одними и теми же монетами, так
что каждое такое событие приходило дважды. В итоге чат забивался повторами
одного и того же текста про ARBUSDT.

ЧТО СТАЛО. Отметки лежат в файле рядом с состоянием ботов и переживают
перезапуск. Повтор возможен, но не чаще REMIND_AFTER_SECONDS — если проблема
висит сутками, раз в шесть часов о ней имеет смысл напомнить, иначе про неё
просто забудут. Это компромисс между «спам» и «молча проглотили».

ПОЧЕМУ ФАЙЛ, А НЕ БАЗА. Здесь десяток ключей, которые читаются раз в минуту.
Любое хранилище сложнее JSON было бы дороже самой задачи. Запись атомарная
(во временный файл и подмена), потому что два бота пишут в один файл: без
этого один мог бы прочитать наполовину записанный JSON и потерять все отметки.
"""
from __future__ import annotations

import json
import os
import time
from pathlib import Path

from app.config import BASE_DIR

STATE_NOTICES_FILE = BASE_DIR / "state_notices.json"

# Повторное напоминание о всё ещё не решённой проблеме.
REMIND_AFTER_SECONDS = 6 * 60 * 60


def _read() -> dict:
    try:
        raw = STATE_NOTICES_FILE.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return {}
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        # Побитый файл не должен мешать боту торговать: начинаем с чистого
        # листа. Худшее следствие — одно лишнее сообщение.
        return {}
    return data if isinstance(data, dict) else {}


def _write(data: dict) -> None:
    try:
        tmp = STATE_NOTICES_FILE.with_suffix(STATE_NOTICES_FILE.suffix + f".tmp{os.getpid()}")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(STATE_NOTICES_FILE)
    except OSError:
        # Не смогли сохранить — не повод падать. В худшем случае сообщение
        # повторится после перезапуска, как было раньше.
        pass


def _key(bot_id: str, symbol: str, kind: str) -> str:
    return f"{bot_id}|{symbol}|{kind}"


def should_send(bot_id: str, symbol: str, kind: str) -> bool:
    """True, если про это ещё не писали или прошло больше REMIND_AFTER_SECONDS."""
    entry = _read().get(_key(bot_id, symbol, kind))
    if not isinstance(entry, dict):
        return True
    last = entry.get("last_sent_at")
    if not isinstance(last, (int, float)):
        return True
    return (time.time() - last) >= REMIND_AFTER_SECONDS


def mark_sent(bot_id: str, symbol: str, kind: str) -> None:
    data = _read()
    data[_key(bot_id, symbol, kind)] = {
        "last_sent_at": time.time(),
        "bot": bot_id,
        "symbol": symbol,
        "kind": kind,
    }
    _write(data)


def clear(bot_id: str, symbol: str, kind: str) -> None:
    """Проблема ушла — забываем о ней, чтобы следующий случай снова заметили."""
    data = _read()
    if data.pop(_key(bot_id, symbol, kind), None) is not None:
        _write(data)


def notify_once(notify, bot_id: str, symbol: str, kind: str, message: str) -> None:
    """Отправляет сообщение, если про эту же проблему давно не писали.

    Отметка ставится ДО отправки намеренно: если Telegram сейчас недоступен и
    notify бросит исключение, лучше пропустить одно уведомление, чем при
    каждом цикле опроса пытаться заново и получить шквал сообщений в момент,
    когда связь восстановится."""
    if not should_send(bot_id, symbol, kind):
        return
    mark_sent(bot_id, symbol, kind)
    notify(message)
