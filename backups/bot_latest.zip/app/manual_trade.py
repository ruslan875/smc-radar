"""Ручной ордер — общий для терминала (windows_app/server.py) и Telegram-бота
(main.py: /buy, /sell, кнопка «Открыть сделку» под /aiidea и /aipick).

2026-09-24. Раньше вся логика жила в server.py, а бот открывал сделки только
старой командой /trade без новых защит. Теперь оба пути идут через этот
модуль, а он — через app/trade_executor.execute_trade() (торговый ключ,
плечо ≤ MAX_TRADE_LEVERAGE, стоп с правильной стороны, недельный риск-бюджет).

Защиты поверх execute_trade:
  * размер позиции не больше MANUAL_MAX_NOTIONAL_USDT (.env, по умолчанию 100);
  * стоп обязателен: 0.2–10 % от цены;
  * не чаще одного ордера в 10 секунд;
  * монеты, которыми торгуют живые боты, на ОБЩЕМ счёте запрещены — на Bybit
    одна позиция на монету, и ручная сделка слилась бы с позицией бота.
    С ключом субаккаунта (слот "manual" в trade_keys.json) — можно всё.
"""
from __future__ import annotations

import json
import os
import re
import sys
import time

from app.config import BASE_DIR, STATE_FILE, TRADE_KEYS_FILE, Settings
from app.trade_keys_store import TradeKeysStore

MANUAL_SLOT = "manual"
BOT_STATE_FILES = [
    ("KC/ROC грид", BASE_DIR / "kc_roc_cci_wt_grid_live_state.json"),
    ("Latuserge", BASE_DIR / "long_strategy15_latuserge_live_state.json"),
]
_LAST = {"at": 0.0}


class ManualTradeError(Exception):
    def __init__(self, message: str, status: int = 400):
        super().__init__(message)
        self.message = message
        self.status = status


def norm_symbol(sym: str) -> str:
    """btc / BTC-USDT-SWAP / BTC/USDT:USDT / BTCUSDT -> BTCUSDT."""
    s = (sym or "").upper().replace("-SWAP", "").replace(":USDT", "")
    s = re.sub(r"[^A-Z0-9]", "", s)
    if s and not s.endswith("USDT"):
        s += "USDT"
    return s


def manual_creds(exch: str = "bybit") -> tuple[dict | None, bool]:
    """(ключ, это_субаккаунт)."""
    store = TradeKeysStore(TRADE_KEYS_FILE)
    own = store.get_all_for_strategy(MANUAL_SLOT).get(exch)
    if own:
        return own, True
    return store.get_all().get(exch), False


def bot_symbols() -> dict:
    """монета -> (бот, в_сделке_ли) по state-файлам живых ботов."""
    out: dict = {}
    for label, path in BOT_STATE_FILES:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        for sym, deal in (data or {}).items():
            if isinstance(deal, dict):
                prev = out.get(sym)
                out[sym] = (label, bool(deal.get("in_deal")) or bool(prev and prev[1]))
    return out


def _num(v, name: str, allow_none: bool = False):
    if v in (None, "", 0, "0") and allow_none:
        return None
    try:
        return float(v)
    except (TypeError, ValueError):
        raise ManualTradeError(f"{name} должно быть числом") from None


def prepare(symbol: str, side: str, usdt, leverage, sl_pct, tp_pct=None, trail_pct=None,
            settings: Settings | None = None) -> dict:
    """Проверки + расчёт объёма, стопа, тейка, трейлинга. Ордер НЕ отправляет."""
    from app.exchanges import bybit as bx  # noqa: PLC0415
    settings = settings or Settings.load()
    symbol = norm_symbol(symbol)
    side = (side or "").upper()
    if not symbol or side not in ("LONG", "SHORT"):
        raise ManualTradeError("нужны монета и направление (LONG/SHORT)")
    creds, isolated = manual_creds("bybit")
    if not creds:
        raise ManualTradeError("нет торгового ключа Bybit (/tradekey)")
    if not isolated:
        bs = bot_symbols().get(symbol)
        if bs:
            raise ManualTradeError(
                f"{symbol} торгует бот «{bs[0]}»{' (сейчас в сделке)' if bs[1] else ''} на этом же счёте — "
                f"ордер слился бы с его позицией. Выбери другую монету или подключи ключ субаккаунта "
                f"(терминал → ручной ордер → «🔑 Субаккаунт»).")
    usdt = _num(usdt, "сумма")
    lev = int(_num(leverage, "плечо"))
    sl_pct = _num(sl_pct, "стоп")
    tp_pct = _num(tp_pct, "тейк", allow_none=True)
    trail_pct = _num(trail_pct, "трейлинг", allow_none=True)
    max_usdt = float(os.getenv("MANUAL_MAX_NOTIONAL_USDT", "100"))
    if usdt <= 0:
        raise ManualTradeError("сумма должна быть больше нуля")
    if usdt > max_usdt:
        raise ManualTradeError(f"сумма {usdt:g} USDT больше лимита {max_usdt:g} USDT "
                               f"(меняется в .env: MANUAL_MAX_NOTIONAL_USDT)")
    if not 0.2 <= sl_pct <= 10:
        raise ManualTradeError("стоп обязателен: от 0.2% до 10%")
    if tp_pct is not None and not 0.1 <= tp_pct <= 50:
        raise ManualTradeError("тейк от 0.1% до 50% (или без тейка)")
    if trail_pct is not None and not 0.2 <= trail_pct <= 10:
        raise ManualTradeError("трейлинг от 0.2% до 10% (или без трейлинга)")
    if lev < 1 or lev > settings.max_trade_leverage:
        raise ManualTradeError(f"плечо от 1 до {settings.max_trade_leverage} (MAX_TRADE_LEVERAGE в .env)")

    try:
        price = bx.get_last_price(symbol)
        info = bx.get_instrument_info(symbol)
    except Exception as exc:  # noqa: BLE001
        raise ManualTradeError(f"нет такой монеты на Bybit или биржа не ответила: {exc}") from None
    step, min_qty = info["qty_step"], info["min_order_qty"]
    qty = int((usdt / price) / step) * step          # сумма = размер позиции (notional)
    qty = float(f"{qty:.10f}".rstrip("0").rstrip(".") or 0)
    if qty < min_qty:
        raise ManualTradeError(f"слишком маленькая сумма: минимум {min_qty:g} {symbol.replace('USDT', '')} "
                               f"≈ {min_qty * price:.2f} USDT")
    d = 1 if side == "LONG" else -1
    sl = round(price * (1 - d * sl_pct / 100), 10)
    tp = round(price * (1 + d * tp_pct / 100), 10) if tp_pct else None
    tick = info.get("tick_size") or 0
    trail = None
    if trail_pct:
        dist = price * trail_pct / 100
        act = price * (1 + d * sl_pct / 100)          # включается при прибыли = стопу (1R)
        if tick:
            dist = max(tick, round(dist / tick) * tick)
            act = round(act / tick) * tick
        trail = {"distance": dist, "active_price": act, "pct": trail_pct}
    return {"symbol": symbol, "side": side, "price": price, "qty": qty, "notional": round(qty * price, 2),
            "margin": round(qty * price / lev, 2), "leverage": lev, "stop_loss": sl, "take_profit": tp,
            "sl_pct": sl_pct, "tp_pct": tp_pct, "risk_usdt": round(qty * abs(price - sl), 2),
            "max_usdt": max_usdt, "trailing": trail, "isolated": isolated,
            "account": "субаккаунт" if isolated else "общий счёт"}


def execute(preview: dict, source: str = "терминал", settings: Settings | None = None) -> dict:
    """Отправляет ордер по результату prepare(). Шлёт отчёт в Telegram."""
    from app.exchanges import bybit as bx  # noqa: PLC0415
    from app.state import StateStore  # noqa: PLC0415
    from app.trade_executor import execute_trade  # noqa: PLC0415
    settings = settings or Settings.load()
    now = time.time()
    if now - _LAST["at"] < 10:
        raise ManualTradeError("ордер уже отправлен — подожди 10 секунд", status=429)
    _LAST["at"] = now
    creds, isolated = manual_creds("bybit")
    p = preview
    result = execute_trade("bybit", p["symbol"], "buy" if p["side"] == "LONG" else "sell", p["qty"],
                           p["leverage"], p["stop_loss"], p["take_profit"], False, settings,
                           StateStore(STATE_FILE), trade_creds_override=creds)
    ok = bool(result.get("ok"))
    msg = (f"✋ <b>Ручной ордер ({source})</b> · {p['symbol']} {p['side']} · "
           f"{'субаккаунт' if isolated else 'общий счёт'}\n"
           + (f"Объём {p['qty']:g} (~{p['notional']} USDT, x{p['leverage']}) · стоп {p['stop_loss']:.6g}"
              + (f" · тейк {p['take_profit']:.6g}" if p["take_profit"] else "")
              + f"\nРиск до стопа ≈ {p['risk_usdt']} USDT"
              if ok else f"❌ Не открыт: {result.get('reason')}"))
    trail_note = None
    if ok and p.get("trailing"):
        tr = p["trailing"]
        for _ in range(3):
            time.sleep(1.5)       # позиция должна появиться на бирже
            try:
                bx.set_trailing_stop(creds["api_key"], creds["api_secret"], p["symbol"], tr["distance"],
                                     tr["active_price"], side=p["side"].lower())
                trail_note = f"трейлинг {tr['pct']}% включится при цене {tr['active_price']:.6g}"
                break
            except Exception as exc:  # noqa: BLE001
                trail_note = f"⚠ трейлинг не поставлен ({exc}) — позиция со стопом, поставь трейлинг вручную"
        msg += f"\n↗️ {trail_note}"
    try:
        from app.telegram_client import TelegramClient  # noqa: PLC0415
        if settings.telegram_token and settings.telegram_chat_id:
            TelegramClient(settings.telegram_token, settings.telegram_chat_id).send_message(msg)
    except Exception as exc:  # noqa: BLE001 -- уведомление не должно влиять на ордер
        print(f"[manual-trade] telegram: {exc}", file=sys.stderr)
    print(f"[manual-trade] {source} {p['symbol']} {p['side']} qty={p['qty']} -> {result}")
    if not ok:
        raise ManualTradeError(result.get("reason") or "биржа отклонила ордер")
    return {"ok": True, **p, "order_id": result.get("order_id"), "trailing_note": trail_note}
