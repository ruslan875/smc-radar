"""
SMC detector, rewritten as a two-stage state machine to match the actual
trading rule:

    слом структуры (BOS/CHoCH) + ордерблок + РЕАКЦИЯ от зоны.
    Без сетапа — без сделки.

Stage 1 (`detect_structure_break` + `arm_zone`): a fresh BOS/CHoCH just
confirmed on the closed candle -> we don't enter yet, we *arm* a zone
(the order block behind the impulse, extended with any FVG inside the
same leg). This zone is persisted by the caller (see app/state.py) and
re-checked on every subsequent poll.

Stage 2 (`check_zone_reaction`): once price has come back and tapped the
armed zone, we look for a *reaction* candle (a close back in the trade
direction, not just a wick) before firing an actual signal. This is
what "ждать" means in practice, and it's the piece the first version of
this bot skipped.

In parallel, `detect_liquidity_sweep` covers the third setup type
(снятие ликвидности): a wick that pierces a recent swing extreme and
closes back inside on the same bar is itself the reaction (no separate
wait needed) -> fires immediately, tagged distinctly as "SWEEP" so it's
never confused with a BOS/CHoCH read.

`structure_direction` gives a same-shaped read on a higher timeframe, so
the caller can require the entry timeframe's signal to agree with the
1H/4H trend before acting on it -- matching "1H/4H для тренда, 5m/15m
для входов".

Stop buffer, 2026-08-22: `stop_buffer_sweep.py` re-simulated the full
2-year backtest with a widened ATR buffer and found that ONLY
CHoCH + Order Block+FVG confluence (no BOS, no plain OB, no sweep) turns
net-positive R in BOTH out-of-sample split halves at every fee scenario
once the buffer is widened to 1.5x ATR (was 0.15x). Every other
event/zone_kind combination stayed net-negative even with a wider stop --
see the Claude project doc for the full numbers. So the wider buffer is
applied ONLY to that specific combo (`_zone_reaction_buffer_mult`); every
other combo keeps the original tight buffer unchanged, so existing
backtest CSVs for BOS/plain-OB/sweep trades stay meaningful.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

import pandas as pd

Direction = Literal["long", "short"]
ZoneKind = Literal["OB", "OB+FVG"]
StructureEvent = Literal["BOS", "CHoCH", "SWEEP"]

# 2026-08-24: bar duration per timeframe string, in minutes -- same set as
# app/data.py's INTERVAL_MAP (kept as a separate literal dict on purpose,
# so app/smc.py doesn't need to import app/data.py just for this one
# lookup). Used by check_zone_reaction/zone_expired below to convert
# "how many bars ago" into a real elapsed-time comparison -- see the bug
# note on PendingZone.armed_index for why this matters.
TIMEFRAME_MINUTES = {
    "1m": 1, "3m": 3, "5m": 5, "15m": 15, "30m": 30, "1h": 60, "4h": 240, "1d": 1440,
}


def _bar_timedelta(timeframe: str) -> pd.Timedelta:
    return pd.Timedelta(minutes=TIMEFRAME_MINUTES.get(timeframe, 15))


@dataclass
class Swing:
    index: int
    time: pd.Timestamp
    price: float
    kind: Literal["high", "low"]


@dataclass
class PendingZone:
    """A structure break has happened and this zone is now 'armed' --
    waiting for price to tap it and react. Persisted across polls."""
    symbol: str
    timeframe: str
    direction: Direction
    top: float
    bottom: float
    zone_kind: ZoneKind
    structure_event: StructureEvent
    # 2026-08-24 BUG FIX NOTE: armed_index is a *positional* index into the
    # DataFrame that happened to be in memory at arm() time. In the live
    # bot every poll fetches a brand-new rolling window (see main.py's
    # _prefetch_klines / process_symbol -- a fresh df_cache every run_once
    # call), so a *later* poll's df has its own unrelated 0-based index --
    # comparing this old positional index against a future df's positions
    # is meaningless (they're both usually ~248, regardless of how much
    # real time actually passed). That bug meant check_zone_reaction's
    # "wait for a bar after arming" guard was almost always true
    # immediately, so Stage-2 zone reactions effectively never fired
    # outside of backtest.py's single continuously-grown DataFrame, and
    # zone_expired() never expired anything either -- zones just piled up
    # in state.json forever. Fixed by keying both checks off armed_time
    # (a real, absolute UTC timestamp, valid across independent re-fetches)
    # instead. armed_index is kept only for debugging/display -- nothing
    # still relies on it being comparable across polls.
    armed_index: int
    armed_time: pd.Timestamp
    swing_broken: float
    expires_after_bars: int = 60

    @property
    def key(self) -> str:
        return f"{self.symbol}:{self.timeframe}:{self.direction}:{self.armed_time.isoformat()}"

    def to_dict(self) -> dict:
        return {
            "symbol": self.symbol, "timeframe": self.timeframe, "direction": self.direction,
            "top": self.top, "bottom": self.bottom, "zone_kind": self.zone_kind,
            "structure_event": self.structure_event, "armed_index": self.armed_index,
            "armed_time": self.armed_time.isoformat(), "swing_broken": self.swing_broken,
            "expires_after_bars": self.expires_after_bars,
        }

    @staticmethod
    def from_dict(d: dict) -> "PendingZone":
        return PendingZone(
            symbol=d["symbol"], timeframe=d["timeframe"], direction=d["direction"],
            top=d["top"], bottom=d["bottom"], zone_kind=d["zone_kind"],
            structure_event=d["structure_event"], armed_index=d["armed_index"],
            armed_time=pd.Timestamp(d["armed_time"]), swing_broken=d["swing_broken"],
            expires_after_bars=d.get("expires_after_bars", 60),
        )


@dataclass
class Signal:
    direction: Direction
    structure_event: StructureEvent
    zone_kind: ZoneKind
    trigger_index: int
    trigger_time: pd.Timestamp
    entry: float
    stop_loss: float
    nearest_target: float | None


# ---------------------------------------------------------------- swings --

def find_swings(df: pd.DataFrame, left: int = 3, right: int = 3) -> list[Swing]:
    """Fractal swing highs/lows, confirmed `right` bars after the pivot
    (no repaint once confirmed)."""
    highs = df["high"].values
    lows = df["low"].values
    n = len(df)
    swings: list[Swing] = []
    for i in range(left, n - right):
        window_h = highs[i - left : i + right + 1]
        if highs[i] == window_h.max() and (highs[i] > window_h[:left]).all() and (highs[i] > window_h[left + 1 :]).all():
            swings.append(Swing(i, df["open_time"].iloc[i], float(highs[i]), "high"))
        window_l = lows[i - left : i + right + 1]
        if lows[i] == window_l.min() and (lows[i] < window_l[:left]).all() and (lows[i] < window_l[left + 1 :]).all():
            swings.append(Swing(i, df["open_time"].iloc[i], float(lows[i]), "low"))
    swings.sort(key=lambda s: s.index)
    return swings


def structure_direction(df: pd.DataFrame, left: int = 3, right: int = 3) -> Literal["up", "down", "range"] | None:
    """Same-shaped structure read as the break detector, meant for a
    higher timeframe: HH+HL -> up, LH+LL -> down, otherwise range.
    Returns None if there isn't enough swing history yet."""
    swings = find_swings(df, left, right)
    highs = [s for s in swings if s.kind == "high"]
    lows = [s for s in swings if s.kind == "low"]
    if len(highs) < 2 or len(lows) < 2:
        return None
    up = highs[-1].price > highs[-2].price and lows[-1].price > lows[-2].price
    down = highs[-1].price < highs[-2].price and lows[-1].price < lows[-2].price
    if up:
        return "up"
    if down:
        return "down"
    return "range"


# ----------------------------------------------------------- order block --

def _last_opposite_candle(df: pd.DataFrame, upto_index: int, direction: Direction, lookback: int = 12) -> int | None:
    """Last candle whose body is opposite `direction`, searching backwards
    from `upto_index` -- the classic 'last down-close candle before the
    up-impulse' (or mirrored for shorts)."""
    start = max(0, upto_index - lookback)
    for i in range(upto_index, start - 1, -1):
        o, c = df["open"].iloc[i], df["close"].iloc[i]
        if direction == "long" and c < o:
            return i
        if direction == "short" and c > o:
            return i
    return None


def _fvg_in_leg(df: pd.DataFrame, leg_start: int, leg_end: int, direction: Direction) -> tuple[float, float] | None:
    """Scans candles [leg_start, leg_end] for a 3-candle fair value gap in
    the direction of the move. Returns (top, bottom) of the *most recent*
    (freshest / closest to the break) unfilled gap found, or None."""
    best: tuple[float, float] | None = None
    for i in range(leg_start + 1, leg_end):
        if i - 1 < 0 or i + 1 > leg_end:
            continue
        c1_high, c1_low = df["high"].iloc[i - 1], df["low"].iloc[i - 1]
        c3_high, c3_low = df["high"].iloc[i + 1], df["low"].iloc[i + 1]
        if direction == "long" and c1_high < c3_low:
            best = (float(c3_low), float(c1_high))  # top, bottom
        elif direction == "short" and c1_low > c3_high:
            best = (float(c1_low), float(c3_high))  # top, bottom
    return best


def _atr(df: pd.DataFrame, period: int = 14) -> pd.Series:
    high, low, close = df["high"], df["low"], df["close"]
    prev_close = close.shift(1)
    tr = pd.concat(
        [(high - low).abs(), (high - prev_close).abs(), (low - prev_close).abs()], axis=1
    ).max(axis=1)
    return tr.rolling(period, min_periods=period).mean()


# Buffer multipliers for the stop, in ATR(14) units -- see the module
# docstring's "Stop buffer, 2026-08-22" note for why CHoCH+OB+FVG is
# special-cased to a much wider buffer than everything else.
WIDE_ZONE_BUFFER_ATR_MULT = 1.5
DEFAULT_ZONE_BUFFER_ATR_MULT = 0.15
DEFAULT_SWEEP_BUFFER_ATR_MULT = 0.10


def _zone_reaction_buffer_mult(structure_event: str, zone_kind: str) -> float:
    if structure_event == "CHoCH" and zone_kind == "OB+FVG":
        return WIDE_ZONE_BUFFER_ATR_MULT
    return DEFAULT_ZONE_BUFFER_ATR_MULT


# ------------------------------------------------------- stage 1: break --

@dataclass
class BreakEvent:
    direction: Direction
    structure_event: Literal["BOS", "CHoCH"]
    index: int
    time: pd.Timestamp
    swing_broken: float
    swing_index: int


def detect_structure_break(df: pd.DataFrame, swing_left: int = 3, swing_right: int = 3) -> BreakEvent | None:
    """Looks at the most recently *closed* candle (index len(df)-2, since
    the caller is expected to pass a frame where the last row may still be
    forming) and checks whether it just confirmed a BOS or CHoCH."""
    if len(df) < (swing_left + swing_right + 20):
        return None
    check_idx = len(df) - 2
    swings = find_swings(df.iloc[: check_idx + swing_right + 1].reset_index(drop=True), swing_left, swing_right)
    swings = [s for s in swings if s.index < check_idx]
    if len(swings) < 2:
        return None

    last_high = next((s for s in reversed(swings) if s.kind == "high"), None)
    last_low = next((s for s in reversed(swings) if s.kind == "low"), None)
    if last_high is None or last_low is None:
        return None

    highs = [s for s in swings if s.kind == "high"]
    lows = [s for s in swings if s.kind == "low"]
    uptrend = downtrend = None
    if len(highs) >= 2 and len(lows) >= 2:
        uptrend = highs[-1].price > highs[-2].price and lows[-1].price > lows[-2].price
        downtrend = highs[-1].price < highs[-2].price and lows[-1].price < lows[-2].price

    close = df["close"].iloc[check_idx]
    prev_close = df["close"].iloc[check_idx - 1]

    if close > last_high.price and prev_close <= last_high.price:
        return BreakEvent("long", "BOS" if uptrend else "CHoCH", check_idx, df["open_time"].iloc[check_idx],
                           last_high.price, last_high.index)
    if close < last_low.price and prev_close >= last_low.price:
        return BreakEvent("short", "BOS" if downtrend else "CHoCH", check_idx, df["open_time"].iloc[check_idx],
                           last_low.price, last_low.index)
    return None


def arm_zone(df: pd.DataFrame, event: BreakEvent, symbol: str, timeframe: str) -> PendingZone | None:
    """Builds the order block (+ FVG confluence tag) behind the impulse
    that caused `event`. This is Stage 1's output: something to watch,
    not yet a signal."""
    ob_idx = _last_opposite_candle(df, event.index, event.direction)
    if ob_idx is None:
        return None
    row = df.iloc[ob_idx]
    top = float(max(row["open"], row["close"], row["high"]))
    bottom = float(min(row["open"], row["close"], row["low"]))

    fvg = _fvg_in_leg(df, ob_idx, event.index, event.direction)
    zone_kind: ZoneKind = "OB"
    if fvg is not None:
        f_top, f_bottom = fvg
        # only count it as confluence if the FVG sits within/near the OB leg
        # (overlap or immediately adjacent) -- otherwise keep the OB as-is
        # and leave the FVG for a future independent read.
        if f_bottom <= top and f_top >= bottom:
            top = max(top, f_top)
            bottom = min(bottom, f_bottom)
            zone_kind = "OB+FVG"

    return PendingZone(
        symbol=symbol, timeframe=timeframe, direction=event.direction,
        top=top, bottom=bottom, zone_kind=zone_kind, structure_event=event.structure_event,
        armed_index=event.index, armed_time=event.time, swing_broken=event.swing_broken,
    )


# --------------------------------------------------- stage 2: reaction --

def check_zone_reaction(df: pd.DataFrame, zone: PendingZone, min_body_atr_mult: float = 0.35) -> Signal | None:
    """Call this on every poll for every still-pending zone. Looks only at
    the most recently closed candle: has price tapped the zone, and did
    that candle show a REAL reaction, not just a weak wobble through it?

    A reaction now requires all three:
      1. close is past the zone's MIDPOINT (not merely past the near edge)
         -- a candle that closes one tick above the zone bottom and calls
         it a day isn't a reaction, it's barely holding.
      2. a directional body (close on the trade side of open).
      3. body size >= `min_body_atr_mult` * ATR(14) -- filters out dojis /
         indecision candles that happen to close on the right side by
         accident.

    This is stricter than the original "close back in the trade direction"
    check -- tightened after backtesting showed the looser version fires
    on a lot of low-conviction taps that don't actually hold.

    Returns a Signal (fire now) or None (keep waiting / expired -- caller
    should drop the zone if `zone_expired` is True).
    """
    check_idx = len(df) - 2
    if check_idx < 0:
        return None
    row = df.iloc[check_idx]
    # 2026-08-24 bug fix: was `check_idx <= zone.armed_index` (positional --
    # meaningless once df is a fresh re-fetch each poll, see PendingZone's
    # armed_index docstring). Only evaluate a reaction on a bar that is
    # actually later, in real time, than the bar the zone was armed on.
    if row["open_time"] <= zone.armed_time:
        return None
    tapped = row["low"] <= zone.top and row["high"] >= zone.bottom

    if not tapped:
        return None

    zone_mid = (zone.top + zone.bottom) / 2
    atr = _atr(df, 14).iloc[check_idx]
    if pd.isna(atr):
        atr = float((df["high"] - df["low"]).iloc[max(0, check_idx - 14) : check_idx + 1].mean())
    body = abs(row["close"] - row["open"])
    min_body = min_body_atr_mult * atr

    if zone.direction == "long":
        reacted = row["close"] > zone_mid and row["close"] >= row["open"] and body >= min_body
    else:
        reacted = row["close"] < zone_mid and row["close"] <= row["open"] and body >= min_body

    if not reacted:
        return None

    entry = float(row["close"])
    buffer_mult = _zone_reaction_buffer_mult(zone.structure_event, zone.zone_kind)
    buffer = buffer_mult * atr  # reuse the ATR already computed for the reaction-body check above
    stop_loss = zone.bottom - buffer if zone.direction == "long" else zone.top + buffer

    swings = find_swings(df.iloc[: check_idx + 1].reset_index(drop=True), 3, 3)
    nearest_target = None
    if zone.direction == "long":
        candidates = [s.price for s in swings if s.kind == "high" and s.price > entry]
        if candidates:
            nearest_target = min(candidates)
    else:
        candidates = [s.price for s in swings if s.kind == "low" and s.price < entry]
        if candidates:
            nearest_target = max(candidates)

    return Signal(
        direction=zone.direction, structure_event=zone.structure_event, zone_kind=zone.zone_kind,
        trigger_index=check_idx, trigger_time=row["open_time"], entry=entry, stop_loss=float(stop_loss),
        nearest_target=nearest_target,
    )


def zone_expired(df: pd.DataFrame, zone: PendingZone) -> bool:
    # 2026-08-24 bug fix: was `(len(df) - 2 - zone.armed_index) >
    # zone.expires_after_bars` -- positional, meaningless across polls
    # once df is re-fetched fresh every time (see PendingZone.armed_index
    # docstring). Zones never actually expired in the live bot because of
    # this. Now measured as real elapsed time since armed_time, converted
    # to a bar count via the zone's own timeframe.
    check_idx = len(df) - 2
    if check_idx < 0:
        return False
    latest_time = df.iloc[check_idx]["open_time"]
    elapsed_bars = (latest_time - zone.armed_time) / _bar_timedelta(zone.timeframe)
    return elapsed_bars > zone.expires_after_bars


# --------------------------------------------- liquidity sweep (standalone) --

def detect_liquidity_sweep(df: pd.DataFrame, swing_left: int = 3, swing_right: int = 3) -> Signal | None:
    """Снятие ликвидности: the most recently closed candle wicks beyond
    the last confirmed swing extreme but closes back inside it. Unlike
    BOS/CHoCH this bar *is* the reaction -- no separate wait needed -- so
    it fires directly, tagged 'SWEEP' so it's never confused with a
    structure-break read."""
    if len(df) < (swing_left + swing_right + 20):
        return None
    check_idx = len(df) - 2
    swings = find_swings(df.iloc[: check_idx + swing_right + 1].reset_index(drop=True), swing_left, swing_right)
    swings = [s for s in swings if s.index < check_idx]
    if not swings:
        return None
    last_high = next((s for s in reversed(swings) if s.kind == "high"), None)
    last_low = next((s for s in reversed(swings) if s.kind == "low"), None)

    row = df.iloc[check_idx]
    atr = _atr(df, 14).iloc[check_idx]
    if pd.isna(atr):
        atr = float((df["high"] - df["low"]).iloc[max(0, check_idx - 14) : check_idx + 1].mean())

    # bearish sweep of a swing high -> short reaction
    if last_high is not None and row["high"] > last_high.price and row["close"] < last_high.price and row["close"] < row["open"]:
        entry = float(row["close"])
        stop_loss = float(row["high"] + DEFAULT_SWEEP_BUFFER_ATR_MULT * atr)
        lows_below = [s.price for s in swings if s.kind == "low" and s.price < entry]
        nearest = max(lows_below) if lows_below else None
        return Signal("short", "SWEEP", "OB", check_idx, row["open_time"], entry, stop_loss, nearest)

    # bullish sweep of a swing low -> long reaction
    if last_low is not None and row["low"] < last_low.price and row["close"] > last_low.price and row["close"] > row["open"]:
        entry = float(row["close"])
        stop_loss = float(row["low"] - DEFAULT_SWEEP_BUFFER_ATR_MULT * atr)
        highs_above = [s.price for s in swings if s.kind == "high" and s.price > entry]
        nearest = min(highs_above) if highs_above else None
        return Signal("long", "SWEEP", "OB", check_idx, row["open_time"], entry, stop_loss, nearest)

    return None
