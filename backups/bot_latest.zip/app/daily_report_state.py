"""
Persists yesterday's end-of-day wallet-balance snapshot per exchange,
2026-08-31, so the automatic daily trading-report digest (main.py's
`_daily_report_worker`) can compute a day-over-day return % without
Bybit exposing account-balance HISTORY directly -- today's "start of day"
capital is simply the balance this same report captured ~24h earlier at
the same UTC time (23:59 UTC by default, the user's own choice). The
first-ever report for a given exchange has no prior snapshot, so it shows
the current balance with a note instead of a (meaningless) 0%/undefined
return, and starts the chain from there.

Same read-whole-write-whole JSON pattern as every other small `*_state.py`
file in this project (AccessStore, ScanSettings, PartialTakeAlertState,
...) -- appropriate at this scale (one float per exchange, written once a
day).
"""
from __future__ import annotations

import json
from pathlib import Path


class DailyReportState:
    def __init__(self, path: Path):
        self.path = path
        if self.path.exists():
            self._data: dict = json.loads(self.path.read_text())
        else:
            self._data = {}

    def _save(self) -> None:
        self.path.write_text(json.dumps(self._data, indent=2, ensure_ascii=False))

    def get_start_balance(self, exch_key: str) -> float | None:
        return self._data.get(exch_key)

    def set_start_balance(self, exch_key: str, balance: float) -> None:
        self._data[exch_key] = balance
        self._save()
