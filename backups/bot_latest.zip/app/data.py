"""
Fetching public market data from Bybit (no API key needed for public endpoints).
"""
from __future__ import annotations

import time
from dataclasses import dataclass

import pandas as pd
import requests

BYBIT_BASE = "https://api.bybit.com"

# Bybit kline intervals: 1,3,5,15,30,60,120,240,360,720,D,W,M
INTERVAL_MAP = {
    "1m": "1",
    "3m": "3",
    "5m": "5",
    "15m": "15",
    "30m": "30",
    "1h": "60",
    "4h": "240",
    "1d": "D",
}


class DataError(RuntimeError):
    pass


def _get(path: str, params: dict, retries: int = 3, timeout: float = 10.0) -> dict:
    last_exc = None
    for attempt in range(retries):
        try:
            resp = requests.get(f"{BYBIT_BASE}{path}", params=params, timeout=timeout)
            resp.raise_for_status()
            payload = resp.json()
            if payload.get("retCode") != 0:
                raise DataError(f"Bybit API error: {payload.get('retMsg')}")
            return payload
        except (requests.RequestException, DataError) as exc:
            last_exc = exc
            time.sleep(1.5 * (attempt + 1))
    raise DataError(f"Failed to fetch {path} after {retries} attempts: {last_exc}")


def get_klines(symbol: str, timeframe: str = "15m", limit: int = 200, category: str = "linear") -> pd.DataFrame:
    """
    Returns a DataFrame indexed by open_time (UTC, tz-aware), columns:
    open, high, low, close, volume, turnover
    Sorted ascending (oldest first).
    """
    interval = INTERVAL_MAP[timeframe]
    payload = _get(
        "/v5/market/kline",
        {"category": category, "symbol": symbol, "interval": interval, "limit": limit},
    )
    rows = payload["result"]["list"]  # newest first
    if not rows:
        raise DataError(f"No kline data returned for {symbol} {timeframe}")

    df = pd.DataFrame(
        rows,
        columns=["open_time", "open", "high", "low", "close", "volume", "turnover"],
    )
    for col in ("open", "high", "low", "close", "volume", "turnover"):
        df[col] = df[col].astype(float)
    df["open_time"] = pd.to_datetime(df["open_time"].astype("int64"), unit="ms", utc=True)
    df = df.sort_values("open_time").reset_index(drop=True)
    return df


def get_top_symbols(n: int, include_btc: bool = False, category: str = "linear") -> list[str]:
    """Top N Bybit USDT perpetuals by 24h turnover (a liquidity/size proxy
    -- Bybit's public API doesn't expose market cap). Added 2026-08-22 for
    main.py's scan-universe setting (see app/scan_settings.py); originally
    lived only in scan_top_symbols.py, which now calls this too."""
    payload = _get("/v5/market/tickers", {"category": category})
    rows = payload["result"]["list"]
    usdt_rows = [r for r in rows if r["symbol"].endswith("USDT")]
    usdt_rows.sort(key=lambda r: float(r.get("turnover24h", 0) or 0), reverse=True)
    symbols = [r["symbol"] for r in usdt_rows]
    if not include_btc:
        symbols = [s for s in symbols if s != "BTCUSDT"]
    return symbols[:n]


def get_last_price(symbol: str, category: str = "linear") -> float:
    payload = _get("/v5/market/tickers", {"category": category, "symbol": symbol})
    lst = payload["result"]["list"]
    if not lst:
        raise DataError(f"No ticker data for {symbol}")
    return float(lst[0]["lastPrice"])


def get_ticker_stats(symbol: str, category: str = "linear") -> dict:
    """2026-09-07: same public (no API key) Bybit ticker endpoint as
    get_last_price, but also pulls the 24h change -- added for
    windows_app/server.py's "Обзор рынка" ticker row, which wants a
    price AND a real (not fabricated) 24h move for each configured
    symbol. Separate function rather than changing get_last_price's
    return shape, since get_last_price already has other callers
    (app/state.py, this project's live bots) that only want a bare
    float and shouldn't have to change to accommodate this."""
    payload = _get("/v5/market/tickers", {"category": category, "symbol": symbol})
    lst = payload["result"]["list"]
    if not lst:
        raise DataError(f"No ticker data for {symbol}")
    row = lst[0]
    return {
        "symbol": symbol,
        "last_price": float(row["lastPrice"]),
        "change_pct_24h": float(row.get("price24hPcnt", 0) or 0) * 100.0,
    }


@dataclass
class SymbolSpec:
    """Human-friendly wrapper: what we call it vs. the Bybit perpetual ticker."""
    label: str      # e.g. "ZEC"
    symbol: str      # e.g. "ZECUSDT"  (Bybit linear perpetual)
