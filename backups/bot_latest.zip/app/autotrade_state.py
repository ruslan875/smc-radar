"""
Tiny persisted dedup store for main.py's _autotrade_worker (2026-09-03,
"Screener auto-trade" feature -- see app/autotrade_settings.py's module
docstring for the full picture). Tracks which already-fired signals
(StateStore's own "sent" keys, see app/state.py's recent_signals(), scoped
per-exchange since the same signal could in principle be tradeable on more
than one connected exchange) have ALREADY been acted on -- successfully
opened, or definitively rejected by a guard in app/trading_guard.py -- so
the same signal is never re-evaluated (and never silently re-traded) on
every ~20s _autotrade_worker pass for as long as it stays within
signal_gate_max_age_minutes.

Deliberately marks a signal "handled" on BOTH a successful order AND a
guard rejection (leverage/stop-loss/risk-budget/gate) -- retrying a
rejected signal every ~20s for up to an hour hoping conditions change
would just be noise (a fresh signal on the same symbol later gets its own,
independent attempt regardless). The one case that does NOT get marked
handled is "symbol already has an open position" -- that is a routine,
expected skip (see _autotrade_worker), not a rejection, so the same signal
is naturally reconsidered on the next pass if the position closes before
the signal ages out.

Same plain-JSON-file, read-whole/write-whole pattern as
app/partial_take_state.py, with one addition: a size cap + oldest-first
eviction (mirroring app/state.py's StateStore._sent pruning) since unlike
that module's per-symbol "last R" dict (bounded by watchlist size), this
one grows by one entry per fired signal and has no natural ceiling on its
own."""
from __future__ import annotations

import json
import time
from pathlib import Path

_MAX_ENTRIES = 2000  # matches StateStore._sent's own cap -- plenty for this bot's signal volume


class AutoTradeState:
    def __init__(self, path: Path):
        self.path = path
        if self.path.exists():
            raw = json.loads(self.path.read_text())
        else:
            raw = {}
        self._handled: dict = raw.get("handled", {})  # dedup_key -> handled_at (unix seconds, for pruning only)

    def _save(self) -> None:
        """Atomic write -- same tmp-file-then-replace() pattern as
        app/state.py's StateStore._save(), for the same reason: this file
        can be read/written from the same background-thread poll loop
        shape (_autotrade_worker runs every ~20s, same as _autopilot_worker
        already does for its own state)."""
        tmp_path = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp_path.write_text(json.dumps({"handled": self._handled}, indent=2))
        tmp_path.replace(self.path)

    def already_handled(self, dedup_key: str) -> bool:
        return dedup_key in self._handled

    def mark_handled(self, dedup_key: str) -> None:
        self._handled[dedup_key] = time.time()
        if len(self._handled) > _MAX_ENTRIES:
            oldest = sorted(self._handled.items(), key=lambda kv: kv[1])[: len(self._handled) - _MAX_ENTRIES]
            for k, _ in oldest:
                self._handled.pop(k, None)
        self._save()
