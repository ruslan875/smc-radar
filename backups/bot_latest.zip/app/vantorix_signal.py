"""app/vantorix_signal.py — мост от Telegram-бота к движку индикаторов VANTORIX.

ПОЧЕМУ НЕ ПОРТ НА PYTHON. 34 индикатора живут в TypeScript
(`terminal/src/indicatorEngine.ts`): их видит человек в терминале, по ним
копится форвард-тест, по ним считается «Мозг». Переписать те же формулы ещё
раз на Python — значит завести вторую реализацию, которая рано или поздно
разойдётся с первой. Тогда терминал покажет LONG, бот напишет SHORT, и никто
не сможет сказать, кто прав, не сверяя две кодовые базы руками. Поэтому бот
запускает собранный `signal.cjs` и читает JSON: считает ровно тот код, что и
экран.

Цена решения: нужен установленный Node и один раз собранный CLI
(`npm run build:cli` в папке terminal). Обе проблемы диагностируются
внятным текстом ниже, а не молчаливым отсутствием ответа.
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
from pathlib import Path

from app.config import BASE_DIR


class SignalError(RuntimeError):
    """Понятная человеку причина, почему сигнал получить не удалось."""


# Терминал лежит рядом с ботом: D:\VANTORIX\{bot,terminal}. Переменная
# окружения нужна на случай другой раскладки — чтобы не править код.
def _cli_path() -> Path:
    override = os.getenv("VANTORIX_SIGNAL_CLI")
    if override:
        return Path(override)
    return BASE_DIR.parent / "terminal" / "dist-cli" / "signal.cjs"


def _node_path() -> str:
    override = os.getenv("NODE_EXE")
    if override and Path(override).exists():
        return override
    found = shutil.which("node")
    if found:
        return found
    raise SignalError(
        "Не найден Node.js — движок индикаторов написан на TypeScript и без Node не считается. "
        "Установи Node с nodejs.org или укажи полный путь к node.exe в переменной NODE_EXE."
    )


def _run_cli(argv: list[str], *, cwd: Path, timeout: float) -> dict:
    """Общий последний шаг для fetch_signal и fetch_ai_pick: запустить node,
    прочитать JSON из stdout, превратить любой сбой в понятный SignalError.
    Вынесено отдельно 2026-09-22 вместе с /aipick, чтобы у второго вызова
    движка не завелась вторая копия этой же обвязки."""
    try:
        proc = subprocess.run(
            argv,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=timeout,
            cwd=str(cwd),
        )
    except subprocess.TimeoutExpired:
        raise SignalError(
            f"Движок не ответил за {timeout:.0f} с. Обычно это медленный ответ Bybit — попробуй ещё раз."
        ) from None
    except OSError as exc:
        raise SignalError(f"Не удалось запустить движок: {exc}") from exc

    if proc.returncode != 0:
        detail = (proc.stderr or proc.stdout or "").strip()
        raise SignalError(detail[:400] or "Движок завершился с ошибкой без объяснения.")

    out = (proc.stdout or "").strip()
    if not out:
        raise SignalError("Движок ничего не вернул.")

    try:
        return json.loads(out)
    except json.JSONDecodeError as exc:
        # Именно поэтому CLI пишет диагностику в stderr, а в stdout — только
        # JSON. Если сюда попали, значит что-то ещё печатает в stdout.
        raise SignalError(f"Движок вернул не-JSON: {out[:200]!r} ({exc})") from exc


def fetch_signal(
    symbol: str,
    timeframe: str = "60",
    *,
    limit: int = 1000,
    threshold: float | None = None,
    tp_atr: float | None = None,
    sl_atr: float | None = None,
    timeout: float = 120.0,
) -> dict:
    """Считает консенсус 34 индикаторов и бэктест по одной монете.

    Бросает SignalError с текстом, который не стыдно показать в Telegram.
    """
    cli = _cli_path()
    if not cli.exists():
        raise SignalError(
            f"Движок индикаторов не собран: нет файла {cli}. "
            "Собери его один раз командой «npm run build:cli» в папке terminal."
        )

    argv = [_node_path(), str(cli), "--symbol", symbol.upper(), "--timeframe", str(timeframe),
            "--limit", str(int(limit))]
    if threshold is not None:
        argv += ["--threshold", str(threshold)]
    if tp_atr is not None:
        argv += ["--tp", str(tp_atr)]
    if sl_atr is not None:
        argv += ["--sl", str(sl_atr)]

    return _run_cli(argv, cwd=cli.parent.parent, timeout=timeout)


def fetch_ai_pick(
    symbol: str,
    timeframe: str = "60",
    *,
    limit: int = 1000,
    iterations: int = 240,
    timeout: float = 180.0,
) -> dict:
    """Просит движок (тот же signal.cjs, режим "--mode pick") перебрать
    `iterations` случайных конфигов стратегии на истории `symbol`/`timeframe`
    и вернуть топ-5 — ровно то же самое, что делает кнопка «Подобрать ИИ» в
    конструкторе терминала (см. searchBestConfigs в strategy.ts), просто
    вызванное из Telegram через /aipick вместо клика в браузере.

    Таймаут больше, чем у fetch_signal (180 с против 120): перебор из
    нескольких сотен бэктестов ощутимо дольше одного, а первый вызов после
    "холодного" запуска Node ещё и платит за старт V8 поверх этого.
    """
    cli = _cli_path()
    if not cli.exists():
        raise SignalError(
            f"Движок индикаторов не собран: нет файла {cli}. "
            "Собери его один раз командой «npm run build:cli» в папке terminal."
        )

    argv = [
        _node_path(), str(cli),
        "--mode", "pick",
        "--symbol", symbol.upper(),
        "--timeframe", str(timeframe),
        "--limit", str(int(limit)),
        "--iterations", str(int(iterations)),
    ]
    return _run_cli(argv, cwd=cli.parent.parent, timeout=timeout)
