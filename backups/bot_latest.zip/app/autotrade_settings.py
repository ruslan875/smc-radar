"""
Live on/off switch (PLUS the sizing pair and a concurrency cap) for the
"Screener auto-trade" feature, 2026-09-03 -- the user asked to have the
Screener "само подтягивать сигналы и открывать сделки", scoped down via
AskUserQuestion the same day to three decisions, all reflected here:

  1. Trigger = the bot's REAL validated signal (CHoCH+Ордерблок+FVG, the
     exact same one StateStore.recent_signals()/latest_active_signal()
     already track for the manual "Открывать только по сигналу" gate) --
     NOT the raw, explicitly-not-backtested Screener Score shown in the
     Mini App's Скринер tab. This module has no opinion on that -- it only
     stores whether auto-trading is on, and at what size -- but it's the
     reason main.py's _autotrade_worker reads app.state.StateStore rather
     than anything screener-related.
  2. Sizing = ONE capital_usdt amount + ONE leverage, applied to every
     symbol the trigger fires on -- not per-symbol. That pair lives here.
  3. Control = on/off from the Mini App's Торговля tab, mirroring the
     existing /autopilot on|off pattern (build the command, review it in
     Telegram, send) -- see main.py's _handle_autotrade_command.

2026-09-04 addition: `max_positions` -- direct user feedback after the
first live run ("автоторговля открывает все сделки хотя должна 3-4 сделки
и ждать пока не закроется"), i.e. the worker was opening a new position on
EVERY fresh signal with no cap on how many could be open at once. Defaults
to 3 (the low end of the user's own "3-4" -- a smaller default is the
safer direction to guess when a range is given and nothing else pins it
down; raise it with `/autotrade on <сумма> <плечо> <макс_сделок>`).
main.py's _autotrade_worker refuses to open anything new for an exchange
once its currently-open-position count has reached this, and simply waits
(no Telegram spam) until a position closes and frees a slot.

Deliberately OFF by default, same reasoning as app/autopilot_settings.py:
a fresh install/restart must never silently start opening brand-new real
positions. This is a BIGGER step up in risk than the breakeven-autopilot
(app/autopilot.py) -- that one can only ever tighten an existing position's
stop, never open a new one -- so capital_usdt/leverage must be explicitly
set at least once (see is_configured()) before /autotrade on can enable
anything; there is no numeric default a fresh clone could silently inherit.

Same plain-JSON-file, read-whole/write-whole pattern as
app/autopilot_settings.py/app/instant_trade_settings.py -- appropriate at
this scale (four fields, changed rarely, checked once per ~20s
_autotrade_worker pass)."""
from __future__ import annotations

import json
from pathlib import Path

DEFAULT_MAX_POSITIONS = 3


class AutoTradeSettings:
    def __init__(self, path: Path):
        self.path = path
        if self.path.exists():
            raw = json.loads(self.path.read_text())
        else:
            raw = {}
        self.enabled: bool = bool(raw.get("enabled", False))
        self.capital_usdt: float = float(raw.get("capital_usdt", 0) or 0)
        self.leverage: int = int(raw.get("leverage", 0) or 0)
        self.max_positions: int = int(raw.get("max_positions", DEFAULT_MAX_POSITIONS) or DEFAULT_MAX_POSITIONS)

    def _save(self) -> None:
        self.path.write_text(json.dumps(
            {
                "enabled": self.enabled,
                "capital_usdt": self.capital_usdt,
                "leverage": self.leverage,
                "max_positions": self.max_positions,
            },
            indent=2,
        ))

    def is_enabled(self) -> bool:
        return self.enabled

    def is_configured(self) -> bool:
        """False until capital_usdt/leverage have been set at least once --
        _handle_autotrade_command refuses a bare `/autotrade on` (no
        numbers) while this is False, and _autotrade_worker refuses to act
        even if `enabled` were somehow True without a valid size, since
        0 USDT / 0x is not a safe fallback for "how much to risk"."""
        return self.capital_usdt > 0 and self.leverage > 0

    def set_enabled(self, enabled: bool) -> None:
        """Flips the switch without touching a previously-saved
        capital_usdt/leverage/max_positions -- so `/autotrade off` then a
        later bare `/autotrade on` reuses the same settings instead of
        forgetting them."""
        self.enabled = enabled
        self._save()

    def set_config(self, capital_usdt: float, leverage: int, max_positions: int | None = None,
                    enabled: bool | None = None) -> None:
        """Sets/updates the size (and optionally the concurrency cap and
        the enabled flag) in the same write (used by
        `/autotrade on <capital> <leverage> [<max_positions>]`, which both
        configures and enables in one command). `max_positions=None` keeps
        whatever was there before (or the default, on first-ever config)."""
        self.capital_usdt = capital_usdt
        self.leverage = leverage
        if max_positions is not None:
            self.max_positions = max_positions
        if enabled is not None:
            self.enabled = enabled
        self._save()

