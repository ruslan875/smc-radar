"""
Live-editable "max concurrent deals" cap for the standalone DCA live bots
(long_strategy15_latuserge_live.py, kc_roc_cci_wt_grid_live.py) -- 2026-09-06,
user request: the cap was previously only a --max-concurrent-deals CLI flag
read once at process startup, so changing it meant stopping and restarting
the live bot. Same plain-JSON-file, read-whole/write-whole pattern as
app/scan_settings.py's ScanSettings and app/autopilot_settings.py's
AutopilotSettings -- appropriate at this scale (one integer, changed rarely,
re-read once per poll cycle by the live bot itself via read_live(), and
written either by /maxdeals in main.py or directly by the live bot's own
--max-concurrent-deals flag, which seeds the file as its default on first
run if the file doesn't exist yet).

0 keeps its existing meaning from the old CLI-only behavior: "no cap" (the
live bots treat `max_concurrent_deals=0` the same as `None` -- see each
script's own `(value or None)` at the call site, unchanged by this file).
"""
from __future__ import annotations

import json
from pathlib import Path


class MaxConcurrentDealsSettings:
    def __init__(self, path: Path, default: int = 2):
        self.path = path
        self.default = default
        if self.path.exists():
            try:
                raw = json.loads(self.path.read_text())
            except (json.JSONDecodeError, OSError):
                raw = {}
        else:
            raw = {}
        value = raw.get("max_concurrent_deals", default)
        try:
            value = int(value)
        except (TypeError, ValueError):
            value = default
        self.value: int = max(0, value)

    def get(self) -> int:
        return self.value

    def set(self, value: int) -> None:
        value = max(0, int(value))
        self.value = value
        self.path.write_text(json.dumps({"max_concurrent_deals": value}, indent=2))

    @classmethod
    def read_live(cls, path: Path, default: int) -> int:
        """Cheap one-shot read for a poll loop that doesn't want to keep an
        instance around -- re-reads the file fresh every call (no caching)
        so a change written by /maxdeals takes effect on the very next poll
        cycle of the live bot, with zero restart needed."""
        return cls(path, default).get()


# ---------------------------------------------------------------------------
# 2026-09-06 (later same day), user request: a local Windows admin GUI (see
# windows_app/) needs to show and edit each live bot's money-management CLI
# flags -- --capital-per-deal, --leverage, --symbol, --stop-loss-pct,
# --telegram-alerts -- from a form, instead of the owner memorizing/typing
# them on a terminal command line every time a bot is (re)started.
#
# STATED PLAINLY, not glossed over: unlike MaxConcurrentDealsSettings above,
# these are NOT hot-reloaded by an already-running live bot. Each script
# reads them ONCE into `args` at the top of main() and uses them for that
# process's entire lifetime -- `symbols` decides which `instruments` dict
# gets built at startup, `leverage` is baked into LiveBackend's constructor,
# `stop_loss_pct` gates every stop-loss calculation for the whole run.
# Rewiring both scripts to re-read these mid-run would be a materially
# bigger, riskier change than what was actually asked for (a validated
# backtest assumes a FIXED sizing/leverage/stop-loss regime for the whole
# run -- silently changing that mid-run would invalidate the very edge the
# backtest measured). So this store's real contract is: "what CLI args
# should windows_app's process supervisor launch this bot with NEXT TIME it
# is (re)started" -- editing it while the bot is already running changes
# nothing until that bot is stopped and started again. The GUI must say
# this next to the form, not just bury it in a code comment.
#
# STRATEGY_DEFAULTS is transcribed 1:1 from each live script's own
# `argparse.add_argument(..., default=...)` line as read on 2026-09-06 --
# never a guessed/assumed number. If a script's own default is ever
# changed, this dict must be updated to match or the GUI will show a stale
# value for an owner who has never touched this file yet.
STRATEGY_DEFAULTS: dict = {
    "latuserge": {
        "capital_per_deal": 100.0,   # long_strategy15_latuserge_live.py --capital-per-deal default
        "leverage": 5,               # --leverage default
        "stop_loss_pct": 75.0,       # --stop-loss-pct default
        "symbols": ["ETHUSDT", "SOLUSDT", "ARBUSDT", "INJUSDT", "TIAUSDT"],  # DEFAULT_WATCHLIST
        "telegram_alerts": True,     # --telegram-alerts default
    },
    "kc_roc": {
        "capital_per_deal": 20.0,    # kc_roc_cci_wt_grid_live.py --capital-per-deal default
        "leverage": 5,               # --leverage default
        "stop_loss_pct": 4.0,        # --stop-loss-pct default
        "symbols": ["ETHUSDT", "SOLUSDT", "ARBUSDT", "INJUSDT", "TIAUSDT", "HYPEUSDT"],  # DEFAULT_WATCHLIST
        "telegram_alerts": True,     # --telegram-alerts default
    },
    # 2026-10-17: combo_xrp_live.py. ТОЛЬКО для отображения в общих экранах панели —
    # реальные параметры бот читает из combo_xrp_live_settings.json (там же правятся).
    # stop_loss_pct = 0: стоп считает сама стратегия (Combo OTM) на каждую сделку.
    "combo_xrp": {
        "capital_per_deal": 25.0,    # 50% от депозита 50 $
        "leverage": 3,
        "stop_loss_pct": 0.0,
        "symbols": ["XRPUSDT"],
        "telegram_alerts": True,
    },
}

_EDITABLE_FIELDS = ("capital_per_deal", "leverage", "stop_loss_pct", "symbols", "telegram_alerts")


class LiveBotParamsStore:
    """Own JSON file per strategy (LATUSERGE_LIVE_PARAMS_FILE /
    KC_GRID_LIVE_PARAMS_FILE in app/config.py -- see that file's comment for
    why this is deliberately NOT the same file MaxConcurrentDealsSettings
    uses). Read-whole/write-whole, same pattern as every other settings
    store in this app -- appropriate at this scale (five fields, changed
    rarely, only consulted when a bot is about to be (re)started)."""

    def __init__(self, path: Path, strategy_id: str):
        if strategy_id not in STRATEGY_DEFAULTS:
            raise ValueError(f"unknown strategy_id {strategy_id!r}, expected one of {list(STRATEGY_DEFAULTS)}")
        self.path = path
        self.strategy_id = strategy_id
        defaults = STRATEGY_DEFAULTS[strategy_id]
        if self.path.exists():
            try:
                raw = json.loads(self.path.read_text())
            except (json.JSONDecodeError, OSError):
                raw = {}
        else:
            raw = {}
        saved = raw.get("live_params") or {}
        self.values = {
            "capital_per_deal": float(saved.get("capital_per_deal", defaults["capital_per_deal"])),
            "leverage": int(saved.get("leverage", defaults["leverage"])),
            "stop_loss_pct": float(saved.get("stop_loss_pct", defaults["stop_loss_pct"])),
            "symbols": [str(s).upper() for s in (saved.get("symbols") or defaults["symbols"])],
            "telegram_alerts": bool(saved.get("telegram_alerts", defaults["telegram_alerts"])),
        }

    def get(self) -> dict:
        return dict(self.values)

    def get_defaults(self) -> dict:
        return dict(STRATEGY_DEFAULTS[self.strategy_id])

    def is_default(self) -> bool:
        """True if every field still matches the script's own CLI default
        -- used by the GUI to show a "default" badge vs. "customised"."""
        return self.values == STRATEGY_DEFAULTS[self.strategy_id]

    def set(self, **updates) -> dict:
        for key, value in updates.items():
            if key not in _EDITABLE_FIELDS:
                raise ValueError(f"unknown live-param field {key!r}, expected one of {_EDITABLE_FIELDS}")
            if value is None:
                continue
            if key == "capital_per_deal":
                value = float(value)
                if value <= 0:
                    raise ValueError("capital_per_deal must be > 0")
            elif key == "leverage":
                value = int(value)
                if value < 1:
                    raise ValueError("leverage must be >= 1")
            elif key == "stop_loss_pct":
                value = float(value)
                if value <= 0:
                    raise ValueError("stop_loss_pct must be > 0")
            elif key == "symbols":
                value = [str(s).strip().upper() for s in value if str(s).strip()]
                if not value:
                    raise ValueError("symbols list must not be empty")
            elif key == "telegram_alerts":
                value = bool(value)
            self.values[key] = value

        # Preserve whatever else lives in this file (nothing does today,
        # but read-then-write rather than blind-overwrite is the right
        # habit regardless -- see the 2026-09-06 project-doc incident this
        # same session about exactly the opposite mistake).
        raw = {}
        if self.path.exists():
            try:
                raw = json.loads(self.path.read_text())
            except (json.JSONDecodeError, OSError):
                raw = {}
        raw["live_params"] = self.values
        self.path.write_text(json.dumps(raw, indent=2, ensure_ascii=False))
        return dict(self.values)
