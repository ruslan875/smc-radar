"""
Validates Telegram Mini App `initData` server-side, 2026-08-25 round 14.

Written for the new local trade-server (see app/trade_server.py) --
the ONE piece of new infrastructure that lets the Торговля tab place a
real order the instant you tap the button, with no "review + tap Send in
Telegram" step in between. Because that step is going away, this module
is the entire replacement safety boundary: if this validation is wrong in
either direction, either real orders stop working (safe failure) or,
much worse, someone other than the owner could trigger one (unsafe
failure) -- so this was implemented against Telegram's own documented
algorithm (fetched directly from core.telegram.org/bots/webapps, plus
cross-checked against a well-known reference Python implementation), not
from memory, exactly the same discipline already used elsewhere in this
project for platform-specific behavior that's easy to misremember.

Algorithm (Telegram's own, "Validating data received via the Mini App"):
  1. secret_key = HMAC_SHA256(key=b"WebAppData", msg=bot_token).digest()
  2. data_check_string = every initData field except "hash", sorted by key,
     joined as "key=value" pairs with "\\n".
  3. computed_hash = HMAC_SHA256(key=secret_key, msg=data_check_string).hexdigest()
  4. compare computed_hash to the "hash" field using a constant-time
     comparison (hmac.compare_digest) -- never plain "==", which is not
     length/timing safe for secrets.

On top of Telegram's own algorithm, two more checks specific to THIS bot
(Telegram's docs only really cover the signature; the freshness/identity
checks are this project's own, not optional here given what's at stake):
  - auth_date freshness: initData is a live signed snapshot of the Mini
    App session, not a one-time-use token -- Telegram doesn't invalidate
    it after use, so without a freshness check a stolen/logged initData
    string would remain replayable forever. max_age_seconds is
    deliberately tight (minutes, not Telegram's own suggested "reject if
    very old" hours-scale guidance) because this gates real money, not a
    login session.
  - user identity: the decoded "user" field's `id` must equal the
    bot's own owner chat_id (TELEGRAM_CHAT_ID) -- this bot has exactly one
    owner and the trade-server must never execute an order for anyone
    else, even a legitimate Telegram user who somehow obtained the tunnel
    URL. This check is what actually matters if the tunnel URL leaks --
    CORS and the URL being hard-to-guess are not the security boundary,
    the signature + identity check is.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import time
from urllib.parse import parse_qsl


class InitDataError(ValueError):
    """Raised with a specific, loggable reason -- never shown to whoever
    sent the (rejected) request, since an attacker probing this endpoint
    shouldn't get free feedback on which check they failed."""


def validate_init_data(init_data: str, bot_token: str, owner_chat_id: str,
                        max_age_seconds: int = 300) -> dict:
    """Returns the parsed initData fields (dict, with "user" already
    JSON-decoded into a nested dict) on success. Raises InitDataError on
    ANY failure -- missing/malformed data, bad signature, stale auth_date,
    or a user id that doesn't match owner_chat_id. Callers must treat
    every InitDataError identically from the requester's point of view
    (a generic "unauthorized"), logging the specific reason server-side
    only."""
    if not init_data or not isinstance(init_data, str):
        raise InitDataError("empty or non-string initData")
    if not bot_token:
        raise InitDataError("no bot token configured -- cannot validate anything")

    pairs = parse_qsl(init_data, keep_blank_values=True, strict_parsing=False)
    data = dict(pairs)
    received_hash = data.pop("hash", None)
    if not received_hash:
        raise InitDataError("initData has no hash field")

    data_check_string = "\n".join(f"{k}={v}" for k, v in sorted(data.items()))
    secret_key = hmac.new(b"WebAppData", bot_token.encode("utf-8"), hashlib.sha256).digest()
    computed_hash = hmac.new(secret_key, data_check_string.encode("utf-8"), hashlib.sha256).hexdigest()

    if not hmac.compare_digest(computed_hash, received_hash):
        raise InitDataError("signature mismatch -- initData was not signed by this bot's token, or was altered")

    try:
        auth_date = int(data.get("auth_date", "0"))
    except ValueError:
        raise InitDataError("auth_date is not a valid integer")
    age = time.time() - auth_date
    if age > max_age_seconds or age < -30:  # small negative slack for clock skew
        raise InitDataError(f"auth_date too stale or in the future (age={age:.0f}s, max={max_age_seconds}s)")

    user_raw = data.get("user")
    if not user_raw:
        raise InitDataError("initData has no user field")
    try:
        user = json.loads(user_raw)
    except (json.JSONDecodeError, TypeError):
        raise InitDataError("user field is not valid JSON")

    user_id = user.get("id")
    if user_id is None or str(user_id) != str(owner_chat_id):
        raise InitDataError(f"initData user id ({user_id}) does not match this bot's owner chat_id")

    data["user"] = user
    return data
