"""
Safety guardrails for live order placement, 2026-08-23 round 8.

Split out of main.py's _handle_trade_command on purpose: these are pure
functions (no I/O, no exchange calls, no Telegram) so every rule can be
unit-tested in isolation without mocking a network call. main.py's
_handle_trade_command runs each check in order and stops at the first
failure -- an order is only ever sent to the exchange once every check here
has passed.

These three guards were explicitly requested by the user (via
AskUserQuestion, 2026-08-23) as non-negotiable from the very start, not
configurable off:
  1. a stop-loss is always required (check_stop_loss)
  2. leverage is always capped (check_leverage, Settings.max_trade_leverage)
  3. a new trade is blocked if it would push the weekly risk budget over
     100% (check_risk_budget, reusing the exact number already computed
     for the Здоровье tab)

The fourth guard (check_signal_gate) is OPT-IN per order -- the user chose
"both" execution models (manual by default, signal-gated as a toggle), so
this one only runs when the /trade command carries the "gate" marker (see
main.py's _handle_trade_command and the Mini App's Торговля tab toggle)."""
from __future__ import annotations


def check_leverage(leverage: int, max_leverage: int) -> tuple[bool, str | None]:
    if leverage < 1 or leverage > max_leverage:
        return False, f"Плечо {leverage}x вне допустимого диапазона (1-{max_leverage}x)."
    return True, None


def check_stop_loss(current_price: float, stop_loss: float, side: str) -> tuple[bool, str | None]:
    """`side` is "buy" or "sell" (the /trade command's own vocabulary, see
    main.py). A stop-loss must sit on the losing side of the current
    price -- a long's stop below entry, a short's stop above -- otherwise
    it's not actually a stop-loss (could be a typo'd take-profit, or a
    price on the wrong side of the market that would trigger the position
    closing instantly, or worse, never trigger at all)."""
    if stop_loss <= 0:
        return False, "Stop-loss обязателен и должен быть больше нуля."
    if side == "buy" and stop_loss >= current_price:
        return False, f"Stop-loss ({stop_loss:g}) должен быть НИЖЕ текущей цены ({current_price:g}) для покупки/лонга."
    if side == "sell" and stop_loss <= current_price:
        return False, f"Stop-loss ({stop_loss:g}) должен быть ВЫШЕ текущей цены ({current_price:g}) для продажи/шорта."
    return True, None


def check_take_profit(current_price: float, take_profit: float | None, side: str) -> tuple[bool, str | None]:
    """Optional -- None means "no take-profit", always allowed (matches
    execute_trade's own take_profit: float | None contract). When given,
    must sit on the WINNING side of the current price -- a long's TP above
    price, a short's TP below -- mirroring check_stop_loss's same-shaped
    check for the losing side.

    Added 2026-09-04 after a real live failure: main.py's _autotrade_worker
    passes a signal's `nearest_target` straight through as take_profit, and
    that target can end up on the WRONG side of the CURRENT price by the
    time the order actually reaches the exchange -- the signal can be up to
    settings.signal_gate_max_age_minutes (default 60min) old, and price can
    simply run through (or past) the target in that window. Bybit's own
    order-create validation rejects that correctly but as a raw
    retCode=10001 ("TakeProfit ... should be higher/lower than base_price")
    -- catching it here first gives a clear Russian-language reason AND,
    crucially, means the caller never has to spend an exchange round-trip
    on what was never going to be a valid order anyway. This also silently
    protects /trade and the instant trade-server -- both already pass
    current_price/take_profit/side through execute_trade -- though it's
    rare for a human typing a TP against a price they're looking at right
    now to hit this."""
    if take_profit is None:
        return True, None
    if take_profit <= 0:
        return False, "Take-profit должен быть больше нуля."
    if side == "buy" and take_profit <= current_price:
        return False, (
            f"Take-profit ({take_profit:g}) должен быть ВЫШЕ текущей цены ({current_price:g}) для покупки/лонга "
            f"-- похоже, цена уже прошла мимо цели."
        )
    if side == "sell" and take_profit >= current_price:
        return False, (
            f"Take-profit ({take_profit:g}) должен быть НИЖЕ текущей цены ({current_price:g}) для продажи/шорта "
            f"-- похоже, цена уже прошла мимо цели."
        )
    return True, None


def check_risk_budget(new_risk_usdt: float, already_used_usdt: float, budget_usdt: float) -> tuple[bool, str | None]:
    """`already_used_usdt` is the SAME risk_used_usdt_week number the
    Здоровье tab already shows for this exchange (closed-this-week losses
    + current open-position unrealized losses, see publish_health.py round
    7) -- this guard is deliberately not a separate/parallel risk
    calculation, so the Mini App and the trade guard can never silently
    disagree about how much budget is left. budget_usdt <= 0 means no
    budget is configured (WEEKLY_RISK_BUDGET_USDT unset/zero) -- treated as
    "don't block", matching how publish_health.py already treats that case
    for risk_used_pct."""
    if budget_usdt <= 0:
        return True, None
    total = already_used_usdt + new_risk_usdt
    if total > budget_usdt:
        pct = round(total / budget_usdt * 100, 1)
        return False, (
            f"Недельный риск-бюджет будет превышен: уже использовано {already_used_usdt:.2f} USDT, "
            f"эта сделка добавит ещё {new_risk_usdt:.2f} USDT (итого {pct}% от {budget_usdt:.2f} USDT)."
        )
    return True, None


def check_signal_gate(active_signal: dict | None, side: str, symbol: str) -> tuple[bool, str | None]:
    """`active_signal` is whatever app.state.StateStore.latest_active_signal()
    returned -- None means nothing fired recently enough. `side` is "buy"
    or "sell"; mapped to the bot's own "long"/"short" vocabulary
    (app.smc.Signal.direction) for comparison, since a gated buy should
    only be allowed to ride an actual long signal, not just any recent
    signal on the same symbol."""
    if active_signal is None:
        return False, f"Нет активного подтверждённого сигнала по {symbol} -- режим «только по сигналу» включён для этой сделки."
    wanted_direction = "long" if side == "buy" else "short"
    if active_signal.get("direction") != wanted_direction:
        return False, (
            f"Активный сигнал по {symbol} направлен в другую сторону "
            f"({active_signal.get('direction')}), а не {wanted_direction}."
        )
    return True, None
