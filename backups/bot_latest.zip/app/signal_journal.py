"""Журнал сигналов /aiidea и /aipick и их исходы (2026-09-24).

Просьба владельца: «отслеживание сигналов /aipick: попал ли сигнал в тейк
или стоп, и общая статистика точности».

Как работает:
  * каждый сигнал с направлением (LONG/SHORT) и уровнями записывается в
    signal_journal.json: монета, таймфрейм, вход, тейк, стоп, время;
  * фоновая проверка (main.py, раз в 5 минут) берёт с Bybit минутные или
    5-минутные свечи с момента сигнала и смотрит, что было задето первым;
  * если в одной свече задеты и тейк, и стоп — считаем СТОП (порядок внутри
    свечи неизвестен, поэтому берём худший вариант, чтобы не завышать точность);
  * если за отведённое время (maxHold свечей сигнала, по умолчанию 48) не
    задето ни то, ни другое — «истёк», результат по цене закрытия.

Только чтение публичных свечей, ни одного ордера. Терминал читает тот же
файл, чтобы рисовать вход/тейк/стоп активных сигналов на графике.
"""
from __future__ import annotations

import json
import threading
import time
import uuid
from pathlib import Path

import requests

from app.config import BASE_DIR

JOURNAL_FILE = BASE_DIR / "signal_journal.json"
BYBIT_KLINE = "https://api.bybit.com/v5/market/kline"
_LOCK = threading.Lock()

# минуты в одной свече таймфрейма сигнала (Bybit-обозначения и человеческие)
_TF_MIN = {"1": 1, "3": 3, "5": 5, "15": 15, "30": 30, "60": 60, "120": 120, "240": 240, "360": 360,
           "720": 720, "D": 1440, "W": 10080, "1m": 1, "5m": 5, "15m": 15, "30m": 30, "1h": 60, "4h": 240,
           "12h": 720, "1d": 1440, "1D": 1440, "1w": 10080, "1W": 10080}
_TF_LABEL = {"1": "1m", "3": "3m", "5": "5m", "15": "15m", "30": "30m", "60": "1h", "120": "2h", "240": "4h",
             "360": "6h", "720": "12h", "D": "1d", "W": "1w"}


def _load(path: Path = JOURNAL_FILE) -> list[dict]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []


def _save(rows: list[dict], path: Path = JOURNAL_FILE) -> None:
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(rows, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(path)


def add_signal(source: str, symbol: str, timeframe: str, side: str, entry: float, tp: float, sl: float,
               max_hold: int | None = None, note: str = "", path: Path = JOURNAL_FILE) -> dict | None:
    """Записывает сигнал. Тот же открытый сигнал (монета+ТФ+направление+
    источник с тем же входом) повторно не пишется — повторный /aiidea по
    той же свече не должен удваивать статистику."""
    side = (side or "").upper()
    if side not in ("LONG", "SHORT") or not entry or not tp or not sl:
        return None
    entry, tp, sl = float(entry), float(tp), float(sl)
    with _LOCK:
        rows = _load(path)
        for r in rows:
            if (r["status"] == "open" and r["symbol"] == symbol and r["tf"] == str(timeframe)
                    and r["side"] == side and r["source"] == source and abs(r["entry"] - entry) <= entry * 1e-6
                    and abs(r["tp"] - tp) <= abs(tp) * 1e-6):
                return None
        rec = {
            "id": uuid.uuid4().hex[:10], "source": source, "symbol": symbol, "tf": str(timeframe),
            "side": side, "entry": entry, "tp": tp, "sl": sl,
            "max_hold": int(max_hold) if max_hold else 48, "note": note,
            "created": int(time.time() * 1000), "status": "open",
            "closed": None, "exit": None, "pnl_pct": None, "r": None,
        }
        rows.append(rec)
        _save(rows, path)
        return rec


def _fetch(symbol: str, interval: str, start_ms: int) -> list[list[float]]:
    """Свечи с start_ms до сейчас, по возрастанию: [open_ms, o, h, l, c]."""
    out: list[list[float]] = []
    cursor = start_ms
    for _ in range(10):
        resp = requests.get(BYBIT_KLINE, params={"category": "linear", "symbol": symbol, "interval": interval,
                                                 "start": cursor, "limit": 1000}, timeout=15)
        resp.raise_for_status()
        rows = (resp.json().get("result") or {}).get("list") or []
        batch = sorted([[int(r[0]), float(r[1]), float(r[2]), float(r[3]), float(r[4])] for r in rows])
        batch = [b for b in batch if b[0] >= cursor]
        if not batch:
            break
        out.extend(batch)
        if len(rows) < 1000:
            break
        cursor = batch[-1][0] + 1
    return out


def _judge(rec: dict, candles: list[list[float]], now_ms: int) -> dict | None:
    """Возвращает изменения для записи, если сигнал закрылся, иначе None."""
    long = rec["side"] == "LONG"
    entry, tp, sl = rec["entry"], rec["tp"], rec["sl"]
    deadline = rec["created"] + rec["max_hold"] * _TF_MIN.get(rec["tf"], 60) * 60_000
    risk = abs(entry - sl) or entry * 1e-9
    last_close = None
    for t, _o, h, l, c in candles:
        if t < rec["created"] - 60_000:
            continue
        if t >= deadline:
            break
        hit_sl = l <= sl if long else h >= sl
        hit_tp = h >= tp if long else l <= tp
        if hit_sl or hit_tp:
            status, px = ("sl", sl) if hit_sl else ("tp", tp)   # оба в одной свече -> стоп (худший случай)
            return _result(rec, status, px, t, risk)
        last_close = c
    if now_ms >= deadline and last_close is not None:
        return _result(rec, "expired", last_close, deadline, risk)
    return None


def _result(rec: dict, status: str, px: float, t: int, risk: float) -> dict:
    sign = 1 if rec["side"] == "LONG" else -1
    pnl = (px / rec["entry"] - 1) * 100 * sign - 0.15   # 2026-09-26: минус комиссия+проскальзывание (0.075% x2)
    return {"status": status, "exit": px, "closed": int(t), "pnl_pct": round(pnl, 3),
            "r": round((px - rec["entry"]) * sign / risk, 2)}


def check_open(path: Path = JOURNAL_FILE) -> list[dict]:
    """Проверяет все открытые сигналы. Возвращает список только что
    закрывшихся (для уведомлений)."""
    with _LOCK:
        rows = _load(path)
    open_rows = [r for r in rows if r["status"] == "open"]
    if not open_rows:
        return []
    now = int(time.time() * 1000)
    updates: dict[str, dict] = {}
    for rec in open_rows:
        tf_min = _TF_MIN.get(rec["tf"], 60)
        interval = "1" if tf_min <= 15 else "5"
        try:
            candles = _fetch(rec["symbol"], interval, rec["created"] - 60_000)
        except (requests.RequestException, ValueError) as exc:
            print(f"[SIGNALS] {rec['symbol']}: свечи не получены: {exc}")
            continue
        ch = _judge(rec, candles, now)
        if ch:
            updates[rec["id"]] = ch
    if not updates:
        return []
    closed = []
    with _LOCK:
        rows = _load(path)                       # перечитываем: за время запросов могли добавиться сигналы
        for r in rows:
            if r["id"] in updates and r["status"] == "open":
                r.update(updates[r["id"]])
                closed.append(dict(r))
        _save(rows, path)
    return closed


def active_for_symbol(symbol: str, path: Path = JOURNAL_FILE) -> list[dict]:
    return [r for r in _load(path) if r["status"] == "open" and r["symbol"] == symbol]


def all_rows(path: Path = JOURNAL_FILE) -> list[dict]:
    return _load(path)


def stats(rows: list[dict] | None = None) -> dict:
    rows = _load() if rows is None else rows
    done = [r for r in rows if r["status"] != "open"]

    def agg(sub):
        n = len(sub)
        tp = sum(1 for r in sub if r["status"] == "tp")
        sl = sum(1 for r in sub if r["status"] == "sl")
        ex = n - tp - sl
        wins = sum(1 for r in sub if (r.get("pnl_pct") or 0) > 0)
        return {"n": n, "tp": tp, "sl": sl, "expired": ex,
                "hit_rate": round(tp / (tp + sl) * 100, 1) if tp + sl else None,
                "win_rate": round(wins / n * 100, 1) if n else None,
                "sum_pct": round(sum(r.get("pnl_pct") or 0 for r in sub), 2),
                "avg_r": round(sum(r.get("r") or 0 for r in sub) / n, 2) if n else None}

    by_source = {s: agg([r for r in done if r["source"] == s]) for s in sorted({r["source"] for r in done})}
    by_symbol = {s: agg([r for r in done if r["symbol"] == s]) for s in sorted({r["symbol"] for r in done})}
    return {"total": agg(done), "open": sum(1 for r in rows if r["status"] == "open"),
            "by_source": by_source, "by_symbol": by_symbol}


def tf_label(tf: str) -> str:
    return _TF_LABEL.get(str(tf), str(tf))
