"""
Scan-universe setting for the live bot, 2026-08-22: either the fixed
`watchlist.json`/`WATCHLIST` list, or a dynamically-fetched top-N-by-24h-
volume list from Bybit -- mirrors the Mini App's "Что сканировать"
selector (see the miniapp project doc), but for the real stateful bot
instead of the client-side scorer.

Owner-only, changed via a Telegram inline-keyboard menu (send /scan, or
"настройки", from your own chat -- see main.py's OWNER_SCAN_COMMANDS /
_handle_scan_callback). Persisted to scan_settings.json so a restart
doesn't silently fall back to the 5-symbol default.
"""
from __future__ import annotations

import json
from pathlib import Path

# mode -> how many top-by-volume symbols to scan (0 = use the fixed
# watchlist instead of fetching anything).
SCAN_MODES = {"watchlist": 0, "top25": 25, "top50": 50, "top100": 100}
DEFAULT_MODE = "watchlist"

SCAN_MODE_LABELS = {
    "watchlist": "Мой список (5 монет)",
    "top25": "Топ-25 по объёму",
    "top50": "Топ-50 по объёму",
    "top100": "Топ-100 по объёму",
}


class ScanSettings:
    def __init__(self, path: Path):
        self.path = path
        if self.path.exists():
            raw = json.loads(self.path.read_text())
        else:
            raw = {}
        mode = raw.get("mode", DEFAULT_MODE)
        self.mode: str = mode if mode in SCAN_MODES else DEFAULT_MODE

    def set_mode(self, mode: str) -> None:
        if mode not in SCAN_MODES:
            raise ValueError(f"unknown scan mode: {mode!r} (expected one of {sorted(SCAN_MODES)})")
        self.mode = mode
        self.path.write_text(json.dumps({"mode": mode}, indent=2))

    @property
    def top_n(self) -> int:
        return SCAN_MODES[self.mode]
