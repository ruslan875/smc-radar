"""
Trading-permission API keys, 2026-08-23 round 8 (live order placement).

Deliberately a SEPARATE store from app.exchange_keys_store.ExchangeKeysStore,
even though the file format is identical -- that store's own docstring says
"Keys saved here are always meant to be READ-ONLY exchange keys" (used only
for fetching closed-trade history / open positions for the Здоровье tab).
Reusing it for a trading key would either break that invariant silently or
require the caller to somehow know which flavor of key is currently saved
for a given exchange. Keeping them in two separate files means:

- /setkey (see main.py's _handle_setkey_command) only ever touches
  exchange_keys.json -- a mistake there can, at worst, misreport trade
  history, never place an order.
- /tradekey (see main.py's _handle_tradekey_command) only ever touches
  trade_keys.json -- and _handle_trade_command refuses to place an order
  at all if nothing is saved here for the requested exchange, even if a
  read-only key already exists in the other store for the same exchange.

Same plain-JSON-file pattern as ExchangeKeysStore/AccessStore (read whole
file, mutate in memory, write whole file back) -- appropriate at this scale
(a handful of keys, written rarely).

Security note: this file holds a plaintext API secret WITH ORDER-PLACEMENT
RIGHTS -- meaningfully more sensitive than the read-only keys in
exchange_keys.json, since anyone with read access to this file (or to the
machine it lives on) could place real trades. It lives next to the other
per-bot JSON state files (same directory, no different exposure model than
.env already has for TELEGRAM_BOT_TOKEN etc.), but this is worth having in
mind if this repo/machine is ever shared or backed up somewhere less
trusted. Never enable withdrawal/transfer permissions on a key saved here --
only Trade/Orders is needed, and .env.example's per-exchange setup
instructions should say so explicitly once this ships.

2026-09-06, user request: PER-STRATEGY keys. Until now every live bot
(currently long_strategy15_latuserge_live.py and kc_roc_cci_wt_grid_live.py)
shared the exact same key under `keys[exch_key]` -- there was no way to,
say, run latuserge against one Bybit account/sub-account and
kc_roc_cci_wt_grid against a different one (separate risk buckets, separate
accounting, or just wanting each strategy's real orders isolated to its own
API key). Added a SECOND, additive top-level section, `strategy_keys`:
`{strategy: {exch_key: {...same shape as `keys`...}}}`. This is deliberately
NOT a breaking change to the existing `keys` section or its file shape --
an old trade_keys.json with only `keys` still loads fine (`strategy_keys`
defaults to `{}`), and every existing caller of `get_all()`/`set_key()`/
`remove_key()` keeps working unchanged, still reading/writing the shared
default key. `get_for_strategy(strategy, exch_key)` is the new lookup a
live script should use instead of `get_all().get(exch_key)`: it returns the
strategy's OWN key if one has been set, otherwise falls back to the shared
default -- so a user who never bothers with per-strategy keys sees no
change at all, and setting one for just one strategy doesn't require also
setting (or duplicating) one for every other."""
from __future__ import annotations

import json
from pathlib import Path


class TradeKeysStore:
    def __init__(self, path: Path):
        self.path = path
        if self.path.exists():
            raw = json.loads(self.path.read_text())
        else:
            raw = {}
        # exch_key (str, e.g. "bybit") -> {"api_key":..., "api_secret":..., "passphrase": ... or None}
        self._keys: dict = raw.get("keys", {})
        # strategy (str, e.g. "latuserge") -> {exch_key: {...same shape as _keys...}}
        self._strategy_keys: dict = raw.get("strategy_keys", {})

    def _save(self) -> None:
        self.path.write_text(json.dumps(
            {"keys": self._keys, "strategy_keys": self._strategy_keys},
            indent=2, ensure_ascii=False,
        ))

    # ---------------------------------------------------------- shared/default key --

    def set_key(self, exch_key: str, api_key: str, api_secret: str, passphrase: str | None = None) -> None:
        self._keys[exch_key] = {
            "api_key": api_key.strip(),
            "api_secret": api_secret.strip(),
            "passphrase": passphrase.strip() if passphrase else None,
        }
        self._save()

    def remove_key(self, exch_key: str) -> bool:
        if exch_key in self._keys:
            del self._keys[exch_key]
            self._save()
            return True
        return False

    def get_all(self) -> dict:
        return dict(self._keys)

    # ---------------------------------------------------------- per-strategy key --

    def set_key_for_strategy(self, strategy: str, exch_key: str, api_key: str, api_secret: str,
                              passphrase: str | None = None) -> None:
        bucket = self._strategy_keys.setdefault(strategy, {})
        bucket[exch_key] = {
            "api_key": api_key.strip(),
            "api_secret": api_secret.strip(),
            "passphrase": passphrase.strip() if passphrase else None,
        }
        self._save()

    def remove_key_for_strategy(self, strategy: str, exch_key: str) -> bool:
        bucket = self._strategy_keys.get(strategy)
        if bucket and exch_key in bucket:
            del bucket[exch_key]
            if not bucket:
                del self._strategy_keys[strategy]
            self._save()
            return True
        return False

    def has_dedicated_key(self, strategy: str, exch_key: str) -> bool:
        """True if THIS strategy has its own key for exch_key (as opposed
        to falling back to the shared default) -- used only for status
        displays (e.g. /tradekey with no arguments), never for the actual
        credential lookup a live script makes (see get_for_strategy)."""
        return exch_key in self._strategy_keys.get(strategy, {})

    def get_for_strategy(self, strategy: str, exch_key: str) -> dict | None:
        """The credential a live script for `strategy` should actually
        trade with: that strategy's own dedicated key if one has been set
        via set_key_for_strategy(), otherwise the shared default from
        set_key() (same key every strategy used before per-strategy keys
        existed) -- returns None if neither is set."""
        dedicated = self._strategy_keys.get(strategy, {}).get(exch_key)
        if dedicated is not None:
            return dedicated
        return self._keys.get(exch_key)

    def get_all_for_strategy(self, strategy: str) -> dict:
        return dict(self._strategy_keys.get(strategy, {}))
