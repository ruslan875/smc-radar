"""Включение/выключение отдельных типов уведомлений Telegram (2026-09-24).

Один файл notify_prefs.json на всю папку бота: его читают main.py, живые
боты (kc_roc, latuserge), paper_live.py и veles_tao_bb.py. Меняется из
Telegram — /notify или кнопкой «🔔 Уведомления» в меню — и действует без
перезапуска: файл перечитывается при изменении (по mtime).

Всё, чего нет в файле, по умолчанию ВКЛЮЧЕНО — выключенным может быть только
то, что владелец выключил сам.
"""
from __future__ import annotations

import json
import re
import threading
from pathlib import Path

from app.config import BASE_DIR

PREFS_FILE = BASE_DIR / "notify_prefs.json"

# ключ -> подпись в меню
CATEGORIES: list[tuple[str, str]] = [
    ("trade_open", "🟢 Открытие сделок ботами"),
    ("trade_close", "🏁 Закрытие сделок ботами"),
    ("grid", "➕ Докупки сетки"),
    ("warnings", "⚠️ Предупреждения ботов"),
    ("paper", "🧪 Paper-тесты"),
    ("signal_results", "🎯 Итоги сигналов /aiidea /aipick"),
    ("psycho", "🧠 Серии убытков (психо)"),
    ("autopilot", "🛡 Автопилот"),
    ("daily", "📰 Дневной отчёт"),
]
_KEYS = {k for k, _ in CATEGORIES}

_lock = threading.Lock()
_cache: dict = {"mtime": None, "data": {}}


def _read() -> dict:
    try:
        mtime = PREFS_FILE.stat().st_mtime
    except OSError:
        return {}
    with _lock:
        if _cache["mtime"] != mtime:
            try:
                _cache["data"] = json.loads(PREFS_FILE.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                _cache["data"] = {}
            _cache["mtime"] = mtime
        return dict(_cache["data"])


def is_enabled(key: str) -> bool:
    return bool(_read().get(key, True))


def all_prefs() -> dict[str, bool]:
    d = _read()
    return {k: bool(d.get(k, True)) for k, _ in CATEGORIES}


def set_pref(key: str, value: bool) -> None:
    if key not in _KEYS:
        raise KeyError(key)
    d = _read()
    d[key] = bool(value)
    tmp = PREFS_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(PREFS_FILE)


def toggle(key: str) -> bool:
    new = not is_enabled(key)
    set_pref(key, new)
    return new


_TAGS = re.compile(r"<[^>]+>")


def classify_bot_message(msg: str) -> str:
    """Категория сообщения живого бота по его тексту (у notify() в живых
    ботах один вход на все события, поэтому различаем по первой строке)."""
    first = _TAGS.sub("", (msg or "").strip().split("\n", 1)[0]).lower()
    if "открыта" in first and "закрыта" not in first:
        return "trade_open"
    if "закрыта" in first or "закрыт" in first:
        return "trade_close"
    if first.startswith("➕") or "нога сетки" in first or "докупк" in first:
        return "grid"
    return "warnings"


def allowed_bot_message(msg: str) -> bool:
    return is_enabled(classify_bot_message(msg))
