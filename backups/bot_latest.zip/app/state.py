"""
On-disk state: two things need to survive between polls.

1. `sent` -- dedupe for fired signals, so the same reaction isn't posted
   twice.
2. `pending_zones` -- armed-but-not-yet-reacted zones from Stage 1
   (structure break). This is what makes the "wait for reaction" rule
   actually work across poll cycles instead of only within one run.
"""
from __future__ import annotations

import json
from pathlib import Path

from app.smc import PendingZone


class StateStore:
    def __init__(self, path: Path):
        self.path = path
        if self.path.exists():
            raw = json.loads(self.path.read_text())
        else:
            raw = {}
        self._sent: dict = raw.get("sent", {})
        self._zones: dict = raw.get("pending_zones", {})  # key -> PendingZone.to_dict()

    def _save(self) -> None:
        """2026-08-29: made atomic after a real live crash --
        `_access_poll_worker` (main.py) constructs a fresh `StateStore`
        every ~3s and this method is called from the main scan loop
        constantly (every `add_zone`/`drop_zone`/`mark_sent`). The old
        version did `self.path.write_text(...)`, which truncates the file
        to zero bytes BEFORE writing the new content -- a reader on
        another thread that happens to open the file in that exact window
        gets an empty file and `json.loads("")` raises
        `JSONDecodeError: Expecting value: line 1 column 1 (char 0)`,
        exactly the traceback seen live once the scan universe grew to
        top-100 (state.json got big enough that the write itself takes
        long enough for the race to actually get hit in practice -- with
        a small watchlist this was always theoretically possible but
        never actually observed). Fix: write the full payload to a
        sibling `.tmp` file first, then `Path.replace()` it over the real
        path -- `replace()` maps to `os.replace()`, which is atomic on
        both POSIX and Windows (this bot only runs on Windows in
        practice), so any concurrent reader always sees either the
        complete old file or the complete new one, never a truncated one."""
        payload = {"sent": self._sent, "pending_zones": self._zones}
        tmp_path = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp_path.write_text(json.dumps(payload, indent=2, default=str))
        tmp_path.replace(self.path)

    # ---- fired-signal dedupe ----
    def already_sent(self, key: str) -> bool:
        return key in self._sent

    def mark_sent(self, key: str, meta: dict) -> None:
        self._sent[key] = meta
        if len(self._sent) > 2000:
            oldest = sorted(self._sent.items(), key=lambda kv: kv[1].get("sent_at", ""))[: len(self._sent) - 2000]
            for k, _ in oldest:
                self._sent.pop(k, None)
        self._save()

    # ---- pending zones (Stage 1 -> Stage 2 bridge) ----
    def zones_for(self, symbol: str, timeframe: str) -> list[PendingZone]:
        return [
            PendingZone.from_dict(d) for d in self._zones.values()
            if d["symbol"] == symbol and d["timeframe"] == timeframe
        ]

    def has_zone_for_break(self, zone_key: str) -> bool:
        return zone_key in self._zones

    def add_zone(self, zone: PendingZone) -> None:
        self._zones[zone.key] = zone.to_dict()
        self._save()

    def drop_zone(self, zone: PendingZone) -> None:
        self._zones.pop(zone.key, None)
        self._save()

    # ---- 2026-08-23, round 8: signal-gate lookup for /trade ----
    def latest_active_signal(self, symbol: str, max_age_minutes: float) -> dict | None:
        """For the /trade command's optional "только по сигналу" gate (see
        app/trading_guard.py + main.py's _handle_trade_command) -- the most
        recently fired signal (main.py's mark_sent() calls, keyed
        "symbol:timeframe:direction:iso_time:kind") for this symbol, if
        it's still within max_age_minutes of "now". Returns the exact meta
        dict mark_sent() stored (sent_at/entry/direction/stop_loss/
        nearest_target as of round 8 -- see main.py's process_symbol), or
        None if nothing recent enough exists. Matches on the symbol prefix
        of the key since the full key (timeframe/direction/trigger time)
        isn't known in advance by the caller."""
        import datetime as _dt

        now = _dt.datetime.now(_dt.timezone.utc)
        best_meta: dict | None = None
        best_sent_at: _dt.datetime | None = None
        for key, meta in self._sent.items():
            if not key.startswith(f"{symbol}:"):
                continue
            sent_at_str = meta.get("sent_at")
            if not sent_at_str:
                continue
            try:
                sent_at = _dt.datetime.fromisoformat(sent_at_str)
            except ValueError:
                continue
            if (now - sent_at).total_seconds() / 60 > max_age_minutes:
                continue
            if best_sent_at is None or sent_at > best_sent_at:
                best_meta, best_sent_at = meta, sent_at
        return best_meta

    # ---- 2026-08-23, round 9 ("Вера" /ideas command) ----
    def all_pending_zones(self) -> list[PendingZone]:
        """Every currently-armed zone across every symbol/timeframe --
        unlike zones_for(), which is scoped to one symbol at a time for
        process_symbol()'s own use. Used by main.py's /ideas command to
        show the owner what the bot is currently watching, independent of
        anything actually having fired yet."""
        return [PendingZone.from_dict(d) for d in self._zones.values()]

    def recent_signals(self, max_age_minutes: float) -> list[dict]:
        """Every fired signal (mark_sent() entry) still within
        max_age_minutes, newest first -- same underlying `sent` dict
        latest_active_signal() reads, but across ALL symbols instead of
        one, for main.py's /ideas command. The symbol isn't stored in the
        meta dict itself (only in the key), so it's split back out here
        (keys are "symbol:timeframe:direction:trigger_time:kind").

        2026-09-03: also returns the raw `key` itself (previously dropped)
        -- main.py's new _autotrade_worker needs a stable, unique
        identifier per fired signal to dedupe against (see
        app/autotrade_state.py), and `symbol+sent_at` alone isn't
        guaranteed unique the way the original key already is. Purely
        additive: existing callers (/ideas, the AI context bundle) just
        get one more field in each dict, nothing they read changes."""
        import datetime as _dt

        now = _dt.datetime.now(_dt.timezone.utc)
        out: list[dict] = []
        for key, meta in self._sent.items():
            sent_at_str = meta.get("sent_at")
            if not sent_at_str:
                continue
            try:
                sent_at = _dt.datetime.fromisoformat(sent_at_str)
            except ValueError:
                continue
            if (now - sent_at).total_seconds() / 60 > max_age_minutes:
                continue
            symbol = key.split(":", 1)[0]
            out.append({"symbol": symbol, "sent_at": sent_at, "key": key, **meta})
        out.sort(key=lambda d: d["sent_at"], reverse=True)
        return out
