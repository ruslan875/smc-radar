"""
Publishes the current active invite-code hash to a small JSON file in the
user's own GitHub Pages repo (ruslan875/smc-radar), so the static Mini App
can check a code against the same one-time-invite system the bot itself
uses (see app/access.py). Only ever writes ONE file (`access.json` at the
repo root by default) via GitHub's Contents API -- no other repo access is
used or needed.

Requires a GitHub Personal Access Token with "Contents: Read and write"
permission scoped to just this repo (fine-grained token recommended --
see the setup instructions given to the user). Set GITHUB_TOKEN and
GITHUB_REPO in .env; if GITHUB_TOKEN is empty, every function here is a
no-op (the bot's own Telegram gate still works fine without it -- this
only affects whether the website can also check the code).
"""
from __future__ import annotations

import base64
import json

import requests

GITHUB_API = "https://api.github.com"


class GitHubSyncError(RuntimeError):
    pass



def _req(method, url, **kw):
    """2026-11-02: медленная связь/VPN — 4 попытки, долгий таймаут (соединение 30 с, ответ 120 с)."""
    import time as _t  # noqa: PLC0415
    last = None
    for k in range(4):
        try:
            return requests.request(method, url, timeout=(30, 120), **kw)
        except (requests.exceptions.Timeout, requests.exceptions.ConnectionError) as exc:
            last = exc
            print(f"GitHub не ответил (попытка {k + 1}/4), повторяю…")
            _t.sleep(5 * (k + 1))
    raise last

def push_json_file(token: str, repo: str, path: str, data: dict, message: str) -> None:
    """Create or update `path` in `repo` (owner/name) with `data` as
    pretty-printed JSON, via GitHub's Contents API. Reads the file's
    current sha first (if it exists) since the API requires it for
    updates -- a plain create (no prior file) omits it.

    2026-09-06: live 409 conflict observed ("is at X but expected Y") --
    the GET-sha-then-PUT sequence above is a classic check-then-act race:
    if anything else (a second bot process left running from an
    incomplete restart, a manual edit, a parallel push_binary_file call)
    updates the same file between our GET and our PUT, GitHub rejects the
    stale sha with a 409 and the whole publish is lost for that cycle
    (health.json only republishes every HEALTH_PUBLISH_INTERVAL_SECONDS,
    so losing one attempt to a race is a real, visible gap, not just a
    log line). Fix: on a 409 specifically, re-fetch the sha (now
    reflecting whoever won the race) and retry the PUT exactly once
    before giving up -- same self-healing shape as every other transient
    failure in this codebase (log-and-continue, never crash), just with
    one retry since this failure mode is a plain stale-version conflict,
    not a real network/API problem that a repeat within milliseconds
    would be unlikely to fix."""
    url = f"{GITHUB_API}/repos/{repo}/contents/{path}"
    headers = {"Authorization": f"Bearer {token}", "Accept": "application/vnd.github+json"}

    content_str = json.dumps(data, indent=2)
    content_b64 = base64.b64encode(content_str.encode("utf-8")).decode("ascii")

    for attempt in (1, 2):
        get_resp = _req("get", url, headers=headers)
        sha = get_resp.json().get("sha") if get_resp.status_code == 200 else None

        payload = {"message": message, "content": content_b64}
        if sha:
            payload["sha"] = sha

        put_resp = _req("put", url, headers=headers, json=payload)
        if put_resp.status_code in (200, 201):
            return
        if put_resp.status_code == 409 and attempt == 1:
            continue
        raise GitHubSyncError(f"GitHub push of {path} failed ({put_resp.status_code}): {put_resp.text[:300]}")


def push_binary_file(token: str, repo: str, path: str, data: bytes, message: str) -> None:
    """2026-08-25, round 16 follow-up: same Contents-API mechanism as
    push_json_file() above (GitHub's API always wants base64 content
    regardless of what it represents -- push_json_file already base64-
    encodes its JSON text), just for raw bytes instead of JSON -- used to
    publish the per-open-position chart PNGs (see app/chart.py's
    render_position_chart() and main.py's _maybe_publish_position_charts())
    to the same GitHub Pages repo health.json/access.json already live
    in. Deliberately a separate function rather than a `data: dict | bytes`
    branch on push_json_file() -- keeps each function's contract simple
    and unambiguous about what it accepts.

    2026-09-06: same stale-sha-race retry as push_json_file() above (see
    its docstring for the full story) -- on a 409, re-fetch sha and retry
    the PUT once before giving up."""
    url = f"{GITHUB_API}/repos/{repo}/contents/{path}"
    headers = {"Authorization": f"Bearer {token}", "Accept": "application/vnd.github+json"}

    content_b64 = base64.b64encode(data).decode("ascii")

    for attempt in (1, 2):
        get_resp = _req("get", url, headers=headers)
        sha = get_resp.json().get("sha") if get_resp.status_code == 200 else None

        payload = {"message": message, "content": content_b64}
        if sha:
            payload["sha"] = sha

        put_resp = _req("put", url, headers=headers, json=payload)
        if put_resp.status_code in (200, 201):
            return
        if put_resp.status_code == 409 and attempt == 1:
            continue
        raise GitHubSyncError(f"GitHub push of {path} failed ({put_resp.status_code}): {put_resp.text[:300]}")
