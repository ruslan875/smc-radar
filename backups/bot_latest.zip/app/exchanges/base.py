"""Shared plumbing for app/exchanges/* -- one module per exchange, each
exposing a uniform

    fetch_closed_trades(api_key, api_secret, passphrase=None,
                         lookback_days=30, limit=100) -> pandas.DataFrame

so publish_health.py can treat every exchange the same way regardless of
how different their raw APIs are. Added 2026-08-23 as part of a
multi-exchange redesign -- Bybit was the only exchange before this; the
user trades on several and asked for an architecture where adding more
later doesn't require touching already-written code.

Every fetch_closed_trades() implementation should return a DataFrame with
exactly these columns (NORMALIZED_COLUMNS below), even if a given exchange
can't populate every one -- use None/NaT for what's genuinely unavailable
rather than guessing (see kucoin.py's `qty` for an example of an honest
gap, documented in its own comment):

  symbol           -- exchange's own symbol/contract string, unmodified
  side              -- "long" / "short" (best-effort normalized via
                       normalize_side() below; raw values that don't map
                       cleanly are passed through lowercased rather than
                       dropped)
  qty               -- position size at close, in contracts/base units
  avg_entry_price   -- average entry price
  avg_exit_price    -- average exit/close price
  cum_entry_value   -- notional value at entry (quote currency, USDT)
  cum_exit_value    -- notional value at exit (quote currency, USDT)
  closed_pnl        -- realized PnL for this closed trade, in quote currency
  created_time      -- pandas UTC Timestamp, when the position was opened
  updated_time      -- pandas UTC Timestamp, when the position was closed

publish_health.py adds an `exchange` column itself after calling each
fetch_closed_trades() (tagged with the REGISTRY key), so individual
modules don't need to know their own registry name.

All of this assumes USDT-margined perpetual/futures instruments -- the
numbers stay comparable across exchanges only if the user's accounts on
each are primarily USDT-margined. Cross-margined or coin-margined
positions will still come through (nothing filters them out) but their
notional/PnL figures are in a different unit than the USDT ones, which
would silently skew the aggregated risk-budget percentage. Worth
revisiting if that turns out to matter in practice.

2026-08-23, round 7: a SECOND, OPTIONAL contract --

    fetch_open_positions(api_key, api_secret, passphrase=None) -> pandas.DataFrame

-- for currently-OPEN (not yet closed) positions, returning
OPEN_POSITION_COLUMNS below. The user pointed out that the Здоровье tab
only ever showed CLOSED trades, so a position they'd just opened live (to
test the Bybit integration) appeared nowhere -- reasonably expected
something closer to real-time, both as a visible "here's what's open
right now" list and factored into the weekly risk-budget figure (an
open position already losing money is real risk you're carrying, not
nothing, even before it closes). This is deliberately OPTIONAL --
publish_health.py checks `hasattr(module, "fetch_open_positions")` before
calling it, so a module that doesn't implement it yet just doesn't
contribute an open-positions block, same as if the exchange had none
open. Only Bybit implements it so far (the only exchange actually
confirmed working against a live account) -- the other five modules will
get this the same way their closed-trades fetch did: one at a time,
verified against a real account before being trusted.

2026-08-23, round 8: a THIRD, OPTIONAL contract -- the highest-stakes one
in this package, since unlike the two above it actually MOVES MONEY:

    set_leverage(api_key, api_secret, symbol, leverage,
                  passphrase=None) -> None
    place_order(api_key, api_secret, symbol, side, qty, stop_loss,
                 take_profit=None, passphrase=None) -> dict
                 (side is "buy"/"sell"; returns at least {"order_id": ...})

Same optional-per-exchange rollout discipline as fetch_open_positions:
publish_health.py/main.py check `hasattr(module, "place_order")` before
offering that exchange for the /trade command, so the five exchanges that
don't have this yet simply aren't offered rather than erroring. Only Bybit
implements it so far. The credentials passed here are DELIBERATELY read
from a separate store than the read-only ones used by fetch_closed_trades/
fetch_open_positions -- see app/trade_keys_store.py's module docstring --
because a trading-permission key is meaningfully more sensitive than a
read-only one and the two should never be silently interchangeable.

Every safety guard (mandatory stop-loss, leverage cap, weekly risk-budget
check, optional signal-gate) lives OUTSIDE these functions, in
app/trading_guard.py + main.py's _handle_trade_command -- an
app/exchanges/*.py order-placement implementation should do the minimum:
translate the already-validated call into that exchange's own API and
surface whatever the exchange's own response says, nothing more. In
particular: no automatic retry on a failed order-create call. Retrying a
network-ambiguous request (timeout, connection drop) risks placing the
SAME order twice if the first attempt actually succeeded on the exchange's
side but the confirmation never made it back -- the caller surfaces the
raw failure to the owner instead, who can check the exchange's own UI
before deciding whether to resend.

2026-08-23, round 9 ("Вера" trading-assistant features): a FOURTH,
OPTIONAL contract -- also money-relevant, though narrower in scope than
place_order() since it can only ever TIGHTEN an existing position's risk,
never open a new one or change its size:

    amend_stop_loss(api_key, api_secret, symbol, stop_loss,
                     passphrase=None) -> None

Used exclusively by app/autopilot.py's breakeven-move loop. Same
hasattr(module, "amend_stop_loss") optional-rollout discipline as the
other three contracts above -- only Bybit implements it so far. Unlike
place_order(), this is meant to be called with NO per-call human
confirmation once the autopilot is switched on (see app/autopilot.py's
module docstring for the full safety reasoning) -- the trigger condition
that decides WHEN to call it lives entirely in app/autopilot.py, kept as
pure functions for the same "independently unit-testable, no hidden
exchange-call side effects" reason as app/trading_guard.py."""
from __future__ import annotations

import pandas as pd

from app.data import DataError

NORMALIZED_COLUMNS = [
    "symbol", "side", "qty", "avg_entry_price", "avg_exit_price",
    "cum_entry_value", "cum_exit_value", "closed_pnl", "created_time", "updated_time",
]

# fetch_open_positions()'s normalized schema (round 7, see module docstring).
# unrealized_pnl is the field the weekly risk-budget overlay actually reads
# (compute_health_from_exchange_trades in publish_health.py) -- everything
# else here is display-only for the Mini App's open-positions card.
#
# 2026-08-23, round 9 ("Вера" autopilot, see app/autopilot.py): stop_loss/
# take_profit added -- the position's CURRENTLY-SET stop/take on the
# exchange (None if the position has none set), read straight from the
# same position-list response fetch_open_positions() already calls, not
# tracked separately by this bot. The breakeven-autopilot loop uses
# stop_loss here (plus avg_entry_price/mark_price) to compute how many R
# a position has moved, which works for ANY open position -- including one
# opened by hand on the exchange's own app, not just ones opened via this
# bot's /trade -- since it never depends on this bot having recorded the
# original stop anywhere itself.
OPEN_POSITION_COLUMNS = [
    "symbol", "side", "qty", "avg_entry_price", "mark_price",
    "unrealized_pnl", "position_value", "leverage", "created_time",
    "stop_loss", "take_profit",
]

_LONG_ALIASES = {"buy", "long", "net"}
_SHORT_ALIASES = {"sell", "short"}


class ExchangeAuthError(DataError):
    """Auth-specific failure (bad key/secret/passphrase, missing read
    permission, or -- for the exchanges that require one -- a missing
    passphrase we caught ourselves before even calling the API) --
    kept separate from a generic DataError so callers (build_health) can
    log something more specific than a generic network-failure message."""


def empty_normalized_df() -> pd.DataFrame:
    return pd.DataFrame(columns=NORMALIZED_COLUMNS)


def empty_open_positions_df() -> pd.DataFrame:
    return pd.DataFrame(columns=OPEN_POSITION_COLUMNS)


def to_float(row: dict, key: str) -> float | None:
    val = row.get(key)
    if val in (None, ""):
        return None
    try:
        return float(val)
    except (TypeError, ValueError):
        return None


def ms_to_utc(value):
    if value in (None, "", 0, "0"):
        return pd.NaT
    try:
        return pd.to_datetime(int(float(value)), unit="ms", utc=True)
    except (TypeError, ValueError):
        return pd.NaT


def sec_to_utc(value):
    if value in (None, "", 0, "0"):
        return pd.NaT
    try:
        return pd.to_datetime(float(value), unit="s", utc=True)
    except (TypeError, ValueError):
        return pd.NaT


def normalize_side(raw) -> str | None:
    if raw is None:
        return None
    s = str(raw).strip().lower()
    if s in _LONG_ALIASES:
        return "long"
    if s in _SHORT_ALIASES:
        return "short"
    return s or None
