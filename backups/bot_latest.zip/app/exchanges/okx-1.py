"""OKX v5 client. (2026-10-17: below the read-only part there is now a
clearly marked TRADING block -- place_order/close_position/amend_stop_loss/
set_leverage -- used by combo_xrp_live.py and /trade. Read-only calls unchanged.)
Originally READ-ONLY. Fetches closed-position history via
GET /api/v5/account/positions-history. See app/exchanges/base.py for the
shared multi-exchange contract this and its siblings implement.

NOT verified against a live OKX account (no sandbox network access + no
real credentials when this was written) -- run `python
app/exchanges/okx.py --smoke-test` after adding OKX_API_KEY/
OKX_API_SECRET/OKX_API_PASSPHRASE to .env, and check the printed trades
against OKX's own Positions History page before trusting the automated
pipeline.

Setup (READ-ONLY key): okx.com -> profile icon -> API -> Create V5 API
Key. Permission: enable "Read" only; leave "Trade" and "Withdraw" OFF.
OKX requires you to CHOOSE a passphrase at key-creation time (it isn't
issued to you) -- write it down, it cannot be recovered if lost, you'd
have to make a new key."""
from __future__ import annotations

import base64
import hashlib
import hmac
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

if __name__ == "__main__":
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

import pandas as pd
import requests

from app.data import DataError
from app.exchanges.base import (ExchangeAuthError, empty_normalized_df, empty_open_positions_df, ms_to_utc,
                                normalize_side, to_float)

DISPLAY_NAME = "OKX"
REQUIRES_PASSPHRASE = True
BASE_URL = "https://www.okx.com"


def _plain_symbol(inst_id) -> str | None:
    """OP-USDT-SWAP -> OPUSDT: как у Bybit и во всём остальном проекте."""
    if not inst_id:
        return inst_id
    return str(inst_id).upper().replace("-SWAP", "").replace("-", "")


def _iso_timestamp() -> str:
    now = datetime.now(timezone.utc)
    return now.strftime("%Y-%m-%dT%H:%M:%S.") + f"{now.microsecond // 1000:03d}Z"


def _sign(api_secret: str, timestamp: str, method: str, request_path: str, body: str = "") -> str:
    prehash = f"{timestamp}{method}{request_path}{body}"
    digest = hmac.new(api_secret.encode("utf-8"), prehash.encode("utf-8"), hashlib.sha256).digest()
    return base64.b64encode(digest).decode()


def _signed_get(path: str, api_key: str, api_secret: str, passphrase: str, params: dict,
                 retries: int = 3, timeout: float = 15.0) -> dict:
    query_string = "&".join(f"{k}={v}" for k, v in params.items() if v is not None)
    request_path = f"{path}?{query_string}" if query_string else path
    last_exc: Exception | None = None
    for attempt in range(retries):
        timestamp = _iso_timestamp()
        signature = _sign(api_secret, timestamp, "GET", request_path)
        headers = {
            "OK-ACCESS-KEY": api_key,
            "OK-ACCESS-SIGN": signature,
            "OK-ACCESS-TIMESTAMP": timestamp,
            "OK-ACCESS-PASSPHRASE": passphrase,
            "Content-Type": "application/json",
        }
        try:
            resp = requests.get(f"{BASE_URL}{request_path}", headers=headers, timeout=timeout)
            resp.raise_for_status()
            payload = resp.json()
            if payload.get("code") == "0":
                return payload
            raise DataError(f"OKX API error for {path}: {payload.get('msg')} (code={payload.get('code')})")
        except (requests.RequestException, DataError) as exc:
            last_exc = exc
            if attempt < retries - 1:
                time.sleep(1.5 * (attempt + 1))
    raise DataError(f"Failed to fetch {path} after {retries} attempts: {last_exc}")


def fetch_closed_trades(api_key: str, api_secret: str, passphrase: str | None = None,
                         inst_type: str = "SWAP", lookback_days: int = 30, limit: int = 100) -> pd.DataFrame:
    if not passphrase:
        raise ExchangeAuthError("OKX requires OKX_API_PASSPHRASE in addition to key/secret.")

    end_time = int(time.time() * 1000)
    start_time = end_time - lookback_days * 24 * 60 * 60 * 1000

    all_rows: list[dict] = []
    cursor_after: str | None = None
    while True:
        params: dict = {"instType": inst_type, "begin": start_time, "end": end_time, "limit": limit}
        if cursor_after:
            params["after"] = cursor_after
        payload = _signed_get("/api/v5/account/positions-history", api_key, api_secret, passphrase, params)
        rows = payload.get("data", [])
        all_rows.extend(rows)
        if len(rows) < limit:
            break
        cursor_after = rows[-1].get("uTime")
        if not cursor_after:
            break
        time.sleep(0.15)

    if not all_rows:
        return empty_normalized_df()

    records = []
    for row in all_rows:
        entry_px = to_float(row, "openAvgPx")
        exit_px = to_float(row, "closeAvgPx")
        open_sz = to_float(row, "openMaxPos")
        close_sz = to_float(row, "closeTotalPos")
        records.append({
            "symbol": _plain_symbol(row.get("instId")),
            "side": normalize_side(row.get("posSide")),
            "qty": close_sz,
            "avg_entry_price": entry_px,
            "avg_exit_price": exit_px,
            "cum_entry_value": (entry_px * open_sz) if entry_px is not None and open_sz is not None else None,
            "cum_exit_value": (exit_px * close_sz) if exit_px is not None and close_sz is not None else None,
            "closed_pnl": to_float(row, "realizedPnl"),
            "created_time": ms_to_utc(row.get("cTime")),
            "updated_time": ms_to_utc(row.get("uTime")),
        })

    df = pd.DataFrame(records)
    df = df.dropna(subset=["closed_pnl", "created_time"])
    df = df.sort_values("created_time").reset_index(drop=True)
    return df


# 2026-09-24: открытые позиции OKX — тот же опциональный контракт
# fetch_open_positions(), что у bybit.py (OPEN_POSITION_COLUMNS в base.py).
# Как только функция есть, publish_health.py, main.py и панель подхватывают
# OKX сами (все они проверяют hasattr(module, "fetch_open_positions")).
# GET /api/v5/account/positions — только чтение. Стоп и тейк берём из
# closeOrderAlgo (TP/SL, привязанные к позиции); если их нет — None.
# qty у OKX в контрактах, поэтому размер в USDT берём из notionalUsd.
def fetch_open_positions(api_key: str, api_secret: str, passphrase: str | None = None,
                          inst_type: str = "SWAP") -> pd.DataFrame:
    if not passphrase:
        raise ExchangeAuthError("OKX requires OKX_API_PASSPHRASE in addition to key/secret.")
    payload = _signed_get("/api/v5/account/positions", api_key, api_secret, passphrase, {"instType": inst_type})
    records = []
    attached = None  # 2026-10-26: SL/TP из attachAlgoOrds (ордер входа) — отдельные алгоордера, грузим разом
    for row in payload.get("data") or []:
        pos = to_float(row, "pos")
        if not pos:
            continue
        side = row.get("posSide")
        if side in (None, "", "net"):          # режим net: знак pos = направление
            side = "long" if pos > 0 else "short"
        algos = row.get("closeOrderAlgo") or []
        sl = next((to_float(a, "slTriggerPx") for a in algos if a.get("slTriggerPx")), None)
        tp = next((to_float(a, "tpTriggerPx") for a in algos if a.get("tpTriggerPx")), None)
        if sl is None:
            if attached is None:
                attached = {}
                for ot in ("oco", "conditional"):
                    try:
                        pl = _signed_get_once("/api/v5/trade/orders-algo-pending", api_key, api_secret, passphrase,
                                              {"instType": inst_type, "ordType": ot})
                    except Exception:  # noqa: BLE001 -- не роняем список позиций
                        continue
                    for a in pl.get("data") or []:
                        if a.get("slTriggerPx") and a.get("instId") not in attached:
                            attached[a.get("instId")] = a
            a = attached.get(row.get("instId"))
            if a:
                sl = to_float(a, "slTriggerPx")
                if tp is None and a.get("tpTriggerPx"):
                    tp = to_float(a, "tpTriggerPx")
        records.append({
            "symbol": _plain_symbol(row.get("instId")),
            "side": normalize_side(side),
            "qty": abs(pos),
            "avg_entry_price": to_float(row, "avgPx"),
            "mark_price": to_float(row, "markPx"),
            "unrealized_pnl": to_float(row, "upl"),
            "position_value": to_float(row, "notionalUsd"),
            "leverage": to_float(row, "lever"),
            "created_time": ms_to_utc(row.get("cTime")),
            "stop_loss": sl,
            "take_profit": tp,
        })
    if not records:
        return empty_open_positions_df()
    return pd.DataFrame(records)


# 2026-09-24: баланс счёта для Mini App (Портфель / Центр риска) — тот же
# опциональный контракт fetch_balance() -> dict, что у bybit.py. Все суммы в USD.
# Ключ read-only достаточно (эндпоинт только читает).
def fetch_balance(api_key: str, api_secret: str, passphrase: str | None = None) -> dict:
    if not passphrase:
        raise ExchangeAuthError("OKX requires a passphrase")
    payload = _signed_get("/api/v5/account/balance", api_key, api_secret, passphrase, {})
    rows = payload.get("data") or []
    if not rows:
        raise DataError("OKX account/balance returned no data")
    r = rows[0]

    def _f(v):
        try:
            return None if v in (None, "") else round(float(v), 2)
        except (TypeError, ValueError):
            return None

    details = r.get("details") or []
    # Доступно — по USDT (основная маржа фьючерсов), иначе сумма availEq в USD по всем валютам.
    usdt = next((d for d in details if d.get("ccy") == "USDT"), None)
    available = _f((usdt or {}).get("availEq") or (usdt or {}).get("availBal"))
    if available is None and details:
        vals = [_f(d.get("availEq")) for d in details]
        vals = [v for v in vals if v is not None]
        available = round(sum(vals), 2) if vals else None
    upl = _f(r.get("upl"))
    if upl is None and details:
        u = [_f(d.get("upl")) for d in details]
        u = [v for v in u if v is not None]
        upl = round(sum(u), 2) if u else None
    # mgnRatio у OKX = скорректированный капитал / поддерживающая маржа;
    # ликвидация при mgnRatio <= 1. Переводим в «% до ликвидации», как у Bybit
    # (accountMMRate): 100% = ликвидация.
    mgn = _f(r.get("mgnRatio"))
    return {
        "equity": _f(r.get("totalEq")),
        "wallet_balance": _f(r.get("totalEq")),
        "available": available,
        "unrealized_pnl": upl,
        "initial_margin": _f(r.get("imr")),
        "maintenance_margin": _f(r.get("mmr")),
        "margin_ratio_pct": round(100 / mgn, 2) if mgn and mgn > 0 else None,
    }



# ======================================================================
# 2026-10-17: ТОРГОВЫЕ функции OKX (ДВИГАЮТ ДЕНЬГИ).
#
# Вызываются ТОЛЬКО живым ботом combo_xrp_live.py после того, как владелец
# запустил его в «Арсенале» с подтверждением LIVE (и mode="live" в
# combo_xrp_live_settings.json), а также общим /trade (app/trade_executor.py),
# который теперь видит OKX, потому что у модуля есть place_order.
# Ключ — ТОРГОВЫЙ из trade_keys.json (/tradekey okx … или /tradekey comboxrp
# okx …), права Trade, БЕЗ Withdraw. Ключи сюда передаются аргументами и
# нигде не печатаются: в текстах ошибок только path/code/msg ответа OKX.
#
# POST без авто-повтора (как в bybit._signed_post): повтор после таймаута
# мог бы открыть вторую позицию. Публичные GET — с повтором.
# NOT verified against a live OKX account (sandbox без сети).
# ======================================================================
import json as _json

OKX_CL_ORD_PREFIX = "cxrp"


def to_inst_id(symbol: str) -> str:
    """XRPUSDT / XRP-USDT / XRP-USDT-SWAP -> XRP-USDT-SWAP."""
    s = str(symbol).upper().strip()
    if s.endswith("-SWAP"):
        return s
    if "-" in s:
        return f"{s}-SWAP"
    for quote in ("USDT", "USDC", "USD"):
        if s.endswith(quote) and len(s) > len(quote):
            return f"{s[:-len(quote)]}-{quote}-SWAP"
    raise ValueError(f"не понимаю символ {symbol!r}")


def _auth_headers(api_key: str, api_secret: str, passphrase: str, method: str, request_path: str,
                  body: str = "") -> dict:
    ts = _iso_timestamp()
    return {
        "OK-ACCESS-KEY": api_key,
        "OK-ACCESS-SIGN": _sign(api_secret, ts, method, request_path, body),
        "OK-ACCESS-TIMESTAMP": ts,
        "OK-ACCESS-PASSPHRASE": passphrase,
        "Content-Type": "application/json",
    }


def _check_payload(path: str, payload: dict) -> dict:
    code = str(payload.get("code"))
    if code == "0":
        return payload
    # Подробность по каждой строке (sCode/sMsg) — без каких-либо ключей.
    details = "; ".join(f"{d.get('sCode')}:{d.get('sMsg')}" for d in (payload.get("data") or [])
                        if isinstance(d, dict) and d.get("sCode") not in (None, "", "0"))
    msg = f"OKX {path}: code={code} msg={payload.get('msg')}" + (f" [{details}]" if details else "")
    if code in ("50111", "50113", "50114", "50103", "50104", "50105", "50120", "50119"):
        raise ExchangeAuthError(msg + " -- проверь торговый ключ OKX (права Trade, passphrase, IP).")
    raise DataError(msg)


def _signed_post(path: str, api_key: str, api_secret: str, passphrase: str | None, body: dict,
                 timeout: float = 15.0) -> dict:
    if not passphrase:
        raise ExchangeAuthError("OKX requires a passphrase")
    raw = _json.dumps(body, separators=(",", ":"))
    headers = _auth_headers(api_key, api_secret, passphrase, "POST", path, raw)
    try:
        resp = requests.post(f"{BASE_URL}{path}", data=raw, headers=headers, timeout=timeout)
        payload = resp.json()
    except (requests.RequestException, ValueError) as exc:
        raise DataError(f"OKX POST {path} failed: {type(exc).__name__}: {exc}")
    return _check_payload(path, payload)


def _signed_get_once(path: str, api_key: str, api_secret: str, passphrase: str | None, params: dict) -> dict:
    if not passphrase:
        raise ExchangeAuthError("OKX requires a passphrase")
    return _signed_get(path, api_key, api_secret, passphrase, params)


def _public_get(path: str, params: dict, retries: int = 3, timeout: float = 15.0) -> dict:
    last: Exception | None = None
    for attempt in range(retries):
        try:
            resp = requests.get(f"{BASE_URL}{path}", params=params, timeout=timeout)
            payload = resp.json()
            return _check_payload(path, payload)
        except (requests.RequestException, ValueError, DataError) as exc:
            last = exc
            if attempt < retries - 1:
                time.sleep(1.5 * (attempt + 1))
    raise DataError(f"OKX GET {path} failed after {retries} attempts: {last}")


_INSTRUMENT_CACHE: dict = {}


def get_instrument(inst_id: str) -> dict:
    """{'ctVal','lotSz','minSz','tickSz','maxMktSz'} для SWAP (публично, кэш)."""
    inst_id = to_inst_id(inst_id)
    if inst_id in _INSTRUMENT_CACHE:
        return _INSTRUMENT_CACHE[inst_id]
    payload = _public_get("/api/v5/public/instruments", {"instType": "SWAP", "instId": inst_id})
    rows = payload.get("data") or []
    if not rows:
        raise DataError(f"OKX: инструмент {inst_id} не найден")
    r = rows[0]
    info = {k: float(r.get(k) or 0) for k in ("ctVal", "lotSz", "minSz", "tickSz")}
    info["maxMktSz"] = float(r.get("maxMktSz") or 0) or None
    info["instId"] = inst_id
    if not info["ctVal"] or not info["lotSz"]:
        raise DataError(f"OKX: у {inst_id} нет ctVal/lotSz")
    _INSTRUMENT_CACHE[inst_id] = info
    return info


def get_last_price(symbol: str) -> float:
    payload = _public_get("/api/v5/market/ticker", {"instId": to_inst_id(symbol)})
    return float((payload.get("data") or [{}])[0]["last"])


def fetch_candles(inst_id: str, bar: str = "1H", total: int = 1000) -> list:
    """Публичные свечи, старые -> новые: [ts_ms, o, h, l, c, vol, confirmed]."""
    inst_id = to_inst_id(inst_id)
    out: dict = {}
    payload = _public_get("/api/v5/market/candles", {"instId": inst_id, "bar": bar, "limit": 300})
    rows = payload.get("data") or []
    after = None
    while True:
        for r in rows:
            out[int(r[0])] = [int(r[0]), float(r[1]), float(r[2]), float(r[3]), float(r[4]), float(r[5]),
                              str(r[8]) == "1" if len(r) > 8 else True]
        if len(out) >= total or not rows:
            break
        oldest = min(int(r[0]) for r in rows)
        if after == oldest:
            break
        after = oldest
        payload = _public_get("/api/v5/market/history-candles",
                              {"instId": inst_id, "bar": bar, "limit": 100, "after": after})
        rows = payload.get("data") or []
        time.sleep(0.12)
    return [out[k] for k in sorted(out)][-total:]


def _decimals(step: float) -> int:
    s = f"{step:.10f}".rstrip("0")
    return len(s.split(".")[1]) if "." in s else 0


def round_down(value: float, step: float) -> float:
    if step <= 0:
        return value
    n = int((value + 1e-9 * step) / step)
    return round(n * step, _decimals(step))


def round_price(px: float, tick: float) -> str:
    if not tick:
        return f"{px}"
    d = _decimals(tick)
    return f"{round(round(px / tick) * tick, d):.{d}f}"


def contracts_for_notional(notional_usdt: float, price: float, inst: dict) -> float:
    """floor(notional / (price*ctVal) / lotSz) * lotSz; 0.0 если меньше minSz."""
    raw = notional_usdt / (price * inst["ctVal"])
    sz = round_down(raw, inst["lotSz"])
    return sz if sz >= inst["minSz"] else 0.0


def get_pos_mode(api_key: str, api_secret: str, passphrase: str | None) -> str:
    """'net_mode' или 'long_short_mode' (GET /api/v5/account/config)."""
    payload = _signed_get_once("/api/v5/account/config", api_key, api_secret, passphrase, {})
    return str((payload.get("data") or [{}])[0].get("posMode") or "net_mode")


def set_leverage(api_key: str, api_secret: str, symbol: str, leverage: int, passphrase: str | None = None,
                 mgn_mode: str = "isolated", pos_mode: str | None = None) -> None:
    """POST /api/v5/account/set-leverage. Для isolated в long_short_mode
    плечо ставится отдельно на long и short."""
    inst_id = to_inst_id(symbol)
    if pos_mode is None:
        pos_mode = get_pos_mode(api_key, api_secret, passphrase)
    sides = ["long", "short"] if (mgn_mode == "isolated" and pos_mode == "long_short_mode") else [None]
    for ps in sides:
        body = {"instId": inst_id, "lever": str(int(leverage)), "mgnMode": mgn_mode}
        if ps:
            body["posSide"] = ps
        _signed_post("/api/v5/account/set-leverage", api_key, api_secret, passphrase, body)


def build_order_body(inst_id: str, side: str, sz: float, stop_loss: float, take_profit: float | None,
                     tick: float, pos_mode: str, td_mode: str = "isolated", cl_ord_id: str | None = None,
                     sl_trigger_px_type: str = "mark", entry_price: float | None = None,
                     reduce_only: bool = False) -> dict:
    """Тело POST /api/v5/trade/order с attachAlgoOrds (SL обязателен)."""
    side = side.lower()
    if side not in ("buy", "sell"):
        raise ValueError("side must be buy/sell")
    if stop_loss is None or float(stop_loss) <= 0:
        raise ValueError("stop_loss обязателен")
    body = {"instId": to_inst_id(inst_id), "tdMode": td_mode, "side": side,
            "ordType": "market" if entry_price is None else "limit", "sz": f"{sz:g}"}
    if entry_price is not None:
        body["px"] = round_price(float(entry_price), tick)
    if pos_mode == "long_short_mode":
        body["posSide"] = "long" if side == "buy" else "short"
    if cl_ord_id:
        body["clOrdId"] = cl_ord_id
    if reduce_only and pos_mode != "long_short_mode":
        body["reduceOnly"] = True
    algo = {"slTriggerPx": round_price(float(stop_loss), tick), "slOrdPx": "-1",
            "slTriggerPxType": sl_trigger_px_type}
    if take_profit:
        algo.update({"tpTriggerPx": round_price(float(take_profit), tick), "tpOrdPx": "-1",
                     "tpTriggerPxType": sl_trigger_px_type})
    body["attachAlgoOrds"] = [algo]
    return body


def new_cl_ord_id(prefix: str = OKX_CL_ORD_PREFIX) -> str:
    return f"{prefix}{int(time.time() * 1000)}"[:32]


def place_order(api_key: str, api_secret: str, symbol: str, side: str, qty: float, stop_loss: float,
                take_profit: float | None = None, passphrase: str | None = None,
                entry_price: float | None = None, *, contracts: float | None = None,
                td_mode: str = "isolated", pos_mode: str | None = None, cl_ord_id: str | None = None,
                sl_trigger_px_type: str = "mark") -> dict:
    """Ордер с привязанным на бирже SL (и TP). Совместим с контрактом
    base.place_order: qty — в монетах (переводится в контракты через ctVal);
    бот передаёт сразу contracts=. Возвращает {'order_id','cl_ord_id','sz',...}.
    Ненулевой code -> DataError/ExchangeAuthError (без ключей в тексте)."""
    inst = get_instrument(symbol)
    if contracts is None:
        contracts = round_down(float(qty) / inst["ctVal"], inst["lotSz"])
    if contracts < inst["minSz"] or contracts <= 0:
        raise DataError(f"OKX: размер {contracts} контрактов меньше минимума {inst['minSz']}")
    if pos_mode is None:
        pos_mode = get_pos_mode(api_key, api_secret, passphrase)
    cl = cl_ord_id or new_cl_ord_id()
    body = build_order_body(inst["instId"], side, contracts, stop_loss, take_profit, inst["tickSz"], pos_mode,
                            td_mode=td_mode, cl_ord_id=cl, sl_trigger_px_type=sl_trigger_px_type,
                            entry_price=entry_price)
    payload = _signed_post("/api/v5/trade/order", api_key, api_secret, passphrase, body)
    row = (payload.get("data") or [{}])[0]
    if str(row.get("sCode", "0")) != "0" or not row.get("ordId"):
        raise DataError(f"OKX order rejected: {row.get('sCode')}:{row.get('sMsg')}")
    return {"order_id": row["ordId"], "cl_ord_id": cl, "sz": contracts, "inst_id": inst["instId"],
            "pos_mode": pos_mode, "request": body}


def fetch_order(api_key: str, api_secret: str, passphrase: str | None, inst_id: str, ord_id: str) -> dict:
    payload = _signed_get_once("/api/v5/trade/order", api_key, api_secret, passphrase,
                               {"instId": to_inst_id(inst_id), "ordId": ord_id})
    return (payload.get("data") or [{}])[0]



_ALGO_ERR: list = []


def find_attached_sl_algo(api_key: str, api_secret: str, passphrase: str | None, inst_id: str) -> dict | None:
    """2026-10-26: SL/TP, привязанные к ордеру входа (attachAlgoOrds), после исполнения живут как
    отдельный алгоордер (oco/conditional) и НЕ видны в closeOrderAlgo позиции. Ищем их тут.
    2026-10-31: Combo XRP ни разу не нашёл свой SL (65 раз «не найден алгоордер»), а панель тот же SL видит —
    панель ищет БЕЗ фильтра instId. Теперь сначала так же (фильтруем сами), затем с instId; ошибки запоминаем.
    Возвращает {'algo_id','sl','tp'} или None. Только чтение."""
    inst_id = to_inst_id(inst_id)
    _ALGO_ERR.clear()

    def _x(v):
        try:
            return float(v) if v not in (None, "") else None
        except (TypeError, ValueError):
            return None
    for params in ({"instType": "SWAP"}, {"instType": "SWAP", "instId": inst_id}):
        for ord_type in ("oco", "conditional"):
            try:
                payload = _signed_get_once("/api/v5/trade/orders-algo-pending", api_key, api_secret, passphrase,
                                           {**params, "ordType": ord_type})
            except Exception as exc:  # noqa: BLE001
                _ALGO_ERR.append(f"{ord_type}: {str(exc)[:120]}")
                continue
            for a in payload.get("data") or []:
                if a.get("instId") == inst_id and a.get("slTriggerPx"):
                    return {"algo_id": a.get("algoId"), "sl": _x(a.get("slTriggerPx")), "tp": _x(a.get("tpTriggerPx"))}
    return None


def fetch_position(api_key: str, api_secret: str, passphrase: str | None, inst_id: str) -> dict | None:
    """Открытая позиция по одному инструменту или None.
    {'side','contracts','avg_px','upl','mgn_mode','pos_side','sl','tp','sl_algo_id','raw_pos'}"""
    inst_id = to_inst_id(inst_id)
    payload = _signed_get_once("/api/v5/account/positions", api_key, api_secret, passphrase,
                               {"instType": "SWAP", "instId": inst_id})
    for row in payload.get("data") or []:
        try:
            pos = float(row.get("pos") or 0)
        except (TypeError, ValueError):
            pos = 0.0
        if not pos:
            continue
        ps = row.get("posSide") or "net"
        side = ps if ps in ("long", "short") else ("long" if pos > 0 else "short")
        algos = row.get("closeOrderAlgo") or []
        sl_algo = next((a for a in algos if a.get("slTriggerPx")), None)
        tp_algo = next((a for a in algos if a.get("tpTriggerPx")), None)
        if not sl_algo:  # 2026-10-26: SL привязан к ордеру входа — ищем среди алгоордеров
            att = find_attached_sl_algo(api_key, api_secret, passphrase, inst_id)
            if att:
                sl_algo = {"slTriggerPx": att["sl"], "algoId": att["algo_id"]}
                if att.get("tp") and not tp_algo:
                    tp_algo = {"tpTriggerPx": att["tp"]}
        return {"side": side, "contracts": abs(pos), "avg_px": float(row.get("avgPx") or 0),
                "upl": float(row.get("upl") or 0), "mgn_mode": row.get("mgnMode"), "pos_side": ps,
                "sl": float(sl_algo["slTriggerPx"]) if sl_algo else None,
                "tp": float(tp_algo["tpTriggerPx"]) if tp_algo else None,
                "sl_algo_id": (sl_algo or {}).get("algoId"), "raw_pos": pos}
    return None


def close_position(api_key: str, api_secret: str, passphrase: str | None, inst_id: str,
                   mgn_mode: str = "isolated", pos_side: str | None = None) -> dict:
    """POST /api/v5/trade/close-position (рыночное закрытие всей позиции,
    привязанные TP/SL OKX снимает сам; autoCxl отменяет висящие ордера)."""
    body = {"instId": to_inst_id(inst_id), "mgnMode": mgn_mode, "autoCxl": True}
    if pos_side in ("long", "short"):
        body["posSide"] = pos_side
    return _signed_post("/api/v5/trade/close-position", api_key, api_secret, passphrase, body)


def amend_stop_loss(api_key: str, api_secret: str, symbol: str, stop_loss: float, passphrase: str | None = None,
                    algo_id: str | None = None, take_profit: float | None = None,
                    sl_trigger_px_type: str = "mark") -> dict:
    """POST /api/v5/trade/amend-algos — двигает SL (и TP) привязанного к
    позиции алгоордера. algo_id берётся из fetch_position()['sl_algo_id']."""
    inst = get_instrument(symbol)
    if not algo_id:
        pos = fetch_position(api_key, api_secret, passphrase, inst["instId"])
        algo_id = (pos or {}).get("sl_algo_id")
    if not algo_id:
        raise DataError("OKX: не найден алгоордер SL для изменения" + (f" ({'; '.join(_ALGO_ERR)})" if _ALGO_ERR else ""))
    body = {"instId": inst["instId"], "algoId": algo_id,
            "newSlTriggerPx": round_price(float(stop_loss), inst["tickSz"]), "newSlOrdPx": "-1",
            "newSlTriggerPxType": sl_trigger_px_type}
    if take_profit:
        body.update({"newTpTriggerPx": round_price(float(take_profit), inst["tickSz"]), "newTpOrdPx": "-1",
                     "newTpTriggerPxType": sl_trigger_px_type})
    return _signed_post("/api/v5/trade/amend-algos", api_key, api_secret, passphrase, body)


def fetch_balance_usdt(api_key: str, api_secret: str, passphrase: str | None = None) -> dict:
    """{'equity','available'} в USDT торгового счёта (GET /api/v5/account/balance?ccy=USDT)."""
    payload = _signed_get_once("/api/v5/account/balance", api_key, api_secret, passphrase, {"ccy": "USDT"})
    rows = payload.get("data") or [{}]
    det = next((d for d in rows[0].get("details") or [] if d.get("ccy") == "USDT"), {})

    def f(v):
        try:
            return None if v in (None, "") else float(v)
        except (TypeError, ValueError):
            return None
    return {"equity": f(det.get("eq")) if det else f(rows[0].get("totalEq")),
            "available": f(det.get("availEq")) or f(det.get("availBal"))}


if __name__ == "__main__":
    from app.exchanges._cli import run_smoke_test
    run_smoke_test(DISPLAY_NAME, fetch_closed_trades, env_prefix="OKX", requires_passphrase=REQUIRES_PASSPHRASE,
                    open_positions_fn=fetch_open_positions)
