"""KuCoin Futures client -- READ-ONLY. Fetches closed-position history via
GET /api/v1/history-positions. See app/exchanges/base.py for the shared
multi-exchange contract.

NOT verified against a live KuCoin account -- run `python
app/exchanges/kucoin.py --smoke-test` after adding KUCOIN_API_KEY/
KUCOIN_API_SECRET/KUCOIN_API_PASSPHRASE to .env, and check the printed
trades against KuCoin's own Futures Closed Positions page before trusting
the automated pipeline.

Auth quirk specific to KuCoin (API key version 2, which is everything
issued today -- v1 was deprecated back in 2021): the passphrase is NOT
sent as plain text. It must itself be HMAC-SHA256-signed with your API
secret and base64-encoded before being sent as the KC-API-PASSPHRASE
header. This module does that for you -- just put the plain passphrase
you chose at key-creation time into .env, unmodified.

This endpoint also doesn't return a plain "quantity" field, only PnL and
a "gross cost" figure -- `qty` below is *approximated* from gross cost /
entry price rather than read directly. That's an honest gap in what
KuCoin's API exposes, not a guess dressed up as a fact -- see the qty
comment in fetch_closed_trades().

Setup (READ-ONLY key): kucoin.com -> API Management -> Create API. Under
permissions choose "General" only (read-only account/order info); leave
Spot/Margin/Futures-trading/Withdrawal/FlexTransfers all OFF."""
from __future__ import annotations

import base64
import hashlib
import hmac
import sys
import time
from pathlib import Path

if __name__ == "__main__":
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

import pandas as pd
import requests

from app.data import DataError
from app.exchanges.base import ExchangeAuthError, empty_normalized_df, ms_to_utc, normalize_side, to_float

DISPLAY_NAME = "KuCoin"
REQUIRES_PASSPHRASE = True
BASE_URL = "https://api-futures.kucoin.com"
_WINDOW_MS = 7 * 24 * 60 * 60 * 1000  # KuCoin caps from/to at 7 days per request


def _signed_headers(api_key: str, api_secret: str, passphrase: str, method: str, endpoint: str, body: str = "") -> dict:
    timestamp = str(int(time.time() * 1000))
    prehash = f"{timestamp}{method}{endpoint}{body}"
    sign = base64.b64encode(hmac.new(api_secret.encode(), prehash.encode(), hashlib.sha256).digest()).decode()
    signed_passphrase = base64.b64encode(
        hmac.new(api_secret.encode(), passphrase.encode(), hashlib.sha256).digest()).decode()
    return {
        "KC-API-KEY": api_key,
        "KC-API-SIGN": sign,
        "KC-API-TIMESTAMP": timestamp,
        "KC-API-PASSPHRASE": signed_passphrase,
        "KC-API-KEY-VERSION": "2",
        "Content-Type": "application/json",
    }


def _signed_get(path: str, api_key: str, api_secret: str, passphrase: str, params: dict,
                 retries: int = 3, timeout: float = 15.0) -> dict:
    query = "&".join(f"{k}={v}" for k, v in params.items() if v is not None)
    endpoint = f"{path}?{query}" if query else path
    last_exc: Exception | None = None
    for attempt in range(retries):
        headers = _signed_headers(api_key, api_secret, passphrase, "GET", endpoint)
        try:
            resp = requests.get(f"{BASE_URL}{endpoint}", headers=headers, timeout=timeout)
            resp.raise_for_status()
            payload = resp.json()
            if str(payload.get("code")) == "200000":
                return payload
            raise DataError(f"KuCoin API error for {path}: {payload.get('msg')} (code={payload.get('code')})")
        except (requests.RequestException, DataError) as exc:
            last_exc = exc
            if attempt < retries - 1:
                time.sleep(1.5 * (attempt + 1))
    raise DataError(f"Failed to fetch {path} after {retries} attempts: {last_exc}")


def fetch_closed_trades(api_key: str, api_secret: str, passphrase: str | None = None,
                         lookback_days: int = 30, limit: int = 100) -> pd.DataFrame:
    if not passphrase:
        raise ExchangeAuthError("KuCoin requires KUCOIN_API_PASSPHRASE in addition to key/secret.")

    end_time = int(time.time() * 1000)
    start_time = end_time - lookback_days * 24 * 60 * 60 * 1000

    all_rows: list[dict] = []
    window_start = start_time
    while window_start < end_time:
        window_end = min(window_start + _WINDOW_MS, end_time)
        page_id = 1
        while True:
            params = {"from": window_start, "to": window_end, "limit": limit, "pageId": page_id}
            payload = _signed_get("/api/v1/history-positions", api_key, api_secret, passphrase, params)
            data = payload.get("data", {}) or {}
            items = data.get("items", [])
            all_rows.extend(items)
            total_page = data.get("totalPage", 1) or 1
            if page_id >= total_page or not items:
                break
            page_id += 1
            time.sleep(0.15)
        window_start = window_end
        time.sleep(0.1)

    if not all_rows:
        return empty_normalized_df()

    records = []
    for row in all_rows:
        entry_px = to_float(row, "openPrice")
        exit_px = to_float(row, "closePrice")
        gross_cost = to_float(row, "realisedGrossCost")
        # No plain quantity field in this response -- approximate it from
        # gross cost / entry price when both are available.
        qty = (gross_cost / entry_px) if (gross_cost is not None and entry_px not in (None, 0)) else None
        records.append({
            "symbol": row.get("symbol"),
            "side": normalize_side(row.get("side")),
            "qty": qty,
            "avg_entry_price": entry_px,
            "avg_exit_price": exit_px,
            "cum_entry_value": gross_cost,
            "cum_exit_value": (exit_px * qty) if exit_px is not None and qty is not None else None,
            "closed_pnl": to_float(row, "pnl"),
            "created_time": ms_to_utc(row.get("openTime")),
            "updated_time": ms_to_utc(row.get("closeTime")),
        })

    df = pd.DataFrame(records)
    df = df.dropna(subset=["closed_pnl", "created_time"])
    df = df.drop_duplicates(subset=["symbol", "created_time", "updated_time", "closed_pnl"])
    df = df.sort_values("created_time").reset_index(drop=True)
    return df


if __name__ == "__main__":
    from app.exchanges._cli import run_smoke_test
    run_smoke_test(DISPLAY_NAME, fetch_closed_trades, env_prefix="KUCOIN", requires_passphrase=REQUIRES_PASSPHRASE)
