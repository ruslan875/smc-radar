"""Multi-exchange read-only trade-history clients. Added 2026-08-23 as a
redesign of what was originally a Bybit-only integration
(app/bybit_account.py) -- the user trades on several exchanges and asked
for an architecture where adding another one later doesn't require
touching already-written code.

Every module here exposes:
  DISPLAY_NAME          -- human-readable name, e.g. "Bybit"
  REQUIRES_PASSPHRASE    -- bool, whether a 3rd credential is needed
  fetch_closed_trades(api_key, api_secret, passphrase=None,
                       lookback_days=30, limit=100) -> pandas.DataFrame
                       (see base.py for the normalized column contract
                       every implementation returns)

REGISTRY maps a short config key (used in .env var name prefixes and in
health.json's per-exchange breakdown) to its module.

To add a new exchange: write app/exchanges/<name>.py implementing the
contract above (base.py + any existing module are good templates), add
one line to REGISTRY below, and add its <PREFIX>_API_KEY/... vars to
app.config.EXCHANGE_ENV_PREFIXES + .env.example -- nothing else in the
pipeline (publish_health.py, main.py) needs to change."""
from __future__ import annotations

from app.exchanges import bitget, bybit, gateio, kucoin, mexc, okx

REGISTRY = {
    "bybit": bybit,
    "okx": okx,
    "bitget": bitget,
    "mexc": mexc,
    "kucoin": kucoin,
    "gateio": gateio,
}
