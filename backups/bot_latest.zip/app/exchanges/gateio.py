"""Gate.io Futures client -- READ-ONLY. Fetches closed-position PnL via
GET /futures/{settle}/position_close (settle=usdt, i.e. USDT-margined
perpetuals). See app/exchanges/base.py for the shared multi-exchange
contract.

NOT verified against a live Gate.io account -- run `python
app/exchanges/gateio.py --smoke-test` after adding GATEIO_API_KEY/
GATEIO_API_SECRET to .env, and check the printed trades against Gate.io's
own Futures Closed Positions page before trusting the automated pipeline.

Setup (READ-ONLY key): gate.io -> API Management -> Create API Key.
Choose "Read Only" (not "Read and Write"); do not attach a withdrawal
address to the key."""
from __future__ import annotations

import hashlib
import hmac
import sys
import time
from pathlib import Path

if __name__ == "__main__":
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

import pandas as pd
import requests

from app.data import DataError
from app.exchanges.base import empty_normalized_df, normalize_side, sec_to_utc, to_float

DISPLAY_NAME = "Gate.io"
REQUIRES_PASSPHRASE = False
BASE_URL = "https://api.gateio.ws/api/v4"


def _sign(api_secret: str, method: str, url_path: str, query_string: str, body: str, timestamp: str) -> str:
    hashed_body = hashlib.sha512(body.encode("utf-8")).hexdigest()
    sign_string = f"{method}\n{url_path}\n{query_string}\n{hashed_body}\n{timestamp}"
    return hmac.new(api_secret.encode("utf-8"), sign_string.encode("utf-8"), hashlib.sha512).hexdigest()


def _signed_get(path: str, api_key: str, api_secret: str, params: dict,
                 retries: int = 3, timeout: float = 15.0) -> list:
    query_string = "&".join(f"{k}={v}" for k, v in params.items() if v is not None)
    url_path = f"/api/v4{path}"
    last_exc: Exception | None = None
    for attempt in range(retries):
        timestamp = str(int(time.time()))
        signature = _sign(api_secret, "GET", url_path, query_string, "", timestamp)
        headers = {"KEY": api_key, "SIGN": signature, "Timestamp": timestamp, "Accept": "application/json"}
        url = f"{BASE_URL}{path}" + (f"?{query_string}" if query_string else "")
        try:
            resp = requests.get(url, headers=headers, timeout=timeout)
            if resp.status_code >= 400:
                try:
                    err = resp.json()
                except ValueError:
                    err = {"message": resp.text}
                raise DataError(f"Gate.io API error for {path}: {err.get('message') or err.get('label')} "
                                 f"(status={resp.status_code})")
            return resp.json()
        except (requests.RequestException, DataError) as exc:
            last_exc = exc
            if attempt < retries - 1:
                time.sleep(1.5 * (attempt + 1))
    raise DataError(f"Failed to fetch {path} after {retries} attempts: {last_exc}")


def fetch_closed_trades(api_key: str, api_secret: str, passphrase: str | None = None,
                         settle: str = "usdt", lookback_days: int = 30, limit: int = 100) -> pd.DataFrame:
    """`passphrase` accepted-and-ignored for call-signature uniformity --
    Gate.io doesn't use one."""
    end_time = int(time.time())
    start_time = end_time - lookback_days * 24 * 60 * 60

    all_rows: list[dict] = []
    offset = 0
    while True:
        params = {"from": start_time, "to": end_time, "limit": limit, "offset": offset}
        rows = _signed_get(f"/futures/{settle}/position_close", api_key, api_secret, params)
        if not isinstance(rows, list):
            raise DataError(f"Gate.io returned an unexpected response shape for position_close: {rows}")
        all_rows.extend(rows)
        if len(rows) < limit:
            break
        offset += limit
        time.sleep(0.15)

    if not all_rows:
        return empty_normalized_df()

    records = []
    for row in all_rows:
        side = normalize_side(row.get("side"))
        long_px = to_float(row, "long_price")
        short_px = to_float(row, "short_price")
        qty = to_float(row, "accum_size")
        if side == "long":
            entry_px, exit_px = long_px, short_px
        else:
            entry_px, exit_px = short_px, long_px
        records.append({
            "symbol": row.get("contract"),
            "side": side,
            "qty": qty,
            "avg_entry_price": entry_px,
            "avg_exit_price": exit_px,
            "cum_entry_value": (entry_px * qty) if entry_px is not None and qty is not None else None,
            "cum_exit_value": (exit_px * qty) if exit_px is not None and qty is not None else None,
            "closed_pnl": to_float(row, "pnl"),
            "created_time": sec_to_utc(row.get("first_open_time")),
            "updated_time": sec_to_utc(row.get("time")),
        })

    df = pd.DataFrame(records)
    df = df.dropna(subset=["closed_pnl", "created_time"])
    df = df.sort_values("created_time").reset_index(drop=True)
    return df


if __name__ == "__main__":
    from app.exchanges._cli import run_smoke_test
    run_smoke_test(DISPLAY_NAME, fetch_closed_trades, env_prefix="GATEIO", requires_passphrase=REQUIRES_PASSPHRASE)
