"""Shared --smoke-test CLI for app/exchanges/* modules. Added 2026-08-23
so every exchange client gets the same "fetch real data, print it raw,
compare against the exchange's own UI before trusting it" verification
step, without duplicating argparse/dotenv boilerplate six times over."""
from __future__ import annotations

import argparse
import os

import pandas as pd
from dotenv import load_dotenv


def run_smoke_test(display_name: str, fetch_fn, env_prefix: str, requires_passphrase: bool = False,
                    open_positions_fn=None) -> None:
    """2026-08-23, round 7: open_positions_fn is optional (only Bybit has
    one so far, see app/exchanges/base.py's module docstring) -- when
    given, also fetches and prints currently-open positions after the
    closed-trade history, same "compare against the exchange's own UI"
    verification step but for the Здоровье tab's new open-positions
    block."""
    load_dotenv()
    extra = f"/{env_prefix}_API_PASSPHRASE" if requires_passphrase else ""
    parser = argparse.ArgumentParser(
        description=f"Fetch your real {display_name} closed-position history and print it raw -- "
                    f"run this FIRST after adding {env_prefix}_API_KEY/{env_prefix}_API_SECRET{extra} "
                    f"to .env, before trusting the automated health-tab pipeline.")
    parser.add_argument("--lookback-days", type=int, default=30)
    parser.add_argument("--smoke-test", action="store_true",
                         help="Required flag -- this module is a library otherwise.")
    args = parser.parse_args()

    if not args.smoke_test:
        parser.error("This module is a library; run with --smoke-test to sanity-check your key/setup.")

    api_key = os.getenv(f"{env_prefix}_API_KEY", "").strip()
    api_secret = os.getenv(f"{env_prefix}_API_SECRET", "").strip()
    passphrase = os.getenv(f"{env_prefix}_API_PASSPHRASE", "").strip() or None

    if not api_key or not api_secret or (requires_passphrase and not passphrase):
        missing = f"{env_prefix}_API_KEY / {env_prefix}_API_SECRET" + (
            f" / {env_prefix}_API_PASSPHRASE" if requires_passphrase else "")
        print(f"{missing} not fully set in .env -- add them first (see .env.example and this "
              f"file's module docstring for how to create a READ-ONLY key on {display_name}).")
        raise SystemExit(1)

    print(f"Fetching {display_name} closed-position history (last {args.lookback_days} days)...")
    try:
        df = fetch_fn(api_key, api_secret, passphrase, lookback_days=args.lookback_days)
    except Exception as exc:
        print(f"FAILED: {exc}")
        raise SystemExit(1)

    if df.empty:
        print("No closed positions found in this window -- either you haven't closed a trade "
              "recently, or (if you expected results) the key/permissions/field names need checking.")
    else:
        with pd.option_context("display.max_columns", None, "display.width", 160):
            print(df)
        print(f"\n{len(df)} closed position(s), {df['created_time'].min()} .. {df['created_time'].max()}")
        print(f"\nCheck this against what you actually see in {display_name}'s own closed-position/"
              f"history page for the same window -- symbol/qty/pnl values should match exactly.")

    if open_positions_fn is not None:
        print(f"\nFetching {display_name} currently-open positions...")
        try:
            open_df = open_positions_fn(api_key, api_secret, passphrase)
        except Exception as exc:
            print(f"FAILED: {exc}")
            raise SystemExit(1)
        if open_df.empty:
            print("No open positions right now.")
        else:
            with pd.option_context("display.max_columns", None, "display.width", 160):
                print(open_df)
            print(f"\n{len(open_df)} open position(s) -- check symbol/qty/unrealized_pnl against "
                  f"{display_name}'s own open-positions page.")
