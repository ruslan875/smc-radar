"""Bitget client -- READ-ONLY. Fetches closed futures-position history via
GET /api/v2/mix/position/history-position (Bitget's "Classic" mix/futures
API -- their docs also have a newer "UTA" unified-account API; this
targets Classic since that's what most existing accounts use). See
app/exchanges/base.py for the shared multi-exchange contract.

NOT verified against a live Bitget account -- run `python
app/exchanges/bitget.py --smoke-test` after adding BITGET_API_KEY/
BITGET_API_SECRET/BITGET_API_PASSPHRASE to .env, and check the printed
trades against Bitget's own Position History page before trusting the
automated pipeline.

Setup (READ-ONLY key): bitget.com -> API Management -> Create API Key.
Permission: select "Read-Only"; leave "Trade"/"Transfer"/"Withdraw" OFF.
Bitget requires you to CHOOSE a passphrase at key-creation time -- write
it down, it cannot be recovered if lost."""
from __future__ import annotations

import base64
import hashlib
import hmac
import sys
import time
from pathlib import Path

if __name__ == "__main__":
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

import pandas as pd
import requests

from app.data import DataError
from app.exchanges.base import ExchangeAuthError, empty_normalized_df, ms_to_utc, normalize_side, to_float

DISPLAY_NAME = "Bitget"
REQUIRES_PASSPHRASE = True
BASE_URL = "https://api.bitget.com"


def _sign(api_secret: str, timestamp: str, method: str, request_path: str, query: str = "", body: str = "") -> str:
    path_part = f"{request_path}?{query}" if query else request_path
    prehash = f"{timestamp}{method}{path_part}{body}"
    digest = hmac.new(api_secret.encode("utf-8"), prehash.encode("utf-8"), hashlib.sha256).digest()
    return base64.b64encode(digest).decode()


def _signed_get(path: str, api_key: str, api_secret: str, passphrase: str, params: dict,
                 retries: int = 3, timeout: float = 15.0) -> dict:
    query = "&".join(f"{k}={v}" for k, v in params.items() if v is not None)
    last_exc: Exception | None = None
    for attempt in range(retries):
        timestamp = str(int(time.time() * 1000))
        signature = _sign(api_secret, timestamp, "GET", path, query)
        headers = {
            "ACCESS-KEY": api_key,
            "ACCESS-SIGN": signature,
            "ACCESS-TIMESTAMP": timestamp,
            "ACCESS-PASSPHRASE": passphrase,
            "Content-Type": "application/json",
            "locale": "en-US",
        }
        url = f"{BASE_URL}{path}" + (f"?{query}" if query else "")
        try:
            resp = requests.get(url, headers=headers, timeout=timeout)
            resp.raise_for_status()
            payload = resp.json()
            if payload.get("code") == "00000":
                return payload
            raise DataError(f"Bitget API error for {path}: {payload.get('msg')} (code={payload.get('code')})")
        except (requests.RequestException, DataError) as exc:
            last_exc = exc
            if attempt < retries - 1:
                time.sleep(1.5 * (attempt + 1))
    raise DataError(f"Failed to fetch {path} after {retries} attempts: {last_exc}")


def fetch_closed_trades(api_key: str, api_secret: str, passphrase: str | None = None,
                         product_type: str = "USDT-FUTURES", lookback_days: int = 30,
                         limit: int = 100) -> pd.DataFrame:
    if not passphrase:
        raise ExchangeAuthError("Bitget requires BITGET_API_PASSPHRASE in addition to key/secret.")

    end_time = int(time.time() * 1000)
    start_time = end_time - lookback_days * 24 * 60 * 60 * 1000

    all_rows: list[dict] = []
    cursor: str | None = None
    while True:
        params: dict = {"productType": product_type, "startTime": start_time, "endTime": end_time, "limit": limit}
        if cursor:
            params["idLessThan"] = cursor
        payload = _signed_get("/api/v2/mix/position/history-position", api_key, api_secret, passphrase, params)
        data = payload.get("data", {}) or {}
        rows = data.get("list", [])
        all_rows.extend(rows)
        cursor = data.get("endId") or None
        if not cursor or not rows:
            break
        time.sleep(0.15)

    if not all_rows:
        return empty_normalized_df()

    records = []
    for row in all_rows:
        open_px = to_float(row, "openAvgPrice")
        close_px = to_float(row, "closeAvgPrice")
        open_sz = to_float(row, "openTotalPos")
        close_sz = to_float(row, "closeTotalPos")
        net_profit = to_float(row, "netProfit")
        records.append({
            "symbol": row.get("symbol"),
            "side": normalize_side(row.get("holdSide")),
            "qty": close_sz,
            "avg_entry_price": open_px,
            "avg_exit_price": close_px,
            "cum_entry_value": (open_px * open_sz) if open_px is not None and open_sz is not None else None,
            "cum_exit_value": (close_px * close_sz) if close_px is not None and close_sz is not None else None,
            "closed_pnl": net_profit if net_profit is not None else to_float(row, "pnl"),
            "created_time": ms_to_utc(row.get("ctime")),
            "updated_time": ms_to_utc(row.get("utime")),
        })

    df = pd.DataFrame(records)
    df = df.dropna(subset=["closed_pnl", "created_time"])
    df = df.sort_values("created_time").reset_index(drop=True)
    return df


if __name__ == "__main__":
    from app.exchanges._cli import run_smoke_test
    run_smoke_test(DISPLAY_NAME, fetch_closed_trades, env_prefix="BITGET", requires_passphrase=REQUIRES_PASSPHRASE)
