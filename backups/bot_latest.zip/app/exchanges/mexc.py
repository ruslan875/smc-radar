"""MEXC Futures/Contract client -- READ-ONLY. Fetches closed-position
history via GET /api/v1/private/position/list/history_positions. This is
MEXC's *contract* API, which uses a different auth scheme from MEXC's
spot API (X-MEXC-APIKEY + query-string signing) -- don't mix them up if
extending this. See app/exchanges/base.py for the shared multi-exchange
contract.

NOT verified against a live MEXC account -- run `python
app/exchanges/mexc.py --smoke-test` after adding MEXC_API_KEY/
MEXC_API_SECRET to .env, and check the printed trades against MEXC's own
Futures Position History page before trusting the automated pipeline.
MEXC's futures API docs are noticeably less polished than the other
exchanges here (no official SDK, sparser examples) -- extra reason to
smoke-test carefully.

Setup (READ-ONLY key): mexc.com -> API Management -> Create API Key.
Under the Futures section enable only the "View" permissions (account
details / order details); leave "Order Placing" OFF. No separate
withdrawal permission exists on a futures-scoped key."""
from __future__ import annotations

import hashlib
import hmac
import sys
import time
from pathlib import Path
from urllib.parse import urlencode

if __name__ == "__main__":
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

import pandas as pd
import requests

from app.data import DataError
from app.exchanges.base import empty_normalized_df, ms_to_utc, normalize_side, to_float

DISPLAY_NAME = "MEXC"
REQUIRES_PASSPHRASE = False
BASE_URL = "https://contract.mexc.com"

_SIDE_MAP = {1: "long", 2: "short"}


def _sign(api_secret: str, api_key: str, timestamp: str, param_string: str) -> str:
    payload = f"{api_key}{timestamp}{param_string}"
    return hmac.new(api_secret.encode("utf-8"), payload.encode("utf-8"), hashlib.sha256).hexdigest()


def _signed_get(path: str, api_key: str, api_secret: str, params: dict,
                 retries: int = 3, timeout: float = 15.0) -> dict:
    sorted_params = {k: v for k, v in sorted(params.items()) if v is not None}
    param_string = urlencode(sorted_params)
    last_exc: Exception | None = None
    for attempt in range(retries):
        timestamp = str(int(time.time() * 1000))
        signature = _sign(api_secret, api_key, timestamp, param_string)
        headers = {"ApiKey": api_key, "Request-Time": timestamp, "Signature": signature,
                   "Content-Type": "application/json"}
        url = f"{BASE_URL}{path}" + (f"?{param_string}" if param_string else "")
        try:
            resp = requests.get(url, headers=headers, timeout=timeout)
            resp.raise_for_status()
            payload = resp.json()
            if payload.get("success") is True:
                return payload
            raise DataError(f"MEXC API error for {path}: {payload.get('message')} (code={payload.get('code')})")
        except (requests.RequestException, DataError) as exc:
            last_exc = exc
            if attempt < retries - 1:
                time.sleep(1.5 * (attempt + 1))
    raise DataError(f"Failed to fetch {path} after {retries} attempts: {last_exc}")


def fetch_closed_trades(api_key: str, api_secret: str, passphrase: str | None = None,
                         lookback_days: int = 30, limit: int = 100) -> pd.DataFrame:
    """`passphrase` accepted-and-ignored for call-signature uniformity.
    `lookback_days` isn't a query param on this endpoint (MEXC's
    history-positions has no start/end filter) so the cutoff is applied
    client-side after fetching each page."""
    cutoff = pd.Timestamp.now(tz="UTC") - pd.Timedelta(days=lookback_days)
    page_size = min(limit, 100)

    all_rows: list[dict] = []
    page_num = 1
    while True:
        params = {"page_num": page_num, "page_size": page_size}
        payload = _signed_get("/api/v1/private/position/list/history_positions", api_key, api_secret, params)
        rows = payload.get("data", []) or []
        all_rows.extend(rows)
        if len(rows) < page_size or page_num > 50:  # hard safety cap against a runaway loop
            break
        page_num += 1
        time.sleep(0.15)

    if not all_rows:
        return empty_normalized_df()

    records = []
    for row in all_rows:
        created = ms_to_utc(row.get("createTime"))
        if created is not pd.NaT and created < cutoff:
            continue
        open_px = to_float(row, "openAvgPrice")
        close_px = to_float(row, "closeAvgPrice")
        close_vol = to_float(row, "closeVol")
        records.append({
            "symbol": row.get("symbol"),
            "side": _SIDE_MAP.get(row.get("positionType"), normalize_side(row.get("positionType"))),
            "qty": close_vol,
            "avg_entry_price": open_px,
            "avg_exit_price": close_px,
            "cum_entry_value": (open_px * close_vol) if open_px is not None and close_vol is not None else None,
            "cum_exit_value": (close_px * close_vol) if close_px is not None and close_vol is not None else None,
            "closed_pnl": to_float(row, "realised"),
            "created_time": created,
            "updated_time": ms_to_utc(row.get("updateTime")),
        })

    df = pd.DataFrame(records)
    df = df.dropna(subset=["closed_pnl", "created_time"])
    df = df.sort_values("created_time").reset_index(drop=True)
    return df


if __name__ == "__main__":
    from app.exchanges._cli import run_smoke_test
    run_smoke_test(DISPLAY_NAME, fetch_closed_trades, env_prefix="MEXC", requires_passphrase=REQUIRES_PASSPHRASE)
