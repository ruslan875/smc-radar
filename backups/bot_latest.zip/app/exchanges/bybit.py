"""Bybit v5 client -- READ-ONLY. First exchange integration in this
codebase (added 2026-08-23), migrated here the same day as part of a
multi-exchange redesign (originally lived at app/bybit_account.py, which
is now a thin backward-compat shim -- see that file). Fetches closed-
position history via GET /v5/position/closed-pnl. See
app/exchanges/base.py for the shared multi-exchange contract this and its
siblings implement.

NOT verified against live Bybit (no sandbox network access + no real
credentials when this was written) -- run `python app/exchanges/bybit.py
--smoke-test` on your own machine after adding BYBIT_API_KEY/
BYBIT_API_SECRET to .env, and check the printed trades against Bybit's
own Orders -> Closed P&L tab before trusting the automated pipeline.

Setup (READ-ONLY key): bybit.com -> profile icon -> API -> Create New Key
-> "System-generated API Keys". Enable ONLY "Positions" (or "Read-Only"
if offered) under Contract/Derivatives; leave "Orders"/"Trade" and every
withdrawal/transfer permission OFF. Bybit shows the secret ONCE."""
from __future__ import annotations

import hashlib
import hmac
import sys
import time
from pathlib import Path
from urllib.parse import urlencode

if __name__ == "__main__":
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent))

import pandas as pd
import requests

from app.data import BYBIT_BASE, DataError
from app.exchanges.base import (
    ExchangeAuthError,
    empty_normalized_df,
    empty_open_positions_df,
    ms_to_utc,
    normalize_side,
    to_float,
)

DISPLAY_NAME = "Bybit"
REQUIRES_PASSPHRASE = False
RECV_WINDOW = "5000"
# 2026-10-25: адрес для ПОДПИСАННЫХ запросов (ордера, позиции). По умолчанию — реальный Bybit, как всегда.
# Демо-копии ботов (start_demo_bots.bat) задают BYBIT_TRADE_BASE=https://api-demo.bybit.com — реальный счёт им недоступен.
import os as _os
TRADE_BASE = (_os.environ.get("BYBIT_TRADE_BASE") or BYBIT_BASE).rstrip("/")
if "api-demo" in TRADE_BASE:
    RECV_WINDOW = "30000"   # демо через VPN бывает медленным

# Backward-compat alias -- the class used to be named BybitAuthError before
# the 2026-08-23 multi-exchange redesign generalized it to ExchangeAuthError
# (see app/exchanges/base.py). Kept so app/bybit_account.py's shim imports
# don't break.
BybitAuthError = ExchangeAuthError



# 2026-09-24: поправка на расхождение часов компьютера с Bybit.
# Bybit отклоняет запрос (retCode 10002), если его время впереди серверного
# больше чем на 1 с. Живой случай: часы ПК спешили на ~1,2 с, и перестали
# работать автопилот и загрузка сделок/баланса. Раз в 5 минут берём время
# сервера (публичный /v5/market/time, без ключей) и считаем смещение;
# ещё 500 мс запаса назад — чтобы не упираться в границу окна.
_TIME_OFFSET_MS = 0
_TIME_OFFSET_AT = 0.0
_TIME_SYNC_EVERY_S = 300


def _sync_time(force: bool = False) -> None:
    global _TIME_OFFSET_MS, _TIME_OFFSET_AT
    if not force and time.time() - _TIME_OFFSET_AT < _TIME_SYNC_EVERY_S:
        return
    try:
        t0 = time.time()
        r = requests.get(f"{TRADE_BASE}/v5/market/time", timeout=5).json()
        t1 = time.time()
        server_ms = int(r.get("time") or int(r["result"]["timeNano"]) // 1_000_000)
        local_ms = int((t0 + t1) / 2 * 1000)
        _TIME_OFFSET_MS = server_ms - local_ms - 500
        _TIME_OFFSET_AT = t1
    except Exception as exc:  # без поправки работаем как раньше
        _TIME_OFFSET_AT = time.time()
        print(f"[BYBIT] time sync failed ({exc}) -- using local clock", file=sys.stderr)


def _now_ms() -> int:
    _sync_time()
    return int(time.time() * 1000) + _TIME_OFFSET_MS


def _sign(api_secret: str, timestamp: str, api_key: str, query_string: str) -> str:
    payload = f"{timestamp}{api_key}{RECV_WINDOW}{query_string}"
    return hmac.new(api_secret.encode("utf-8"), payload.encode("utf-8"), hashlib.sha256).hexdigest()


def _signed_post(path: str, api_key: str, api_secret: str, params: dict, timeout: float = 15.0) -> dict:
    """POST counterpart to _signed_get, for order-placement/leverage calls
    (2026-08-23, round 8) -- Bybit v5 signs POST requests over the raw JSON
    body instead of a query string, everything else about the signing
    scheme is identical (see _sign).

    Deliberately NO automatic retry, unlike _signed_get's retries=3 above:
    retrying a create-order call after a network timeout risks placing the
    SAME order twice if the first request actually succeeded on Bybit's
    side but the response never made it back. Callers (set_leverage,
    place_order below) surface the raw failure instead -- main.py's
    _handle_trade_command tells the owner to check Bybit's own UI before
    deciding whether to resend, rather than silently retrying on their
    behalf."""
    import json as _json

    body = _json.dumps(params)
    timestamp = str(_now_ms())
    signature = _sign(api_secret, timestamp, api_key, body)
    headers = {
        "X-BAPI-API-KEY": api_key,
        "X-BAPI-SIGN": signature,
        "X-BAPI-SIGN-TYPE": "2",
        "X-BAPI-TIMESTAMP": timestamp,
        "X-BAPI-RECV-WINDOW": RECV_WINDOW,
        "Content-Type": "application/json",
    }
    try:
        resp = requests.post(f"{TRADE_BASE}{path}", data=body, headers=headers, timeout=timeout)
        resp.raise_for_status()
        payload = resp.json()
    except requests.RequestException as exc:
        raise DataError(f"Bybit POST {path} failed: {exc}")

    ret_code = payload.get("retCode")
    if ret_code in (10003, 10004, 10005):
        raise ExchangeAuthError(
            f"Bybit auth error ({ret_code}): {payload.get('retMsg')} -- this key needs 'Orders'/'Trade' "
            f"permission (not just 'Positions' read-only) to place trades. Check BYBIT trade key setup."
        )
    return payload


def _signed_get(path: str, api_key: str, api_secret: str, params: dict,
                 retries: int = 3, timeout: float = 15.0) -> dict:
    query_string = urlencode(params, doseq=True)
    last_exc: Exception | None = None
    for attempt in range(retries):
        timestamp = str(_now_ms())
        signature = _sign(api_secret, timestamp, api_key, query_string)
        headers = {
            "X-BAPI-API-KEY": api_key,
            "X-BAPI-SIGN": signature,
            "X-BAPI-SIGN-TYPE": "2",
            "X-BAPI-TIMESTAMP": timestamp,
            "X-BAPI-RECV-WINDOW": RECV_WINDOW,
        }
        try:
            resp = requests.get(f"{TRADE_BASE}{path}", params=params, headers=headers, timeout=timeout)
            resp.raise_for_status()
            payload = resp.json()
            ret_code = payload.get("retCode")
            if ret_code == 0:
                return payload
            # 10003/10004/10005 = invalid key/sign/permission per Bybit's error-code table.
            if ret_code in (10003, 10004, 10005):
                raise ExchangeAuthError(
                    f"Bybit auth error ({ret_code}): {payload.get('retMsg')} -- check BYBIT_API_KEY/"
                    f"BYBIT_API_SECRET in .env and that the key has 'Positions' read permission."
                )
            if ret_code == 10002:  # часы разошлись — пересинхронизироваться перед повтором
                _sync_time(force=True)
            raise DataError(f"Bybit API error for {path}: {payload.get('retMsg')} (retCode={ret_code})")
        except ExchangeAuthError:
            raise
        except (requests.RequestException, DataError) as exc:
            last_exc = exc
            if attempt < retries - 1:
                time.sleep(1.5 * (attempt + 1))
    raise DataError(f"Failed to fetch {path} after {retries} attempts: {last_exc}")


# 2026-08-23, round 5 bugfix: confirmed live against the user's real Bybit
# account -- a single startTime..endTime request spanning the full
# lookback_days (30 by default) fails with retCode=10001 "The time range
# between startTime and endTime cannot exceed 7 days." This was never
# caught earlier because this module was "NOT verified against live
# Bybit" until now (see the module docstring). Fixed the same way KuCoin's
# client already handles its own 7-day-per-request cap: walk the full
# lookback in non-overlapping 7-day windows, paginating (cursor) within
# each window.
_WINDOW_MS = 7 * 24 * 60 * 60 * 1000


def fetch_closed_trades(api_key: str, api_secret: str, passphrase: str | None = None,
                         category: str = "linear", lookback_days: int = 30, limit: int = 100) -> pd.DataFrame:
    """`passphrase` is accepted-and-ignored -- kept only so every
    app/exchanges/* module has the same call signature; Bybit doesn't use
    one."""
    end_time = int(time.time() * 1000)
    overall_start = end_time - lookback_days * 24 * 60 * 60 * 1000

    all_rows: list[dict] = []
    window_end = end_time
    while window_end > overall_start:
        window_start = max(overall_start, window_end - _WINDOW_MS)
        cursor: str | None = None
        while True:
            params: dict = {
                "category": category, "startTime": window_start, "endTime": window_end, "limit": limit,
            }
            if cursor:
                params["cursor"] = cursor
            payload = _signed_get("/v5/position/closed-pnl", api_key, api_secret, params)
            result = payload.get("result", {})
            rows = result.get("list", [])
            all_rows.extend(rows)
            cursor = result.get("nextPageCursor") or None
            if not cursor or not rows:
                break
            time.sleep(0.15)
        window_end = window_start
        if window_end > overall_start:
            time.sleep(0.15)

    if not all_rows:
        return empty_normalized_df()

    # Adjacent windows share their boundary timestamp, so a trade sitting
    # exactly on one could in principle come back in both -- dedupe on
    # Bybit's own orderId (unique per closed position) before normalizing.
    seen_ids: set[str] = set()
    deduped_rows: list[dict] = []
    for row in all_rows:
        order_id = row.get("orderId")
        if order_id is not None:
            if order_id in seen_ids:
                continue
            seen_ids.add(order_id)
        deduped_rows.append(row)
    all_rows = deduped_rows

    records = []
    for row in all_rows:
        # 2026-09-24: в closed-pnl поле side — сторона ЗАКРЫВАЮЩЕГО ордера
        # (Sell закрывает лонг). Mini App показывал лонги ботов как SHORT.
        close_side = normalize_side(row.get("side"))
        pos_side = {"short": "long", "long": "short"}.get(close_side, close_side)
        records.append({
            "symbol": row.get("symbol"),
            "side": pos_side,
            "qty": to_float(row, "qty"),
            "avg_entry_price": to_float(row, "avgEntryPrice"),
            "avg_exit_price": to_float(row, "avgExitPrice"),
            "cum_entry_value": to_float(row, "cumEntryValue"),
            "cum_exit_value": to_float(row, "cumExitValue"),
            "closed_pnl": to_float(row, "closedPnl"),
            "created_time": ms_to_utc(row.get("createdTime")),
            "updated_time": ms_to_utc(row.get("updatedTime")),
        })

    df = pd.DataFrame(records)
    df = df.dropna(subset=["closed_pnl", "created_time"])
    df = df.sort_values("created_time").reset_index(drop=True)
    return df


# 2026-08-23, round 7: the OPTIONAL fetch_open_positions() contract (see
# app/exchanges/base.py's module docstring) -- added after the user opened
# a real position live to test the /setkey flow and found the Здоровье tab
# showed nothing, since /v5/position/closed-pnl (above) only ever returns
# CLOSED trades. GET /v5/position/list is the read-only counterpart for
# what's currently open; unlike closed-pnl it has no 7-day-window
# restriction (round 6's bug) so one request covers everything. Passing
# settleCoin=USDT (rather than a specific symbol) returns every open
# USDT-margined linear position on the account in one call.
def fetch_open_positions(api_key: str, api_secret: str, passphrase: str | None = None,
                          category: str = "linear", settle_coin: str = "USDT") -> pd.DataFrame:
    """`passphrase` accepted-and-ignored, same reasoning as
    fetch_closed_trades() above."""
    params = {"category": category, "settleCoin": settle_coin, "limit": 200}
    payload = _signed_get("/v5/position/list", api_key, api_secret, params)
    rows = payload.get("result", {}).get("list", [])

    records = []
    for row in rows:
        size = to_float(row, "size")
        if not size:  # Bybit can include zero-size rows for a symbol you've traded before; skip those.
            continue
        records.append({
            "symbol": row.get("symbol"),
            "side": normalize_side(row.get("side")),
            "qty": size,
            "avg_entry_price": to_float(row, "avgPrice"),
            "mark_price": to_float(row, "markPrice"),
            "unrealized_pnl": to_float(row, "unrealisedPnl"),
            "position_value": to_float(row, "positionValue"),
            "leverage": to_float(row, "leverage"),
            "created_time": ms_to_utc(row.get("createdTime")),
            # 2026-08-23, round 9: Bybit returns these as "" (empty string)
            # when the position has no stop/take set -- to_float() already
            # treats "" as None (see base.py), so this is just the plain
            # currently-set value on the exchange, not anything this bot
            # tracks itself. Powers the breakeven-autopilot R calculation
            # (see app/autopilot.py) for ANY open position, including ones
            # opened by hand rather than via this bot's /trade.
            "stop_loss": to_float(row, "stopLoss"),
            "take_profit": to_float(row, "takeProfit"),
        })

    if not records:
        return empty_open_positions_df()
    return pd.DataFrame(records)


# 2026-08-23, round 8: the OPTIONAL place_order()/set_leverage() contract
# (see app/exchanges/base.py's module docstring) -- the only exchange with
# this implemented so far. Deliberately NOT wired into run_smoke_test's CLI
# (app/exchanges/_cli.py) the way fetch_open_positions is -- a generic
# --smoke-test flag accidentally placing a real order would be a much
# worse failure mode than it printing wrong data, so this can only ever be
# reached through main.py's /trade command, which runs every guard in
# app/trading_guard.py first.
def set_leverage(api_key: str, api_secret: str, symbol: str, leverage: int,
                  passphrase: str | None = None, category: str = "linear") -> None:
    """`passphrase` accepted-and-ignored, same reasoning as
    fetch_closed_trades() above. retCode 110043 ("leverage not modified")
    means the symbol is already set to this leverage -- Bybit treats that
    as an error but it isn't one for our purposes, so it's treated as
    success rather than surfaced to the owner as a failure."""
    params = {
        "category": category, "symbol": symbol,
        "buyLeverage": str(leverage), "sellLeverage": str(leverage),
    }
    payload = _signed_post("/v5/position/set-leverage", api_key, api_secret, params)
    ret_code = payload.get("retCode")
    if ret_code not in (0, 110043):
        raise DataError(f"Bybit set-leverage error: {payload.get('retMsg')} (retCode={ret_code})")


# 2026-08-25, round 15: real live failure -- a real /trade attempt on the
# user's own account came back "Bybit order-create error: position idx
# not match position mode (retCode=10001)". Root cause, confirmed against
# Bybit's own v5 docs (bybit-exchange.github.io/docs/v5/order/create-order)
# plus real-world reports of this exact error (not guessed): Bybit's
# `positionIdx` field means 0 = One-Way Mode, 1 = Hedge-Mode Buy/long side,
# 2 = Hedge-Mode Sell/short side -- and it's REQUIRED to match whichever
# mode the account is actually in (One-Way vs Hedge), account-side, not
# something this bot can see in advance without an extra API call. This
# module always omitted positionIdx entirely (equivalent to sending 0,
# i.e. assuming One-Way Mode) -- fine for a One-Way account, but Bybit
# rejects it outright with retCode 10001 the instant the account is
# actually in Hedge Mode, which is exactly what happened live. See
# `_retry_with_hedge_position_idx` below for the fix, shared by both
# place_order() and amend_stop_loss() since both hardcoded the same
# One-Way assumption.
_POSITION_IDX_ERROR_CODE = 10001


def _is_position_idx_mismatch(payload: dict) -> bool:
    """True only for the SPECIFIC "position idx not match position mode"
    rejection -- retCode 10001 is Bybit's generic "parameter error" code
    and covers many unrelated problems too, so this also checks retMsg
    before treating it as the hedge-mode case (a different param error
    retrying with a positionIdx change wouldn't fix, and could mask)."""
    if payload.get("retCode") != _POSITION_IDX_ERROR_CODE:
        return False
    return "position idx" in str(payload.get("retMsg") or "").lower()


def _hedge_position_idx(side: str) -> int:
    """side is "buy"/"long" -> 1 (hedge-mode Buy side), anything else
    (sell/short) -> 2 (hedge-mode Sell side) -- per Bybit's own v5 docs."""
    return 1 if side in ("buy", "long") else 2


# 2026-08-23, round 9 ("Вера" autopilot -- see app/autopilot.py): moves an
# EXISTING open position's stop-loss, unlike place_order() below which
# opens a brand-new one. Calls Bybit's dedicated trading-stop endpoint
# rather than amending via order/create, since that endpoint is built
# specifically for changing SL/TP on a position that's already open and
# doesn't touch position size at all.
def amend_stop_loss(api_key: str, api_secret: str, symbol: str, stop_loss: float,
                     passphrase: str | None = None, category: str = "linear",
                     side: str | None = None) -> None:
    """`passphrase` accepted-and-ignored, same reasoning as
    fetch_closed_trades() above. Deliberately does NOT touch take_profit --
    only ever called by the breakeven-autopilot loop, which only ever
    changes the stop.

    `side` ("long"/"short", from the SAME open-position dict the autopilot
    already has -- see main.py's `_autopilot_worker`) is OPTIONAL and only
    used for the round-15 Hedge-Mode retry below -- omitting it just means
    a Hedge-Mode account's mismatch can't be auto-corrected here (the
    original error is raised instead, same as before this round)."""
    params = {
        "category": category, "symbol": symbol, "positionIdx": 0,
        "stopLoss": str(stop_loss), "tpslMode": "Full",
    }
    payload = _signed_post("/v5/position/trading-stop", api_key, api_secret, params)
    ret_code = payload.get("retCode")
    if ret_code not in (0, 34040) and _is_position_idx_mismatch(payload) and side is not None:
        # 2026-08-25, round 15: the account is in Hedge Mode -- retry ONCE
        # with the side-appropriate hedge positionIdx. Safe to retry: a
        # retCode-10001 parameter rejection happens BEFORE Bybit touches
        # the position at all, so nothing was changed by the first
        # attempt -- this is not the "network-ambiguous, might have
        # already succeeded" case this module avoids auto-retrying
        # elsewhere (see place_order()'s own docstring).
        retry_params = dict(params, positionIdx=_hedge_position_idx(side))
        payload = _signed_post("/v5/position/trading-stop", api_key, api_secret, retry_params)
        ret_code = payload.get("retCode")
    # 34040 = "not modified" (already at this exact stop) -- treat as
    # success, same reasoning as set_leverage()'s 110043 above.
    if ret_code not in (0, 34040):
        raise DataError(f"Bybit trading-stop error: {payload.get('retMsg')} (retCode={ret_code})")


def set_trailing_stop(api_key: str, api_secret: str, symbol: str, distance: float, active_price: float,
                      side: str | None = None, category: str = "linear") -> None:
    """2026-09-24: трейлинг-стоп НА СТОРОНЕ БИРЖИ (Bybit trading-stop,
    поле trailingStop). Когда цена дойдёт до active_price, Bybit начинает
    вести стоп на расстоянии `distance` (в единицах цены) за лучшей ценой и
    двигает его только в сторону прибыли. Работает, даже если компьютер
    выключен. Обычный stopLoss позиции не трогаем: он остаётся страховкой
    до активации трейлинга, срабатывает тот, что ближе."""
    params = {"category": category, "symbol": symbol, "positionIdx": 0, "tpslMode": "Full",
              "trailingStop": f"{distance:.10f}".rstrip("0").rstrip("."),
              "activePrice": f"{active_price:.10f}".rstrip("0").rstrip(".")}
    payload = _signed_post("/v5/position/trading-stop", api_key, api_secret, params)
    ret_code = payload.get("retCode")
    if ret_code not in (0, 34040) and _is_position_idx_mismatch(payload) and side is not None:
        payload = _signed_post("/v5/position/trading-stop", api_key, api_secret,
                               dict(params, positionIdx=_hedge_position_idx(side)))
        ret_code = payload.get("retCode")
    if ret_code not in (0, 34040):
        raise DataError(f"Bybit trailing-stop error: {payload.get('retMsg')} (retCode={ret_code})")


def place_order(api_key: str, api_secret: str, symbol: str, side: str, qty: float, stop_loss: float,
                 take_profit: float | None = None, passphrase: str | None = None,
                 category: str = "linear", entry_price: float | None = None) -> dict:
    """`side` is "buy"/"sell" (the /trade command's own vocabulary, see
    main.py's _handle_trade_command), mapped to Bybit's "Buy"/"Sell".
    stop_loss is REQUIRED (mandatory per the user's explicit choice, see
    app/trading_guard.py) and passed straight through as Bybit's own
    `stopLoss` order field, so the exchange attaches it atomically with
    the entry rather than this module making a second, separately-
    fallible API call to set it afterward. `passphrase` accepted-and-
    ignored, same reasoning as fetch_closed_trades() above.

    `entry_price` -- 2026-08-25, round 16: OPTIONAL, added at the user's
    request ("нужно добавить функцию по какой цене входить в сделку" --
    need a way to say what price to enter at). `None` (the default, and
    the ONLY behavior that existed before this round) places a Market
    order exactly as before -- fills immediately at whatever the current
    price is. A real number instead places a GTC Limit order resting on
    Bybit's own order book at that exact price -- it may fill instantly
    if the price already qualifies (crossing the book, same as a taker
    market fill), may sit unfilled until the market reaches it, or may
    never fill at all. This bot does not yet expose a way to cancel a
    still-pending limit order -- see the project doc's Round 16 write-up
    for that known gap. app/trade_executor.py is responsible for using
    `entry_price` (when given) instead of the live market price for every
    guard check (stop-loss side, risk-budget sizing) -- this function
    itself just places whichever order type it's told to.

    Deliberately does NOT auto-retry on an ambiguous failure (a network
    timeout could mean the order actually went through) -- see the
    module's place_order() contract in app/exchanges/base.py. The ONE
    exception, added 2026-08-25 round 15: a retCode-10001 "position idx
    not match position mode" rejection is NOT ambiguous -- it's Bybit
    refusing the request before creating anything, because this module's
    default assumption (One-Way Mode, positionIdx 0) doesn't match a
    Hedge-Mode account. That specific, well-understood case IS safely
    retried once with the correct hedge positionIdx for this order's own
    side."""
    bybit_side = "Buy" if side == "buy" else "Sell"
    params = {
        "category": category, "symbol": symbol, "side": bybit_side,
        "qty": str(qty), "stopLoss": str(stop_loss),
    }
    if entry_price is not None:
        params["orderType"] = "Limit"
        params["price"] = str(entry_price)
        params["timeInForce"] = "GTC"  # rests on the book until filled or manually cancelled
    else:
        params["orderType"] = "Market"
    if take_profit:
        params["takeProfit"] = str(take_profit)
    # 2026-11-08 (аудит, ТЗ ChatGPT P1): свой уникальный ID ордера. Пишем его в журнал ДО отправки —
    # после таймаута ордер можно точно найти на бирже по orderLinkId и не отправить второй.
    import uuid as _uuid  # noqa: PLC0415
    params["orderLinkId"] = "TOS-" + _uuid.uuid4().hex[:20]
    order_state(params["orderLinkId"], "NEW", symbol=symbol, side=bybit_side, qty=str(qty), sl=str(stop_loss),
                tp=str(take_profit or ""), type=params["orderType"], price=params.get("price"))
    try:
        payload = _signed_post("/v5/order/create", api_key, api_secret, params)
    except Exception as _e:
        order_state(params["orderLinkId"], "UNKNOWN", error=str(_e)[:200], note="обрыв/таймаут — проверить на бирже по orderLinkId, повторно НЕ отправлять")
        raise
    ret_code = payload.get("retCode")
    if ret_code != 0 and _is_position_idx_mismatch(payload):
        retry_params = dict(params, positionIdx=_hedge_position_idx(side))
        payload = _signed_post("/v5/order/create", api_key, api_secret, retry_params)
        ret_code = payload.get("retCode")
    if ret_code != 0:
        order_state(params["orderLinkId"], "REJECTED", ret_code=ret_code, ret_msg=str(payload.get("retMsg"))[:200])
        raise DataError(f"Bybit order-create error: {payload.get('retMsg')} (retCode={ret_code})")

    result = payload.get("result", {})
    order_state(params["orderLinkId"], "ACCEPTED", order_id=result.get("orderId"), ret_code=0, ret_msg=str(payload.get("retMsg"))[:80])
    return {"order_id": result.get("orderId"), "order_link_id": result.get("orderLinkId")}


# 2026-11-08 (ChatGPT ТЗ, фаза 8): конечный автомат состояний ордера + журнал ответов биржи.
# NEW → (ACCEPTED | REJECTED | UNKNOWN) → (FILLED | PARTIAL | CANCELLED) → SL_CONFIRMED | SL_MISSING.
# Пишется в logs/order_journal.jsonl (без ключей). Последнее состояние — у последней записи с этим id.
ORDER_STATES = ("NEW", "ACCEPTED", "REJECTED", "UNKNOWN", "FILLED", "PARTIAL", "CANCELLED", "SL_CONFIRMED", "SL_MISSING")


def order_state(link_id: str, state: str, **info) -> None:
    import json as _json, time as _time  # noqa: PLC0415
    from pathlib import Path as _P  # noqa: PLC0415
    if state not in ORDER_STATES:
        state = "UNKNOWN"
    try:
        lg = _P(__file__).resolve().parents[2] / "logs" / "order_journal.jsonl"; lg.parent.mkdir(exist_ok=True)
        with open(lg, "a", encoding="utf-8") as f:
            f.write(_json.dumps({"t": int(_time.time() * 1000), "ex": "bybit", "id": link_id, "state": state,
                                 **{k: v for k, v in info.items() if v not in (None, "")}}, ensure_ascii=False) + "\n")
    except OSError:
        pass


def confirm_order(api_key: str, api_secret: str, symbol: str, link_id: str) -> str:
    """Проверить на бирже, что стало с ордером (по orderLinkId), и записать итоговое состояние. Без повторной отправки."""
    st = "UNKNOWN"
    try:
        for path in ("/v5/order/realtime", "/v5/order/history"):
            rows = (_signed_get(path, api_key, api_secret, {"category": "linear", "symbol": symbol, "orderLinkId": link_id}).get("result") or {}).get("list") or []
            if rows:
                o = rows[0]; s_ = str(o.get("orderStatus"))
                st = {"Filled": "FILLED", "PartiallyFilled": "PARTIAL", "Cancelled": "CANCELLED", "Rejected": "REJECTED",
                      "Deactivated": "CANCELLED", "New": "ACCEPTED"}.get(s_, "UNKNOWN")
                order_state(link_id, st, exch_status=s_, avg_price=o.get("avgPrice"), cum_qty=o.get("cumExecQty"), qty=o.get("qty"))
                break
        if st in ("FILLED", "PARTIAL"):
            pos = (_signed_get("/v5/position/list", api_key, api_secret, {"category": "linear", "symbol": symbol}).get("result") or {}).get("list") or []
            sl = next((float(p.get("stopLoss") or 0) for p in pos if float(p.get("size") or 0) > 0), 0)
            order_state(link_id, "SL_CONFIRMED" if sl > 0 else "SL_MISSING", stop_loss=sl or None)
            st = "SL_CONFIRMED" if sl > 0 else "SL_MISSING"
    except Exception as e:  # noqa: BLE001
        order_state(link_id, "UNKNOWN", error=f"проверка: {e}"[:200])
    return st


# 2026-08-31: DCA-grid live trading (veles_dca_live.py) needs two
# capabilities no existing caller of this module needed before:
#
#   1. Flattening a position with NO new stop-loss to set (place_order()'s
#      contract makes stop_loss mandatory, correct for opening a fresh
#      manual /trade but wrong for closing one -- there's no "loss" to
#      protect against on the way out). See close_position() below.
#   2. Pulling back still-resting grid safety-orders once a deal is done
#      (by stop-loss or by the WaveTrend take-profit signal) so they can
#      never fill later against a position that no longer exists -- the
#      exact "known gap" place_order()'s own docstring flagged back in
#      round 16 ("This bot does not yet expose a way to cancel a still-
#      pending limit order"). See cancel_all_open_orders() below.
#
# Also added: get_instrument_info(), a PUBLIC (unsigned) endpoint the live
# script needs to convert a USDT notional into a valid contract quantity
# (Bybit rejects sizes that don't line up with a symbol's qtyStep/
# minOrderQty) -- unrelated to auth, so it takes no api_key/api_secret.

def get_instrument_info(symbol: str, category: str = "linear", retries: int = 3,
                         timeout: float = 15.0) -> dict:
    """Public endpoint, no signing needed. Returns {"qty_step":..,
    "min_order_qty":..} for rounding a USDT notional into a valid order
    quantity before calling place_order()/close_position(). Retry-with-
    backoff, same pattern as every other repeated/critical network call in
    this project (see veles_dca_backtest.py's _fetch_page() docstring for
    why a bare, unretried request is a real, previously-hit bug class
    here) -- this one only runs once per symbol at live-script startup,
    but a transient blip there would otherwise abort the whole run before
    it even begins."""
    last_exc: Exception | None = None
    for attempt in range(retries):
        try:
            resp = requests.get(
                f"{BYBIT_BASE}/v5/market/instruments-info",
                params={"category": category, "symbol": symbol}, timeout=timeout,
            )
            resp.raise_for_status()
            payload = resp.json()
            if payload.get("retCode") != 0:
                raise DataError(f"Bybit instruments-info error for {symbol}: {payload.get('retMsg')}")
            rows = payload.get("result", {}).get("list", [])
            if not rows:
                raise DataError(f"No instrument info returned for {symbol}")
            lot = rows[0].get("lotSizeFilter", {})
            pf = rows[0].get("priceFilter", {})
            return {
                "qty_step": float(lot.get("qtyStep", "0.001")),
                "min_order_qty": float(lot.get("minOrderQty", "0.001")),
                "tick_size": float(pf.get("tickSize", "0.0001")),  # 2026-09-24: для трейлинг-стопа
            }
        except (requests.RequestException, DataError) as exc:
            last_exc = exc
            if attempt < retries - 1:
                time.sleep(1.5 * (attempt + 1))
    raise DataError(f"Bybit instruments-info failed for {symbol} after {retries} attempts: {last_exc}")


def get_last_price(symbol: str, category: str = "linear", retries: int = 3,
                    timeout: float = 15.0) -> float:
    """Public endpoint, no signing needed. Returns the last traded price
    for `symbol`. 2026-09-01: added alongside a new startup check in
    kc_roc_cci_wt_grid_live.py that needs a real price to warn about
    qty-step rounding distorting the grid split on higher-priced coins
    (see that file's main() -- get_instrument_info() alone only gives
    qtyStep/minOrderQty, not price, and that check needs both). Same
    retry-with-backoff pattern as get_instrument_info() -- this also only
    runs once per symbol at live-script startup."""
    last_exc: Exception | None = None
    for attempt in range(retries):
        try:
            resp = requests.get(
                f"{BYBIT_BASE}/v5/market/tickers",
                params={"category": category, "symbol": symbol}, timeout=timeout,
            )
            resp.raise_for_status()
            payload = resp.json()
            if payload.get("retCode") != 0:
                raise DataError(f"Bybit tickers error for {symbol}: {payload.get('retMsg')}")
            rows = payload.get("result", {}).get("list", [])
            if not rows:
                raise DataError(f"No ticker returned for {symbol}")
            return float(rows[0]["lastPrice"])
        except (requests.RequestException, DataError, KeyError, ValueError) as exc:
            last_exc = exc
            if attempt < retries - 1:
                time.sleep(1.5 * (attempt + 1))
    raise DataError(f"Bybit tickers failed for {symbol} after {retries} attempts: {last_exc}")


def cancel_all_open_orders(api_key: str, api_secret: str, symbol: str,
                            passphrase: str | None = None, category: str = "linear") -> int:
    """Cancels every still-resting order for `symbol` (used to pull back
    unfilled DCA-grid safety-orders once a deal closes, see module note
    above). `passphrase` accepted-and-ignored, same reasoning as
    fetch_closed_trades() above. Returns the number of orders Bybit
    reports as cancelled -- 0 is not an error, it just means nothing was
    resting."""
    params = {"category": category, "symbol": symbol}
    payload = _signed_post("/v5/order/cancel-all", api_key, api_secret, params)
    ret_code = payload.get("retCode")
    if ret_code != 0:
        raise DataError(f"Bybit cancel-all error: {payload.get('retMsg')} (retCode={ret_code})")
    return len(payload.get("result", {}).get("list", []) or [])


def close_position(api_key: str, api_secret: str, symbol: str, position_side: str, qty: float,
                    passphrase: str | None = None, category: str = "linear") -> dict:
    """Flattens an EXISTING position with a reduce-only Market order -- the
    DCA-grid live take-profit exit path (see module note above), which has
    no stop-loss to set because the position is being closed, not opened.
    `position_side` is the side the OPEN position is on ("buy"/"long" or
    "sell"/"short"), NOT the order side -- this function flips it
    internally to place the opposite-side closing order. `passphrase`
    accepted-and-ignored, same reasoning as fetch_closed_trades() above.

    reduceOnly=True is the safety property that matters here: if `qty`
    ever overshoots the real remaining position size (e.g. a stale local
    estimate racing a grid-leg fill), Bybit rejects the excess rather than
    silently flipping into a fresh position in the opposite direction."""
    close_side = "Sell" if position_side in ("buy", "long") else "Buy"
    params = {
        "category": category, "symbol": symbol, "side": close_side,
        "qty": str(qty), "orderType": "Market", "reduceOnly": True,
    }
    payload = _signed_post("/v5/order/create", api_key, api_secret, params)
    ret_code = payload.get("retCode")
    if ret_code != 0 and _is_position_idx_mismatch(payload):
        retry_params = dict(params, positionIdx=_hedge_position_idx(position_side))
        payload = _signed_post("/v5/order/create", api_key, api_secret, retry_params)
        ret_code = payload.get("retCode")
    if ret_code != 0:
        raise DataError(f"Bybit close-position error: {payload.get('retMsg')} (retCode={ret_code})")
    result = payload.get("result", {})
    return {"order_id": result.get("orderId"), "order_link_id": result.get("orderLinkId")}


# 2026-08-31: total account equity, for the automatic daily trading-report
# digest (main.py's _daily_report_worker) -- Bybit's own wallet-balance
# endpoint, not used by anything else in this project so far. `passphrase`
# accepted-and-ignored, same reasoning as fetch_closed_trades() above.
def get_wallet_balance(api_key: str, api_secret: str, passphrase: str | None = None,
                        account_type: str = "UNIFIED") -> float:
    """Returns total account equity in USD. Raises DataError if the
    account isn't the expected type (e.g. a classic non-Unified account)
    or the response is missing the field -- callers should treat that as
    "balance unavailable" and omit the capital figures from a report
    rather than guess a number."""
    payload = _signed_get("/v5/account/wallet-balance", api_key, api_secret, {"accountType": account_type})
    rows = payload.get("result", {}).get("list", [])
    if not rows:
        raise DataError("Bybit wallet-balance returned no account rows")
    equity = rows[0].get("totalEquity")
    if equity in (None, ""):
        raise DataError("Bybit wallet-balance response has no totalEquity field")
    return float(equity)


# 2026-09-23: детальный баланс для Mini App (Портфель / Центр риска).
# Опциональный контракт fetch_balance() -> dict: publish_health.py
# вызывает его только если он есть у модуля биржи (hasattr), как и
# fetch_open_positions(). Все суммы в USD, None — если поле не пришло.
def fetch_balance(api_key: str, api_secret: str, passphrase: str | None = None,
                  account_type: str = "UNIFIED") -> dict:
    payload = _signed_get("/v5/account/wallet-balance", api_key, api_secret, {"accountType": account_type})
    rows = payload.get("result", {}).get("list", [])
    if not rows:
        raise DataError("Bybit wallet-balance returned no account rows")
    r = rows[0]

    def _f(key):
        v = r.get(key)
        try:
            return None if v in (None, "") else round(float(v), 2)
        except (TypeError, ValueError):
            return None

    return {
        "equity": _f("totalEquity"),
        "wallet_balance": _f("totalWalletBalance"),
        "available": _f("totalAvailableBalance"),
        "unrealized_pnl": _f("totalPerpUPL"),
        "initial_margin": _f("totalInitialMargin"),
        "maintenance_margin": _f("totalMaintenanceMargin"),
        "margin_ratio_pct": (round(float(r["accountMMRate"]) * 100, 2)
                             if r.get("accountMMRate") not in (None, "") else None),
    }


if __name__ == "__main__":
    from app.exchanges._cli import run_smoke_test
    run_smoke_test(DISPLAY_NAME, fetch_closed_trades, env_prefix="BYBIT", requires_passphrase=REQUIRES_PASSPHRASE,
                    open_positions_fn=fetch_open_positions)
