"""Fetch Bybit funding-rate and open-interest history -- public endpoints,
no API key needed. NEW data source for this project: everything tested so
far (49 ported indicators + SMC bot) is derived purely from OHLCV price
action; funding rate and open interest are crypto-derivatives-specific
signals that carry different information (positioning/crowding), not
price-derived TA.

Endpoints verified against Bybit's official v5 docs (2026-08-20):
  - https://bybit-exchange.github.io/docs/v5/market/history-fund-rate
  - https://bybit-exchange.github.io/docs/v5/market/open-interest

Funding rate history: GET /v5/market/funding/history
  params: category (linear|inverse), symbol, startTime/endTime (ms,
  optional), limit (1-200, default 200). No cursor -- paginate backward by
  decrementing `endTime` from the earliest timestamp returned, same
  pattern as generic_backtest.fetch_history's kline pagination.
  result.list[] fields: symbol, fundingRate (string), fundingRateTimestamp
  (string, ms).
  NOTE: funding interval is NOT fixed at 8h for every symbol -- Bybit
  varies it per-symbol (some run 1h/2h/4h/8h). This module does not
  assume a fixed interval; it just forward-fills whatever funding events
  actually occurred onto the kline timeline (see `align_funding_to_bars`).

Open interest history: GET /v5/market/open-interest
  params: category (linear|inverse), symbol, intervalTime (5min|15min|
  30min|1h|4h|1d, required), startTime/endTime (ms, optional), limit
  (1-200, default 50), cursor (optional, from nextPageCursor). Paginate
  backward the same way (decrement endTime) rather than using the cursor,
  for consistency with the rest of this codebase's pagination style.
  result.list[] fields: openInterest (string), timestamp (string, ms) --
  linear category may or may not populate `singleOpenInterest` (one-side
  OI); not relied on here.

Both endpoints were verified against DOCS TEXT ONLY (the sandbox that
wrote this module has no outbound network access to Bybit) -- run
`python derivatives_data.py --symbol ETHUSDT --smoke-test` on your own
machine FIRST, before trusting anything built on top of this, to confirm
field names/pagination actually behave as documented.
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

if __name__ == "__main__":
    # Allow `python app/derivatives_data.py --smoke-test` to find the `app`
    # package -- repo root, not this file's own directory, needs to be on
    # sys.path. (Running `python -m app.derivatives_data --smoke-test`
    # from the repo root works either way without this.)
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import pandas as pd
import requests

from app.data import BYBIT_BASE, DataError

INTERVAL_TIME_MAP = {
    "5m": "5min", "15m": "15min", "30m": "30min",
    "1h": "1h", "4h": "4h", "1d": "1d",
}


def _get_with_retry(path: str, params: dict, retries: int = 3, timeout: float = 15.0) -> dict:
    """Same retry-with-backoff shape as app/data.py's `_get` -- a bare
    `requests.get(...)` here would let a single transient timeout/DNS
    hiccup crash the whole multi-symbol backtest run (as happened on
    INJUSDT: a plain ReadTimeout propagated all the way up and killed the
    process instead of being caught as a DataError by
    next_gen_combo.compute_funding_oi_veto's try/except)."""
    last_exc = None
    for attempt in range(retries):
        try:
            resp = requests.get(f"{BYBIT_BASE}{path}", params=params, timeout=timeout)
            resp.raise_for_status()
            payload = resp.json()
            if payload.get("retCode") != 0:
                raise DataError(f"Bybit API error for {path}: {payload.get('retMsg')}")
            return payload
        except (requests.RequestException, DataError) as exc:
            last_exc = exc
            if attempt < retries - 1:
                time.sleep(1.5 * (attempt + 1))
    raise DataError(f"Failed to fetch {path} after {retries} attempts: {last_exc}")


def fetch_funding_rate_history(symbol: str, total_records: int = 2000,
                                category: str = "linear") -> pd.DataFrame:
    """Returns columns: funding_time (UTC tz-aware), funding_rate (float),
    sorted ascending (oldest first)."""
    all_rows: list = []
    end = None
    while len(all_rows) < total_records:
        params = {"category": category, "symbol": symbol, "limit": 200}
        if end is not None:
            params["endTime"] = end
        payload = _get_with_retry("/v5/market/funding/history", params)
        rows = payload["result"]["list"]
        if not rows:
            break
        all_rows.extend(rows)
        oldest_ts = min(int(r["fundingRateTimestamp"]) for r in rows)
        end = oldest_ts - 1
        if len(rows) < 200:
            break
        time.sleep(0.15)

    if not all_rows:
        raise DataError(f"No funding rate history returned for {symbol}")

    df = pd.DataFrame(all_rows)
    df["funding_time"] = pd.to_datetime(df["fundingRateTimestamp"].astype("int64"), unit="ms", utc=True)
    df["funding_rate"] = df["fundingRate"].astype(float)
    df = df.drop_duplicates(subset="funding_time").sort_values("funding_time").reset_index(drop=True)
    return df[["funding_time", "funding_rate"]]


def fetch_open_interest_history(symbol: str, timeframe: str, total_records: int = 2000,
                                 category: str = "linear") -> pd.DataFrame:
    """Returns columns: oi_time (UTC tz-aware), open_interest (float),
    sorted ascending (oldest first). `timeframe` is one of this project's
    own labels (e.g. "15m"), mapped to Bybit's intervalTime values."""
    interval_time = INTERVAL_TIME_MAP.get(timeframe)
    if interval_time is None:
        raise ValueError(f"No open-interest intervalTime mapping for timeframe {timeframe!r}; "
                          f"choose from {sorted(INTERVAL_TIME_MAP)}")

    all_rows: list = []
    end = None
    while len(all_rows) < total_records:
        params = {"category": category, "symbol": symbol, "intervalTime": interval_time, "limit": 200}
        if end is not None:
            params["endTime"] = end
        payload = _get_with_retry("/v5/market/open-interest", params)
        rows = payload["result"]["list"]
        if not rows:
            break
        all_rows.extend(rows)
        oldest_ts = min(int(r["timestamp"]) for r in rows)
        end = oldest_ts - 1
        if len(rows) < 200:
            break
        time.sleep(0.15)

    if not all_rows:
        raise DataError(f"No open interest history returned for {symbol}")

    df = pd.DataFrame(all_rows)
    df["oi_time"] = pd.to_datetime(df["timestamp"].astype("int64"), unit="ms", utc=True)
    df["open_interest"] = df["openInterest"].astype(float)
    df = df.drop_duplicates(subset="oi_time").sort_values("oi_time").reset_index(drop=True)
    return df[["oi_time", "open_interest"]]


def align_funding_to_bars(kline_df: pd.DataFrame, funding_df: pd.DataFrame) -> pd.Series:
    """Forward-fills the most recent known funding rate onto each kline
    bar's open_time (no lookahead -- a bar only ever sees funding events
    that have already occurred at or before its own open_time)."""
    merged = pd.merge_asof(
        kline_df[["open_time"]].sort_values("open_time"),
        funding_df.sort_values("funding_time"),
        left_on="open_time", right_on="funding_time", direction="backward",
    )
    return merged["funding_rate"]


def align_oi_to_bars(kline_df: pd.DataFrame, oi_df: pd.DataFrame) -> pd.Series:
    """Same no-lookahead forward-fill, for open interest."""
    merged = pd.merge_asof(
        kline_df[["open_time"]].sort_values("open_time"),
        oi_df.sort_values("oi_time"),
        left_on="open_time", right_on="oi_time", direction="backward",
    )
    return merged["open_interest"]


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--symbol", default="ETHUSDT")
    parser.add_argument("--timeframe", default="15m")
    parser.add_argument("--smoke-test", action="store_true",
                         help="Fetch a small sample of both endpoints and print the raw shape -- "
                              "run this FIRST to confirm the endpoints behave as documented.")
    args = parser.parse_args()

    if not args.smoke_test:
        parser.error("This module is a library; run with --smoke-test to sanity-check the endpoints.")

    print(f"Fetching funding rate history for {args.symbol}...")
    fr = fetch_funding_rate_history(args.symbol, total_records=20)
    print(fr.tail(10))
    print(f"\n{len(fr)} rows, {fr['funding_time'].min()} .. {fr['funding_time'].max()}")

    print(f"\nFetching open interest history for {args.symbol} ({args.timeframe})...")
    oi = fetch_open_interest_history(args.symbol, args.timeframe, total_records=20)
    print(oi.tail(10))
    print(f"\n{len(oi)} rows, {oi['oi_time'].min()} .. {oi['oi_time'].max()}")
