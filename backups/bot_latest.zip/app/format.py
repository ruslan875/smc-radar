"""
Builds the Telegram caption text, mirroring the layout of the reference
"Адаптивная стратегия" cards: direction header, entry/SL, three R-multiple
take-profits, a "nearest swing" take, then volume/volatility/BTC-correlation
stats.
"""
from __future__ import annotations

from datetime import datetime, timezone


def pct(from_price: float, to_price: float, direction: str) -> float:
    """Signed % move from `from_price` to `to_price`, positive = profit
    in the trade's direction."""
    raw = (to_price - from_price) / from_price * 100
    return raw if direction == "long" else -raw


def build_caption(
    *,
    symbol_label: str,
    timeframe: str,
    direction: str,  # "long" | "short"
    entry: float,
    stop_loss: float,
    take_profits: list[tuple[float, float]],  # [(price, pct), ...] already signed
    nearest_target: float | None,
    nearest_target_pct: float | None,
    daily_volume_str: str,
    average_volume_str: str,
    volatility_pct: float,
    btc_correlation: float,
    setup_label: str = "",
    htf_label: str = "",
    strategy_name: str = "Адаптивная",
    strategy_tag: str = "#Стратегия1",
    exchange: str = "BYBIT",
    tradingview_url: str = "https://www.tradingview.com",
    when: datetime | None = None,
) -> str:
    when = when or datetime.now(timezone.utc)
    dir_ru = "Лонг" if direction == "long" else "Шорт"
    dot = "🟢" if direction == "long" else "🔴"
    sl_pct = pct(entry, stop_loss, direction)

    lines = []
    lines.append(f"{dot} <b>#{symbol_label}</b> в {dir_ru} ({timeframe}).")
    lines.append(f"🕐 {when.strftime('%H:%M %d.%m.%Y')} UTC")
    lines.append(f"«{strategy_name}» {strategy_tag}")
    if setup_label:
        lines.append(f"Сетап: {setup_label}")
    if htf_label:
        lines.append(f"Старший ТФ: {htf_label}")
    lines.append("")
    lines.append(f"Вход: <b>{entry:g}</b>")
    lines.append(f"Стоплосс: <b>{stop_loss:g}</b>    {sl_pct:+.4f}%")
    lines.append("Тейкпрофиты с риском 1/1, 1/2 и 1/3:")
    for price, p in take_profits:
        lines.append(f"<code>{price:g}</code>    {p:+.4f}%")
    if nearest_target is not None:
        lines.append("Или Тейк за ближайший экстремум:")
        lines.append(f"<code>{nearest_target:g}</code>    {nearest_target_pct:+.4f}%")
    lines.append("")
    lines.append(f"Дневной объём: {daily_volume_str}")
    lines.append(f"Средний объём: {average_volume_str}")
    lines.append(f"Волатильность: {volatility_pct:.2f}%")
    if btc_correlation == btc_correlation:  # not NaN
        lines.append(f"Корреляция с BTC: {btc_correlation:.2f}")
    lines.append("")
    lines.append(f'Биржа {exchange}: <a href="{tradingview_url}">TradingView</a>')
    lines.append("")
    lines.append("⚠️ Не является финансовой рекомендацией. Решение и риски — ваши.")
    return "\n".join(lines)
