"""
2026-08-24, round 10: an optional AI-explanation/chat/idea layer, built on
top of everything the bot already computes (health.json's numbers, the
journal, the detector's own armed-zones/recent-signals state) rather than
replacing any of it. Scoped via `AskUserQuestion` after the user asked to
"add AI" to the "Вера"-style assistant (round 9) -- the user picked all
three offered pieces (plain-language explanations of existing
signals/reports, a free-form chat grounded in their own data, AND a new
experimental entry-idea generator), and picked "advisory-only, never
auto-executed" for what happens if the AI suggests an idea -- same
scope-narrowing precedent already established for round 9's
partial-take-profit advisory.

Talks to Anthropic's Messages API directly via `requests` -- same
"raw HTTP, no SDK" style every app/exchanges/*.py module in this project
already uses, rather than adding a new `anthropic` package dependency.
One new credential, resolved the same two-tier way every exchange key in
this project already works: a static `.env` fallback
(`Settings.anthropic_api_key`, `ANTHROPIC_API_KEY`) and a dynamically-
added one via `/setaikey` in the bot's own chat (`app/ai_key_store.py`,
`AiKeyStore`) that wins on collision and needs no restart -- see
`resolve_api_key()` below. Every function in this module is a graceful
no-op (returns `None`, never raises) when no key is configured, so the
rest of the bot behaves exactly as it did before round 10 if the owner
never sets one up.

**Why this is advisory-text-only, never wired into any trading action**:
an LLM can be confidently wrong, and this project already has two
exchange-writing features (`/trade`, round 8; the breakeven-autopilot,
round 9) that place or move real money on an EXPLICIT, narrow,
deterministic rule. Feeding an LLM's own free-text output into either of
those -- even indirectly, even just as one more input to a human's
decision inside `/trade`'s signal-gate -- was deliberately NOT built here.
Every function below only ever returns text for a Telegram message; none
of it is called from `_autopilot_worker` or `_handle_trade_command`.

**Cost discipline**: every function here is called ONLY on-demand, from a
Telegram command handler (`/ai`, `/aiidea`, or the optional AI paragraph
on `/report`/`/ideas`) -- NEVER from a poll loop. LLM calls cost real
money per call; running one on a 15-30s poll cadence the way
psycho-alerts or autopilot do would rack up unbounded spend for
something the owner may not even be reading. If a scheduled/automatic AI
digest is ever wanted, that needs its own explicit opt-in setting and a
cost conversation with the user first, not silent reuse of an existing
fast poll.

**2026-08-31 update**: that "no scheduled digest" line held until the
user explicitly asked for exactly that (after seeing a ByTrader
screenshot with an automatic end-of-day report) and was told up front it
costs one extra API call per day, via `AskUserQuestion` -- see
`daily_digest()` below and main.py's `_daily_report_worker`. This is
still bounded (a sleep-until-next-scheduled-time loop, not a fast poll)
and still opt-in-by-construction (main.py only starts that thread in the
normal forever-loop mode, same as every other background worker), so the
spirit of this section holds: no function here runs on a fast poll
cadence, this one just runs once a day instead of only on request.

**Disclaimer discipline**: every AI-generated string returned by this
module already has DISCLAIMER appended by the functions below, so
callers don't have to remember to add it -- but callers (main.py) should
still NOT blindly HTML-parse this text into a `parse_mode="HTML"`
Telegram message without escaping it first (the model's own output isn't
guaranteed to be free of stray "<"/"&" characters, e.g. someone asking
"why did BTCUSDT go below $60k" could get a reply containing a literal
"<" from arithmetic phrasing) -- see main.py's `_ai_escape()` helper,
used everywhere this module's return value is interpolated into an HTML
message.
"""
from __future__ import annotations

import json
import math
import sys

import requests

from app.ai_key_store import AiKeyStore
from app.config import AI_KEY_FILE, Settings

ANTHROPIC_VERSION = "2023-06-01"
DEFAULT_MAX_TOKENS = 700
REQUEST_TIMEOUT_SECONDS = 30

DISCLAIMER = (
    "\n\n⚠️ Это текст от ИИ-модели (эксперимент), а не финансовый совет и не гарантия результата. "
    "ИИ может ошибаться или упускать важное -- решения и ответственность всегда твои."
)

# Shared framing every AI call gets, on top of each function's own
# task-specific instructions below -- the single place that enforces "no
# confident price predictions" at the prompt level (DISCLAIMER above is
# the actual hard enforcement; this is the softer, first line of defense).
_BASE_SYSTEM_PREAMBLE = (
    "Ты - вспомогательный текстовый модуль внутри крипто-трейдинг бота пользователя. "
    "Отвечай по-русски, кратко (не больше 5-6 предложений), разговорным языком, без markdown-разметки. "
    "НИКОГДА не давай уверенных прогнозов цены и не обещай результат сделки -- используй осторожные "
    "формулировки ('может', 'стоит учитывать', 'один из сценариев'). Ты не финансовый советник. "
    "Используй ТОЛЬКО данные, которые тебе передали в сообщении -- никогда не придумывай цифры, "
    "сделки или цены, которых там нет. Если данных не хватает, чтобы ответить, так и скажи."
)


def resolve_api_key(settings: Settings) -> str:
    """Dynamically-added key (via /setaikey) wins on collision, same
    precedent as ExchangeKeysStore/TradeKeysStore -- falls back to the
    static .env value, empty string if neither is set (callers treat that
    as "AI features not configured")."""
    dynamic = AiKeyStore(AI_KEY_FILE).get_key()
    return dynamic or settings.anthropic_api_key


def _call_ai(system_prompt: str, user_prompt: str, settings: Settings,
             max_tokens: int = DEFAULT_MAX_TOKENS) -> str | None:
    """Raw POST to Anthropic's Messages API (or an Anthropic-API-compatible
    reseller/proxy, if `settings.ai_base_url` has been pointed at one --
    see that field's own docstring in app/config.py; this was added
    2026-08-25, round 16 follow-up #2, after a real key from exactly such
    a reseller kept failing against the hardcoded real Anthropic host).
    Returns the model's text, or None on ANY failure (missing key,
    network error, non-2xx response, unexpected payload shape) --
    callers must treat None as "AI unavailable right now" and degrade
    gracefully, never crash a Telegram command over this."""
    api_key = resolve_api_key(settings)
    if not api_key:
        return None
    api_url = f"{settings.ai_base_url}/v1/messages"
    try:
        resp = requests.post(
            api_url,
            headers={
                "x-api-key": api_key,
                "anthropic-version": ANTHROPIC_VERSION,
                "content-type": "application/json",
            },
            json={
                "model": settings.ai_model,
                "max_tokens": max_tokens,
                "system": system_prompt,
                "messages": [{"role": "user", "content": user_prompt}],
            },
            timeout=REQUEST_TIMEOUT_SECONDS,
        )
        if resp.status_code != 200:
            print(f"[AI] Anthropic API error {resp.status_code}: {resp.text[:500]}", file=sys.stderr)
            return None
        payload = resp.json()
        content = payload.get("content") or []
        text_parts = [block.get("text", "") for block in content if block.get("type") == "text"]
        text = "".join(text_parts).strip()
        return text or None
    except requests.RequestException as exc:
        print(f"[AI] request to Anthropic failed: {exc}", file=sys.stderr)
        return None
    except (ValueError, KeyError, TypeError) as exc:
        print(f"[AI] couldn't parse Anthropic response: {exc}", file=sys.stderr)
        return None


def explain_report(report_text: str, settings: Settings) -> str | None:
    """Plain-language paragraph summarizing the SAME numbers /report
    already sent as raw lines -- doesn't compute anything new, doesn't see
    anything /report itself didn't already show the owner."""
    system_prompt = (
        _BASE_SYSTEM_PREAMBLE
        + " Тебе присылают отчёт по торговой дисциплине (риск-бюджет, серия убытков, открытые позиции). "
        "Перескажи его простыми словами, как будто объясняешь другу -- что хорошо, на что стоит обратить "
        "внимание. Не повторяй все цифры дословно, выбери 2-3 самых важных момента."
    )
    text = _call_ai(system_prompt, f"Вот отчёт:\n\n{report_text}", settings)
    return (text + DISCLAIMER) if text else None


def daily_digest(stats_text: str, settings: Settings) -> str | None:
    """Proactive end-of-day AI commentary -- the ONE deliberate exception
    to this module's "on-demand only, never from a poll loop" cost
    discipline (see module docstring above). Added 2026-08-31 after the
    user explicitly opted in via `AskUserQuestion` -- told up front this
    costs one extra Anthropic API call per day -- to a ByTrader-style
    automatic daily report (the user showed a screenshot of that app's
    "Вера" assistant sending an unprompted end-of-day digest with
    structured sections and asked why this bot didn't). Still costs only
    ONE call per calendar day (main.py's `_daily_report_worker` sleeps
    until the next scheduled time, never polls), so the existing cost
    discipline is preserved in spirit: still bounded, still not a fast
    loop, just no longer purely on-demand.

    Same "use ONLY the numbers given, no invented trades/prices, no
    confident predictions" discipline as every other function here --
    `stats_text` is plain text built by main.py from the SAME
    fetch_closed_trades/fetch_open_positions/get_wallet_balance data the
    rest of the bot already uses, not new analysis of its own."""
    system_prompt = (
        _BASE_SYSTEM_PREAMBLE
        + " Тебе присылают сводку торговой активности пользователя за прошедшие сутки (P&L, число сделок, "
        "win rate, открытые позиции, капитал). Дай короткий структурированный разбор СТРОГО в таком "
        "формате, с этими же заголовками и порядком:\n\n"
        "1) Финансовые инсайты:\n- ...\n\n2) Оценка рисков:\n- ...\n\n3) Поведенческие паттерны:\n- ...\n\n"
        "4) Рекомендации:\n- ...\n\n5) Резюме:\n...\n\nУрок дня: <одно предложение — главный вывод для памяти>\n\n"
        "В данных есть блок «МОЗГ ТРЕЙДЕРА» (правила и прошлые уроки владельца) и челлендж Hash Hedge: сверяй день с правилами, "
        "прямо называй нарушения (объём больше сигнала, торговля после стопа дня, ручное закрытие, вход не по сигналу). "
        "Каждый раздел -- 2-3 коротких пункта или предложения (кроме Резюме -- 1-2 предложения). Если "
        "сделок за день не было, честно скажи об этом в п.1 и не выдумывай активность, которой не было. "
        "Раздел 3 (поведенческие паттерны) делай осторожным и общим, если данных за один день откровенно "
        "мало для вывода о паттерне -- не делай далеко идущих заключений из одного дня наблюдений."
    )
    text = _call_ai(system_prompt, f"Сводка за сутки:\n\n{stats_text}", settings, max_tokens=1100)
    return (text + DISCLAIMER) if text else None


def explain_ideas(ideas_text: str, settings: Settings) -> str | None:
    """Plain-language paragraph summarizing /ideas' existing digest
    (armed zones + recently-fired signals from the validated detector) --
    same "reuse what's already there, add zero new analysis" discipline
    as /ideas itself."""
    system_prompt = (
        _BASE_SYSTEM_PREAMBLE
        + " Тебе присылают список того, что сейчас отслеживает торговый бот пользователя (заряженные зоны "
        "ожидания реакции + недавно сработавшие сигналы проверенного детектора структуры рынка). Объясни "
        "простыми словами, что это значит, без новых догадок о будущем движении цены -- только пересказ "
        "того, что уже есть в данных."
    )
    text = _call_ai(system_prompt, f"Вот список:\n\n{ideas_text}", settings)
    return (text + DISCLAIMER) if text else None


def answer_question(question: str, context_bundle: str, settings: Settings) -> str | None:
    """Free-form chat grounded in the user's own data (health/journal/
    detector state) -- the `/ai <question>` command. `context_bundle` is
    plain text built by main.py from the SAME sources /report and /ideas
    already use; the model is instructed (in _BASE_SYSTEM_PREAMBLE) to
    only use what's in that bundle and say so when it doesn't have
    enough."""
    system_prompt = (
        _BASE_SYSTEM_PREAMBLE
        + " Тебе передают срез данных о торговле пользователя (риск-бюджеты, сделки, что сейчас отслеживает "
        "детектор, а также «МОЗГ ТРЕЙДЕРА» — правила владельца и уроки прошлых ошибок, челлендж Hash Hedge, сигналы "
        "пробоя канала, бумажные боты) и его вопрос. Ответь, используя только эти данные; опирайся на правила и уроки, "
        "напоминай о них, если вопрос их касается. Не прогнозируй цену и не советуй сделки вне правил."
    )
    user_prompt = f"Данные:\n\n{context_bundle}\n\nВопрос пользователя: {question}"
    text = _call_ai(system_prompt, user_prompt, settings)
    return (text + DISCLAIMER) if text else None


def build_market_context(df, timeframe: str, current_price: float) -> str:
    """Real, already-fetched OHLCV summary used as the ACTUAL market context
    passed to the AI for /aiidea and /aichart -- added 2026-09-06 after the
    user reported both commands were nearly useless ("толку от Веры нет"):
    both handlers were previously only ever passing a single current-price
    number as `market_context`, no historical price action at all, which is
    almost certainly why the model so often had to answer insufficient_data
    (see generate_chart_annotation's contract above) or produced numbers that
    failed `_validate_chart_annotation`'s sanity checks -- there was
    genuinely nothing to reason from. This gives the model a compact but
    real summary of recent price action instead: range, % change, a crude
    volatility measure, volume vs. its own recent average, and a short list
    of recent closes. Deliberately NOT a full OHLCV dump (token budget, and
    a wall of numbers invites overfitting noise) -- this is a summary, not
    the raw series.

    `df` is the same klines DataFrame `app.data.get_klines()` already
    returns (columns: open, high, low, close, volume, turnover) -- callers
    already fetch this to draw/inspect the chart, so this is free reuse, not
    an extra API call."""
    if df is None or len(df) == 0:
        return f"Текущая цена: {current_price:g}. (Исторические свечи недоступны.)"
    window = df.tail(60)
    highs, lows, closes, vols = window["high"], window["low"], window["close"], window["volume"]
    period_high = float(highs.max())
    period_low = float(lows.min())
    first_close = float(closes.iloc[0])
    last_close = float(closes.iloc[-1])
    pct_change = (last_close / first_close - 1.0) * 100.0 if first_close else 0.0
    avg_range_pct = float(((highs - lows) / closes.replace(0, float("nan"))).mean() * 100.0)
    avg_vol = float(vols.mean())
    last_vol = float(vols.iloc[-1])
    vol_ratio = (last_vol / avg_vol) if avg_vol else 1.0
    recent_n = min(12, len(closes))
    recent_closes = ", ".join(f"{c:g}" for c in closes.tail(recent_n))
    return "\n".join([
        f"Текущая цена: {current_price:g}.",
        f"Таймфрейм свечей: {timeframe}, окно {len(window)} свечей.",
        f"Диапазон за окно: {period_low:g} - {period_high:g}.",
        f"Изменение цены за окно: {pct_change:+.2f}%.",
        f"Средний размах свечи (волатильность): {avg_range_pct:.2f}% от цены закрытия.",
        f"Объём последней свечи: {last_vol:.0f} ({vol_ratio:.2f}x от среднего объёма за окно).",
        f"Последние {recent_n} закрытий, от старых к новым: {recent_closes}.",
    ])


def generate_entry_idea(symbol: str, market_context: str, settings: Settings) -> str | None:
    """EXPERIMENTAL, clearly-labeled hypothesis for one symbol -- the
    `/aiidea <symbol>` command. Deliberately separate from `app/smc.py`'s
    (now-retired) CHoCH+OB+FVG detector (see the project doc's "Deliberate
    scope boundary" section): this function's output never feeds into any
    detector state, is never used by `/trade`'s signal-gate, and is
    ALWAYS advisory-only text in Telegram -- per the user's own choice
    when this was scoped (same "advisory in Telegram, never auto-acted
    on" precedent as round 9's partial-take-profit suggestion).

    2026-09-06: `market_context` is now expected to be a real OHLCV summary
    (see `build_market_context` above), not just a current-price line --
    the system prompt below was updated to match what's actually sent."""
    system_prompt = (
        _BASE_SYSTEM_PREAMBLE
        + " Тебе передают текущую цену монеты и сводку по недавним свечам (диапазон, % изменения, объём, "
        "последние закрытия). Опиши ОДИН возможный сценарий развития (не прогноз, а гипотезу) -- на что стоит "
        "обратить внимание, какой уровень мог бы быть важен. Явно скажи, что это не готовая сделка, а просто "
        "идея для дальнейшего собственного анализа. Если данных откровенно мало для какой-либо гипотезы, "
        "честно скажи, что сказать нечего, вместо того чтобы что-то придумывать."
    )
    user_prompt = f"Монета: {symbol}\n\nДанные:\n\n{market_context}"
    text = _call_ai(system_prompt, user_prompt, settings)
    return (text + DISCLAIMER) if text else None


# ---------------------------------------------------------------------------
# 2026-09-07: advisory-only comparison of windows_app's own two live/paper
# strategies (latuserge, kc_roc) -- the owner asked for a ByTrader/"Вера"
# -style AI auto-strategy-picker on the panel after seeing that competitor's
# marketing. Scoped down via AskUserQuestion to the SAME "advisory text
# only, human clicks the actual switch" precedent as every other function in
# this module: the model gets ONLY the two strategies' already-computed real
# numbers (windows_app/server.py's own _history/_open_positions/_market_overview
# -- the exact figures already shown on "Обзор"), compares them in prose, and
# is NEVER wired to actually start/stop a strategy or touch LIVE mode --
# switching which strategy is live stays behind process_supervisor.py's
# existing manual confirm-checkbox flow. An LLM's own text isn't backtested
# the way the strategies themselves are (see this module's own docstring:
# "an LLM can be confidently wrong"), so it doesn't get to move real capital
# on its own, no matter how it's branded. Called ONLY on a manual "Обновить"
# button click in the panel (see windows_app/server.py's _ai_advice) -- same
# cost discipline as every other on-demand function here, never a poll loop.
# ---------------------------------------------------------------------------


def advise_strategy_pick(context: str, settings: Settings) -> str | None:
    """Compares the panel's own strategies using ONLY the real stats/positions/
    market data passed in `context` (built by windows_app/server.py's
    _ai_context() from the same endpoints "Обзор" already reads) -- returns
    plain Russian text for the panel to display, or None if no key is
    configured or the call fails (see _call_ai's contract). Never returns
    trade signals or price predictions -- only a comparison of the two
    strategies' own track records."""
    system_prompt = (
        _BASE_SYSTEM_PREAMBLE
        + " Тебе передают статистику по двум автоматическим торговым стратегиям пользователя (число "
        "закрытых сделок, win-rate, суммарный и средний P&L, profit factor, текущие открытые позиции) и "
        "краткий обзор цен по их торгуемым монетам. Сравни стратегии МЕЖДУ СОБОЙ строго по этим цифрам -- "
        "какая сейчас статистически выглядит лучше и почему, есть ли настораживающие моменты (слишком мало "
        "сделок для выводов, просадка, profit factor ниже 1). Явно скажи, если данных откровенно мало "
        "(например, 0-2 сделки у обеих), чтобы делать выводы -- не притворяйся уверенным при таком объёме "
        "данных. НЕ предлагай конкретных новых сделок, точек входа или сигналов -- только сравнение "
        "эффективности САМИХ стратегий по их собственной истории."
    )
    text = _call_ai(system_prompt, f"Данные:\n\n{context}", settings, max_tokens=500)
    return (text + DISCLAIMER) if text else None


# ---------------------------------------------------------------------------
# 2026-08-26/29, round 18: chart-annotation hypothesis for /aichart.
#
# This is the FIRST time this project lets an LLM's own generated price
# levels get drawn onto an image instead of staying as hedged Telegram
# prose (see the project doc's round-18 write-up for the full scoping --
# the user asked for "entry/take/stop + support/resistance marked on the
# chart"; the non-negotiable answer was to ALWAYS show the bot's own real,
# already-computed zones/levels as the base layer, plus a separately and
# clearly labeled EXPERIMENTAL AI layer on the same image). Because a
# drawn number is far more "authoritative-looking" than a sentence of
# prose, and because a chart image can be screenshotted/forwarded with its
# caption stripped off, this function's contract is much stricter than
# every other function above:
#
#   1. The model is required to answer with ONLY a JSON object (no prose,
#      no markdown fences) -- see _CHART_ANNOTATION_SYSTEM_PROMPT below.
#   2. The response is parsed defensively: broken JSON -> None. This
#      module NEVER raises out of this function.
#   3. The model must self-report `insufficient_data` -- true means "don't
#      have enough to say anything," and this function returns None in
#      that case even if other fields are also (perhaps confidently)
#      filled in. A model that hallucinates numbers while ALSO claiming
#      insufficient data is still refused, on purpose.
#   4. Every numeric field is validated to actually be a finite real
#      number (rejects inf/nan/strings/bools/missing), the stop-loss (and,
#      for good measure, the take-profit) must sit on the geometrically
#      correct side of the entry for the stated direction, and every level
#      must be within a sane order-of-magnitude band of the real current
#      price (0.2x-5x) so a hallucinated wildly-off number (wrong decimal
#      place, wrong symbol, stale training-data price) can never silently
#      reach the chart-drawing code.
#
# Returning None here must NEVER be treated as an error the caller should
# retry or complain loudly about -- it's the intended, safe outcome for
# "the model didn't give us something trustworthy enough to draw," and
# main.py's /aichart handler falls back to a chart with only the bot's own
# real zones/levels plus a plain-text note when this returns None.
# ---------------------------------------------------------------------------

_SR_MAX_ITEMS = 8
_LEVEL_MIN_RATIO = 0.2  # a validated level must be within [0.2x, 5x] of the
_LEVEL_MAX_RATIO = 5.0  # real current price -- catches a wildly-off hallucination.

_CHART_ANNOTATION_SYSTEM_PROMPT = (
    _BASE_SYSTEM_PREAMBLE
    + " Тебе передают монету, её текущую реальную цену и сводку по недавним свечам (диапазон, % изменения, "
    "объём, последние закрытия). Твоя задача -- предложить ОДНУ гипотезу разметки графика: точку "
    "входа, стоп-лосс, тейк-профит и несколько уровней поддержки/сопротивления. Это ЭКСПЕРИМЕНТ и НЕ "
    "торговый сигнал -- явно скажи об этом в поле note.\n\n"
    "ОТВЕЧАЙ СТРОГО ОДНИМ JSON-ОБЪЕКТОМ И БОЛЬШЕ НИЧЕМ -- без markdown-разметки, без ``` оград, без текста "
    "до или после JSON. Формат ровно такой:\n"
    '{"insufficient_data": true/false, "direction": "long"/"short", "entry": число, "stop_loss": число, '
    '"take_profit": число, "support_resistance": [{"price": число, "kind": "support"/"resistance", '
    '"label": "короткая подпись"}], "note": "1-2 коротких предложения"}\n\n'
    "Если данных откровенно мало, чтобы предложить осмысленную гипотезу, поставь insufficient_data=true и "
    "можешь оставить числовые поля null -- НЕ придумывай цифры в этом случае. Если insufficient_data=false, "
    "все числовые поля (entry, stop_loss, take_profit) обязаны быть реальными числами, разумно близкими к "
    "переданной текущей цене, а stop_loss и take_profit обязаны быть на правильной стороне от entry для "
    "указанного direction (для long: stop_loss < entry < take_profit; для short: stop_loss > entry > "
    "take_profit)."
)


def _finite_number(value: object) -> bool:
    """True only for an actual int/float that is finite (rejects bool --
    Python's bool is a subclass of int, and `True`/`False` sneaking through
    as 1/0 would be a silent, confusing corruption of a price level -- as
    well as inf/nan/strings/None/missing)."""
    if isinstance(value, bool):
        return False
    if not isinstance(value, (int, float)):
        return False
    return math.isfinite(value)


def _validate_price_level(value: object, current_price: float) -> float | None:
    if not _finite_number(value):
        return None
    price = float(value)
    if price <= 0 or not _finite_number(current_price) or current_price <= 0:
        return None
    ratio = price / current_price
    if not (_LEVEL_MIN_RATIO <= ratio <= _LEVEL_MAX_RATIO):
        return None
    return price


def _validate_chart_annotation(data: object, current_price: float) -> dict | None:
    """Defensive validation of one parsed JSON annotation -- returns a
    clean dict on success, or None on ANY problem whatsoever (never
    raises). See this section's module-level comment above for the full
    rationale behind each check. Order matters a little for clarity but
    not for correctness -- every check is independent and short-circuits
    to None on its own."""
    try:
        if not isinstance(data, dict):
            return None

        insufficient = data.get("insufficient_data")
        if not isinstance(insufficient, bool):
            return None
        if insufficient:
            # The model itself says it doesn't have enough -- honor that
            # even if other fields also look populated (a model that
            # hedges AND hallucinates numbers is still refused).
            return None

        direction = data.get("direction")
        if direction not in ("long", "short"):
            return None

        entry = _validate_price_level(data.get("entry"), current_price)
        stop_loss = _validate_price_level(data.get("stop_loss"), current_price)
        take_profit = _validate_price_level(data.get("take_profit"), current_price)
        if entry is None or stop_loss is None or take_profit is None:
            return None

        # Correct-side check -- the one explicitly required by this
        # feature's safety design, extended to take_profit too since a
        # take-profit on the wrong side of entry is equally nonsensical to
        # draw. A long's stop must sit below entry and its take above; a
        # short is the mirror image.
        if direction == "long":
            if not (stop_loss < entry < take_profit):
                return None
        else:
            if not (stop_loss > entry > take_profit):
                return None

        sr_raw = data.get("support_resistance")
        sr_validated: list[dict] = []
        if sr_raw is not None:
            if not isinstance(sr_raw, list):
                return None
            for item in sr_raw[:_SR_MAX_ITEMS]:
                if not isinstance(item, dict):
                    continue
                price = _validate_price_level(item.get("price"), current_price)
                if price is None:
                    continue
                kind = item.get("kind")
                if kind not in ("support", "resistance"):
                    # Don't reject the whole level over a bad label --
                    # infer a reasonable kind from where it sits relative
                    # to price instead, this is cosmetic, not a safety field.
                    kind = "support" if price < current_price else "resistance"
                label = item.get("label")
                label = label.strip()[:40] if isinstance(label, str) else ""
                sr_validated.append({"price": price, "kind": kind, "label": label})

        note = data.get("note")
        note = note.strip()[:300] if isinstance(note, str) else ""

        return {
            "direction": direction,
            "entry": entry,
            "stop_loss": stop_loss,
            "take_profit": take_profit,
            "support_resistance": sr_validated,
            "note": note,
        }
    except Exception:
        # Belt-and-suspenders: this function must NEVER raise, no matter
        # how malformed the input is -- a validation bug here must fail
        # closed (nothing drawn), never crash the /aichart command.
        return None


def generate_chart_annotation(symbol: str, market_context: str, current_price: float,
                               settings: Settings) -> dict | None:
    """EXPERIMENTAL chart-annotation hypothesis for `/aichart <symbol>` --
    see this module's round-18 comment block above for the full safety
    contract. Returns a validated dict
    ({direction, entry, stop_loss, take_profit, support_resistance, note})
    on success, or None on ANY failure: no key configured, the network/API
    call itself failing (see _call_ai), a non-JSON or malformed-JSON
    response, `insufficient_data: true`, or any single validation check
    failing. None is the safe, expected outcome for "don't draw anything
    AI-generated this time" -- callers must fall back to a real-zones-only
    chart, never block or corrupt that real layer over this."""
    if not _finite_number(current_price) or current_price <= 0:
        return None
    user_prompt = f"Монета: {symbol}\nТекущая цена: {current_price:g}\n\nДанные:\n\n{market_context}"
    text = _call_ai(_CHART_ANNOTATION_SYSTEM_PROMPT, user_prompt, settings, max_tokens=500)
    if not text:
        return None

    cleaned = text.strip()
    if cleaned.startswith("```"):
        # The system prompt explicitly forbids markdown fences, but models
        # don't always follow instructions perfectly -- strip a fence
        # defensively rather than fail on an otherwise-good response.
        cleaned = cleaned.strip("`").strip()
        if cleaned.lower().startswith("json"):
            cleaned = cleaned[4:].strip()

    try:
        data = json.loads(cleaned)
    except (ValueError, TypeError) as exc:
        print(f"[AI] /aichart: couldn't parse JSON annotation: {exc}", file=sys.stderr)
        return None

    return _validate_chart_annotation(data, current_price)
