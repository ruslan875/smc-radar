"""app/bybit_demo.py — 2026-10-25. Минимальный клиент ДЕМО-счёта Bybit (api-demo.bybit.com) для панели.
Адрес зашит — реальный счёт этим модулем недоступен. Ключ — из слота bybit_demo (save_demo_key.bat).
Подпись заново на каждую попытку, поправка часов по серверу, повторы при обрывах (связь через VPN медленная)."""
from __future__ import annotations

import hashlib, hmac, json, time
from urllib.parse import urlencode

import requests

BASE = "https://api-demo.bybit.com"
RW = "30000"
_OFF = {"ms": 0, "at": 0.0}


class DemoError(Exception):
    pass


def creds() -> dict | None:
    try:
        from app.config import TRADE_KEYS_FILE
        from app.trade_keys_store import TradeKeysStore
        c = TradeKeysStore(TRADE_KEYS_FILE).get_for_strategy("bybit_demo", "bybit")
        return c if c and c.get("api_key") else None
    except Exception:  # noqa: BLE001
        return None


def _sync() -> None:
    if time.time() - _OFF["at"] < 300:
        return
    try:
        t0 = time.time(); r = requests.get(f"{BASE}/v5/market/time", timeout=20).json(); t1 = time.time()
        srv = int(r.get("time") or int(r["result"]["timeNano"]) // 1_000_000)
        _OFF["ms"] = srv - int((t0 + t1) / 2 * 1000)
    except Exception:  # noqa: BLE001
        pass
    _OFF["at"] = time.time()


def call(c: dict, method: str, path: str, params: dict | None = None, tries: int = 4) -> dict:
    params = params or {}
    if method == "GET":
        payload = urlencode(params); url, body = f"{BASE}{path}" + (f"?{payload}" if payload else ""), None
    else:
        payload = json.dumps(params, separators=(",", ":")); url, body = f"{BASE}{path}", payload
    _sync()
    last: Exception | None = None
    for a in range(tries):
        ts = str(int(time.time() * 1000) + _OFF["ms"])
        sig = hmac.new(c["api_secret"].encode(), (ts + c["api_key"] + RW + payload).encode(), hashlib.sha256).hexdigest()
        h = {"X-BAPI-API-KEY": c["api_key"], "X-BAPI-SIGN": sig, "X-BAPI-TIMESTAMP": ts, "X-BAPI-RECV-WINDOW": RW,
             "Content-Type": "application/json"}
        try:
            r = requests.request(method, url, headers=h, data=body, timeout=30).json()
        except (requests.RequestException, ValueError) as e:
            last = e; time.sleep(2 * (a + 1)); continue
        if r.get("retCode") == 10002:
            _OFF["at"] = 0; _sync(); continue
        if r.get("retCode") != 0:
            raise DemoError(f"{path}: {r.get('retCode')} {r.get('retMsg')}")
        return r.get("result") or {}
    raise DemoError(f"нет связи с Bybit Demo ({type(last).__name__ if last else 'время'})")


def positions(c: dict) -> list[dict]:
    lst = call(c, "GET", "/v5/position/list", {"category": "linear", "settleCoin": "USDT"}).get("list") or []
    return [p for p in lst if float(p.get("size") or 0) > 0]


def instrument(symbol: str) -> dict:
    r = requests.get("https://api.bybit.com/v5/market/instruments-info", params={"category": "linear", "symbol": symbol},
                     timeout=20).json()
    it = (r.get("result") or {}).get("list") or []
    if not it:
        raise DemoError(f"нет инструмента {symbol}")
    lf = it[0]["lotSizeFilter"]
    return {"step": float(lf["qtyStep"]), "min": float(lf["minOrderQty"]), "tick": float(it[0]["priceFilter"]["tickSize"])}
