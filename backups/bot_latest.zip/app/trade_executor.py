"""
The one and only place a real order actually gets placed, 2026-08-25
round 14 -- extracted out of main.py's _handle_trade_command (round 8)
so the exact same guard-checked execution path can be called from TWO
places with byte-identical safety behavior:

  1. main.py's _handle_trade_command -- the original /trade command typed
     or built-and-sent through a Telegram chat (review-before-send).
  2. app/trade_server.py -- the new round-14 local HTTP endpoint the
     Торговля tab can call directly for instant, no-chat execution.

This split exists specifically so those two paths can never quietly
diverge on what they allow -- every guard in app/trading_guard.py runs
here, in the same order, regardless of which caller is asking. Whichever
new execution path this project ever grows next (there is currently no
third one, but if there is a next one) MUST also call this function
rather than reimplementing any part of the guard sequence.

Deliberately NOT sending any Telegram message itself -- that's caller
-specific (the chat command replies to the chat it came from with plain
text; the trade-server returns JSON to the Mini App AND separately fires
its own Telegram notification for the audit trail, see its module
docstring for why "instant" doesn't mean "silent"). Callers get back a
plain dict and decide how to present it.
"""
from __future__ import annotations

import sys
import traceback

import publish_health
from app import trading_guard
from app.config import LIVE_JOURNAL_FILE, TRADE_KEYS_FILE, Settings
from app.data import DataError, get_last_price
from app.exchanges import REGISTRY as EXCHANGE_REGISTRY
from app.exchanges.base import ExchangeAuthError
from app.state import StateStore
from app.trade_keys_store import TradeKeysStore


# 2026-09-24: «ордер долго доходит до биржи». Раньше риск-бюджет считался
# через publish_health.build_health() — это загрузка истории ВСЕХ бирж
# (у OKX с ботами GinArea ~2600 сделок) при каждом ордере, 10–30 секунд.
# Теперь — только закрытые сделки этой биржи за 7 дней, та же функция
# расчёта (compute_health_from_exchange_trades), кэш на 60 секунд.
_RISK_CACHE: dict = {}


def _risk_used_week(exch_key: str, module, trade_creds: dict, settings: Settings) -> float:
    import time as _time
    ck = f"{exch_key}:{trade_creds.get('api_key', '')[:6]}"
    hit = _RISK_CACHE.get(ck)
    if hit and _time.time() - hit[0] < 60:
        return hit[1]
    try:
        df = module.fetch_closed_trades(trade_creds["api_key"], trade_creds["api_secret"],
                                        trade_creds.get("passphrase"), lookback_days=7)
    except TypeError:  # модуль без параметра lookback_days
        df = module.fetch_closed_trades(trade_creds["api_key"], trade_creds["api_secret"],
                                        trade_creds.get("passphrase"))
    used = publish_health.compute_health_from_exchange_trades(
        df, risk_budget_usdt=settings.weekly_risk_budget_usdt, recent_n=1,
        daily_budget_usdt=settings.daily_risk_limit_usdt).get("risk_used_usdt_week", 0.0)
    _RISK_CACHE[ck] = (_time.time(), float(used or 0.0))
    return float(used or 0.0)


def execute_trade(exch_key: str, symbol: str, side: str, qty: float, leverage: int,
                   stop_loss: float, take_profit: float | None, gate_requested: bool,
                   settings: Settings, state: StateStore, entry_price: float | None = None,
                   trade_creds_override: dict | None = None) -> dict:
    """Runs every guard in app/trading_guard.py in order, stopping at the
    first failure -- an order is only ever sent to the exchange once every
    check here has passed, exactly the round-8 discipline, unchanged.

    Round 16 addition: `entry_price`. When None (default), behavior is
    byte-identical to before this round -- a Market order at the live
    price, which is also what's used for every guard check below. When a
    number is given, it becomes a GTC Limit order at that price on the
    exchange (may fill instantly, eventually, or never -- there is no
    cancel command for a still-pending limit order yet), AND it -- not the
    live market price -- is used as the reference price for the
    stop-loss-direction check and the risk-budget calculation, since that
    is the economically correct number for a resting limit order (the
    live price at submit time is irrelevant to a limit order's actual
    risk once it fills at its own price).

    Returns a dict, always with an "ok" key:
      ok=False: {"ok": False, "reason": "<Russian, user-facing text>"}
      ok=True:  {"ok": True, "order_id": ..., "exchange_display": ...,
                 "symbol": ..., "side": ..., "qty": ..., "leverage": ...,
                 "stop_loss": ..., "take_profit": ..., "entry_price": ...}
    Never raises -- every exchange-side or internal error is caught and
    turned into an ok=False result with an explanatory reason, same as
    _handle_trade_command already did before this was extracted."""
    exch_key = exch_key.strip().lower()
    symbol = symbol.strip().upper()
    side = side.strip().lower()

    module = EXCHANGE_REGISTRY.get(exch_key)
    if module is None or not hasattr(module, "place_order"):
        available = [k for k, m in EXCHANGE_REGISTRY.items() if hasattr(m, "place_order")]
        return {"ok": False, "reason": (
            f"Реальная торговля пока поддерживается только для: {', '.join(available) or '(пока ни для одной биржи)'}."
        )}

    if side not in ("buy", "sell"):
        return {"ok": False, "reason": "Направление должно быть buy (лонг) или sell (шорт)."}

    if qty <= 0:
        return {"ok": False, "reason": "Объём должен быть больше нуля."}

    # 2026-09-24: ручные ордера терминала могут идти через отдельный ключ
    # СУБАККАУНТА (слот "manual"), чтобы не сливаться с позициями ботов.
    trade_creds = trade_creds_override or TradeKeysStore(TRADE_KEYS_FILE).get_all().get(exch_key)
    if trade_creds is None:
        return {"ok": False, "reason": (
            f"Для {module.DISPLAY_NAME} не сохранён торговый ключ (права на ордера) -- это ОТДЕЛЬНЫЙ ключ от "
            f"read-only ключа для вкладки «Здоровье». Добавь его: /tradekey {exch_key} api_key api_secret "
            f"(создай НОВЫЙ ключ на бирже с правами Trade/Orders, БЕЗ вывода средств)."
        )}

    ok, reason = trading_guard.check_leverage(leverage, settings.max_trade_leverage)
    if not ok:
        return {"ok": False, "reason": reason}

    try:
        current_price = get_last_price(symbol)
    except DataError as exc:
        return {"ok": False, "reason": f"Не удалось получить текущую цену {symbol}: {exc}"}

    # Round 16: for a limit order, the resting entry price -- not the live
    # market price -- is the economically correct reference for both the
    # stop-loss-direction sanity check and the risk-budget math below.
    reference_price = entry_price if entry_price is not None else current_price

    ok, reason = trading_guard.check_stop_loss(reference_price, stop_loss, side)
    if not ok:
        return {"ok": False, "reason": reason}

    # 2026-09-04: catches a real live failure from _autotrade_worker -- see
    # trading_guard.check_take_profit's own docstring for why a take_profit
    # sourced from a signal (rather than typed fresh by a human looking at
    # the current price) can end up on the wrong side of `reference_price`
    # by execution time.
    ok, reason = trading_guard.check_take_profit(reference_price, take_profit, side)
    if not ok:
        return {"ok": False, "reason": reason}

    if gate_requested:
        active_signal = state.latest_active_signal(symbol, settings.signal_gate_max_age_minutes)
        ok, reason = trading_guard.check_signal_gate(active_signal, side, symbol)
        if not ok:
            return {"ok": False, "reason": reason}

    new_risk_usdt = qty * abs(reference_price - stop_loss)
    try:
        already_used_usdt = _risk_used_week(exch_key, module, trade_creds, settings)
    except Exception as exc:
        print(f"[TRADE] couldn't compute current risk usage, blocking trade to be safe: {exc}", file=sys.stderr)
        return {"ok": False, "reason": (
            "Не удалось проверить текущий риск-бюджет -- сделка НЕ открыта (безопаснее отказать, чем "
            "открыть вслепую). Попробуй ещё раз через минуту."
        )}

    ok, reason = trading_guard.check_risk_budget(new_risk_usdt, already_used_usdt, settings.weekly_risk_budget_usdt)
    if not ok:
        return {"ok": False, "reason": reason}

    try:
        module.set_leverage(trade_creds["api_key"], trade_creds["api_secret"], symbol, leverage,
                             trade_creds.get("passphrase"))
        order = module.place_order(
            trade_creds["api_key"], trade_creds["api_secret"], symbol, side, qty, stop_loss,
            take_profit=take_profit, passphrase=trade_creds.get("passphrase"),
            entry_price=entry_price,
        )
    except (ExchangeAuthError, DataError) as exc:
        # 2026-11-07 (аудит): таймаут сети ≠ «отклонила». Ордер мог пройти — проверяем позицию на бирже, второй ордер НЕ шлём.
        if "timed out" in str(exc).lower() or "timeout" in str(exc).lower() or "connection" in str(exc).lower():
            import time as _t  # noqa: PLC0415
            _t.sleep(3)
            try:
                df = module.fetch_open_positions(trade_creds["api_key"], trade_creds["api_secret"], trade_creds.get("passphrase"))
                rows = df.to_dict("records") if df is not None and not df.empty else []
                hit = next((r for r in rows if r.get("symbol") == symbol), None)
            except Exception:  # noqa: BLE001
                hit = "?"
            if hit and hit != "?":
                return {"ok": True, "order_id": None, "exchange_display": module.DISPLAY_NAME, "symbol": symbol, "side": side,
                        "qty": hit.get("qty"), "leverage": leverage, "stop_loss": hit.get("stop_loss"), "take_profit": take_profit,
                        "entry_price": entry_price, "note": "ответ биржи потерялся, но позиция на бирже ЕСТЬ — проверь стоп"}
            return {"ok": False, "reason": ("⚠️ Нет ответа от биржи (обрыв связи). Позиции по монете сейчас не видно — скорее всего ордер НЕ прошёл, "
                                            "но ПРОВЕРЬ в приложении биржи, прежде чем отправлять ещё раз." if hit != "?" else
                                            "⚠️ Нет ответа от биржи и не удалось проверить позицию. ОБЯЗАТЕЛЬНО проверь в приложении биржи, прежде чем повторять.")}
        return {"ok": False, "reason": f"Биржа отклонила ордер: {exc}"}
    except Exception as exc:
        print(f"[TRADE] unexpected error placing order: {exc}", file=sys.stderr)
        traceback.print_exc()
        return {"ok": False, "reason": (
            f"Непредвиденная ошибка при отправке ордера -- ПРОВЕРЬ позиции на {module.DISPLAY_NAME} "
            f"вручную, возможно ордер всё же прошёл: {exc}"
        )}

    print(f"[TRADE] order placed: {exch_key} {symbol} {side} qty={qty} leverage={leverage} "
          f"sl={stop_loss} tp={take_profit} entry_price={entry_price} gate={gate_requested} "
          f"order_id={order.get('order_id')}")

    return {
        "ok": True,
        "order_id": order.get("order_id"),
        "exchange_display": module.DISPLAY_NAME,
        "symbol": symbol,
        "side": side,
        "qty": qty,
        "leverage": leverage,
        "stop_loss": stop_loss,
        "take_profit": take_profit,
        "entry_price": entry_price,
    }
