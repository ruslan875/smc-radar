"""
Local HTTP server for instant, no-chat order execution -- 2026-08-25,
round 14. Direct follow-up to the user asking "а можем ли мы сервер
сделать сами" (can we build our own server) after being told why the
Торговля tab's "Отправить ордер боту" button only ever opens a pre-filled
Telegram chat instead of executing instantly (see round 8's "Why
client-side, no backend" section in the project doc): the Mini App itself
has nowhere safe to hold a trading key, so *something* server-side has to
hold it and expose an endpoint the Mini App can call. This is that
something -- it runs on the SAME machine as main.py (not a separate paid
cloud box, per the user's explicit choice), reuses the exact SAME trading
key already stored in trade_keys.json, and is exposed to the public
internet via a free Cloudflare Tunnel so the Mini App (hosted on GitHub
Pages, a different origin) can actually reach it.

THIS IS THE HIGHEST-RISK STANDING FEATURE IN THIS PROJECT, MORE SO THAN
ROUND 8's /trade OR ROUND 9's AUTOPILOT. Both of those still require a
human action before anything happens: /trade needs the owner to review
and tap Send in a real Telegram chat; the autopilot can only ever
TIGHTEN an existing stop, never open a new position. This endpoint, once
enabled, places a BRAND NEW real order the instant the Торговля tab's
button is tapped -- the user explicitly chose this over adding any kind
of in-app confirmation step (see the round-14 AskUserQuestion answers
in the project doc). Two things keep this from being reckless:

  1. Every guard in app/trading_guard.py (mandatory stop-loss, leverage
     cap, weekly risk-budget check) still runs, unconditionally, via the
     SAME app/trade_executor.execute_trade() function the Telegram /trade
     command calls -- nothing about round 8's non-negotiable guardrails
     changed. Only the "a human has to tap Send in Telegram" step is
     gone; everything else that could stop a bad order is still there.
  2. Authentication is NOT "the tunnel URL is hard to guess" -- CORS and
     a random-looking URL are not a security boundary, they're just
     tidiness. The actual boundary is app/telegram_auth.py's initData
     validation: every request must carry a signature Telegram itself
     produced for the owner's own Telegram session, freshly (a few
     minutes old at most), and naming the owner's own user id. No one
     else's Telegram account, however they got the URL, can pass that
     check -- this was implemented against Telegram's own documented
     algorithm, not guessed.

There is also a SEPARATE, live-toggleable kill switch on top of both of
the above: app/instant_trade_settings.py's InstantTradeSettings, checked
on every single request. /instanttrade off in Telegram (or restarting
without TRADE_SERVER_ENABLED) disables this instantly. The Telegram-chat
/trade flow is completely unaffected either way and keeps working as the
reliable fallback regardless of whether this server is running.

## Why a Cloudflare Tunnel, and why the URL keeps changing

This machine (the owner's own PC) has no public IP most home ISPs would
reliably route to, so the HTTP server here binds to 127.0.0.1 only and a
free `cloudflared tunnel --url ...` ("quick tunnel", no Cloudflare
account needed) exposes it at a random `https://xxxx.trycloudflare.com`
address. The tradeoff of the free/no-account version: that address is
NOT stable -- it's different every time cloudflared (re)starts, and a
paid/named tunnel with a fixed hostname needs a domain in a Cloudflare
account, which wasn't asked for. Rather than push that instability onto
the user, _TunnelManager below launches cloudflared as a subprocess,
parses the assigned URL straight out of its own log output the moment
it appears, and publishes it as `server_url.json` in the SMC Radar repo
via the exact same app.github_sync.push_json_file() mechanism already
used for access.json/health.json. The Mini App just fetches that file
fresh (cache-busted) every time it needs to call the server -- so a
changed URL after any restart is invisible to the user, no manual URL
entry required. If GITHUB_TOKEN isn't set, or the feature is off, the
published `url` field is explicitly null rather than left stale, so the
Mini App never tries to call a tunnel that no longer exists.
"""
from __future__ import annotations

import json
import re
import subprocess
import sys
import threading
import time
import traceback
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import requests

from app.config import INSTANT_TRADE_SETTINGS_FILE, STATE_FILE
from app.github_sync import GitHubSyncError, push_json_file
from app.instant_trade_settings import InstantTradeSettings
from app.state import StateStore
from app.telegram_auth import InitDataError, validate_init_data
from app.telegram_client import TelegramClient
from app.trade_executor import execute_trade

SERVER_URL_JSON_PATH = "server_url.json"  # published to the Mini App's repo root, like access.json/health.json
TUNNEL_URL_RE = re.compile(r"https://[a-zA-Z0-9-]+\.trycloudflare\.com")
# initData is a live, replayable snapshot (Telegram never expires it) --
# see app/telegram_auth.py's module docstring for why this window is
# tight (minutes) rather than the hours-scale staleness Telegram's own
# docs discuss for ordinary login use. A few minutes is enough slack for
# a slow phone connection, not enough to matter if a request were somehow
# captured and replayed later.
INIT_DATA_MAX_AGE_SECONDS = 180


# main.py подставляет сюда функцию «прислать превью сделки в чат» (см. /buy).
PREVIEW_HOOK = None


def _cors_headers(handler: BaseHTTPRequestHandler, origin: str) -> None:
    handler.send_header("Access-Control-Allow-Origin", origin)
    handler.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
    handler.send_header("Access-Control-Allow-Headers", "Content-Type")
    handler.send_header("Access-Control-Max-Age", "600")


class _TradeHTTPServer(ThreadingHTTPServer):
    """Holds everything the handler needs per-request as plain attributes
    on the server object -- BaseHTTPRequestHandler is instantiated fresh
    per request, so shared context has to live here, not on the handler."""
    daemon_threads = True

    def __init__(self, address, settings, allowed_origin: str):
        super().__init__(address, _TradeRequestHandler)
        self.settings = settings
        self.allowed_origin = allowed_origin
        self.telegram = TelegramClient(settings.telegram_token, settings.telegram_chat_id)
        self.instant_settings_path = None  # set by caller before serving


class _TradeRequestHandler(BaseHTTPRequestHandler):
    # Quiet by default -- BaseHTTPRequestHandler logs every request to
    # stderr otherwise, which would drown out this bot's own [TAG] log
    # lines; failures are already logged explicitly below where it matters.
    def log_message(self, fmt, *args):
        pass

    def do_OPTIONS(self):
        self.send_response(204)
        _cors_headers(self, self.server.allowed_origin)
        self.end_headers()

    def _json_response(self, status: int, payload: dict) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        _cors_headers(self, self.server.allowed_origin)
        self.end_headers()
        self.wfile.write(body)

    def _settings_api(self, body: dict) -> None:
        """2026-09-25: настройки прямо из Mini App. Раньше кнопки «Автопилот»,
        «Мгновенная торговля», «Максимум сделок» открывали чат с подставленной
        командой — на телефоне это вообще не срабатывало. Та же проверка
        initData владельца, что и у /api/trade; мгновенная торговля для этого
        не нужна (здесь нет ордеров)."""
        from app import notify_prefs  # noqa: PLC0415
        from app.autopilot_settings import AutopilotSettings  # noqa: PLC0415
        from app.config import (AUTOPILOT_SETTINGS_FILE, KC_GRID_MAX_DEALS_FILE,  # noqa: PLC0415
                                LATUSERGE_MAX_DEALS_FILE)
        from app.live_bot_settings import MaxConcurrentDealsSettings  # noqa: PLC0415
        settings = self.server.settings
        try:
            validate_init_data(body.get("initData", ""), settings.telegram_token, settings.telegram_chat_id,
                               max_age_seconds=INIT_DATA_MAX_AGE_SECONDS)
        except InitDataError as exc:
            print(f"[TRADE-SERVER] settings rejected: {exc}", file=sys.stderr)
            self._json_response(401, {"ok": False, "reason": "unauthorized"})
            return
        bots = {"latuserge": ("Latuserge", LATUSERGE_MAX_DEALS_FILE), "kcroc": ("KC/ROC грид", KC_GRID_MAX_DEALS_FILE)}
        key, value = body.get("key"), body.get("value")
        changed = None
        try:
            if key == "autopilot":
                AutopilotSettings(AUTOPILOT_SETTINGS_FILE).set_enabled(bool(value)); changed = f"Автопилот: {'ВКЛ' if value else 'ВЫКЛ'}"
            elif key == "autopilot_trail":
                AutopilotSettings(AUTOPILOT_SETTINGS_FILE).set_trail(bool(value))
                changed = f"Трейлинг автопилота: {'ВКЛ' if value else 'ВЫКЛ'}"
            elif key == "instanttrade":
                InstantTradeSettings(self.server.instant_settings_path).set_enabled(bool(value))
                changed = f"Мгновенная торговля: {'ВКЛ' if value else 'ВЫКЛ'}"
            elif key and key.startswith("maxdeals:") and key.split(":", 1)[1] in bots:
                label, path = bots[key.split(":", 1)[1]]
                n = int(value)
                if not 0 <= n <= 20:
                    raise ValueError("0..20")
                MaxConcurrentDealsSettings(path, default=2).set(n); changed = f"{label}: максимум сделок {n or 'без ограничения'}"
            elif key and key.startswith("notify:"):
                notify_prefs.set_pref(key.split(":", 1)[1], bool(value)); changed = f"Уведомления «{key[7:]}»: {'вкл' if value else 'выкл'}"
            elif key:
                raise ValueError("unknown key")
        except (ValueError, KeyError, TypeError) as exc:
            self._json_response(400, {"ok": False, "reason": f"неверная настройка: {exc}"})
            return
        if changed:
            print(f"[TRADE-SERVER] settings from Mini App: {changed}")
            try:
                self.server.telegram.send_message(f"⚙️ Изменено из Mini App — {changed}", chat_id=settings.telegram_chat_id)
            except Exception:  # noqa: BLE001
                pass
        self._json_response(200, {
            "ok": True,
            "autopilot": AutopilotSettings(AUTOPILOT_SETTINGS_FILE).is_enabled(),
            "autopilot_trail": AutopilotSettings(AUTOPILOT_SETTINGS_FILE).is_trail(),
            "instanttrade": InstantTradeSettings(self.server.instant_settings_path).is_enabled(),
            "maxdeals": {k: {"label": l, "value": MaxConcurrentDealsSettings(p, default=2).get()}
                         for k, (l, p) in bots.items()},
            "notify": notify_prefs.all_prefs(),
            "notify_labels": dict(notify_prefs.CATEGORIES),
        })

    def _trade_preview_api(self, body: dict) -> None:
        """2026-09-25: «Отправить ордер» из Mini App без мгновенного режима.
        Раньше открывался чат с подставленной командой /trade — на телефоне это
        не работало. Теперь бот сам присылает в чат превью (график, объём,
        стоп, риск) с кнопками «Открыть / Отмена» — как /buy и /sell."""
        settings = self.server.settings
        try:
            validate_init_data(body.get("initData", ""), settings.telegram_token, settings.telegram_chat_id,
                               max_age_seconds=INIT_DATA_MAX_AGE_SECONDS)
        except InitDataError:
            self._json_response(401, {"ok": False, "reason": "unauthorized"})
            return
        why = self._guard_block(body)
        if why:
            self._json_response(200, {"ok": False, "reason": why})
            return
        if PREVIEW_HOOK is None:
            self._json_response(503, {"ok": False, "reason": "бот не готов"})
            return
        try:
            from app.exchanges import bybit as bx  # noqa: PLC0415
            symbol = str(body["symbol"]).upper()
            price = bx.get_last_price(symbol)
            qty, sl = float(body["qty"]), float(body["stop_loss"])
            tp = float(body["take_profit"]) if body.get("take_profit") not in (None, "") else None
            params = {"symbol": symbol, "side": "LONG" if str(body["side"]).lower() == "buy" else "SHORT",
                      "usdt": round(qty * price, 2), "leverage": int(body.get("leverage") or 1),
                      "sl_pct": round(abs(price - sl) / price * 100, 3),
                      "tp_pct": round(abs(tp - price) / price * 100, 3) if tp else None, "trail_pct": None}
            PREVIEW_HOOK(params)
            try:
                from windows_app import challenge_guard as cg  # noqa: PLC0415
                cg.record_be(symbol, params["side"])
            except Exception:  # noqa: BLE001
                pass
        except Exception as exc:  # noqa: BLE001
            self._json_response(400, {"ok": False, "reason": str(exc)[:200]})
            return
        self._json_response(200, {"ok": True})

    def _guard_api(self, body: dict) -> None:
        """2026-11-02: режим «только по сигналу» для Mini App — сигнал по монете (обе стороны), состояние, вкл/выкл режима."""
        settings = self.server.settings
        try:
            validate_init_data(body.get("initData", ""), settings.telegram_token, settings.telegram_chat_id,
                               max_age_seconds=INIT_DATA_MAX_AGE_SECONDS)
        except InitDataError:
            self._json_response(401, {"ok": False, "reason": "unauthorized"})
            return
        from windows_app import challenge_guard as cg  # noqa: PLC0415
        if self.path == "/api/quality_mode":
            self._json_response(200, cg.set_mode(bool(body.get("on"))) if "on" in body else cg.mode())
            return
        self._json_response(200, cg.gate2(str(body.get("symbol") or "BTCUSDT")))

    @staticmethod
    def _guard_block(body: dict):
        try:
            from windows_app import challenge_guard as cg  # noqa: PLC0415
            ok, why = cg.allow(str(body.get("symbol") or ""), str(body.get("side") or ""))
            return None if ok else why
        except Exception as exc:  # noqa: BLE001
            print(f"[TRADE-SERVER] guard error (пропускаю проверку): {exc}", file=sys.stderr)
            return None

    def do_POST(self):
        if self.path in ("/api/signal_gate", "/api/quality_mode"):
            try:
                length = int(self.headers.get("Content-Length", "0"))
                body = json.loads(self.rfile.read(length).decode("utf-8")) if length > 0 else {}
            except (ValueError, UnicodeDecodeError):
                self._json_response(400, {"ok": False, "reason": "malformed request body"})
                return
            self._guard_api(body)
            return
        if self.path == "/api/trade_preview":
            try:
                length = int(self.headers.get("Content-Length", "0"))
                body = json.loads(self.rfile.read(length).decode("utf-8")) if length > 0 else {}
            except (ValueError, UnicodeDecodeError):
                self._json_response(400, {"ok": False, "reason": "malformed request body"})
                return
            self._trade_preview_api(body)
            return
        if self.path == "/api/settings":
            try:
                length = int(self.headers.get("Content-Length", "0"))
                body = json.loads(self.rfile.read(length).decode("utf-8")) if length > 0 else {}
            except (ValueError, UnicodeDecodeError):
                self._json_response(400, {"ok": False, "reason": "malformed request body"})
                return
            self._settings_api(body)
            return
        if self.path != "/api/trade":
            self._json_response(404, {"ok": False, "reason": "unknown endpoint"})
            return

        settings = self.server.settings
        try:
            length = int(self.headers.get("Content-Length", "0"))
            raw = self.rfile.read(length) if length > 0 else b""
            body = json.loads(raw.decode("utf-8")) if raw else {}
        except (ValueError, UnicodeDecodeError, json.JSONDecodeError):
            self._json_response(400, {"ok": False, "reason": "malformed request body"})
            return

        instant_settings = InstantTradeSettings(self.server.instant_settings_path)
        if not instant_settings.is_enabled():
            self._json_response(403, {
                "ok": False,
                "reason": "Мгновенное исполнение сейчас выключено (/instanttrade on в чате с ботом), "
                          "используй обычную отправку через чат.",
            })
            return

        init_data = body.get("initData", "")
        try:
            validate_init_data(init_data, settings.telegram_token, settings.telegram_chat_id,
                                max_age_seconds=INIT_DATA_MAX_AGE_SECONDS)
        except InitDataError as exc:
            print(f"[TRADE-SERVER] rejected request: {exc}", file=sys.stderr)
            self._json_response(401, {"ok": False, "reason": "unauthorized"})
            return

        try:
            exch_key = str(body["exchange"])
            symbol = str(body["symbol"])
            side = str(body["side"])
            qty = float(body["qty"])
            leverage = int(body["leverage"])
            stop_loss = float(body["stop_loss"])
            take_profit = float(body["take_profit"]) if body.get("take_profit") not in (None, "") else None
            gate_requested = bool(body.get("gate", False))
            # Round 16: optional entry_price -- absent/None keeps this a
            # Market order (byte-identical to before this round); a
            # number makes it a GTC Limit order at that price. See
            # app/trade_executor.execute_trade()'s docstring for how it
            # changes the reference price used by the guard checks.
            entry_price = float(body["entry_price"]) if body.get("entry_price") not in (None, "") else None
        except (KeyError, TypeError, ValueError):
            self._json_response(400, {"ok": False, "reason": "missing or invalid trade fields"})
            return

        why = self._guard_block({"symbol": symbol, "side": side})
        if why:
            self._json_response(200, {"ok": False, "reason": why})
            return

        # Fresh StateStore per request (cheap -- one JSON read), NOT cached
        # on the server object: the main scan loop's own StateStore is the
        # one actually writing new signals to state.json as they fire, and
        # a cached copy here would silently never see them, breaking the
        # "по сигналу" gate's freshness guarantee for anyone using it
        # through this endpoint.
        state = StateStore(STATE_FILE)
        try:
            result = execute_trade(exch_key, symbol, side, qty, leverage, stop_loss, take_profit,
                                    gate_requested, settings, state, entry_price=entry_price)
        except Exception as exc:
            print("[TRADE-SERVER] unexpected error in execute_trade", file=sys.stderr)
            traceback.print_exc()
            self._json_response(500, {"ok": False, "reason": f"internal error: {exc}"})
            return

        if result.get("ok"):
            try:
                from windows_app import challenge_guard as cg  # noqa: PLC0415
                result["be"] = cg.record_be(symbol, side)
            except Exception as exc:  # noqa: BLE001
                print(f"[TRADE-SERVER] record_be: {exc}", file=sys.stderr)
            direction_ru = "ЛОНГ" if result["side"] == "buy" else "ШОРТ"
            order_kind = (f"лимитный ордер по {result['entry_price']:g}" if result.get("entry_price") is not None
                          else "рыночный ордер")
            self.server.telegram.send_message(
                f"⚡ Мгновенный {order_kind} (без подтверждения в чате): {result['symbol']} {direction_ru}, "
                f"объём {result['qty']:g}, плечо {result['leverage']}x, SL {result['stop_loss']:g}"
                + (f", TP {result['take_profit']:g}" if result.get("take_profit") else "") + ".\n"
                f"ID ордера: {result.get('order_id')}. Проверь на {result['exchange_display']}.",
                chat_id=settings.telegram_chat_id,
            )
        self._json_response(200, result)


class _TunnelManager:
    """Launches `cloudflared tunnel --url http://127.0.0.1:<port>` as a
    subprocess, watches its own log output for the assigned quick-tunnel
    URL, and calls on_url(url) the moment it's found. Restarts cloudflared
    (with a backoff) if the process dies -- a tunnel dropping is a
    connectivity hiccup, not something that should require the whole bot
    to be restarted. Never touches trading state itself; this is purely
    plumbing to keep server_url.json accurate."""

    def __init__(self, port: int, cloudflared_path: str, on_url) -> None:
        self.port = port
        self.cloudflared_path = cloudflared_path
        self.on_url = on_url
        self._stop = False

    def stop(self) -> None:
        self._stop = True

    def _watch(self, proc, url: str) -> None:
        """2026-09-26: quick-туннель может «умереть» при живом процессе
        cloudflared (обрыв сети, сон компьютера) -- Mini App тогда пишет
        «сервер недоступен», а новый адрес не публикуется. Раз в 2 минуты
        стучимся в свой же адрес снаружи; 3 провала подряд -> убиваем
        cloudflared, run_forever поднимет новый туннель и опубликует URL."""
        fails = 0
        time.sleep(40)
        while proc.poll() is None and not self._stop:
            try:
                r = requests.options(f"{url}/api/settings", timeout=20)
                dead = r.status_code in (502, 503, 504, 530)
            except requests.exceptions.RequestException:
                dead = True
            fails = fails + 1 if dead else 0
            if fails >= 2:
                print(f"[TRADE-SERVER] туннель {url} не отвечает 2 раза подряд -- перезапускаю cloudflared",
                      file=sys.stderr)
                try:
                    proc.kill()
                except OSError:
                    pass
                return
            time.sleep(45)

    def run_forever(self) -> None:
        backoff = 5
        while not self._stop:
            try:
                proc = subprocess.Popen(
                    # 2026-11-02: --protocol http2 — QUIC (UDP) часто режут VPN/провайдер, из-за этого туннель
                    # «умирал» (Cloudflare 530) и Mini App открывала чат вместо мгновенной сделки
                    [self.cloudflared_path, "tunnel", "--protocol", "http2", "--no-autoupdate", "--url", f"http://127.0.0.1:{self.port}"],
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1,
                )
            except FileNotFoundError:
                print(f"[TRADE-SERVER] cloudflared not found at '{self.cloudflared_path}' -- instant execution "
                      f"will stay unreachable from the Mini App until it's installed (see .env.example). "
                      f"Retrying in {backoff}s.", file=sys.stderr)
                time.sleep(backoff)
                backoff = min(backoff * 2, 300)
                continue

            found_url = False
            for line in proc.stdout:
                match = TUNNEL_URL_RE.search(line)
                if match and not found_url:
                    found_url = True
                    backoff = 5
                    self.on_url(match.group(0))
                    threading.Thread(target=self._watch, args=(proc, match.group(0)), daemon=True,
                                     name="trade-server-tunnel-watch").start()
                if self._stop:
                    proc.terminate()
                    return

            proc.wait()
            if not found_url:
                print("[TRADE-SERVER] cloudflared exited before printing a tunnel URL -- check that it's a "
                      "current, working cloudflared.exe.", file=sys.stderr)
            self.on_url(None)  # tunnel is down -- tell the Mini App via server_url.json before retrying
            time.sleep(backoff)
            backoff = min(backoff * 2, 300)


class _NgrokManager:
    """2026-11-02: туннель ngrok вместо cloudflared (у пользователя VPN режет порт 7844, ngrok ходит по 443).
    Постоянный бесплатный домен → адрес не меняется. Туннель ведёт на mobile_gateway (порт 8770), который
    отдаёт приложение и проксирует /api/* Mini App сюда, на 127.0.0.1:8766."""
    def __init__(self, token: str, domain: str, settings) -> None:
        self.token, self.domain, self.settings = token, domain, settings
        from pathlib import Path  # noqa: PLC0415
        self.exe = Path(__file__).resolve().parent.parent.parent / "mobile" / "tools" / "ngrok" / "ngrok.exe"

    def _ensure_exe(self) -> bool:
        if self.exe.exists():
            return True
        import io, zipfile  # noqa: PLC0415,E401
        try:
            print("[NGROK] скачиваю ngrok.exe …")
            r = requests.get("https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-v3-stable-windows-amd64.zip", timeout=180)
            r.raise_for_status()
            self.exe.parent.mkdir(parents=True, exist_ok=True)
            with zipfile.ZipFile(io.BytesIO(r.content)) as z:
                self.exe.write_bytes(z.read("ngrok.exe"))
            return True
        except Exception as exc:  # noqa: BLE001
            print(f"[NGROK] не удалось скачать ngrok: {exc}", file=sys.stderr)
            return False

    def _publish_loop(self, url: str) -> None:
        for _ in range(60):                     # GitHub у пользователя иногда не отвечает — повторяем
            try:
                push_json_file(self.settings.github_token, self.settings.github_repo, SERVER_URL_JSON_PATH,
                               {"url": url, "updated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())},
                               message="chore: update trade-server URL (ngrok)")
                print(f"[NGROK] server_url.json -> {url}")
                return
            except Exception as exc:  # noqa: BLE001
                print(f"[NGROK] публикация адреса не удалась ({exc}), повтор через 60 с", file=sys.stderr)
                time.sleep(60)

    def run_forever(self) -> None:
        url = f"https://{self.domain}"
        if self.settings.github_token:
            threading.Thread(target=self._publish_loop, args=(url,), daemon=True, name="ngrok-publish").start()
        backoff = 5
        while True:
            if not self._ensure_exe():
                time.sleep(300); continue
            print(f"[NGROK] туннель {url} → 127.0.0.1:8770")
            proc = subprocess.Popen([str(self.exe), "http", "8770", "--url", url, "--authtoken", self.token,
                                     "--log", "stdout", "--log-level", "warn"],
                                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace",
                                    creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
            t0 = time.time()
            for line in proc.stdout:
                line = line.strip()
                if line and ("err" in line.lower() or "warn" in line.lower()):
                    print(f"[NGROK] {line[:300]}", file=sys.stderr)
            proc.wait()
            backoff = 5 if time.time() - t0 > 300 else min(backoff * 2, 300)
            print(f"[NGROK] процесс завершился (код {proc.returncode}) — перезапуск через {backoff} с", file=sys.stderr)
            time.sleep(backoff)


def _ngrok_conf() -> tuple[str, str]:
    """NGROK_AUTHTOKEN / NGROK_DOMAIN из окружения или bot/.env."""
    import os  # noqa: PLC0415
    from pathlib import Path  # noqa: PLC0415
    tok, dom = os.getenv("NGROK_AUTHTOKEN", "").strip(), os.getenv("NGROK_DOMAIN", "").strip()
    try:
        for ln in (Path(__file__).resolve().parent.parent / ".env").read_text(encoding="utf-8", errors="replace").splitlines():
            k, _, v = ln.partition("=")
            if k.strip() == "NGROK_AUTHTOKEN" and not tok: tok = v.strip().strip('"').strip("'")
            if k.strip() == "NGROK_DOMAIN" and not dom: dom = v.strip().strip('"').strip("'")
    except OSError:
        pass
    if not tok:   # 2026-11-02: токен, вписанный удалённо (в .env удалённо писать нельзя) — bot/ngrok.json
        try:
            j = json.loads((Path(__file__).resolve().parent.parent / "ngrok.json").read_text(encoding="utf-8"))
            tok = str(j.get("authtoken") or "").strip(); dom = dom or str(j.get("domain") or "").strip()
        except (OSError, ValueError):
            pass
    return tok, dom or "roman-resale-shanty.ngrok-free.dev"


def _publish_server_url(settings, url: str | None) -> None:
    if not settings.github_token:
        return
    try:
        push_json_file(
            settings.github_token, settings.github_repo, SERVER_URL_JSON_PATH,
            {"url": url, "updated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())},
            message="chore: update trade-server URL (automated)",
        )
        print(f"[TRADE-SERVER] published server_url.json -> {url or '(off)'}")
    except (GitHubSyncError, requests.exceptions.RequestException, OSError) as exc:
        print(f"[TRADE-SERVER] publishing server_url.json failed: {exc}", file=sys.stderr)


def maybe_start_trade_server(settings) -> None:
    """Called once from main() in forever-loop mode, same placement as
    the access-poll and autopilot threads. If TRADE_SERVER_ENABLED is
    false (the default), this only makes sure server_url.json says
    {"url": null} -- so a Mini App that saw a real URL from an earlier,
    since-disabled run doesn't keep trying to call a dead tunnel -- and
    returns without starting anything. If enabled, starts the HTTP server
    thread and the tunnel-manager thread, both daemon so they never block
    Ctrl+C."""
    if not settings.trade_server_enabled:
        _publish_server_url(settings, None)
        return

    if not settings.telegram_token or not settings.telegram_chat_id:
        print("[TRADE-SERVER] TRADE_SERVER_ENABLED is true but TELEGRAM_BOT_TOKEN/TELEGRAM_CHAT_ID are "
              "missing -- refusing to start (instant execution cannot be authenticated without them).",
              file=sys.stderr)
        _publish_server_url(settings, None)
        return

    instant_settings_path = INSTANT_TRADE_SETTINGS_FILE

    server = _TradeHTTPServer(("127.0.0.1", settings.trade_server_port), settings,
                               allowed_origin=settings.trade_server_allowed_origin)
    server.instant_settings_path = instant_settings_path
    threading.Thread(target=server.serve_forever, daemon=True, name="trade-server-http").start()
    print(f"[TRADE-SERVER] listening on 127.0.0.1:{settings.trade_server_port} "
          f"(instant execution is currently {'ON' if InstantTradeSettings(instant_settings_path).is_enabled() else 'off'} "
          f"-- toggle with /instanttrade on|off)")

    ng_tok, ng_dom = _ngrok_conf()
    if ng_tok:                                   # 2026-11-02: ngrok (постоянный адрес, порт 443) вместо cloudflared
        threading.Thread(target=_NgrokManager(ng_tok, ng_dom, settings).run_forever, daemon=True, name="ngrok").start()
        return
    tunnel = _TunnelManager(settings.trade_server_port, settings.cloudflared_path,
                             on_url=lambda url: _publish_server_url(settings, url))
    threading.Thread(target=tunnel.run_forever, daemon=True, name="trade-server-tunnel").start()
