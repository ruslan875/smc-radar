"""
Psycho-emotional heuristic alerts, 2026-08-23, round 9 ("Вера" trading-
assistant features). Deliberately narrow in scope for this first version:
these are NOT a diagnosis of anything, and this module says so in every
message it generates -- they're simple threshold-crossing checks on
numbers publish_health.py ALREADY computes for the Здоровье tab
(losing_streak, position_size_ratio), turned into a proactively-PUSHED
Telegram message instead of something the owner only sees if they happen
to open the Mini App.

What this version deliberately does NOT do (see the project doc's "Round
9 -- still deferred" section for the full list): detect revenge-trading by
looking at how soon a new trade follows a loss, or overtrading by counting
trades in a rolling time window. Both would need the raw per-trade
timestamps AND a running memory of what's already been alerted on, which
build_health()'s already-serialized health dict doesn't carry end-to-end
today -- worth building once there's real trade volume to tune the
thresholds against, rather than guessing at cutoffs with no data.

Pure functions, no I/O -- see app/psycho_state.py for the tiny bit of
persistence (dedup so the SAME streak/ratio doesn't re-alert every
15-minute publish cycle) and main.py's _maybe_check_psycho_alerts for how
they're wired into the existing health-publish cycle."""
from __future__ import annotations

STREAK_ALERT_THRESHOLD = 2  # matches compute_health's own "risk" tier (2 losses in a row)
POSITION_RATIO_ALERT_THRESHOLD = 2.0  # matches compute_health's own "risk" tier
# Насколько ratio должен вырасти, чтобы считаться НОВЫМ поводом написать.
# Без этого пересчёт медианы дёргал бы сообщение на каждом дрожании числа.
RATIO_ALERT_STEP = 0.5


def check_alerts(health: dict, display_name: str, last_notified_streak: int,
                 last_notified_ratio: float = 0.0) -> tuple[list[str], int, float]:
    """`health` is one per-source dict as returned by
    compute_health()/compute_health_from_exchange_trades() (NOT the whole
    build_health() payload -- caller passes one source at a time).
    `last_notified_streak` is whatever this source was last alerted at
    (see app/psycho_state.py), so a streak that's still at 3 on the next
    publish cycle doesn't alert again every 15 minutes -- only a NEW,
    higher streak does. Returns (messages, new_last_notified_streak) --
    caller persists the second value regardless of whether any message
    was produced (a streak that DROPPED back down should reset the
    dedup floor too, so a future new streak alerts again from scratch)."""
    messages: list[str] = []
    streak = health.get("losing_streak") or 0
    ratio = health.get("position_size_ratio")

    if streak >= STREAK_ALERT_THRESHOLD and streak > last_notified_streak:
        messages.append(
            f"⚠️ {display_name}: {streak} убыточные сделки подряд. Это не диагноз, а просто счётчик -- "
            f"но серии убытков часто совпадают с желанием \"отыграться\" увеличенным объёмом. Возможно, "
            f"стоит сделать паузу или уменьшить размер следующей сделки."
        )

    # 2026-09-22: раньше здесь не было НИКАКОЙ защиты от повтора — в отличие
    # от серии убытков выше. Одна крупная сделка на OKX давала одинаковое
    # сообщение каждые 15 минут часами подряд. Теперь пишем только когда
    # показатель заметно вырос по сравнению с тем, о чём уже сообщали.
    ratio_is_new = (ratio is not None
                    and ratio >= POSITION_RATIO_ALERT_THRESHOLD
                    and ratio > last_notified_ratio + RATIO_ALERT_STEP)

    if ratio_is_new:
        messages.append(
            f"⚠️ {display_name}: последняя сделка в {ratio:.1f}× больше твоего обычного размера "
            f"(медиана последних сделок). Стоит убедиться, что это осознанное решение, а не эмоциональное."
        )

    new_last_notified_streak = streak if streak >= STREAK_ALERT_THRESHOLD else 0
    # Показатель упал ниже порога — забываем его, чтобы следующая крупная
    # сделка снова считалась новостью (та же логика, что у серии убытков).
    new_last_notified_ratio = (
        ratio if (ratio is not None and ratio >= POSITION_RATIO_ALERT_THRESHOLD)
        else 0.0)
    return messages, new_last_notified_streak, new_last_notified_ratio
