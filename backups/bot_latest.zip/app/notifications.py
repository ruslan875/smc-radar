"""
2026-09-08: real email notifications for windows_app/'s panel (one of the
three "Уведомления" pieces requested -- see
claude/windows-admin-app-2026-09-06.md for the honest scope decision on
this whole round). The other two pieces are NOT here:

- Telegram alerts already exist end-to-end via main.py's TelegramClient --
  this module doesn't touch that, it's real and separate.
- "Push" in the literal mobile-push sense (a notification that reaches a
  phone while the panel isn't open) needs a cloud relay service this
  project doesn't have and was NOT built -- see the panel's "Уведомления"
  tab copy. What IS real: the browser Notification API fired client-side
  from windows_app/static/index.html while the panel window is open --
  that lives entirely in the frontend, nothing to import here.

Only SMTP email is implemented here, using the Python standard library
(smtplib + email.mime) -- no new third-party dependency, no email service
account created or touched by Claude. The user types their own SMTP
host/port/username/password into the panel's UI themselves (same
never-touch-credentials discipline as trade_keys.json/ai_key.json) --
this module only ever reads whatever EmailSettingsStore already has on
disk, it never asks the user for a value or fills one in.

Same plain-JSON-file, read-whole/write-whole pattern as
app/autopilot_settings.py.
"""
from __future__ import annotations

import json
import smtplib
import ssl
from dataclasses import dataclass, asdict
from email.mime.text import MIMEText
from pathlib import Path


class EmailNotifyError(Exception):
    """Raised by send_email() on any real SMTP failure (auth, connect,
    timeout, ...) -- the caller (server.py's API handler) turns this into
    an honest error message shown in the panel, never swallowed."""


@dataclass
class EmailSettings:
    enabled: bool = False
    host: str = ""
    port: int = 587
    username: str = ""
    password: str = ""
    use_tls: bool = True  # STARTTLS on `port` (587 typical); if False, see send_email() for port==465 vs plain
    from_addr: str = ""
    to_addr: str = ""
    notify_on_closed_trade: bool = True
    notify_on_health_critical: bool = True

    def is_configured(self) -> bool:
        # username/password are deliberately NOT required here -- a plain,
        # unauthenticated internal relay (see send_email()'s "else" branch)
        # is a real, valid configuration with no credentials at all. If the
        # user's real server DOES need auth and they left it blank, that
        # surfaces as a real, honest SMTP error from send_email() instead of
        # a pre-emptive guess here.
        return bool(self.host and self.from_addr and self.to_addr)

    def public_dict(self) -> dict:
        """Same fields, but with the password masked -- for API responses
        the panel's own JS will render (GET /api/notifications/email), so
        a saved password is never echoed back to the browser/DOM."""
        d = asdict(self)
        d["password"] = "•" * 8 if d["password"] else ""
        d["password_set"] = bool(self.password)
        del d["password"]
        return d


class EmailSettingsStore:
    def __init__(self, path: Path):
        self.path = path
        if self.path.exists():
            raw = json.loads(self.path.read_text())
        else:
            raw = {}
        known = {f.name for f in EmailSettings.__dataclass_fields__.values()}
        self.settings = EmailSettings(**{k: v for k, v in raw.items() if k in known})

    def save(self, **updates) -> None:
        known = {f.name for f in EmailSettings.__dataclass_fields__.values()}
        current = asdict(self.settings)
        for k, v in updates.items():
            if k not in known:
                continue
            if k == "password" and v == "":
                continue  # empty password in an update means "leave unchanged", never blank it out silently
            current[k] = v
        self.settings = EmailSettings(**current)
        self.path.write_text(json.dumps(current, indent=2))


def send_email(settings: EmailSettings, subject: str, body: str) -> None:
    """Sends ONE real email now, using whatever is currently in
    `settings`. Raises EmailNotifyError with the real underlying message
    on any failure -- never silently swallowed, never retried
    automatically (a retry loop belongs in the caller if ever needed,
    this function's job is just "try once, honestly")."""
    if not settings.is_configured():
        raise EmailNotifyError("SMTP не настроен полностью (нужны host, username, password, from, to)")

    msg = MIMEText(body, "plain", "utf-8")
    msg["Subject"] = subject
    msg["From"] = settings.from_addr
    msg["To"] = settings.to_addr

    try:
        if settings.use_tls:
            # STARTTLS -- typical for port 587 (Gmail, Outlook/Office365, most providers).
            with smtplib.SMTP(settings.host, settings.port, timeout=15) as server:
                server.starttls(context=ssl.create_default_context())
                server.login(settings.username, settings.password)
                server.sendmail(settings.from_addr, [settings.to_addr], msg.as_string())
        elif settings.port == 465:
            # Implicit SSL from the first byte -- typical for legacy port 465.
            with smtplib.SMTP_SSL(settings.host, settings.port, timeout=15, context=ssl.create_default_context()) as server:
                server.login(settings.username, settings.password)
                server.sendmail(settings.from_addr, [settings.to_addr], msg.as_string())
        else:
            # Plain, unencrypted SMTP -- a real option for an internal/local
            # relay that doesn't offer TLS at all (e.g. port 25 on a
            # self-hosted mail relay), not the common case but a genuine one
            # -- never silently "upgraded" to TLS behind the user's back.
            with smtplib.SMTP(settings.host, settings.port, timeout=15) as server:
                if settings.username or settings.password:
                    server.login(settings.username, settings.password)
                server.sendmail(settings.from_addr, [settings.to_addr], msg.as_string())
    except Exception as exc:  # noqa: BLE001 -- deliberately broad: any SMTP/network failure becomes one honest message
        raise EmailNotifyError(f"{type(exc).__name__}: {exc}") from exc
