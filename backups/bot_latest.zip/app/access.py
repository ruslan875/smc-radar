"""
One-time invite-code access gate, 2026-08-22 (v2 -- replaces the earlier
static PROMO_CODE design the same day, before it was ever actually
configured).

How it works: the owner sends the bot a command (see main.py's
OWNER_CODE_COMMANDS) in their own chat. The bot generates a random
6-character code, remembers it as "pending" with a 24h expiry, and replies
with it so the owner can hand it to exactly one new person through
whatever channel they like (WhatsApp, in person, etc). The first chat that
sends that exact code back to the bot is authorized and added to the
signal-delivery broadcast list; the code is then marked used and can never
authorize a second chat.

The owner's own chat_id (TELEGRAM_CHAT_ID in .env) is always authorized
automatically -- the gate is for *additional* people, never a way to lock
the owner out of their own bot.

Site sync: the SMC Radar Mini App (static GitHub Pages page, no backend of
its own) can optionally check codes too, via app/github_sync.py publishing
a SHA-256 hash of the current active code to a small JSON file in the same
GitHub repo. This is weaker than the bot's own enforcement (a code shared
for site-only use can't be "consumed" by a static page -- there's no
server round-trip to tell this process it was used), so the site instead
relies on the same 24h expiry, and gets invalidated as soon as the code is
consumed via Telegram (whichever channel the invited person uses first).
See app/github_sync.py and the Mini App's index.html gate screen.
"""
from __future__ import annotations

import hashlib
import json
import random
import string
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

# Excludes visually-ambiguous characters (0/O, 1/I/L) so a code read aloud
# or typed from memory doesn't fail on a transcription mistake.
CODE_ALPHABET = "".join(c for c in string.ascii_uppercase + string.digits if c not in "0O1IL")
CODE_LENGTH = 6
CODE_TTL_SECONDS = 24 * 3600


def generate_code() -> str:
    return "".join(random.choices(CODE_ALPHABET, k=CODE_LENGTH))


def code_hash(code: str) -> str:
    return hashlib.sha256(code.strip().upper().encode("utf-8")).hexdigest()


class AccessStore:
    def __init__(self, path: Path):
        self.path = path
        if self.path.exists():
            raw = json.loads(self.path.read_text())
        else:
            raw = {}
        self._authorized: dict = raw.get("authorized", {})  # chat_id (str) -> meta dict
        # code (str) -> {"created_at": iso, "expires_at": iso, "used": bool, "used_by": str|None}
        self._codes: dict = raw.get("pending_codes", {})
        self.last_update_id: int | None = raw.get("last_update_id")

    def _save(self) -> None:
        payload = {
            "authorized": self._authorized,
            "pending_codes": self._codes,
            "last_update_id": self.last_update_id,
        }
        self.path.write_text(json.dumps(payload, indent=2, ensure_ascii=False))

    # ---- authorization ----
    def is_authorized(self, chat_id: str) -> bool:
        return str(chat_id) in self._authorized

    def authorize(self, chat_id: str, meta: dict) -> None:
        self._authorized[str(chat_id)] = meta
        self._save()

    def ensure_owner_authorized(self, chat_id: str) -> None:
        """The owner's own chat (from TELEGRAM_CHAT_ID) is never gated --
        this just makes sure they're always present in the broadcast list
        even before this feature existed / before they type a code."""
        if chat_id and not self.is_authorized(chat_id):
            self.authorize(chat_id, {"role": "owner", "authorized_via": "auto (TELEGRAM_CHAT_ID)"})

    def authorized_chat_ids(self) -> list[str]:
        return list(self._authorized.keys())

    def is_owner(self, chat_id: str) -> bool:
        meta = self._authorized.get(str(chat_id))
        return bool(meta and meta.get("role") == "owner")

    # ---- one-time invite codes ----
    def create_code(self, ttl_seconds: int = CODE_TTL_SECONDS) -> str:
        code = generate_code()
        now = datetime.now(timezone.utc)
        self._codes[code] = {
            "created_at": now.isoformat(),
            "expires_at": (now + timedelta(seconds=ttl_seconds)).isoformat(),
            "used": False,
            "used_by": None,
        }
        self._save()
        return code

    def consume_code(self, code: str, chat_id: str) -> bool:
        """Returns True and marks the code used iff it exists, is unused,
        and hasn't expired. False for any other reason (never generated,
        already used by someone else, or expired) -- callers should treat
        all of those identically (a generic "wrong or expired code")."""
        code = code.strip().upper()
        entry = self._codes.get(code)
        if entry is None or entry["used"]:
            return False
        if datetime.fromisoformat(entry["expires_at"]) < datetime.now(timezone.utc):
            return False
        entry["used"] = True
        entry["used_by"] = str(chat_id)
        self._save()
        return True

    def current_active_code(self) -> str | None:
        """The most recently created code that's still unused and
        unexpired -- this is what gets published for the Mini App to
        check against. None if nothing qualifies (never generated any /
        the last one is used or expired)."""
        now = datetime.now(timezone.utc)
        active = [
            (entry["created_at"], code) for code, entry in self._codes.items()
            if not entry["used"] and datetime.fromisoformat(entry["expires_at"]) > now
        ]
        if not active:
            return None
        active.sort()
        return active[-1][1]

    def active_code_payload(self) -> dict:
        """What gets pushed to GitHub for the Mini App's gate to check
        against -- a hash, never the plaintext code, plus its expiry so
        the site can also reject a stale one locally without a fetch."""
        code = self.current_active_code()
        if code is None:
            return {"code_hash": None, "expires_at": None, "issued_at": None}
        entry = self._codes[code]
        return {"code_hash": code_hash(code), "expires_at": entry["expires_at"], "issued_at": entry["created_at"]}

    def set_last_update_id(self, update_id: int) -> None:
        self.last_update_id = update_id
        self._save()
