"""
Tiny persisted dedup store for app/psycho_heuristics.py's threshold
alerts, 2026-08-23, round 9. Tracks, per health-source key (e.g. "bybit",
"journal"), the highest losing-streak value already alerted on, so
_maybe_check_psycho_alerts (main.py) doesn't push the same "N losses in a
row" message every 15-minute publish cycle while the streak sits
unchanged -- only a NEW, higher streak (or a fresh streak after it reset
to 0) triggers another message. Same plain-JSON-file pattern as
app/scan_settings.py -- one small dict, changed rarely."""
from __future__ import annotations

import json
from pathlib import Path


class PsychoAlertState:
    def __init__(self, path: Path):
        self.path = path
        if self.path.exists():
            raw = json.loads(self.path.read_text())
        else:
            raw = {}
        self._last_streak: dict = raw.get("last_notified_streak", {})
        # 2026-09-22: то же самое для position_size_ratio. Без него алерт
        # "последняя сделка в N× больше обычной" уходил КАЖДЫЙ цикл публикации
        # здоровья, то есть раз в 15 минут, пока показатель держался выше
        # порога — одна сделка давала бесконечную ленту одинаковых сообщений.
        self._last_ratio: dict = raw.get("last_notified_ratio", {})

    def _save(self) -> None:
        self.path.write_text(json.dumps({
            "last_notified_streak": self._last_streak,
            "last_notified_ratio": self._last_ratio,
        }, indent=2))

    def last_notified_streak(self, source_key: str) -> int:
        return int(self._last_streak.get(source_key, 0))

    def set_last_notified_streak(self, source_key: str, streak: int) -> None:
        self._last_streak[source_key] = streak
        self._save()

    def last_notified_ratio(self, source_key: str) -> float:
        return float(self._last_ratio.get(source_key, 0.0))

    def set_last_notified_ratio(self, source_key: str, ratio: float) -> None:
        self._last_ratio[source_key] = ratio
        self._save()
