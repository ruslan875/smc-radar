"""app/ledger_backend.py — 2026-10-25. Бэкенд «каждый бот — свой объём» на ОБЩЕМ счёте Bybit (как GinArea).

Подменяет LiveBackend у Latuserge и KC/ROC (флаг --demo, только демо-счёт Bybit). Тот же интерфейс:
open_base / place_leg_market / place_grid_leg / sync_stop / close_market / cancel_all / get_position / last_closed_exit.

Отличия от LiveBackend:
  • все ордера бота помечены orderLinkId «<TAG>-…» — по ним бот узнаёт СВОИ исполнения;
  • вход и доборы — без стопа в ордере (стоп в ордере ставит стоп на ВСЮ позицию, задевая другого бота);
  • стоп — отдельный условный reduce-only ордер на СВОЙ объём (orderLinkId «<TAG>-SL-…»);
  • get_position возвращает СВОЙ объём и среднюю по своим исполнениям, а не всю позицию биржи;
  • close_market — reduce-only ровно на свой объём; cancel_all — только свои ордера, чужие не трогает;
  • если свой объём изменился (исполнился лимитный добор) — стоп сам пересоздаётся на новый объём.
Проверено: ledger/ledger_test.py (симулятор, 12/12) и ledger/ledger_demo_test.py (Bybit DEMO, 5/5).
"""
from __future__ import annotations

import json
import time
import uuid
from pathlib import Path

from app.data import DataError
from app.exchanges import bybit as bx

CAT = "linear"


class LedgerBackend:
    live = True

    def __init__(self, api_key: str, api_secret: str, leverage: int, tag: str, state_path: Path):
        self.k, self.s, self.leverage, self.tag = api_key, api_secret, leverage, tag
        self.state_path = Path(state_path)
        self._lev: set[str] = set()
        self.st = self._load()          # {symbol: {"since": ms, "stop": price|None}}

    # ---------- хранение ----------
    def _load(self) -> dict:
        try:
            return json.loads(self.state_path.read_text("utf-8"))
        except (OSError, ValueError):
            return {}

    def _save(self) -> None:
        tmp = self.state_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.st, indent=1), "utf-8"); tmp.replace(self.state_path)

    # ---------- низкий уровень ----------
    def _post(self, path: str, params: dict) -> dict:
        p = bx._signed_post(path, self.k, self.s, params)  # noqa: SLF001
        if p.get("retCode") not in (0, None):
            raise DataError(f"Bybit {path}: {p.get('retMsg')} (retCode={p.get('retCode')})")
        return p.get("result") or {}

    def _get(self, path: str, params: dict) -> dict:
        return (bx._signed_get(path, self.k, self.s, params) or {}).get("result") or {}  # noqa: SLF001

    def _link(self, kind: str) -> str:
        return f"{self.tag}-{kind}-{uuid.uuid4().hex[:12]}"

    def _ensure_leverage(self, symbol: str) -> None:
        if symbol not in self._lev:
            try:
                bx.set_leverage(self.k, self.s, symbol, self.leverage)
            except Exception:  # noqa: BLE001 -- «плечо уже такое» и т.п.
                pass
            self._lev.add(symbol)

    def _order(self, symbol: str, side: str, qty: float, kind: str, reduce: bool = False, price: float | None = None) -> dict:
        body = {"category": CAT, "symbol": symbol, "side": side, "orderType": "Limit" if price else "Market",
                "qty": f"{qty:.10g}", "reduceOnly": reduce, "positionIdx": 0, "orderLinkId": self._link(kind)}
        if price:
            body["price"] = f"{price:.10g}"; body["timeInForce"] = "GTC"
        r = self._post("/v5/order/create", body)
        return {"order_id": r.get("orderId"), "link": body["orderLinkId"]}

    def _open_orders(self, symbol: str) -> list[dict]:
        out = []
        for flt in ("Order", "StopOrder"):
            try:
                out += self._get("/v5/order/realtime", {"category": CAT, "symbol": symbol, "orderFilter": flt}).get("list") or []
            except DataError:
                pass
        return [o for o in out if str(o.get("orderLinkId", "")).startswith(self.tag + "-")]

    def _my_stops(self, symbol: str) -> list[dict]:
        return [o for o in self._open_orders(symbol) if f"{self.tag}-SL-" in o.get("orderLinkId", "")]

    def _cancel(self, symbol: str, o: dict) -> None:
        try:
            self._post("/v5/order/cancel", {"category": CAT, "symbol": symbol, "orderId": o["orderId"]})
        except DataError as e:
            if "110001" not in str(e) and "not exists" not in str(e):   # уже исполнен/снят биржей — норма
                raise

    def _own(self, symbol: str) -> tuple[float, float, float | None]:
        """Свой объём, средняя входа, цена последнего своего выхода — по своим исполнениям с начала сделки."""
        since = int((self.st.get(symbol) or {}).get("since") or 0)
        rows = self._get("/v5/execution/list", {"category": CAT, "symbol": symbol, "limit": 100}).get("list") or []
        rows = [r for r in rows if str(r.get("orderLinkId", "")).startswith(self.tag + "-") and int(r.get("execTime", 0)) >= since]
        rows.sort(key=lambda r: int(r["execTime"]))
        qty = cost = 0.0; last_exit = None
        for r in rows:
            q, px = float(r["execQty"]), float(r["execPrice"])
            if r["side"] == "Buy":
                cost += q * px; qty += q
            else:
                avg = cost / qty if qty else 0.0
                qty = max(0.0, qty - q); cost = avg * qty; last_exit = px
        return qty, (cost / qty if qty > 1e-12 else 0.0), last_exit

    def _place_stop(self, symbol: str, qty: float, stop: float) -> None:
        for o in self._my_stops(symbol):                 # старый стоп был на старый объём
            self._cancel(symbol, o)
        if qty <= 1e-12 or not stop:
            return
        self._post("/v5/order/create", {"category": CAT, "symbol": symbol, "side": "Sell", "orderType": "Market",
                                        "qty": f"{qty:.10g}", "reduceOnly": True, "closeOnTrigger": True, "positionIdx": 0,
                                        "triggerPrice": f"{stop:.10g}", "triggerDirection": 2, "triggerBy": "MarkPrice",
                                        "orderLinkId": self._link("SL")})
        self.st.setdefault(symbol, {})["stop"] = stop
        self.st[symbol]["stop_qty"] = qty
        self._save()

    # ---------- интерфейс LiveBackend ----------
    def open_base(self, symbol, qty, stop_price):
        self._ensure_leverage(symbol)
        self.st[symbol] = {"since": int(time.time() * 1000) - 5000, "stop": stop_price}
        self._save()
        r = self._order(symbol, "Buy", qty, "IN")
        time.sleep(1.0)
        own, _avg, _ = self._own(symbol)
        self._place_stop(symbol, own or qty, stop_price)
        return r

    def place_leg_market(self, symbol, qty, stop_price):
        r = self._order(symbol, "Buy", qty, "IN")
        time.sleep(1.0)
        own, _avg, _ = self._own(symbol)
        self._place_stop(symbol, own, stop_price or (self.st.get(symbol) or {}).get("stop"))
        return r

    def place_grid_leg(self, symbol, limit_price, qty, stop_price):
        # лимитный добор: стоп пересоздастся на новый объём, когда добор исполнится (см. get_position)
        return self._order(symbol, "Buy", qty, "LEG", price=limit_price)

    def sync_stop(self, symbol, stop_price):
        own, _avg, _ = self._own(symbol)
        self._place_stop(symbol, own, stop_price)

    def close_market(self, symbol, qty):
        own, _avg, _ = self._own(symbol)
        if own > 1e-12:
            self._order(symbol, "Sell", own, "OUT", reduce=True)   # ровно свой объём, чужой не трогаем
        for o in self._my_stops(symbol):
            self._cancel(symbol, o)

    def cancel_all(self, symbol):
        for o in self._open_orders(symbol):              # только свои ордера
            self._cancel(symbol, o)

    def get_position(self, symbol) -> dict | None:
        own, avg, _ = self._own(symbol)
        if own <= 1e-12:
            return None
        st = self.st.get(symbol) or {}
        if st.get("stop") and abs(float(st.get("stop_qty") or 0) - own) > 1e-9:
            try:                                         # добор исполнился — стоп на весь свой объём
                self._place_stop(symbol, own, st["stop"])
            except DataError as e:
                print(f"[{self.tag}] {symbol}: не удалось пересоздать стоп ({e})")
        return {"qty": own, "avg_entry_price": avg}

    def last_closed_exit(self, symbol: str) -> float | None:
        try:
            return self._own(symbol)[2]
        except DataError:
            return None
