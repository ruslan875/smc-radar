"""
Live on/off switch for the breakeven-autopilot loop (2026-08-23, round 9
-- "Вера" trading-assistant features, see app/autopilot.py). Deliberately
OFF by default and toggled via /autopilot on|off in Telegram (or the Mini
App's Торговля tab, which builds that exact command through the same
review-before-send flow as /trade) -- NOT an .env flag, so the owner can
turn this on/off instantly without restarting the bot, and so a fresh
install/clone never silently starts placing live stop-loss amendments.

Same plain-JSON-file, read-whole/write-whole pattern as
app/scan_settings.py's ScanSettings -- appropriate at this scale (one
boolean, changed rarely, checked once per autopilot poll)."""
from __future__ import annotations

import json
from pathlib import Path


class AutopilotSettings:
    def __init__(self, path: Path):
        self.path = path
        if self.path.exists():
            raw = json.loads(self.path.read_text())
        else:
            raw = {}
        self.enabled: bool = bool(raw.get("enabled", False))
        # 2026-09-26: режим «безубыток + трейлинг» -- после переноса стопа в
        # безубыток бот ставит на бирже трейлинг на расстоянии 1R.
        self.trail: bool = bool(raw.get("trail", False))

    def _save(self) -> None:
        self.path.write_text(json.dumps({"enabled": self.enabled, "trail": self.trail}, indent=2))

    def set_enabled(self, enabled: bool) -> None:
        self.enabled = enabled
        self._save()

    def set_trail(self, trail: bool) -> None:
        self.trail = trail
        self._save()

    def is_enabled(self) -> bool:
        return self.enabled

    def is_trail(self) -> bool:
        return self.trail
