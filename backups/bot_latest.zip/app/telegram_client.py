"""
Minimal Telegram Bot API client -- just what we need: sendPhoto with a
caption. Uses the HTTP API directly (no extra SDK dependency).
"""
from __future__ import annotations

import json

import requests

API_BASE = "https://api.telegram.org"


class TelegramError(RuntimeError):
    pass


class TelegramClient:
    def __init__(self, token: str, chat_id: str):
        if not token or not chat_id:
            raise ValueError("TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID must be set")
        self.token = token
        self.chat_id = chat_id

    def _url(self, method: str) -> str:
        return f"{API_BASE}/bot{self.token}/{method}"

    def send_photo(self, photo_bytes: bytes | None, caption: str, parse_mode: str = "HTML",
                    chat_id: str | None = None, reply_markup: dict | None = None,
                    file_id: str | None = None) -> dict:
        """2026-09-23: + reply_markup (меню-баннер TRADEOS) и file_id —
        повторная отправка уже загруженной картинки без перезаливки."""
        data = {"chat_id": chat_id or self.chat_id, "caption": caption, "parse_mode": parse_mode}
        if reply_markup is not None:
            data["reply_markup"] = json.dumps(reply_markup)
        files = None
        if file_id:
            data["photo"] = file_id
        else:
            files = {"photo": ("image.png", photo_bytes, "image/png")}
        resp = requests.post(self._url("sendPhoto"), data=data, files=files, timeout=20)
        payload = resp.json()
        if not payload.get("ok"):
            raise TelegramError(f"sendPhoto failed: {payload}")
        return payload

    def send_message(self, text: str, parse_mode: str = "HTML", chat_id: str | None = None,
                      reply_markup: dict | None = None) -> dict:
        data = {"chat_id": chat_id or self.chat_id, "text": text, "parse_mode": parse_mode}
        if reply_markup is not None:
            # 2026-08-22: inline-keyboard menus (scan-mode picker). Telegram
            # wants this as a JSON-encoded string even in a form-data body.
            data["reply_markup"] = json.dumps(reply_markup)
        resp = requests.post(self._url("sendMessage"), data=data, timeout=20)
        payload = resp.json()
        if not payload.get("ok"):
            raise TelegramError(f"sendMessage failed: {payload}")
        return payload

    def answer_callback_query(self, callback_query_id: str, text: str | None = None) -> dict:
        """Acknowledges an inline-keyboard button press (2026-08-22, scan-
        mode picker) -- Telegram shows a loading spinner on the button
        until this is called, regardless of whether `text` is set."""
        data: dict = {"callback_query_id": callback_query_id}
        if text:
            data["text"] = text
        resp = requests.post(self._url("answerCallbackQuery"), data=data, timeout=10)
        payload = resp.json()
        if not payload.get("ok"):
            raise TelegramError(f"answerCallbackQuery failed: {payload}")
        return payload

    def set_my_commands(self, commands: list[dict], chat_id: str | None = None) -> dict:
        """Registers the "/" command menu shown in Telegram's UI next to
        the message box (2026-08-22, so /newcode and /scan don't have to
        be remembered/typed from scratch). Without `chat_id` this sets the
        DEFAULT menu (visible to every chat, including not-yet-authorized
        guests); pass `chat_id` to scope a menu to one specific chat only
        (e.g. the owner's), which overrides the default there. Safe to
        call on every startup -- Telegram just overwrites the previous
        list, no accumulation."""
        data: dict = {"commands": json.dumps(commands)}
        if chat_id is not None:
            data["scope"] = json.dumps({"type": "chat", "chat_id": chat_id})
        resp = requests.post(self._url("setMyCommands"), data=data, timeout=10)
        payload = resp.json()
        if not payload.get("ok"):
            raise TelegramError(f"setMyCommands failed: {payload}")
        return payload

    def edit_message_text(self, chat_id: str, message_id: int, text: str, reply_markup: dict | None = None,
                          parse_mode: str = "HTML") -> dict:
        """2026-09-23: меню TRADEOS листается в одном сообщении (раздел ->
        подраздел -> назад) вместо того, чтобы каждое нажатие плодило новое."""
        data = {"chat_id": chat_id, "message_id": message_id, "text": text, "parse_mode": parse_mode}
        if reply_markup is not None:
            data["reply_markup"] = json.dumps(reply_markup)
        resp = requests.post(self._url("editMessageText"), data=data, timeout=10)
        payload = resp.json()
        if not payload.get("ok"):
            raise TelegramError(f"editMessageText failed: {payload}")
        return payload

    def edit_message_caption(self, chat_id: str, message_id: int, caption: str,
                             reply_markup: dict | None = None, parse_mode: str = "HTML") -> dict:
        """Для меню-баннера: у сообщения с картинкой меняется подпись, а не текст."""
        data = {"chat_id": chat_id, "message_id": message_id, "caption": caption, "parse_mode": parse_mode}
        if reply_markup is not None:
            data["reply_markup"] = json.dumps(reply_markup)
        resp = requests.post(self._url("editMessageCaption"), data=data, timeout=10)
        payload = resp.json()
        if not payload.get("ok"):
            raise TelegramError(f"editMessageCaption failed: {payload}")
        return payload

    def delete_message(self, chat_id: str, message_id: int) -> dict:
        """Deletes one message (2026-08-23, so a guest's typed invite code
        doesn't sit in the chat history afterward). Telegram allows bots
        to delete incoming messages in private chats -- which is the only
        kind of chat a guest ever has with this bot -- so this works
        without any special admin rights."""
        resp = requests.post(
            self._url("deleteMessage"),
            data={"chat_id": chat_id, "message_id": message_id},
            timeout=10,
        )
        payload = resp.json()
        if not payload.get("ok"):
            raise TelegramError(f"deleteMessage failed: {payload}")
        return payload

    def test_connection(self) -> dict:
        resp = requests.get(self._url("getMe"), timeout=10)
        payload = resp.json()
        if not payload.get("ok"):
            raise TelegramError(f"getMe failed: {payload}")
        return payload["result"]

    def get_updates(self, offset: int | None = None, timeout: int = 0) -> list[dict]:
        """Long/short-poll for new incoming messages (promo-code gate, 2026-08-22)
        and inline-keyboard button presses (scan-mode picker, same day).
        `offset` should be the last-seen update_id + 1 so Telegram doesn't
        redeliver already-handled updates; `timeout=0` returns immediately
        with whatever's already queued (used here since this is called once
        per market-scan cycle, not in a dedicated blocking loop).

        2026-09-06: the user's connection to api.telegram.org is
        intermittently flaky (confirmed live: a hung connect attempt that
        times out, then a retry moments later succeeds in under a second --
        not a hard block, since a browser and a one-off script on the same
        machine reach the API fine). The old single `timeout=timeout + 10`
        applied to BOTH the connect phase and the read phase, so a
        blackholed connect attempt (the actual observed failure mode, never
        a slow read) ate the full 10s before _access_poll_worker's 3s sleep
        even started -- ~13s deaf per bad attempt. Splitting it into a
        requests (connect_timeout, read_timeout) tuple lets the connect
        phase give up in 5s instead, roughly halving that dead time per
        failed attempt during a flaky stretch, while the read side keeps
        the old generous allowance (irrelevant in practice here since
        timeout=0 responses come back in well under a second once
        connected)."""
        params: dict = {"timeout": timeout, "allowed_updates": '["message", "callback_query"]'}
        if offset is not None:
            params["offset"] = offset
        # 2026-09-22: connect-таймаут поднят с 5 до 15 секунд. Пяти не хватало:
        # в логе десятки ConnectTimeoutError подряд, при том что та же машина
        # открывает api.telegram.org за доли секунды — то есть соединение
        # изредка устанавливается медленно, а не блокируется. Read-таймаут
        # не трогаем, он привязан к long-polling и своей логике.
        resp = requests.get(self._url("getUpdates"), params=params,
                            timeout=(15, timeout + 10))
        payload = resp.json()
        if not payload.get("ok"):
            raise TelegramError(f"getUpdates failed: {payload}")
        return payload["result"]
