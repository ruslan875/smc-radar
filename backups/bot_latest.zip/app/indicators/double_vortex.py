"""Port of "Double Vortex [RSI + Volume + MidPrice]" (source:
Double_Vortex_RSI__Volume__MidPrice.txt).

Clean, self-contained, fully vectorizable signal -- no visuals-only parts
to skip beyond the plotshape markers themselves (which just draw the same
buySignal/sellSignal booleans ported below).

Entry logic:
  - Long: RSI(7) crosses over 30 (leaving oversold), current volume above
    its 100-bar SMA, and close above the bar's own midprice
    ((high+low)/2) -- i.e. bullish pressure within the triggering candle.
  - Short: RSI(7) crosses under 70 (leaving overbought), volume above its
    100-bar SMA, and close below the bar's midprice.
"""
from __future__ import annotations

import pandas as pd

from .common import Signal, rsi, sma, atr, synthetic_stop, SYNTHETIC_ATR_LEN

RSI_PERIOD = 7
RSI_OVERBOUGHT = 70
RSI_OVERSOLD = 30
VOLUME_LOOKBACK = 100


def _crossover(a: pd.Series, level: float) -> pd.Series:
    return (a.shift(1) < level) & (a > level)


def _crossunder(a: pd.Series, level: float) -> pd.Series:
    return (a.shift(1) > level) & (a < level)


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    high, low, close, volume = df["high"], df["low"], df["close"], df["volume"]

    rsi_value = rsi(close, RSI_PERIOD)
    avg_volume = sma(volume, VOLUME_LOOKBACK)
    mid_price = (high + low) / 2
    atr_series = atr(df, SYNTHETIC_ATR_LEN)

    buy_signal = _crossover(rsi_value, RSI_OVERSOLD) & (volume > avg_volume) & (close > mid_price)
    sell_signal = _crossunder(rsi_value, RSI_OVERBOUGHT) & (volume > avg_volume) & (close < mid_price)

    signals: list[Signal] = []
    valid_from = max(RSI_PERIOD, VOLUME_LOOKBACK) + 1

    for i in range(valid_from, len(df)):
        is_buy = bool(buy_signal.iloc[i]) if not pd.isna(buy_signal.iloc[i]) else False
        is_sell = bool(sell_signal.iloc[i]) if not pd.isna(sell_signal.iloc[i]) else False
        if not (is_buy or is_sell):
            continue
        atr_v = atr_series.iloc[i]
        if pd.isna(atr_v):
            continue

        entry = float(close.iloc[i])
        direction = "long" if is_buy else "short"
        stop = synthetic_stop(entry, float(atr_v), direction)
        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=stop,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="double_vortex", synthetic_stop=True,
        ))

    return signals
