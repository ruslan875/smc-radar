"""Python ports of third-party TradingView/Pine indicators, for backtesting
against the same Bybit history + fee-aware methodology used for the SMC bot.

Each module exposes:

    generate_signals(df: pd.DataFrame) -> list[Signal]

where `df` has columns open/high/low/close/volume/open_time (ascending,
oldest first -- same shape fetch_history() in generic_backtest.py returns).
Every module is self-contained and causal: signal i only ever looks at
df.iloc[:=i], matching the "last-closed-candle" convention used by
app/smc.py and backtest.py (no lookahead).

See PORTING_NOTES.md in this folder for per-indicator fidelity notes
(where a Pine library internal had to be reimplemented from published
formulas rather than the exact closed-source original, and where a
synthetic SL/TP rule was applied because the original indicator has none).
"""
