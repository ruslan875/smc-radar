"""Port of the "Bullish/Bearish Divergence" alertconditions (bullCond /
bearCond, the "𝓤𝓹" / "𝓓𝓸𝔀𝓷" labels) from "MoPeDa.net" v2.0 (source lines
798-858, 1143-1144). A composite oscillator, not a single indicator's
divergence: RSI, StochRSI-of-RSI, and MACD are each z-scored against their
own 100-bar mean/stdev, averaged, then EMA-smoothed:

    r_z    = zscore(RSI(close,14), 100)
    stoch  = ta.stoch(RSI, RSI, RSI, 14)            // StochRSI (high=low=src=RSI)
    k_z    = zscore(stoch, 100)
    macd_l = ema(close,12) - ema(close,26)          // MACD line only
    m_z    = zscore(macd_l, 100)
    avgZ   = (r_z + k_z + m_z) / 3
    mainLine = ema(avgZ, 10)                        // smoothLen

Regular divergence is then read off PIVOTS of `mainLine` vs. price, using
the source's own explicit prev-pivot state (not `ta.valuewhen`):

    pl = pivotlow(mainLine, 15, 1)   // lookbackLeft, lookbackRight
    ph = pivothigh(mainLine, 15, 1)

    on each new pivot low: compare mainLine/low at this pivot vs. the
    PREVIOUS pivot low -- if mainLine made a higher low (zUp) while price
    made a lower low (priceDown), and the two pivots are 5-60 bars apart
    -> bullCond (BUY / long). Mirrored for pivot highs -> bearCond
    (SELL / short).

Entry = close of the signal bar (market), no native stop in the source
(pure alert indicator, no strategy.entry/exit anywhere in the file) --
synthetic ATR(14) stop + default 1R/2R/3R ladder per the batch convention.
"""
from __future__ import annotations

import pandas as pd

from .common import Signal, atr, ema, highest, lowest, pivothigh, pivotlow, rsi as rsi_fn, \
    sma, stdev, synthetic_stop, SYNTHETIC_ATR_LEN, SYNTHETIC_ATR_MULT

RSI_LENGTH = 14
STOCH_LENGTH = 14
LEN_Z = 100
SMOOTH_LEN = 10
LOOKBACK_LEFT = 15
LOOKBACK_RIGHT = 1
RANGE_MIN = 5
RANGE_MAX = 60


def _stoch_of(src: pd.Series, length: int) -> pd.Series:
    """Pine ta.stoch(source, high, low, length) with high=low=source --
    same construct as extreme_reversal.py's _stoch_of."""
    hh = highest(src, length)
    ll = lowest(src, length)
    rng = (hh - ll).replace(0, float("nan"))
    return 100 * (src - ll) / rng


def _zscore(series: pd.Series, length: int) -> pd.Series:
    m = sma(series, length)
    sd = stdev(series, length).replace(0, 1.0)
    return (series - m) / sd


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    n = len(df)
    if n < LEN_Z + LOOKBACK_LEFT + LOOKBACK_RIGHT + 5:
        return []

    close = df["close"]
    low = df["low"]
    high = df["high"]

    r = rsi_fn(close, RSI_LENGTH)
    r_z = _zscore(r, LEN_Z)

    stoch = _stoch_of(r, STOCH_LENGTH)
    k_z = _zscore(stoch, LEN_Z)

    macd_line = ema(close, 12) - ema(close, 26)
    m_z = _zscore(macd_line, LEN_Z)

    avg_z = (r_z + k_z + m_z) / 3.0
    main_line = ema(avg_z, SMOOTH_LEN)

    pl = pivotlow(main_line, LOOKBACK_LEFT, LOOKBACK_RIGHT)
    ph = pivothigh(main_line, LOOKBACK_LEFT, LOOKBACK_RIGHT)

    pl_np = pl.to_numpy()
    ph_np = ph.to_numpy()
    low_np = low.to_numpy()
    high_np = high.to_numpy()
    close_np = close.to_numpy()
    atr_synth = atr(df, SYNTHETIC_ATR_LEN).to_numpy()

    signals: list[Signal] = []
    prev_pl_z = prev_pl_price = None
    prev_pl_bar = None
    prev_ph_z = prev_ph_price = None
    prev_ph_bar = None

    for i in range(n):
        bull_cond = False
        bear_cond = False
        src_idx = i - LOOKBACK_RIGHT  # the actual pivot bar

        if src_idx >= 0 and not pd.isna(pl_np[i]):
            curr_z = pl_np[i]  # == main_line at src_idx (pivot value itself)
            curr_price = low_np[src_idx]
            z_up = prev_pl_z is not None and curr_z > prev_pl_z
            price_down = prev_pl_price is not None and curr_price < prev_pl_price
            bars_btw = (src_idx - prev_pl_bar) if prev_pl_bar is not None else None
            if z_up and price_down and bars_btw is not None and RANGE_MIN <= bars_btw <= RANGE_MAX:
                bull_cond = True
            prev_pl_z, prev_pl_price, prev_pl_bar = curr_z, curr_price, src_idx

        if src_idx >= 0 and not pd.isna(ph_np[i]):
            curr_z = ph_np[i]
            curr_price = high_np[src_idx]
            z_down = prev_ph_z is not None and curr_z < prev_ph_z
            price_up = prev_ph_price is not None and curr_price > prev_ph_price
            bars_btw = (src_idx - prev_ph_bar) if prev_ph_bar is not None else None
            if z_down and price_up and bars_btw is not None and RANGE_MIN <= bars_btw <= RANGE_MAX:
                bear_cond = True
            prev_ph_z, prev_ph_price, prev_ph_bar = curr_z, curr_price, src_idx

        if bull_cond:
            direction = "long"
        elif bear_cond:
            direction = "short"
        else:
            continue

        a_synth = atr_synth[i]
        if a_synth != a_synth:
            continue

        entry = float(close_np[i])
        sl = synthetic_stop(entry, float(a_synth), direction, SYNTHETIC_ATR_MULT)
        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=sl,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="mopeda_zscore_divergence", synthetic_stop=True,
        ))

    return signals
