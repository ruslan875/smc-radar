"""Port of "ATrPro" (source: ATrPro____.______..txt).

Pure candlestick-pattern signal, fully self-contained -- no other
sub-systems in this file to skip.

Entry logic:
  - Bullish (long): a bullish engulfing candle (`close[1] < open[1] and
    close > open and close > open[1]`), whose body is "stable" relative to
    its true range (`|close-open| / TR > candle_stability_index`, default
    0.5), RSI(14) below `rsi_index_param` (default 50), and the close is
    lower than it was `candle_delta_length_param` (default 5) bars ago
    (price has been decreasing into the reversal).
  - Bearish (short): symmetric -- bearish engulfing, stable body, RSI
    above `100 - rsi_index_param`, and close higher than
    `candle_delta_length_param` bars ago.

`barstate.isconfirmed` in the source just means "don't fire on the
still-forming live bar" -- every bar in our historical `df` is already a
closed/confirmed bar, so this is a no-op here and is omitted.

Not ported: all `disable_repeating_signals_param` label-dedupe cosmetics
and the label style/color options -- they only affect how the built-in
Pine `label.new` markers are drawn, never the underlying `bull`/`bear`
booleans that feed `alertcondition(bull, ...)` / `alertcondition(bear,
...)`, so skipping them doesn't drop any tradeable event.
"""
from __future__ import annotations

import pandas as pd

from .common import Signal, true_range, rsi, atr, synthetic_stop, SYNTHETIC_ATR_LEN

CANDLE_STABILITY_INDEX = 0.5
RSI_INDEX = 50
CANDLE_DELTA_LENGTH = 5


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    open_, high, low, close = df["open"], df["high"], df["low"], df["close"]

    tr = true_range(df)
    stable_candle = (close - open_).abs() / tr.replace(0, float("nan")) > CANDLE_STABILITY_INDEX
    rsi14 = rsi(close, 14)
    atr_series = atr(df, SYNTHETIC_ATR_LEN)

    prev_close, prev_open = close.shift(1), open_.shift(1)
    bullish_engulfing = (prev_close < prev_open) & (close > open_) & (close > prev_open)
    bearish_engulfing = (prev_close > prev_open) & (close < open_) & (close < prev_open)

    rsi_below = rsi14 < RSI_INDEX
    rsi_above = rsi14 > (100 - RSI_INDEX)
    decrease_over = close < close.shift(CANDLE_DELTA_LENGTH)
    increase_over = close > close.shift(CANDLE_DELTA_LENGTH)

    bull = bullish_engulfing & stable_candle & rsi_below & decrease_over
    bear = bearish_engulfing & stable_candle & rsi_above & increase_over

    signals: list[Signal] = []
    valid_from = max(CANDLE_DELTA_LENGTH, 14) + 1

    for i in range(valid_from, len(df)):
        is_bull = bool(bull.iloc[i]) if not pd.isna(bull.iloc[i]) else False
        is_bear = bool(bear.iloc[i]) if not pd.isna(bear.iloc[i]) else False
        if not (is_bull or is_bear):
            continue
        atr_v = atr_series.iloc[i]
        if pd.isna(atr_v):
            continue

        entry = float(close.iloc[i])
        direction = "long" if is_bull else "short"
        stop = synthetic_stop(entry, float(atr_v), direction)
        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=stop,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="atrpro", synthetic_stop=True,
        ))

    return signals
