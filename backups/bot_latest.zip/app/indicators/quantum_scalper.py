"""Port of "Quantum Scalper 5M" (source: QuantumScalper.txt).

Entry logic ("STRICT TOUCH & REJECT"): a bar's wick has to *touch* all
three of (fixed S/R from `lookback` bars confirmed `confirmBars` bars ago,
Bollinger Band, and the "Quantum Trend Flow" ATR/stdev channel) on one
side, then *close back on the other side* of all three -- a rejection
candle at confluent support/resistance. Direction flips are debounced by
`last_signal` so the same direction can't fire twice in a row without an
opposite signal first.

This is the ONLY indicator in the whole 24-file collection whose author
hard-coded a percentage SL/TP directly (rr_sl_pct=0.5%, rr_tp_pct=1.0%,
i.e. a fixed 1:2 R:R) -- ported verbatim, no synthetic stop needed.

Not ported: the entire "Swing Volume Profile" block bolted onto the back
half of the same file (lines ~269-684 of the source) -- it's a separate,
unrelated visualization tool with no bearing on the BUY/SELL signal or
the RR box, confirmed by reading through it (never referenced by
finalLong/finalShort/masterLong/masterShort). Also not ported: the
optional MTF trend filter (`useMTF`, default false in the source) --
implementing it would need a second, higher-timeframe fetch; since it's
off by default we replicate the default (mtf_check_long/short always
True) and note this here for anyone who wants to re-enable it.
"""
from __future__ import annotations

import pandas as pd

from .common import Signal, ema, atr, sma, stdev, rsi, highest, lowest

LOOKBACK = 50
CONFIRM_BARS = 2
BB_LENGTH = 15
BB_MULT = 2.0
QTF_LEN = 20
QTF_MULT = 2.0
SL_PCT = 0.5 / 100
TP_PCT = 1.0 / 100


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    high, low, close = df["high"], df["low"], df["close"]

    sr_high_fixed = highest(high, LOOKBACK).shift(CONFIRM_BARS)
    sr_low_fixed = lowest(low, LOOKBACK).shift(CONFIRM_BARS)

    bb_basis = sma(close, BB_LENGTH)
    bb_dev = BB_MULT * stdev(close, BB_LENGTH)
    bb_upper, bb_lower = bb_basis + bb_dev, bb_basis - bb_dev

    qtf_basis = ema(close, QTF_LEN)
    qtf_range = atr(df, QTF_LEN)
    qtf_dev = QTF_MULT * stdev(close, QTF_LEN)
    qtf_upper = qtf_basis + (qtf_range + qtf_dev) / 2
    qtf_lower = qtf_basis - (qtf_range + qtf_dev) / 2

    buy_touch = (low <= sr_low_fixed) & (low <= bb_lower) & (low <= qtf_lower)
    buy_reject = (close > sr_low_fixed) & (close > bb_lower) & (close > qtf_lower)
    master_long = buy_touch & buy_reject

    sell_touch = (high >= sr_high_fixed) & (high >= bb_upper) & (high >= qtf_upper)
    sell_reject = (close < sr_high_fixed) & (close < bb_upper) & (close < qtf_upper)
    master_short = sell_touch & sell_reject

    signals: list[Signal] = []
    last_signal = 0  # 0 = none, 1 = last fired was long, -1 = last fired was short
    valid_from = max(LOOKBACK + CONFIRM_BARS, BB_LENGTH, QTF_LEN) + 1

    for i in range(valid_from, len(df)):
        final_long = bool(master_long.iloc[i]) and last_signal != 1
        final_short = bool(master_short.iloc[i]) and last_signal != -1
        if not (final_long or final_short):
            continue

        entry = float(close.iloc[i])
        if final_long:
            last_signal = 1
            sl = entry * (1 - SL_PCT)
            tp = entry * (1 + TP_PCT)
            direction = "long"
        else:
            last_signal = -1
            sl = entry * (1 + SL_PCT)
            tp = entry * (1 - TP_PCT)
            direction = "short"

        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=sl,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=[tp], label="quantum_scalper", synthetic_stop=False,
        ))

    return signals
