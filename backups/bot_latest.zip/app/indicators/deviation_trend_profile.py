"""Port of "Deviation Trend Profile" (source: Deviation_Trend_Profile.txt).

The file has three parts:
  1. ATR-deviation bands (`stdv1..stdv3`, `stdv_1..stdv_3`) -- pure
     visualization (right-edge level lines), never referenced by any
     signal condition. Not ported.
  2. A "Trend Distribution Profile" histogram (`profile()`) -- pure
     visualization (boxes), not ported.
  3. A trend-direction state machine (`trend`) derived from the slope of
     the 50-SMA, and a QQE-based long/short signal optionally filtered by
     that trend state. THIS is what's ported below.

QQE ownership note: `app/indicators/qqe_signal.py` is the canonical QQE
port designated by the batch plan (see that module's own docstring,
which explicitly names this file as a module that must defer to it), so
this module reuses `qqe_signal.generate_signals(df)` directly instead of
re-implementing the RSI/ATR-band QQE construction. Concretely:
`qqe_signal.generate_signals(df)` already returns one `Signal` per QQE
long/short trigger bar (entry=close, a synthetic ATR stop, trigger_index/
trigger_time) -- we take that as the QQE trigger stream, apply this
file's own trend filter on top, and re-label the surviving signals
`"deviation_trend_profile"`.

Fidelity caveat: `qqe_signal.py`'s QQE was extracted from a DIFFERENT
source file (an "Adaptive Kalman Filter with Trend Signals" script) whose
QQE cross condition is `crossunder(RsiMa, longband[1])` /
`crossover(RsiMa, shortband[1])` (one-directional), whereas THIS file's
own inline QQE block uses `ta.cross(longband[1], RSIndex)` /
`ta.cross(RSIndex, shortband[1])` (bidirectional `ta.cross`, so it also
fires the case `crossover(RsiMa, longband[1])` / `crossunder(RsiMa,
shortband[1])` which the canonical module's one-directional check does
not). Per the batch instructions this file must defer to the canonical
module rather than keep its own slightly-different variant, so that
minor formula difference is accepted as the price of a single
non-duplicated QQE implementation across the collection, and is called
out here rather than silently glossed over.

Trend detection:
  - `avg` = SMA(close, 50); `avg_diff = avg - avg[5]`.
  - `avg_col = avg_diff / percentile_linear_interpolation(avg_diff, 500,
    100)`. The 100th percentile with linear interpolation is
    mathematically just the rolling maximum, so this is implemented as
    `avg_diff / highest(avg_diff, 500)`.
  - `trend` flips to `True` when `avg_col` crosses over 0.1 (while not
    already `True`), and to `False` when it crosses under -0.1 (while
    not already `False`). Fidelity note: Pine's `trend` starts as
    `bool(na)`, and `not na` is itself `na` (neither branch fires until
    `trend` has a concrete value at least once) -- a genuine Pine edge
    case at the very start of history with no clean causal equivalent.
    We resolve it pragmatically by treating an undefined `trend` as
    eligible to flip on the FIRST qualifying crossover in either
    direction (i.e. `not trend` / `trend` treated as vacuously
    satisfiable while `trend is None`); this only affects which of the
    first two crossovers (if any) is allowed to set the initial trend,
    with no effect once `trend` has been set at least once.

QQE + trend combination (matches source lines 150-198):
  - `useSignals` (default True) and `filterUse` (default True) gate the
    signal: when `filterUse` is on, a QQE long trigger only fires while
    `trend` is True, and a QQE short trigger only fires while `trend` is
    False.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .common import Signal, sma, highest
from .qqe_signal import generate_signals as _qqe_generate_signals

SMA_LENGTH = 50
TREND_DIFF_LOOKBACK = 5
TREND_PERCENTILE_LEN = 500
TREND_UP_THRESH = 0.1
TREND_DN_THRESH = -0.1

FILTER_USE = True
USE_SIGNALS = True


def _trend_series(close: pd.Series) -> pd.Series:
    avg = sma(close, SMA_LENGTH)
    avg_diff = avg - avg.shift(TREND_DIFF_LOOKBACK)
    denom = highest(avg_diff, TREND_PERCENTILE_LEN)
    avg_col = avg_diff / denom.replace(0, np.nan)

    cross_up = (avg_col.shift(1) < TREND_UP_THRESH) & (avg_col > TREND_UP_THRESH)
    cross_dn = (avg_col.shift(1) > TREND_DN_THRESH) & (avg_col < TREND_DN_THRESH)

    trend = np.empty(len(close), dtype=object)
    state = None
    for i in range(len(close)):
        up = bool(cross_up.iloc[i]) if not pd.isna(cross_up.iloc[i]) else False
        dn = bool(cross_dn.iloc[i]) if not pd.isna(cross_dn.iloc[i]) else False
        if up and state is not True:
            state = True
        elif dn and state is not False:
            state = False
        trend[i] = state
    return pd.Series(trend, index=close.index)


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    if not USE_SIGNALS:
        return []

    close = df["close"]
    trend = _trend_series(close)
    qqe_events = _qqe_generate_signals(df)

    signals: list[Signal] = []
    for sig in qqe_events:
        if FILTER_USE:
            t = trend.iloc[sig.trigger_index]
            if sig.direction == "long" and t is not True:
                continue
            if sig.direction == "short" and t is not False:
                continue

        signals.append(Signal(
            direction=sig.direction, entry=sig.entry, stop_loss=sig.stop_loss,
            trigger_index=sig.trigger_index, trigger_time=sig.trigger_time,
            take_profits=None, label="deviation_trend_profile", synthetic_stop=True,
        ))

    return signals
