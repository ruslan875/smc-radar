"""Port of the genuinely-new parts of ComboInd1 (source: 9292ef80-
ComboInd1.txt), a superset of JohnScript.

ComboInd1 = JohnScript's TAST table (lines 354-903, byte-identical) +
JohnScript's LuxAlgo Liquidity Swings (lines 904-1117, byte-identical) +
a brand-new "7-way selectable strategy engine" at the top of the file
(lines 1-352) that JohnScript does not have. It does NOT contain UT Bot
Alert at all. Per the batch plan: the TAST and LuxAlgo duplicates are
skipped here (see tast_composite.py / luxalgo_liquidity_swings.py, which
are the canonical copies), and only the 7-way engine is ported, one
function per strategy option, below.

The engine has two independent selector inputs plotted as separate
label sets:
  - `inputStrategy` (BUY/SELL labels): EMA/SMA, EMA/SMA TF based,
    Fractal Regular, Fractal Bill Williams, Percentage Price
    Oscillator, Hull Trend, Kaufman Adaptive Moving Average
  - `inputStrategyLongShort` (LONG/SHORT labels): DISABLED, ADX,
    Ichimoku_9-26-52, Ichimoku_10-30-60, Ichimoku_20-60-120

"EMA/SMA TF based" is NOT ported as a separate function: it's the exact
same `funcEmaSma` crossover logic as plain "EMA/SMA", just swapping in a
lookup table of MA lengths keyed by chart timeframe string (a cosmetic
parameter change, not new entry logic) -- `ema_sma_strategy()` below
takes the lengths as arguments so callers can reproduce the TF-based
variant by passing the Pine lookup table's values for their timeframe
if desired.

Each function below returns list[Signal] independently (this file is
"one function per strategy", not a single blended system) using the
same close-trigger-bar-entry + synthetic-stop convention as the rest of
the batch. `generate_signals(df)` is also provided, for
generic_backtest.py's auto-discovery, and simply runs every strategy at
its Pine-script defaults and concatenates the results with per-strategy
labels (so a single `--indicator comboind1_extra_strategies` run reports
all seven at once, distinguishable by `label`).
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .common import (
    Signal, ema, sma, rsi, highest, lowest, synthetic_stop, atr,
    SYNTHETIC_ATR_LEN,
)

# ---- EMA/SMA (default lengths) -------------------------------------------
EMASMA_BUY_LEN1, EMASMA_BUY_LEN2 = 14, 3
EMASMA_SELL_LEN1, EMASMA_SELL_LEN2 = 8, 1
EMASMA_THRESH_POS = 88
EMASMA_THRESH_NEG = -88

# ---- PPO -------------------------------------------------------------------
PPO_FAST, PPO_SLOW, PPO_SMOOTH = 12, 26, 2

# ---- KAMA -------------------------------------------------------------------
KAMA_FAST_LEN, KAMA_FAST_KAMA = 12, 2
KAMA_SLOW_LEN, KAMA_SLOW_KAMA = 26, 30
KAMA_SIGNAL_LEN = 9

# ---- Ichimoku ---------------------------------------------------------------
ICHI_CONFIGS = {
    "9-26-52": (9, 26, 52),
    "10-30-60": (10, 30, 60),
    "20-60-120": (20, 60, 120),
}
ICHI_RSI_LEN = 14
ICHI_RSI_OVERBOUGHT = 50
ICHI_RSI_OVERSOLD = 100

# ---- ADX long/short ----------------------------------------------------------
ADX_DI_LEN = 14
ADX_LEN = 13
ADX_THRESH = 20
ADX_DI_HIGHER_LOW_TREND = 40

# ---- Hull Trend ---------------------------------------------------------------
HULL_TREND_LEN = 30

# ---- Fractal ------------------------------------------------------------------
# (no parameters -- fixed 5-bar window)


def _emit(direction, entry_close, i, open_time, atr_synth, label) -> Signal | None:
    if pd.isna(atr_synth):
        return None
    entry = float(entry_close)
    sl = synthetic_stop(entry, float(atr_synth), direction)
    return Signal(direction=direction, entry=entry, stop_loss=sl,
                  trigger_index=i, trigger_time=open_time,
                  take_profits=None, label=label, synthetic_stop=True)


def _wma(series: pd.Series, length: float) -> pd.Series:
    length = max(1, int(round(length)))
    weights = np.arange(1, length + 1)
    return series.rolling(length, min_periods=length).apply(
        lambda x: np.dot(x, weights) / weights.sum(), raw=True)


def _crossover(a: pd.Series, b: pd.Series) -> pd.Series:
    return (a.shift(1) <= b.shift(1)) & (a > b)


def _crossunder(a: pd.Series, b: pd.Series) -> pd.Series:
    return (a.shift(1) >= b.shift(1)) & (a < b)


# --------------------------------------------------------------- 1. EMA/SMA

def ema_sma_strategy(df: pd.DataFrame, buy_len1: int = EMASMA_BUY_LEN1, buy_len2: int = EMASMA_BUY_LEN2,
                      sell_len1: int = EMASMA_SELL_LEN1, sell_len2: int = EMASMA_SELL_LEN2) -> list[Signal]:
    """`funcEmaSma`: a CCI-of-EMA ("TSI-like") trend line crossing its own
    4-bar SMA, gated by the trend line being in extreme (+-88) territory.
    Buy/sell are independent booleans in the original (not long/short),
    ported as independent long/short Signals here since that's this
    batch's convention."""
    src = df["close"]

    def _ci(length1, length2):
        esa = ema(src, length1)
        dev = ema((src - esa).abs(), length1)
        ci = (src - esa) / (0.015 * dev.replace(0, np.nan))
        trend_ema = ema(ci, length2)
        trend_sma = sma(trend_ema, 4)
        return trend_ema, trend_sma

    trend_ema_buy, trend_sma_buy = _ci(buy_len1, buy_len2)
    trend_ema_sell, trend_sma_sell = _ci(sell_len1, sell_len2)

    buy = _crossover(trend_ema_buy, trend_sma_buy) & (trend_ema_buy <= EMASMA_THRESH_NEG)
    sell = _crossunder(trend_ema_sell, trend_sma_sell) & (trend_ema_sell >= EMASMA_THRESH_POS)

    atr_synth = atr(df, SYNTHETIC_ATR_LEN)
    signals: list[Signal] = []
    for i in range(len(df)):
        if bool(buy.iloc[i]):
            sig = _emit("long", src.iloc[i], i, df["open_time"].iloc[i], atr_synth.iloc[i], "comboind1_ema_sma")
            if sig:
                signals.append(sig)
        if bool(sell.iloc[i]):
            sig = _emit("short", src.iloc[i], i, df["open_time"].iloc[i], atr_synth.iloc[i], "comboind1_ema_sma")
            if sig:
                signals.append(sig)
    return signals


# --------------------------------------------------------------- 2. PPO

def ppo_divergence_strategy(df: pd.DataFrame) -> list[Signal]:
    """`funcPPO`: fires on local min/max (turning points) of a smoothed
    Percentage Price Oscillator -- i.e. every PPO swing low is read as a
    buy trigger and every swing high as a sell trigger (the Pine source
    literally checks `valPPOdivergenceBull != 0`, which -- since the
    "divergence" value is just `valPPOresult[1]` whenever a min/max was
    just found -- fires on essentially every local turning point, not
    genuine price/oscillator divergence despite the variable names)."""
    src = df["close"]
    fast = ema(src, PPO_FAST)
    slow = ema(src, PPO_SLOW)
    macd2 = (fast - slow) / slow * 100
    result = sma(macd2, PPO_SMOOTH)

    osc_min = (result > result.shift(1)) & (result.shift(1) < result.shift(2))
    osc_max = (result < result.shift(1)) & (result.shift(1) > result.shift(2))

    atr_synth = atr(df, SYNTHETIC_ATR_LEN)
    signals: list[Signal] = []
    for i in range(len(df)):
        if bool(osc_min.iloc[i]) if not pd.isna(osc_min.iloc[i]) else False:
            sig = _emit("long", src.iloc[i], i, df["open_time"].iloc[i], atr_synth.iloc[i], "comboind1_ppo")
            if sig:
                signals.append(sig)
        if bool(osc_max.iloc[i]) if not pd.isna(osc_max.iloc[i]) else False:
            sig = _emit("short", src.iloc[i], i, df["open_time"].iloc[i], atr_synth.iloc[i], "comboind1_ppo")
            if sig:
                signals.append(sig)
    return signals


# --------------------------------------------------------------- 3. KAMA

def _kama_line(src: pd.Series, length: int, kama_fast: int, kama_slow: int) -> pd.Series:
    lag = (length - 1) // 2
    zero_lag_src = src + src - src.shift(lag)
    zero_lag_ema = ema(zero_lag_src, length)
    plain_ema = ema(src, length)
    volatility = src.diff().abs().rolling(length, min_periods=length).sum()
    er = (src - src.shift(length)).abs() / volatility.replace(0, np.nan)
    er = er.fillna(0.0)
    alpha = (er * (2 / (kama_fast + 1) - 2 / (kama_slow + 1)) + 2 / (kama_slow + 1)) ** 2

    kama = np.zeros(len(src))
    src_arr = src.to_numpy()
    alpha_arr = alpha.to_numpy()
    for i in range(len(src)):
        prev = kama[i - 1] if i > 0 else 0.0
        if np.isnan(alpha_arr[i]):
            kama[i] = prev
        else:
            kama[i] = prev + alpha_arr[i] * (src_arr[i] - prev)
    return zero_lag_ema, plain_ema, pd.Series(kama, index=src.index)


def kama_macd_strategy(df: pd.DataFrame) -> list[Signal]:
    """`funcKAMA`: averages three MACD-style lines (zero-lag-EMA diff,
    plain-EMA diff, and true adaptive-KAMA diff) into one "KAMA MACD",
    then trades its crossover with its own EMA signal line."""
    src = df["close"]
    fast_zl, fast_ema, fast_kama = _kama_line(src, KAMA_FAST_LEN, KAMA_FAST_KAMA, KAMA_SLOW_KAMA)
    slow_zl, slow_ema, slow_kama = _kama_line(src, KAMA_SLOW_LEN, KAMA_FAST_KAMA, KAMA_SLOW_KAMA)

    macd1 = fast_zl - slow_zl
    macd2 = fast_ema - slow_ema
    macd3 = fast_kama - slow_kama
    macd_avg = (macd1 + macd2 + macd3) / 3
    signal = ema(macd_avg, KAMA_SIGNAL_LEN)

    buy = _crossover(macd_avg, signal)
    sell = _crossunder(macd_avg, signal)

    atr_synth = atr(df, SYNTHETIC_ATR_LEN)
    signals: list[Signal] = []
    for i in range(len(df)):
        if bool(buy.iloc[i]) if not pd.isna(buy.iloc[i]) else False:
            sig = _emit("long", src.iloc[i], i, df["open_time"].iloc[i], atr_synth.iloc[i], "comboind1_kama")
            if sig:
                signals.append(sig)
        if bool(sell.iloc[i]) if not pd.isna(sell.iloc[i]) else False:
            sig = _emit("short", src.iloc[i], i, df["open_time"].iloc[i], atr_synth.iloc[i], "comboind1_kama")
            if sig:
                signals.append(sig)
    return signals


# --------------------------------------------------------------- 4. Ichimoku long/short

def ichimoku_longshort_strategy(df: pd.DataFrame, config: str = "9-26-52") -> list[Signal]:
    """`funcIchimoku`: Tenkan/Kijun cross, gated by Chikou-vs-cloud trend
    direction AND an RSI filter (note the Pine source's RSI thresholds
    are unusually loose -- overbought=50, oversold=100 -- so the RSI
    gate is nearly always satisfied; ported as-is)."""
    conv_len, base_len, span_len = ICHI_CONFIGS[config]
    high, low, src = df["high"], df["low"], df["close"]

    def donchian(length):
        return (lowest(low, length) + highest(high, length)) / 2

    tenkan = donchian(conv_len)
    kijun = donchian(base_len)
    span_a = (tenkan + kijun) / 2
    span_b = donchian(span_len)

    tenkan_line = tenkan.shift(base_len)
    kijun_line = kijun.shift(base_len)
    senkou_a = span_a.shift(base_len * 2)
    senkou_b = span_b.shift(base_len * 2)
    chiku = src

    ichi_min = pd.concat([senkou_a, senkou_b], axis=1).min(axis=1)
    ichi_max = pd.concat([senkou_a, senkou_b], axis=1).max(axis=1)
    up_trend = chiku > ichi_max
    down_trend = chiku < ichi_min

    bull = _crossover(tenkan_line, kijun_line)
    bear = _crossunder(tenkan_line, kijun_line)

    rsi_val = rsi(src, ICHI_RSI_LEN)
    long_ichi = bull & up_trend & (rsi_val <= ICHI_RSI_OVERSOLD)
    short_ichi = bear & down_trend & (rsi_val >= ICHI_RSI_OVERBOUGHT)

    atr_synth = atr(df, SYNTHETIC_ATR_LEN)
    signals: list[Signal] = []
    for i in range(len(df)):
        if bool(long_ichi.iloc[i]) if not pd.isna(long_ichi.iloc[i]) else False:
            sig = _emit("long", src.iloc[i], i, df["open_time"].iloc[i], atr_synth.iloc[i], f"comboind1_ichimoku_{config}")
            if sig:
                signals.append(sig)
        if bool(short_ichi.iloc[i]) if not pd.isna(short_ichi.iloc[i]) else False:
            sig = _emit("short", src.iloc[i], i, df["open_time"].iloc[i], atr_synth.iloc[i], f"comboind1_ichimoku_{config}")
            if sig:
                signals.append(sig)
    return signals


# --------------------------------------------------------------- 5. ADX long/short

def adx_longshort_strategy(df: pd.DataFrame) -> list[Signal]:
    """`funcAdxFinal`: a persistent +1/0/-1 counter that flips to +1 when
    ADX is trending (>=20) AND +DI/-DI both agree on direction AND the
    dominant DI is above a 40 "higher-low" threshold, flips to -1 on the
    symmetric bear case, and resets to 0 the bar the DI lines cross
    while the *previous* bar's directional read still held. Signal fires
    the bar the counter transitions 0->+-1."""
    from .common import true_range
    high, low = df["high"], df["low"]
    up = high.diff()
    down = -low.diff()
    plus_dm = np.where((up > down) & (up > 0), up, 0.0)
    minus_dm = np.where((down > up) & (down > 0), down, 0.0)
    plus_dm = pd.Series(plus_dm, index=df.index)
    minus_dm = pd.Series(minus_dm, index=df.index)
    from .common import rma
    tr_rma = rma(true_range(df), ADX_DI_LEN)
    di_plus = (100 * rma(plus_dm, ADX_DI_LEN) / tr_rma).ffill()
    di_minus = (100 * rma(minus_dm, ADX_DI_LEN) / tr_rma).ffill()

    total = (di_plus + di_minus).replace(0, 1.0)
    dx = (di_plus - di_minus).abs() / total * 100
    adx_val = 100 * rma(dx, ADX_LEN)

    di_cross = (_crossover(di_plus, di_minus) | _crossunder(di_plus, di_minus))
    adx_up = adx_val >= ADX_THRESH
    di_up = di_plus >= di_minus
    di_ups = di_plus >= ADX_DI_HIGHER_LOW_TREND
    di_down = di_minus > di_plus
    di_downs = di_minus >= ADX_DI_HIGHER_LOW_TREND

    buy_cond = adx_up & di_up & di_ups
    buy_close = di_cross & di_up.shift(1).fillna(False)
    sell_cond = adx_up & di_down & di_downs
    sell_close = di_cross & di_down.shift(1).fillna(False)

    counter = np.zeros(len(df), dtype=int)
    for i in range(1, len(df)):
        if bool(buy_close.iloc[i]) or bool(sell_close.iloc[i]):
            counter[i] = 0
        elif bool(buy_cond.iloc[i]) if not pd.isna(buy_cond.iloc[i]) else False:
            counter[i] = 1
        elif bool(sell_cond.iloc[i]) if not pd.isna(sell_cond.iloc[i]) else False:
            counter[i] = -1
        else:
            counter[i] = counter[i - 1]

    src = df["close"]
    atr_synth = atr(df, SYNTHETIC_ATR_LEN)
    signals: list[Signal] = []
    for i in range(1, len(df)):
        if pd.isna(atr_synth.iloc[i]):
            continue
        if counter[i] == 1 and counter[i - 1] == 0:
            sig = _emit("long", src.iloc[i], i, df["open_time"].iloc[i], atr_synth.iloc[i], "comboind1_adx_longshort")
            if sig:
                signals.append(sig)
        elif counter[i] == -1 and counter[i - 1] == 0:
            sig = _emit("short", src.iloc[i], i, df["open_time"].iloc[i], atr_synth.iloc[i], "comboind1_adx_longshort")
            if sig:
                signals.append(sig)
    return signals


# --------------------------------------------------------------- 6. Hull Trend

def hull_trend_strategy(df: pd.DataFrame, length: int = HULL_TREND_LEN) -> list[Signal]:
    """`funcHullTrend`: standard HMA vs a 3-stage "super-smoothed" HMA
    variant (`funcHullMovingAverage3`), buy/sell on their crossover."""
    src = df["close"]

    def hma(length):
        half = max(1, length // 2)
        return _wma(2 * _wma(src, half) - _wma(src, length), max(1, round(length ** 0.5)))

    def hma3(length):
        third = max(1, length // 2 // 3)
        half = max(1, length // 2 // 2)
        full = max(1, length // 2)
        return _wma(_wma(src, third) * 3 - _wma(src, half) - _wma(src, full), full)

    hull_a = hma(length)
    hull_b = hma3(length)

    buy = (hull_b > hull_a) & (hull_b.shift(1) < hull_a.shift(1))
    sell = (hull_a > hull_b) & (hull_a.shift(1) < hull_b.shift(1))

    atr_synth = atr(df, SYNTHETIC_ATR_LEN)
    signals: list[Signal] = []
    for i in range(len(df)):
        if bool(buy.iloc[i]) if not pd.isna(buy.iloc[i]) else False:
            sig = _emit("long", src.iloc[i], i, df["open_time"].iloc[i], atr_synth.iloc[i], "comboind1_hull_trend")
            if sig:
                signals.append(sig)
        if bool(sell.iloc[i]) if not pd.isna(sell.iloc[i]) else False:
            sig = _emit("short", src.iloc[i], i, df["open_time"].iloc[i], atr_synth.iloc[i], "comboind1_hull_trend")
            if sig:
                signals.append(sig)
    return signals


# --------------------------------------------------------------- 7. Fractal

def fractal_strategy(df: pd.DataFrame, variant: str = "regular") -> list[Signal]:
    """`funcFractalCalculated`: classic 5-bar Williams-style fractal,
    either the "Regular" strictly-decreasing/increasing variant or the
    "Bill Williams" (middle bar is the single extreme of the 5) variant.
    Confirmed 2 bars after the fractal's centre bar (bar[2]..bar[-2]
    window, all historical -- causal as coded, no future leakage since
    every index used is `[k]` i.e. `shift(k)`, k>=0)."""
    high, low, close = df["high"], df["low"], df["close"]

    h0, h1, h2, h3, h4 = high, high.shift(1), high.shift(2), high.shift(3), high.shift(4)
    l0, l1, l2, l3, l4 = low, low.shift(1), low.shift(2), low.shift(3), low.shift(4)

    if variant == "regular":
        fractal_high = (h4 < h3) & (h3 < h2) & (h2 > h1) & (h1 > h0)
        fractal_low = (l4 > l3) & (l3 > l2) & (l2 < l1) & (l1 < l0)
    else:  # "billwilliams"
        fractal_high = (h4 < h2) & (h3 < h2) & (h2 > h1) & (h2 > h0)
        fractal_low = (l4 > l2) & (l3 > l2) & (l2 < l1) & (l2 < l0)

    # buy = fractal_low (bullish reversal fractal), sell = fractal_high
    atr_synth = atr(df, SYNTHETIC_ATR_LEN)
    signals: list[Signal] = []
    for i in range(4, len(df)):
        if pd.isna(atr_synth.iloc[i]):
            continue
        if bool(fractal_low.iloc[i]):
            sig = _emit("long", close.iloc[i], i, df["open_time"].iloc[i], atr_synth.iloc[i], f"comboind1_fractal_{variant}")
            if sig:
                signals.append(sig)
        if bool(fractal_high.iloc[i]):
            sig = _emit("short", close.iloc[i], i, df["open_time"].iloc[i], atr_synth.iloc[i], f"comboind1_fractal_{variant}")
            if sig:
                signals.append(sig)
    return signals


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    """Runs every strategy at Pine-script defaults and concatenates the
    results (sorted by trigger bar) so this module is directly runnable
    via `generic_backtest.py --indicator comboind1_extra_strategies`.
    For per-strategy backtests, call the individual functions above."""
    all_signals: list[Signal] = []
    all_signals += ema_sma_strategy(df)
    all_signals += ppo_divergence_strategy(df)
    all_signals += kama_macd_strategy(df)
    all_signals += hull_trend_strategy(df)
    all_signals += fractal_strategy(df, "regular")
    all_signals += fractal_strategy(df, "billwilliams")
    all_signals += adx_longshort_strategy(df)
    all_signals += ichimoku_longshort_strategy(df, "9-26-52")
    all_signals.sort(key=lambda s: s.trigger_index)
    return all_signals
