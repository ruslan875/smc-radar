"""Port of "Liquidity Sweep, MSS & FVG Entry with SL/TP" (source:
Liquidity_Sweep_MSS__FVG_Entry.txt, Pine v6, indicator "ICT Entry Model").

A complete, self-contained ICT-style entry model -- one signal, four
stages, all defined by the original script itself (no synthetic stop
needed, unlike most of this collection):

    1. LIQUIDITY SWEEP -- price wicks through a confirmed swing high/low
       and closes back inside it (stop-run + rejection).
    2. MSS (Market Structure Shift) -- close breaks the nearest *internal*
       (short-term) swing the other way, confirming the reversal, within
       `maxWait` bars of the sweep.
    3. FVG ENTRY -- the 3-bar imbalance left by the displacement leg
       becomes the entry price (near edge of the gap); if no FVG formed,
       entry falls back to the MSS level itself.
    4. SL / TP -- stop is the sweep's extreme wick, target is a fixed R
       multiple (`rrMult`, default 2R) of that risk.

SETUP QUALITY 0-100 (sweep depth 30% + displacement strength 30% + FVG
size 25% + speed-of-shift 15%) is computed exactly as in the source and
stored in `Signal.meta["quality"]`, but `minQual` defaults to 0 in the
original (no setups are filtered by quality unless the user raises it),
so it is not used to drop signals here either -- kept available for
later analysis/filtering instead.

Non-repainting by construction: swings come from `ta.pivothigh/low`
(confirmed `right`-bar-delayed pivots, see common.pivothigh/low), and the
sweep/MSS/FVG state machine only evaluates closed-bar values -- ported
1:1 from the Pine bar-by-bar state machine (lines 71-299 of the source;
everything after that, the "clean candles" plot and the dashboard table,
is pure visualization and is not ported).

One setup can only be "in flight" at a time (state==0 idle / state==1
waiting for MSS) exactly as in the source -- a fresh sweep cannot start
while a previous one is still waiting for its MSS.
"""
from __future__ import annotations

import math

import pandas as pd

from .common import Signal, atr, pivothigh, pivotlow

PIV_LEN = 8          # "Liquidity swing length"
INT_LEN = 3           # "Internal structure length"
MAX_WAIT = 20         # "Max bars sweep -> MSS"
RR_MULT = 2.0         # "Take profit (R)"
MIN_RISK_ATR = 0.20   # "Min stop distance (x ATR)"
MIN_QUAL = 0          # "Hide setups below quality" (0 = no filtering, matches the source default)


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    high = df["high"].to_numpy()
    low = df["low"].to_numpy()
    close = df["close"].to_numpy()
    n = len(df)
    if n < 2 * PIV_LEN + 5:
        return []

    atr14 = atr(df, 14).to_numpy()

    ph = pivothigh(df["high"], PIV_LEN, PIV_LEN).to_numpy()
    pl = pivotlow(df["low"], PIV_LEN, PIV_LEN).to_numpy()
    iph = pivothigh(df["high"], INT_LEN, INT_LEN).to_numpy()
    ipl = pivotlow(df["low"], INT_LEN, INT_LEN).to_numpy()

    sw_high = sw_low = float("nan")
    int_high = int_low = float("nan")
    int_high_bar = int_low_bar = -1
    hi_taken = lo_taken = False

    state = 0
    direction = 0
    sweep_ext = sweep_bar = swept_lvl = float("nan")
    mss_level = float("nan")
    mss_lev_bar = -1
    waited = 0

    signals: list[Signal] = []

    for i in range(n):
        if not math.isnan(ph[i]):
            sw_high = ph[i]
            hi_taken = False
        if not math.isnan(pl[i]):
            sw_low = pl[i]
            lo_taken = False
        if not math.isnan(iph[i]):
            int_high = iph[i]
            int_high_bar = i - INT_LEN
        if not math.isnan(ipl[i]):
            int_low = ipl[i]
            int_low_bar = i - INT_LEN

        # -- stage 1: liquidity sweep --
        if state == 0:
            if (not math.isnan(sw_low) and not lo_taken and low[i] < sw_low and close[i] > sw_low
                    and not math.isnan(int_high) and int_high > close[i]):
                lo_taken = True
                state, direction = 1, 1
                sweep_ext, sweep_bar, swept_lvl = low[i], i, sw_low
                mss_level, mss_lev_bar = int_high, int_high_bar
                waited = 0
            elif (not math.isnan(sw_high) and not hi_taken and high[i] > sw_high and close[i] < sw_high
                    and not math.isnan(int_low) and int_low < close[i]):
                hi_taken = True
                state, direction = 1, -1
                sweep_ext, sweep_bar, swept_lvl = high[i], i, sw_high
                mss_level, mss_lev_bar = int_low, int_low_bar
                waited = 0
            continue

        # -- stage 2: MSS confirmation --
        waited += 1
        if waited > MAX_WAIT:
            state = 0
            continue

        mss_fired = False
        if direction == 1 and not math.isnan(mss_level) and close[i] > mss_level:
            mss_fired = True
        if direction == -1 and not math.isnan(mss_level) and close[i] < mss_level:
            mss_fired = True
        if not mss_fired:
            continue

        # -- stage 3: FVG search over the displacement leg --
        span = min(waited + 4, 18)
        fvg_t = fvg_b = None
        for j in range(0, span + 1):
            k = i - j
            if k - 2 < 0:
                break
            if direction == 1 and low[k] > high[k - 2]:
                fvg_t, fvg_b = low[k], high[k - 2]
                break
            if direction == -1 and high[k] < low[k - 2]:
                fvg_t, fvg_b = low[k - 2], high[k]
                break

        entry = (fvg_t if direction == 1 else fvg_b) if fvg_t is not None else mss_level
        sl = sweep_ext
        risk = abs(entry - sl)
        tp = entry + risk * RR_MULT if direction == 1 else entry - risk * RR_MULT

        a = max(atr14[i], 1e-9) if not math.isnan(atr14[i]) else 1e-9
        depth = abs(sweep_ext - swept_lvl) / a
        disp = abs(close[i] - mss_level) / a
        f_size = (abs(fvg_t - fvg_b) / a) if fvg_t is not None else 0.0
        q_sweep = min(1.0, depth / 0.45) * 100
        q_disp = min(1.0, disp / 1.20) * 100
        q_fvg = min(1.0, f_size / 0.40) * 100
        q_speed = max(0.0, 1.0 - waited / float(MAX_WAIT)) * 100
        qual = round(0.30 * q_sweep + 0.30 * q_disp + 0.25 * q_fvg + 0.15 * q_speed)

        valid = risk > a * MIN_RISK_ATR and ((entry > sl) if direction == 1 else (entry < sl))

        if qual >= MIN_QUAL and valid:
            signals.append(Signal(
                direction="long" if direction == 1 else "short",
                entry=float(entry), stop_loss=float(sl),
                trigger_index=i, trigger_time=df["open_time"].iloc[i],
                take_profits=[float(tp)], label="liquidity_sweep_mss_fvg",
                synthetic_stop=False,
                meta={"quality": qual, "has_fvg": fvg_t is not None},
            ))

        state = 0  # sequence complete either way (same as the Pine source)

    return signals
