"""Port of the Parabolic SAR flip from "4 EMAs, PSAR, VP, BB, RSI, MACD &
INFO BOX" / "9 indicators in 1 and more" (source: 9_indicators_in_1_and_
more.txt, lines 33-46). The source only calls Pine's built-in `ta.sar(0.02,
0.02, 0.2)` and colours the plotted dots by whether price is above or
below the line -- there is no explicit flip event or alertcondition in
the file, so the flip itself (the bar SAR crosses to the other side of
price) is this port's own, standard reading of what a PSAR system is for.

`ta.sar` is a Pine built-in (not custom code in the source), so this is a
straight implementation of the well-known Wilder Parabolic SAR algorithm
itself (acceleration factor ratchet, extreme-point tracking, stop-and-
reverse on the SAR line being crossed) -- the same public algorithm the
Pine built-in implements, not a guess at obfuscated custom logic.

**Native stop**: PSAR IS a stop-and-reverse trailing-stop system by
design -- the SAR value at the moment of the flip (the old extreme point,
which becomes the new SAR) is used directly as `Signal.stop_loss`, no
synthetic ATR stop needed. Take-profit is not something the source
defines (a real PSAR strategy would just ride until the next flip) -- for
comparability with the rest of the collection this falls back to the
project's standard 1R/2R/3R ladder rather than a dynamic flip-to-flip
exit, same simplification already applied to several other trend-follower
ports here.
"""
from __future__ import annotations

import pandas as pd

from .common import Signal

START = 0.02
INCREMENT = 0.02
MAX_AF = 0.2


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    high = df["high"].to_numpy()
    low = df["low"].to_numpy()
    close = df["close"].to_numpy()
    n = len(df)
    if n < 5:
        return []

    trend = 1
    ep = high[0]
    af = START
    sar = low[0]

    signals: list[Signal] = []

    for i in range(1, n):
        if trend == 1:
            cur_sar = sar + af * (ep - sar)
            cur_sar = min(cur_sar, low[i - 1], low[i - 2] if i >= 2 else low[i - 1])
            if high[i] > ep:
                ep = high[i]
                af = min(af + INCREMENT, MAX_AF)
            if low[i] < cur_sar:
                new_sar = ep
                trend = -1
                ep = low[i]
                af = START
                sar = new_sar
                entry = float(close[i])
                if entry < sar:
                    signals.append(Signal(
                        direction="short", entry=entry, stop_loss=float(sar),
                        trigger_index=i, trigger_time=df["open_time"].iloc[i],
                        take_profits=None, label="psar_flip", synthetic_stop=False,
                    ))
            else:
                sar = cur_sar
        else:
            cur_sar = sar - af * (sar - ep)
            cur_sar = max(cur_sar, high[i - 1], high[i - 2] if i >= 2 else high[i - 1])
            if low[i] < ep:
                ep = low[i]
                af = min(af + INCREMENT, MAX_AF)
            if high[i] > cur_sar:
                new_sar = ep
                trend = 1
                ep = high[i]
                af = START
                sar = new_sar
                entry = float(close[i])
                if entry > sar:
                    signals.append(Signal(
                        direction="long", entry=entry, stop_loss=float(sar),
                        trigger_index=i, trigger_time=df["open_time"].iloc[i],
                        take_profits=None, label="psar_flip", synthetic_stop=False,
                    ))
            else:
                sar = cur_sar

    return signals
