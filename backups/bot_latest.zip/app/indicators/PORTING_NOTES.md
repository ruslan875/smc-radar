# Porting notes

Python ports of 33 third-party Pine Script indicators (42 distinct
tradeable signals once bolted-on sub-systems are split out), collected
2026-08-18 through 2026-08-19, for fee-aware backtesting against Bybit
history with the same methodology as the repo's own SMC bot
(`app/smc.py`, `backtest.py`).

Every module lives in `app/indicators/` and exposes
`generate_signals(df) -> list[Signal]` (see `common.py`). Run
`python generic_backtest.py --list` for the discovered module names, or
`python compare_indicators.py` to backtest and rank all of them at once.

None of these indicators (except QuantumScalper and sr_range_module,
below) define a native stop-loss, so per the user's own risk rule
("stop-loss обязателен всегда, без исключений" -- see trader-profile.md
in the Claude project), every other module uses a synthetic stop:
`entry -/+ 1.5 * ATR(14)` (see `common.SYNTHETIC_ATR_MULT`/`SYNTHETIC_ATR_LEN`),
with `Signal.synthetic_stop = True` marking this. Take-profit defaults to
the same 1R/2R/3R ladder `backtest.py` already uses for the SMC bot
(`Signal.take_profits = None`).

## Fully native SL/TP (no synthetic stop needed)

- **`quantum_scalper.py`** -- QuantumScalper's own fixed 0.5%/1.0% SL/TP, ported verbatim. Skipped: the "Swing Volume Profile" block bolted onto the back half of the source file (unrelated visualization, confirmed unreferenced by the actual signal) and the MTF trend filter (off by default in the source).
- **`sr_range_module.py`** -- the range-detection + `calcSLTP` module from "Support/Resistance Re-test Finder", ATR-relative SL + 3-tier TP, ported verbatim. **Needs `--bars` comfortably above 2000** (the `r` band-width calc needs a full 2000-bar `sma` to produce a value at all) -- with under ~2000 bars it will report zero signals, which is expected, not a bug.

## Own defined exit, but no protective stop (synthetic stop layered on top)

- **`ml_lorentzian.py`** -- k-NN Lorentzian Classification with a custom HMA regime filter. Has its own real entry+exit rule (4-bar hold or opposite-signal flip), just no hard stop -- a synthetic ATR stop was added on top per the user's risk rule, and the module resolves its own trade outcome directly (see `meta["resolved_outcome"]`) rather than going through the generic touch-based TP scan, since a time-based exit isn't a price target. **Fidelity warning**: two Pine libraries this script imports (`jdehorty/MLExtensions`, `jdehorty/KernelFunctions`) aren't inlined in the source we have -- their internals (feature normalization, regime filter, kernel regression) were reconstructed from the publicly-documented versions of these libraries, not read verbatim. The k-NN core, custom regime filter, and entry/exit state machine ARE byte-faithful to the given source. Treat this as the lowest-confidence port in the collection.

## Everything else: synthetic ATR stop, default R-ladder TP

Grouped by what each module actually does; see each file's own docstring
for exact approximations.

**SMC/structure-style:** `alphax_structure_flow.py` (order-block + FVG +
liquidity-sweep engine), `tdz_pullback.py` / `tdz_range_signals.py` /
`tdz_swing_bos.py` / `tdz_qatl_mtf.py` (4 independent sub-signals from one
file; `tdz_qatl_mtf.py` approximates its HTF feed via causal resampling of
the same timeframe rather than a real multi-timeframe fetch), `sr_retest_finder.py`
(pivot-based S/R re-test state machine; direction mapping is our own
reasonable interpretation since the source never labels long/short).

**Trend/MA cross:** `ut_bot_alert.py` (canonical -- reused by
"OrderBlock with Signals", which was otherwise skipped as a pure
duplicate + informational-only order blocks), `g_channel_magic_trend.py`,
`ema_super_divergence.py`, `supertrend_relvolume.py` (KDE volume filter
approximated as an empirical-CDF, `isEma` confirmed dead code in the
original), `twin_range_signal.py`, `gradient_trend_filter.py` +
`hema_cross.py`, `adaptive_kalman_trend.py` (hand-verified 2x2 Kalman
matrix math against a numpy reference), `kalman_trend_strength_oscillator.py`
(approximated as a zero-cross, source has no native discrete signal),
`channel_breakout.py`, `ml_supertrend_cluster.py` (5-member weighted
consensus), `ml_supertrend_volume_profile_mtf.py` (5-HTF volume profile
dropped, not itself an entry rule).

**Oscillator/mean-reversion:** `extreme_reversal.py`,
`two_pole_filter_signal.py` (canonical, extracted from Extreme Reversal --
also used by two other files), `qqe_signal.py` (canonical, extracted from
the Kalman Trend Strength Oscillator file -- also reused by Deviation
Trend Profile), `deviation_trend_profile.py`, `double_vortex.py`,
`atrpro.py`, `ewa_profit_ssl.py`, `volatility_reversion_zones.py` (4H
trend label confirmed display-only, not gating the signal),
`parad_rsi.py` / `parad_wt.py` / `parad_osc.py` (single-timeframe only --
the original's 14-timeframe confluence scan is explicitly NOT replicated).

**Composite/voting:** `tast_composite.py` (32-vote table; cross-market
inputs replaced with the entry timeframe's own OHLCV, Bull/Bear Power
uses the textbook Elder formula rather than transcribing obfuscated
ternaries), `luxalgo_liquidity_swings.py` (original is display-only --
approximated as a liquidity-sweep reversal read, documented as our
interpretation), `comboind1_extra_strategies.py` (7 selectable strategy
variants from ComboInd1's own engine, after confirming its TAST/LuxAlgo
sections are byte-identical duplicates of JohnScript).

## Confirmed pure visualization / no tradeable signal -- not ported

- `ComboInd2` -- ADX/MACD footer, no `alertcondition` anywhere.
- `CM_Twiggs Money Flow` -- oscillator only, `overlay=false`, no signal condition.
- `OrderBlock with Signals Buy|Sell` -- signal is a duplicate of `ut_bot_alert.py`; the order blocks themselves are informational only.

## Known duplicate logic (ported once, reused)

- UT Bot Alert: JohnScript, ComboInd1, "OrderBlock with Signals" -> canonical `ut_bot_alert.py`.
- TAST + LuxAlgo Liquidity Swings: JohnScript, ComboInd1 -> canonical `tast_composite.py` / `luxalgo_liquidity_swings.py`.
- Two-pole filter streak: Extreme Reversal, Kalman oscillator file, Zero Lag Signals -> canonical `two_pole_filter_signal.py`. (Zero Lag Signals For Loop itself was assigned in the original triage but consolidated into this shared module rather than getting its own file -- its unique for-loop trend score, if wanted standalone later, is a small addition on top of `two_pole_filter_signal.py`.)
- QQE construction: Kalman Trend Strength Oscillator file, Deviation Trend Profile -> canonical `qqe_signal.py`.

## 2026-08-19 batch (4 new modules, from this session's uploads)

- **`liquidity_sweep_mss_fvg.py`** -- "Liquidity Sweep, MSS & FVG Entry with SL/TP" (ICT Entry Model). Fully native SL/TP like `quantum_scalper.py`/`sr_range_module.py` -- no synthetic stop. Complete 4-stage state machine (sweep -> MSS -> FVG entry -> fixed-R target), setup quality 0-100 stored in `meta["quality"]` but not used to filter (matches the source's own `minQual=0` default).
- **`ai_vanga_trend_flip.py`** -- the ATR-envelope trend-flip half of "AI_Vanga Forecast Line + ATR Fibonacci Trend Envelopes". The "Forecast Line" half of that file is `barstate.islast`-only random-walk visualization and was not ported (Category D). Synthetic ATR stop (the envelope itself is a trend filter, not a risk level).
- **`custom_hybrid_ema_cross.py`** -- the Dual EMA (12/6) cross from "Custom Hybrid Indicator with Lines". The file's linear-regression channel, volume-surge bubbles and "whale" markers are all pure visualization/no-signal and were not ported. **Note the source's own labels are inverted from the textbook direction** (bullish 12-over-6 cross is plotted "SELL", bearish cross "BUY") -- ported literally per the source's own alert text rather than "corrected", same principle as flagging (not silently fixing) the MELONA combo's mislabelled alert below. Synthetic ATR stop.
- **`blackflag_fts_fib_entry.py`** -- the "Blackflag FTS" ATR-chandelier + Fibonacci-pullback entry system, one of several sub-scripts bundled in the COMBOV6RUS / "Algo & Blackflag FTS & Daily Volume Profile" mega-file (the two uploads are byte-identical, ported once). Native stop (the chandelier trailing-stop line itself). Three independent fib-retracement entries (61.8/78.6/88.6%) per trend leg, each its own `Signal.label`. The same mega-file's "Algo V.12" range-filter signal was judged a duplicate of the already-ported `twin_range_signal.py` family and its S/R alerts overlap `sr_retest_finder.py`, so neither was re-ported; the "Daily Volume Profile" section (POC/VAH/VAL touches) was not fully re-read this round and is a candidate for a future batch if wanted.

Not ported this round (flagged, not forgotten): the "MELONA OB, OPFX ZONA PREMIUM" mega-combo (~9 constituent sub-scripts, several genuinely tradeable -- MELONA's pressure order-block detector, OPFX's TASDIQ zone-confluence entry -- but large enough that porting all of it in one pass without the ability to test in this sandbox first risked more bugs than value; say the word and it's next).

## 2026-08-19 batch 3 (5 new modules, from "9 indicators in 1 and more")

Source: "4 EMAs, PSAR, VP, BB, RSI, MACD & INFO BOX" / "9 indicators in 1
and more" -- a dashboard combo with **zero `alertcondition`s anywhere in
the file**. Every signal below is this project's own reasonable reading
of a classic, well-known TA construct bundled into the dashboard, not
something the source itself defines as a trade signal -- documented as
such in each module's own docstring.

- **`psar_flip.py`** -- Parabolic SAR (0.02/0.02/0.2) flip. **Native stop**: the SAR line itself is a stop-and-reverse system by design, so the post-flip SAR value is used directly as `Signal.stop_loss` -- the fourth module in the whole collection with a real native stop, alongside `quantum_scalper.py`, `sr_range_module.py` and `liquidity_sweep_mss_fvg.py`.
- **`ema_cross_small.py`** -- EMA(10)/EMA(21) cross ("small cross" in the source). Standard, correctly-labelled direction (unlike `custom_hybrid_ema_cross.py`'s inverted labels). Synthetic ATR stop.
- **`ema_cross_golden.py`** -- EMA(55)/EMA(200) cross, the classic golden/death cross. Same source file as `ema_cross_small.py`, kept as a separate module so the two pairs can be compared independently. Synthetic ATR stop.
- **`macd_hist_flip.py`** -- MACD(12,26,9) histogram zero-cross. The source only displays a static Bullish/Bearish text based on the current sign; the flip event itself is this port's own standard MACD rule. Synthetic ATR stop.
- **`rsi_extreme_reversal.py`** -- RSI(14) crossing above 70 / below 30, read as a mean-reversion fade (short the overbought cross, long the oversold cross). The source only flashes a warning label at these levels, doesn't define a direction -- same "our own interpretation" caveat as `sr_retest_finder.py`. Synthetic ATR stop.

Not ported from the same file: Bollinger Bands (plot-only, no signal), Volume Profile (`barstate.islast`-only, non-deterministic bar-to-bar, same Category-D reasoning as the AI_Vanga forecast line and MELONA's VP block), and the info-box label itself (pure text/visualization, external-ticker `request.security` calls for CCL/DXY/Gold/Silver/dominance have no bearing on any of the above signals).

## 2026-08-20 batch 4 (5 new modules, from "MoPeDa.net" v2.0)

Source: `MoPeDa.net.txt`, a large combo indicator (HTF candle overlay,
FVG imbalances, volume profile + initial balance, ADX-adaptive Bollinger
entry zones, wick-rejection signals, two independent divergence
detectors, S/R levels, dashboard) with **11 real `alertcondition`s** --
more genuine signal candidates in one file than any prior batch. Ported
the 10 alertconditions that have a clear direction (5 bull/bear pairs);
the 11th (`isSqueeze and not isSqueeze[1]`, "Squeeze Started") is
direction-less -- a volatility-regime flag, not an entry signal -- and
was not ported as its own tradeable module.

- **`mopeda_zone_entry.py`** -- "Buy/Sell Signal": price *entering* an ADX-adaptive Bollinger zone (BB(24, 1.4σ) widened by ADX(20,30), 20-bar cooldown per side). **Canonical**: exports `compute_zones()`, reused by `mopeda_wick_signal.py` below. Synthetic ATR stop.
- **`mopeda_wick_signal.py`** ("MoPeD Wick Signals") -- long rejection wick (≥25% of candle range) touching the same zones from `mopeda_zone_entry.py`, 6-bar cooldown. Different trigger condition than zone-entry (wick touch, not close-inside). Synthetic ATR stop.
- **`mopeda_wick_pressure_sidd.py`** ("Wick Pressure (SiddWolf)") -- independent of the zone logic: a tight 3-candle cluster of rejection wicks near the same level (bodies clustered, wicks extending ≥0.35×ATR beyond), confirmed by RSI oversold/overbought in the last 3 bars. No cooldown in the source. The source only draws a visual pressure box (no entry price defined) -- market entry at signal-bar close is this port's own interpretation, flagged same as `sr_retest_finder.py`. Synthetic ATR stop.
- **`mopeda_zscore_divergence.py`** ("Bullish/Bearish Divergence", 𝓤𝓹/𝓓𝓸𝔀𝓷 labels) -- composite: RSI + StochRSI-of-RSI + MACD-line each z-scored (100-bar) and averaged, EMA(10)-smoothed, then classic pivot divergence (15/1 pivot lookback, 5-60 bars between pivots) read off that composite line vs. price. Synthetic ATR stop.
- **`mopeda_rsi_tt_divergence.py`** ("RSI Bullish/Bearish Div") -- a SECOND, separate divergence detector in the same file: plain RSI(24) regular divergence via `ta.valuewhen`-style pivot comparison (6/6 pivot lookback). Required adding generic `barssince()`/`valuewhen()` helpers to `common.py` (Pine built-ins with no prior equivalent in this collection) -- reusable for any future indicator with the same construct. Synthetic ATR stop.

Not ported from the same file (all pure visualization / non-deterministic, same Category-D reasoning used throughout this project): HTF candle overlay, FVG imbalance boxes, volume profile + POC/VAH/VAL/naked-POC (`barstate.islast`-only), Initial Balance box, S/R pivot lines, correction zones, dashboard table, watermark.

## 2026-08-20 batch 5 (1 new module, hand-built, not a port)

Source: category 4 ("Anchored VWAP / session VWAP") of
`next-gen-indicator-research-2026-08-20.md`, the doc a research agent
produced after the whole 49-module ported collection + confluence
combiner + next-gen combo (session filter / funding-OI filter / squeeze
breakout, all closed net-negative or split-sample-refuted) ran out of
untested candidates. Unlike everything above, this is **not a port of any
specific TradingView script** -- the two scripts the research doc cited
(open-source "Anchored VWAP" and Zeiierman's "Dynamic Swing Anchored
VWAP STRAT") weren't available to read source-for-source, so this module
is this project's own construction of the standard, well-documented
VWAP-sweep-and-reclaim concept. Flagged the same way `sr_retest_finder.py`
and `rsi_extreme_reversal.py` flag their own "our reading of a classic
construct, not a verified line-by-line port" status.

- **`anchored_vwap_reclaim.py`** -- daily-UTC-session VWAP (cumulative
  typical-price*volume / cumulative volume, reset at 00:00 UTC). Long
  when price dipped >=0.5 ATR below VWAP within the last 6 bars (a real
  sweep, not a brush) and then closes back above VWAP; short is the
  mirror image. Stop is derived from the actual sweep extreme (+/- a
  0.25 ATR buffer), same "structure-derived stop" idea as
  `liquidity_sweep_mss_fvg.py`'s sweep-extreme stop -- not a plain
  synthetic entry-minus-ATR stop, though still flagged
  `synthetic_stop=True` since there's no author-defined risk rule being
  copied. Smoke-tested clean on synthetic data (238 signals / 4000 bars,
  balanced long/short, cooldown respected, no bad values) -- **not yet
  backtested on real Bybit data**, same caveat as every module below.

Genuinely new mechanism vs. everything else in the collection: VWAP is
volume-weighted and continuously re-anchored per session, unlike any
swing-structure zone, Bollinger band, or price-only oscillator already
tested. Per the research doc's own honest read, expect a similar failure
mode to the SMC bot's own zone logic (works as S/R in trend, whipsaws in
range) -- this is a real test of that prediction, not an assumption it'll
finally be the one that works.

Remaining untested candidates from the same research doc: LuxAlgo's
"Smart Money Concepts" script (category 5) -- deprioritized because the
actual source wasn't available to port faithfully, and a from-scratch
reconstruction would closely duplicate logic this project's own
`app/smc.py` already implements and has already tested exhaustively (see
`smc-bot-backtest-2026-08-17.md`), so the marginal value of guessing at
LuxAlgo's specific mitigation/invalidation rules without the real source
is low relative to the risk of quietly re-testing the same thing under a
new name.

## How to actually run this

This sandbox has no outbound network access to Bybit, so nothing above
has been backtested on real data yet -- only smoke-tested on synthetic
random-walk OHLCV to catch crashes/bad values (all 50 modules pass clean,
2026-08-20). On your own machine, with the repo's existing `requirements.txt`:

    python compare_indicators.py --bars 3000

This runs every indicator across `watchlist.json`'s symbols, prints a
ranked table (net R after taker+taker/taker+maker/maker+maker fees, win
rate), and writes per-indicator trade CSVs to `generic_backtest_out/`. Use
`--indicators quantum_scalper sr_range_module ml_lorentzian` to run just
the three highest-confidence candidates first.
