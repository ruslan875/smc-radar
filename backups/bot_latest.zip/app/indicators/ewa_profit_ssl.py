"""Port of "EWA_Profit_Day_Round_level" (source:
EWA_Profit_Day_Round_level_27_11_2024.txt).

The file bundles a lot of visual-only machinery: SSL1 (`Hlv`/`emaHigh`/
`emaLow`, HMA length 60) and SSL2 (`Hlv2`/`maHigh`/`maLow`, JMA length 5)
channels, a Keltner "Baseline" channel, Heikin-Ashi smoothed candles, and
a round-level price grid. NONE of these feed the only two actual signal
conditions in the script (`isBuy`/`isSell`) -- verified by tracing every
reference to `Hlv`/`Hlv2`/`BBMC`/`upper_band`/`lower_band`/`haclose`/
`roundLevel*`, none of which appear in the `isBuy`/`isSell` expressions.
Only the "EXIT" SSL channel (`Hlv3`/`ExitHigh`/`ExitLow`, `SSL3Type` =
HMA, `len3` = 15) and the Williams %R + LSMA block feed the real signal,
so that's all that's ported here.

Entry logic:
  - `sslExit` = HMA(15) of `high`/`low`, tracked with the same
    "sticky state" pattern used by the S/R re-test logic elsewhere in
    this collection: `Hlv3` flips to `+1` when close > ExitHigh, `-1`
    when close < ExitLow, and otherwise holds its last value.
    `sslExit = ExitHigh if Hlv3 < 0 else ExitLow` (ported literally, even
    though the naming reads backwards -- this is exactly what the Pine
    source computes).
  - `codiff` = `+1` the bar `close` crosses over `sslExit`, `-1` the bar
    it crosses under, else undefined (NOT held between bars -- it's a
    fresh ternary every bar in the source, so it's only ever meaningful
    on the crossing bar itself).
  - Williams %R (`outputW`, length 21) vs its own 13-EMA (`emaW`).
  - `isBuy = crossover(outputW, emaW) and (lsma > lsma[1] or not
    UseLSMA) and codiff == 1`; `isSell` is the mirror image with
    `crossunder` and `codiff == -1`.
  - `UseLSMA` defaults to `false` in the source, so the LSMA
    (`ta.linreg(close, 25, 0)`) term is always true by default and the
    condition reduces to the Williams %R cross gated by the SSL-exit
    cross direction. LSMA is still computed and the `USE_LSMA` constant
    below can be flipped to `True` to re-enable that filter, matching
    the source's toggle.

HMA is implemented locally (`_hma`/`_wma`) since `common.py` has no WMA
primitive; `half_length = round(length/2)`, `sqrt_length =
round(sqrt(length))`, matching the standard community HMA formula the
source's own `ma(type, src, len)` dispatcher uses for `type == 'HMA'`.

Not ported (confirmed visual-only, no bearing on isBuy/isSell): SSL1,
SSL2, the Keltner baseline/`candlesize_violation`, the Heikin-Ashi
smoothed-candle overlay, and the round-level price grid.
"""
from __future__ import annotations

import math

import numpy as np
import pandas as pd

from .common import Signal, ema, atr, synthetic_stop, SYNTHETIC_ATR_LEN

LEN3 = 15  # EXIT SSL channel length (HMA)
LENGTH_W = 21  # Williams %R length
EMA_W_LEN = 13
LSMA_LENGTH = 25
USE_LSMA = False  # matches the source's `UseLSMA` default (false)


def _wma(series: pd.Series, length: int) -> pd.Series:
    weights = np.arange(1, length + 1, dtype=float)  # oldest=1 ... newest=length

    def _w(x: np.ndarray) -> float:
        return float(np.dot(x, weights) / weights.sum())

    return series.rolling(length, min_periods=length).apply(_w, raw=True)


def _hma(series: pd.Series, length: int) -> pd.Series:
    half_length = max(1, round(length / 2))
    sqrt_length = max(1, round(math.sqrt(length)))
    raw = 2 * _wma(series, half_length) - _wma(series, length)
    return _wma(raw, sqrt_length)


def _linreg(series: pd.Series, length: int) -> pd.Series:
    """Pine's ta.linreg(src, length, offset=0): fitted regression value at
    the current (rightmost) bar of a rolling window."""
    x = np.arange(length, dtype=float)
    x_mean = x.mean()
    denom = ((x - x_mean) ** 2).sum()

    def _f(y: np.ndarray) -> float:
        y_mean = y.mean()
        slope = ((x - x_mean) * (y - y_mean)).sum() / denom
        intercept = y_mean - slope * x_mean
        return intercept + slope * x[-1]

    return series.rolling(length, min_periods=length).apply(_f, raw=True)


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    high, low, close = df["high"], df["low"], df["close"]

    exit_high = _hma(high, LEN3)
    exit_low = _hma(low, LEN3)

    # Sticky Hlv3 state: +1 once close>exit_high, -1 once close<exit_low,
    # else carries the last defined value forward (Pine's `Hlv3[1]`).
    raw_state = pd.Series(np.nan, index=df.index)
    raw_state[close > exit_high] = 1.0
    raw_state[close < exit_low] = -1.0
    hlv3 = raw_state.ffill()

    ssl_exit = exit_high.where(hlv3 < 0, exit_low)

    codiff_up = (close.shift(1) < ssl_exit.shift(1)) & (close > ssl_exit)
    codiff_dn = (close.shift(1) > ssl_exit.shift(1)) & (close < ssl_exit)

    upper_w = high.rolling(LENGTH_W, min_periods=LENGTH_W).max()
    lower_w = low.rolling(LENGTH_W, min_periods=LENGTH_W).min()
    output_w = 100 * (close - upper_w) / (upper_w - lower_w)
    ema_w = ema(output_w, EMA_W_LEN)

    wcross_up = (output_w.shift(1) < ema_w.shift(1)) & (output_w > ema_w)
    wcross_dn = (output_w.shift(1) > ema_w.shift(1)) & (output_w < ema_w)

    lsma = _linreg(close, LSMA_LENGTH)
    lsma_rising = lsma > lsma.shift(1)
    lsma_falling = lsma < lsma.shift(1)

    is_buy = wcross_up & (lsma_rising | (not USE_LSMA)) & codiff_up
    is_sell = wcross_dn & (lsma_falling | (not USE_LSMA)) & codiff_dn

    atr_series = atr(df, SYNTHETIC_ATR_LEN)
    signals: list[Signal] = []
    valid_from = max(LEN3 * 2, LENGTH_W, LSMA_LENGTH) + 2

    for i in range(valid_from, len(df)):
        buy = bool(is_buy.iloc[i]) if not pd.isna(is_buy.iloc[i]) else False
        sell = bool(is_sell.iloc[i]) if not pd.isna(is_sell.iloc[i]) else False
        if not (buy or sell):
            continue
        atr_v = atr_series.iloc[i]
        if pd.isna(atr_v):
            continue

        entry = float(close.iloc[i])
        direction = "long" if buy else "short"
        stop = synthetic_stop(entry, float(atr_v), direction)
        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=stop,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="ewa_profit_ssl", synthetic_stop=True,
        ))

    return signals
