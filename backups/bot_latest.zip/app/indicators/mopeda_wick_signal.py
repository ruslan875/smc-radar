"""Port of the "MoPeD Bullish/Bearish Wick" alertconditions from
"MoPeDa.net" v2.0 (source lines 920-936, 1147-1148) -- a wick-rejection
signal layered on the SAME ADX-adaptive Bollinger zones as
`mopeda_zone_entry.py` (imports `compute_zones` from there rather than
recomputing it). Different trigger than the zone-entry signal: this one
requires an actual long wick touching (but not breaking out past) the
zone, not just price closing inside it.

    lowerWickPct = (min(open,close) - low) / (high - low) * 100
    upperWickPct = (high - max(open,close)) / (high - low) * 100

    wickBullCondition = priceInBottomZone
                         and low < bottomZoneTop and low > bottomZoneBottom
                         and lowerWickPct >= 25            // minWickPercent
                         and (bar_index - lastWickBuyBar >= 6)   // wickCooldown
                         -> BUY (long)
    wickBearCondition = priceInTopZone
                         and high > topZoneBottom and high < topZoneTop
                         and upperWickPct >= 25
                         and (bar_index - lastWickSellBar >= 6)
                         -> SELL (short)

Entry = close of the signal bar (market), no native stop in the source
(pure alert indicator) -- synthetic ATR(14) stop + default 1R/2R/3R ladder
per the batch convention.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .common import Signal, atr, synthetic_stop, SYNTHETIC_ATR_LEN, SYNTHETIC_ATR_MULT
from .mopeda_zone_entry import compute_zones, SMOOTH_LENGTH, BB_LENGTH

MIN_WICK_PERCENT = 25.0
WICK_COOLDOWN = 6


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    n = len(df)
    if n < SMOOTH_LENGTH + BB_LENGTH + 5:
        return []

    high = df["high"].to_numpy()
    low = df["low"].to_numpy()
    open_ = df["open"].to_numpy()
    close = df["close"].to_numpy()
    candle_range = high - low
    lower_wick = np.minimum(open_, close) - low
    upper_wick = high - np.maximum(open_, close)
    with np.errstate(invalid="ignore", divide="ignore"):
        lower_wick_pct = np.where(candle_range > 0, lower_wick / candle_range * 100, 0.0)
        upper_wick_pct = np.where(candle_range > 0, upper_wick / candle_range * 100, 0.0)

    zones = compute_zones(df)
    price_in_top = zones["price_in_top_zone"].to_numpy()
    price_in_bottom = zones["price_in_bottom_zone"].to_numpy()
    top_zone_bottom = zones["top_zone_bottom"].to_numpy()
    top_zone_top = zones["top_zone_top"].to_numpy()
    bottom_zone_top = zones["bottom_zone_top"].to_numpy()
    bottom_zone_bottom = zones["bottom_zone_bottom"].to_numpy()

    atr_synth = atr(df, SYNTHETIC_ATR_LEN).to_numpy()

    signals: list[Signal] = []
    last_wick_buy_bar = -999
    last_wick_sell_bar = -999

    for i in range(n):
        def valid(x):
            return x == x  # not NaN

        wick_bull = (
            bool(price_in_bottom[i]) and valid(bottom_zone_top[i]) and valid(bottom_zone_bottom[i])
            and low[i] < bottom_zone_top[i] and low[i] > bottom_zone_bottom[i]
            and lower_wick_pct[i] >= MIN_WICK_PERCENT
            and (i - last_wick_buy_bar >= WICK_COOLDOWN)
        )
        wick_bear = (
            bool(price_in_top[i]) and valid(top_zone_bottom[i]) and valid(top_zone_top[i])
            and high[i] > top_zone_bottom[i] and high[i] < top_zone_top[i]
            and upper_wick_pct[i] >= MIN_WICK_PERCENT
            and (i - last_wick_sell_bar >= WICK_COOLDOWN)
        )

        if wick_bull:
            last_wick_buy_bar = i
        if wick_bear:
            last_wick_sell_bar = i

        direction = "long" if wick_bull else ("short" if wick_bear else None)
        if direction is None:
            continue

        a_synth = atr_synth[i]
        if a_synth != a_synth:
            continue

        entry = float(close[i])
        sl = synthetic_stop(entry, float(a_synth), direction, SYNTHETIC_ATR_MULT)
        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=sl,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="mopeda_wick_signal", synthetic_stop=True,
        ))

    return signals
