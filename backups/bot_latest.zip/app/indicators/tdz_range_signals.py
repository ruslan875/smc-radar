"""Port of Module 2 ("Range Signals") from TDZPullback.txt (source lines
~184-220, labeled in the original "второй индикатор - оставлен без
изменений" / "second indicator, left unchanged" -- a separate bolted-on
script). See tdz_pullback.py's module docstring for how this file relates
to the other three TDZ sub-modules.

Detects abnormally wide-range candles that sweep a recent high/low and
close back near the opposite extreme of their own range -- a false
breakout / momentum exhaustion pattern:

    avrange = ta.sma(high - low, malen)
    longsig  = (high-low) >= avrange*mult
               and low  < ta.lowest(low[1],  lookback)
               and close >= high - (high-low)*rangethreshold
    shortsig = (high-low) >= avrange*mult
               and high > ta.highest(high[1], lookback)
               and close <= low  + (high-low)*rangethreshold

Ported verbatim, all default inputs preserved. Not ported: the optional
bar/candle coloring and the highest/lowest tracking plots -- pure
visualization.
"""
from __future__ import annotations

import pandas as pd

from .common import Signal, sma, highest, lowest, atr, synthetic_stop, SYNTHETIC_ATR_LEN, SYNTHETIC_ATR_MULT

LOOKBACK = 20
MA_LEN = 20
RANGE_MULT = 1.5
RANGE_THRESHOLD = 0.50  # 50%


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    high, low, close = df["high"], df["low"], df["close"]
    candle_range = high - low

    avrange = sma(candle_range, MA_LEN)
    wide_enough = candle_range >= (avrange * RANGE_MULT)

    prev_low_lowest = lowest(low.shift(1), LOOKBACK)
    prev_high_highest = highest(high.shift(1), LOOKBACK)

    longsig = wide_enough & (low < prev_low_lowest) & (close >= (high - candle_range * RANGE_THRESHOLD))
    shortsig = wide_enough & (high > prev_high_highest) & (close <= (low + candle_range * RANGE_THRESHOLD))

    synth_atr = atr(df, SYNTHETIC_ATR_LEN)

    signals: list[Signal] = []
    for i in range(len(df)):
        is_long = bool(longsig.iloc[i]) if not pd.isna(longsig.iloc[i]) else False
        is_short = bool(shortsig.iloc[i]) if not pd.isna(shortsig.iloc[i]) else False
        if not (is_long or is_short):
            continue
        synth = synth_atr.iloc[i]
        if pd.isna(synth):
            continue

        entry = float(close.iloc[i])
        direction = "long" if is_long else "short"
        stop = synthetic_stop(entry, float(synth), direction, SYNTHETIC_ATR_MULT)

        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=stop,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="tdz_range_signals", synthetic_stop=True,
        ))

    return signals
