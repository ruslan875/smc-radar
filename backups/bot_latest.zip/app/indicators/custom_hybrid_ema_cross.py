"""Port of the "Dual EMA" cross signal from "Custom Hybrid Indicator with
Lines" (source: Custom_Hybrid_Indicator_with_Lines.txt, Pine v6).

Not ported: the Linear Regression Channel (lines 15-137 -- a `barstate.
islast`-only redraw of trend lines/labels, non-deterministic bar-to-bar,
pure visualization), the volume-surge "bubbles" (lines 160-193 -- sized
circles marking volume spikes, no directional continuation rule, no
alertcondition, informational only) and the "Whale Jumpings" markers
(lines 195-203 -- same: a volume+ATR spike marker with no follow-through
logic). None of these define a tradeable entry/exit.

The EMA cross (fastLength=12, slowLength=6 -- named "fast"/"slow" in the
source but note fastLength > slowLength, i.e. the "fast" EMA is actually
the slower-moving one of the pair) IS deterministic and non-repainting.

**Labeling oddity, preserved as-is**: the source's own comments and
plotshape text invert the usual convention -- `crossUp` (12-EMA crosses
*above* the 6-EMA, i.e. the textbook bullish cross) is commented "Сигнал
'SELL' (бычий тренд)" ["Signal 'SELL' (bullish trend)"] and plotted with
text="SELL"; `crossDown` is plotted text="BUY". This port follows the
source's own literal alert semantics (crossUp -> short, crossDown ->
long) rather than "fixing" it to the textbook direction, on the same
principle used elsewhere in this collection (e.g. the MELONA/OPFX combo's
mislabelled bearish alert was flagged, not silently corrected). If this
turns out to trade like an inverted mess in backtesting, that itself is
useful information about the source file.

No native stop-loss is defined -- per the batch-wide convention, the
shared synthetic ATR(14) stop is used.
"""
from __future__ import annotations

import pandas as pd

from .common import Signal, atr, ema, synthetic_stop, SYNTHETIC_ATR_LEN, SYNTHETIC_ATR_MULT

FAST_LENGTH = 12
SLOW_LENGTH = 6


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    close = df["close"]
    fast_ema = ema(close, FAST_LENGTH)
    slow_ema = ema(close, SLOW_LENGTH)

    prev_fast = fast_ema.shift(1)
    prev_slow = slow_ema.shift(1)

    cross_up = (prev_fast <= prev_slow) & (fast_ema > slow_ema)     # source labels this "SELL"
    cross_down = (prev_fast >= prev_slow) & (fast_ema < slow_ema)   # source labels this "BUY"

    atr_synth = atr(df, SYNTHETIC_ATR_LEN)

    signals: list[Signal] = []
    for i in range(len(df)):
        if bool(cross_up.iloc[i]):
            direction = "short"
        elif bool(cross_down.iloc[i]):
            direction = "long"
        else:
            continue

        a_synth = atr_synth.iloc[i]
        if pd.isna(a_synth):
            continue

        entry = float(close.iloc[i])
        sl = synthetic_stop(entry, float(a_synth), direction, SYNTHETIC_ATR_MULT)
        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=sl,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="custom_hybrid_ema_cross", synthetic_stop=True,
        ))

    return signals
