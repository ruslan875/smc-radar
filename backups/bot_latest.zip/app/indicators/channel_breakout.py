"""Standalone port of the unrelated recursive-channel breakout script
bolted onto the very bottom of "Adaptive Kalman filter - Trend Strength
Oscillator" (code: f0f7ea58-code_Adaptive_Kalman_filter_Trend_Strength_
Oscillator_with_Signals.txt, lines ~162-183). Nothing about this section
references the Kalman filter above it in the same file -- it's a fully
independent mini-indicator with its own inputs (`length`, `src2`) that
happens to share the file, plots directly onto the price chart
(`force_overlay = true`), and has its own native Buy/Sell plotshapes.

Pine source (verbatim)::

    length = input(100)
    src2   = input(close)
    a = 0., b = 0.
    a := math.max(src2, nz(a[1])) - nz(a[1] - b[1]) / length
    b := math.min(src2, nz(b[1])) + nz(a[1] - b[1]) / length
    avg = math.avg(a, b)

    crossup = b[1] < close[1] and b > close
    crossdn = a[1] < close[1] and a > close
    bullish = ta.barssince(crossdn) <= ta.barssince(crossup)

    plotshape(not bullish and bullish[1] ? avg : na, ..., text="Sell", ...)
    plotshape(bullish and not bullish[1] ? avg : na, ..., text="Buy", ...)

`a`/`b` form a recursive channel that ratchets toward price at a rate of
1/length per bar (similar family to a Chandelier/SuperTrend-style
trailing envelope, though the exact formula is this script's own).
`crossup`/`crossdn` mark the bar the lower/upper band respectively
overtakes price; `bullish` tracks which of the two happened more
recently via `ta.barssince`. Ported directly against the native Buy
(bullish flips true) / Sell (bullish flips false) plotshapes -- no
approximation needed, every operator here has a direct translation.
"""
from __future__ import annotations

import pandas as pd

from .common import Signal, synthetic_stop, atr, SYNTHETIC_ATR_LEN

LENGTH = 100


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    close = df["close"].to_numpy()
    n = len(close)

    a = [0.0] * n
    b = [0.0] * n
    for i in range(n):
        prev_a = a[i - 1] if i > 0 else 0.0
        prev_b = b[i - 1] if i > 0 else 0.0
        a[i] = max(close[i], prev_a) - (prev_a - prev_b) / LENGTH
        b[i] = min(close[i], prev_b) + (prev_a - prev_b) / LENGTH

    crossup = [False] * n   # b crosses above close
    crossdn = [False] * n   # a crosses above close
    for i in range(1, n):
        crossup[i] = b[i - 1] < close[i - 1] and b[i] > close[i]
        crossdn[i] = a[i - 1] < close[i - 1] and a[i] > close[i]

    bars_since_up = None
    bars_since_dn = None
    bullish = [False] * n
    for i in range(n):
        if crossup[i]:
            bars_since_up = 0
        elif bars_since_up is not None:
            bars_since_up += 1
        if crossdn[i]:
            bars_since_dn = 0
        elif bars_since_dn is not None:
            bars_since_dn += 1

        if bars_since_dn is None and bars_since_up is None:
            bullish[i] = False
        elif bars_since_dn is None:
            bullish[i] = False
        elif bars_since_up is None:
            bullish[i] = True
        else:
            bullish[i] = bars_since_dn <= bars_since_up

    atr_synth = atr(df, SYNTHETIC_ATR_LEN)
    signals: list[Signal] = []
    for i in range(1, n):
        if pd.isna(atr_synth.iloc[i]):
            continue
        buy = bullish[i] and not bullish[i - 1]
        sell = (not bullish[i]) and bullish[i - 1]
        if not (buy or sell):
            continue
        direction = "long" if buy else "short"
        entry = float(close[i])
        sl = synthetic_stop(entry, float(atr_synth.iloc[i]), direction)
        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=sl,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="channel_breakout", synthetic_stop=True,
        ))

    return signals
