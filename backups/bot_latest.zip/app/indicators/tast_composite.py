"""Port of the "Technical Analysis Consulting Table" (TAST) sub-system
bolted into the middle of JohnScript (source: 04932d32-______.txt, lines
89-637). Identical code also appears verbatim in ComboInd1
(9292ef80-ComboInd1.txt lines 354-903) -- confirmed by diff, so ComboInd1
does not get its own copy of this module.

TAST is a weighted-vote composite: 11 oscillators (group A), 17 moving
averages (group B) and 4 pivot-point systems x2 (group C, "red"/"blue"
crossed-and-not-recrossed state machines) each cast a red(bearish==1) or
blue(bullish==1) vote every bar. The votes are summed (A_red/A_blue,
B_red/B_blue, C_red/C_blue -> Sum_red/Sum_blue out of 32 total) and
converted to a 0-10 "point" score; BUY/SELL/STRONG BUY/STRONG SELL/NEUTRAL
is whichever crosses the >5 threshold, with "Strong" requiring every one
of the three sub-groups to agree in direction.

This is a decision *table*, not a source of discrete alertconditions in
the original script (no alertcondition() calls exist for it at all --
it only ever draws into a table cell). generate_signals() below fires an
edge-triggered long/short Signal the bar the composite label FIRST flips
into BUY/STRONG BUY or SELL/STRONG SELL (i.e. `sell != sell[1]` etc.),
which is the natural causal reading of "a table cell just turned red/
green" translated into a discrete trade trigger.

Fidelity notes:
  - `tick`/`res` (Symbol/Resolution) inputs default to a DIFFERENT
    instrument+timeframe (CRYPTOCAP:TOTAL) than the chart the indicator
    is plotted on, fed through `request.security`. That is explicitly a
    cross-market confirmation table in the original -- reproducing it
    would require fetching a second series. Since this backtest only
    ever has the single OHLCV frame for the traded symbol/timeframe, all
    of `source`/`res`-based sub-signals are computed on the entry
    timeframe's own OHLCV instead (`source = close`), which is the
    standard "use it on your own chart" mode the indicator also supports
    when `res=''` (empty resolution = current chart) -- for a crypto
    perp bot with no CRYPTOCAP:TOTAL reference this is the closest
    faithful behaviour.
  - The 4 pivot-point families (Traditional/Fibonacci/Woodie/Camarilla)
    are computed on `res`-period pivots (daily-by-default via `pp_res`
    tracking `res`). With `res=''` in Pine that resolves to the chart's
    own timeframe, i.e. pivots recompute every bar off the *previous
    bar's* HLC -- ported exactly that way (no daily aggregation is
    grafted on, matching the literal `res=''` behaviour).
  - `ta.dev` (mean absolute deviation) for CCI uses the same formula as
    common.cci here (verified identical to Pine's `ta.dev`).
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .common import Signal, ema, sma, rma, rsi, atr, highest, lowest, cci, synthetic_stop, SYNTHETIC_ATR_LEN

# ---- group A: oscillators ------------------------------------------------
RSI_LEN = 14
STOCH_K, STOCH_D, STOCH_S = 14, 3, 3
CCI_LEN = 20
ADX_DI_LEN, ADX_LEN = 14, 14
ADX_THRESH = 25
AO_FAST, AO_SLOW = 5, 34
MOM_LEN = 10
MACD_FAST, MACD_SLOW, MACD_SIGNAL = 12, 26, 9
STOCH_RSI_LEN = 14
STOCH_RSI_K, STOCH_RSI_D = 3, 3
WPR_LEN = 14
BULLBEAR_LEN = 30
UO_LEN1, UO_LEN2, UO_LEN3 = 7, 14, 28

# ---- group B: moving averages --------------------------------------------
MA_LENGTHS = (5, 10, 20, 30, 50, 100, 200)
ICHI_BASE_LEN = 26
VWMA_LEN = 20
HULL_LEN = 9

# ---- group C: pivots -------------------------------------------------------
CAMARILLA_K = 1.1


def _wma(series: pd.Series, length: int) -> pd.Series:
    weights = np.arange(1, length + 1)
    return series.rolling(length, min_periods=length).apply(
        lambda x: np.dot(x, weights) / weights.sum(), raw=True)


def _hma(series: pd.Series, length: int) -> pd.Series:
    return _wma(2 * _wma(series, length // 2) - _wma(series, length), int(round(length ** 0.5)))


def _vwma(close: pd.Series, volume: pd.Series, length: int) -> pd.Series:
    return (close * volume).rolling(length, min_periods=length).sum() / volume.rolling(length, min_periods=length).sum()


def _stoch_k(src: pd.Series, high: pd.Series, low: pd.Series, k: int, smooth: int) -> pd.Series:
    hh = highest(high, k)
    ll = lowest(low, k)
    raw = (src - ll) / (hh - ll) * 100
    return sma(raw, smooth)


def _macd_hist(src: pd.Series) -> pd.Series:
    macd = ema(src, MACD_FAST) - ema(src, MACD_SLOW)
    signal = ema(macd, MACD_SIGNAL)
    return macd - signal


def _bull_bear_power(df: pd.DataFrame) -> pd.Series:
    # APPROXIMATION: the Pine source computes `bull`/`bear` via a dozen
    # nested iff_1..iff_12 ternaries referencing request.security(...,
    # open/high/low) of the (by-default different) `tick`/`res` symbol,
    # which (with source==close on the local chart, our only mode -- see
    # module docstring) is a convoluted but not-obviously-non-standard
    # restatement of Elder's classic Bulls/Bears Power. Rather than risk
    # silently mistranslating 12 nested ternaries, this uses the
    # textbook formula (bulls = high - EMA(close,len), bears = low -
    # EMA(close,len)) that the obfuscated code appears to be computing.
    # This is 1 vote out of 32 in the composite, so any discrepancy here
    # has bounded impact on the overall signal.
    ema_len = BULLBEAR_LEN
    bull = df["high"] - ema(df["close"], ema_len)
    bear = df["low"] - ema(df["close"], ema_len)
    return sma(bull - bear, ema_len)


def _ultimate_osc(df: pd.DataFrame) -> pd.Series:
    close, high, low = df["close"], df["high"], df["low"]
    prev_close = close.shift(1)
    high_ = pd.concat([high, prev_close], axis=1).max(axis=1)
    low_ = pd.concat([low, prev_close], axis=1).min(axis=1)
    bp = close - low_
    tr_ = high_ - low_
    avg1 = bp.rolling(UO_LEN1).sum() / tr_.rolling(UO_LEN1).sum()
    avg2 = bp.rolling(UO_LEN2).sum() / tr_.rolling(UO_LEN2).sum()
    avg3 = bp.rolling(UO_LEN3).sum() / tr_.rolling(UO_LEN3).sum()
    return 100 * (4 * avg1 + 2 * avg2 + avg3) / 7


def _adx_di(df: pd.DataFrame, length: int) -> tuple[pd.Series, pd.Series, pd.Series]:
    from .common import true_range
    up = df["high"].diff()
    down = -df["low"].diff()
    plus_dm = np.where((up > down) & (up > 0), up, 0.0)
    minus_dm = np.where((down > up) & (down > 0), down, 0.0)
    plus_dm = pd.Series(plus_dm, index=df.index)
    minus_dm = pd.Series(minus_dm, index=df.index)
    tr_rma = rma(true_range(df), length)
    plus = (100 * rma(plus_dm, length) / tr_rma).ffill()
    minus = (100 * rma(minus_dm, length) / tr_rma).ffill()
    total = (plus + minus).replace(0, 1.0)
    dx = (plus - minus).abs() / total * 100
    adx = 100 * rma(dx, ADX_LEN)
    return plus, minus, adx


def _pivot_signal(close: pd.Series, high: pd.Series, low: pd.Series,
                   pp: pd.Series, r1, s1, r2, s2, r3, s3) -> tuple[pd.Series, pd.Series]:
    def crossed(a: pd.Series, b: pd.Series) -> pd.Series:
        prev_diff = (a.shift(1) - b.shift(1))
        cur_diff = (a - b)
        return (prev_diff * cur_diff < 0) | ((prev_diff == 0) & (cur_diff != 0))

    red = ((close < s1) & ~crossed(close, s2)) | ((close < s2) & ~crossed(close, s3)) | ((close < s3) & ~crossed(high, s3))
    blue = ((close > r1) & ~crossed(close, r2)) | ((close > r2) & ~crossed(close, r3)) | ((close > r3) & ~crossed(low, r3))
    return red.fillna(False).astype(int), blue.fillna(False).astype(int)


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    high, low, close, volume = df["high"], df["low"], df["close"], df["volume"]
    source = close  # `res=''` -> current chart; see fidelity note

    # ---- A. Oscillators ----
    rsi_sig = rsi(source, RSI_LEN)
    a1_red, a1_blue = (rsi_sig < 30).astype(int), (rsi_sig > 70).astype(int)

    stoch_sig = _stoch_k(source, high, low, STOCH_K, STOCH_S)
    a2_red, a2_blue = (stoch_sig < 20).astype(int), (stoch_sig > 80).astype(int)

    cci_sig = cci(source, CCI_LEN)
    a3_red, a3_blue = (cci_sig < -100).astype(int), (cci_sig > 100).astype(int)

    di_plus, di_minus, adx_sig = _adx_di(df, ADX_DI_LEN)
    a4_red = ((di_minus > di_plus) & (adx_sig > ADX_THRESH)).astype(int)
    a4_blue = ((di_plus > di_minus) & (adx_sig > ADX_THRESH)).astype(int)

    hl2 = (high + low) / 2
    ao = sma(hl2, AO_FAST) - sma(hl2, AO_SLOW)
    a5_red, a5_blue = (ao < 0).astype(int), (ao > 0).astype(int)

    mom = source - source.shift(MOM_LEN)
    a6_red, a6_blue = (mom < 0).astype(int), (mom > 0).astype(int)

    hist = _macd_hist(source)
    a7_red = (hist < hist.shift(1)).astype(int)
    a7_blue = (hist > hist.shift(1)).astype(int)

    rsi1 = rsi(source, STOCH_RSI_LEN)
    rsik = sma(_stoch_k(rsi1, rsi1, rsi1, STOCH_RSI_LEN, 1), STOCH_RSI_K)
    a8_red, a8_blue = (rsik < 20).astype(int), (rsik > 80).astype(int)

    upper_w = highest(source, WPR_LEN)
    lower_w = lowest(source, WPR_LEN)
    wpr = 100 * (source - upper_w) / (upper_w - lower_w)
    a9_red, a9_blue = (wpr < -80).astype(int), (wpr > -20).astype(int)

    bbp = _bull_bear_power(df)
    a10_red, a10_blue = (bbp < 0).astype(int), (bbp > 0).astype(int)

    uo = _ultimate_osc(df)
    a11_red, a11_blue = (uo < 30).astype(int), (uo > 70).astype(int)

    a_red = a1_red + a2_red + a3_red + a4_red + a5_red + a6_red + a7_red + a8_red + a9_red + a10_red + a11_red
    a_blue = a1_blue + a2_blue + a3_blue + a4_blue + a5_blue + a6_blue + a7_blue + a8_blue + a9_blue + a10_blue + a11_blue

    # ---- B. Moving Averages ----
    b_red = pd.Series(0, index=df.index)
    b_blue = pd.Series(0, index=df.index)
    for length in MA_LENGTHS:
        e = ema(source, length)
        s = sma(source, length)
        b_red = b_red + (source < e).astype(int) + (source < s).astype(int)
        b_blue = b_blue + (source > e).astype(int) + (source > s).astype(int)

    ichi_base = (lowest(source, ICHI_BASE_LEN) + highest(source, ICHI_BASE_LEN)) / 2
    b_red = b_red + (source < ichi_base).astype(int)
    b_blue = b_blue + (source > ichi_base).astype(int)

    vwma = _vwma(source, volume, VWMA_LEN)
    b_red = b_red + (source < vwma).astype(int)
    b_blue = b_blue + (source > vwma).astype(int)

    hma = _hma(source, HULL_LEN)
    b_red = b_red + (source < hma).astype(int)
    b_blue = b_blue + (source > hma).astype(int)

    # ---- C. Pivots (recomputed every bar off prior-bar HLC, res='' mode) ----
    phigh, plow, popen, psource = high.shift(1), low.shift(1), df["open"].shift(1), source.shift(1)

    tr_pp = (phigh + plow + psource) / 3
    tr_r1, tr_s1 = 2 * tr_pp - plow, tr_pp - (phigh - tr_pp)
    tr_r2, tr_s2 = tr_pp + phigh - plow, tr_pp - (phigh - plow)
    tr_r3, tr_s3 = phigh + 2 * (tr_pp - plow), plow - 2 * (phigh - tr_pp)
    c1_red, c1_blue = _pivot_signal(close, high, low, tr_pp, tr_r1, tr_s1, tr_r2, tr_s2, tr_r3, tr_s3)

    fib_pp = (phigh + plow + psource) / 3
    rng = phigh - plow
    fib_r1, fib_s1 = fib_pp + rng * 0.382, fib_pp - rng * 0.382
    fib_r2, fib_s2 = fib_pp + rng * 0.618, fib_pp - rng * 0.618
    fib_r3, fib_s3 = fib_pp + rng * 1.0, fib_pp - rng * 1.0
    c2_red, c2_blue = _pivot_signal(close, high, low, fib_pp, fib_r1, fib_s1, fib_r2, fib_s2, fib_r3, fib_s3)

    wo_pp = (phigh + plow + 2 * popen) / 4
    wo_r1, wo_s1 = 2 * wo_pp - plow, wo_pp - (phigh - wo_pp)
    wo_r2, wo_s2 = wo_pp + phigh - plow, wo_pp - (phigh - plow)
    wo_r3, wo_s3 = phigh + 2 * (wo_pp - plow), plow - 2 * (phigh - wo_pp)
    c3_red, c3_blue = _pivot_signal(close, high, low, wo_pp, wo_r1, wo_s1, wo_r2, wo_s2, wo_r3, wo_s3)

    ca_r1, ca_s1 = psource + rng * CAMARILLA_K / 12, psource - rng * CAMARILLA_K / 12
    ca_r2, ca_s2 = psource + rng * CAMARILLA_K / 6, psource - rng * CAMARILLA_K / 6
    ca_r3, ca_s3 = psource + rng * CAMARILLA_K / 4, psource - rng * CAMARILLA_K / 4
    c4_red, c4_blue = _pivot_signal(close, high, low, psource, ca_r1, ca_s1, ca_r2, ca_s2, ca_r3, ca_s3)

    c_red = c1_red + c2_red + c3_red + c4_red
    c_blue = c1_blue + c2_blue + c3_blue + c4_blue

    sum_red = a_red + b_red + c_red
    sum_blue = a_blue + b_blue + c_blue
    sell_point = sum_red / 32 * 10
    buy_point = sum_blue / 32 * 10

    sell = (sum_red > sum_blue) & (sell_point > 5)
    strong_sell = (a_red > a_blue) & (b_red > b_blue) & (c_red > c_blue) & (sell_point > 5)
    buy = (sum_red < sum_blue) & (buy_point > 5)
    strong_buy = (a_red < a_blue) & (b_red < b_blue) & (c_red < c_blue) & (buy_point > 5)

    is_sell = (sell | strong_sell).fillna(False)
    is_buy = (buy | strong_buy).fillna(False)

    atr_synth = atr(df, SYNTHETIC_ATR_LEN)
    valid_from = max(MA_LENGTHS[-1], ICHI_BASE_LEN, UO_LEN3, SYNTHETIC_ATR_LEN) + 2

    signals: list[Signal] = []
    for i in range(valid_from, len(df)):
        if pd.isna(atr_synth.iloc[i]):
            continue
        buy_now, buy_prev = bool(is_buy.iloc[i]), bool(is_buy.iloc[i - 1])
        sell_now, sell_prev = bool(is_sell.iloc[i]), bool(is_sell.iloc[i - 1])

        direction = None
        if buy_now and not buy_prev:
            direction = "long"
        elif sell_now and not sell_prev:
            direction = "short"
        if direction is None:
            continue

        entry = float(close.iloc[i])
        sl = synthetic_stop(entry, float(atr_synth.iloc[i]), direction)
        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=sl,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="tast_composite", synthetic_stop=True,
        ))

    return signals
