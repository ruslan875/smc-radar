"""Port of "SuperTrend + Relative Volume (Kernel Optimized) and S/R
level" (source:
SuperTrend_and_Relative_Volume_Kernel_Optimized_and_SR_level.txt).

Entry logic: a standard `ta.supertrend(atrMultiplier=3, atrLength=10)`
cross (`bullishBreak`/`bearishBreak` = `close` crossing over/under the
SuperTrend line), optionally gated by a KDE-based relative-volume
"activation threshold" filter (`activationThresholdEnabled`, default
OFF, so the filter passes everything by default). Ported anyway
(gated by the same default-off flag) per the batch instructions, since
it's not much extra code.

Dead-code finding (verified by reading the whole file): `isEma` ("Use
filter EMA?") is declared (`len_ema`/`isEma` inputs) and `ema` IS
computed and plotted, and even used to mask which half of the
SuperTrend line is drawn (`close > ema ? ... : na` for the up-line,
`close < ema ? ... : na` for the down-line) -- but that masking is
PURELY visual (it only hides/shows the plotted line), and `isEma` itself
is never read anywhere after its declaration, not even to toggle that
masking. `bull_condition`/`bear_condition` (what actually feeds
`alertcondition`) are computed from `bullishBreak`/`bearishBreak` and
`threshold_condition` only -- `ema`/`isEma` play no role. So neither is
wired into the ported signal here.

KDE relative-volume filter -- approximation note: the source builds a
custom Gaussian-KDE density array over the last `KDEStep` (100)
standardized buy/sell "relative volume" values recorded at each prior
SuperTrend break, then sums that density up to the current point via
`array.binary_search_leftmost`/`rightmost` to get `volumeProb`, an
estimated CDF value compared against `activationThresholdInput/100`
(default 70%). Reproducing that exact binary-search-over-a-100-point KDE
grid procedure bar-by-bar isn't practical to verify byte-exact from the
source alone, so this port uses an EMPIRICAL CDF over the same rolling
window of up-to-100 standardized historical breakout "relative volume"
ratios instead of a Gaussian-KDE-smoothed one -- both estimate "what
fraction of recent breakout relative-volume readings were at or below
this one", they just differ in how they smooth between the discrete
history points. Since `activationThresholdEnabled` defaults to False,
this path is inactive unless explicitly turned on.

Also not ported: the S/R "power"/retest module at the bottom of the file
(`run_indicator`/`power`/`signals`/`max_min`) -- it only runs on
`barstate.islast` (i.e. it recomputes once for the live/last bar to draw
static support/resistance boxes and touch labels), it's not a
bar-by-bar directional entry rule, and it isn't wired to any
alertcondition.
"""
from __future__ import annotations

import math
from collections import deque

import numpy as np
import pandas as pd

from .common import Signal, atr, true_range, ema, synthetic_stop, SYNTHETIC_ATR_LEN

ATR_LENGTH = 10
ATR_MULTIPLIER = 3

ACTIVATION_THRESHOLD_ENABLED = False  # source default: False
ACTIVATION_THRESHOLD = 0.70
BAR_LENGTH = 25       # "Relative Volume Length" (long EMA window)
SHORT_LENGTH = 10      # hard-coded short EMA window in the source
KDE_STEP = 100          # rolling history window size for the empirical CDF


def _supertrend(df: pd.DataFrame, length: int, mult: float) -> tuple[np.ndarray, np.ndarray]:
    """Standard `ta.supertrend`: returns (supertrend_line, direction),
    direction == -1 => uptrend (bullish), +1 => downtrend (bearish),
    matching Pine's own convention (`pineDirection < 0` => bull)."""
    high, low, close = df["high"].to_numpy(), df["low"].to_numpy(), df["close"].to_numpy()
    hl2 = (high + low) / 2
    atr_arr = atr(df, length).to_numpy()

    n = len(df)
    upperband = hl2 + mult * atr_arr
    lowerband = hl2 - mult * atr_arr
    supertrend = np.full(n, np.nan)
    direction = np.zeros(n, dtype=int)

    for i in range(n):
        if math.isnan(atr_arr[i]):
            continue
        if i == 0 or math.isnan(supertrend[i - 1]):
            supertrend[i] = upperband[i]
            direction[i] = 1
            continue

        if close[i - 1] <= upperband[i - 1]:
            upperband[i] = min(upperband[i], upperband[i - 1])
        if close[i - 1] >= lowerband[i - 1]:
            lowerband[i] = max(lowerband[i], lowerband[i - 1])

        if supertrend[i - 1] == upperband[i - 1]:
            direction[i] = -1 if close[i] > upperband[i] else 1
        else:
            direction[i] = 1 if close[i] < lowerband[i] else -1

        supertrend[i] = lowerband[i] if direction[i] == -1 else upperband[i]

    return supertrend, direction


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    high, low, close = df["high"], df["low"], df["close"]
    n = len(df)

    supertrend, pine_direction = _supertrend(df, ATR_LENGTH, ATR_MULTIPLIER)
    supertrend_s = pd.Series(supertrend, index=df.index)

    bullish_break = (close.shift(1) < supertrend_s.shift(1)) & (close > supertrend_s)
    bearish_break = (close.shift(1) > supertrend_s.shift(1)) & (close < supertrend_s)

    rng = (high - low).replace(0, np.nan)
    buy_volume_total = df["volume"] * (close - low) / rng
    sell_volume_total = df["volume"] * (high - close) / rng
    buy_volume_avg = ema(buy_volume_total, BAR_LENGTH)
    buy_volume_avg_short = ema(buy_volume_total, SHORT_LENGTH)
    sell_volume_avg = ema(sell_volume_total, BAR_LENGTH)
    sell_volume_avg_short = ema(sell_volume_total, SHORT_LENGTH)

    buy_volume = (buy_volume_avg_short / buy_volume_avg).to_numpy()
    sell_volume = (sell_volume_avg_short / sell_volume_avg).to_numpy()

    atr_series = atr(df, SYNTHETIC_ATR_LEN)

    bull_hist: deque[float] = deque(maxlen=KDE_STEP)
    bear_hist: deque[float] = deque(maxlen=KDE_STEP)

    signals: list[Signal] = []
    valid_from = max(ATR_LENGTH, BAR_LENGTH) + 2

    for i in range(valid_from, n):
        bull = bool(bullish_break.iloc[i]) if not pd.isna(bullish_break.iloc[i]) else False
        bear = bool(bearish_break.iloc[i]) if not pd.isna(bearish_break.iloc[i]) else False
        if not (bull or bear):
            continue

        threshold_pass = True
        if ACTIVATION_THRESHOLD_ENABLED:
            if bull and not math.isnan(buy_volume[i]):
                bull_hist.append(buy_volume[i])
                if len(bull_hist) > 1:
                    arr = np.array(bull_hist)
                    std = arr.std(ddof=0)
                    mean = arr.mean()
                    standardized = (buy_volume[i] - mean) / std if std > 0 else 0.0
                    standardized_hist = (arr - mean) / std if std > 0 else np.zeros_like(arr)
                    vol_prob = float((standardized_hist <= standardized).mean())
                    threshold_pass = vol_prob >= ACTIVATION_THRESHOLD
                else:
                    threshold_pass = False
            elif bear and not math.isnan(sell_volume[i]):
                bear_hist.append(sell_volume[i])
                if len(bear_hist) > 1:
                    arr = np.array(bear_hist)
                    std = arr.std(ddof=0)
                    mean = arr.mean()
                    standardized = (sell_volume[i] - mean) / std if std > 0 else 0.0
                    standardized_hist = (arr - mean) / std if std > 0 else np.zeros_like(arr)
                    vol_prob = float((standardized_hist <= standardized).mean())
                    threshold_pass = vol_prob >= ACTIVATION_THRESHOLD
                else:
                    threshold_pass = False

        if not threshold_pass:
            continue

        atr_v = atr_series.iloc[i]
        if pd.isna(atr_v):
            continue

        entry = float(close.iloc[i])
        direction = "long" if bull else "short"
        stop = synthetic_stop(entry, float(atr_v), direction)
        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=stop,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="supertrend_relvolume", synthetic_stop=True,
        ))

    return signals
