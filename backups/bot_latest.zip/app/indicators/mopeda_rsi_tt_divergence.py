"""Port of the "RSI Bullish/Bearish Div" alertconditions from
"MoPeDa.net" v2.0 (source lines 958-975, 1145-1146) -- a second, separate
divergence detector from `mopeda_zscore_divergence.py`, plain classic RSI
regular divergence (not the z-score composite), using `ta.valuewhen`-style
pivot comparison instead of the composite module's explicit prev-pivot
state variables:

    rsi_tt = RSI(close, 24)
    rsi_pl = pivotlow(rsi_tt, 6, 6)     // rsiDivLen used as both L and R
    rsi_ph = pivothigh(rsi_tt, 6, 6)

    _inRange(cond) = 5 <= barssince(cond) <= 60     // hardcoded range,
                                                      // NOT the user's
                                                      // rangeMin/rangeMax
                                                      // inputs (those only
                                                      // feed the OTHER
                                                      // (z-score) divergence)

    rsi_HL      = rsi_tt[6] > valuewhen(rsi_plFound, rsi_tt[6], 1) and inRange(plFound[1])
    rsi_priceLL = low[6]    < valuewhen(rsi_plFound, low[6], 1)
    rsi_bullDiv = rsi_priceLL and rsi_HL and rsi_plFound     -> BUY (long)

Mirrored (rsi_LH / rsi_priceHH) for rsi_bearDiv -> SELL (short). Entry =
close of the signal bar (market), no native stop in the source (pure
alert indicator) -- synthetic ATR(14) stop + default 1R/2R/3R ladder per
the batch convention.
"""
from __future__ import annotations

import pandas as pd

from .common import Signal, atr, barssince, pivothigh, pivotlow, rsi as rsi_fn, \
    synthetic_stop, valuewhen, SYNTHETIC_ATR_LEN, SYNTHETIC_ATR_MULT

RSI_LENGTH = 24
LOOKBACK = 6          # rsiDivLen, used as both pivot left and right
RANGE_LOW = 5          # hardcoded in source (tt_rangeLow), not user-configurable
RANGE_HIGH = 60        # hardcoded in source (tt_rangeHi), not user-configurable


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    n = len(df)
    if n < RSI_LENGTH + 2 * LOOKBACK + RANGE_HIGH + 5:
        return []

    close = df["close"]
    low = df["low"]
    high = df["high"]

    rsi_tt = rsi_fn(close, RSI_LENGTH)
    rsi_pl = pivotlow(rsi_tt, LOOKBACK, LOOKBACK)
    rsi_ph = pivothigh(rsi_tt, LOOKBACK, LOOKBACK)
    rsi_pl_found = rsi_pl.notna()
    rsi_ph_found = rsi_ph.notna()

    rsi_osc_lbr = rsi_tt.shift(LOOKBACK)
    rsi_low_lbr = low.shift(LOOKBACK)
    rsi_high_lbr = high.shift(LOOKBACK)

    def in_range(cond: pd.Series) -> pd.Series:
        bars = barssince(cond)
        return (bars >= RANGE_LOW) & (bars <= RANGE_HIGH)

    rsi_inrange_pl = in_range(rsi_pl_found.shift(1))
    rsi_inrange_ph = in_range(rsi_ph_found.shift(1))

    val_osc_pl = valuewhen(rsi_pl_found, rsi_osc_lbr, 1)
    val_low_pl = valuewhen(rsi_pl_found, rsi_low_lbr, 1)
    val_osc_ph = valuewhen(rsi_ph_found, rsi_osc_lbr, 1)
    val_high_ph = valuewhen(rsi_ph_found, rsi_high_lbr, 1)

    rsi_hl = (rsi_osc_lbr > val_osc_pl) & rsi_inrange_pl
    rsi_price_ll = rsi_low_lbr < val_low_pl
    rsi_bull_div = (rsi_price_ll & rsi_hl & rsi_pl_found).fillna(False).to_numpy()

    rsi_lh = (rsi_osc_lbr < val_osc_ph) & rsi_inrange_ph
    rsi_price_hh = rsi_high_lbr > val_high_ph
    rsi_bear_div = (rsi_price_hh & rsi_lh & rsi_ph_found).fillna(False).to_numpy()

    close_np = close.to_numpy()
    atr_synth = atr(df, SYNTHETIC_ATR_LEN).to_numpy()

    signals: list[Signal] = []
    for i in range(n):
        if rsi_bull_div[i]:
            direction = "long"
        elif rsi_bear_div[i]:
            direction = "short"
        else:
            continue

        a_synth = atr_synth[i]
        if a_synth != a_synth:
            continue

        entry = float(close_np[i])
        sl = synthetic_stop(entry, float(a_synth), direction, SYNTHETIC_ATR_MULT)
        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=sl,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="mopeda_rsi_tt_divergence", synthetic_stop=True,
        ))

    return signals
