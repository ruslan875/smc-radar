"""Port of "ParadOSC" (source: f95076c8-ParadOSC.txt).

Same family as parad_rsi.py / parad_wt.py: the original is a multi-
timeframe (up to 14 TFs) "Double Smoothed Stochastic (of RSI)" ("DSS")
extreme-reading scanner:

    rsiValue1 = ta.rsi(srcStoch, length)                    # length = 14
    DSS_k     = ta.sma(100 * (rsiValue1 - ta.lowest(rsiValue1, length))
                        / (ta.highest(rsiValue1, length) - ta.lowest(rsiValue1, length)), smoothK)   # smoothK = 3
    DSS_d     = ta.sma(DSS_k, smoothD)                       # smoothD = 3, unused by the OB/OS signal itself

i.e. a Stochastic oscillator applied to RSI values rather than price
(DSS_d, the %D signal line, is computed in the source but never actually
compared against anything -- only raw DSS_k is checked against the
upper/lower bands).

NOT REPLICATED: the multi-timeframe confluence aspect -- see
parad_rsi.py's docstring for why. This module applies the DSS
overbought/oversold bands (default upperBand=80 / lowerBand=20) to the
entry timeframe itself only.

Signal definition: edge-triggered DSS extreme entry -- long fires the
bar DSS_k first drops below 20 (oversold), short fires the bar DSS_k
first rises above 80 (overbought).
"""
from __future__ import annotations

import pandas as pd

from .common import Signal, rsi, sma, highest, lowest, synthetic_stop, atr, SYNTHETIC_ATR_LEN

LENGTH = 14
SMOOTH_K = 3
SMOOTH_D = 3
UPPER_BAND = 80
LOWER_BAND = 20


def _dss_k(close: pd.Series) -> pd.Series:
    rsi_val = rsi(close, LENGTH)
    hh = highest(rsi_val, LENGTH)
    ll = lowest(rsi_val, LENGTH)
    raw = 100 * (rsi_val - ll) / (hh - ll)
    return sma(raw, SMOOTH_K)


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    close = df["close"]
    dss_k = _dss_k(close)
    atr_synth = atr(df, SYNTHETIC_ATR_LEN)

    oversold_now = dss_k <= LOWER_BAND
    overbought_now = dss_k >= UPPER_BAND
    oversold_prev = oversold_now.shift(1).fillna(False)
    overbought_prev = overbought_now.shift(1).fillna(False)

    enter_long = oversold_now & ~oversold_prev
    enter_short = overbought_now & ~overbought_prev

    signals: list[Signal] = []
    for i in range(len(df)):
        if pd.isna(atr_synth.iloc[i]) or pd.isna(dss_k.iloc[i]):
            continue
        direction = None
        if bool(enter_long.iloc[i]):
            direction = "long"
        elif bool(enter_short.iloc[i]):
            direction = "short"
        if direction is None:
            continue

        entry = float(close.iloc[i])
        sl = synthetic_stop(entry, float(atr_synth.iloc[i]), direction)
        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=sl,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="parad_osc", synthetic_stop=True,
        ))

    return signals
