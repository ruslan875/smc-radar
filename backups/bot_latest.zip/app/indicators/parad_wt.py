"""Port of "ParadWT" (source: 75e474f2-ParadWT.txt).

Same family as parad_rsi.py / parad_osc.py: the original is a multi-
timeframe (up to 14 TFs) WaveTrend extreme-reading scanner built on top
of LazyBear's classic WaveTrend oscillator:

    ap  = hlc3
    esa = ta.ema(ap, n1)                          # n1 = 10
    d   = ta.ema(|ap - esa|, n1)
    ci  = (ap - esa) / (0.015 * d)
    wt  = ta.sma(ta.ema(ci, n2), 4)                # n2 = 21   (wt1 in LazyBear's original, `tci`)

(The file computes the fully-expanded version of this formula a second
time as its `wt` variable using hlc3 directly rather than reusing `ap`,
`ci`; identical math, ported once here.)

NOT REPLICATED: the multi-timeframe confluence aspect -- see parad_rsi.py's
docstring for why (no `request.security`-equivalent resampling harness in
this single-timeframe backtest). This module applies WaveTrend's own
overbought/oversold levels (obLevel1=60 / osLevel1=-60) to the entry
timeframe itself only. The secondary, looser obLevel2/osLevel2 (53/-53)
thresholds from the source are not used (level1 is the primary signal
level the script's own default `fl_WTLine` plots highlight).

Also not ported: the bolted-on Stochastic-of-RSI ("DSS") multi-TF block
in the same file (identical construction to parad_osc.py, which is the
canonical port of that -- this file's copy is a duplicate; see that
module for DSS specifics) and the RSI multi-TF block (a straight
duplicate of parad_rsi.py, entirely commented out / disabled in this
file's source anyway).

Signal definition: edge-triggered WaveTrend extreme entry -- long fires
the bar `wt` first drops below -60 (oversold), short fires the bar `wt`
first rises above 60 (overbought), the natural mean-reversion trade read
of an extreme-value scanner.
"""
from __future__ import annotations

import pandas as pd

from .common import Signal, ema, sma, synthetic_stop, atr, SYNTHETIC_ATR_LEN

N1 = 10   # Channel Length
N2 = 21   # Average Length
OB_LEVEL1 = 60
OS_LEVEL1 = -60


def _wavetrend(df: pd.DataFrame) -> pd.Series:
    hlc3 = (df["high"] + df["low"] + df["close"]) / 3
    esa = ema(hlc3, N1)
    d = ema((hlc3 - esa).abs(), N1)
    ci = (hlc3 - esa) / (0.015 * d.replace(0, float("nan")))
    return sma(ema(ci, N2), 4)


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    close = df["close"]
    wt = _wavetrend(df)
    atr_synth = atr(df, SYNTHETIC_ATR_LEN)

    oversold_now = wt <= OS_LEVEL1
    overbought_now = wt >= OB_LEVEL1
    oversold_prev = oversold_now.shift(1).fillna(False)
    overbought_prev = overbought_now.shift(1).fillna(False)

    enter_long = oversold_now & ~oversold_prev
    enter_short = overbought_now & ~overbought_prev

    signals: list[Signal] = []
    for i in range(len(df)):
        if pd.isna(atr_synth.iloc[i]) or pd.isna(wt.iloc[i]):
            continue
        direction = None
        if bool(enter_long.iloc[i]):
            direction = "long"
        elif bool(enter_short.iloc[i]):
            direction = "short"
        if direction is None:
            continue

        entry = float(close.iloc[i])
        sl = synthetic_stop(entry, float(atr_synth.iloc[i]), direction)
        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=sl,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="parad_wt", synthetic_stop=True,
        ))

    return signals
