"""Two-pole filter streak-counter signal, extracted as a standalone,
reusable module because the same construct ("Two-Pole Filter" method +
rising/falling streak counters + a threshold crossover) recurs verbatim
in at least three of the source files handed out for this porting batch:
Extreme Reversal Signal (ExtremeReversal.txt), an Adaptive Kalman Filter
oscillator, and a Zero Lag Signals file (the latter two owned by other
agents in this effort -- they were told to skip re-implementing this and
just point back here).

Source construct (from ExtremeReversal.txt):

    method two_pole_filter(float src, int length, float damping) =>
        float omega = 2.0 * math.pi / length
        float alpha = damping * omega
        float beta  = math.pow(omega, 2)
        var float f1 = na
        var float f2 = na
        f1 := nz(f1[1]) + alpha * (src - nz(f1[1]))
        f2 := nz(f2[1]) + beta  * (f1 - nz(f2[1]))
        f2

    up = tp_f > tp_f[2]
    dn = tp_f < tp_f[2]
    if up
        rising += 1
        falling := 0
    if dn
        rising := 0
        falling += 1

    sig_up = ta.crossover(rising, ris_fal) and barstate.isconfirmed
    sig_dn = ta.crossover(falling, ris_fal) and barstate.isconfirmed

`sig_up` (rising-streak crosses the threshold) is plotted as a bullish
"Rising" triangle below the bar; `sig_dn` (falling-streak crosses the
threshold) is a bearish "Falling" triangle above the bar -- so sig_up is
ported here as a "long" Signal and sig_dn as "short". The `Signals`
toggle that gates these in the original (default false, since the file
ships with the alerts turned off by default) is treated as always-on
here since porting the OFF state would just mean "this sub-signal never
fires"; we port the signal logic itself, same convention used elsewhere
in this collection for default-off toggles that gate an otherwise fully
specified rule.

Not ported: the `atr`-offset circle markers (`tp_f +/- atr`) and bar
coloring -- pure visualization, no bearing on sig_up/sig_dn.
"""
from __future__ import annotations

import math

import numpy as np
import pandas as pd

from .common import Signal, atr as atr_fn, synthetic_stop, SYNTHETIC_ATR_LEN, SYNTHETIC_ATR_MULT

LENGTH = 100
DAMPING = 0.9
RISING_FALLING_THRESHOLD = 5


def two_pole_filter(src: pd.Series, length: int = LENGTH, damping: float = DAMPING) -> pd.Series:
    """Direct translation of the Pine `two_pole_filter` method. Recursive
    (each output depends on its own previous value), so this is computed
    with an explicit loop rather than vectorized -- still fully causal,
    output[i] only depends on src[<=i] and output[<i]."""
    omega = 2.0 * math.pi / length
    alpha = damping * omega
    beta = omega ** 2

    vals = src.to_numpy(dtype=float)
    n = len(vals)
    f1 = np.zeros(n)
    f2 = np.zeros(n)
    prev_f1 = 0.0  # nz(f1[1]) treats the undefined seed as 0.0
    prev_f2 = 0.0
    for i in range(n):
        s = vals[i]
        if np.isnan(s):
            f1[i] = prev_f1
            f2[i] = prev_f2
            continue
        cur_f1 = prev_f1 + alpha * (s - prev_f1)
        cur_f2 = prev_f2 + beta * (cur_f1 - prev_f2)
        f1[i] = cur_f1
        f2[i] = cur_f2
        prev_f1, prev_f2 = cur_f1, cur_f2

    return pd.Series(f2, index=src.index)


def _rising_falling_counters(tp_f: pd.Series) -> tuple[np.ndarray, np.ndarray]:
    vals = tp_f.to_numpy(dtype=float)
    n = len(vals)
    rising = np.zeros(n, dtype=int)
    falling = np.zeros(n, dtype=int)
    r, f = 0, 0
    for i in range(n):
        if i < 2 or np.isnan(vals[i]) or np.isnan(vals[i - 2]):
            rising[i], falling[i] = r, f
            continue
        up = vals[i] > vals[i - 2]
        dn = vals[i] < vals[i - 2]
        if up:
            r += 1
            f = 0
        if dn:
            r = 0
            f += 1
        rising[i], falling[i] = r, f
    return rising, falling


def generate_signals(
    df: pd.DataFrame,
    length: int = LENGTH,
    damping: float = DAMPING,
    ris_fal: int = RISING_FALLING_THRESHOLD,
    label: str = "two_pole_filter_signal",
) -> list[Signal]:
    close = df["close"]
    tp_f = two_pole_filter(close, length, damping)
    rising, falling = _rising_falling_counters(tp_f)

    atr_series = atr_fn(df, SYNTHETIC_ATR_LEN)

    signals: list[Signal] = []
    for i in range(1, len(df)):
        sig_up = rising[i] > ris_fal and rising[i - 1] <= ris_fal
        sig_dn = falling[i] > ris_fal and falling[i - 1] <= ris_fal
        if not (sig_up or sig_dn):
            continue
        atrv = atr_series.iloc[i]
        if pd.isna(atrv):
            continue

        entry = float(close.iloc[i])
        direction = "long" if sig_up else "short"
        stop = synthetic_stop(entry, float(atrv), direction, SYNTHETIC_ATR_MULT)

        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=stop,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label=label, synthetic_stop=True,
        ))

    return signals
