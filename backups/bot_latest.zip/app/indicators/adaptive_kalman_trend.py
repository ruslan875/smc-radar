"""Port of "Adaptive Kalman Filter with Trend Signals" (code:
2d41efc2-code_Adaptive_Kalman_Filter_with_Trend_Signals.txt, description:
968c676b-description_...txt).

The source runs a two-stage 2-state (level, "trend"/oscillator) linear
Kalman filter (state-transition F=[[1,1],[1,0]], the second stage
re-filtering the first stage's own level estimate with much looser
process/measurement noise to produce a smoother `filtered_src2`), then
derives a discrete trend-flip signal from that smoothed price:

    basis        = ta.sma(filtered_src2, 20)
    upper_signal = basis + ta.stdev(filtered_src2, 20, biased=true)
    lower_signal = basis - ta.stdev(filtered_src2, 20, biased=true)

    trend_signal := kf_src > basis and kf_src > upper_signal ?  1
                  : kf_src < basis and kf_src < lower_signal ? -1
                  : trend_signal[1]   (persists otherwise)

    alertcondition(ta.crossover(trend_signal, 0), "Bullish Trend ...")
    alertcondition(ta.crossunder(trend_signal, 0), "Bearish Trend ...")

Ported directly against those two native alertcondition()s (long on
crossover(trend_signal,0), short on crossunder) -- this is the only
alert-worthy discrete signal the script itself defines.

Kalman filter math note: the Pine source's `kalmanStep()` prediction
step is NOT a textbook full 2x2 matrix-vector product for the state
mean -- it literally computes `pred_x2 = F[1][1] * X[1]` (using only the
F(1,1) entry, which is never set and therefore always 0), while the
COVARIANCE prediction (`pred_P`) does use the full F matrix product.
That asymmetry is preserved exactly here for fidelity (see
`_kalman_step`) rather than "fixed" to the mathematically-expected
`F[1][0]*X[0] + F[1][1]*X[1]`, since the goal is byte-for-byte behaviour
matching, not a textbook-correct Kalman filter.

NOT PORTED (visualization/alert-adjacent, no bearing on the trend
signal): the "Trend Strength" gauge/table, the confidence-interval
projection boxes (`calcHiLo`/`confEstPos`/`confEstNeg`), the take-profit
crosses (`ta.crossover(kf_src, lower1_signal)` etc. -- these ARE genuine
alertconditions in the source but are exit/TP markers, not entries; the
generic backtester's own 1R/2R/3R ladder is used instead per this
batch's convention), and the Parkinson/volume-adjusted Kalman model
variants (`selected_kf_model` defaults to "standard", which is what's
implemented; the other two only change the measurement-noise adjustment
factor and are not selectable here).

The QQE construction embedded in the back half of this same source file
(`RSI_Period`/`SF`/`QQE`/`ThreshHold`/`qqeLong_signal`/`qqeShort_signal`)
is intentionally NOT ported here -- it is extracted into its own
standalone, reusable module, qqe_signal.py (see that module's docstring;
note the batch task description associated the QQE extraction with the
*other* Kalman file, but the QQE code is actually here -- ported from
its actual location).
"""
from __future__ import annotations

import pandas as pd

from .common import Signal, sma, stdev, synthetic_stop, atr, SYNTHETIC_ATR_LEN

# ~~ Kalman filter settings (Pine defaults) ~~
MEAS_NOISE_1 = 500.0          # fixed in source (not an input)
MEAS_NOISE_2 = 5000.0         # "Measurement Noise" input default
P_NOISE_1, P_NOISE_2 = 0.01, 0.01     # stage-1 process noise
P_NOISE_1B, P_NOISE_2B = 0.00, 1000.0  # stage-2 process noise

# ~~ Trend Strength Signals settings ~~
TREND_LEN = 20    # `lenn`


def _kalman_step(X, P, Q, R, src):
    """One predict+update step of the source's 2-state Kalman filter.
    F = [[1,1],[1,0]], H = [[1,0]], I = 2x2 identity -- all fixed, so
    they're inlined rather than passed around as matrices.

    Deliberately replicates the source's asymmetric prediction step:
    pred_x1 = X0 + X1 (full F row 0), pred_x2 = 0 (F row 1 uses only
    F[1][1]=0, dropping the F[1][0]*X0 term Pine's own F matrix defines
    but the scalar pred_X line never applies) -- see module docstring.
    """
    x0, x1 = X
    pred_x0 = x0 + x1
    pred_x1 = 0.0
    pred_X = (pred_x0, pred_x1)

    (p00, p01), (p10, p11) = P
    # F @ P
    fp00, fp01 = p00 + p10, p01 + p11
    fp10, fp11 = p00, p01
    # (F@P) @ F^T
    fpft00 = fp00 + fp01
    fpft01 = fp00
    fpft10 = fp10 + fp11
    fpft11 = fp10
    q00, q01 = Q[0]
    q10, q11 = Q[1]
    pred_P = ((fpft00 + q00, fpft01 + q01), (fpft10 + q10, fpft11 + q11))

    r_adj = R  # standard model only (see docstring)

    # S = H @ pred_P @ H^T + R  (H = [1, 0])
    s = pred_P[0][0] + r_adj
    # K = pred_P @ H^T / S  (2x1)
    k0, k1 = pred_P[0][0] / s, pred_P[1][0] / s

    innovation = src - pred_X[0]
    new_x0 = pred_X[0] + k0 * innovation
    new_x1 = pred_X[1] + k1 * innovation
    new_X = (new_x0, new_x1)

    # new_P = (I - K@H) @ pred_P ,  K@H = [[k0,0],[k1,0]]
    new_p00 = (1 - k0) * pred_P[0][0]
    new_p01 = (1 - k0) * pred_P[0][1]
    new_p10 = -k1 * pred_P[0][0] + pred_P[1][0]
    new_p11 = -k1 * pred_P[0][1] + pred_P[1][1]
    new_P = ((new_p00, new_p01), (new_p10, new_p11))

    return new_X, new_P


def _two_stage_kalman_filtered_src(close: pd.Series) -> pd.Series:
    n = len(close)
    src = close.to_numpy()

    X = (0.0, 0.0)
    P = ((1.0, 0.0), (0.0, 1.0))
    Q1 = ((P_NOISE_1, P_NOISE_1 * P_NOISE_2), (P_NOISE_2 * P_NOISE_1, P_NOISE_2))

    X2 = (0.0, 0.0)
    P2 = ((1.0, 0.0), (0.0, 1.0))
    Q2 = ((P_NOISE_1B, P_NOISE_1B * P_NOISE_2B), (P_NOISE_2B * P_NOISE_1B, P_NOISE_2B))

    filtered_src2 = [float("nan")] * n
    for i in range(n):
        X, P = _kalman_step(X, P, Q1, MEAS_NOISE_1, src[i])
        X2, P2 = _kalman_step(X2, P2, Q2, MEAS_NOISE_2, X[0])
        filtered_src2[i] = X2[0]

    return pd.Series(filtered_src2, index=close.index)


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    close = df["close"]
    kf_src = _two_stage_kalman_filtered_src(close)

    basis = sma(kf_src, TREND_LEN)
    band = stdev(kf_src, TREND_LEN)
    upper_signal = basis + band
    lower_signal = basis - band

    n = len(df)
    trend_signal = [0] * n
    for i in range(n):
        if pd.isna(basis.iloc[i]):
            trend_signal[i] = trend_signal[i - 1] if i > 0 else 0
            continue
        if kf_src.iloc[i] > basis.iloc[i] and kf_src.iloc[i] > upper_signal.iloc[i]:
            trend_signal[i] = 1
        elif kf_src.iloc[i] < basis.iloc[i] and kf_src.iloc[i] < lower_signal.iloc[i]:
            trend_signal[i] = -1
        else:
            trend_signal[i] = trend_signal[i - 1] if i > 0 else 0

    atr_synth = atr(df, SYNTHETIC_ATR_LEN)
    signals: list[Signal] = []
    for i in range(1, n):
        if pd.isna(atr_synth.iloc[i]):
            continue
        crossover = trend_signal[i] > 0 and trend_signal[i - 1] <= 0
        crossunder = trend_signal[i] < 0 and trend_signal[i - 1] >= 0
        if not (crossover or crossunder):
            continue
        direction = "long" if crossover else "short"
        entry = float(close.iloc[i])
        sl = synthetic_stop(entry, float(atr_synth.iloc[i]), direction)
        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=sl,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="adaptive_kalman_trend", synthetic_stop=True,
        ))

    return signals
