"""Port of "Adaptive Kalman filter - Trend Strength Oscillator" (code:
f0f7ea58-code_Adaptive_Kalman_filter_Trend_Strength_Oscillator_with_
Signals.txt, description: f83c42a5-description_...txt).

Despite the "with signals" title, the oscillator itself has NO native
alertcondition, plotshape, or label anywhere in the source -- the only
actual Buy/Sell plotshapes in the file belong to an unrelated bolted-on
channel-breakout script tacked onto the bottom (ported separately as
channel_breakout.py; see that module). This module ports only the
primary Kalman Trend Strength Oscillator itself.

Single-stage 2-state Kalman filter (same F/H/I structure and the same
prediction-step asymmetry as adaptive_kalman_trend.py -- see that
module's docstring for the fidelity note on why `pred_x2` only uses
F(1,1)=0 rather than the full matrix row; this file's `kalmanStep` has
the identical construction), seeded with `X = [close[0], close[0]]` on
the first bar rather than `[0, 0]`. The oscillator state (`X[1]`) is
turned into a bounded trend-strength reading:

    A               = max(|oscillator|) over the trailing `N2`-bar window   (N2 = "Trend Lookback" = 10)
    raw_strength    = ta.wma(oscillator / A * 100, R2)                     (R2 = "Strength Smoothness" = 10)
    oscPlot         = ta.wma(raw_strength, R1)                             (R1 = "Osc Smoothness" = 10)

with OBOS reference bands drawn at +-70 and gradient fills starting at
+-30 -- but again, no discrete entry condition is ever compared against
either of those in the source.

APPROXIMATION (documented, not a native signal): since a discrete
Signal is required by every module in this batch and none exists
natively, this fires long/short on `oscPlot` crossing the zero line
(the only trend-direction event the oscillator's own math defines),
mirroring the same "trend flip" convention used by
adaptive_kalman_trend.py's native trend_signal for consistency across
the two related Kalman modules in this batch. A mean-reversion read off
the +-70 OBOS bands would be an equally defensible alternative
interpretation; zero-cross was chosen as the more conservative,
less-parameter-sensitive one.

Not ported: the volume-adjusted / Parkinson-adjusted Kalman model
variants (defaults to "standard", same as adaptive_kalman_trend.py), the
gradient-coloring table, and the trend-strength gauge table (pure
display).
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .common import Signal, synthetic_stop, atr, SYNTHETIC_ATR_LEN

MEASUREMENT_NOISE = 500.0
P_NOISE_1, P_NOISE_2 = 0.01, 0.01
N2 = 10   # "Trend Lookback" -- rolling window for max(|oscillator|)
R1 = 10   # "Osc Smoothness" -- final WMA length
R2 = 10   # "Strength Smoothness" -- first WMA length


def _kalman_step(X, P, Q, R, src):
    """Same construction (and the same F(1,1)=0 prediction quirk) as
    adaptive_kalman_trend._kalman_step -- see that module's docstring."""
    x0, x1 = X
    pred_x0 = x0 + x1
    pred_x1 = 0.0
    pred_X = (pred_x0, pred_x1)

    (p00, p01), (p10, p11) = P
    fp00, fp01 = p00 + p10, p01 + p11
    fp10, fp11 = p00, p01
    fpft00 = fp00 + fp01
    fpft01 = fp00
    fpft10 = fp10 + fp11
    fpft11 = fp10
    q00, q01 = Q[0]
    q10, q11 = Q[1]
    pred_P = ((fpft00 + q00, fpft01 + q01), (fpft10 + q10, fpft11 + q11))

    s = pred_P[0][0] + R
    k0, k1 = pred_P[0][0] / s, pred_P[1][0] / s

    innovation = src - pred_X[0]
    new_X = (pred_X[0] + k0 * innovation, pred_X[1] + k1 * innovation)

    new_p00 = (1 - k0) * pred_P[0][0]
    new_p01 = (1 - k0) * pred_P[0][1]
    new_p10 = -k1 * pred_P[0][0] + pred_P[1][0]
    new_p11 = -k1 * pred_P[0][1] + pred_P[1][1]
    new_P = ((new_p00, new_p01), (new_p10, new_p11))

    return new_X, new_P


def _wma(values: list[float], length: int) -> list[float]:
    """Causal weighted moving average (linear weights 1..length),
    NaN until `length` samples are available -- matches ta.wma."""
    n = len(values)
    weights = np.arange(1, length + 1, dtype=float)
    wsum = weights.sum()
    out = [float("nan")] * n
    for i in range(length - 1, n):
        window = values[i - length + 1: i + 1]
        if any(np.isnan(v) for v in window):
            continue
        out[i] = float(np.dot(window, weights) / wsum)
    return out


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    close = df["close"]
    n = len(df)
    src = close.to_numpy()

    Q = ((P_NOISE_1, P_NOISE_1 * P_NOISE_2), (P_NOISE_2 * P_NOISE_1, P_NOISE_2))

    oscillator = [0.0] * n
    if n > 0:
        X = (src[0], src[0])
        P = ((1.0, 0.0), (0.0, 1.0))
        for i in range(n):
            X, P = _kalman_step(X, P, Q, MEASUREMENT_NOISE, src[i])
            oscillator[i] = X[1]

    # trend_strength = wma(oscillator / A * 100, R2), A = rolling max(|osc|) over N2
    raw_ratio = [float("nan")] * n
    for i in range(n):
        lo = max(0, i - N2 + 1)
        window = oscillator[lo:i + 1]
        a = max(abs(v) for v in window) if len(window) >= N2 else float("nan")
        if a and a != 0 and not np.isnan(a):
            raw_ratio[i] = oscillator[i] / a * 100

    trend_strength = _wma(raw_ratio, R2)
    osc_plot = _wma(trend_strength, R1)

    atr_synth = atr(df, SYNTHETIC_ATR_LEN)
    signals: list[Signal] = []
    for i in range(1, n):
        if pd.isna(atr_synth.iloc[i]):
            continue
        prev, cur = osc_plot[i - 1], osc_plot[i]
        if np.isnan(prev) or np.isnan(cur):
            continue
        crossover = prev <= 0 < cur
        crossunder = prev >= 0 > cur
        if not (crossover or crossunder):
            continue
        direction = "long" if crossover else "short"
        entry = float(close.iloc[i])
        sl = synthetic_stop(entry, float(atr_synth.iloc[i]), direction)
        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=sl,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="kalman_trend_strength_oscillator", synthetic_stop=True,
        ))

    return signals
