"""Port of the "UT Bot Alert" sub-system bolted onto the front of
JohnScript (source: 04932d32-______.txt, lines 1-73 -- Russian variable
titles translated in this docstring: `a`='Sensitivity', `c`='ATR Period').

This is the classic, widely-cloned "UT Bot Alerts" indicator: an ATR
trailing-stop line that only ever moves in the favourable direction
(ratchets up under an uptrend, down under a downtrend, and only resets
across the price when price actually crosses it), with buy/sell firing on
the bar the trailing stop is crossed.

CANONICAL COPY: this module is intentionally the one other ports in this
collection point back to instead of re-implementing UT Bot themselves
(ComboInd1 bundles an identical copy of JohnScript's UT Bot and is
skipped as a pure duplicate; a separate "OrderBlock with Signals" file
handled by another agent also contains a copy and was told to defer to
this module). Ported as faithfully as possible bar-by-bar from the Pine
source below -- no approximation needed, every operator has a direct
common.py or plain-Python equivalent.

Not ported: the Heikin-Ashi source option (`ha` input, default false --
we always use raw close, matching the default) and the linear-regression
candle / TAST-signal-line cosmetic overlay in the same file section
(`lin_reg`, `sma_signal` inputs feed only `mysignal`/`plotcandle`, which
are pure visualization with no bearing on mybuy/mysell).

Pine reference (verbatim, close-source-only path since ha=false default)::

    xATR = ta.atr(c)                       # c = 10
    nLoss = a * xATR                       # a = 1
    src = close
    xATRTrailingStop := (bar-by-bar ratchet, see _trailing_stop below)
    ema = ta.ema(src, 1)                   # length-1 EMA == src itself
    above = ta.crossover(ema, xATRTrailingStop)
    below = ta.crossover(xATRTrailingStop, ema)
    mybuy  = src > xATRTrailingStop and above
    mysell = src < xATRTrailingStop and below

No native stop-loss/take-profit is defined by the original script (no
alertcondition or plot carries risk levels) -- per the batch-wide
convention, the shared synthetic ATR stop is used and `synthetic_stop`
is flagged True on every Signal.
"""
from __future__ import annotations

import pandas as pd

from .common import Signal, atr, synthetic_stop, SYNTHETIC_ATR_LEN, SYNTHETIC_ATR_MULT

SENSITIVITY = 1          # `a` in the Pine source
ATR_PERIOD = 10           # `c` in the Pine source


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    close = df["close"]
    xatr = atr(df, ATR_PERIOD)
    n_loss = SENSITIVITY * xatr
    atr_synth = atr(df, SYNTHETIC_ATR_LEN)

    n = len(df)
    stop = [0.0] * n          # xATRTrailingStop, nz(...,0) seed
    src = close.to_numpy()
    nloss_arr = n_loss.to_numpy()

    signals: list[Signal] = []

    for i in range(n):
        if i == 0 or pd.isna(nloss_arr[i]):
            # nLoss (via ATR) isn't formed yet -- Pine would still emit a
            # (meaningless) stop of +-src since xATR is na, but no valid
            # trade signal can fire before ATR is seeded, so just carry
            # the same nz(...,0)-seeded value forward.
            stop[i] = 0.0
            continue

        prev_stop = stop[i - 1]
        prev_src = src[i - 1]
        cur_src = src[i]
        nloss = nloss_arr[i]

        if cur_src > prev_stop and prev_src > prev_stop:
            new_stop = max(prev_stop, cur_src - nloss)
        elif cur_src < prev_stop and prev_src < prev_stop:
            new_stop = min(prev_stop, cur_src + nloss)
        elif cur_src > prev_stop:
            new_stop = cur_src - nloss
        else:
            new_stop = cur_src + nloss
        stop[i] = new_stop

        if i < 2:
            continue

        # ta.crossover(a, b): a[1] <= b[1] and a > b, all evaluated with
        # each series' OWN bar (ema[i] == src[i] since length-1 EMA).
        above = (prev_src <= prev_stop) and (cur_src > new_stop)
        below = (prev_stop <= prev_src) and (new_stop > cur_src)

        mybuy = cur_src > new_stop and above
        mysell = cur_src < new_stop and below
        if not (mybuy or mysell):
            continue

        direction = "long" if mybuy else "short"
        entry = float(cur_src)
        sl = synthetic_stop(entry, float(atr_synth.iloc[i]), direction, SYNTHETIC_ATR_MULT) \
            if not pd.isna(atr_synth.iloc[i]) else None
        if sl is None:
            continue

        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=sl,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="ut_bot_alert", synthetic_stop=True,
        ))

    return signals
