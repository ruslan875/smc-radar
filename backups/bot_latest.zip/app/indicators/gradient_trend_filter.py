"""Port of the primary "Gradient Trend Filter" diamond-reversal signal
from "Gradient Trend Filter [with signals local]" (source:
Gradient_trend_with_local_signals_________________________________.txt,
© ChartPrime). This file bundles TWO independent signal systems; the
other one (HEMA20/HEMA40 cross with box re-test markers) is ported
separately as `app/indicators/hema_cross.py`.

Entry logic:
  - `base` = a triple-stage single-pole EMA smoothing of `close`
    (`noise_filter`, alpha = 2/(length+1), length=25 by default). Each
    stage `nf := alpha*src + (1-alpha)*nf[1]` is algebraically identical
    to `ta.ema(src, length)` (same alpha derivation), so this is
    implemented simply as `ema(ema(ema(close, 25), 25), 25)`.
  - `diff = base - base[2]`.
  - Long ("signal_up"): `diff` crosses over 0.
  - Short ("signal_dn"): `diff` crosses under 0.

`barstate.isconfirmed` is a no-op here (every historical bar is already
closed).

Not ported: the six `bands()` levels (`upper1..upper3`/`lower1..lower3`)
and all gradient-fill visuals -- pure display, not referenced by
`signal_up`/`signal_dn`. `isFilter` in the source only toggles whether
the `base` line/bands are drawn -- it does NOT gate `signal_up`/
`signal_dn` (they're computed unconditionally), so it has no Python
counterpart here.
"""
from __future__ import annotations

import pandas as pd

from .common import Signal, ema, atr, synthetic_stop, SYNTHETIC_ATR_LEN

LENGTH = 25


def _noise_filter(src: pd.Series, length: int) -> pd.Series:
    return ema(ema(ema(src, length), length), length)


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    close = df["close"]

    base = _noise_filter(close, LENGTH)
    diff = base - base.shift(2)

    signal_up = (diff.shift(1) < 0) & (diff > 0)
    signal_dn = (diff.shift(1) > 0) & (diff < 0)

    atr_series = atr(df, SYNTHETIC_ATR_LEN)
    signals: list[Signal] = []
    valid_from = LENGTH * 3 + 3

    for i in range(valid_from, len(df)):
        up = bool(signal_up.iloc[i]) if not pd.isna(signal_up.iloc[i]) else False
        dn = bool(signal_dn.iloc[i]) if not pd.isna(signal_dn.iloc[i]) else False
        if not (up or dn):
            continue
        atr_v = atr_series.iloc[i]
        if pd.isna(atr_v):
            continue

        entry = float(close.iloc[i])
        direction = "long" if up else "short"
        stop = synthetic_stop(entry, float(atr_v), direction)
        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=stop,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="gradient_trend_filter", synthetic_stop=True,
        ))

    return signals
