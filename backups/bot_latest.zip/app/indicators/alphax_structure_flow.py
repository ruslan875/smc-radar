"""Port of "Structure Flow Pro" / AlphaX (source: SMCFlowIndicator.txt,
1303 lines -- the SMCFlowIndicator description file is a Russian summary
of the same indicator, confirmed consistent with the code).

This is a large SMC "confluence engine": pivot-based market structure
break (MSB) / body-close break of structure (BMS), an order-block engine
with a 0-100 quality score and High-Probability-Zone (HPZ) classification,
Fair Value Gaps (FVG), liquidity sweeps, equal highs/lows, session ranges
and an on-chart dashboard. Only the actual entry rule is ported here --
everything else in the file (structure swing lines, EQH/EQL, sessions,
dashboard table) is pure visualization with no bearing on `bullSignal`/
`bearSignal`, confirmed by grep'ing every `alertcondition(...)` in the
source: the only conviction/entry-tier alerts fire off `bullSignal`/
`bearSignal` (lines ~857-877 of the source), everything else alerts on
sub-components (MSB, sweeps, FVGs) that only feed the SMC score below.

Ported entry rule (SMC Confluence Engine, `smcEnabled` default true):

    bullSignalRaw = bullSMC >= minSMCScore and volOK and (isMSBBull or bullSweep)
    bearSignalRaw = bearSMC >= minSMCScore and volOK and (isMSBBear or bearSweep)
    bullSignal = bullSignalRaw and (bar_index - lastBullBar >= cooldownBars)
    bearSignal = bearSignalRaw and (bar_index - lastBearBar >= cooldownBars)

where bullSMC/bearSMC are the weighted 0-100 scores computed in
`calcBullSMC()`/`calcBearSMC()` from: MSB/BMS strength, a liquidity sweep
at the extreme, nearby active HPZ order blocks, opposing unfilled FVGs as
a "draw on liquidity" magnet, momentum Z-score, volume ratio, and candle
body strength -- reproduced verbatim below, including the order-block and
FVG state machines (mitigation, quality scoring, array eviction once
`obCount`/50 respectively is exceeded) that those score inputs depend on.

Fidelity notes:
- `useVolFilter` defaults to **false** in the source, so `volOK` is always
  True here; the `Require Volume Confirmation` toggle and its
  `Min Volume Ratio` gate were not implemented since they're off by
  default (same convention as quantum_scalper.py's MTF toggle).
- `ta.percentrank(volume, 100)` (used inside the OB quality score) is
  reproduced as "% of the previous 100 bars with volume strictly less
  than the current bar", matching Pine's documented definition.
- The engine is inherently stateful (order blocks and FVGs persist,
  mitigate, and age out across bars, same as the original's `var array`
  usage) so this is implemented as a single causal forward loop rather
  than vectorized, matching Pine's own bar-by-bar execution model.
"""
from __future__ import annotations

import math

import numpy as np
import pandas as pd

from .common import (
    Signal, atr, sma, stdev, highest, lowest, pivothigh, pivotlow,
    synthetic_stop, SYNTHETIC_ATR_LEN, SYNTHETIC_ATR_MULT,
)

PIVOT_LEN = 7
MSB_Z_SCORE = 0.5
BMS_ENABLED = True

OB_COUNT = 10
OB_LOOKBACK = 10
HPZ_THRESH = 75.0

FVG_MIN_SIZE = 0.05
SWEEP_LOOKBACK = 20

MIN_SMC_SCORE = 30
COOLDOWN_BARS = 3
USE_VOL_FILTER = False   # default off in the source
VOL_MIN_RATIO = 0.7


def _percentrank(series: pd.Series, length: int) -> pd.Series:
    """Pine ta.percentrank(source, length): % of the previous `length`
    bars whose value is strictly less than the current bar's value."""
    def _f(x: np.ndarray) -> float:
        cur = x[-1]
        prev = x[:-1]
        return 100.0 * float(np.sum(prev < cur)) / length
    return series.rolling(length + 1, min_periods=length + 1).apply(_f, raw=True)


def _calc_bull_smc(is_msb_bull, is_bms_bull, bull_sweep, near_bull_hpz, near_bear_hpz,
                    fvg_bear_above, momentum_z, vol_ratio, close_i, open_i, body_ratio) -> float:
    s = 30.0 if is_msb_bull else (20.0 if is_bms_bull else 0.0)
    s += 20.0 if bull_sweep else 0.0
    s += 18.0 if near_bull_hpz >= 2 else (10.0 if near_bull_hpz == 1 else 0.0)
    s += 10.0 if fvg_bear_above >= 2 else (5.0 if fvg_bear_above == 1 else 0.0)
    s += 12.0 if momentum_z > 2.0 else (7.0 if momentum_z > 1.0 else (3.0 if momentum_z > 0.5 else 0.0))
    s += 8.0 if vol_ratio > 2.0 else (5.0 if vol_ratio > 1.3 else (2.0 if vol_ratio > 1.0 else 0.0))
    s += 6.0 if (close_i > open_i and body_ratio > 0.6) else (3.0 if close_i > open_i else 0.0)
    s -= 10.0 if momentum_z < -1.0 else 0.0
    s -= 8.0 if near_bear_hpz >= 2 else 0.0
    return max(0.0, min(100.0, s))


def _calc_bear_smc(is_msb_bear, is_bms_bear, bear_sweep, near_bear_hpz, near_bull_hpz,
                    fvg_bull_below, momentum_z, vol_ratio, close_i, open_i, body_ratio) -> float:
    s = 30.0 if is_msb_bear else (20.0 if is_bms_bear else 0.0)
    s += 20.0 if bear_sweep else 0.0
    s += 18.0 if near_bear_hpz >= 2 else (10.0 if near_bear_hpz == 1 else 0.0)
    s += 10.0 if fvg_bull_below >= 2 else (5.0 if fvg_bull_below == 1 else 0.0)
    s += 12.0 if momentum_z < -2.0 else (7.0 if momentum_z < -1.0 else (3.0 if momentum_z < -0.5 else 0.0))
    s += 8.0 if vol_ratio > 2.0 else (5.0 if vol_ratio > 1.3 else (2.0 if vol_ratio > 1.0 else 0.0))
    s += 6.0 if (close_i < open_i and body_ratio > 0.6) else (3.0 if close_i < open_i else 0.0)
    s -= 10.0 if momentum_z > 1.0 else 0.0
    s -= 8.0 if near_bull_hpz >= 2 else 0.0
    return max(0.0, min(100.0, s))


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    high, low, close, open_ = df["high"], df["low"], df["close"], df["open"]
    n = len(df)

    atr_val = atr(df, 14)
    synth_atr = atr(df, SYNTHETIC_ATR_LEN)

    price_change = close.diff()
    avg_change = sma(price_change, 50)
    std_change = stdev(price_change, 50)
    momentum_z = ((price_change - avg_change) / std_change.replace(0, np.nan)).fillna(0.0)
    momentum_z = momentum_z.where(std_change > 0, 0.0)

    vol_percent = _percentrank(df["volume"], 100)
    vol_sma = sma(df["volume"], 20)
    vol_ratio = (df["volume"] / vol_sma.replace(0, np.nan))
    vol_ratio = vol_ratio.where(vol_sma > 0, 1.0)

    candle_body = (close - open_).abs()
    candle_range = high - low
    body_ratio = (candle_body / candle_range.replace(0, np.nan)).where(candle_range > 0, 0.0)

    ph = pivothigh(high, PIVOT_LEN, PIVOT_LEN)
    pl = pivotlow(low, PIVOT_LEN, PIVOT_LEN)

    sweep_low_prev = lowest(low.shift(1), SWEEP_LOOKBACK)
    sweep_high_prev = highest(high.shift(1), SWEEP_LOOKBACK)
    bull_sweep_s = (low < sweep_low_prev) & (close > sweep_low_prev) & (close > open_)
    bear_sweep_s = (high > sweep_high_prev) & (close < sweep_high_prev) & (close < open_)

    fvg_min_sz = atr_val * FVG_MIN_SIZE
    bull_fvg_s = (low > high.shift(2)) & ((low - high.shift(2)) >= fvg_min_sz)
    bear_fvg_s = (high < low.shift(2)) & ((low.shift(2) - high) >= fvg_min_sz)

    last_ph = math.nan
    last_pl = math.nan
    ob_list: list[dict] = []
    fvg_list: list[dict] = []
    last_bull_bar = -10 ** 9
    last_bear_bar = -10 ** 9

    signals: list[Signal] = []

    for i in range(n):
        if not pd.isna(ph.iloc[i]):
            last_ph = float(ph.iloc[i])
        if not pd.isna(pl.iloc[i]):
            last_pl = float(pl.iloc[i])

        c = float(close.iloc[i])
        c_prev = float(close.iloc[i - 1]) if i > 0 else math.nan
        mz = momentum_z.iloc[i]
        mz = 0.0 if pd.isna(mz) else float(mz)
        br = body_ratio.iloc[i]
        br = 0.0 if pd.isna(br) else float(br)
        rng = candle_range.iloc[i]

        is_msb_bull = (not math.isnan(last_ph)) and c > last_ph and not math.isnan(c_prev) \
            and c_prev <= last_ph and mz > MSB_Z_SCORE
        is_msb_bear = (not math.isnan(last_pl)) and c < last_pl and not math.isnan(c_prev) \
            and c_prev >= last_pl and mz < -MSB_Z_SCORE

        is_bms_bull = BMS_ENABLED and (not math.isnan(last_ph)) and c > last_ph and not math.isnan(c_prev) \
            and c_prev <= last_ph and rng > 0 and br > 0.5
        is_bms_bear = BMS_ENABLED and (not math.isnan(last_pl)) and c < last_pl and not math.isnan(c_prev) \
            and c_prev >= last_pl and rng > 0 and br > 0.5

        # ── Order block creation ──────────────────────────────────────
        if is_msb_bull or is_msb_bear:
            ob_idx = None
            for k in range(1, OB_LOOKBACK + 1):
                if i - k < 0:
                    break
                c_k = close.iloc[i - k]
                o_k = open_.iloc[i - k]
                if (is_msb_bull and c_k < o_k) or (is_msb_bear and c_k > o_k):
                    ob_idx = k
                    break

            if ob_idx is not None:
                ob_top = float(high.iloc[i - ob_idx])
                ob_bottom = float(low.iloc[i - ob_idx])
                ob_size = ob_top - ob_bottom
                atrv = atr_val.iloc[i]
                vp = vol_percent.iloc[i]
                vp = 0.0 if pd.isna(vp) else float(vp)
                size_term = (ob_size / atrv * 10.0) if (not pd.isna(atrv) and atrv > 0) else 0.0
                base_score = min(100.0, abs(mz) * 15.0 + vp * 0.4 + br * 20.0 + size_term)
                score = max(0.0, min(100.0, base_score))
                is_hpz = score >= HPZ_THRESH
                ob_list.append({
                    "top": ob_top, "bottom": ob_bottom,
                    "is_bull": bool(is_msb_bull), "is_hpz": is_hpz, "mitigated": False,
                })

            if is_msb_bull:
                last_ph = math.nan
            else:
                last_pl = math.nan

        # ── OB mitigation + FIFO cap ────────────────────────────────
        for ob in ob_list:
            if not ob["mitigated"]:
                mitigated_now = (low.iloc[i] < ob["bottom"]) if ob["is_bull"] else (high.iloc[i] > ob["top"])
                if mitigated_now:
                    ob["mitigated"] = True
        if len(ob_list) > OB_COUNT:
            ob_list.pop(0)

        # ── FVG creation, fill tracking, FIFO cap ───────────────────
        if i >= 2 and bool(bull_fvg_s.iloc[i]):
            fvg_list.append({"top": float(low.iloc[i]), "bottom": float(high.iloc[i - 2]),
                              "is_bull": True, "filled": False})
        if i >= 2 and bool(bear_fvg_s.iloc[i]):
            fvg_list.append({"top": float(low.iloc[i - 2]), "bottom": float(high.iloc[i]),
                              "is_bull": False, "filled": False})
        for fvg in fvg_list:
            if not fvg["filled"]:
                filled_now = (low.iloc[i] <= fvg["top"]) if fvg["is_bull"] else (high.iloc[i] >= fvg["bottom"])
                if filled_now:
                    fvg["filled"] = True
        if len(fvg_list) > 50:
            fvg_list.pop(0)

        # ── Confluence inputs ────────────────────────────────────────
        near_bull_hpz = 0
        near_bear_hpz = 0
        atrv = atr_val.iloc[i]
        if not pd.isna(atrv):
            for ob in ob_list:
                if not ob["mitigated"] and ob["is_hpz"] and (c >= ob["bottom"] - atrv * 2) and (c <= ob["top"] + atrv * 2):
                    if ob["is_bull"]:
                        near_bull_hpz += 1
                    else:
                        near_bear_hpz += 1

        fvg_bull_below = 0
        fvg_bear_above = 0
        for fvg in fvg_list:
            if not fvg["filled"]:
                if fvg["is_bull"] and fvg["top"] < c:
                    fvg_bull_below += 1
                if not fvg["is_bull"] and fvg["bottom"] > c:
                    fvg_bear_above += 1

        bull_sw = bool(bull_sweep_s.iloc[i]) if not pd.isna(bull_sweep_s.iloc[i]) else False
        bear_sw = bool(bear_sweep_s.iloc[i]) if not pd.isna(bear_sweep_s.iloc[i]) else False

        vr = vol_ratio.iloc[i]
        vr = 1.0 if pd.isna(vr) else float(vr)
        vol_ok = True  # useVolFilter default off

        bull_smc = _calc_bull_smc(is_msb_bull, is_bms_bull, bull_sw, near_bull_hpz, near_bear_hpz,
                                   fvg_bear_above, mz, vr, c, float(open_.iloc[i]), br)
        bear_smc = _calc_bear_smc(is_msb_bear, is_bms_bear, bear_sw, near_bear_hpz, near_bull_hpz,
                                   fvg_bull_below, mz, vr, c, float(open_.iloc[i]), br)

        bull_signal_raw = bull_smc >= MIN_SMC_SCORE and vol_ok and (is_msb_bull or bull_sw)
        bear_signal_raw = bear_smc >= MIN_SMC_SCORE and vol_ok and (is_msb_bear or bear_sw)

        bull_cool_ok = (i - last_bull_bar) >= COOLDOWN_BARS
        bear_cool_ok = (i - last_bear_bar) >= COOLDOWN_BARS

        bull_signal = bull_signal_raw and bull_cool_ok
        bear_signal = bear_signal_raw and bear_cool_ok

        if bull_signal:
            last_bull_bar = i
        if bear_signal:
            last_bear_bar = i

        if not (bull_signal or bear_signal):
            continue

        synth = synth_atr.iloc[i]
        if pd.isna(synth):
            continue

        direction = "long" if bull_signal else "short"
        score = bull_smc if bull_signal else bear_smc
        tier = "S" if score >= 70 else ("A" if score >= 55 else "B")
        stop = synthetic_stop(c, float(synth), direction, SYNTHETIC_ATR_MULT)

        signals.append(Signal(
            direction=direction, entry=c, stop_loss=stop,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="alphax_structure_flow", synthetic_stop=True,
            meta={"smc_score": score, "tier": tier},
        ))

    return signals
