"""Port of "ParadRSI" (source: 1159fd7e-ParadRSI.txt).

The original is a multi-timeframe (up to 14 TFs: 1m..1M) RSI extreme-
reading scanner: it pulls `ta.rsi(src, 14)` via `request.security()` on
every enabled timeframe and labels the bar with the list of timeframes
currently reading oversold (<=30.11) or overbought (>=70.11).

NOT REPLICATED: the multi-timeframe confluence aspect. Doing that
faithfully needs a `request.security`-equivalent resampling harness
(fetch/aggregate N higher timeframes from the same base data), which
this single-timeframe backtest does not have. Instead, this module
applies the exact same RSI + overbought/oversold threshold logic to the
entry timeframe itself only (i.e. treats the chart's own timeframe as
the one and only "enabled" TF) -- a single-timeframe extreme-reading
signal, not the original's multi-TF scanner. A real multi-TF confluence
version would need a proper resampling harness and is out of scope here.

Also not ported: the "Calculator" (`fl_DrwCalcRSI` table showing the
average RSI value across bars currently in the OB/OS zone) -- pure
display, no trading signal.

Signal definition: edge-triggered RSI extreme entry, matching the source
script's own oversold/overbought comparison (`rsi <= oversold` / `rsi >=
overbought`) -- long fires the bar RSI first drops into oversold, short
fires the bar RSI first rises into overbought (mean-reversion read, the
natural trade interpretation of an "extreme reading" scanner).
"""
from __future__ import annotations

import pandas as pd

from .common import Signal, rsi, synthetic_stop, atr, SYNTHETIC_ATR_LEN

RSI_LENGTH = 14
OVERBOUGHT = 70.11
OVERSOLD = 30.11


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    close = df["close"]
    rsi_val = rsi(close, RSI_LENGTH)
    atr_synth = atr(df, SYNTHETIC_ATR_LEN)

    oversold_now = rsi_val <= OVERSOLD
    overbought_now = rsi_val >= OVERBOUGHT
    oversold_prev = oversold_now.shift(1).fillna(False)
    overbought_prev = overbought_now.shift(1).fillna(False)

    enter_long = oversold_now & ~oversold_prev
    enter_short = overbought_now & ~overbought_prev

    signals: list[Signal] = []
    for i in range(len(df)):
        if pd.isna(atr_synth.iloc[i]) or pd.isna(rsi_val.iloc[i]):
            continue
        direction = None
        if bool(enter_long.iloc[i]):
            direction = "long"
        elif bool(enter_short.iloc[i]):
            direction = "short"
        if direction is None:
            continue

        entry = float(close.iloc[i])
        sl = synthetic_stop(entry, float(atr_synth.iloc[i]), direction)
        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=sl,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="parad_rsi", synthetic_stop=True,
        ))

    return signals
