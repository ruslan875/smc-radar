"""Port of the "3 & 4 EMAs Big Crosses" signal from "9 indicators in 1
and more" (source lines 58-76): EMA(55) crossing EMA(200) -- the classic
golden cross / death cross. Same file, same direction-label convention
as `ema_cross_small.py` (standard, not inverted): `golden_cross` requires
`EMA3[1] <= EMA4[1]` (55 was below 200, now crossed above = bullish).

No native stop-loss defined -- synthetic ATR(14) stop per the batch
convention.
"""
from __future__ import annotations

import pandas as pd

from .common import Signal, atr, ema, synthetic_stop, SYNTHETIC_ATR_LEN, SYNTHETIC_ATR_MULT

FAST_LENGTH = 55
SLOW_LENGTH = 200


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    close = df["close"]
    fast = ema(close, FAST_LENGTH)
    slow = ema(close, SLOW_LENGTH)

    prev_fast = fast.shift(1)
    prev_slow = slow.shift(1)

    golden = (prev_fast <= prev_slow) & (fast > slow)
    death = (prev_slow <= prev_fast) & (fast < slow)

    atr_synth = atr(df, SYNTHETIC_ATR_LEN)

    signals: list[Signal] = []
    for i in range(len(df)):
        if bool(golden.iloc[i]):
            direction = "long"
        elif bool(death.iloc[i]):
            direction = "short"
        else:
            continue

        a_synth = atr_synth.iloc[i]
        if pd.isna(a_synth):
            continue

        entry = float(close.iloc[i])
        sl = synthetic_stop(entry, float(a_synth), direction, SYNTHETIC_ATR_MULT)
        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=sl,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="ema_cross_golden_55_200", synthetic_stop=True,
        ))

    return signals
