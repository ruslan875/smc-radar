"""Anchored (session) VWAP sweep + reclaim -- a hand-built module for the
next-gen-indicator-research doc's category 4 candidate, NOT a literal port
of any specific TradingView script. Unlike every prior candidate in this
collection (LuxAlgo's actual "Smart Money Concepts" script and the
"Dynamic Swing Anchored VWAP" script referenced in that research doc are
closed/paid or weren't available to read source-for-source), this is this
project's own construction of the well-documented, standard VWAP-reclaim
concept -- flagged here exactly the way `sr_retest_finder.py` and
`rsi_extreme_reversal.py` flag their own "our reading of a classic
construct" status, so it's not mistaken for a verified line-by-line port.

Why this is a genuinely different mechanism from everything else tested
in this project: every prior signal (SMC bot's OB/FVG/BOS, all 49 ported
indicators, squeeze breakout) is either pure price action or a price-only
oscillator. VWAP is volume-weighted and continuously re-anchored every
session -- the "fair value" reference actual market participants (not
just chartists) use for execution benchmarking, so a reclaim of it after
a sweep is a different kind of level than a swing high/low or a Bollinger
zone.

Construction (session = one UTC calendar day, reset at 00:00 UTC -- daily
reset chosen over hourly/funding-interval anchors for simplicity and
because crypto has no single "session open" the way equities do, per the
research doc's own caution about naively porting equity-session concepts):

  vwap[i] = cumsum(typical_price * volume)[i] / cumsum(volume)[i]
            within the current UTC calendar day, typical_price = (H+L+C)/3

  LONG:  price dipped >= MIN_SWEEP_ATR * ATR(14) below vwap at some bar in
         the last LOOKBACK bars (a genuine "sweep" below the level, not
         just brushing it), THEN the current bar's close crosses back
         above vwap (close > vwap, previous close was < previous vwap).
  SHORT: the mirror image above vwap.

Stop-loss is DERIVED from the actual sweep extreme (min low / max high
over the sweep lookback window, +/- a small ATR buffer) rather than a
plain synthetic entry-minus-ATR stop -- same "structure-derived stop"
idea as `liquidity_sweep_mss_fvg.py`'s sweep-extreme stop, though this
project doesn't consider it a fully "native" stop since the underlying
concept has no author-defined risk rule to copy (`synthetic_stop=True`
is still set on every Signal for that reason).
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .common import Signal, atr, synthetic_stop, SYNTHETIC_ATR_LEN, SYNTHETIC_ATR_MULT

MIN_SWEEP_ATR = 0.5     # sweep must clear vwap by this many ATRs to count (filters noise crosses)
LOOKBACK = 6             # bars back to look for a qualifying sweep before the reclaim bar
STOP_BUFFER_ATR = 0.25   # extra buffer beyond the sweep extreme for the stop
SIGNAL_COOLDOWN = 10     # min bars between signals, per direction


def _session_vwap(df: pd.DataFrame) -> pd.Series:
    typical = (df["high"] + df["low"] + df["close"]) / 3.0
    pv = typical * df["volume"]
    session_id = df["open_time"].dt.floor("D")
    cum_pv = pv.groupby(session_id).cumsum()
    cum_vol = df["volume"].groupby(session_id).cumsum()
    return cum_pv / cum_vol.replace(0, np.nan)


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    n = len(df)
    if n < LOOKBACK + SYNTHETIC_ATR_LEN + 5:
        return []

    vwap = _session_vwap(df)
    atr_vals = atr(df, SYNTHETIC_ATR_LEN)

    close = df["close"]
    low = df["low"]
    high = df["high"]

    below_vwap = close < vwap
    above_vwap = close > vwap
    reclaim_long_cross = above_vwap & below_vwap.shift(1).fillna(False)
    reclaim_short_cross = below_vwap & above_vwap.shift(1).fillna(False)

    swept_low_flag = low < (vwap - MIN_SWEEP_ATR * atr_vals)
    swept_high_flag = high > (vwap + MIN_SWEEP_ATR * atr_vals)
    # "in the last LOOKBACK bars BEFORE the current one" -- shift(1) first so
    # the current bar's own low/high (the reclaim bar itself) isn't counted
    # as its own sweep confirmation.
    swept_recent_low = swept_low_flag.shift(1).rolling(LOOKBACK, min_periods=1).max().fillna(0).astype(bool)
    swept_recent_high = swept_high_flag.shift(1).rolling(LOOKBACK, min_periods=1).max().fillna(0).astype(bool)

    sweep_extreme_low = low.shift(1).rolling(LOOKBACK, min_periods=1).min()
    sweep_extreme_high = high.shift(1).rolling(LOOKBACK, min_periods=1).max()

    long_ok = (reclaim_long_cross & swept_recent_low).fillna(False).to_numpy()
    short_ok = (reclaim_short_cross & swept_recent_high).fillna(False).to_numpy()

    close_np = close.to_numpy()
    atr_np = atr_vals.to_numpy()
    sweep_low_np = sweep_extreme_low.to_numpy()
    sweep_high_np = sweep_extreme_high.to_numpy()
    vwap_np = vwap.to_numpy()

    signals: list[Signal] = []
    last_fire = {"long": -10 ** 9, "short": -10 ** 9}

    for i in range(n):
        a = atr_np[i]
        if a != a:  # NaN
            continue

        if long_ok[i] and (i - last_fire["long"]) >= SIGNAL_COOLDOWN:
            base = sweep_low_np[i]
            if base == base:  # not NaN
                sl = base - STOP_BUFFER_ATR * a
                entry = float(close_np[i])
                if entry - sl > 0:
                    last_fire["long"] = i
                    signals.append(Signal(
                        direction="long", entry=entry, stop_loss=float(sl),
                        trigger_index=i, trigger_time=df["open_time"].iloc[i],
                        take_profits=None, label="anchored_vwap_reclaim", synthetic_stop=True,
                        meta={"vwap": float(vwap_np[i])},
                    ))
                    continue

        if short_ok[i] and (i - last_fire["short"]) >= SIGNAL_COOLDOWN:
            base = sweep_high_np[i]
            if base == base:
                sl = base + STOP_BUFFER_ATR * a
                entry = float(close_np[i])
                if sl - entry > 0:
                    last_fire["short"] = i
                    signals.append(Signal(
                        direction="short", entry=entry, stop_loss=float(sl),
                        trigger_index=i, trigger_time=df["open_time"].iloc[i],
                        take_profits=None, label="anchored_vwap_reclaim", synthetic_stop=True,
                        meta={"vwap": float(vwap_np[i])},
                    ))

    return signals
