"""Port of "ML: Lorentzian Classification with Regime Filter" (source:
Code_MLWithRegimeFilter.txt) -- jdehorty's open-source Lorentzian
Classification k-NN model plus a bolted-on custom HMA regime filter.

FIDELITY WARNING (read before trusting these numbers): the original script
imports two external public libraries -- jdehorty/MLExtensions and
jdehorty/KernelFunctions -- whose internals (n_rsi/n_wt/n_cci/n_adx
normalization, regime_filter, filter_volatility, the Rational Quadratic /
Gaussian kernel regression) are NOT in the source file we were given (Pine
`import` statements pull compiled/hosted library code, not inlined text).
Everything below those two imports (the k-NN core, the custom regime
filter, the entry/exit state machine) is ported verbatim from the actual
source. Everything feeding INTO those imports had to be reconstructed
from the published/well-documented formulas for these specific libraries
(they're widely mirrored in the Pine community) -- treat this module as
directionally faithful, not byte-exact. If a real backtest run shows this
performing suspiciously well or badly compared to how the indicator reads
live on TradingView, the reconstructed library internals are the first
place to check.

Trade lifecycle (unlike every other module in this collection, this one
IS the original author's fully-specified entry+exit): enter on a new
buy/sell k-NN signal filtered by the regime/volatility/kernel filters;
exit after exactly 4 bars held, or earlier if the opposite new signal
fires. The original has no protective stop-loss at all -- per the user's
own risk rule ("stop-loss обязателен всегда"), a synthetic ATR stop
(see app/indicators/common.py) is layered on top and can cut the trade
short before the 4-bar exit. Because the exit is time/signal-based rather
than a price target, this module resolves its own trade outcomes instead
of going through generic_backtest.simulate_outcome's touch-based TP scan
(see the `meta["resolved_outcome"]` short-circuit in generic_backtest.py).
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .common import (
    Signal, ema, sma, rsi, cci, dmi_adx, atr, rma,
    SYNTHETIC_ATR_LEN, SYNTHETIC_ATR_MULT,
)

NEIGHBORS_COUNT = 8
MAX_BARS_BACK = 2000
FEATURE_COUNT = 5
REGIME_THRESHOLD = -0.1
USE_ADX_FILTER = False  # off by default in the source -- not ported, always passes
ADX_THRESHOLD = 20
CUSTOM_REGIME_LEN = 20
KERNEL_H = 8
KERNEL_R = 8.0
KERNEL_X = 25
KERNEL_LAG = 2
KERNEL_WINDOW_CAP = 500  # practical truncation of the kernel sum -- weights are ~0 beyond this for h=8,r=8


# ----------------------------------------------------------- features --

def _normalize_expanding(series: pd.Series) -> pd.Series:
    """Reconstruction of MLExtensions' `normalize`: rescale to [0,1] using
    the running (all-history-so-far) min/max rather than a fixed range."""
    run_min = series.expanding().min()
    run_max = series.expanding().max()
    span = (run_max - run_min).replace(0, np.nan)
    return ((series - run_min) / span).fillna(0.5)


def _n_rsi(close: pd.Series, n1: int, n2: int) -> pd.Series:
    return ema(rsi(close, n1), n2) / 100.0


def _n_wt(hlc3: pd.Series, n1: int, n2: int) -> pd.Series:
    esa = ema(hlc3, n1)
    d = ema((hlc3 - esa).abs(), n1)
    ci = (hlc3 - esa) / (0.015 * d.replace(0, np.nan))
    wt1 = ema(ci, n2)
    wt2 = sma(wt1, 4)
    return _normalize_expanding(wt1 - wt2)


def _n_cci(close: pd.Series, n1: int, n2: int) -> pd.Series:
    return _normalize_expanding(ema(cci(close, n1), n2))


def _n_adx(df: pd.DataFrame, length: int) -> pd.Series:
    return dmi_adx(df, length, length) / 100.0


def _hma(series: pd.Series, length: int) -> pd.Series:
    def wma(s: pd.Series, n: int) -> pd.Series:
        weights = np.arange(1, n + 1)
        return s.rolling(n).apply(lambda x: np.dot(x, weights) / weights.sum(), raw=True)
    half = max(1, int(round(length / 2)))
    sqrt_n = max(1, int(round(np.sqrt(length))))
    return wma(2 * wma(series, half) - wma(series, length), sqrt_n)


def _regime_filter(src: pd.Series, high: pd.Series, low: pd.Series, threshold: float) -> pd.Series:
    """Reconstruction of MLExtensions' regime_filter: an adaptive
    Kalman-like curve (klmf) whose slope-decline vs its own EMA(200) is
    thresholded."""
    n = len(src)
    value1 = np.zeros(n)
    value2 = np.zeros(n)
    klmf = np.zeros(n)
    klmf[0] = src.iloc[0]
    src_v, high_v, low_v = src.values, high.values, low.values
    for t in range(1, n):
        value1[t] = 0.2 * (src_v[t] - src_v[t - 1]) + 0.8 * value1[t - 1]
        value2[t] = 0.1 * (high_v[t] - low_v[t]) + 0.8 * value2[t - 1]
        omega = abs(value1[t] / value2[t]) if value2[t] != 0 else 0.0
        alpha = (-omega ** 2 + np.sqrt(omega ** 4 + 16 * omega ** 2)) / 8 if omega else 0.0
        klmf[t] = alpha * src_v[t] + (1 - alpha) * klmf[t - 1]
    klmf_s = pd.Series(klmf, index=src.index)
    abs_curve_slope = klmf_s.diff().abs()
    exp_avg = ema(abs_curve_slope, 200)
    normalized_slope_decline = (abs_curve_slope - exp_avg) / exp_avg.replace(0, np.nan)
    return normalized_slope_decline >= threshold


def _filter_volatility(df: pd.DataFrame, min_len: int = 1, max_len: int = 10) -> pd.Series:
    return atr(df, min_len) > atr(df, max_len)


def _kernel_regression(src: pd.Series, lookback: int, relative_weight: float, window_cap: int) -> pd.Series:
    """Rational Quadratic kernel regression (Nadaraya-Watson family),
    reconstructed from jdehorty's published KernelFunctions formula:
    weight(i) = (1 + i^2 / (lookback^2 * 2 * relative_weight)) ^ (-relative_weight).
    Truncated to the last `window_cap` bars per point instead of full
    history -- weight decays to ~0 well before that for h=8, r=8."""
    values = src.values
    n = len(values)
    out = np.full(n, np.nan)
    i_full = np.arange(window_cap)
    weights_full = (1 + (i_full ** 2) / (lookback ** 2 * 2 * relative_weight)) ** (-relative_weight)
    for t in range(n):
        span = min(t + 1, window_cap)
        y = values[t - span + 1: t + 1][::-1]  # y[0] = current bar, y[1] = 1 bar back, ...
        w = weights_full[:span]
        out[t] = np.dot(y, w) / w.sum()
    return pd.Series(out, index=src.index)


# --------------------------------------------------------------- core --

def generate_signals(df: pd.DataFrame) -> list[Signal]:
    close, high, low = df["close"], df["high"], df["low"]
    hlc3 = (high + low + close) / 3.0
    n = len(df)

    f1 = _n_rsi(close, 14, 1)
    f2 = _n_wt(hlc3, 10, 11)
    f3 = _n_cci(close, 20, 1)
    f4 = _n_adx(df, 20)
    f5 = _n_rsi(close, 9, 1)
    features = np.column_stack([f1.values, f2.values, f3.values, f4.values, f5.values])

    y_train = np.where(close.shift(4) < close, -1, np.where(close.shift(4) > close, 1, 0))  # src[4]<src[0]=>short(-1)

    filter_vol = _filter_volatility(df)
    filter_regime = _regime_filter(close, high, low, REGIME_THRESHOLD)
    filter_adx = pd.Series(True, index=df.index) if not USE_ADX_FILTER else (_n_adx(df, 14) * 100 > ADX_THRESHOLD)

    hma20 = _hma(hlc3, 15)
    trend_val = pd.Series(0.0, index=df.index)
    coeff = 10.0 / CUSTOM_REGIME_LEN
    # trend_custom[t] = sum over i in 0..regimeLen-1 of sign(hma[t] - hma[t-i])
    hma_v = hma20.values
    trend_custom = np.zeros(n)
    for i in range(CUSTOM_REGIME_LEN):
        shifted = np.roll(hma_v, i)
        shifted[:i] = np.nan
        cmp = np.where(hma_v > shifted, 1.0, -1.0)
        cmp[np.isnan(shifted)] = 0.0
        trend_custom += cmp
    trend_val = pd.Series(trend_custom * coeff, index=df.index)
    is_uptrend_custom = trend_val > 2
    is_downtrend_custom = trend_val < -2
    is_strong_trend_custom = trend_val.abs() > 3
    is_ranging_custom = trend_val.abs() <= 1

    yhat1 = _kernel_regression(close, KERNEL_H, KERNEL_R, KERNEL_WINDOW_CAP)
    is_bullish_rate = yhat1.shift(1) < yhat1
    is_bearish_rate = yhat1.shift(1) > yhat1

    valid_from = 250  # let EMA(200)-based regime filter, expanding-normalize features, HMA/kernel warm up
    max_bars_back_index = max(0, (n - 1) - MAX_BARS_BACK)
    start = max(valid_from, max_bars_back_index)

    signal_arr = np.zeros(n, dtype=int)  # 0 neutral, 1 long, -1 short (persisted "signal" series)
    bars_held = np.zeros(n, dtype=int)
    predictions_out = np.zeros(n)

    for t in range(start, n):
        size = min(MAX_BARS_BACK - 1, t)  # y_train/features available for indices 0..t
        cur = features[t]
        hist = features[: size + 1]
        # vectorized Lorentzian distance to every historical point 0..size
        d_all = np.log1p(np.abs(cur[None, :] - hist)).sum(axis=1)

        last_distance = -1.0
        distances: list[float] = []
        predictions: list[int] = []
        for i in range(0, size + 1):
            if i % 4 == 0:
                continue
            d = d_all[i]
            if d >= last_distance:
                last_distance = d
                distances.append(d)
                predictions.append(int(y_train[i]))
                if len(predictions) > NEIGHBORS_COUNT:
                    idx = round(NEIGHBORS_COUNT * 3 / 4)
                    last_distance = distances[idx]
                    distances.pop(0)
                    predictions.pop(0)
        prediction = sum(predictions)
        predictions_out[t] = prediction

        filt_all = bool(filter_vol.iloc[t]) and bool(filter_regime.iloc[t]) and bool(filter_adx.iloc[t])
        uptrend_t, downtrend_t = bool(is_uptrend_custom.iloc[t]), bool(is_downtrend_custom.iloc[t])
        strong_t, ranging_t = bool(is_strong_trend_custom.iloc[t]), bool(is_ranging_custom.iloc[t])

        if uptrend_t:
            filt_custom = filt_all and prediction > 0
        elif downtrend_t:
            filt_custom = filt_all and prediction < 0
        elif strong_t:
            filt_custom = filt_all
        elif ranging_t:
            filt_custom = abs(prediction) < NEIGHBORS_COUNT / 2
        else:
            filt_custom = filt_all

        prev_signal = signal_arr[t - 1] if t > 0 else 0
        if prediction > 0 and filt_custom:
            signal_arr[t] = 1
        elif prediction < 0 and filt_custom:
            signal_arr[t] = -1
        else:
            signal_arr[t] = prev_signal

        bars_held[t] = 0 if signal_arr[t] != prev_signal else bars_held[t - 1] + 1 if t > 0 else 0

    # --------------------------------------------------------- entries --
    is_buy_signal = np.zeros(n, dtype=bool)
    is_sell_signal = np.zeros(n, dtype=bool)
    for t in range(start, n):
        if signal_arr[t] == 1 and (not is_ranging_custom.iloc[t] and is_uptrend_custom.iloc[t]
                                    or (is_strong_trend_custom.iloc[t] and predictions_out[t] > 0)):
            is_buy_signal[t] = True
        if signal_arr[t] == -1 and (not is_ranging_custom.iloc[t] and is_downtrend_custom.iloc[t]
                                     or (is_strong_trend_custom.iloc[t] and predictions_out[t] < 0)):
            is_sell_signal[t] = True

    is_different_signal = np.zeros(n, dtype=bool)
    for t in range(start + 1, n):
        is_different_signal[t] = signal_arr[t] != signal_arr[t - 1]

    is_new_buy = is_buy_signal & is_different_signal
    is_new_sell = is_sell_signal & is_different_signal

    signals: list[Signal] = []
    for t in range(start, n):
        want_long = is_new_buy[t] and bool(is_bullish_rate.iloc[t])
        want_short = is_new_sell[t] and bool(is_bearish_rate.iloc[t])
        if not (want_long or want_short):
            continue

        entry = float(close.iloc[t])
        direction = "long" if want_long else "short"
        atr_val = atr(df, SYNTHETIC_ATR_LEN).iloc[t]
        if pd.isna(atr_val) or atr_val <= 0:
            continue
        stop_dist = SYNTHETIC_ATR_MULT * float(atr_val)
        stop = entry - stop_dist if direction == "long" else entry + stop_dist

        # Resolve this trade's own outcome: exit after 4 bars held, or
        # earlier on the next opposite new signal -- whichever comes
        # first -- unless the synthetic ATR stop is touched beforehand.
        exit_idx = min(t + 4, n - 1)
        for look in range(t + 1, min(t + 4, n - 1) + 1):
            if (direction == "long" and is_new_sell[look]) or (direction == "short" and is_new_buy[look]):
                exit_idx = look
                break

        outcome, r = None, None
        for i in range(t + 1, exit_idx + 1):
            row = df.iloc[i]
            sl_hit = row["low"] <= stop if direction == "long" else row["high"] >= stop
            if sl_hit:
                outcome, r = "SL", -1.0
                break
        if outcome is None:
            if exit_idx >= n:
                outcome, r = "open (no resolution within window)", None
            else:
                exit_close = float(df["close"].iloc[exit_idx])
                raw_r = (exit_close - entry) / stop_dist if direction == "long" else (entry - exit_close) / stop_dist
                outcome, r = ("time_exit" if exit_idx == t + 4 else "signal_flip_exit"), raw_r

        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=stop,
            trigger_index=t, trigger_time=df["open_time"].iloc[t],
            take_profits=None, label="ml_lorentzian", synthetic_stop=True,
            meta={"resolved_outcome": {"outcome": outcome, "r": r}},
        ))

    return signals
