"""Port of the range-detection + SL/TP sub-system bolted onto "Support/
Resistance Re-test Finder with Range and Liq lines" (calcSLTP block,
source lines ~343-543 of SupportResistance_Retest_Finder_with_Range_and_
Liq_lines.txt). This is a *different* signal from the file's main pivot
re-test state machine (not ported here -- that one has no defined
entry/exit rule of its own) and from the pivot-slope trend-line drawer at
the bottom of the file (pure visualization, not ported).

Logic: detect a ranging regime (ADX below threshold, by default -- a
Volatility-compression mode also exists in the source and is implemented
here as `method="volatility"` but ADX is the indicator's own default), track
a recursive range-filter (`rngfilt`, identical family of algorithm to
Twin Range Signal's `rngfilt`) with band width `r`, and fire long/short
the moment the filter steps in a new direction while still inside a
detected range, subject to a cooldown between signals. This is one of
only two indicators in the whole 24-file collection with a fully
hard-coded SL + tiered TP (`calcSLTP`) -- ported verbatim.

Fidelity note: `r = sma(2.618 * |high - low[1]|, 2000) * band_mult` needs
2000 fully-formed bars before it produces a value at all (Pine's ta.sma
returns na until `length` bars have accumulated) -- run generic_backtest.py
with --bars comfortably above 2000 (3000+) for this module, otherwise it
will never fire.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .common import Signal, atr, dmi_adx, sma, stdev, variance

RANGE_LEN = 10
BAND_MULT = 1.8
ADX_THRESH = 17
ADX_SMOOTH = 10
VOL_MULT_STD = 0.8
VOL_MULT_VAR = 0.8
VOL_MULT_ATR = 0.9
COOLDOWN = 20
SL_MULT = 0.4
TP1_MULT = 0.5
TP2_MULT = 1.0
TP3_MULT = 2.0
R_SMA_LEN = 2000


def _method_detected(df: pd.DataFrame, method: str) -> pd.Series:
    if method == "adx":
        adx = dmi_adx(df, RANGE_LEN, ADX_SMOOTH)
        return adx < ADX_THRESH
    close = df["close"]
    logret = np.log(close / close.shift(1))
    std_now = stdev(logret, RANGE_LEN)
    std_avg = sma(std_now, RANGE_LEN)
    atr_now = atr(df, RANGE_LEN)
    atr_avg = sma(atr_now, RANGE_LEN)
    var_now = variance(logret, RANGE_LEN)
    var_avg = sma(var_now, RANGE_LEN)
    return (std_now < std_avg * VOL_MULT_STD) & (var_now < var_avg * VOL_MULT_VAR) & (atr_now < atr_avg * VOL_MULT_ATR)


def generate_signals(df: pd.DataFrame, method: str = "adx") -> list[Signal]:
    high, low, close = df["high"], df["low"], df["close"]

    detected = _method_detected(df, method)
    diff = (high - low.shift(1)).abs()
    r_series = sma(2.618 * diff, R_SMA_LEN) * BAND_MULT

    start_idx = R_SMA_LEN  # first index where r_series is guaranteed non-NaN (rolling(2000) fills in at pos 1999)
    if start_idx >= len(df):
        return []

    signals: list[Signal] = []
    range_start_bar = None
    range_visible = False
    prev_hi = None
    prev_lo = None
    last_breakout_bar = None
    prev_rngfilt = 0.0  # matches Pine's nz(rngfilt[1]) == 0 at the first evaluable bar

    for i in range(start_idx, len(df)):
        r = r_series.iloc[i]
        if pd.isna(r):
            continue
        method_now = bool(detected.iloc[i]) if not pd.isna(detected.iloc[i]) else False

        if method_now and range_start_bar is None:
            range_start_bar = i
        elif not method_now:
            range_start_bar = None
        if method_now:
            range_visible = True

        close_i = float(close.iloc[i])
        prev = prev_rngfilt
        hh_break = close_i > prev
        hh_too_close = (close_i - r) < prev
        hh_shift = close_i - r
        ll_too_close = (close_i + r) > prev
        ll_shift = close_i + r
        step1 = (prev if hh_too_close else hh_shift) if hh_break else (prev if ll_too_close else ll_shift)
        hh_above = close_i >= prev + r
        ll_below = close_i <= prev - r
        rngfilt = close_i if (hh_above or ll_below) else step1

        rngfilt_step_up = rngfilt > prev
        rngfilt_step_down = rngfilt < prev

        hiband, loband = rngfilt + r, rngfilt - r
        if method_now:
            prev_hi, prev_lo = hiband, loband
        elif prev_hi is not None:
            prev_close = float(close.iloc[i - 1])
            if prev_close > prev_hi or prev_close < prev_lo:
                range_visible = False

        can_trigger = last_breakout_bar is None or (i - last_breakout_bar) >= COOLDOWN
        enter_long = range_visible and rngfilt_step_up and can_trigger
        enter_short = range_visible and rngfilt_step_down and can_trigger

        if enter_long or enter_short:
            base = rngfilt
            offset = r * SL_MULT
            tp_offs = (r * TP1_MULT, r * TP2_MULT, r * TP3_MULT)
            if enter_long:
                direction = "long"
                stop = base - offset
                tps = [base + off for off in tp_offs]
            else:
                direction = "short"
                stop = base + offset
                tps = [base - off for off in tp_offs]

            signals.append(Signal(
                direction=direction, entry=close_i, stop_loss=stop,
                trigger_index=i, trigger_time=df["open_time"].iloc[i],
                take_profits=tps, label="sr_range_module", synthetic_stop=False,
            ))
            last_breakout_bar = i

        prev_rngfilt = rngfilt

    return signals
