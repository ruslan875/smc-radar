"""Variant of `liquidity_sweep_mss_fvg.py` with a different entry rule --
NOT a direct Pine port, this is our own follow-up experiment after the
original FVG-retracement entry was debunked by a fill-realism check (see
pine-indicators-python-port doc): 26% of its setups never got touched by
price at all within 30 bars, and of the ones that did fill, win rate
collapsed from an assumed 57.1% to a real 30.9%, net R going from
strongly positive to strongly negative across every fee scenario.

Same sweep -> MSS detection and the same 0-100 setup-quality score as the
original (see that module's docstring for the full state-machine
description) -- the ONLY thing that changes is the entry price: instead
of waiting for a retracement into the FVG left by the displacement leg
(a limit order that may never fill), this version enters at MARKET, at
the close of the bar the MSS confirms. This is structurally the same
entry mechanic the user's own SMC bot uses (confirmation-candle-close),
which sidesteps the fill-realism problem entirely -- a market order is
always fillable by definition, so no separate fill-check script is
needed for this variant the way `validate_liquidity_sweep_fills.py` was
needed for the FVG version.

Trade-off: risk per trade is larger (entry is further from the stop than
the FVG edge would have been, since price has already moved through the
FVG zone by the time MSS confirms), so in R terms this should look
different from the original even before considering realism -- worth
comparing both gross R *and* fee-in-R drag against the FVG version's
numbers, not just win rate.

Stop = the sweep's extreme wick (native, same as the original). Take-
profit = fixed 2R off the market-entry risk (same `RR_MULT` as the
original, just applied to a different risk distance).
"""
from __future__ import annotations

import math

import pandas as pd

from .common import Signal, atr, pivothigh, pivotlow

PIV_LEN = 8
INT_LEN = 3
MAX_WAIT = 20
RR_MULT = 2.0
MIN_RISK_ATR = 0.20
MIN_QUAL = 0


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    high = df["high"].to_numpy()
    low = df["low"].to_numpy()
    close = df["close"].to_numpy()
    n = len(df)
    if n < 2 * PIV_LEN + 5:
        return []

    atr14 = atr(df, 14).to_numpy()

    ph = pivothigh(df["high"], PIV_LEN, PIV_LEN).to_numpy()
    pl = pivotlow(df["low"], PIV_LEN, PIV_LEN).to_numpy()
    iph = pivothigh(df["high"], INT_LEN, INT_LEN).to_numpy()
    ipl = pivotlow(df["low"], INT_LEN, INT_LEN).to_numpy()

    sw_high = sw_low = float("nan")
    int_high = int_low = float("nan")
    int_high_bar = int_low_bar = -1
    hi_taken = lo_taken = False

    state = 0
    direction = 0
    sweep_ext = sweep_bar = swept_lvl = float("nan")
    mss_level = float("nan")
    mss_lev_bar = -1
    waited = 0

    signals: list[Signal] = []

    for i in range(n):
        if not math.isnan(ph[i]):
            sw_high = ph[i]
            hi_taken = False
        if not math.isnan(pl[i]):
            sw_low = pl[i]
            lo_taken = False
        if not math.isnan(iph[i]):
            int_high = iph[i]
            int_high_bar = i - INT_LEN
        if not math.isnan(ipl[i]):
            int_low = ipl[i]
            int_low_bar = i - INT_LEN

        if state == 0:
            if (not math.isnan(sw_low) and not lo_taken and low[i] < sw_low and close[i] > sw_low
                    and not math.isnan(int_high) and int_high > close[i]):
                lo_taken = True
                state, direction = 1, 1
                sweep_ext, sweep_bar, swept_lvl = low[i], i, sw_low
                mss_level, mss_lev_bar = int_high, int_high_bar
                waited = 0
            elif (not math.isnan(sw_high) and not hi_taken and high[i] > sw_high and close[i] < sw_high
                    and not math.isnan(int_low) and int_low < close[i]):
                hi_taken = True
                state, direction = 1, -1
                sweep_ext, sweep_bar, swept_lvl = high[i], i, sw_high
                mss_level, mss_lev_bar = int_low, int_low_bar
                waited = 0
            continue

        waited += 1
        if waited > MAX_WAIT:
            state = 0
            continue

        mss_fired = False
        if direction == 1 and not math.isnan(mss_level) and close[i] > mss_level:
            mss_fired = True
        if direction == -1 and not math.isnan(mss_level) and close[i] < mss_level:
            mss_fired = True
        if not mss_fired:
            continue

        # FVG still searched for -- feeds the quality score's fSize component
        # exactly like the original -- but NOT used as the entry price here.
        span = min(waited + 4, 18)
        fvg_t = fvg_b = None
        for j in range(0, span + 1):
            k = i - j
            if k - 2 < 0:
                break
            if direction == 1 and low[k] > high[k - 2]:
                fvg_t, fvg_b = low[k], high[k - 2]
                break
            if direction == -1 and high[k] < low[k - 2]:
                fvg_t, fvg_b = low[k - 2], high[k]
                break

        entry = float(close[i])  # <-- the only real change vs. liquidity_sweep_mss_fvg.py
        sl = sweep_ext
        risk = abs(entry - sl)
        tp = entry + risk * RR_MULT if direction == 1 else entry - risk * RR_MULT

        a = max(atr14[i], 1e-9) if not math.isnan(atr14[i]) else 1e-9
        depth = abs(sweep_ext - swept_lvl) / a
        disp = abs(close[i] - mss_level) / a
        f_size = (abs(fvg_t - fvg_b) / a) if fvg_t is not None else 0.0
        q_sweep = min(1.0, depth / 0.45) * 100
        q_disp = min(1.0, disp / 1.20) * 100
        q_fvg = min(1.0, f_size / 0.40) * 100
        q_speed = max(0.0, 1.0 - waited / float(MAX_WAIT)) * 100
        qual = round(0.30 * q_sweep + 0.30 * q_disp + 0.25 * q_fvg + 0.15 * q_speed)

        valid = risk > a * MIN_RISK_ATR and ((entry > sl) if direction == 1 else (entry < sl))

        if qual >= MIN_QUAL and valid:
            signals.append(Signal(
                direction="long" if direction == 1 else "short",
                entry=entry, stop_loss=float(sl),
                trigger_index=i, trigger_time=df["open_time"].iloc[i],
                take_profits=[float(tp)], label="liquidity_sweep_mss_market_entry",
                synthetic_stop=False,
                meta={"quality": qual, "has_fvg": fvg_t is not None},
            ))

        state = 0

    return signals
