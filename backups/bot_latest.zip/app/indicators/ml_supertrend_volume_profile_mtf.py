"""Port of "Machine Learning Adaptive SuperTrend and Volume" (source:
MLSuperTrendWithVolumeProfileMTF.txt). Despite the filename, this is two
loosely-related features bolted into one indicator:

1. A K-means-clustered, volatility-adaptive SuperTrend (the actual
   tradeable entry rule) -- ported here.
2. A 5-higher-timeframe rolling Volume Profile display (POC/VAH/VAL
   boxes for HTF #1..#5, each with its own lower-timeframe volume-delta
   breakdown via `request.security_lower_tf`) -- **not ported**. This
   needs live per-trade-tick (or at minimum sub-bar) volume-delta data
   fetched via multi-timeframe + lower-timeframe requests simultaneously,
   which this backtest sandbox has no access to (no network, no tick
   data), and per the task brief this is confluence/visualization
   context anyway, not itself an entry rule -- nothing in the source
   references the volume profile arrays when deciding `long_trend`/
   `short_trend`.

Ported entry rule:

    volatility = ta.atr(atr_len)                       // atr_len=10
    // K-means (k=3) clusters ATR into High/Medium/Low volatility
    // regimes over a rolling `training_data_period` (100) window,
    // re-fit every bar; nearest-centroid ATR value becomes the
    // SuperTrend's ATR input for that bar.
    [ST, dir] = pine_supertrend(fact, assigned_centroid)   // fact=3, src=hl2
    ema = ta.ema(close, 200)
    long_trend  = ta.crossunder(dir, 0) and ema < close   -> long
    short_trend = ta.crossover(dir, 0)  and ema > close   -> short

(`dir == -1` is the library's uptrend state in this script's convention,
so `crossunder(dir, 0)` is the flip *into* uptrend and `crossover(dir, 0)`
the flip *into* downtrend -- confirmed against the plotshape labels in
the source, "Bullish Trend" / "Bearish Trend".)

Fidelity notes:
- The K-means step (`training_data_period`=100, initial centroid guesses
  at the 75th/50th/25th percentile of the ATR range) is re-run from
  scratch on every bar's trailing window, iterating to a fixed point the
  same way the Pine `while` loop does, capped here at 50 iterations as a
  safety valve (empty clusters/oscillation would otherwise be an
  infinite loop in Pine too -- assumed not to occur in practice, same
  assumption the original script makes).
- `ta.atr(7)` label-offset math and the K-means cluster-count/centroid
  info table are pure display, not ported.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .common import Signal, ema, atr, synthetic_stop, SYNTHETIC_ATR_LEN, SYNTHETIC_ATR_MULT

ATR_LEN = 10
FACTOR = 3.0
TRAINING_PERIOD = 100
HIGH_VOL_PCTL = 0.75
MID_VOL_PCTL = 0.50
LOW_VOL_PCTL = 0.25
EMA_LEN = 200
MAX_KMEANS_ITER = 50


def _kmeans_assigned_centroid(vol_window: np.ndarray, high_g: float, mid_g: float, low_g: float) -> float:
    a, b, c = high_g, mid_g, low_g
    for _ in range(MAX_KMEANS_ITER):
        d1 = np.abs(vol_window - a)
        d2 = np.abs(vol_window - b)
        d3 = np.abs(vol_window - c)
        hv = vol_window[(d1 < d2) & (d1 < d3)]
        mv = vol_window[(d2 < d1) & (d2 < d3)]
        lv = vol_window[(d3 < d1) & (d3 < d2)]
        new_a = hv.mean() if hv.size else a
        new_b = mv.mean() if mv.size else b
        new_c = lv.mean() if lv.size else c
        if new_a == a and new_b == b and new_c == c:
            a, b, c = new_a, new_b, new_c
            break
        a, b, c = new_a, new_b, new_c

    cur = vol_window[-1]
    dists = [abs(cur - a), abs(cur - b), abs(cur - c)]
    centroids = [a, b, c]
    cluster = int(np.argmin(dists))
    return centroids[cluster]


def _pine_supertrend(hl2: pd.Series, close: pd.Series, atr_series: pd.Series, factor: float) -> pd.Series:
    """`pine_supertrend(factor, atr)` from the source: standard SuperTrend
    flip recursion on hl2, direction convention -1=uptrend/+1=downtrend
    (matches Pine's built-in ta.supertrend). Returns the direction series
    only (the ST line itself isn't needed for the entry rule)."""
    h = hl2.to_numpy(dtype=float)
    c = close.to_numpy(dtype=float)
    a = atr_series.to_numpy(dtype=float)
    n = len(h)

    direction = np.full(n, np.nan)
    prev_lower = np.nan
    prev_upper = np.nan
    prev_supertrend = np.nan
    prev_close = np.nan
    prev_atr = np.nan

    for i in range(n):
        if np.isnan(h[i]) or np.isnan(a[i]):
            prev_close = c[i]
            prev_atr = a[i]
            continue

        upper_band = h[i] + factor * a[i]
        lower_band = h[i] - factor * a[i]
        pl = 0.0 if np.isnan(prev_lower) else prev_lower
        pu = 0.0 if np.isnan(prev_upper) else prev_upper

        lower_band = lower_band if (lower_band > pl or (not np.isnan(prev_close) and prev_close < pl)) else pl
        upper_band = upper_band if (upper_band < pu or (not np.isnan(prev_close) and prev_close > pu)) else pu

        if np.isnan(prev_atr):
            dcur = 1
        elif not np.isnan(prev_supertrend) and prev_supertrend == prev_upper:
            dcur = -1 if c[i] > upper_band else 1
        else:
            dcur = 1 if c[i] < lower_band else -1

        supertrend = lower_band if dcur == -1 else upper_band

        direction[i] = dcur
        prev_lower, prev_upper = lower_band, upper_band
        prev_supertrend = supertrend
        prev_close = c[i]
        prev_atr = a[i]

    return pd.Series(direction, index=hl2.index)


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    high, low, close = df["high"], df["low"], df["close"]
    hl2 = (high + low) / 2.0
    n = len(df)

    volatility = atr(df, ATR_LEN)
    vol = volatility.to_numpy(dtype=float)

    assigned = np.full(n, np.nan)
    for i in range(TRAINING_PERIOD - 1, n):
        window = vol[i - TRAINING_PERIOD + 1: i + 1]
        if np.isnan(window).any() or window[-1] <= 0:
            continue
        upper = window.max()
        lower = window.min()
        high_g = lower + (upper - lower) * HIGH_VOL_PCTL
        mid_g = lower + (upper - lower) * MID_VOL_PCTL
        low_g = lower + (upper - lower) * LOW_VOL_PCTL
        assigned[i] = _kmeans_assigned_centroid(window, high_g, mid_g, low_g)

    assigned_series = pd.Series(assigned, index=df.index)
    direction = _pine_supertrend(hl2, close, assigned_series, FACTOR)

    ema200 = ema(close, EMA_LEN)

    dir_vals = direction.to_numpy()
    ema_vals = ema200.to_numpy()
    close_vals = close.to_numpy()

    synth_atr = atr(df, SYNTHETIC_ATR_LEN).to_numpy()

    signals: list[Signal] = []
    for i in range(1, n):
        if np.isnan(dir_vals[i]) or np.isnan(dir_vals[i - 1]) or np.isnan(ema_vals[i]):
            continue
        crossunder = dir_vals[i] < 0 <= dir_vals[i - 1]
        crossover = dir_vals[i] > 0 >= dir_vals[i - 1]

        long_trend = crossunder and ema_vals[i] < close_vals[i]
        short_trend = crossover and ema_vals[i] > close_vals[i]
        if not (long_trend or short_trend):
            continue

        synth = synth_atr[i]
        if np.isnan(synth):
            continue

        entry = float(close_vals[i])
        dirn = "long" if long_trend else "short"
        stop = synthetic_stop(entry, float(synth), dirn, SYNTHETIC_ATR_MULT)

        signals.append(Signal(
            direction=dirn, entry=entry, stop_loss=stop,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="ml_supertrend_volume_profile_mtf", synthetic_stop=True,
        ))

    return signals
