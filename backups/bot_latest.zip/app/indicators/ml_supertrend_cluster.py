"""Port of "SuperTrend Cluster with Volume Analytics and Predicted"
(source: MLSuperTrendClusterWithVolumeAndPredicted.txt -- two files were
handed out, differing only in one default input, "Segment Resolution"
for the unrelated volume-profile block, "W" vs "D"; confirmed via diff,
same logic, ported once).

Core engine: five independent SuperTrend "members" (each its own
ATR length / factor / smoothing-of-`hlc3` / weight), combined into a
weighted consensus. A regime is only "confirmed" once its weighted vote
share clears `thr` (Consensus Threshold, default 0.60) *and* the
user-chosen "base" member (`baseIx`, default 3rd) agrees with that
regime; the confirmed regime (`dLast`) is sticky (only changes on a
qualifying flip) and the tradeable entry is `dLast` itself crossing zero:

    dLast = +1 if (scBu >= thr and dB > 0) and not (scBe >= thr and dB < 0)
          = -1 if (scBe >= thr and dB < 0) and not (scBu >= thr and dB > 0)
          = sticky (unchanged) otherwise
    alBu = ta.crossover(dLast, 0)   -> long
    alBe = ta.crossunder(dLast, 0)  -> short

Each SuperTrend member computes its band from `fac * ta.atr(atrLen)`
around a smoothed `hlc3` (`fMa`, one of SMA/EMA/LSMA/WMA/HMA/RMA per
member) rather than the usual raw hl2 -- ported exactly as written,
including the "sticky band" (`ub`/`lb` only move toward price, never
away, until a flip) and flip-direction (`d`) recursion, since that
recursion is what makes this a genuine SuperTrend rather than a plain
band.

Not ported (confirmed pure visualization/no alertcondition references
them):
- The "Predicted" path: a `barstate.islast`-only linear-regression
  pattern-matcher that searches historical bars with a similar
  time/price slope and re-draws that segment projected forward as a
  price-path preview. It only executes on the chart's last bar and has
  no discrete per-bar trigger -- there is nothing to backtest here.
- The bolted-on "Segment Resolution" Volume Profile block (everything
  after the `// ＩＮＰＵＴＳ` divider near the end of the source) -- a
  separate display feature with its own timeframe-segmented histogram,
  unrelated to the cluster SuperTrend signal and never referenced by
  `alBu`/`alBe`.
- Cluster labels, cloud fill, and dynamic bar coloring -- pure display.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .common import Signal, sma, ema, rma, atr, synthetic_stop, SYNTHETIC_ATR_LEN, SYNTHETIC_ATR_MULT

THRESHOLD = 0.60
BASE_INDEX = 3  # 1-based, matches Pine's baseIx default

# (atr_len, factor, smoothing_type, smoothing_len, weight) per member, in source order
MEMBERS = [
    (7, 1.5, "EMA", 3, 1.0),
    (10, 2.0, "EMA", 5, 1.0),
    (14, 2.5, "SMA", 8, 1.2),
    (21, 3.0, "WMA", 13, 1.4),
    (34, 4.0, "HMA", 21, 1.6),
]


def _wma(series: pd.Series, length: int) -> pd.Series:
    weights = np.arange(1, length + 1, dtype=float)
    wsum = weights.sum()
    return series.rolling(length, min_periods=length).apply(lambda x: np.dot(x, weights) / wsum, raw=True)


def _hma(series: pd.Series, length: int) -> pd.Series:
    half = max(1, round(length / 2))
    sqrt_len = max(1, round(length ** 0.5))
    return _wma(2 * _wma(series, half) - _wma(series, length), sqrt_len)


def _linreg(series: pd.Series, length: int, offset: int = 0) -> pd.Series:
    x = np.arange(length, dtype=float)
    x_mean = x.mean()
    x_var = ((x - x_mean) ** 2).sum()

    def _f(y: np.ndarray) -> float:
        y_mean = y.mean()
        slope = ((x - x_mean) * (y - y_mean)).sum() / x_var
        intercept = y_mean - slope * x_mean
        return intercept + slope * (length - 1 - offset)

    return series.rolling(length, min_periods=length).apply(_f, raw=True)


def _fma(ma_type: str, src: pd.Series, length: int) -> pd.Series:
    length = max(1, length)
    if ma_type == "SMA":
        return sma(src, length)
    if ma_type == "LSMA":
        return _linreg(src, length, 0)
    if ma_type == "WMA":
        return _wma(src, length)
    if ma_type == "HMA":
        return _hma(src, length)
    if ma_type == "RMA":
        return rma(src, length)
    return ema(src, length)  # default / "EMA"


def _supertrend(src: pd.Series, df: pd.DataFrame, atr_len: int, factor: float) -> tuple[pd.Series, pd.Series]:
    """fSt(src, atrLen, fac) from the source: a standard SuperTrend flip
    recursion, but centered on a *smoothed* `src` (fMa(hlc3)) rather than
    the usual raw hl2. Recursive -> explicit causal loop."""
    atr_series = atr(df, max(1, atr_len))
    s = src.to_numpy(dtype=float)
    a = atr_series.to_numpy(dtype=float)
    n = len(s)

    st = np.full(n, np.nan)
    d = np.full(n, np.nan)
    ub_prev = np.nan
    lb_prev = np.nan
    d_prev = np.nan
    prev_s = np.nan

    for i in range(n):
        if np.isnan(s[i]) or np.isnan(a[i]):
            prev_s = s[i]
            continue
        ub0 = s[i] + factor * a[i]
        lb0 = s[i] - factor * a[i]

        if np.isnan(ub_prev):
            ub = ub0
        else:
            ub = ub0 if (ub0 < ub_prev or (not np.isnan(prev_s) and prev_s > ub_prev)) else ub_prev
        if np.isnan(lb_prev):
            lb = lb0
        else:
            lb = lb0 if (lb0 > lb_prev or (not np.isnan(prev_s) and prev_s < lb_prev)) else lb_prev

        if np.isnan(d_prev):
            dcur = 1.0
        elif d_prev == -1.0 and s[i] > ub_prev:
            dcur = 1.0
        elif d_prev == 1.0 and s[i] < lb_prev:
            dcur = -1.0
        else:
            dcur = d_prev

        st[i] = lb if dcur == 1.0 else ub
        d[i] = dcur
        ub_prev, lb_prev, d_prev = ub, lb, dcur
        prev_s = s[i]

    return pd.Series(st, index=src.index), pd.Series(d, index=src.index)


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    src = (df["high"] + df["low"] + df["close"]) / 3.0  # hlc3
    close = df["close"]
    n = len(df)

    d_members: list[np.ndarray] = []
    weights = [w for *_, w in MEMBERS]
    w_sum = max(sum(weights), 1e-7)

    base_d: np.ndarray | None = None
    for idx, (atr_len, factor, ma_type, ma_len, weight) in enumerate(MEMBERS, start=1):
        smoothed = _fma(ma_type, src, ma_len)
        _st, d = _supertrend(smoothed, df, atr_len, factor)
        d_members.append(d.to_numpy())
        if idx == BASE_INDEX:
            base_d = d.to_numpy()

    assert base_d is not None

    synth_atr = atr(df, SYNTHETIC_ATR_LEN).to_numpy()

    signals: list[Signal] = []
    d_last = 0.0
    prev_d_last = 0.0

    for i in range(n):
        d_vals = [dm[i] for dm in d_members]
        if any(np.isnan(v) for v in d_vals) or np.isnan(base_d[i]):
            continue

        w_bu = sum(w for w, v in zip(weights, d_vals) if v > 0)
        w_be = sum(w for w, v in zip(weights, d_vals) if v < 0)
        sc_bu = w_bu / w_sum
        sc_be = w_be / w_sum

        d_base = base_d[i]
        ok_bu = (sc_bu >= THRESHOLD) and d_base > 0
        ok_be = (sc_be >= THRESHOLD) and d_base < 0

        prev_d_last = d_last
        if ok_bu and not ok_be:
            d_last = 1.0
        elif ok_be and not ok_bu:
            d_last = -1.0
        # else sticky, unchanged

        al_bu = d_last > 0 and prev_d_last <= 0
        al_be = d_last < 0 and prev_d_last >= 0
        if not (al_bu or al_be):
            continue

        synth = synth_atr[i]
        if np.isnan(synth):
            continue

        entry = float(close.iloc[i])
        direction = "long" if al_bu else "short"
        stop = synthetic_stop(entry, float(synth), direction, SYNTHETIC_ATR_MULT)

        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=stop,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="ml_supertrend_cluster", synthetic_stop=True,
        ))

    return signals
