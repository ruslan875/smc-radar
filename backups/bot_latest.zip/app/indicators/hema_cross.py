"""Port of the "HEMA20/HEMA40 cross" signal bundled in "Gradient Trend
Filter [with signals local]" (source:
Gradient_trend_with_local_signals_________________________________.txt,
© ChartPrime). This is the SECOND, independent signal system in that
file; the gradient/noise-filter diamond signal is ported separately as
`app/indicators/gradient_trend_filter.py`.

Entry logic:
  - HEMA ("Hull EMA", the source's own `f_hema`): `half = round(length/2)`,
    `sqrt_len = round(sqrt(length))`, `diff = 2*ema(src,half) -
    ema(src,length)`, `hema = ema(diff, sqrt_len)`.
  - `hema1` = HEMA(close, 20) (fast), `hema2` = HEMA(close, 40) (slow).
  - Long ("Bullish Trend"): `hema1` crosses over `hema2`, optionally
    (`isFilter`, default True) additionally requiring `close > base`,
    where `base` is the SAME triple-EMA "Gradient Trend Filter" base
    line from the sibling signal in this file (`noise_filter(close,
    25)`) -- recomputed locally here rather than importing
    `gradient_trend_filter` to keep this module self-contained, matching
    the style of other single-purpose modules in this collection.
  - Short ("Bearish Trend"): `hema1` crosses under `hema2`, optionally
    (`isFilter`) requiring `close < base`.

Not ported: the box-based "re-test" markers (`bull_box`/`bear_box`,
`low_test`/`high_test` triangle plotchars) and the EMA/ATR support-
resistance touch labels lower in the same source region -- pure
visualization, not alertcondition-gated. `barcolor` trend classification
is likewise cosmetic and skipped.
"""
from __future__ import annotations

import math

import pandas as pd

from .common import Signal, ema, atr, synthetic_stop, SYNTHETIC_ATR_LEN

HEMA_LENGTH_FAST = 20
HEMA_LENGTH_SLOW = 40
IS_FILTER = True
BASE_LENGTH = 25  # gradient-filter base (see gradient_trend_filter.py)


def _hema(src: pd.Series, length: int) -> pd.Series:
    half = max(1, round(length / 2))
    sqrt_len = max(1, round(math.sqrt(length)))
    diff = 2 * ema(src, half) - ema(src, length)
    return ema(diff, sqrt_len)


def _base_filter(src: pd.Series, length: int) -> pd.Series:
    return ema(ema(ema(src, length), length), length)


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    close = df["close"]

    hema1 = _hema(close, HEMA_LENGTH_FAST)
    hema2 = _hema(close, HEMA_LENGTH_SLOW)
    base = _base_filter(close, BASE_LENGTH)

    cross_up = (hema1.shift(1) < hema2.shift(1)) & (hema1 > hema2)
    cross_dn = (hema1.shift(1) > hema2.shift(1)) & (hema1 < hema2)

    if IS_FILTER:
        bullish = cross_up & (close > base)
        bearish = cross_dn & (close < base)
    else:
        bullish = cross_up
        bearish = cross_dn

    atr_series = atr(df, SYNTHETIC_ATR_LEN)
    signals: list[Signal] = []
    valid_from = max(HEMA_LENGTH_SLOW, BASE_LENGTH * 3) + 2

    for i in range(valid_from, len(df)):
        up = bool(bullish.iloc[i]) if not pd.isna(bullish.iloc[i]) else False
        dn = bool(bearish.iloc[i]) if not pd.isna(bearish.iloc[i]) else False
        if not (up or dn):
            continue
        atr_v = atr_series.iloc[i]
        if pd.isna(atr_v):
            continue

        entry = float(close.iloc[i])
        direction = "long" if up else "short"
        stop = synthetic_stop(entry, float(atr_v), direction)
        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=stop,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="hema_cross", synthetic_stop=True,
        ))

    return signals
