"""Port of the "Blackflag FTS" (Fibonacci Trailing Stop) pullback-entry
signal, one of the sub-scripts bundled into the "COMBO" mega-file
(source: COMBOV6RUS.txt, lines ~628-712 -- confirmed byte-identical to
Algo__Blackflag_FTS__Daily_Volume_Profile.txt's own copy of the same
section, so this is ported once and covers both uploads).

Not ported from the same COMBO file (separate concerns, left for a later
round if wanted):
  - "Algo V.12" (lines 8-624) -- its own `bull`/`bear` range-filter flip
    signal is structurally the same family as the already-ported
    `twin_range_signal.py` (smoothed range filter + up/dn streak counter
    + flip-on-cross), and its S/R level crossing + trendline-break
    alertconditions overlap with the already-ported `sr_retest_finder.py`.
  - "Daily Volume Profile" (lines ~717-1342) -- POC/VAH/VAL level touches
    could in principle be turned into a mean-reversion signal, but the
    file wasn't fully re-read this round; flagging as a candidate rather
    than guessing at its alert semantics.

Blackflag FTS itself is a self-contained ATR chandelier-exit trend
follower (`Wild_ma`-smoothed modified True Range, ATRPeriod=28,
ATRFactor=5) with three Fibonacci retracement "buy/sell the pullback"
triggers layered on top (61.8% / 78.6% / 88.6% of the run from the
post-flip extreme back toward the trailing stop). This IS a genuinely
different, fully self-defined entry+exit system:

    entry  = close, the bar price closes back through a fib retracement
             level while still in the confirmed trend direction
    stop   = the chandelier trailing-stop line itself (`trail`) --
             NATIVE, no synthetic ATR stop needed
    target = none defined by the source -- falls back to the project's
             standard 1R/2R/3R ladder (Signal.take_profits=None)

Each of the three fib levels (61.8/78.6/88.6) fires as its own
independent Signal with a distinct label, since the source treats them
as three separate entry opportunities rather than one signal with three
targets.

`Wild_ma` is ported as the literal recursive formula from the source
(seeded at 0.0, alpha=1/28) rather than via common.rma, since Pine's
`var float _wild = 0.0` seeding differs from common.rma's NaN-until-
`length`-bars-accumulate seeding -- this matters here because Wild_ma
directly drives the stop-loss distance.
"""
from __future__ import annotations

import pandas as pd

from .common import Signal, sma

ATR_PERIOD = 28
ATR_FACTOR = 5
FIB_LEVELS = (0.618, 0.786, 0.886)
FIB_LABELS = ("fib_61.8", "fib_78.6", "fib_88.6")


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    h = df["high"].to_numpy()
    l = df["low"].to_numpy()
    c = df["close"].to_numpy()
    n = len(df)
    if n < ATR_PERIOD + 5:
        return []

    hl = df["high"] - df["low"]
    hl_sma = sma(hl, ATR_PERIOD).to_numpy()

    true_range = [0.0] * n
    for i in range(1, n):
        hi_lo = min(h[i] - l[i], 1.5 * hl_sma[i]) if not pd.isna(hl_sma[i]) else (h[i] - l[i])
        h_ref = (h[i] - c[i - 1]) if l[i] <= h[i - 1] else (h[i] - c[i - 1] - 0.5 * (l[i] - h[i - 1]))
        l_ref = (c[i - 1] - l[i]) if h[i] >= l[i - 1] else (c[i - 1] - l[i] - 0.5 * (l[i - 1] - h[i]))
        true_range[i] = max(hi_lo, h_ref, l_ref)
    true_range[0] = h[0] - l[0]

    wild = [0.0] * n
    for i in range(n):
        prev = wild[i - 1] if i > 0 else 0.0
        wild[i] = prev + (true_range[i] - prev) / ATR_PERIOD

    loss = [ATR_FACTOR * w for w in wild]
    up = [c[i] - loss[i] for i in range(n)]
    dn = [c[i] + loss[i] for i in range(n)]

    trend_up = [0.0] * n
    trend_down = [0.0] * n
    trend = [1] * n
    trail = [0.0] * n
    ex = [0.0] * n

    trend_up[0] = up[0]
    trend_down[0] = dn[0]
    trend[0] = 1
    trail[0] = trend_up[0]
    ex[0] = h[0]  # Trend[0] == 1 -> extremum seeds from the high (see docstring on the na-edge case)

    for i in range(1, n):
        trend_up[i] = max(up[i], trend_up[i - 1]) if c[i - 1] > trend_up[i - 1] else up[i]
        trend_down[i] = min(dn[i], trend_down[i - 1]) if c[i - 1] < trend_down[i - 1] else dn[i]

        if c[i] > trend_down[i - 1]:
            trend[i] = 1
        elif c[i] < trend_up[i - 1]:
            trend[i] = -1
        else:
            trend[i] = trend[i - 1]

        trail[i] = trend_up[i] if trend[i] == 1 else trend_down[i]

        flipped_up = trend[i - 1] == -1 and trend[i] == 1
        flipped_down = trend[i - 1] == 1 and trend[i] == -1
        if flipped_up:
            ex[i] = h[i]
        elif flipped_down:
            ex[i] = l[i]
        elif trend[i] == 1:
            ex[i] = max(ex[i - 1], h[i])
        else:
            ex[i] = min(ex[i - 1], l[i])

    fibs = {lvl: [ex[i] + (trail[i] - ex[i]) * lvl for i in range(n)] for lvl in FIB_LEVELS}

    signals: list[Signal] = []
    for lvl, label in zip(FIB_LEVELS, FIB_LABELS):
        f = fibs[lvl]
        for i in range(2, n):
            cross_under = c[i - 1] >= f[i - 2] and c[i] < f[i - 1]
            cross_over = c[i - 1] <= f[i - 2] and c[i] > f[i - 1]

            state_prev = trend[i - 1]
            entry = float(c[i])
            sl = float(trail[i])

            if state_prev == 1 and cross_under:
                if entry <= sl:
                    continue
                signals.append(Signal(
                    direction="long", entry=entry, stop_loss=sl,
                    trigger_index=i, trigger_time=df["open_time"].iloc[i],
                    take_profits=None, label=f"blackflag_fts_{label}", synthetic_stop=False,
                ))
            elif state_prev == -1 and cross_over:
                if entry >= sl:
                    continue
                signals.append(Signal(
                    direction="short", entry=entry, stop_loss=sl,
                    trigger_index=i, trigger_time=df["open_time"].iloc[i],
                    take_profits=None, label=f"blackflag_fts_{label}", synthetic_stop=False,
                ))

    signals.sort(key=lambda s: s.trigger_index)
    return signals
