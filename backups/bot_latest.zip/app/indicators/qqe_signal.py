"""Standalone port of the QQE (Quantitative Qualitative Estimation)
long/short construction found bolted onto the back of "Adaptive Kalman
Filter with Trend Signals" (code: 2d41efc2-code_Adaptive_Kalman_Filter_
with_Trend_Signals.txt, lines ~256-298, the "QQE Signals Logic with
Kalman Filter" section).

Note on source attribution: the batch task description associated this
extraction with the *other* Kalman file (the Trend Strength Oscillator
one), but on inspection the QQE code actually lives in this one instead
(the Trend Strength Oscillator file has no QQE at all -- it has an
unrelated channel-breakout script, ported separately as
channel_breakout.py). Ported from where the code actually is.

CANONICAL COPY: this module is the one other ports in this collection
should point back to for QQE (per the batch plan, a separate "Deviation
Trend Profile" file handled by another agent also contains a QQE
construction and was told to defer to this module instead of
re-implementing it).

Generalization: the source runs QQE on `qqe_src = filtered_src2`, i.e.
chained after that file's own two-stage Kalman filter. Since this module
needs to be independently reusable (per the task), it runs the exact
same QQE recipe directly on `close` instead -- QQE is itself a
well-known standalone indicator (Quantitative Qualitative Estimation,
by Sherbina, built from a double-smoothed RSI with an ATR-of-RSI
trailing band) and does not depend on being fed a Kalman-filtered price.
Anyone wanting the exact original chained behaviour can pre-filter
`close` with adaptive_kalman_trend.py's `_two_stage_kalman_filtered_src`
before calling this module's internals.

Formula (verbatim from source, `src` = close here)::

    Wilders_Period = RSI_Period * 2 - 1        # RSI_Period = 14 -> 27
    Rsi     = ta.rsi(src, RSI_Period)
    RsiMa   = ta.ema(Rsi, SF)                  # SF = 5
    AtrRsi  = |RsiMa[1] - RsiMa|
    MaAtrRsi= ta.ema(AtrRsi, Wilders_Period)
    dar     = ta.ema(MaAtrRsi, Wilders_Period) * QQE   # QQE = 4.238 ("Fast QQE Factor")

    newshortband = RsiMa + dar
    newlongband  = RsiMa - dar
    longband  := (RsiMa[1] > longband[1] and RsiMa > longband[1]) ? max(longband[1], newlongband) : newlongband
    shortband := (RsiMa[1] < shortband[1] and RsiMa < shortband[1]) ? min(shortband[1], newshortband) : newshortband

    long_cross  = ta.crossunder(RsiMa, longband[1])
    short_cross = ta.crossover(RsiMa, shortband[1])
    trend_qqe := short_cross ? 1 : long_cross ? -1 : trend_qqe[1]

    qqeLong_signal  = trend_qqe == 1  and trend_qqe[1] == -1
    qqeShort_signal = trend_qqe == -1 and trend_qqe[1] == 1

`ThreshHold` (default 10, "Thresh-hold" input) is read from the UI but
never referenced anywhere in the signal logic in the source file -- kept
here as a documented but unused constant for parity, matching the
source's own dead input.
"""
from __future__ import annotations

import pandas as pd

from .common import Signal, rsi, ema, synthetic_stop, atr, SYNTHETIC_ATR_LEN

RSI_PERIOD = 14
SF = 5              # "RSI Smoothing"
QQE_FACTOR = 4.238   # "Fast QQE Factor"
THRESHOLD = 10        # unused in source logic; kept for parity


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    close = df["close"]
    n = len(df)

    wilders_period = RSI_PERIOD * 2 - 1
    rsi_val = rsi(close, RSI_PERIOD)
    rsi_ma = ema(rsi_val, SF)
    atr_rsi = (rsi_ma.shift(1) - rsi_ma).abs()
    ma_atr_rsi = ema(atr_rsi, wilders_period)
    dar = ema(ma_atr_rsi, wilders_period) * QQE_FACTOR

    rsi_ma_arr = rsi_ma.to_numpy()
    dar_arr = dar.to_numpy()

    longband = [0.0] * n
    shortband = [0.0] * n
    trend_qqe = [0] * n

    # Pine: long_cross = ta.crossunder(RsiMa, longband[1])
    #       short_cross = ta.crossover(RsiMa, shortband[1])
    # Both compare RsiMa against the ONE-BAR-SHIFTED band series, and
    # ta.crossunder/over itself compares each series' own current vs
    # previous value -- i.e. long_cross[i] needs longband[i-1] (this
    # bar's "current" value of the shifted series) AND longband[i-2]
    # (last bar's value of the shifted series). See module docstring.
    for i in range(n):
        if i == 0 or pd.isna(rsi_ma_arr[i]) or pd.isna(dar_arr[i]):
            continue

        new_shortband = rsi_ma_arr[i] + dar_arr[i]
        new_longband = rsi_ma_arr[i] - dar_arr[i]

        prev_rsi_ma = rsi_ma_arr[i - 1]
        prev_longband = longband[i - 1]
        prev_shortband = shortband[i - 1]

        if prev_rsi_ma > prev_longband and rsi_ma_arr[i] > prev_longband:
            longband[i] = max(prev_longband, new_longband)
        else:
            longband[i] = new_longband

        if prev_rsi_ma < prev_shortband and rsi_ma_arr[i] < prev_shortband:
            shortband[i] = min(prev_shortband, new_shortband)
        else:
            shortband[i] = new_shortband

        if i >= 2:
            long_cross = rsi_ma_arr[i - 1] >= longband[i - 2] and rsi_ma_arr[i] < longband[i - 1]
            short_cross = rsi_ma_arr[i - 1] <= shortband[i - 2] and rsi_ma_arr[i] > shortband[i - 1]
        else:
            long_cross = short_cross = False

        if short_cross:
            trend_qqe[i] = 1
        elif long_cross:
            trend_qqe[i] = -1
        else:
            trend_qqe[i] = trend_qqe[i - 1]

    atr_synth = atr(df, SYNTHETIC_ATR_LEN)
    signals: list[Signal] = []
    for i in range(1, n):
        if pd.isna(atr_synth.iloc[i]):
            continue
        qqe_long = trend_qqe[i] == 1 and trend_qqe[i - 1] == -1
        qqe_short = trend_qqe[i] == -1 and trend_qqe[i - 1] == 1
        if not (qqe_long or qqe_short):
            continue
        direction = "long" if qqe_long else "short"
        entry = float(close.iloc[i])
        sl = synthetic_stop(entry, float(atr_synth.iloc[i]), direction)
        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=sl,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="qqe_signal", synthetic_stop=True,
        ))

    return signals
