"""Squeeze Momentum Indicator (LazyBear's classic "SQZMOM_LB", the
canonical free/open TradingView version of "TTM Squeeze") -- ported here
as a genuinely NEW mechanism family for this project: every prior
indicator tested (49 ports + the SMC bot + a 5-way confluence combiner,
see pine-indicators-python-port doc) was either trend-following,
oscillator/mean-reversion, or SMC/order-block. This is a volatility-
BREAKOUT system: it detects when price coils tightly (Bollinger Bands
sitting fully inside Keltner Channels -- "squeeze on") and fires when
that coil releases (BB expands back outside KC -- "squeeze off"),
direction taken from the sign of a linear-regression momentum value. Buys
expansion instead of fading extension -- the opposite philosophy from
every mean-reversion module already tested here.

    bb_basis = SMA(close, 20);  bb_dev = 2.0 * STDEV(close, 20)
    kc_basis = SMA(close, 20);  kc_range = 1.5 * SMA(TrueRange, 20)   // useTrueRange=true
    squeeze_on  = (bb_basis - bb_dev > kc_basis - kc_range) and
                  (bb_basis + bb_dev < kc_basis + kc_range)            // BB fully inside KC
    val = linreg( close - avg( avg(highest(high,20), lowest(low,20)), sma(close,20) ), 20 )

Entry fires on the bar squeeze_on transitions True -> False (release),
direction = long if val > 0 else short. No native stop (this is a pure
momentum/volatility construct, no risk level defined) -- synthetic
ATR(14) stop + default 1R/2R/3R ladder, same convention as every other
synthetic-stop module in this collection.
"""
from __future__ import annotations

import pandas as pd

from .common import Signal, atr, linreg_endpoint, highest, lowest, sma, stdev, \
    synthetic_stop, true_range, SYNTHETIC_ATR_LEN, SYNTHETIC_ATR_MULT

BB_LENGTH = 20
BB_MULT = 2.0
KC_LENGTH = 20
KC_MULT = 1.5


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    n = len(df)
    if n < BB_LENGTH + 5:
        return []

    close = df["close"]
    high = df["high"]
    low = df["low"]

    bb_basis = sma(close, BB_LENGTH)
    bb_dev = BB_MULT * stdev(close, BB_LENGTH)
    bb_upper = bb_basis + bb_dev
    bb_lower = bb_basis - bb_dev

    kc_basis = sma(close, KC_LENGTH)
    kc_range = KC_MULT * sma(true_range(df), KC_LENGTH)
    kc_upper = kc_basis + kc_range
    kc_lower = kc_basis - kc_range

    squeeze_on = (bb_lower > kc_lower) & (bb_upper < kc_upper)

    mid = (highest(high, BB_LENGTH) + lowest(low, BB_LENGTH)) / 2.0
    mid = (mid + sma(close, BB_LENGTH)) / 2.0
    val = linreg_endpoint(close - mid, BB_LENGTH)

    squeeze_on_np = squeeze_on.fillna(False).to_numpy()
    val_np = val.to_numpy()
    close_np = close.to_numpy()
    atr_synth = atr(df, SYNTHETIC_ATR_LEN).to_numpy()

    signals: list[Signal] = []
    for i in range(1, n):
        released = bool(squeeze_on_np[i - 1]) and not bool(squeeze_on_np[i])
        if not released:
            continue
        v = val_np[i]
        if v != v:  # NaN
            continue
        direction = "long" if v > 0 else "short"

        a_synth = atr_synth[i]
        if a_synth != a_synth:
            continue

        entry = float(close_np[i])
        sl = synthetic_stop(entry, float(a_synth), direction, SYNTHETIC_ATR_MULT)
        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=sl,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="squeeze_momentum_breakout", synthetic_stop=True,
            meta={"momentum": float(v)},
        ))

    return signals
