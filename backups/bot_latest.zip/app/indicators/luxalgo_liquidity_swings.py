"""Port of the "Liquidity Swings [LuxAlgo]" sub-system bolted onto the
back of JohnScript (source: 04932d32-______.txt, lines 639-850). The
identical code also appears in ComboInd1 (9292ef80-ComboInd1.txt lines
904-1117) -- confirmed by diff, so ComboInd1 does not get its own copy.

CANONICAL COPY: this module is the one other ports in this collection
should point back to for LuxAlgo Liquidity Swings (see ut_bot_alert.py's
docstring for the equivalent note about UT Bot -- same batch-ownership
arrangement applies here).

What the original script actually does: on every confirmed `ta.pivothigh
(length, length)` / `ta.pivotlow(length, length)`, it draws a box/line/
label showing how many bars (or how much volume) have since traded back
into that pivot's wick-to-body ("Wick Extremity") or full-range zone --
a liquidity/order-flow visualization, not a directional trade signal.
There is no alertcondition, plotshape long/short, or barcolor anywhere
in the file.

Fidelity note / approximation: to turn this into a discrete directional
Signal (required by every module in this batch), a confirmed swing pivot
is read as a liquidity-sweep reversal setup -- the same interpretation
already used implicitly by quantum_scalper.py's S/R touch-and-reject
logic and consistent with how liquidity-swing zones are conventionally
traded (fade the sweep): a confirmed pivot LOW fires long (support/
liquidity zone held), a confirmed pivot HIGH fires short (resistance/
liquidity zone held). The `area` ('Wick Extremity' vs 'Full Range'),
count/volume filter, and intrabar-precision options are pure display
filters in the original and are not modelled -- every confirmed pivot
fires, matching `filterValue=0` (the default, which passes everything).
"""
from __future__ import annotations

import pandas as pd

from .common import Signal, pivothigh, pivotlow, synthetic_stop, atr, SYNTHETIC_ATR_LEN

PIVOT_LOOKBACK = 14  # `length` in the Pine source


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    high, low, close = df["high"], df["low"], df["close"]

    ph = pivothigh(high, PIVOT_LOOKBACK, PIVOT_LOOKBACK)
    pl = pivotlow(low, PIVOT_LOOKBACK, PIVOT_LOOKBACK)
    atr_synth = atr(df, SYNTHETIC_ATR_LEN)

    signals: list[Signal] = []
    valid_from = 2 * PIVOT_LOOKBACK + 1

    for i in range(valid_from, len(df)):
        if pd.isna(atr_synth.iloc[i]):
            continue

        is_ph = not pd.isna(ph.iloc[i])
        is_pl = not pd.isna(pl.iloc[i])
        if not (is_ph or is_pl):
            continue

        # Both could fire on the same confirmation bar in a very choppy
        # window (independent left/right windows) -- emit both if so.
        entry = float(close.iloc[i])
        if is_ph:
            sl = synthetic_stop(entry, float(atr_synth.iloc[i]), "short")
            signals.append(Signal(
                direction="short", entry=entry, stop_loss=sl,
                trigger_index=i, trigger_time=df["open_time"].iloc[i],
                take_profits=None, label="luxalgo_liquidity_swings", synthetic_stop=True,
            ))
        if is_pl:
            sl = synthetic_stop(entry, float(atr_synth.iloc[i]), "long")
            signals.append(Signal(
                direction="long", entry=entry, stop_loss=sl,
                trigger_index=i, trigger_time=df["open_time"].iloc[i],
                take_profits=None, label="luxalgo_liquidity_swings", synthetic_stop=True,
            ))

    return signals
