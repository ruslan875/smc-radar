"""Port of the "ATR Fibonacci Trend Envelopes" half of "AI_Vanga Forecast
Line + ATR Fibonacci Trend Envelopes" (source: AI_Vanga_Forecast_Line__
ATR_Fibonacci_Trend_Envelopes.txt, Pine v6).

Not ported: the "Forecast Line" half (lines 1-46 of the source) -- a
`barstate.islast`-only extrapolation that redraws itself from a random
walk seeded by trailing price changes every time the chart repaints; it
has no bar-by-bar signal or alertcondition, is explicitly non-deterministic
bar-to-bar (recomputed only on the last bar), and is pure visualization
by the project's own Category D standard. The MTF dashboard (lines
191-204) is also visualization-only and not ported.

The trend envelope itself IS a genuine, deterministic, non-repainting
signal: an RMA(100) basis +/- ATR(100)*3 channel, with a persistent
`trend` state that flips from -1 to +1 the bar close crosses over the
upper band, and from +1 to -1 the bar close crosses under the lower band
(`calc_trend_and_pocket`, lines 99-114). Every flip bar is ported here as
an entry signal -- the golden-pocket Fibonacci retracement levels (fib50/
618/786) and their projection lines are the indicator's own visualization
of "where a pullback should hold", not an entry trigger, so they are not
turned into a separate signal; only the initial breakout flip is.

No native stop-loss is defined (the bands are a trend filter, not a risk
level) -- per the batch-wide convention, the shared synthetic ATR(14)
stop is used.
"""
from __future__ import annotations

import pandas as pd

from .common import Signal, atr, rma, synthetic_stop, SYNTHETIC_ATR_LEN, SYNTHETIC_ATR_MULT

MA_LENGTH = 100
ATR_LENGTH = 100
ATR_MULT = 3.0


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    close = df["close"]
    basis = rma(close, MA_LENGTH)
    a = atr(df, ATR_LENGTH)
    upper = basis + a * ATR_MULT
    lower = basis - a * ATR_MULT

    prev_close = close.shift(1)
    prev_upper = upper.shift(1)
    prev_lower = lower.shift(1)

    crossover_up = (prev_close <= prev_upper) & (close > upper)
    crossunder_lo = (prev_close >= prev_lower) & (close < lower)

    atr_synth = atr(df, SYNTHETIC_ATR_LEN)

    signals: list[Signal] = []
    for i in range(len(df)):
        if bool(crossover_up.iloc[i]):
            direction = "long"
        elif bool(crossunder_lo.iloc[i]):
            direction = "short"
        else:
            continue

        a_synth = atr_synth.iloc[i]
        if pd.isna(a_synth):
            continue

        entry = float(close.iloc[i])
        sl = synthetic_stop(entry, float(a_synth), direction, SYNTHETIC_ATR_MULT)
        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=sl,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="ai_vanga_trend_flip", synthetic_stop=True,
        ))

    return signals
