"""Port of the "Wick Pressure" (SiddWolf) alertconditions from
"MoPeDa.net" v2.0 (source lines 938-953, 1149-1150) -- independent of the
ADX/Bollinger zone logic used by `mopeda_zone_entry.py` /
`mopeda_wick_signal.py`. Detects a tight 3-candle cluster of rejection
wicks near the same level, confirmed by a recent RSI extreme:

    ll3 = lowest(low, 3)
    lc3 = min(lowest(close, 3), lowest(open, 3))       // 3-bar min "body low"
    rsi_bullish_cond = rsi<35 or rsi[1]<35 or rsi[2]<35   // oversold in last 3 bars
    sidd_bull_cond = low<=lc3 and low[1]<=lc3 and low[2]<=lc3     // NOTE: lc3
                      and open>=lc3 and open[1]>=lc3 and open[2]>=lc3   // is the
                      and (lc3 - ll3) > 0.35*ATR(14)                    // CURRENT
                      and rsi_bullish_cond and close > open             // bar's lc3,
                                                                          // not shifted
    -> BUY (long)

Mirrored with highs/opens (hh3, hc3, RSI>70) for sidd_bear_cond -> SELL
(short). The source only draws a visual "pressure box" from lc3/ll3 (or
hc3/hh3) extending `wpBoxLength` bars forward -- it does not define an
entry price. Reading it as a market entry at the close of the signal bar
is this port's own reasonable interpretation (same caveat as
`sr_retest_finder.py` elsewhere in this collection), not something the
source itself specifies. No native stop -- synthetic ATR(14) stop +
default 1R/2R/3R ladder per the batch convention. No cooldown in the
source for this signal (unlike the zone-based signals above).
"""
from __future__ import annotations

import pandas as pd

from .common import Signal, atr, highest, lowest, rsi as rsi_fn, synthetic_stop, \
    SYNTHETIC_ATR_LEN, SYNTHETIC_ATR_MULT

RSI_LENGTH = 14
RSI_OB = 70
RSI_OS = 35
ATR_MULT = 0.35


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    n = len(df)
    if n < 20:
        return []

    high = df["high"]
    low = df["low"]
    open_ = df["open"]
    close = df["close"]

    r = rsi_fn(close, RSI_LENGTH)
    atr14 = atr(df, SYNTHETIC_ATR_LEN)

    ll3 = lowest(low, 3)
    lc3 = pd.concat([lowest(close, 3), lowest(open_, 3)], axis=1).min(axis=1)
    rsi_bullish_cond = (r < RSI_OS) | (r.shift(1) < RSI_OS) | (r.shift(2) < RSI_OS)
    sidd_bull_cond = (
        (low <= lc3) & (low.shift(1) <= lc3) & (low.shift(2) <= lc3)
        & (open_ >= lc3) & (open_.shift(1) >= lc3) & (open_.shift(2) >= lc3)
        & ((lc3 - ll3) > ATR_MULT * atr14)
        & rsi_bullish_cond & (close > open_)
    )

    hh3 = highest(high, 3)
    hc3 = pd.concat([highest(close, 3), highest(open_, 3)], axis=1).max(axis=1)
    rsi_bearish_cond = (r > RSI_OB) | (r.shift(1) > RSI_OB) | (r.shift(2) > RSI_OB)
    sidd_bear_cond = (
        (high >= hc3) & (high.shift(1) >= hc3) & (high.shift(2) >= hc3)
        & (open_ <= hc3) & (open_.shift(1) <= hc3) & (open_.shift(2) <= hc3)
        & ((hh3 - hc3) > ATR_MULT * atr14)
        & rsi_bearish_cond & (close < open_)
    )

    sidd_bull_cond = sidd_bull_cond.fillna(False).to_numpy()
    sidd_bear_cond = sidd_bear_cond.fillna(False).to_numpy()
    atr_np = atr14.to_numpy()
    close_np = close.to_numpy()

    signals: list[Signal] = []
    for i in range(n):
        if sidd_bull_cond[i]:
            direction = "long"
        elif sidd_bear_cond[i]:
            direction = "short"
        else:
            continue

        a_synth = atr_np[i]
        if a_synth != a_synth:
            continue

        entry = float(close_np[i])
        sl = synthetic_stop(entry, float(a_synth), direction, SYNTHETIC_ATR_MULT)
        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=sl,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="mopeda_wick_pressure_sidd", synthetic_stop=True,
        ))

    return signals
