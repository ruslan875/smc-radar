"""Shared Signal type + hand-rolled TA primitives for the third-party
indicator ports.

No pandas-ta/ta dependency is used on purpose: those libraries' exact
formulas don't always match Pine's built-ins (rounding, seeding,
Wilder-vs-simple smoothing), and app/smc.py already sets the precedent of
hand-rolling everything so the Python side is byte-for-byte auditable
against the Pine source. Every function here is a direct translation of a
documented Pine `ta.*` built-in.
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np
import pandas as pd

RISK_MULTIPLES_DEFAULT = (1, 2, 3)

# Synthetic stop used for indicators that define an entry signal but no
# native stop-loss (the vast majority of the collection). Chosen once here
# and applied consistently everywhere instead of inventing a bespoke rule
# per indicator: stop = entry -/+ ATR_MULT * ATR(ATR_LEN), same spirit as
# app/smc.py's own zone-edge-minus-ATR stop. Take-profit defaults to the
# same 1R/2R/3R ladder backtest.py already uses for the SMC bot, via
# Signal.take_profits=None (see generic_backtest.simulate_outcome).
SYNTHETIC_ATR_LEN = 14
SYNTHETIC_ATR_MULT = 1.5


@dataclass
class Signal:
    direction: str          # "long" or "short"
    entry: float
    stop_loss: float
    trigger_index: int      # positional index into the df this signal came from
    trigger_time: pd.Timestamp
    take_profits: list[float] | None = None   # explicit price levels; None => use 1R/2R/3R ladder
    label: str = ""          # which sub-signal within a multi-signal file this is
    synthetic_stop: bool = False  # True if stop_loss was NOT defined by the original Pine script
    meta: dict = field(default_factory=dict)


# --------------------------------------------------------------- basics --

def true_range(df: pd.DataFrame) -> pd.Series:
    prev_close = df["close"].shift(1)
    return pd.concat([
        df["high"] - df["low"],
        (df["high"] - prev_close).abs(),
        (df["low"] - prev_close).abs(),
    ], axis=1).max(axis=1)


def rma(series: pd.Series, length: int) -> pd.Series:
    """Pine's ta.rma: Wilder smoothing, alpha = 1/length, seeded with the
    simple mean of the first `length` values (matches Pine's internal
    behaviour of returning na until `length` bars have accumulated)."""
    alpha = 1.0 / length
    out = series.ewm(alpha=alpha, adjust=False).mean()
    out.iloc[: length - 1] = np.nan
    return out


def ema(series: pd.Series, length: int) -> pd.Series:
    return series.ewm(span=length, adjust=False).mean()


def sma(series: pd.Series, length: int) -> pd.Series:
    return series.rolling(length, min_periods=length).mean()


def stdev(series: pd.Series, length: int) -> pd.Series:
    """Pine's ta.stdev is a population (not sample) standard deviation."""
    return series.rolling(length, min_periods=length).std(ddof=0)


def variance(series: pd.Series, length: int) -> pd.Series:
    return series.rolling(length, min_periods=length).var(ddof=0)


def atr(df: pd.DataFrame, length: int) -> pd.Series:
    return rma(true_range(df), length)


def rsi(series: pd.Series, length: int) -> pd.Series:
    delta = series.diff()
    up = delta.clip(lower=0)
    down = -delta.clip(upper=0)
    roll_up = rma(up, length)
    roll_down = rma(down, length)
    rs = roll_up / roll_down.replace(0, np.nan)
    out = 100 - (100 / (1 + rs))
    out = out.where(roll_down != 0, 100.0)
    return out


def cci(src: pd.Series, length: int) -> pd.Series:
    ma = sma(src, length)
    mad = src.rolling(length, min_periods=length).apply(lambda x: np.mean(np.abs(x - x.mean())), raw=True)
    return (src - ma) / (0.015 * mad.replace(0, np.nan))


def dmi_adx(df: pd.DataFrame, di_length: int, adx_smoothing: int) -> pd.Series:
    """Pine's ta.dmi(diLength, adxSmoothing) -- returns only the ADX line
    (the third return value), which is all every indicator in this
    collection actually uses."""
    up = df["high"].diff()
    down = -df["low"].diff()
    plus_dm = np.where((up > down) & (up > 0), up, 0.0)
    minus_dm = np.where((down > up) & (down > 0), down, 0.0)
    plus_dm = pd.Series(plus_dm, index=df.index)
    minus_dm = pd.Series(minus_dm, index=df.index)

    tr_rma = rma(true_range(df), di_length)
    plus = 100 * rma(plus_dm, di_length) / tr_rma
    minus = 100 * rma(minus_dm, di_length) / tr_rma
    plus = plus.ffill()
    minus = minus.ffill()

    total = (plus + minus).replace(0, 1.0)
    dx = (plus - minus).abs() / total * 100
    return rma(dx, adx_smoothing)


def highest(series: pd.Series, length: int) -> pd.Series:
    return series.rolling(length, min_periods=length).max()


def lowest(series: pd.Series, length: int) -> pd.Series:
    return series.rolling(length, min_periods=length).min()


def rising(series: pd.Series, length: int) -> pd.Series:
    return series > series.shift(length)


def falling(series: pd.Series, length: int) -> pd.Series:
    return series < series.shift(length)


def pivothigh(series: pd.Series, left: int, right: int) -> pd.Series:
    """Pine's ta.pivothigh(left, right): a bar is a confirmed pivot if it's
    the max over [bar-left, bar+right], and Pine only reveals that value
    `right` bars later (no lookahead). Works for asymmetric left != right,
    unlike a naive centered rolling window."""
    window = left + right + 1
    rolling_max = series.rolling(window, min_periods=window).max()
    aligned_max = rolling_max.shift(-right)  # bring window-max at i+right back to i
    raw = series.where(series == aligned_max)
    return raw.shift(right)  # reveal at the confirmation bar, i+right


def pivotlow(series: pd.Series, left: int, right: int) -> pd.Series:
    window = left + right + 1
    rolling_min = series.rolling(window, min_periods=window).min()
    aligned_min = rolling_min.shift(-right)
    raw = series.where(series == aligned_min)
    return raw.shift(right)


def synthetic_stop(entry: float, atr_value: float, direction: str,
                    mult: float = SYNTHETIC_ATR_MULT) -> float:
    if direction == "long":
        return entry - mult * atr_value
    return entry + mult * atr_value


def barssince(cond: pd.Series) -> pd.Series:
    """Pine's ta.barssince(cond): bars since `cond` was last true (0 if
    true on the current bar itself), NaN if it has never been true yet."""
    vals = cond.fillna(False).to_numpy()
    out = np.full(len(vals), np.nan)
    last_true = -1
    for i in range(len(vals)):
        if vals[i]:
            last_true = i
        if last_true >= 0:
            out[i] = i - last_true
    return pd.Series(out, index=cond.index)


def linreg_endpoint(series: pd.Series, length: int) -> pd.Series:
    """Pine's ta.linreg(source, length, offset=0): fits a least-squares
    line to the last `length` bars and returns the line's value AT the
    current (most recent) bar -- i.e. the regression endpoint, not the
    midpoint. Vectorized via a sliding window (no NaNs tolerated inside a
    window, same as Pine)."""
    values = series.to_numpy(dtype=float)
    n = len(values)
    out = np.full(n, np.nan)
    if n < length:
        return pd.Series(out, index=series.index)

    x = np.arange(length, dtype=float)
    x_mean = x.mean()
    x_var = ((x - x_mean) ** 2).sum()

    windows = np.lib.stride_tricks.sliding_window_view(values, length)
    y_mean = windows.mean(axis=1)
    cov = ((windows - y_mean[:, None]) * (x - x_mean)).sum(axis=1)
    slope = cov / x_var
    intercept = y_mean - slope * x_mean
    pred = intercept + slope * (length - 1)

    out[length - 1:] = pred
    return pd.Series(out, index=series.index)


def valuewhen(cond: pd.Series, source: pd.Series, occurrence: int = 0) -> pd.Series:
    """Pine's ta.valuewhen(cond, source, occurrence): the value of `source`
    at the `occurrence`-th most recent bar (at or before the current one)
    where `cond` was true -- occurrence=0 is the most recent such bar,
    occurrence=1 the one before that, etc. NaN until enough occurrences
    have happened."""
    cond_vals = cond.fillna(False).to_numpy()
    src_vals = source.to_numpy()
    out = np.full(len(cond_vals), np.nan)
    true_indices: list[int] = []
    for i in range(len(cond_vals)):
        if cond_vals[i]:
            true_indices.append(i)
        idx_pos = len(true_indices) - 1 - occurrence
        if idx_pos >= 0:
            out[i] = src_vals[true_indices[idx_pos]]
    return pd.Series(out, index=cond.index)
