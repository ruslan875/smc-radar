"""Port of Module 1 ("Trend Deviation Zones [Pullback Entries]", TDZ core)
from TDZPullback.txt. This file bundles four independent sub-scripts
concatenated together (confirmed by reading the whole 696-line source and
its accompanying description) -- each is ported into its own module so
they stay independently testable:

    tdz_pullback.py      <- this file, Module 1: TDZ core (trend + zones)
    tdz_range_signals.py <- Module 2: wide-range false-breakout signals
    tdz_qatl_mtf.py       <- Module 3: QATL Multi-Timeframe adaptive trend
    tdz_swing_bos.py      <- Module 4: swing points + Break of Structure

Module 1 logic (source lines ~1-183): a moving average (`maType`, default
EMA) with four ATR/StdDev/MeanDev-scaled deviation bands above and below
it. `trendUp`/`trendDown` come from `ta.rising`/`ta.falling` on the MA
itself (stable through pullbacks). The "optimal zone" (between the MA and
the first band, on the side favoring trend continuation) is the entry
signal, debounced to fire once on zone *entry* rather than every bar
spent inside it:

    inOptimalLong  = trendUp   and close <= maValue and close >= l1
    newOptimalLong = inOptimalLong and not (same condition true last bar)
    inOptimalShort = trendDown and close >= maValue and close <= u1
    newOptimalShort = inOptimalShort and not (same condition true last bar)

Fidelity notes:
- `maType` defaults to "EMA" and `devType` defaults to "ATR" -- both
  ported faithfully via common.py. WMA/HMA/LinReg (`maType` options) and
  MeanDev (`devType` option) are also implemented locally below (not in
  common.py) since a caller could reasonably want to exercise them, but
  the *defaults* (EMA + ATR) are what this module runs unless overridden.
- `ta.dev` (MeanDev) is mean absolute deviation from the window's own
  SMA, same rolling-apply pattern common.py already uses for `cci`'s MAD.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .common import (
    Signal, sma, ema, atr, stdev, rising, falling,
    synthetic_stop, SYNTHETIC_ATR_LEN, SYNTHETIC_ATR_MULT,
)

MA_LENGTH = 50
MA_TYPE = "EMA"          # SMA | EMA | WMA | HMA | LinReg
DEV_TYPE = "ATR"         # ATR | StdDev | MeanDev
DEV_LENGTH = 14
MULT1, MULT2, MULT3, MULT4 = 0.5, 1.0, 1.5, 2.0


def _wma(series: pd.Series, length: int) -> pd.Series:
    weights = np.arange(1, length + 1, dtype=float)
    wsum = weights.sum()
    return series.rolling(length, min_periods=length).apply(lambda x: np.dot(x, weights) / wsum, raw=True)


def _hma(series: pd.Series, length: int) -> pd.Series:
    half = max(1, round(length / 2))
    sqrt_len = max(1, round(length ** 0.5))
    return _wma(2 * _wma(series, half) - _wma(series, length), sqrt_len)


def _linreg(series: pd.Series, length: int, offset: int = 0) -> pd.Series:
    x = np.arange(length, dtype=float)
    x_mean = x.mean()
    x_var = ((x - x_mean) ** 2).sum()

    def _f(y: np.ndarray) -> float:
        y_mean = y.mean()
        slope = ((x - x_mean) * (y - y_mean)).sum() / x_var
        intercept = y_mean - slope * x_mean
        return intercept + slope * (length - 1 - offset)

    return series.rolling(length, min_periods=length).apply(_f, raw=True)


def _mean_dev(series: pd.Series, length: int) -> pd.Series:
    return series.rolling(length, min_periods=length).apply(lambda x: np.mean(np.abs(x - x.mean())), raw=True)


def _ma_by_type(close: pd.Series, ma_type: str, length: int) -> pd.Series:
    if ma_type == "SMA":
        return sma(close, length)
    if ma_type == "WMA":
        return _wma(close, length)
    if ma_type == "HMA":
        return _hma(close, length)
    if ma_type == "LinReg":
        return _linreg(close, length, 0)
    return ema(close, length)  # default / "EMA"


def _dev_by_type(df: pd.DataFrame, dev_type: str, length: int) -> pd.Series:
    if dev_type == "StdDev":
        return stdev(df["close"], length)
    if dev_type == "MeanDev":
        return _mean_dev(df["close"], length)
    return atr(df, length)  # default / "ATR"


def generate_signals(df: pd.DataFrame, ma_type: str = MA_TYPE, dev_type: str = DEV_TYPE) -> list[Signal]:
    close = df["close"]

    ma_value = _ma_by_type(close, ma_type, MA_LENGTH)
    dev_value = _dev_by_type(df, dev_type, DEV_LENGTH)

    u1 = ma_value + MULT1 * dev_value
    l1 = ma_value - MULT1 * dev_value

    trend_up = rising(ma_value, 3)
    trend_down = falling(ma_value, 3)

    in_optimal_short = trend_down & (close >= ma_value) & (close <= u1)
    in_optimal_long = trend_up & (close <= ma_value) & (close >= l1)

    new_optimal_short = in_optimal_short & ~in_optimal_short.shift(1).fillna(False)
    new_optimal_long = in_optimal_long & ~in_optimal_long.shift(1).fillna(False)

    synth_atr = atr(df, SYNTHETIC_ATR_LEN)

    signals: list[Signal] = []
    for i in range(len(df)):
        is_long = bool(new_optimal_long.iloc[i]) if not pd.isna(new_optimal_long.iloc[i]) else False
        is_short = bool(new_optimal_short.iloc[i]) if not pd.isna(new_optimal_short.iloc[i]) else False
        if not (is_long or is_short):
            continue
        synth = synth_atr.iloc[i]
        if pd.isna(synth):
            continue

        entry = float(close.iloc[i])
        direction = "long" if is_long else "short"
        stop = synthetic_stop(entry, float(synth), direction, SYNTHETIC_ATR_MULT)

        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=stop,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="tdz_pullback", synthetic_stop=True,
        ))

    return signals
