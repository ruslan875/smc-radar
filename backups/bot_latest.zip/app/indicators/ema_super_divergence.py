"""Port of "EMA+Super with Divergence signals" (code: 0bfcd48c-code_
Emasuper_with_Divergence_signals.txt, description: 906e958d-description_
Emasuper_with_Divergence_signals..txt).

Two independent native signal sources in the source file, both ported:

1. Trend-confirmation cross (the file's own labelled "BUY"/"SELL"):
   a 9/21 EMA ("NovaWave") crossover confirmed by ta.supertrend(4.0, 10)
   direction --

       buy_signal  = ta.crossover(nw_fast, nw_slow) and direction < 0   (supertrend uptrend)
       sell_signal = ta.crossunder(nw_fast, nw_slow) and direction > 0  (supertrend downtrend)

2. Regular RSI divergence (bullish: price Lower-Low + RSI Higher-Low;
   bearish: price Higher-High + RSI Lower-High), computed on
   `ta.rsi(ta.mom(close, 10), 14)` (RSI of a 10-bar momentum series, as
   literally coded -- an unusual double-transform but ported as-is) with
   5-bar pivots and a 5-50 bar in-range gate between consecutive pivots.

Both fire as independent Signals (label distinguishes them), sorted by
trigger bar, so a single backtest run reports on the combined,
un-deduplicated signal stream -- exactly like the source draws both
label sets simultaneously and independently.

Not ported (pure visualization, no bearing on either signal): the 5 EMA
plots (9/21/50/100/200), the Supertrend fill shading itself (only its
`direction` value is used, for signal #1), the DMA20/50/200 displaced
moving averages, and the divergence zone box/line drawing
(`plotDivergenceLevels`) -- only the underlying `isBullDiv`/`isBearDiv`
booleans that drive it are used.

Fidelity note: `ta.supertrend` is Pine's built-in ATR SuperTrend; since
common.py has no ready-made SuperTrend, a standard causal
implementation (ATR bands that only ever tighten toward price, flip on
a close beyond the opposite band) is added locally below -- this is the
well-documented public SuperTrend algorithm, not a Pine-internal detail
requiring guesswork.
"""
from __future__ import annotations

import pandas as pd

from .common import Signal, rsi, atr, pivothigh, pivotlow, synthetic_stop, SYNTHETIC_ATR_LEN

NW_FAST_LEN = 9
NW_SLOW_LEN = 21
ST_ATR_PERIOD = 10
ST_FACTOR = 4.0

DIV_RSI_LEN = 14
DIV_MOM_LEN = 10
DIV_LOOKBACK_L = 5
DIV_LOOKBACK_R = 5
DIV_MIN_BARS_IN_RANGE = 5
DIV_MAX_BARS_IN_RANGE = 50


def _supertrend(df: pd.DataFrame, period: int, factor: float) -> pd.Series:
    """Standard causal ATR SuperTrend. direction<0 => uptrend (matches
    Pine's ta.supertrend convention used by the source: `direction < 0`
    gates the buy signal, `direction > 0` gates the sell signal)."""
    hl2 = (df["high"] + df["low"]) / 2
    atr_val = atr(df, period)
    upper_basic = hl2 + factor * atr_val
    lower_basic = hl2 - factor * atr_val
    close = df["close"]
    n = len(df)

    upper_final = [float("nan")] * n
    lower_final = [float("nan")] * n
    direction = [1] * n  # 1 = downtrend (direction>0), -1 = uptrend (direction<0)

    for i in range(n):
        if pd.isna(upper_basic.iloc[i]):
            continue
        if i == 0 or pd.isna(upper_final[i - 1]):
            upper_final[i] = upper_basic.iloc[i]
            lower_final[i] = lower_basic.iloc[i]
            direction[i] = 1
            continue

        upper_final[i] = (upper_basic.iloc[i] if (upper_basic.iloc[i] < upper_final[i - 1]
                           or close.iloc[i - 1] > upper_final[i - 1]) else upper_final[i - 1])
        lower_final[i] = (lower_basic.iloc[i] if (lower_basic.iloc[i] > lower_final[i - 1]
                           or close.iloc[i - 1] < lower_final[i - 1]) else lower_final[i - 1])

        prev_dir = direction[i - 1]
        if prev_dir == 1:  # was downtrend
            direction[i] = -1 if close.iloc[i] > upper_final[i] else 1
        else:  # was uptrend
            direction[i] = 1 if close.iloc[i] < lower_final[i] else -1

    return pd.Series(direction, index=df.index)


def _valuewhen_and_barssince(cond: pd.Series, src: pd.Series, occurrence: int):
    """Returns two aligned lists: `valuewhen[i]` = src value the
    `occurrence`-th most recent time cond was true at-or-before bar i
    (0 = the occurrence at bar i itself if cond[i], else the most recent
    prior one), and `barssince_shift1[i]` = ta.barssince(cond[1])[i]
    (bars since cond was last true, evaluated on the series shifted by
    one bar, matching the source's `_inRange(foundPL[1])` call)."""
    n = len(cond)
    hist_idx: list[int] = []  # bar indices (ascending) where cond was True
    valuewhen = [float("nan")] * n
    for i in range(n):
        if bool(cond.iloc[i]):
            hist_idx.append(i)
        target_pos = len(hist_idx) - 1 - occurrence
        if target_pos >= 0:
            valuewhen[i] = float(src.iloc[hist_idx[target_pos]])

    # barssince(cond[1])[i]: distance from bar i back to the most recent
    # j <= i-1 with cond[j] true (shifted-by-1 series read at bar i).
    barssince_shift1 = [float("inf")] * n
    last_true = None
    for i in range(n):
        # at bar i we look at shifted series value = cond[i-1]
        if i >= 1 and bool(cond.iloc[i - 1]):
            last_true = i - 1
        if last_true is not None:
            barssince_shift1[i] = i - last_true
    return valuewhen, barssince_shift1


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    close, high, low = df["close"], df["high"], df["low"]
    atr_synth = atr(df, SYNTHETIC_ATR_LEN)
    signals: list[Signal] = []

    # ---- 1. NovaWave EMA cross confirmed by SuperTrend direction ----
    from .common import ema
    nw_fast = ema(close, NW_FAST_LEN)
    nw_slow = ema(close, NW_SLOW_LEN)
    direction = _supertrend(df, ST_ATR_PERIOD, ST_FACTOR)

    crossover = (nw_fast.shift(1) <= nw_slow.shift(1)) & (nw_fast > nw_slow)
    crossunder = (nw_fast.shift(1) >= nw_slow.shift(1)) & (nw_fast < nw_slow)
    buy_signal = crossover & (direction < 0)
    sell_signal = crossunder & (direction > 0)

    for i in range(len(df)):
        if pd.isna(atr_synth.iloc[i]):
            continue
        d = None
        if bool(buy_signal.iloc[i]):
            d = "long"
        elif bool(sell_signal.iloc[i]):
            d = "short"
        if d is None:
            continue
        entry = float(close.iloc[i])
        sl = synthetic_stop(entry, float(atr_synth.iloc[i]), d)
        signals.append(Signal(
            direction=d, entry=entry, stop_loss=sl,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="ema_super_divergence_trend", synthetic_stop=True,
        ))

    # ---- 2. Regular RSI divergence ----
    rsi_src = close - close.shift(DIV_MOM_LEN)   # ta.mom(close, 10)
    rsi_val = rsi(rsi_src, DIV_RSI_LEN)
    rsi_right = rsi_val.shift(DIV_LOOKBACK_R)
    low_right = low.shift(DIV_LOOKBACK_R)
    high_right = high.shift(DIV_LOOKBACK_R)

    found_pl = ~pivotlow(rsi_val, DIV_LOOKBACK_L, DIV_LOOKBACK_R).isna()
    found_ph = ~pivothigh(rsi_val, DIV_LOOKBACK_L, DIV_LOOKBACK_R).isna()

    rsi_vw_pl, barssince_pl = _valuewhen_and_barssince(found_pl, rsi_right, 1)
    low_vw_pl, _ = _valuewhen_and_barssince(found_pl, low_right, 1)
    rsi_vw_ph, barssince_ph = _valuewhen_and_barssince(found_ph, rsi_right, 1)
    high_vw_ph, _ = _valuewhen_and_barssince(found_ph, high_right, 1)

    n = len(df)
    for i in range(n):
        if pd.isna(atr_synth.iloc[i]):
            continue

        if bool(found_pl.iloc[i]) and not pd.isna(rsi_vw_pl[i]):
            in_range = DIV_MIN_BARS_IN_RANGE <= barssince_pl[i] <= DIV_MAX_BARS_IN_RANGE
            rsi_hl = (not pd.isna(rsi_right.iloc[i])) and rsi_right.iloc[i] > rsi_vw_pl[i] and in_range
            price_ll = (not pd.isna(low_right.iloc[i])) and low_right.iloc[i] < low_vw_pl[i]
            if rsi_hl and price_ll:
                entry = float(close.iloc[i])
                sl = synthetic_stop(entry, float(atr_synth.iloc[i]), "long")
                signals.append(Signal(
                    direction="long", entry=entry, stop_loss=sl,
                    trigger_index=i, trigger_time=df["open_time"].iloc[i],
                    take_profits=None, label="ema_super_divergence_bull_div", synthetic_stop=True,
                ))

        if bool(found_ph.iloc[i]) and not pd.isna(rsi_vw_ph[i]):
            in_range = DIV_MIN_BARS_IN_RANGE <= barssince_ph[i] <= DIV_MAX_BARS_IN_RANGE
            rsi_lh = (not pd.isna(rsi_right.iloc[i])) and rsi_right.iloc[i] < rsi_vw_ph[i] and in_range
            price_hh = (not pd.isna(high_right.iloc[i])) and high_right.iloc[i] > high_vw_ph[i]
            if rsi_lh and price_hh:
                entry = float(close.iloc[i])
                sl = synthetic_stop(entry, float(atr_synth.iloc[i]), "short")
                signals.append(Signal(
                    direction="short", entry=entry, stop_loss=sl,
                    trigger_index=i, trigger_time=df["open_time"].iloc[i],
                    take_profits=None, label="ema_super_divergence_bear_div", synthetic_stop=True,
                ))

    signals.sort(key=lambda s: s.trigger_index)
    return signals
