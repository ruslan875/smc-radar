"""Port of the "1 & 2 EMAs Small crosses" signal from "9 indicators in 1
and more" (source lines 58-76): EMA(10) crossing EMA(21). Unlike
`custom_hybrid_ema_cross.py`'s source, this file's own direction labels
are the textbook-standard ones -- `golden_cross_small` requires
`EMA1[1] <= EMA2[1]` (fast was below slow, now crossed above = bullish),
`death_cross_small` the mirror -- so no inversion caveat is needed here.

No native stop-loss defined -- synthetic ATR(14) stop per the batch
convention. See `ema_cross_golden.py` for the file's other EMA pair
(55/200, the classic golden/death cross); the two are kept as separate
modules so their performance can be compared independently rather than
averaged together.
"""
from __future__ import annotations

import pandas as pd

from .common import Signal, atr, ema, synthetic_stop, SYNTHETIC_ATR_LEN, SYNTHETIC_ATR_MULT

FAST_LENGTH = 10
SLOW_LENGTH = 21


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    close = df["close"]
    fast = ema(close, FAST_LENGTH)
    slow = ema(close, SLOW_LENGTH)

    prev_fast = fast.shift(1)
    prev_slow = slow.shift(1)

    golden = (prev_fast <= prev_slow) & (fast > slow)
    death = (prev_slow <= prev_fast) & (fast < slow)

    atr_synth = atr(df, SYNTHETIC_ATR_LEN)

    signals: list[Signal] = []
    for i in range(len(df)):
        if bool(golden.iloc[i]):
            direction = "long"
        elif bool(death.iloc[i]):
            direction = "short"
        else:
            continue

        a_synth = atr_synth.iloc[i]
        if pd.isna(a_synth):
            continue

        entry = float(close.iloc[i])
        sl = synthetic_stop(entry, float(a_synth), direction, SYNTHETIC_ATR_MULT)
        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=sl,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="ema_cross_small_10_21", synthetic_stop=True,
        ))

    return signals
