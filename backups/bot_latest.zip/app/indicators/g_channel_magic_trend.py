"""Port of "G-Channel Trend Detection with magic filter" (source:
______________________________G_Channel_Trend_Detection_with_magic.txt,
Pine v4). Translated 1:1 -- v4/v5 `ta.*` semantics are equivalent for
everything used here (`max`/`min`/`avg`/`barssince`/`cci`/`sma`/`ema`/
`rma`/`tr` all behave the same, just called positionally in v4).

Two signal systems live in this file, gating each other via the source's
own `isFilter` (default True):

  1. G-Channel trend detection: a Gann-style recursive channel
     `a[i] = max(src[i], a[i-1]) - (a[i-1]-b[i-1])/length`,
     `b[i] = min(src[i], b[i-1]) + (a[i-1]-b[i-1])/length`
     (length=100, src=close). `crossup`/`crossdn` and a `bullish` state
     (`barssince(crossdn) <= barssince(crossup)`) are ported literally,
     including Pine's na-propagation: `bullish` is undefined until BOTH
     a crossup and a crossdn have happened at least once in history
     (`barssince` of an event that hasn't happened yet is `na`, and any
     comparison against `na` is itself `na`).

     The ONLY discrete buy/sell markers the source actually plots are
     triggered by a `bullish` FLIP (`not bullish and bullish[1]` for
     Sell, `bullish and not bullish[1]` for Buy), each additionally
     gated by the Magic Trend CCI sign when `isFilter` is on. This is
     ported as `_g_channel_signals()` / label "g_channel".

  2. "Magic Trend": a CCI(20)+ATR(5, SMA-smoothed) ratchet line
     (`MagicTrend`) -- `upT = low - ATR*coeff`, `downT = high +
     ATR*coeff` (coeff=1), the ratchet sides with `upT` while
     `cci(close,20) >= 0` and `downT` otherwise, each side only allowed
     to move in the direction that tightens the stop (a trailing-stop
     family, same spirit as ATR trailing-stop indicators elsewhere in
     this collection). The source itself never plots a discrete
     buy/sell event for Magic Trend on its own (no `alertcondition`, no
     `plotshape` keyed off the ratchet or off `MagicTrend` crossing
     price) -- its only role in the source is (a) the colored trend
     line and (b) the CCI-sign gate used by the G-Channel signal above.
     Since the task calls for both as separate, gate-able signals, we
     add our own reasonable standalone definition here, clearly an
     INTERPRETATION rather than a literal port (the source has no
     alertcondition to match byte-exact): a Magic Trend "flip" is
     defined the way this style of trailing-stop indicator is
     conventionally traded elsewhere -- price crossing over/under the
     `MagicTrend` line -- optionally gated by the G-Channel `bullish`
     state (long requires `bullish is True`, short requires `bullish is
     False`) when `isFilter` is on, the reciprocal of gate (1). Ported
     as `_magic_trend_signals()` / label "magic_trend".

`generate_signals()` returns the union of both, each carrying its own
`label`, sorted by `trigger_index`.

Not ported: the EMA(100)+ATR(25) "Support"/"Resistance" touch labels at
the bottom of the file (`support_hit`/`resistance_hit` `xcross`
plotshapes) -- these fire on every single bar the wick reaches a slowly
drifting band (not a discrete entry event), and have no alertcondition;
pure visualization.
"""
from __future__ import annotations

import math

import numpy as np
import pandas as pd

from .common import Signal, cci, sma, true_range, atr, synthetic_stop, SYNTHETIC_ATR_LEN

G_LENGTH = 100
CCI_PERIOD = 20
ATR_COEFF = 1
ATR_PERIOD = 5
IS_FILTER = True


def _g_channel_bullish(close: pd.Series) -> pd.Series:
    n = len(close)
    src = close.to_numpy()
    a = 0.0
    b = 0.0
    a_arr = [0.0] * n
    b_arr = [0.0] * n

    last_crossup = None
    last_crossdn = None
    bullish = [None] * n

    prev_a, prev_b = 0.0, 0.0
    prev_close = None
    for i in range(n):
        a = max(src[i], prev_a) - (prev_a - prev_b) / G_LENGTH
        b = min(src[i], prev_b) + (prev_a - prev_b) / G_LENGTH
        a_arr[i] = a
        b_arr[i] = b

        if prev_close is not None:
            crossup = prev_b < prev_close and b > src[i]
            crossdn = prev_a < prev_close and a > src[i]
            if crossup:
                last_crossup = i
            if crossdn:
                last_crossdn = i

        if last_crossdn is None or last_crossup is None:
            bullish[i] = None
        else:
            bullish[i] = (i - last_crossdn) <= (i - last_crossup)

        prev_a, prev_b, prev_close = a, b, src[i]

    return pd.Series(bullish, index=close.index, dtype=object)


def _g_channel_signals(df: pd.DataFrame) -> list[Signal]:
    close = df["close"]
    bullish = _g_channel_bullish(close)
    cci_val = cci(close, CCI_PERIOD)
    atr_series = atr(df, SYNTHETIC_ATR_LEN)

    signals: list[Signal] = []
    for i in range(1, len(df)):
        cur, prev = bullish.iloc[i], bullish.iloc[i - 1]
        if cur is None or prev is None:
            continue
        buy = (cur is True) and (prev is False)
        sell = (cur is False) and (prev is True)
        if not (buy or sell):
            continue

        c = cci_val.iloc[i]
        if pd.isna(c):
            continue
        if IS_FILTER:
            if buy and not (c >= 0):
                continue
            if sell and not (c < 0):
                continue

        atr_v = atr_series.iloc[i]
        if pd.isna(atr_v):
            continue

        entry = float(close.iloc[i])
        direction = "long" if buy else "short"
        stop = synthetic_stop(entry, float(atr_v), direction)
        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=stop,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="g_channel", synthetic_stop=True,
        ))
    return signals


def _magic_trend_line(df: pd.DataFrame) -> pd.Series:
    close = df["close"]
    high, low = df["high"], df["low"]
    n = len(df)

    atr_sma = sma(true_range(df), ATR_PERIOD).to_numpy()
    cci_val = cci(close, CCI_PERIOD).to_numpy()
    up_t = low.to_numpy() - atr_sma * ATR_COEFF
    down_t = high.to_numpy() + atr_sma * ATR_COEFF

    magic = np.zeros(n)
    prev = 0.0
    for i in range(n):
        if math.isnan(cci_val[i]) or math.isnan(atr_sma[i]):
            magic[i] = prev
            continue
        if cci_val[i] >= 0:
            magic[i] = prev if up_t[i] < prev else up_t[i]
        else:
            magic[i] = prev if down_t[i] > prev else down_t[i]
        prev = magic[i]

    return pd.Series(magic, index=df.index)


def _magic_trend_signals(df: pd.DataFrame) -> list[Signal]:
    """Our own interpretation of a standalone "Magic Trend" buy/sell
    signal (price crossing the CCI+ATR ratchet line) -- see module
    docstring. Not a literal alertcondition in the source."""
    close = df["close"]
    bullish = _g_channel_bullish(close)
    magic_trend = _magic_trend_line(df)
    atr_series = atr(df, SYNTHETIC_ATR_LEN)

    cross_up = (close.shift(1) < magic_trend.shift(1)) & (close > magic_trend)
    cross_dn = (close.shift(1) > magic_trend.shift(1)) & (close < magic_trend)

    signals: list[Signal] = []
    for i in range(1, len(df)):
        up = bool(cross_up.iloc[i]) if not pd.isna(cross_up.iloc[i]) else False
        dn = bool(cross_dn.iloc[i]) if not pd.isna(cross_dn.iloc[i]) else False
        if not (up or dn):
            continue

        if IS_FILTER:
            b = bullish.iloc[i]
            if up and b is not True:
                continue
            if dn and b is not False:
                continue

        atr_v = atr_series.iloc[i]
        if pd.isna(atr_v):
            continue

        entry = float(close.iloc[i])
        direction = "long" if up else "short"
        stop = synthetic_stop(entry, float(atr_v), direction)
        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=stop,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="magic_trend", synthetic_stop=True,
        ))
    return signals


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    signals = _g_channel_signals(df) + _magic_trend_signals(df)
    signals.sort(key=lambda s: s.trigger_index)
    return signals
