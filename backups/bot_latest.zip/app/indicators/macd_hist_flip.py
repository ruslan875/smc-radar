"""Port of the MACD trend read from the "INFO BOX" label in "9 indicators
in 1 and more" (source lines 263-267): `ta.macd(close, 12, 26, 9)`, with
the source just displaying static text ("Bullish"/"Bearish") based on the
current histogram sign -- no cross event, no alertcondition. The signal
here is our own reasonable reading of that: fire on the bar the histogram
crosses zero (MACD line crossing its signal line), long on a bullish
cross, short on a bearish one -- the standard MACD-histogram trading
rule, not something specific to this file's own logic.

No native stop-loss defined -- synthetic ATR(14) stop per the batch
convention.
"""
from __future__ import annotations

import pandas as pd

from .common import Signal, atr, ema, synthetic_stop, SYNTHETIC_ATR_LEN, SYNTHETIC_ATR_MULT

FAST_LENGTH = 12
SLOW_LENGTH = 26
SIGNAL_LENGTH = 9


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    close = df["close"]
    macd_line = ema(close, FAST_LENGTH) - ema(close, SLOW_LENGTH)
    signal_line = ema(macd_line, SIGNAL_LENGTH)
    hist = macd_line - signal_line

    prev_hist = hist.shift(1)
    cross_up = (prev_hist <= 0) & (hist > 0)
    cross_down = (prev_hist >= 0) & (hist < 0)

    atr_synth = atr(df, SYNTHETIC_ATR_LEN)

    signals: list[Signal] = []
    for i in range(len(df)):
        if bool(cross_up.iloc[i]):
            direction = "long"
        elif bool(cross_down.iloc[i]):
            direction = "short"
        else:
            continue

        a_synth = atr_synth.iloc[i]
        if pd.isna(a_synth):
            continue

        entry = float(close.iloc[i])
        sl = synthetic_stop(entry, float(a_synth), direction, SYNTHETIC_ATR_MULT)
        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=sl,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="macd_hist_flip", synthetic_stop=True,
        ))

    return signals
