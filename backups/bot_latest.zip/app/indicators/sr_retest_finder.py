"""Port of the "Support/Resistance Re-test Finder with Range and Liq
lines" main pivot-based re-test state machine (source lines ~105-290 of
SupportResistance_Retest_Finder_with_Range_and_Liq_lines.txt).

This source file bundles THREE independent systems; the other two are
NOT ported here:
  - The range-detection + calcSLTP block is already ported separately as
    `app/indicators/sr_range_module.py` -- don't redo it.
  - The pivot-slope trend-line drawer at the bottom (`res_lines`/
    `sup_lines` construction) is pure visualization with no
    alertcondition/plotshape tied to it -- skipped entirely.

Interpretation / direction mapping (the Pine source labels this system's
output as "New Support Re-Test X" / "New Resistance Re-Test X"
plotshapes, never as long/short -- direction is our own reasonable
reading, documented here since the original doesn't commit to one):

  1. A pivot high (`leftBars`/`rightBars` wick pivot, default 20/20) is
     tracked ("firstPhaseHigh") until a later bar's LOW moves entirely
     above it -- i.e. price has broken out above the old high, so that
     level is now acting as potential SUPPORT ("secondPhaseHigh").
  2. If, while tracked as support, a bar's low dips back down to touch
     that level (low <= price) but closes back above it on a bullish
     candle (close > price and close > open), that is a confirmed
     "successful support re-test" -- `newTestedSupport`. We map this to
     a LONG entry (price held support and is resuming the up-move).
  3. Symmetrically, a pivot low that gets broken to the downside becomes
     a potential resistance level ("secondPhaseLow"); a later bar that
     wicks up to touch it (high >= price) but closes back below on a
     bearish candle (close < price and close < open) is
     `newTestedResistance`, mapped to a SHORT entry.
  4. Levels expire out of the first/second-phase tracking arrays after
     1000 bars of no interaction (hard-coded in the Pine source as
     `bar_index - index > 1000`, not a user input) -- ported verbatim.

This mapping matches the ONLY two conditions the source itself actually
plots (`newTestedSupport`/`newTestedResistance` via `plotshape`) -- there
is no ambiguity about which two booleans constitute "the signal", only
about which side is long vs short, which is what we're documenting here.

Not ported: the `flipManager` bookkeeping that tracks further
breaks/reclaims of an *already confirmed* re-test line
(`supportBrokeDownside`/`supportBrokeUpside`/`resistanceBrokeDownside`/
`resistanceBrokeUpside`) and the line-deletion/coloring rules
(`flipsUntilDeletion`, `ageUntilDeletion`, `definitionOfDelete`). None of
these ever feed a plotshape/alertcondition in the source -- they're
purely for the visual line objects and their color/lifecycle -- so
there's no tradeable event being dropped by skipping them.

`levelMethod="Body"` (the alternative to the default "Wick") is not
ported; only the default Wick-based pivot source (high/low) is
implemented. `retestLogic` (default False, only flips plotshape
colors/locations) is not ported since it has no bearing on which bars
fire.
"""
from __future__ import annotations

import math

import pandas as pd

from .common import Signal, pivothigh, pivotlow, atr, synthetic_stop, SYNTHETIC_ATR_LEN

LEFT_BARS = 20
RIGHT_BARS = 20
STALE_BARS = 1000  # hard-coded "bar_index - index > 1000" eviction in source


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    high, low, close, open_ = df["high"], df["low"], df["close"], df["open"]
    n = len(df)

    ph = pivothigh(high, LEFT_BARS, RIGHT_BARS)
    pl = pivotlow(low, LEFT_BARS, RIGHT_BARS)
    atr_series = atr(df, SYNTHETIC_ATR_LEN)

    first_phase_high: list[tuple[float, int]] = []
    first_phase_low: list[tuple[float, int]] = []
    second_phase_high: list[tuple[float, int]] = []
    second_phase_low: list[tuple[float, int]] = []

    signals: list[Signal] = []

    for i in range(n):
        if i < RIGHT_BARS:
            continue

        ph_v, pl_v = ph.iloc[i], pl.iloc[i]
        if not math.isnan(ph_v):
            first_phase_high.append((float(ph_v), i - RIGHT_BARS))
        if not math.isnan(pl_v):
            first_phase_low.append((float(pl_v), i - RIGHT_BARS))

        c, o, h, l = float(close.iloc[i]), float(open_.iloc[i]), float(high.iloc[i]), float(low.iloc[i])

        # -- second-phase support re-test check --
        new_tested_support = False
        kept = []
        for price, idx in second_phase_high:
            if l <= price and c > price and c > o:
                new_tested_support = True  # (line creation skipped -- visualization only)
            elif (i - idx) > STALE_BARS or c < price:
                pass  # evicted
            else:
                kept.append((price, idx))
        second_phase_high = kept

        # -- second-phase resistance re-test check --
        new_tested_resistance = False
        kept = []
        for price, idx in second_phase_low:
            if h >= price and c < price and c < o:
                new_tested_resistance = True
            elif (i - idx) > STALE_BARS or c > price:
                pass
            else:
                kept.append((price, idx))
        second_phase_low = kept

        # -- promote first-phase pivots into second-phase once broken through --
        kept = []
        for price, idx in first_phase_high:
            if l > price:
                second_phase_high.append((price, idx))
            elif (i - idx) > STALE_BARS:
                pass
            else:
                kept.append((price, idx))
        first_phase_high = kept

        kept = []
        for price, idx in first_phase_low:
            if h < price:
                second_phase_low.append((price, idx))
            elif (i - idx) > STALE_BARS:
                pass
            else:
                kept.append((price, idx))
        first_phase_low = kept

        if not (new_tested_support or new_tested_resistance):
            continue

        atr_v = atr_series.iloc[i]
        if pd.isna(atr_v):
            continue

        if new_tested_support:
            direction = "long"
            stop = synthetic_stop(c, float(atr_v), direction)
            signals.append(Signal(
                direction=direction, entry=c, stop_loss=stop,
                trigger_index=i, trigger_time=df["open_time"].iloc[i],
                take_profits=None, label="sr_retest_finder", synthetic_stop=True,
            ))
        if new_tested_resistance:
            direction = "short"
            stop = synthetic_stop(c, float(atr_v), direction)
            signals.append(Signal(
                direction=direction, entry=c, stop_loss=stop,
                trigger_index=i, trigger_time=df["open_time"].iloc[i],
                take_profits=None, label="sr_retest_finder", synthetic_stop=True,
            ))

    return signals
