"""Port of "Twin Range Signal with filter" (source:
Twin_Range_with_filter__________________________________.txt, © colinmck).

Two systems, both ported (they gate each other exactly as in the
source):
  1. Core range-filter long/short signal (dual smoothed-average-range
     periods 27 and 55).
  2. Gaussian-filter trend overlay, used as an optional gate (`isFilter`,
     default True) on the core signal.

Core signal:
  - `smoothrng(x, t, m) = ema(ema(|x - x[1]|, t), t*2-1) * m` computed
    for (period=27, mult=1.6) and (period=55, mult=2.0); `smrng` is their
    average.
  - `rngfilt(x, r)`: a recursive range filter -- `filt` only moves when
    price closes beyond `filt[1] +/- r`, otherwise it steps toward price
    by at most `r`. Implemented with a sequential loop (self-referential
    on its own previous value, same family of filter as
    `sr_range_module.py`'s `rngfilt`, but WITHOUT that file's extra
    "jump" branch -- this source's version is the simpler two-branch
    form, ported literally).
  - `upward`/`downward` are running streak counters of consecutive bars
    `filt` moved up/down (reset to 0 the instant it reverses).
  - `longCond`/`shortCond` require `source` on the correct side of
    `filt`, the relevant streak counter > 0, AND `source != source[1]`
    (the Pine expression is an exhaustive OR over `source > source[1]`
    and `source < source[1]`, which together exclude only an exact tie --
    ported literally rather than simplified away, since real tick data
    can repeat a close price exactly).
  - `long`/`short` only fire on the bar the running `CondIni` state
    (`+1` while `longCond` most recently true, `-1` while `shortCond`
    most recently true) FLIPS, i.e. a fresh reversal, not every bar the
    raw condition holds.

Gaussian filter gate (`isFilter`, default True):
  - `smoothed` = a length-50/sigma-10 causal Gaussian-weighted moving
    average of `close` (weights `exp(-0.5*((i-length/2)/sigma)^2)`,
    normalized to sum to 1, applied to the current bar and the previous
    `length-1` bars -- no lookahead).
  - The source's final plotshape gating uses `smoothed` directly (NOT
    the separately-tracked `trend` boolean state, which only drives
    label/candle-coloring cosmetics): `Long shown = isFilter ? (close >
    smoothed and long) : long`; `Short shown = isFilter ? (close <=
    smoothed and short) : short`. Ported exactly as that -- the `trend`/
    `condition_up`/`condition_dn`/Enter-Exit-label machinery is
    visualization-only and skipped.
"""
from __future__ import annotations

import math

import numpy as np
import pandas as pd

from .common import Signal, ema, atr, synthetic_stop, SYNTHETIC_ATR_LEN

PER1, MULT1 = 27, 1.6
PER2, MULT2 = 55, 2.0

IS_FILTER = True
GAUSS_LENGTH = 50
GAUSS_SIGMA = 10


def _smoothrng(x: pd.Series, t: int, m: float) -> pd.Series:
    wper = t * 2 - 1
    avrng = ema((x - x.shift(1)).abs(), t)
    return ema(avrng, wper) * m


def _gaussian_weights(length: int, sigma: float) -> np.ndarray:
    i = np.arange(length, dtype=float)
    w = np.exp(-0.5 * ((i - length / 2) / sigma) ** 2) / (sigma * math.sqrt(2 * math.pi))
    return w / w.sum()


def _gaussian_filter(close: pd.Series, length: int, sigma: float) -> pd.Series:
    weights = _gaussian_weights(length, sigma)  # weights[0] = current bar, weights[k] = k bars back

    def _f(window: np.ndarray) -> float:
        rev = window[::-1]  # rev[0] = current bar (rightmost of window)
        return float(np.dot(rev, weights))

    return close.rolling(length, min_periods=length).apply(_f, raw=True)


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    close = df["close"]
    n = len(close)

    smrng1 = _smoothrng(close, PER1, MULT1)
    smrng2 = _smoothrng(close, PER2, MULT2)
    smrng = (smrng1 + smrng2) / 2

    src = close.to_numpy()
    r_arr = smrng.to_numpy()
    smoothed = _gaussian_filter(close, GAUSS_LENGTH, GAUSS_SIGMA).to_numpy()

    filt = np.full(n, np.nan)
    upward = np.zeros(n)
    downward = np.zeros(n)
    cond_ini = np.zeros(n, dtype=int)
    long_flip = np.zeros(n, dtype=bool)
    short_flip = np.zeros(n, dtype=bool)

    prev_filt = 0.0
    for i in range(n):
        x = src[i]
        r = r_arr[i]
        if math.isnan(r):
            filt[i] = prev_filt
            upward[i] = upward[i - 1] if i > 0 else 0
            downward[i] = downward[i - 1] if i > 0 else 0
            cond_ini[i] = cond_ini[i - 1] if i > 0 else 0
            continue

        if x > prev_filt:
            f = prev_filt if (x - r) < prev_filt else (x - r)
        else:
            f = prev_filt if (x + r) > prev_filt else (x + r)
        filt[i] = f

        if f > prev_filt:
            upward[i] = (upward[i - 1] + 1) if i > 0 else 1
            downward[i] = 0
        elif f < prev_filt:
            downward[i] = (downward[i - 1] + 1) if i > 0 else 1
            upward[i] = 0
        else:
            upward[i] = upward[i - 1] if i > 0 else 0
            downward[i] = downward[i - 1] if i > 0 else 0

        prev_src = src[i - 1] if i > 0 else np.nan
        not_tied = (not math.isnan(prev_src)) and x != prev_src
        long_cond = (x > f) and (upward[i] > 0) and not_tied
        short_cond = (x < f) and (downward[i] > 0) and not_tied

        prev_cond_ini = cond_ini[i - 1] if i > 0 else 0
        if long_cond:
            cond_ini[i] = 1
        elif short_cond:
            cond_ini[i] = -1
        else:
            cond_ini[i] = prev_cond_ini

        long_flip[i] = long_cond and prev_cond_ini == -1
        short_flip[i] = short_cond and prev_cond_ini == 1

        prev_filt = f

    if IS_FILTER:
        long_signal = long_flip & (src > smoothed)
        short_signal = short_flip & (src <= smoothed)
    else:
        long_signal = long_flip
        short_signal = short_flip

    atr_series = atr(df, SYNTHETIC_ATR_LEN)
    signals: list[Signal] = []
    valid_from = max(PER2 * 2, GAUSS_LENGTH) + 2

    for i in range(valid_from, n):
        up = bool(long_signal[i])
        dn = bool(short_signal[i])
        if not (up or dn):
            continue
        atr_v = atr_series.iloc[i]
        if pd.isna(atr_v):
            continue

        entry = float(close.iloc[i])
        direction = "long" if up else "short"
        stop = synthetic_stop(entry, float(atr_v), direction)
        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=stop,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="twin_range_signal", synthetic_stop=True,
        ))

    return signals
