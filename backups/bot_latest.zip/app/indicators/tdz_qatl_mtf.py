"""Port of Module 3 ("QATL MTF" -- Multi-Timeframe Adaptive Trend Line)
from TDZPullback.txt (source lines ~221-580). See tdz_pullback.py's
module docstring for how this relates to the other three TDZ sub-modules.

This is the most involved sub-module: on a higher timeframe (auto-picked
from the chart's own timeframe, e.g. 5m/15m -> 1h, 1h/4h -> 1D, ...), it
blends three adaptive moving averages (ALMA, Zero-Lag EMA, KAMA) weighted
by a Kaufman Efficiency Ratio into one "core line", wraps it in an
ATR-based adaptive noise channel, and confirms trend state with
ADX/DI + momentum + slope, using a hysteresis state machine so the trend
label doesn't flip on every wiggle. The entry signal is the trend-state
flip itself:

    bullConditionTF = tfClose > noiseUpperTF and momSmoothTF > 0
                       and (diPlusTF > diMinusTF or adxValTF < 15) and slopeSmoothTF > 0
    bearConditionTF = tfClose < noiseLowerTF and momSmoothTF < 0
                       and (diMinusTF > diPlusTF or adxValTF < 15) and slopeSmoothTF < 0
    // hysteresis: trendStateTF only changes on a qualifying condition,
    // or reverts to neutral (0) once price re-enters the noise channel
    // *and* momentum/slope have already flipped against the open trend.
    trendBullTF = trendStateTF == 1 and trendStateTF[1] != 1   -> long
    trendBearTF = trendStateTF == -1 and trendStateTF[1] != -1 -> short

Multi-timeframe fidelity note (read before trusting this module's exact
timing): the source fetches the HTF via `request.security(..., HTF, ...,
lookahead=barmerge.lookahead_on)` and then manually shifts the result by
one more bar (`tfHighRaw[1]`) specifically to avoid TradingView's
well-known `lookahead_on` intrabar repaint risk on the currently-forming
HTF bar. There is no live multi-timeframe feed in this backtest sandbox,
so the HTF series is instead built by resampling the *same* OHLC history
this module is given (causal: each lower-timeframe bar is only ever
mapped to the most recently fully-CLOSED higher-timeframe bar as of that
bar's time, via `pd.merge_asof(..., direction="backward")` on the HTF
bar's close time). This is guaranteed no-lookahead, which is the hard
requirement here, but it does not reproduce Pine's *extra* one-HTF-bar
safety margin byte-for-byte -- treat this module's exact trigger bar as
approximate-but-causal, not a byte-for-byte match to the live indicator.
The auto-timeframe-selection table itself is also simplified to the
common intraday cases (this bot only ever backtests intraday/day bars):
1-5min -> 1h, 15-30min -> 4h, 1-2h -> 1D, 4h -> 1D, >=1D -> 7D (a fixed
weekly proxy standing in for Pine's calendar "W"/"M" escalation, which
needs calendar-aware resampling this module doesn't attempt).

Not ported: fractal HH/LL structure tracking (dashboard-only, doesn't
gate the signal), the "current TF" comparison line, and the info panel.
"""
from __future__ import annotations

import math

import numpy as np
import pandas as pd

from .common import (
    Signal, ema, sma, rma, true_range, atr,
    synthetic_stop, SYNTHETIC_ATR_LEN, SYNTHETIC_ATR_MULT,
)

CORE_LENGTH = 21
ALMA_OFFSET = 0.85
ALMA_SIGMA = 6.0
ZLEMA_LENGTH = 14
KAMA_LEN = 10
KAMA_FAST = 2
KAMA_SLOW = 30

NOISE_PERIOD = 14
NOISE_MULT = 1.618
ADAPT_NOISE = True
NOISE_SMOOTH = 5

ADX_LEN = 14
ADX_THRESH = 25.0
MOM_LEN = 14
SMOOTH_SLOPE = 3


def _auto_htf_freq(df: pd.DataFrame) -> str:
    deltas = df["open_time"].diff().dropna()
    if deltas.empty:
        return "4h"
    base_minutes = deltas.dt.total_seconds().median() / 60.0
    if base_minutes <= 5:
        return "1h"
    if base_minutes <= 30:
        return "4h"
    if base_minutes <= 240:
        return "1D"
    return "7D"


def _alma(series: pd.Series, length: int, offset: float, sigma: float) -> pd.Series:
    m = offset * (length - 1)
    s = length / sigma
    idx_back = np.arange(length - 1, -1, -1, dtype=float)  # chrono k=0..len-1 -> i=len-1-k bars back
    w = np.exp(-((idx_back - m) ** 2) / (2 * s * s))
    wsum = w.sum()
    return series.rolling(length, min_periods=length).apply(lambda x: np.dot(x, w) / wsum, raw=True)


def _zlema(series: pd.Series, length: int) -> pd.Series:
    lag = round((length - 1) / 2)
    ema_data = series + (series - series.shift(lag))
    return ema(ema_data, length)


def _kama(series: pd.Series, length: int, fast: int, slow: int) -> pd.Series:
    diffs = series.diff().abs()
    volatility = diffs.rolling(length, min_periods=length).sum()
    change = (series - series.shift(length)).abs()
    er = (change / volatility.replace(0, np.nan)).fillna(0.0)
    fast_sc = 2.0 / (fast + 1)
    slow_sc = 2.0 / (slow + 1)
    sc = (er * (fast_sc - slow_sc) + slow_sc) ** 2

    vals = series.to_numpy(dtype=float)
    sc_vals = sc.to_numpy(dtype=float)
    n = len(vals)
    out = np.full(n, np.nan)
    prev = 0.0  # nz(kama[1]) treats the undefined seed as 0.0
    have_prev = False
    for i in range(n):
        if np.isnan(sc_vals[i]) or np.isnan(vals[i]):
            continue
        base = prev if have_prev else 0.0
        cur = base + sc_vals[i] * (vals[i] - base)
        out[i] = cur
        prev = cur
        have_prev = True
    return pd.Series(out, index=series.index)


def _adx_di(df: pd.DataFrame, length: int) -> tuple[pd.Series, pd.Series, pd.Series]:
    up = df["high"].diff()
    down = -df["low"].diff()
    plus_dm = pd.Series(np.where((up > down) & (up > 0), up, 0.0), index=df.index)
    minus_dm = pd.Series(np.where((down > up) & (down > 0), down, 0.0), index=df.index)

    tr_rma = rma(true_range(df), length)
    plus = (100 * rma(plus_dm, length) / tr_rma).ffill()
    minus = (100 * rma(minus_dm, length) / tr_rma).ffill()
    total = (plus + minus).replace(0, 1.0)
    dx = (plus - minus).abs() / total * 100
    adx = rma(dx, length)
    return adx, plus, minus


def _compute_htf_trend(htf: pd.DataFrame) -> pd.DataFrame:
    close = htf["close"]

    alma_core = _alma(close, CORE_LENGTH, ALMA_OFFSET, ALMA_SIGMA)
    zlema_core = _zlema(close, ZLEMA_LENGTH)
    kama_core = _kama(close, KAMA_LEN, KAMA_FAST, KAMA_SLOW)

    diffs = close.diff().abs()
    volatility = diffs.rolling(KAMA_LEN, min_periods=KAMA_LEN).sum()
    change = (close - close.shift(KAMA_LEN)).abs()
    er = (change / volatility.replace(0, np.nan)).fillna(0.0)

    w_zlema = er ** 2
    w_kama = (1 - er) ** 2
    w_alma = (1.0 - w_zlema - w_kama).clip(lower=0.0)
    norm_w = (w_zlema + w_kama + w_alma).replace(0, 1.0)
    core_line = (zlema_core * w_zlema + kama_core * w_kama + alma_core * w_alma) / norm_w

    base_atr = atr(htf, NOISE_PERIOD)
    atr_hist = base_atr.rolling(NOISE_PERIOD * 2, min_periods=NOISE_PERIOD * 2).median()
    atr_ratio = (base_atr / atr_hist.replace(0, np.nan)).fillna(1.0)
    if ADAPT_NOISE:
        adaptive_mult = NOISE_MULT * (0.5 + 0.5 * atr_ratio.clip(upper=3.0))
    else:
        adaptive_mult = pd.Series(NOISE_MULT, index=htf.index)

    noise_upper = ema(core_line + adaptive_mult * base_atr, NOISE_SMOOTH)
    noise_lower = ema(core_line - adaptive_mult * base_atr, NOISE_SMOOTH)

    adx_val, di_plus, di_minus = _adx_di(htf, ADX_LEN)

    mom_raw = close - close.shift(MOM_LEN)
    mom_smooth = ema(mom_raw, SMOOTH_SLOPE)
    slope = core_line - core_line.shift(SMOOTH_SLOPE)
    slope_smooth = ema(slope, SMOOTH_SLOPE)

    bull_cond = (close > noise_upper) & (mom_smooth > 0) & ((di_plus > di_minus) | (adx_val < 15)) & (slope_smooth > 0)
    bear_cond = (close < noise_lower) & (mom_smooth < 0) & ((di_minus > di_plus) | (adx_val < 15)) & (slope_smooth < 0)
    in_channel = (close < noise_upper) & (close > noise_lower)

    n = len(htf)
    trend_state = np.zeros(n, dtype=int)
    state = 0
    bc = bull_cond.to_numpy()
    brc = bear_cond.to_numpy()
    inc = in_channel.to_numpy()
    cl = core_line.to_numpy()
    cv = close.to_numpy()
    ss = slope_smooth.to_numpy()
    ms = mom_smooth.to_numpy()

    for i in range(n):
        if np.isnan(cl[i]) or np.isnan(cv[i]):
            trend_state[i] = state
            continue
        if bc[i] and state != 1:
            state = 1
        elif brc[i] and state != -1:
            state = -1
        elif inc[i]:
            if state == 1 and cv[i] < cl[i] and not np.isnan(ss[i]) and ss[i] < 0 and not np.isnan(ms[i]) and ms[i] < 0:
                state = 0
            elif state == -1 and cv[i] > cl[i] and not np.isnan(ss[i]) and ss[i] > 0 and not np.isnan(ms[i]) and ms[i] > 0:
                state = 0
        trend_state[i] = state

    out = htf.copy()
    out["trend_state"] = trend_state
    prev_state = out["trend_state"].shift(1).fillna(0).astype(int)
    out["bull_flip"] = (out["trend_state"] == 1) & (prev_state != 1)
    out["bear_flip"] = (out["trend_state"] == -1) & (prev_state != -1)
    return out


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    n = len(df)
    if n < 50:
        return []

    freq = _auto_htf_freq(df)
    htf = (
        df.resample(freq, on="open_time", label="left", closed="left")
        .agg(open=("open", "first"), high=("high", "max"), low=("low", "min"), close=("close", "last"))
        .dropna(subset=["close"])
        .reset_index()
        .rename(columns={"open_time": "bar_start"})
    )
    if len(htf) < 30:
        return []  # not enough HTF history to warm up the core line / noise channel

    offset = pd.tseries.frequencies.to_offset(freq)
    htf["bar_end"] = htf["bar_start"] + offset

    htf = _compute_htf_trend(htf)

    merged = pd.merge_asof(
        df[["open_time"]], htf[["bar_end", "bull_flip", "bear_flip"]],
        left_on="open_time", right_on="bar_end", direction="backward",
    )
    new_ref = merged["bar_end"] != merged["bar_end"].shift(1)
    signal_bull = merged["bull_flip"].fillna(False) & new_ref
    signal_bear = merged["bear_flip"].fillna(False) & new_ref

    close = df["close"]
    synth_atr = atr(df, SYNTHETIC_ATR_LEN)

    signals: list[Signal] = []
    for i in range(n):
        is_long = bool(signal_bull.iloc[i])
        is_short = bool(signal_bear.iloc[i])
        if not (is_long or is_short):
            continue
        synth = synth_atr.iloc[i]
        if pd.isna(synth):
            continue

        entry = float(close.iloc[i])
        direction = "long" if is_long else "short"
        stop = synthetic_stop(entry, float(synth), direction, SYNTHETIC_ATR_MULT)

        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=stop,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="tdz_qatl_mtf", synthetic_stop=True,
        ))

    return signals
