"""Port of the "Buy Signal" / "Sell Signal" alertconditions from
"MoPeDa.net" v2.0 (source: MoPeDa.net.txt, lines 860-916, 1140-1141) -- a
large combo indicator (HTF candles, imbalances, volume profile, initial
balance, ADX-adaptive Bollinger zones, wick signals, divergences, S/R
levels, dashboard). Everything except the price-action zone/signal/
divergence logic is pure visualization (volume profile boxes, HTF candle
overlay, S/R lines, dashboard table, watermark) and was not ported --
those don't gate any `alertcondition` in the source.

This module is the CANONICAL zone computation (`compute_zones`), reused by
`mopeda_wick_signal.py` for its own, separate signal built on the same
zones -- same "shared helper, canonical file" pattern as
`two_pole_filter_signal.py`.

Zone construction (source lines 798-889): an ADX-adaptive Bollinger Band.
    adx           = ta.dmi(20, 30)[2]              // ADX line only
    bbBasis       = ta.sma(close, 24)
    bbDev         = ta.stdev(close, 24)
    adxMultiplier = 1 + (adx/100) * 1.0             // adxInfluence
    bbDevAdjusted = 1.4 * bbDev * adxMultiplier     // bbMult
    bbUpper/Lower = bbBasis +/- bbDevAdjusted
    bbUpperSmooth = ta.sma(bbUpper, 50)             // smoothLength
    bbLowerSmooth = ta.sma(bbLower, 50)
    bbRangeSmooth = bbUpperSmooth - bbLowerSmooth
    offsetDistance = bbRangeSmooth * 1.0            // zoneOffset
    topZoneBottom = bbUpperSmooth + offsetDistance
    topZoneTop    = topZoneBottom + bbRangeSmooth * 1.0   // zoneExpansion
    bottomZoneTop    = bbLowerSmooth - offsetDistance
    bottomZoneBottom = bottomZoneTop - bbRangeSmooth * 1.0

The signal itself fires once, on the bar price *enters* a zone (not every
bar it stays inside), with a 20-bar cooldown per side (`signalCooldown`):

    enterBottomZone = priceInBottomZone and not priceInBottomZone[1]
                       and (bar_index - lastBuySignalBar >= 20)   -> BUY (long)
    enterTopZone    = priceInTopZone and not priceInTopZone[1]
                       and (bar_index - lastSellSignalBar >= 20)  -> SELL (short)

Entry = close of the signal bar (market), no native stop/target defined by
the source (this is a pure alert indicator, no strategy.entry/exit
anywhere in the file) -- synthetic ATR(14) stop + default 1R/2R/3R ladder
per the batch convention. The source's own diPlus/diMinus trend read
(bullishTrend/bearishTrend) only colors the central line for display and
does not gate this signal, so it's not replicated here.
"""
from __future__ import annotations

import pandas as pd

from .common import Signal, atr, dmi_adx, sma, stdev, synthetic_stop, \
    SYNTHETIC_ATR_LEN, SYNTHETIC_ATR_MULT

BB_LENGTH = 24
BB_MULT = 1.4
ADX_LENGTH = 20
ADX_SMOOTH = 30
ADX_INFLUENCE = 1.0
SMOOTH_LENGTH = 50
ZONE_OFFSET = 1.0
ZONE_EXPANSION = 1.0
SIGNAL_COOLDOWN = 20


def compute_zones(df: pd.DataFrame) -> dict[str, pd.Series]:
    close = df["close"]
    adx = dmi_adx(df, ADX_LENGTH, ADX_SMOOTH)
    adx_normalized = adx / 100.0

    bb_basis = sma(close, BB_LENGTH)
    bb_dev = stdev(close, BB_LENGTH)
    adx_multiplier = 1 + adx_normalized * ADX_INFLUENCE
    bb_dev_adjusted = BB_MULT * bb_dev * adx_multiplier
    bb_upper = bb_basis + bb_dev_adjusted
    bb_lower = bb_basis - bb_dev_adjusted

    bb_upper_smooth = sma(bb_upper, SMOOTH_LENGTH)
    bb_lower_smooth = sma(bb_lower, SMOOTH_LENGTH)
    bb_range_smooth = bb_upper_smooth - bb_lower_smooth
    offset_distance = bb_range_smooth * ZONE_OFFSET

    top_zone_bottom = bb_upper_smooth + offset_distance
    top_zone_top = top_zone_bottom + bb_range_smooth * ZONE_EXPANSION
    bottom_zone_top = bb_lower_smooth - offset_distance
    bottom_zone_bottom = bottom_zone_top - bb_range_smooth * ZONE_EXPANSION

    price_in_top_zone = close > top_zone_bottom
    price_in_bottom_zone = close < bottom_zone_top

    return {
        "top_zone_bottom": top_zone_bottom,
        "top_zone_top": top_zone_top,
        "bottom_zone_top": bottom_zone_top,
        "bottom_zone_bottom": bottom_zone_bottom,
        "price_in_top_zone": price_in_top_zone,
        "price_in_bottom_zone": price_in_bottom_zone,
    }


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    n = len(df)
    if n < SMOOTH_LENGTH + BB_LENGTH + 5:
        return []

    close = df["close"]
    zones = compute_zones(df)
    price_in_top = zones["price_in_top_zone"].to_numpy()
    price_in_bottom = zones["price_in_bottom_zone"].to_numpy()
    atr_synth = atr(df, SYNTHETIC_ATR_LEN).to_numpy()
    close_np = close.to_numpy()

    signals: list[Signal] = []
    last_buy_bar = -999
    last_sell_bar = -999
    prev_in_top = False
    prev_in_bottom = False

    for i in range(n):
        in_top = bool(price_in_top[i]) if price_in_top[i] == price_in_top[i] else False
        in_bottom = bool(price_in_bottom[i]) if price_in_bottom[i] == price_in_bottom[i] else False

        enter_bottom = in_bottom and not prev_in_bottom and (i - last_buy_bar >= SIGNAL_COOLDOWN)
        enter_top = in_top and not prev_in_top and (i - last_sell_bar >= SIGNAL_COOLDOWN)

        if enter_bottom:
            last_buy_bar = i
        if enter_top:
            last_sell_bar = i

        direction = None
        if enter_bottom:
            direction = "long"
        elif enter_top:
            direction = "short"

        prev_in_top, prev_in_bottom = in_top, in_bottom

        if direction is None:
            continue
        a_synth = atr_synth[i]
        if a_synth != a_synth:  # NaN
            continue

        entry = float(close_np[i])
        sl = synthetic_stop(entry, float(a_synth), direction, SYNTHETIC_ATR_MULT)
        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=sl,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="mopeda_zone_entry", synthetic_stop=True,
        ))

    return signals
