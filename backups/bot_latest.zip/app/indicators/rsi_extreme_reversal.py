"""Port of the RSI overbought/oversold read from the "INFO BOX" label in
"9 indicators in 1 and more" (source lines 269-274): `ta.rsi(close, 14)`,
with the source only flashing a warning label when RSI is above 70 or
below 30 -- no directional trade logic, no alertcondition. The signal
here is our own reasonable mean-reversion reading of that warning: fire
short the bar RSI crosses above 70 (fade the overbought extreme), long
the bar RSI crosses below 30 (fade the oversold extreme) -- a documented
interpretation, same principle as `sr_retest_finder.py`'s own direction
mapping elsewhere in this collection where the source never labels
long/short itself.

No native stop-loss defined -- synthetic ATR(14) stop per the batch
convention.
"""
from __future__ import annotations

import pandas as pd

from .common import Signal, atr, rsi, synthetic_stop, SYNTHETIC_ATR_LEN, SYNTHETIC_ATR_MULT

RSI_LENGTH = 14
OVERBOUGHT = 70
OVERSOLD = 30


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    close = df["close"]
    rsi_val = rsi(close, RSI_LENGTH)

    prev_rsi = rsi_val.shift(1)
    cross_ob = (prev_rsi <= OVERBOUGHT) & (rsi_val > OVERBOUGHT)
    cross_os = (prev_rsi >= OVERSOLD) & (rsi_val < OVERSOLD)

    atr_synth = atr(df, SYNTHETIC_ATR_LEN)

    signals: list[Signal] = []
    for i in range(len(df)):
        if bool(cross_ob.iloc[i]):
            direction = "short"
        elif bool(cross_os.iloc[i]):
            direction = "long"
        else:
            continue

        a_synth = atr_synth.iloc[i]
        if pd.isna(a_synth):
            continue

        entry = float(close.iloc[i])
        sl = synthetic_stop(entry, float(a_synth), direction, SYNTHETIC_ATR_MULT)
        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=sl,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="rsi_extreme_reversal", synthetic_stop=True,
        ))

    return signals
