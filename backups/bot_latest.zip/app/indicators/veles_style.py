"""Primitives for replicating a Veles Finance-style DCA/grid bot
(the "SIGNAL bot" flavor: entry gated by a filter set spanning several
timeframes, exit gated by a VuManChu/LazyBear-style WaveTrend SELL cross
plus a minimum-P&L floor, and an unconditional hard stop-loss).

Not a port of a single third-party Pine script -- these are the standard,
publicly-documented TradingView built-ins (Keltner Channel, Rate of
Change) plus the classic LazyBear WaveTrend oscillator, reimplemented
by hand (same house rule as every other module in app/indicators/: no
pandas-ta/ta dependency, so behaviour is byte-for-byte auditable against
the documented Pine formulas). Deliberately NOT cross-imported from
parad_wt.py: that module only ever computes the single smoothed WaveTrend
line (LazyBear's "wt2") for a threshold-only OB/OS signal and never
computes the raw wt1 line or a wt1/wt2 crossover, which is what a
Wave-Trend-SELL exit actually needs.

Also holds the no-lookahead multi-timeframe (MTF) alignment helper
(`htf_closed_series`) used to pull in a 15m/30m confirmation reading
without ever leaking a still-forming higher-timeframe candle into a
1-minute bar's decision -- something no existing single-timeframe
backtest in this project has needed before (see parad_rsi.py's and
parad_wt.py's docstrings for the prior "not replicated: MTF" caveat).
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from .common import ema, sma, atr, true_range

# ------------------------------------------------------------ indicators --

def rate_of_change(series: pd.Series, length: int) -> pd.Series:
    """Pine's ta.roc(src, length): percent change vs. `length` bars ago."""
    prior = series.shift(length)
    return (series - prior) / prior.replace(0, np.nan) * 100


def keltner_channel(df: pd.DataFrame, length: int = 20, mult: float = 2.0,
                     use_true_range: bool = True) -> tuple[pd.Series, pd.Series, pd.Series]:
    """TradingView's standard built-in Keltner Channel indicator:
    basis = ema(close, length)
    range = atr(length)                      if use_true_range
          = sma(true_range, length)          otherwise
    upper/lower = basis +/- mult * range
    Returns (basis, upper, lower).
    """
    basis = ema(df["close"], length)
    if use_true_range:
        rng = atr(df, length)
    else:
        rng = sma(true_range(df), length)
    upper = basis + mult * rng
    lower = basis - mult * rng
    return basis, upper, lower


def atr_percent(df: pd.DataFrame, length: int = 14) -> pd.Series:
    """ATR expressed as a percent of price -- used as a volatility-regime
    filter (Veles' "ATR %" filter row)."""
    return atr(df, length) / df["close"] * 100


def wave_trend(df: pd.DataFrame, n1: int = 10, n2: int = 21,
                avg_len: int = 4) -> tuple[pd.Series, pd.Series]:
    """LazyBear's classic WaveTrend oscillator (the indicator VuManChu
    Cipher and most "VMC Wave Trend" TradingView scripts build on):
        hlc3 = (h+l+c)/3
        esa  = ema(hlc3, n1)
        d    = ema(|hlc3-esa|, n1)
        ci   = (hlc3-esa) / (0.015*d)
        wt1  = ema(ci, n2)          -- raw/fast line
        wt2  = sma(wt1, avg_len)    -- smoothed/slow line
    Returns (wt1, wt2). A SELL / take-profit-gate condition is wt1
    crossing under wt2 -- see wt_sell_cross().

    Defaults (10/21/4) are LazyBear's originals. Veles' own "Wave Trend"
    exit block may use different Channel/Average/MA lengths -- pass n1/n2/
    avg_len explicitly (exposed as CLI flags in veles_dca_backtest.py) to
    match a specific saved bot exactly.
    """
    hlc3 = (df["high"] + df["low"] + df["close"]) / 3
    esa = ema(hlc3, n1)
    d = ema((hlc3 - esa).abs(), n1)
    ci = (hlc3 - esa) / (0.015 * d.replace(0, np.nan))
    wt1 = ema(ci, n2)
    wt2 = sma(wt1, avg_len)
    return wt1, wt2


def wt_sell_cross(wt1: pd.Series, wt2: pd.Series) -> pd.Series:
    """Bearish crossunder: wt1 was >= wt2 on the previous bar and is now
    < wt2 on this bar (the WaveTrend "SELL" signal Veles uses as its
    take-profit gate). Edge-triggered, boolean, NaN-safe."""
    prev_ge = (wt1.shift(1) >= wt2.shift(1))
    now_lt = wt1 < wt2
    return (prev_ge & now_lt).fillna(False)


# --------------------------------------------------- multi-timeframe MTF --

def resample_ohlc(df_1m: pd.DataFrame, timeframe_minutes: int) -> pd.DataFrame:
    """Resample a 1-minute OHLCV frame (must have an `open_time` column,
    UTC, ascending) into higher-timeframe candles. Returns a DataFrame
    with open_time (HTF candle open), close_time (= open_time +
    timeframe_minutes, i.e. the instant the candle is fully closed),
    open/high/low/close/volume. A trailing partial (still-forming) HTF
    candle is naturally the last row and is excluded downstream by the
    close_time <= as-of check in htf_closed_series -- it is never used
    directly, only as an input to the merge_asof there."""
    d = df_1m.set_index("open_time")
    rule = f"{timeframe_minutes}min"
    o = d["open"].resample(rule, label="left", closed="left").first()
    h = d["high"].resample(rule, label="left", closed="left").max()
    l = d["low"].resample(rule, label="left", closed="left").min()
    c = d["close"].resample(rule, label="left", closed="left").last()
    v = d["volume"].resample(rule, label="left", closed="left").sum()
    out = pd.DataFrame({"open": o, "high": h, "low": l, "close": c, "volume": v})
    out = out.dropna(subset=["open"]).reset_index()
    # NOTE: adding a Timedelta can silently upcast the datetime64 resolution
    # (e.g. ms -> us on pandas >= 2.2/3.x), which later makes merge_asof in
    # htf_closed_series reject the two sides as "incompatible merge keys"
    # even though both are UTC. Cast back to open_time's own dtype so the
    # two columns always agree.
    out["close_time"] = (out["open_time"] + pd.Timedelta(minutes=timeframe_minutes)).astype(out["open_time"].dtype)
    return out


def htf_closed_series(df_1m: pd.DataFrame, timeframe_minutes: int, compute) -> pd.Series:
    """No-lookahead MTF alignment. `compute(htf_df) -> pd.Series` computes
    some indicator on the resampled higher-timeframe frame (row-aligned to
    htf_df). Returns a Series aligned to df_1m's row order/length where
    each 1-minute bar sees the value from the most recently FULLY CLOSED
    higher-timeframe candle as of that bar's own open_time -- a bar can
    never see the HTF candle it is still inside of, because merge_asof
    matches on close_time <= open_time (direction="backward"). This is
    this project's first MTF resampling harness (an explicitly documented
    gap in parad_rsi.py / parad_wt.py); every future indicator that needs
    a `request.security`-equivalent should reuse this helper rather than
    re-deriving the alignment logic.
    """
    htf = resample_ohlc(df_1m, timeframe_minutes)
    htf = htf.copy()
    htf["value"] = compute(htf)

    left = df_1m[["open_time"]].reset_index(drop=True)
    right = htf[["close_time", "value"]].sort_values("close_time")

    # Defensive normalization: merge_asof rejects datetime64 keys of
    # different resolutions (ms vs us vs ns) even when both sides are the
    # same UTC timezone, and different construction paths (pd.to_datetime
    # on int64 ms epochs vs. arithmetic on a resampled index) can easily
    # produce different resolutions. Force both keys to a single common
    # resolution right before the merge so this never resurfaces even if
    # resample_ohlc's own dtype-preservation above is ever bypassed.
    common_dtype = "datetime64[ns, UTC]"
    left = left.assign(open_time=left["open_time"].astype(common_dtype))
    right = right.assign(close_time=right["close_time"].astype(common_dtype))

    merged = pd.merge_asof(
        left.sort_values("open_time"),
        right,
        left_on="open_time", right_on="close_time",
        direction="backward",
    )
    return merged["value"].reset_index(drop=True)
