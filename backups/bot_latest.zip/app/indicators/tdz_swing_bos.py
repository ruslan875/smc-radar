"""Port of Module 4 ("Swing Points, BOS, 0.5 Retracement") from
TDZPullback.txt (source lines ~580-696). See tdz_pullback.py's module
docstring for how this relates to the other three TDZ sub-modules.

Classic market-structure analysis: finds swing highs/lows with
`ta.pivothigh`/`ta.pivotlow(swingSize, swingSize)`, classifies them as
HH/LH/HL/LL (display-only, not needed for the entry rule), and fires a
"Break of Structure" the first time price closes back through the most
recent still-unbroken opposite swing point:

    pivHi = ta.pivothigh(high, swingSize, swingSize)
    pivLo = ta.pivotlow(low, swingSize, swingSize)
    // ... track prevHigh/prevLow + highActive/lowActive (an unbroken
    // swing can only trigger one breakout, then goes inactive until a
    // newer swing point replaces it)
    highBroken = close > prevHigh and highActive   // bosConfType default "Candle Close"
    lowBroken  = close < prevLow  and lowActive

A bullish BOS (breaking the last unbroken swing high to the upside) is
ported as a "long" continuation signal; a bearish BOS (breaking the last
unbroken swing low to the downside) as "short" -- matching the source's
own convention that BOS confirms trend continuation in the break
direction.

Fidelity note: `bosConfType` defaults to "Candle Close" (close vs. the
swing level); the "Wicks" alternative (high/low vs. the swing level) is
supported via the `bos_conf_type` parameter but not exercised by default.
CHoCH relabeling and the optional 0.5-retracement line are pure display,
not ported (they don't gate the breakout condition itself).
"""
from __future__ import annotations

import math

import pandas as pd

from .common import Signal, pivothigh, pivotlow, atr, synthetic_stop, SYNTHETIC_ATR_LEN, SYNTHETIC_ATR_MULT

SWING_SIZE = 20
BOS_CONF_TYPE = "Candle Close"  # "Candle Close" | "Wicks"


def generate_signals(df: pd.DataFrame, bos_conf_type: str = BOS_CONF_TYPE) -> list[Signal]:
    high, low, close = df["high"], df["low"], df["close"]
    n = len(df)

    piv_hi = pivothigh(high, SWING_SIZE, SWING_SIZE)
    piv_lo = pivotlow(low, SWING_SIZE, SWING_SIZE)

    high_src = close if bos_conf_type == "Candle Close" else high
    low_src = close if bos_conf_type == "Candle Close" else low

    synth_atr = atr(df, SYNTHETIC_ATR_LEN)

    prev_high = math.nan
    prev_low = math.nan
    high_active = False
    low_active = False

    signals: list[Signal] = []

    for i in range(n):
        ph = piv_hi.iloc[i]
        if not pd.isna(ph):
            prev_high = float(ph)
            high_active = True

        pl = piv_lo.iloc[i]
        if not pd.isna(pl):
            prev_low = float(pl)
            low_active = True

        hs = high_src.iloc[i]
        ls = low_src.iloc[i]

        high_broken = high_active and not math.isnan(prev_high) and hs > prev_high
        low_broken = low_active and not math.isnan(prev_low) and ls < prev_low

        if high_broken:
            high_active = False
        if low_broken:
            low_active = False

        if not (high_broken or low_broken):
            continue

        synth = synth_atr.iloc[i]
        if pd.isna(synth):
            continue

        entry = float(close.iloc[i])
        # Both can fire on the same bar (a swing high and a swing low both
        # broken); Pine draws both BOS lines independently, so we emit both.
        for direction in (["long"] if high_broken else []) + (["short"] if low_broken else []):
            stop = synthetic_stop(entry, float(synth), direction, SYNTHETIC_ATR_MULT)
            signals.append(Signal(
                direction=direction, entry=entry, stop_loss=stop,
                trigger_index=i, trigger_time=df["open_time"].iloc[i],
                take_profits=None, label="tdz_swing_bos", synthetic_stop=True,
            ))

    return signals
