"""Port of "Extreme Reversal Signal" (ERS mod.) (source: ExtremeReversal.txt;
the second file handed out alongside it, ExtremeReversal(2), turned out to
be a Russian-language *description* of the same indicator, not a second
code variant -- both were read, only one is Pine source).

The file bundles four largely independent techniques:
  1. A Bollinger Band + RSI-of-RSI-Stochastic mean-reversion Buy/Sell signal
     (the file's own primary, unique entry logic) -- ported here.
  2. A "two-pole filter" rising/falling streak-counter signal, identical to
     the construct that recurs in a Kalman-filter file and a Zero Lag
     Signals file -- de-duplicated into its own module,
     `two_pole_filter_signal.py` (see that file's docstring). This module
     imports its `two_pole_filter()` helper because the primary signal
     below also *uses* the filtered line as a confirmation filter (not the
     rising/falling counter -- just the smoothed tp_f value).
  3. An RSI/Z-score info-table -- pure display, not ported.
  4. A "Volume Profile" (POC / Value Area) drawn only on the last bar
     (`barstate.islast`) -- pure visualization with no bearing on any
     signal, not ported.

Primary signal (from the source):

    basis = ta.sma(close, bb_input)          // basis_type default "SMA"
    dev   = ta.stdev(close, bb_input)
    upper = basis + std_dev_up * dev
    lower = basis - std_dev_down * dev
    rsi   = ta.rsi(close, rsi_input)
    stoch = ta.stoch(rsi, rsi, rsi, sto_input)   // StochRSI (high=low=src=rsi)
    sma   = ta.sma(stoch, 3)
    bull = close[1] < lower[1] and close > lower and sma[1] < lower_limit_sto
    bear = close[1] > upper[1] and close < upper and sma[1] > upper_limit_sto
    plotshape(bull and close > tp_f, ...)   // tp_f = two_pole_filter(close, 100, 0.9)
    plotshape(bear and close < tp_f, ...)

`basis_type` defaults to "SMA" and is the only variant ported (EMA/RMA/WMA/
VWMA options exist in the source's `input.string` but were never exercised
at default settings); WMA/VWMA also have no ready-made helper in
common.py. If you need a different basis type, swap `sma()` for `ema()`/
`rma()` from common.py -- both are already available.
"""
from __future__ import annotations

import pandas as pd

from .common import Signal, sma, stdev, rsi as rsi_fn, highest, lowest, atr as atr_fn, \
    synthetic_stop, SYNTHETIC_ATR_LEN, SYNTHETIC_ATR_MULT
from .two_pole_filter_signal import two_pole_filter, LENGTH as TPF_LENGTH, DAMPING as TPF_DAMPING

BB_LENGTH = 20
STD_DEV_UP = 2.0
STD_DEV_DOWN = 2.0
STO_LENGTH = 14
STO_UPPER = 70
STO_LOWER = 30
RSI_LENGTH = 14


def _stoch_of(src: pd.Series, length: int) -> pd.Series:
    """Pine ta.stoch(source, high, low, length) with high=low=source (as
    used here, i.e. a plain Stochastic-of-RSI): 100*(src - lowest(src,len))
    / (highest(src,len) - lowest(src,len))."""
    hh = highest(src, length)
    ll = lowest(src, length)
    rng = (hh - ll).replace(0, float("nan"))
    return 100 * (src - ll) / rng


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    close = df["close"]

    basis = sma(close, BB_LENGTH)
    dev = stdev(close, BB_LENGTH)
    upper = basis + STD_DEV_UP * dev
    lower = basis - STD_DEV_DOWN * dev

    rsi_val = rsi_fn(close, RSI_LENGTH)
    stoch = _stoch_of(rsi_val, STO_LENGTH)
    stoch_sma = sma(stoch, 3)

    tp_f = two_pole_filter(close, TPF_LENGTH, TPF_DAMPING)

    prev_close = close.shift(1)
    prev_lower = lower.shift(1)
    prev_upper = upper.shift(1)
    prev_stoch_sma = stoch_sma.shift(1)

    bull = (prev_close < prev_lower) & (close > lower) & (prev_stoch_sma < STO_LOWER)
    bear = (prev_close > prev_upper) & (close < upper) & (prev_stoch_sma > STO_UPPER)

    buy = bull & (close > tp_f)
    sell = bear & (close < tp_f)

    atr_series = atr_fn(df, SYNTHETIC_ATR_LEN)

    signals: list[Signal] = []
    for i in range(len(df)):
        is_buy = bool(buy.iloc[i]) if not pd.isna(buy.iloc[i]) else False
        is_sell = bool(sell.iloc[i]) if not pd.isna(sell.iloc[i]) else False
        if not (is_buy or is_sell):
            continue
        atrv = atr_series.iloc[i]
        if pd.isna(atrv):
            continue

        entry = float(close.iloc[i])
        direction = "long" if is_buy else "short"
        stop = synthetic_stop(entry, float(atrv), direction, SYNTHETIC_ATR_MULT)

        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=stop,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="extreme_reversal", synthetic_stop=True,
        ))

    return signals
