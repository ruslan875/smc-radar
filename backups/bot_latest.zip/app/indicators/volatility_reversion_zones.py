"""Port of "Volatility-Based Reversion Zones" (source:
VolatilityBased_Reversion_Zones.txt).

Entry logic: ATR mean-reversion bands around an EMA/SMA basis --
    long_level  = basis - ATR(14) * 1.5
    short_level = basis + ATR(14) * 1.5
both smoothed with a 3-bar EMA, then:
  - Long: close crosses over the smoothed long-zone level.
  - Short: close crosses under the smoothed short-zone level.

Volume filter: the source's `alertcondition`s (the actual "fire an alert"
events, as opposed to the purely visual `plotshape`s) require
`volume_ok = volume > ta.sma(volume, 20)[1]` in addition to the
cross. Since alertcondition is the closest Pine concept to "this is a
real signal", we treat volume_ok as part of the entry rule here (ported
verbatim, including the `[1]` -- it's the *previous* bar's 20-period
volume SMA, not the current one).

4H trend label: `ema50`/`ema200` via `request.security(..., "240", ...)`
feeds ONLY a `table.cell` text display ("BUY"/"SELL") -- verified by
reading the whole file, it never gates `long_condition`/`short_condition`
or either `alertcondition`. So there is no HTF filter to drop or
approximate: the entry-timeframe logic below is already the complete,
faithful signal.
"""
from __future__ import annotations

import pandas as pd

from .common import Signal, ema, sma, atr, synthetic_stop, SYNTHETIC_ATR_LEN

ATR_LENGTH = 14
MULT_LONG = 1.5
MULT_SHORT = 1.5
SMOOTH = 3
USE_EMA = True
VOLUME_SMA_LEN = 20


def _crossover(a: pd.Series, b: pd.Series) -> pd.Series:
    return (a.shift(1) < b.shift(1)) & (a > b)


def _crossunder(a: pd.Series, b: pd.Series) -> pd.Series:
    return (a.shift(1) > b.shift(1)) & (a < b)


def generate_signals(df: pd.DataFrame) -> list[Signal]:
    close, volume = df["close"], df["volume"]

    atr_ = atr(df, ATR_LENGTH)
    basis = ema(close, ATR_LENGTH) if USE_EMA else sma(close, ATR_LENGTH)

    long_level = basis - atr_ * MULT_LONG
    short_level = basis + atr_ * MULT_SHORT

    long_level_sm = ema(long_level, SMOOTH)
    short_level_sm = ema(short_level, SMOOTH)

    long_condition = _crossover(close, long_level_sm)
    short_condition = _crossunder(close, short_level_sm)

    volume_ok = volume > sma(volume, VOLUME_SMA_LEN).shift(1)

    long_signal = long_condition & volume_ok
    short_signal = short_condition & volume_ok

    synth_atr = atr(df, SYNTHETIC_ATR_LEN)
    signals: list[Signal] = []
    valid_from = max(ATR_LENGTH, VOLUME_SMA_LEN, SYNTHETIC_ATR_LEN) + SMOOTH + 2

    for i in range(valid_from, len(df)):
        is_long = bool(long_signal.iloc[i]) if not pd.isna(long_signal.iloc[i]) else False
        is_short = bool(short_signal.iloc[i]) if not pd.isna(short_signal.iloc[i]) else False
        if not (is_long or is_short):
            continue
        atr_v = synth_atr.iloc[i]
        if pd.isna(atr_v):
            continue

        entry = float(close.iloc[i])
        direction = "long" if is_long else "short"
        stop = synthetic_stop(entry, float(atr_v), direction)
        signals.append(Signal(
            direction=direction, entry=entry, stop_loss=stop,
            trigger_index=i, trigger_time=df["open_time"].iloc[i],
            take_profits=None, label="volatility_reversion_zones", synthetic_stop=True,
        ))

    return signals
