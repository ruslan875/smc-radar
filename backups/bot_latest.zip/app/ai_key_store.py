"""
2026-08-24, round 10: the Anthropic API key that powers the AI features
(see app/ai_assistant.py -- /ai chat, AI paragraphs on /report and
/ideas, /aiidea). Added live via `/setaikey <api_key>` in the bot's own
chat, same "no .env edit, no bot restart" convenience already established
for exchange keys (app/exchange_keys_store.py, round 5) and trade keys
(app/trade_keys_store.py, round 8) -- but this one holds a SINGLE key,
not a per-exchange dict, since there's only ever one AI provider key in
play at a time.

Same plain-JSON read-whole/mutate/write-whole-back pattern as every other
store in this project. `Settings.anthropic_api_key` (.env,
ANTHROPIC_API_KEY) is still supported as a static fallback for anyone who
prefers to set it up once before the bot's first run; when both are set,
this store wins (matches ExchangeKeysStore's "dynamically-added key wins
on collision" precedent) -- see app/ai_assistant.py's resolve_api_key().

Security note: same as every other key store in this project -- this
file holds a plaintext secret on disk, no new exposure beyond what .env
already carries for the statically-configured case. The `/setaikey`
command's triggering Telegram message is deleted immediately after
processing (main.py's _try_delete_message), same hygiene as /setkey and
/tradekey.
"""
from __future__ import annotations

import json
from pathlib import Path


class AiKeyStore:
    def __init__(self, path: Path):
        self.path = path
        if self.path.exists():
            raw = json.loads(self.path.read_text())
        else:
            raw = {}
        self._api_key: str = raw.get("api_key", "")

    def _save(self) -> None:
        self.path.write_text(json.dumps({"api_key": self._api_key}, indent=2))

    def set_key(self, api_key: str) -> None:
        self._api_key = api_key.strip()
        self._save()

    def get_key(self) -> str:
        return self._api_key
