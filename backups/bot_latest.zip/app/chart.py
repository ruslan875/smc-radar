"""
Renders a dark-theme candlestick card with Entry / SL / TP lines and a
small RSI panel underneath -- visually in the spirit of the reference
"Адаптивная стратегия" screenshots, built from scratch with matplotlib
(no mplfinance dependency).
"""
from __future__ import annotations

import io

import matplotlib
matplotlib.use("Agg")
import matplotlib.dates as mdates
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.patches import Rectangle

BG = "#0b0e14"
GRID = "#1c2230"
UP = "#26a69a"
DOWN = "#ef5350"
TEXT = "#c7cede"
ENTRY_COLOR = "#42a5f5"
SL_COLOR = "#ef5350"
TP_COLOR = "#26a69a"


def _rsi(close: pd.Series, period: int = 14) -> pd.Series:
    delta = close.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.ewm(alpha=1 / period, min_periods=period).mean()
    avg_loss = loss.ewm(alpha=1 / period, min_periods=period).mean()
    rs = avg_gain / avg_loss.replace(0, np.nan)
    rsi = 100 - (100 / (1 + rs))
    return rsi.fillna(50)


def render_signal_card(
    df: pd.DataFrame,
    symbol_label: str,
    timeframe: str,
    direction: str,
    entry: float,
    stop_loss: float,
    take_profits: list[tuple[float, float]],  # (price, pct)
    nearest_target: float | None,
    bars_shown: int = 90,
    strategy_name: str = "Адаптивная стратегия",
    show_rsi: bool = False,
) -> bytes:
    """
    show_rsi is off by default: the trader this bot is built for
    explicitly doesn't use classic indicators (RSI/MACD) -- they read
    structure. The panel is purely decorative when enabled (it plays no
    role in the signal logic in app/smc.py), kept only for anyone who
    wants the visual reference. Set SHOW_RSI=true in .env to turn it on.
    """
    plot_df = df.tail(bars_shown).reset_index(drop=True)
    x = np.arange(len(plot_df))

    if show_rsi:
        fig = plt.figure(figsize=(9, 7.2), dpi=150, facecolor=BG)
        gs = fig.add_gridspec(4, 1, height_ratios=[0.55, 3.2, 0.9, 0.05], hspace=0.06)
        ax_title = fig.add_subplot(gs[0])
        ax = fig.add_subplot(gs[1])
        ax_rsi = fig.add_subplot(gs[2], sharex=ax)
    else:
        fig = plt.figure(figsize=(9, 6.4), dpi=150, facecolor=BG)
        gs = fig.add_gridspec(2, 1, height_ratios=[0.55, 3.6], hspace=0.06)
        ax_title = fig.add_subplot(gs[0])
        ax = fig.add_subplot(gs[1])
        ax_rsi = None

    # --- title bar ---
    ax_title.set_facecolor(BG)
    ax_title.axis("off")
    ax_title.text(
        0.01, 0.5, strategy_name, color="white", fontsize=20, fontweight="bold",
        va="center", ha="left", family="DejaVu Sans",
    )
    ax_title.text(
        0.99, 0.5, f"{symbol_label}  ·  {timeframe}", color="#8b93a7", fontsize=12,
        va="center", ha="right",
    )

    # --- candles ---
    ax.set_facecolor(BG)
    width = 0.62
    for i, row in plot_df.iterrows():
        color = UP if row["close"] >= row["open"] else DOWN
        ax.add_line(plt.Line2D([i, i], [row["low"], row["high"]], color=color, linewidth=1, zorder=2))
        y0 = min(row["open"], row["close"])
        h = max(abs(row["close"] - row["open"]), 1e-9)
        ax.add_patch(Rectangle((i - width / 2, y0), width, h, facecolor=color, edgecolor=color, zorder=3))

    lo = plot_df["low"].min()
    hi = plot_df["high"].max()
    all_levels = [entry, stop_loss] + [p for p, _ in take_profits]
    if nearest_target:
        all_levels.append(nearest_target)
    lo = min(lo, min(all_levels))
    hi = max(hi, max(all_levels))
    pad = (hi - lo) * 0.06
    ax.set_ylim(lo - pad, hi + pad)
    ax.set_xlim(-1, len(plot_df) + 14)

    def hline(y, color, label, style="--", lw=1.3, alpha=0.9):
        ax.axhline(y, color=color, linestyle=style, linewidth=lw, alpha=alpha, zorder=1)
        ax.text(
            len(plot_df) + 0.6, y, f" {label}",
            color=color, fontsize=9.5, va="center", ha="left", fontweight="bold",
            bbox=dict(boxstyle="round,pad=0.25", fc="#11151f", ec=color, lw=1),
        )

    hline(entry, ENTRY_COLOR, f"ВХОД {entry:g}")
    hline(stop_loss, SL_COLOR, f"SL {stop_loss:g}")
    for price, pct in take_profits:
        hline(price, TP_COLOR, f"TP {price:g} ({pct:+.2f}%)")
    if nearest_target:
        ax.axhline(nearest_target, color="#ffb74d", linestyle=":", linewidth=1.1, alpha=0.8, zorder=1)

    marker_i = len(plot_df) - 1
    ax.scatter([marker_i], [entry], marker=("v" if direction == "short" else "^"),
               s=140, color=ENTRY_COLOR, zorder=5, edgecolor="white", linewidth=0.6)

    ax.grid(color=GRID, linewidth=0.6, alpha=0.7)
    ax.tick_params(colors=TEXT, labelsize=8.5)
    for spine in ax.spines.values():
        spine.set_color(GRID)
    ax.set_xticks([])

    # --- RSI panel (optional, decorative only -- see docstring) ---
    if ax_rsi is not None:
        rsi = _rsi(df["close"]).tail(bars_shown).reset_index(drop=True)
        ax_rsi.set_facecolor(BG)
        ax_rsi.plot(x, rsi.values, color="#ab47bc", linewidth=1.2)
        ax_rsi.axhline(70, color=GRID, linewidth=0.8, linestyle="--")
        ax_rsi.axhline(30, color=GRID, linewidth=0.8, linestyle="--")
        ax_rsi.set_ylim(0, 100)
        ax_rsi.set_xlim(-1, len(plot_df) + 14)
        ax_rsi.tick_params(colors=TEXT, labelsize=8)
        ax_rsi.text(0.01, 0.82, f"RSI {rsi.values[-1]:.1f}", transform=ax_rsi.transAxes,
                    color="#ab47bc", fontsize=9, fontweight="bold")
        for spine in ax_rsi.spines.values():
            spine.set_color(GRID)
        ax_rsi.set_xticks([])

    fig.patch.set_facecolor(BG)
    buf = io.BytesIO()
    fig.savefig(buf, format="png", facecolor=BG, bbox_inches="tight", pad_inches=0.25)
    plt.close(fig)
    buf.seek(0)
    return buf.read()


# 2026-08-26/29, round 18: /aichart -- a SEPARATE optional AI-hypothesis
# color family, deliberately distinct from every real-data color above
# (ENTRY_COLOR/SL_COLOR/TP_COLOR/UP/DOWN/MARK_COLOR), so a viewer can tell
# the two layers apart at a glance even after the caption text is
# stripped off (screenshot/forward). Purple/magenta family + dash-dot
# linestyle, vs. the real layer's blue/red/teal solid lines and shaded
# zone rectangles.
AI_ENTRY_COLOR = "#ce93d8"
AI_SL_COLOR = "#e040fb"
AI_TP_COLOR = "#ba68c8"
AI_SR_COLOR = "#ffd54f"
AI_WARNING_BG = "#4a1030"
AI_WARNING_EDGE = "#ff5252"

# Real-zone shading (order-block/FVG zones from the deterministic
# detector, see app/state.py's all_pending_zones()) -- reuses the same
# UP/DOWN palette everything else already uses for "long"/"short", just at
# low alpha since these are bands, not lines.
ZONE_LONG_COLOR = UP
ZONE_SHORT_COLOR = DOWN

MARK_COLOR = "#ffb74d"


def render_position_chart(
    df: pd.DataFrame,
    symbol_label: str,
    timeframe: str,
    side: str,
    entry: float,
    stop_loss: float | None = None,
    take_profit: float | None = None,
    mark_price: float | None = None,
    bars_shown: int = 90,
) -> bytes:
    """
    2026-08-25, round 16 follow-up: the user pointed at the bot's own
    signal-alert chart above (render_signal_card -- which DOES draw entry/
    SL/TP directly on the candles) and asked why the open position shown
    in the Торговля tab can't do the same. Fair point: the earlier round-16
    finding that the TradingView chart embed can't draw lines was only
    ever true of that specific product's free embed widget (see the
    project doc's round-16 write-up) -- it says nothing about this bot's
    OWN matplotlib-based charting, which has been drawing exactly these
    kinds of lines since round 1. This function reuses that same visual
    style for an OPEN POSITION instead of a fresh signal.

    Deliberately a SEPARATE function from render_signal_card rather than
    threading optional args into it: render_signal_card's contract (entry
    and stop_loss always given, direction always "long"/"short") is used
    for every real trading signal this bot sends and stays completely
    unchanged. An open position can genuinely be missing a stop_loss or
    take_profit (Bybit returns "" for an unset one, normalized to None
    elsewhere in this project -- see app/exchanges/bybit.py), so every
    line here is drawn only if its price is actually given -- nothing is
    invented or defaulted to make a line appear. `side` is this project's
    own "buy"/"sell" vocabulary (matching Bybit's own position side field
    and app/trading_guard.py's convention) and is mapped to "long"/"short"
    just for the up/down arrow marker and percentage-sign convention.
    `mark_price`, when given, is drawn as a dotted line (same visual
    treatment render_signal_card already gives a signal's nearest_target)
    so the viewer can see at a glance where price currently sits relative
    to entry/stop/take -- purely informational, this bot never uses it to
    decide anything.
    """
    direction = "long" if side in ("buy", "long") else "short"
    plot_df = df.tail(bars_shown).reset_index(drop=True)

    fig = plt.figure(figsize=(9, 6.4), dpi=150, facecolor=BG)
    gs = fig.add_gridspec(2, 1, height_ratios=[0.55, 3.6], hspace=0.06)
    ax_title = fig.add_subplot(gs[0])
    ax = fig.add_subplot(gs[1])

    ax_title.set_facecolor(BG)
    ax_title.axis("off")
    ax_title.text(
        0.01, 0.5, "Открытая позиция", color="white", fontsize=20, fontweight="bold",
        va="center", ha="left", family="DejaVu Sans",
    )
    ax_title.text(
        0.99, 0.5, f"{symbol_label}  ·  {timeframe}", color="#8b93a7", fontsize=12,
        va="center", ha="right",
    )

    ax.set_facecolor(BG)
    width = 0.62
    for i, row in plot_df.iterrows():
        color = UP if row["close"] >= row["open"] else DOWN
        ax.add_line(plt.Line2D([i, i], [row["low"], row["high"]], color=color, linewidth=1, zorder=2))
        y0 = min(row["open"], row["close"])
        h = max(abs(row["close"] - row["open"]), 1e-9)
        ax.add_patch(Rectangle((i - width / 2, y0), width, h, facecolor=color, edgecolor=color, zorder=3))

    lo = plot_df["low"].min()
    hi = plot_df["high"].max()
    all_levels = [entry] + [p for p in (stop_loss, take_profit, mark_price) if p is not None]
    lo = min(lo, min(all_levels))
    hi = max(hi, max(all_levels))
    pad = (hi - lo) * 0.06
    ax.set_ylim(lo - pad, hi + pad)
    ax.set_xlim(-1, len(plot_df) + 14)

    def hline(y, color, label, style="--", lw=1.3, alpha=0.9):
        ax.axhline(y, color=color, linestyle=style, linewidth=lw, alpha=alpha, zorder=1)
        ax.text(
            len(plot_df) + 0.6, y, f" {label}",
            color=color, fontsize=9.5, va="center", ha="left", fontweight="bold",
            bbox=dict(boxstyle="round,pad=0.25", fc="#11151f", ec=color, lw=1),
        )

    hline(entry, ENTRY_COLOR, f"ВХОД {entry:g}")
    if stop_loss is not None:
        hline(stop_loss, SL_COLOR, f"SL {stop_loss:g}")
    if take_profit is not None:
        hline(take_profit, TP_COLOR, f"TP {take_profit:g}")
    if mark_price is not None:
        ax.axhline(mark_price, color=MARK_COLOR, linestyle=":", linewidth=1.1, alpha=0.8, zorder=1)
        ax.text(
            len(plot_df) + 0.6, mark_price, " ТЕКУЩАЯ",
            color=MARK_COLOR, fontsize=8.5, va="center", ha="left",
            bbox=dict(boxstyle="round,pad=0.2", fc="#11151f", ec=MARK_COLOR, lw=0.8),
        )

    marker_i = len(plot_df) - 1
    ax.scatter([marker_i], [entry], marker=("v" if direction == "short" else "^"),
               s=140, color=ENTRY_COLOR, zorder=5, edgecolor="white", linewidth=0.6)

    ax.grid(color=GRID, linewidth=0.6, alpha=0.7)
    ax.tick_params(colors=TEXT, labelsize=8.5)
    for spine in ax.spines.values():
        spine.set_color(GRID)
    ax.set_xticks([])

    fig.patch.set_facecolor(BG)
    buf = io.BytesIO()
    fig.savefig(buf, format="png", facecolor=BG, bbox_inches="tight", pad_inches=0.25)
    plt.close(fig)
    buf.seek(0)
    return buf.read()


def render_ai_annotated_chart(
    df: pd.DataFrame,
    symbol_label: str,
    timeframe: str,
    real_zones: list | None = None,
    real_entry: float | None = None,
    real_stop: float | None = None,
    real_take: float | None = None,
    ai_annotation: dict | None = None,
    bars_shown: int = 90,
) -> bytes:
    """
    2026-08-26/29, round 18 -- the user asked for Vera (the AI persona) to
    "analyze the chart and mark the entry point, take-profit, stop-loss
    with labels, and mark the support/resistance zones." Scoped via
    AskUserQuestion into "both at once": ALWAYS draw the bot's own real,
    already-computed zones/levels (order-block/FVG zones from
    app/state.py's all_pending_zones(), plus a real active signal's real
    entry/stop/take if one exists) as the base layer, PLUS a separately
    and clearly labeled EXPERIMENTAL AI-hypothesis layer on the SAME
    image, if (and only if) app/ai_assistant.generate_chart_annotation()
    returned something that passed its own strict validation.

    Safety-critical design points, matching the project's non-negotiable
    constraints for this round:

    - The two layers are visually unambiguous even with the caption
      stripped off (a chart image can be screenshotted/forwarded on its
      own): the real layer reuses this project's existing solid-line
      ENTRY_COLOR/SL_COLOR/TP_COLOR + shaded zone rectangles (the same
      visual language render_signal_card/render_position_chart already
      use everywhere else), while the AI layer uses a completely
      different purple/magenta family, dash-dot linestyles, and its own
      "🧪 ИИ" label prefix on every line.
    - Whenever `ai_annotation` is given, a bordered warning box is drawn
      DIRECTLY ON THE IMAGE (not just relying on the Telegram caption --
      captions get stripped when an image is forwarded/screenshotted):
      "⚠️ ИИ-гипотеза, эксперимент -- не сигнал".
    - `ai_annotation` is trusted as-is here -- this function does NOT
      re-validate it (that already happened, defensively, in
      generate_chart_annotation/_validate_chart_annotation). Callers MUST
      pass None here for anything that failed that validation; this
      function's own job is only to draw whatever it's handed and never
      crash regardless of what real/AI data is or isn't present.
    - Every input is optional except `df`/`symbol_label`/`timeframe`: no
      real zones, no real entry/stop/take (no active signal for this
      symbol), and/or ai_annotation=None (AI unavailable/invalid this
      time) must all render a valid, non-crashing chart -- a chart with
      just candles and nothing else is a legitimate, safe output.
    """
    plot_df = df.tail(bars_shown).reset_index(drop=True)
    real_zones = real_zones or []
    x_right = len(plot_df) + 14

    fig = plt.figure(figsize=(9, 6.8), dpi=150, facecolor=BG)
    gs = fig.add_gridspec(2, 1, height_ratios=[0.55, 3.6], hspace=0.06)
    ax_title = fig.add_subplot(gs[0])
    ax = fig.add_subplot(gs[1])

    ax_title.set_facecolor(BG)
    ax_title.axis("off")
    ax_title.text(
        0.01, 0.5, "Вера: зоны бота + ИИ-гипотеза", color="white", fontsize=17, fontweight="bold",
        va="center", ha="left", family="DejaVu Sans",
    )
    ax_title.text(
        0.99, 0.5, f"{symbol_label}  ·  {timeframe}", color="#8b93a7", fontsize=12,
        va="center", ha="right",
    )

    # --- candles (always drawn -- base layer, never depends on real/AI data) ---
    ax.set_facecolor(BG)
    width = 0.62
    for i, row in plot_df.iterrows():
        color = UP if row["close"] >= row["open"] else DOWN
        ax.add_line(plt.Line2D([i, i], [row["low"], row["high"]], color=color, linewidth=1, zorder=2))
        y0 = min(row["open"], row["close"])
        h = max(abs(row["close"] - row["open"]), 1e-9)
        ax.add_patch(Rectangle((i - width / 2, y0), width, h, facecolor=color, edgecolor=color, zorder=3))

    lo = plot_df["low"].min()
    hi = plot_df["high"].max()
    all_levels = [lo, hi]
    for z in real_zones:
        all_levels.append(getattr(z, "bottom", lo))
        all_levels.append(getattr(z, "top", hi))
    for v in (real_entry, real_stop, real_take):
        if v is not None:
            all_levels.append(v)
    if ai_annotation:
        all_levels.extend([ai_annotation["entry"], ai_annotation["stop_loss"], ai_annotation["take_profit"]])
        all_levels.extend(sr["price"] for sr in ai_annotation.get("support_resistance", []))
    lo = min(all_levels)
    hi = max(all_levels)
    pad = (hi - lo) * 0.06 if hi > lo else max(hi * 0.02, 1e-6)
    ax.set_ylim(lo - pad, hi + pad)
    ax.set_xlim(-1, x_right)

    def hline(y, color, label, style="--", lw=1.3, alpha=0.9, x_pos=None):
        ax.axhline(y, color=color, linestyle=style, linewidth=lw, alpha=alpha, zorder=1)
        ax.text(
            (x_pos if x_pos is not None else x_right - 13.4), y, f" {label}",
            color=color, fontsize=8.8, va="center", ha="left", fontweight="bold",
            bbox=dict(boxstyle="round,pad=0.22", fc="#11151f", ec=color, lw=1),
        )

    # --- real zones (order-block/FVG, from the deterministic detector) ---
    # Shaded bands, not lines -- a zone is a price RANGE, not a single
    # level. Reuses the same UP/DOWN palette everything else already uses
    # for "long"/"short", just at low alpha so candles stay legible
    # underneath.
    for z in real_zones:
        try:
            bottom = float(z.bottom)
            top = float(z.top)
        except (TypeError, ValueError, AttributeError):
            continue
        if not (np.isfinite(bottom) and np.isfinite(top)):
            continue
        band_color = ZONE_LONG_COLOR if getattr(z, "direction", "long") == "long" else ZONE_SHORT_COLOR
        y0, y1 = (bottom, top) if bottom <= top else (top, bottom)
        ax.add_patch(Rectangle((-1, y0), x_right + 1, y1 - y0, facecolor=band_color,
                                edgecolor=band_color, alpha=0.14, linewidth=0.6, zorder=0))
        label = f"{getattr(z, 'zone_kind', 'зона')} {getattr(z, 'direction', '')}".strip()
        ax.text(0.3, (y0 + y1) / 2, label, color=band_color, fontsize=7.2, va="center", ha="left",
                alpha=0.9, zorder=1)

    # --- real bot entry/stop/take (an active signal for this symbol, if any) ---
    if real_entry is not None:
        hline(real_entry, ENTRY_COLOR, f"БОТ ВХОД {real_entry:g}", style="-", x_pos=x_right - 13.4)
    if real_stop is not None:
        hline(real_stop, SL_COLOR, f"БОТ SL {real_stop:g}", style="-", x_pos=x_right - 13.4)
    if real_take is not None:
        hline(real_take, TP_COLOR, f"БОТ TP {real_take:g}", style="-", x_pos=x_right - 13.4)

    # --- AI hypothesis layer (only if a validated annotation was given) ---
    if ai_annotation:
        # Plain "ИИ" text prefix, not an emoji, in the drawn labels below --
        # DejaVu Sans (matplotlib's default font) doesn't have a glyph for
        # the test-tube emoji, which would otherwise render as a visible
        # missing-glyph box directly on the chart image itself. The emoji
        # is still used in the Telegram caption text (main.py), where the
        # Telegram client's own font handles it fine.
        hline(ai_annotation["entry"], AI_ENTRY_COLOR, f"ИИ вход {ai_annotation['entry']:g}",
              style="-.", lw=1.5, x_pos=x_right - 6.8)
        hline(ai_annotation["stop_loss"], AI_SL_COLOR, f"ИИ SL {ai_annotation['stop_loss']:g}",
              style="-.", lw=1.5, x_pos=x_right - 6.8)
        hline(ai_annotation["take_profit"], AI_TP_COLOR, f"ИИ TP {ai_annotation['take_profit']:g}",
              style="-.", lw=1.5, x_pos=x_right - 6.8)
        for sr in ai_annotation.get("support_resistance", []):
            price = sr["price"]
            label = sr.get("label") or sr.get("kind", "")
            ax.axhline(price, color=AI_SR_COLOR, linestyle=":", linewidth=0.9, alpha=0.75, zorder=1)
            ax.text(0.3, price, f"ИИ: {label}".strip(), color=AI_SR_COLOR, fontsize=7,
                    va="center", ha="left", alpha=0.85, zorder=1)

        # Baked-in warning, directly on the pixels -- NOT relying on the
        # Telegram caption, since a chart image is often screenshotted or
        # forwarded on its own with no caption attached. Anchored in axes
        # (0..1) coordinates so it always sits in the same visible corner
        # regardless of the price scale.
        ax.text(
            0.5, 0.965, "⚠️ ИИ-ГИПОТЕЗА, ЭКСПЕРИМЕНТ -- НЕ СИГНАЛ",
            transform=ax.transAxes, color="white", fontsize=10.5, fontweight="bold",
            va="top", ha="center", zorder=10,
            bbox=dict(boxstyle="round,pad=0.35", fc=AI_WARNING_BG, ec=AI_WARNING_EDGE, lw=1.6),
        )

    marker_i = len(plot_df) - 1
    if real_entry is not None:
        ax.scatter([marker_i], [real_entry], marker="o", s=110, color=ENTRY_COLOR, zorder=5,
                   edgecolor="white", linewidth=0.6)

    ax.grid(color=GRID, linewidth=0.6, alpha=0.7)
    ax.tick_params(colors=TEXT, labelsize=8.5)
    for spine in ax.spines.values():
        spine.set_color(GRID)
    ax.set_xticks([])

    fig.patch.set_facecolor(BG)
    buf = io.BytesIO()
    fig.savefig(buf, format="png", facecolor=BG, bbox_inches="tight", pad_inches=0.25)
    plt.close(fig)
    buf.seek(0)
    return buf.read()
