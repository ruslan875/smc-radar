"""app/trader_brain.py — 2026-10-05. «Мозг трейдера» для ИИ-помощника TRADEOS.

Что это честно: память + правила, а не предсказатель рынка.
  • brain.json — уроки (что пошло не так / что работает) и правила владельца. Пополняется:
      – вручную: /learn текст;
      – автоматически: разбор журнала челленджа (объём больше сигнала, стоп дня, серия убытков, ручное закрытие),
        итоги бумажных ботов, выводы ИИ из вечернего отчёта (раздел «Урок дня»).
  • context() — срез для ИИ: правила, уроки, челлендж Hash Hedge, сигналы пробоя канала, бумажные боты,
    сводка проверенных стратегий. Добавляется к /ai, к свободным вопросам и к вечернему отчёту.
ИИ ничего не торгует сам; команды (/risk) меняют только настройки челленджа.
"""
from __future__ import annotations

import datetime as dt
import json
import threading
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
BRAIN = BASE / "brain.json"
_lock = threading.Lock()

DEFAULT_RULES = [
    "Челлендж Hash Hedge: торговать ТОЛЬКО сигналы «📐 ПРОБОЙ КАНАЛА 4h» (12 монет), объём и стоп — ровно из сообщения.",
    "Риск на сделку — из окна «Челлендж» (сейчас ~30 $). Стоп дня 100 $: после него в этот день не входить.",
    "Не закрывать сделку руками раньше стопа/тейка. Не больше 3 сделок одновременно.",
    "Не входить, если цена после пробоя вернулась внутрь канала или ушла дальше половины стопа.",
    "Проверено на истории: работает пробой канала 100 на крипте 4h (+0.14R/сделку, 12/12 монет). "
    "KVOO, Midas, SrgArt, Герчик-отбой, ATR-фильтры, всё на 1h — не работает.",
]


def _load() -> dict:
    try:
        d = json.loads(BRAIN.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        d = {}
    d.setdefault("rules", list(DEFAULT_RULES))
    d.setdefault("lessons", [])
    d.setdefault("seen", [])
    return d


def _save(d: dict) -> None:
    d["lessons"] = d["lessons"][-60:]
    d["seen"] = d["seen"][-500:]
    tmp = BRAIN.with_suffix(".tmp")
    tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(BRAIN)


def add_lesson(text: str, source: str = "владелец", key: str | None = None) -> bool:
    text = " ".join(str(text).split())[:300]
    if not text:
        return False
    with _lock:
        d = _load()
        k = key or text.lower()
        if k in d["seen"]:
            return False
        d["seen"].append(k)
        d["lessons"].append({"date": dt.date.today().isoformat(), "src": source, "text": text})
        _save(d)
    return True


def forget(n: int) -> str | None:
    with _lock:
        d = _load()
        if 1 <= n <= len(d["lessons"]):
            x = d["lessons"].pop(n - 1)
            _save(d)
            return x["text"]
    return None


def add_rule(text: str) -> None:
    with _lock:
        d = _load()
        d["rules"].append(" ".join(text.split())[:300])
        _save(d)


def listing() -> str:
    d = _load()
    out = ["<b>📜 Правила</b>"] + [f"• {r}" for r in d["rules"]]
    out += ["", "<b>🧠 Уроки</b> (удалить: /forget номер)"]
    out += [f"{i}. [{x['date']}, {x['src']}] {x['text']}" for i, x in enumerate(d["lessons"], 1)] or ["пока нет"]
    return "\n".join(out)


# ---------- данные для ИИ ----------
def _read(p: Path):
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return None


def _challenge_text() -> str:
    c = _read(BASE / "challenge.json")
    if not c:
        return "Челлендж Hash Hedge: окно «Челлендж» ещё не заполнено."
    today = dt.date.today().isoformat()
    tr = c.get("trades") or []
    day = sum(float(t.get("pnl") or 0) for t in tr if t.get("date") == today)
    lines = [f"Челлендж Hash Hedge: баланс {c.get('bal')} $, провал при {c.get('floor')} $ "
             f"(запас {float(c.get('bal', 0)) - float(c.get('floor', 0)):.0f} $), риск на сделку {c.get('risk')} $, "
             f"стоп дня {c.get('day')} $, сегодня {day:+.2f} $."]
    for t in tr[:15]:
        lines.append(f"  {t.get('date')} {t.get('time')} {t.get('sym')} {t.get('side')} объём {t.get('size')} $ "
                     f"итог {t.get('pnl')} $" + (" — ОБЪЁМ БОЛЬШЕ СИГНАЛА" if t.get("over") else ""))
    return "\n".join(lines)


def _bots_text() -> str:
    lines = ["Бумажные/внешние боты (сделки вперёд, не история):"]
    for f in sorted((BASE / "bt_lab_bots").glob("*.json")):
        b = _read(f)
        if not isinstance(b, dict) or "trades" not in b:
            continue
        tr = b.get("trades") or []
        dep = float((b.get("params") or {}).get("deposit") or 0)
        usd = sum(float(t.get("usd") or 0) for t in tr)
        wins = sum(1 for t in tr if float(t.get("usd") or t.get("r") or 0) > 0)
        label = (b.get("params") or {}).get("label") or b.get("id")
        lines.append(f"  {label}: сделок {len(tr)}, в плюсе {wins}, итог {usd:+.2f} $" + (f" от {dep:.0f} $" if dep else "")
                     + (f", открыто {len(b['open'])}" if b.get("open") else ""))
    return "\n".join(lines[:25])


def _signals_text() -> str:
    b = _read(BASE / "bt_lab_bots" / "chan_paper.json") or {}
    op = b.get("open") or []
    if not op:
        return "Пробой канала 4h: открытых сигналов сейчас нет."
    return "Пробой канала 4h, открытые сигналы:\n" + "\n".join(
        f"  {o.get('sym')} {o.get('side')} вход {o.get('entry'):.6g} стоп {o.get('sl'):.6g} тейк {o.get('tp'):.6g}" for o in op)


def context() -> str:
    d = _load()
    parts = ["=== МОЗГ ТРЕЙДЕРА: правила владельца ===", *[f"- {r}" for r in d["rules"]],
             "=== Уроки (прошлые ошибки и выводы) ===", *([f"- [{x['date']}] {x['text']}" for x in d["lessons"][-25:]] or ["- пока нет"]),
             "=== Сейчас ===", _challenge_text(), _signals_text(), own_ai_text(), _bots_text(), _bots_trades_text()]
    return "\n".join(parts)


# ---------- автоматические уроки ----------
def auto_lessons() -> list[str]:
    """Разбор журнала челленджа и ботов → новые уроки (без ИИ, только факты). Возвращает добавленные."""
    added: list[str] = []
    c = _read(BASE / "challenge.json") or {}
    tr = c.get("trades") or []
    for t in tr:
        if t.get("over"):
            txt = (f"{t.get('date')}: {t.get('sym')} — объём {t.get('size')} $ был больше сигнального, итог {t.get('pnl')} $. "
                   f"Вводить количество монет ровно из сообщения.")
            if add_lesson(txt, "журнал", key=f"over:{t.get('id')}"):
                added.append(txt)
    by_day: dict[str, float] = {}
    for t in tr:
        by_day[t.get("date")] = by_day.get(t.get("date"), 0.0) + float(t.get("pnl") or 0)
    lim = abs(float(c.get("day") or 100))
    for day, s in by_day.items():
        if s <= -lim:
            txt = f"{day}: дневной убыток {s:.0f} $ превысил стоп дня {lim:.0f} $. После стопа дня — не торговать."
            if add_lesson(txt, "журнал", key=f"daystop:{day}"):
                added.append(txt)
    losses = 0
    for t in sorted(tr, key=lambda x: (x.get("date"), x.get("time"))):
        losses = losses + 1 if float(t.get("pnl") or 0) < 0 else 0
        if losses == 4:
            txt = f"{t.get('date')}: 4 убытка подряд в челлендже. Сделать паузу на день, риск не повышать."
            if add_lesson(txt, "журнал", key=f"streak:{t.get('id')}"):
                added.append(txt)
    for f in (BASE / "bt_lab_bots").glob("*.json"):
        b = _read(f)
        if not isinstance(b, dict):
            continue
        tr2 = b.get("trades") or []
        if len(tr2) >= 20:
            usd = sum(float(x.get("usd") or 0) for x in tr2)
            label = (b.get("params") or {}).get("label") or b.get("id")
            verdict = "в плюсе — подтверждается вживую" if usd > 0 else "в минусе — вживую не подтверждается"
            txt = f"Бумажный бот «{label}»: {len(tr2)} сделок, итог {usd:+.2f} $ — {verdict}."
            if add_lesson(txt, "боты", key=f"bot20:{b.get('id')}:{len(tr2) // 20}"):
                added.append(txt)
    return added


def lesson_from_digest(digest: str) -> str | None:
    """Строка «Урок дня: …» из вечернего разбора ИИ → в память."""
    for line in (digest or "").splitlines():
        s = line.strip().lstrip("-•* ").strip()
        if s.lower().startswith("урок дня"):
            txt = s.split(":", 1)[-1].strip()
            if len(txt) > 10 and add_lesson(f"{dt.date.today().isoformat()}: {txt}", "ИИ"):
                return txt
    return None


def set_risk(v: float) -> str:
    p = BASE / "challenge.json"
    c = _read(p) or {"bal": 9436.0, "floor": 9000.0, "risk": 30.0, "day": 100.0, "trades": []}
    old = c.get("risk")
    c["risk"] = float(v)
    p.write_text(json.dumps(c, ensure_ascii=False, indent=1), encoding="utf-8")
    return f"Риск на сделку: {old} → {v:g} $. Следующие сигналы пробоя посчитают объём под него."


# ---------- самообучение (2026-10-05): статистика + еженедельная самопроверка ИИ ----------
def learn_from_stats() -> list[str]:
    """Сам считает, где система/вы зарабатываете и теряете (по монетам и часам), и пишет выводы,
    когда данных достаточно (≥5 сделок в группе). Обновляется при каждом вечернем отчёте."""
    added: list[str] = []
    rows = []
    for t in (_read(BASE / "challenge.json") or {}).get("trades") or []:
        rows.append(("челлендж", t.get("sym"), (t.get("time") or "00")[:2], float(t.get("pnl") or 0)))
    b = _read(BASE / "bt_lab_bots" / "chan_paper.json") or {}
    for t in b.get("trades") or []:
        h = dt.datetime.utcfromtimestamp(int(t.get("open_t") or 0) / 1000).strftime("%H")
        rows.append(("пробой канала", t.get("sym"), h, float(t.get("r") or 0)))
    for src in {r[0] for r in rows}:
        for idx, name in ((1, "монета"), (2, "час")):
            g: dict[str, list[float]] = {}
            for r in rows:
                if r[0] == src:
                    g.setdefault(str(r[idx]), []).append(r[3])
            for k, v in g.items():
                if len(v) < 5:
                    continue
                s = sum(v); wins = sum(1 for x in v if x > 0)
                if s < 0 and wins / len(v) < 0.3:
                    txt = f"{src}: {name} {k} — {len(v)} сделок, в плюсе {wins}, итог {s:+.2f}. Пока в минусе — осторожнее."
                elif s > 0 and wins / len(v) >= 0.5:
                    txt = f"{src}: {name} {k} — {len(v)} сделок, в плюсе {wins}, итог {s:+.2f}. Работает хорошо."
                else:
                    continue
                if add_lesson(txt, "статистика", key=f"stat:{src}:{name}:{k}:{len(v) // 5}"):
                    added.append(txt)
    return added


def weekly_review(call_ai) -> str | None:
    """Раз в неделю ИИ перечитывает все уроки вместе со свежими итогами и сам решает: какие подтвердились,
    какие устарели (удаляет), какие объединить. call_ai(system, user) -> str. Ответ ждём JSON."""
    d = _load()
    if not d["lessons"]:
        return None
    last = d.get("review_date")
    if last and (dt.date.today() - dt.date.fromisoformat(last)).days < 7:
        return None
    numbered = "\n".join(f"{i}. {x['text']}" for i, x in enumerate(d["lessons"], 1))
    sysm = ("Ты ведёшь память трейдера. Тебе дают пронумерованные уроки и свежие данные. Верни ТОЛЬКО JSON: "
            '{"remove":[номера устаревших или опровергнутых данными], "merge":[{"from":[номера],"text":"объединённый урок"}], '
            '"new":["новый вывод из данных, если он явно следует"], "summary":"2 предложения: чему научились за неделю"}. '
            "Удаляй только то, что данные опровергают или что дублируется. Не выдумывай.")
    raw = call_ai(sysm, f"Уроки:\n{numbered}\n\nДанные сейчас:\n{context()}")
    if not raw:
        return None
    try:
        j = json.loads(raw[raw.find("{"): raw.rfind("}") + 1])
    except Exception:  # noqa: BLE001
        return None
    with _lock:
        d = _load()
        drop = {int(i) for i in j.get("remove") or [] if str(i).isdigit()}
        for m in j.get("merge") or []:
            drop |= {int(i) for i in m.get("from") or [] if str(i).isdigit()}
        keep = [x for i, x in enumerate(d["lessons"], 1) if i not in drop]
        today = dt.date.today().isoformat()
        for m in j.get("merge") or []:
            if m.get("text"):
                keep.append({"date": today, "src": "ИИ-обзор", "text": str(m["text"])[:300]})
        for t in j.get("new") or []:
            keep.append({"date": today, "src": "ИИ-обзор", "text": str(t)[:300]})
        d["lessons"] = keep
        d["review_date"] = today
        _save(d)
    return str(j.get("summary") or "")


def own_ai_text() -> str:
    """Что «свой ИИ» (own_ai.py) говорил о сигналах пробоя и чем они закончились — чтобы помощник видел его точность."""
    b = _read(BASE / "bt_lab_bots" / "chan_paper.json") or {}
    sc = b.get("ai_scores") or {}
    rep = _read(BASE / "own_ai_report.json") or {}
    if not rep:
        return "Свой ИИ (модель на свечах): ещё не обучен."
    agg: dict[str, list[float]] = {}
    for t in b.get("trades") or []:
        lvl = sc.get(f"{t.get('sym')}:{t.get('open_t')}")
        if lvl:
            agg.setdefault(lvl, []).append(float(t.get("r") or 0))
    parts = [f"Свой ИИ: обучен {rep.get('trained')} на {rep.get('signals')} сигналах. Вживую:"]
    parts += [f"  {k}: {len(v)} сделок, в плюсе {sum(1 for x in v if x > 0)}, итог {sum(v):+.2f}R" for k, v in agg.items()] or ["  оценённых закрытых сделок пока нет."]
    return "\n".join(parts)


# ---------- 2026-10-06: учёба на сделках РЕАЛЬНЫХ ботов, демо-ботов и демо-счёта ----------
def _csv(p: Path) -> list[dict]:
    import csv  # noqa: PLC0415
    try:
        with open(p, encoding="utf-8", newline="") as f:
            return list(csv.DictReader(f))
    except Exception:  # noqa: BLE001
        return []


def _all_bot_trades() -> list[tuple]:
    """(источник, стратегия, монета, час UTC, результат %, причина выхода)."""
    out = []
    for name, f in (("РЕАЛ Latuserge", "long_strategy15_latuserge_live_trades.csv"), ("РЕАЛ KC/ROC грид", "kc_roc_cci_wt_grid_live_trades.csv")):
        for r in _csv(BASE / f):
            try:
                out.append((name, name, r["symbol"], str(r.get("entry_time", ""))[11:13], float(r.get("gross_pnl_pct") or 0) - 0.11, r.get("reason", "")))
            except Exception:  # noqa: BLE001
                pass
    for r in _csv(BASE / "paper_live_trades.csv"):
        try:
            out.append(("демо", r.get("strategy", "?"), r.get("symbol", "?").replace("/", ""), str(r.get("entry_time", ""))[11:13],
                        float(r.get("pnl_pct") or 0), r.get("reason", "")))
        except Exception:  # noqa: BLE001
            pass
    for t in (_read(BASE / "bt_lab_bots" / "demo_manual.json") or {}).get("trades") or []:
        h = dt.datetime.utcfromtimestamp(int(t.get("open_t") or 0) / 1000).strftime("%H")
        out.append(("демо-счёт (ручные)", "ручная торговля", t.get("sym"), h, float(t.get("pnl_pct") or 0), t.get("why", "")))
    return out


def learn_from_bots() -> list[str]:
    """Ищет повторяющиеся ошибки ботов: стратегия×монета, стратегия×час, серии стопов, «большой стоп съедает много тейков».
    Пишет урок, когда группа набрала ≥8 сделок и явно в минусе (или явно в плюсе)."""
    added: list[str] = []
    rows = _all_bot_trades()
    groups: dict[tuple, list[float]] = {}
    for src, strat, sym, hr, pnl, _why in rows:
        groups.setdefault((src, strat, "монета", sym), []).append(pnl)
        groups.setdefault((src, strat, "час UTC", hr), []).append(pnl)
        groups.setdefault((src, strat, "всего", ""), []).append(pnl)
    for (src, strat, kind, key), v in groups.items():
        if len(v) < 8:
            continue
        s = sum(v); wr = sum(1 for x in v if x > 0) / len(v)
        where = f"{kind} {key}" if key else "в целом"
        if s < -2 and wr < 0.45:
            txt = f"{src} «{strat}», {where}: {len(v)} сделок, в плюсе {wr * 100:.0f}%, итог {s:+.1f}% — повторяющийся минус, не повторять / исключить."
        elif s > 2 and wr >= 0.55:
            txt = f"{src} «{strat}», {where}: {len(v)} сделок, в плюсе {wr * 100:.0f}%, итог {s:+.1f}% — работает."
        else:
            continue
        if add_lesson(txt, "боты", key=f"bot:{src}:{strat}:{kind}:{key}:{len(v) // 8}"):
            added.append(txt)
    # «много маленьких тейков и редкий большой стоп» — классическая ловушка
    by_strat: dict[tuple, list[float]] = {}
    for src, strat, _s, _h, pnl, _w in rows:
        by_strat.setdefault((src, strat), []).append(pnl)
    for (src, strat), v in by_strat.items():
        wins = [x for x in v if x > 0]; losses = [x for x in v if x < 0]
        if len(v) >= 15 and wins and losses and min(losses) < -3 * (sum(wins) / len(wins)):
            txt = (f"{src} «{strat}»: средний плюс {sum(wins) / len(wins):.2f}%, но худший стоп {min(losses):.2f}% — "
                   f"один стоп съедает {abs(min(losses)) / (sum(wins) / len(wins)):.0f} тейков. Следить за размером убытка, а не за винрейтом.")
            if add_lesson(txt, "боты", key=f"bigloss:{src}:{strat}:{round(min(losses))}"):
                added.append(txt)
    return added


def _bots_trades_text() -> str:
    rows = _all_bot_trades()
    agg: dict[tuple, list[float]] = {}
    for src, strat, *_rest, pnl, _w in [(r[0], r[1], r[2], r[3], r[4], r[5]) for r in rows]:
        agg.setdefault((src, strat), []).append(pnl)
    if not agg:
        return ""
    return "Сделки ботов (реальные и демо, %):\n" + "\n".join(
        f"  {s} «{k}»: {len(v)} сделок, в плюсе {sum(1 for x in v if x > 0)}, сумма {sum(v):+.1f}%, худшая {min(v):+.2f}%"
        for (s, k), v in sorted(agg.items()))
