from __future__ import annotations

import json
import os
import sys
from dataclasses import dataclass, field
from pathlib import Path

from dotenv import load_dotenv

load_dotenv()

# 2026-09-06: BASE_DIR must resolve differently once this codebase can also
# run frozen (packaged into a standalone .exe via PyInstaller for
# windows_app/'s admin panel -- see windows_app/README.md). Normally
# (`python main.py`, `python long_strategy15_latuserge_live.py`, `python
# windows_app/run.py` -- i.e. every way this project has ever been run
# before today) `sys.frozen` does not exist and this is BYTE-FOR-BYTE the
# original, already-in-production computation: `Path(__file__).resolve()
# .parent.parent`. That path stays completely unchanged for the live
# Telegram bot and both *_live.py scripts -- nothing here can affect them.
#
# Only when frozen (PyInstaller sets `sys.frozen = True`) does this take
# the other branch: `Path(__file__)` for a bundled module then resolves
# INSIDE PyInstaller's extraction location -- for --onefile builds
# specifically, a fresh temp directory that is deleted when the process
# exits. Computing BASE_DIR from `__file__` in that case would mean every
# single launch of the packaged .exe starts with empty trade_keys.json/
# watchlist.json/etc: whatever was written on the previous run is gone.
# `sys.executable`, by contrast, is the STABLE path to the actual .exe file
# the user launched (not the temp extraction dir) in both --onefile and
# --onedir builds -- using its parent directory as BASE_DIR means the
# installed app's data lives next to the .exe itself and survives restarts,
# matching what "install this on my PC" should mean for a JSON-file-backed
# app like this one.
def _resolve_frozen_base_dir() -> Path:
    """2026-09-08: real-machine bug -- the packaged .exe was being run
    directly from PyInstaller's own `dist\\` output folder instead of
    being copied to the repo root next to main.py (build_exe.bat's last
    step, and windows_app/README.md, both say to do this -- but nothing
    stopped the app from running anyway if that step was skipped or its
    copy silently didn't happen). The old plain
    `Path(sys.executable).resolve().parent` then pointed AT `dist\\`
    itself -- a folder that holds only the .exe, none of the actual bot
    scripts or shared JSON stores (trade_keys.json, ai_key.json,
    live-params files, watchlist.json, ...). Confirmed on the user's real
    machine via windows_app's own "Мониторинг" log tail: EVERY strategy
    launch (both bots, paper AND live) failed immediately with Python's
    own `can't open file 'dist\\kc_roc_cci_wt_grid_live.py': [Errno 2] No
    such file or directory`, exit code 2 -- the scripts simply aren't in
    `dist\\`, they're one level up. Worse, silently: any trade key or AI
    key saved through the panel while running from `dist\\` was being
    written to a `dist\\...json` file that nothing else (Telegram bot,
    the *_live.py scripts run directly, or the same panel run from its
    intended location) ever reads back -- the same class of silent
    settings-divergence this project already hit once before with
    LiveBotParamsStore needing its own separate files (see this doc's
    2026-09-06 section).

    Fixed by no longer trusting the .exe's own immediate folder blindly:
    walk upward from it (a handful of levels -- comfortably covers
    `dist\\` and any similarly-shaped PyInstaller output folder) looking
    for `main.py`, the one file guaranteed to exist at the real repo
    root and nowhere else in this project, and use THAT directory as
    BASE_DIR the moment it's found. This makes the frozen app resolve
    correctly no matter which copy of itself the user happens to
    double-click -- the intended repo-root copy (found immediately, zero
    extra lookups) or the raw `dist\\` build output (found one level up)
    -- instead of depending on the user, or build_exe.bat's copy step,
    to always get the .exe's location exactly right. Falls back to the
    OLD exe-parent-directory behavior, completely unchanged, if no
    `main.py` turns up within the search depth (e.g. a copy deliberately
    moved somewhere outside the repo entirely) -- so this change can only
    ever find a BETTER answer than before, never a worse one."""
    exe_dir = Path(sys.executable).resolve().parent
    candidate = exe_dir
    for _ in range(5):
        if (candidate / "main.py").exists():
            return candidate
        parent = candidate.parent
        if parent == candidate:  # reached filesystem root, stop climbing
            break
        candidate = parent
    return exe_dir  # unchanged fallback: exactly the pre-existing behavior


if getattr(sys, "frozen", False):
    BASE_DIR = _resolve_frozen_base_dir()
else:
    BASE_DIR = Path(__file__).resolve().parent.parent
DEFAULT_WATCHLIST_FILE = BASE_DIR / "watchlist.json"
STATE_FILE = BASE_DIR / "state.json"
ACCESS_FILE = BASE_DIR / "authorized_users.json"
SCAN_SETTINGS_FILE = BASE_DIR / "scan_settings.json"
LIVE_JOURNAL_FILE = BASE_DIR / "live_trade_journal.csv"  # 2026-08-23: see publish_health.py
# 2026-08-23, round 5: keys added live via the Mini App Settings tab's
# /setkey command (see app/exchange_keys_store.py) -- separate from .env
# so the bot never has to be restarted for a newly-added key to take
# effect. Overlaid on top of exchange_credentials below at read time.
EXCHANGE_KEYS_FILE = BASE_DIR / "exchange_keys.json"
# 2026-08-23, round 8: trading-permission keys, added via /tradekey --
# deliberately a SEPARATE file from EXCHANGE_KEYS_FILE above, see
# app/trade_keys_store.py's module docstring for why.
TRADE_KEYS_FILE = BASE_DIR / "trade_keys.json"
# 2026-08-23, round 9 ("Вера"): whether the breakeven-autopilot loop is
# currently turned on -- live-toggleable via /autopilot on|off (or the Mini
# App's Торговля tab), same "own JSON file, no restart needed" pattern as
# app/scan_settings.py. See app/autopilot_settings.py.
AUTOPILOT_SETTINGS_FILE = BASE_DIR / "autopilot_settings.json"
# 2026-09-06: live-editable "max concurrent deals" cap for the two
# standalone DCA live bots (long_strategy15_latuserge_live.py,
# kc_roc_cci_wt_grid_live.py) -- was CLI-only before (--max-concurrent-deals,
# read once at process startup), now re-read every poll cycle by each live
# bot itself and editable without a restart via /maxdeals in main.py. Same
# "own JSON file, no restart needed" pattern as SCAN_SETTINGS_FILE/
# AUTOPILOT_SETTINGS_FILE above. See app/live_bot_settings.py.
LATUSERGE_MAX_DEALS_FILE = BASE_DIR / "long_strategy15_latuserge_settings.json"
KC_GRID_MAX_DEALS_FILE = BASE_DIR / "kc_roc_cci_wt_grid_settings.json"
# 2026-09-06 (later same day): windows_app/'s local admin GUI needs to store
# the money-management CLI flags each live bot should be (re)started with
# (--capital-per-deal/--leverage/--symbol/--stop-loss-pct/--telegram-alerts)
# -- see app/live_bot_settings.py's LiveBotParamsStore for why this is a
# DELIBERATELY SEPARATE file from LATUSERGE_MAX_DEALS_FILE/KC_GRID_MAX_DEALS_FILE
# above, even though those two already hold general per-bot settings: those
# files' own MaxConcurrentDealsSettings.set() blindly overwrites the WHOLE
# file with just {"max_concurrent_deals": ...} (read-then-write was never
# needed before because nothing else lived in that file) -- sharing it here
# would silently lose whatever this store just saved the next time /maxdeals
# is used. Two clean, single-purpose files avoid that risk entirely rather
# than patching MaxConcurrentDealsSettings' write path to matter.
LATUSERGE_LIVE_PARAMS_FILE = BASE_DIR / "long_strategy15_latuserge_live_params.json"
KC_GRID_LIVE_PARAMS_FILE = BASE_DIR / "kc_roc_cci_wt_grid_live_params.json"
# 2026-08-23, round 9: dedup floor for the psycho-heuristic advisory
# alerts (see app/psycho_heuristics.py + app/psycho_state.py).
PSYCHO_STATE_FILE = BASE_DIR / "psycho_state.json"
# 2026-08-23, round 9: dedup floor for the partial-take-profit ADVISORY
# messages (never auto-executed, see app/autopilot.py's module docstring
# for why) -- see app/partial_take_state.py.
PARTIAL_TAKE_STATE_FILE = BASE_DIR / "partial_take_state.json"
# 2026-08-24, round 10: the Anthropic API key that powers the optional AI
# features (see app/ai_assistant.py), added live via /setaikey -- same
# "own JSON file, no restart needed" pattern as EXCHANGE_KEYS_FILE/
# TRADE_KEYS_FILE above. See app/ai_key_store.py.
AI_KEY_FILE = BASE_DIR / "ai_key.json"
# 2026-08-25, round 14: live kill switch for the local trade-server's
# instant (no chat review) order execution -- see app/trade_server.py and
# app/instant_trade_settings.py. Separate from TRADE_SERVER_ENABLED below
# (which only controls whether the server/tunnel start at all): this one
# is checked on every single request and can be flipped instantly via
# /instanttrade on|off, no restart needed, same "own JSON file" pattern.
INSTANT_TRADE_SETTINGS_FILE = BASE_DIR / "instant_trade_settings.json"
# 2026-08-31: yesterday's end-of-day wallet-balance snapshot per exchange,
# for the automatic daily trading-report digest (main.py's
# _daily_report_worker) to compute a day-over-day return % -- see
# app/daily_report_state.py's module docstring for why this is needed
# (Bybit doesn't expose balance HISTORY directly).
DAILY_REPORT_STATE_FILE = BASE_DIR / "daily_report_state.json"
# 2026-09-03: "Screener auto-trade" -- live on/off switch PLUS the one
# global capital_usdt/leverage pair the user asked for ("выбор на какую
# сумму и плечо"), for the new _autotrade_worker (main.py). Same "own JSON
# file, no restart needed" pattern as AUTOPILOT_SETTINGS_FILE above, toggled
# via /autotrade on|off (or the Mini App's Торговля tab, same
# review-before-send flow as /autopilot). See app/autotrade_settings.py.
AUTOTRADE_SETTINGS_FILE = BASE_DIR / "autotrade_settings.json"
# 2026-09-03: dedup floor so _autotrade_worker only ever acts ONCE per
# unique fired signal (StateStore's own "sent" key, see app/state.py's
# recent_signals()) -- without this, a signal younger than
# signal_gate_max_age_minutes would be re-evaluated (and, if still eligible,
# re-traded) on every ~20s poll pass. See app/autotrade_state.py.
AUTOTRADE_STATE_FILE = BASE_DIR / "autotrade_state.json"
# 2026-09-08: windows_app/'s panel -- email notification settings (SMTP
# host/port/username/password/from/to, entered by the user themselves in
# the "Ключи"/"Уведомления" screen, same "own JSON file, no restart needed"
# pattern as everything else above). See app/notifications.py's
# EmailSettingsStore. Deliberately a SEPARATE file from TRADE_KEYS_FILE/
# AI_KEY_FILE (different credential class, no reason to couple them).
EMAIL_SETTINGS_FILE = BASE_DIR / "email_settings.json"
# 2026-09-08: dedup floor for the panel's own new-closed-trade / health-
# critical email+desktop-notification watcher (windows_app/server.py's
# background "_notify_worker") -- without this, a restart of the panel
# would re-send an email for every already-closed trade currently sitting
# in *_live_trades.csv. Records, per strategy, the row count already seen
# and the last health state already seen -- same tiny-JSON-file pattern as
# PSYCHO_STATE_FILE/PARTIAL_TAKE_STATE_FILE above.
NOTIFY_STATE_FILE = BASE_DIR / "notify_state.json"
# 2026-09-08: one backtest job (subprocess running long_strategy15_latuserge_backtest.py
# or kc_roc_cci_wt_grid_backtest.py) writes its per-symbol *_deals.csv files
# here instead of into the repo root's own long_strategy15_latuserge_backtest_out/
# kc_roc_cci_wt_grid_backtest_out folders (those are for the user's own manual
# CLI runs -- the panel gets its own subfolder per job so a panel-triggered
# run never overwrites or gets confused with a manual one). See
# app/backtest_runner.py.
PANEL_BACKTEST_OUT_DIR = BASE_DIR / "windows_app_logs" / "backtests"

# 2026-08-23, same day round 2: which exchange each .env prefix maps to,
# and whether that exchange needs a passphrase in addition to key+secret.
# Used by Settings.load() to build exchange_credentials below without
# config.py needing to import the exchange clients themselves (kept as a
# plain dict here, on purpose, for zero import-time coupling). See
# app/exchanges/ for the actual read-only clients -- this redesign
# replaced the original Bybit-only bybit_api_key/bybit_api_secret fields
# because the user trades on several exchanges and asked for an
# architecture where adding another one later doesn't require touching
# already-written code. To add an exchange: write app/exchanges/<name>.py,
# register it in app/exchanges/REGISTRY, and add one line here.
EXCHANGE_ENV_PREFIXES = {
    "bybit": ("BYBIT", False),
    "okx": ("OKX", True),
    "bitget": ("BITGET", True),
    "mexc": ("MEXC", False),
    "kucoin": ("KUCOIN", True),
    "gateio": ("GATEIO", False),
}


@dataclass
class Settings:
    telegram_token: str
    telegram_chat_id: str
    timeframe: str
    swing_left: int
    swing_right: int
    poll_seconds: int
    watchlist: list[str]  # Bybit linear perpetual symbols, e.g. ["BTCUSDT", "ZECUSDT"]
    use_htf_filter: bool
    show_rsi: bool
    github_token: str  # 2026-08-22: optional, see app/github_sync.py. Empty = site sync disabled.
    github_repo: str
    weekly_risk_budget_usdt: float  # 2026-08-23: see publish_health.py -- how much you're willing to risk per week.
    # 2026-08-23, same day round 2: {exchange_key: {"api_key":..., "api_secret":...,
    # "passphrase": ... or None}} -- see app/exchanges/. Only includes exchanges
    # whose required env vars are ALL set (passphrase included, for the exchanges
    # that need one). Empty dict = health tab stays CSV-only, same as before this
    # feature existed. Replaces the earlier bybit_api_key/bybit_api_secret fields.
    exchange_credentials: dict = field(default_factory=dict)
    # 2026-08-23, round 8: live order placement via /trade (see
    # app/trading_guard.py + main.py's _handle_trade_command). Both are
    # non-negotiable guardrails the user asked for from the start, not
    # meant to be disabled -- they're env-configurable only so the exact
    # numbers can be tuned without a code change, same reasoning as
    # weekly_risk_budget_usdt above.
    max_trade_leverage: int = 5  # hard cap on /trade's leverage argument, regardless of what the exchange allows.
    signal_gate_max_age_minutes: float = 60.0  # how "fresh" a fired signal must be for the optional "gate" /trade flag.
    # 2026-08-23, round 9 ("Вера" trading-assistant features -- see
    # app/autopilot.py + publish_health.py's daily-limit computation):
    daily_risk_limit_usdt: float = 15.0  # per-day cousin of weekly_risk_budget_usdt above -- same USDT-budget
    # style rather than a %-of-equity figure (matching the reference bot's "1.0%/день") on purpose: computing a
    # real % would need a new authenticated "account equity" API call per exchange, which none of the exchange
    # modules implement yet, and a flat-USDT figure stays consistent with how weekly_risk_budget_usdt already
    # works. Revisit if you'd rather have it as a % once an equity fetch exists.
    autopilot_breakeven_trigger_r: float = 1.0  # move stop to breakeven once unrealized profit reaches this many
    # multiples of the position's own (entry - stop_loss) distance. 1.0 = classic "risk-free once +1R" rule.
    autopilot_partial_take_trigger_r: float = 2.0  # ADVISORY-only cousin of the trigger above (see
    # app/autopilot.py's decide_partial_take_advisories) -- higher than the breakeven trigger on purpose, since
    # this is a "consider locking in some profit" suggestion, not a safety action, so it only speaks up once a
    # position is meaningfully further into profit than the point where the stop already got risk-free.
    # 2026-08-24, round 10: optional AI layer (see app/ai_assistant.py) -- explanations on /report and /ideas,
    # free-form /ai chat, and the experimental /aiidea generator. Both fields are ONLY a static .env fallback;
    # the live /setaikey command (app/ai_key_store.py) is the primary, no-restart-needed way to set the key and
    # wins on collision -- see app/ai_assistant.py's resolve_api_key(). Every AI function degrades to returning
    # None (feature silently absent, nothing else in the bot changes) when no key is configured either way.
    anthropic_api_key: str = ""  # ANTHROPIC_API_KEY -- get one at https://console.anthropic.com (API Keys),
    # separate from a claude.ai subscription; billed per-call, needs its own payment method/credits there.
    ai_model: str = "claude-sonnet-5"  # ANTHROPIC_MODEL -- 2026-08-25, round 16 follow-up: the user's real
    # /ai calls were failing ("ИИ сейчас недоступен") after adding a real key -- this default had been
    # "claude-sonnet-4-5" since round 10 and was very likely a stale/retired alias by now (Anthropic's own
    # current docs, checked live via WebFetch this round at
    # https://platform.claude.com/docs/en/models/overview and .../model-ids-and-versions, list
    # "claude-sonnet-5" as the current recommended Sonnet model id). If AI calls start failing again with a
    # "not found"-style error in the console (see app/ai_assistant.py's _call_ai(), which already logs
    # "[AI] Anthropic API error <code>: ..." to stderr on any non-200 response), re-check that same page and
    # update this again -- model names do move on.
    # 2026-08-25, round 16 follow-up #2: the model-name fix above turned out not to be the whole story --
    # the key the user actually added via /setaikey came from a third-party Anthropic-API-compatible reseller
    # (their own screenshot showed the exact same key prefix on that service's dashboard, with its own
    # "ANTHROPIC_BASE_URL" pointing at ITS OWN domain, not api.anthropic.com), which this module never had a
    # way to point at -- _call_ai() always POSTed straight to the real Anthropic API, so a key that's only
    # valid at a reseller's own base URL would fail there regardless of the model name. This field lets the
    # base URL be overridden to match whatever the key's actual issuer is; the /v1/messages path is appended
    # the same way either way (see app/ai_assistant.py) since these resellers advertise themselves as
    # "Anthropic-compatible" (same request/response shape at a different host).
    ai_base_url: str = "https://api.anthropic.com"  # ANTHROPIC_BASE_URL -- leave this alone for a real key
    # from console.anthropic.com. Only change it if your key comes from a different provider/reseller that
    # gave you its own base URL to use (they'll usually spell this out explicitly, e.g. for their own
    # Claude Code setup instructions) -- set it to exactly that URL, with NO trailing "/v1/messages" (this
    # module appends that path itself).
    # 2026-08-25, round 14: local trade-server (see app/trade_server.py) that lets the Торговля tab place a
    # real order INSTANTLY, no Telegram review-and-send step -- built at the user's explicit request after
    # asking "can we build our own server", and just as explicitly told this is the highest-risk feature in
    # the project (see that module's docstring). OFF by default (TRADE_SERVER_ENABLED unset/false) -- the bot
    # runs exactly as before, /trade via chat only, until this is deliberately turned on. Even once the
    # server/tunnel are running, instant execution ALSO needs InstantTradeSettings on (see
    # app/instant_trade_settings.py, toggled via /instanttrade on|off) -- two separate switches on purpose,
    # so the fast kill switch doesn't require touching .env or restarting the bot.
    trade_server_enabled: bool = False  # TRADE_SERVER_ENABLED
    trade_server_port: int = 8765  # TRADE_SERVER_PORT -- bound to 127.0.0.1 only, never exposed on the LAN
    # directly; only reachable from outside this machine through the Cloudflare Tunnel _TunnelManager starts.
    trade_server_allowed_origin: str = "https://ruslan875.github.io"  # TRADE_SERVER_ALLOWED_ORIGIN -- CORS
    # scoping only (tidiness, not the real security boundary -- see app/telegram_auth.py for that). Update
    # this if the Mini App is ever moved off GitHub Pages to a different origin.
    cloudflared_path: str = "cloudflared.exe"  # CLOUDFLARED_PATH -- defaults to expecting cloudflared.exe
    # sitting right next to main.py in this same folder (simplest for a non-technical setup, no PATH editing
    # needed); override if it's installed somewhere else or under a different name (e.g. plain "cloudflared"
    # on PATH). See .env.example for the download link and setup steps.

    @staticmethod
    def load() -> "Settings":
        watchlist_env = os.getenv("WATCHLIST")
        if watchlist_env:
            watchlist = [s.strip().upper() for s in watchlist_env.split(",") if s.strip()]
        elif DEFAULT_WATCHLIST_FILE.exists():
            watchlist = json.loads(DEFAULT_WATCHLIST_FILE.read_text())
        else:
            watchlist = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "ARBUSDT", "INJUSDT", "TIAUSDT"]

        exchange_credentials: dict = {}
        for exch_key, (prefix, requires_passphrase) in EXCHANGE_ENV_PREFIXES.items():
            api_key = os.getenv(f"{prefix}_API_KEY", "").strip()
            api_secret = os.getenv(f"{prefix}_API_SECRET", "").strip()
            passphrase = os.getenv(f"{prefix}_API_PASSPHRASE", "").strip()
            if api_key and api_secret and (passphrase or not requires_passphrase):
                exchange_credentials[exch_key] = {
                    "api_key": api_key,
                    "api_secret": api_secret,
                    "passphrase": passphrase or None,
                }

        return Settings(
            telegram_token=os.getenv("TELEGRAM_BOT_TOKEN", ""),
            telegram_chat_id=os.getenv("TELEGRAM_CHAT_ID", ""),
            timeframe=os.getenv("TIMEFRAME", "15m"),
            swing_left=int(os.getenv("SWING_LEFT", "3")),
            swing_right=int(os.getenv("SWING_RIGHT", "3")),
            poll_seconds=int(os.getenv("POLL_SECONDS", "60")),
            watchlist=watchlist,
            use_htf_filter=os.getenv("USE_HTF_FILTER", "true").strip().lower() not in ("0", "false", "no"),
            show_rsi=os.getenv("SHOW_RSI", "false").strip().lower() in ("1", "true", "yes"),
            github_token=os.getenv("GITHUB_TOKEN", "").strip(),
            github_repo=os.getenv("GITHUB_REPO", "ruslan875/smc-radar").strip(),
            weekly_risk_budget_usdt=float(os.getenv("WEEKLY_RISK_BUDGET_USDT", "50")),
            exchange_credentials=exchange_credentials,
            max_trade_leverage=int(os.getenv("MAX_TRADE_LEVERAGE", "5")),
            signal_gate_max_age_minutes=float(os.getenv("SIGNAL_GATE_MAX_AGE_MINUTES", "60")),
            daily_risk_limit_usdt=float(os.getenv("DAILY_RISK_LIMIT_USDT", "15")),
            autopilot_breakeven_trigger_r=float(os.getenv("AUTOPILOT_BREAKEVEN_TRIGGER_R", "1.0")),
            autopilot_partial_take_trigger_r=float(os.getenv("AUTOPILOT_PARTIAL_TAKE_TRIGGER_R", "2.0")),
            anthropic_api_key=os.getenv("ANTHROPIC_API_KEY", "").strip(),
            ai_model=os.getenv("ANTHROPIC_MODEL", "claude-sonnet-5").strip(),
            ai_base_url=os.getenv("ANTHROPIC_BASE_URL", "https://api.anthropic.com").strip().rstrip("/"),
            trade_server_enabled=os.getenv("TRADE_SERVER_ENABLED", "false").strip().lower() in ("1", "true", "yes"),
            trade_server_port=int(os.getenv("TRADE_SERVER_PORT", "8765")),
            trade_server_allowed_origin=os.getenv("TRADE_SERVER_ALLOWED_ORIGIN", "https://ruslan875.github.io").strip(),
            # Resolved against BASE_DIR (not CWD) so "cloudflared.exe sitting next to main.py" is true
            # regardless of what directory the bot happens to be launched from.
            cloudflared_path=os.getenv("CLOUDFLARED_PATH", "").strip() or str(BASE_DIR / "cloudflared.exe"),
        )
