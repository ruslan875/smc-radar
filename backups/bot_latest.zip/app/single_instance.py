"""app/single_instance.py — не дать второй копии торгового бота запуститься.

ЗАЧЕМ. 13.09 при перезапуске выяснилось, что на машине одновременно жили
ЧЕТЫРЕ копии main.py и ЧЕТЫРЕ копии kc_roc_cci_wt_grid_live.py -- последний
в режиме --live, с настоящими ордерами. Копии накопились от запусков руками:
`restart_grid_bot.bat` перед стартом убивает старые, а вот запуск
`python kc_roc_cci_wt_grid_live.py --live ...` прямо из PowerShell -- нет.

Это не теория. В журнале сделок нашёлся след: ARBUSDT, две отдельные сделки
с ОДНИМ И ТЕМ ЖЕ временем входа 2026-09-08T16:54:00+00:00, одна закрыта по
тейку, другая по стопу. Так выглядит двойной объём: две копии увидели один
сигнал и обе поставили ордер.

КАК УСТРОЕНО. Блокировка файла, которую держит ОС, пока жив процесс. Это
важнее, чем кажется: вариант «записать PID в файл и проверять» оставляет
висячие блокировки после падения или убийства процесса, и бот однажды
откажется стартовать без причины. Здесь после смерти процесса блокировка
снимается ядром сама, что бы с процессом ни случилось.

os.kill(pid, 0) для проверки живости НЕ используется намеренно: на Windows
os.kill игнорирует номер сигнала и зовёт TerminateProcess -- «проверка»
убила бы чужой процесс.

ПОВЕДЕНИЕ ПРИ ОШИБКАХ. Если блокировка занята -- отказ и понятный текст:
это ровно тот случай, ради которого модуль написан. Если механизм блокировки
вообще не заработал (экзотическая ФС, нет прав на папку) -- предупреждение и
запуск: бот, который отказывается стартовать из-за подсистемы блокировок,
хуже, чем бот без этой подстраховки.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

from app.config import BASE_DIR

LOCK_DIR = BASE_DIR


class AlreadyRunning(RuntimeError):
    pass


# Держим ссылки на открытые файлы на весь срок жизни процесса: если сборщик
# мусора закроет файл, ОС снимет блокировку, и вторая копия спокойно
# запустится -- то есть защита тихо перестанет работать.
_held: list = []


def _try_lock(fh) -> bool:
    """True -- блокировка наша. False -- занята другой копией.
    Исключение -- механизм не работает, решать вызывающему."""
    if os.name == "nt":
        import msvcrt
        try:
            msvcrt.locking(fh.fileno(), msvcrt.LK_NBLCK, 1)
            return True
        except OSError:
            return False
    import fcntl
    try:
        fcntl.flock(fh.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        return True
    except OSError:
        return False


def acquire(name: str, *, quiet: bool = False) -> None:
    """Занимает блокировку для `name` или бросает AlreadyRunning."""
    path = Path(LOCK_DIR) / f".{name}.lock"
    try:
        fh = open(path, "a+b")
        fh.seek(0)
        locked = _try_lock(fh)
    except OSError as exc:
        if not quiet:
            print(f"[{name}] не удалось воспользоваться файлом блокировки ({exc}). "
                  f"Запускаюсь без защиты от второй копии.", file=sys.stderr)
        return

    if not locked:
        fh.close()
        raise AlreadyRunning(
            f"{name} уже запущен в другом окне.\n"
            f"Две копии одной стратегии читают один файл состояния и ставят ордера по "
            f"одним и тем же сигналам -- это двойной объём вместо заданного.\n"
            f"Закрой то окно (или запусти restart_grid_bot.bat / restart_all.bat, "
            f"они сначала останавливают старые копии) и попробуй снова."
        )

    try:
        fh.seek(0)
        fh.truncate()
        fh.write(str(os.getpid()).encode("ascii"))
        fh.flush()
    except OSError:
        pass  # PID тут для человека, на саму защиту он не влияет
    _held.append(fh)


def acquire_or_exit(name: str) -> None:
    """То же, но с выходом из программы -- удобно звать из main()."""
    try:
        acquire(name)
    except AlreadyRunning as exc:
        print(f"\nОТКАЗ ЗАПУСКА: {exc}\n", file=sys.stderr)
        raise SystemExit(1)
