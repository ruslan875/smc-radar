"""Снова запустить paper-ботов вкладки «Бэктест», остановленных кнопкой «Стоп»
за последние N часов (по умолчанию 12). Счёт и сделки бота сохраняются. 2026-09-27.

    venv\\Scripts\\python.exe lab_bots_resume.py          # остановленные за 12 ч
    venv\\Scripts\\python.exe lab_bots_resume.py 48       # за 48 ч
"""
import json
import subprocess
import sys
import time
from pathlib import Path

BASE = Path(__file__).resolve().parent
BOTS = BASE / "bt_lab_bots"
hours = float(sys.argv[1]) if len(sys.argv) > 1 else 12
flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
now = time.time()
n = 0
for stop in sorted(BOTS.glob("*.stop")):
    if now - stop.stat().st_mtime > hours * 3600:
        continue
    sp = BOTS / (stop.stem + ".json")
    if not sp.exists():
        continue
    st = json.loads(sp.read_text(encoding="utf-8"))
    st.pop("stopped", None)
    sp.write_text(json.dumps(st, ensure_ascii=False, default=float), encoding="utf-8")
    stop.unlink()
    p = st["params"]
    subprocess.Popen([sys.executable, str(BASE / "lab_paper.py"), "--id", st["id"], "--params", json.dumps(p)],
                     cwd=str(BASE), creationflags=flags)
    n += 1
    print(f"запущен: {p.get('symbol')} · x{p.get('leverage')} · {str(p.get('label', ''))[:60]}")
print(f"Готово: {n} бот(ов). Через минуту в панели они будут «работает».")
