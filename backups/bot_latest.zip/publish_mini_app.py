"""publish_mini_app.py — публикует Telegram Mini App в GitHub Pages.

Заливает два файла в репозиторий, из которого Telegram открывает Mini App:

  index.html           -- сама страница (mini_app/index.html)
  vantorix-signals.js  -- движок 34 индикаторов, собранный из того же
                          indicatorEngine.ts, что считает терминал

ПОЧЕМУ ДВИЖОК ЕДЕТ РЯДОМ СО СТРАНИЦЕЙ, А НЕ С CDN. В этом проекте уже был
случай, когда cdnjs оказался недоступен на телефоне владельца и графики на
вкладке «Обзор» молча отрисовались пустыми -- без ошибки, просто белые
прямоугольники (см. комментарий в <head> у index.html). Файл, лежащий в том
же репозитории, такой отказ повторить не может.

ПОЧЕМУ СЧИТАЕМ НА ТЕЛЕФОНЕ. У Mini App нет своего сервера, а до компьютера
владельца с телефона не достучаться. Но свечи Bybit отдаёт публично, а движок
-- это чистые вычисления. Значит сигнал можно посчитать прямо в телефоне, и
он будет тем же самым, что на экране терминала: код физически один.

Перед заливкой скачивает то, что опубликовано сейчас, в
mini_app/published_backup_<дата>.html.

Запуск:      .\\venv\\Scripts\\python.exe publish_mini_app.py
Без записи:  .\\venv\\Scripts\\python.exe publish_mini_app.py --dry-run
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import requests

from app.config import BASE_DIR, Settings
from app.github_sync import GitHubSyncError, push_binary_file

LOCAL_PAGE = BASE_DIR / "mini_app" / "index.html"
LOCAL_ENGINE = BASE_DIR.parent / "terminal" / "dist-cli" / "vantorix-signals.js"
REMOTE_PAGE = "index.html"
REMOTE_ENGINE = "vantorix-signals.js"


def _published(repo: str, path: str) -> bytes | None:
    url = f"https://raw.githubusercontent.com/{repo}/main/{path}"
    try:
        resp = requests.get(url, timeout=20)
    except requests.RequestException as exc:
        print(f"  не удалось скачать текущую версию {path}: {exc}", file=sys.stderr)
        return None
    return resp.content if resp.status_code == 200 else None


def main() -> int:
    dry_run = "--dry-run" in sys.argv
    settings = Settings.load()

    if not settings.github_token:
        print("GITHUB_TOKEN пуст в .env -- публиковать нечем.", file=sys.stderr)
        return 1

    jobs: list[tuple[str, Path, bytes]] = []

    if not LOCAL_PAGE.exists():
        print(f"Нет файла {LOCAL_PAGE}.", file=sys.stderr)
        return 1
    jobs.append((REMOTE_PAGE, LOCAL_PAGE, LOCAL_PAGE.read_bytes()))

    if LOCAL_ENGINE.exists():
        jobs.append((REMOTE_ENGINE, LOCAL_ENGINE, LOCAL_ENGINE.read_bytes()))
    else:
        print(f"ВНИМАНИЕ: нет {LOCAL_ENGINE}.")
        print("Собери его: в папке terminal выполни  npm run build:signals")
        print("Без него вкладка «Сигналы» честно скажет, что движок не загрузился,")
        print("а остальные разделы будут работать как раньше.\n")

    changed = 0
    for remote, local, data in jobs:
        current = _published(settings.github_repo, remote)
        print(f"{remote}: локально {len(data):,} байт, "
              f"опубликовано {len(current):,} байт" if current is not None
              else f"{remote}: локально {len(data):,} байт, опубликованного нет")
        if current == data:
            print("  уже совпадает, пропускаю")
            continue
        if remote == REMOTE_PAGE and current is not None:
            backup = LOCAL_PAGE.parent / f"published_backup_{time.strftime('%Y%m%d-%H%M%S')}.html"
            backup.write_bytes(current)
            print(f"  бэкап прежней страницы: {backup}")
        if dry_run:
            print("  --dry-run: не заливаю")
            continue
        try:
            push_binary_file(settings.github_token, settings.github_repo, remote, data,
                             f"publish {remote} (VANTORIX Mini App)")
        except GitHubSyncError as exc:
            print(f"  публикация не удалась: {exc}", file=sys.stderr)
            return 1
        print("  опубликовано")
        changed += 1

    if dry_run:
        print("\n--dry-run: ничего не залито.")
        return 0

    print(f"\nГотово, файлов обновлено: {changed}.")
    if changed:
        print("GitHub Pages обновляется примерно минуту. Telegram кэширует Mini App --")
        print("закрой его полностью и открой заново.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
