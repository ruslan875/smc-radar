"""mt5_probe.py — 2026-11-14. Проверка связи TradeOS ↔ MetaTrader 5 (БЕЗ сделок): счёт, символы золота/нефти/индексов/акций.
Итог: mt5_probe.txt"""
import json, sys, time
from pathlib import Path
B = Path(__file__).resolve().parent
out = []
try:
    import MetaTrader5 as mt5
except Exception as e:
    (B / "mt5_probe.txt").write_text(f"нет модуля MetaTrader5: {e}", encoding="utf-8"); sys.exit(1)
ok = mt5.initialize()
out.append(f"initialize: {ok} {mt5.last_error()}")
if ok:
    ti = mt5.terminal_info(); ai = mt5.account_info()
    out.append(f"терминал: {ti.company if ti else '?'} · алготрейдинг разрешён: {ti.trade_allowed if ti else '?'} · связь: {ti.connected if ti else '?'}")
    if ai:
        out.append(f"счёт: {ai.login} · сервер {ai.server} · демо: {ai.trade_mode == 0} · баланс {ai.balance} {ai.currency} · плечо 1:{ai.leverage} · "
                   f"режим {'hedge' if ai.margin_mode == 2 else 'netting' if ai.margin_mode == 1 else ai.margin_mode}")
    keys = ("XAU", "GOLD", "XAG", "SILVER", "OIL", "WTI", "BRENT", "UKO", "USO", "NAS", "US100", "USTEC", "NDX", "SPX", "US500",
            "TSLA", "AAPL", "NVDA", "MU", "INTC", "MSTR", "QQQ", "AMZN", "META", "COIN", "BTC", "ETH")
    syms = mt5.symbols_get() or []
    out.append(f"всего символов: {len(syms)}")
    for s in syms:
        n = s.name.upper()
        if any(k in n for k in keys):
            out.append(f"  {s.name:14s} {s.description[:34]:34s} · контракт {s.trade_contract_size} · лот мин {s.volume_min} шаг {s.volume_step} · "
                       f"знаков {s.digits} · торговля {s.trade_mode} · путь {s.path}")
    mt5.shutdown()
(B / "mt5_probe.txt").write_text("\n".join(out), encoding="utf-8")
print("\n".join(out))
