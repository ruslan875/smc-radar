@echo off
rem 2026-09-06: one-time build of a standalone SMCSignalBotPanel.exe from
rem windows_app/. Run this from anywhere by double-clicking it -- it changes
rem into its own folder first. Needs Python + pip (already installed, since
rem the rest of this project already needs them) and internet access once,
rem to install PyInstaller itself.
cd /d "%~dp0"

rem 2026-09-06, added after the FIRST real build on the user's machine: this
rem project's own dependencies (pandas, requests, python-dotenv, ...) live
rem inside venv\, not the global/system Python -- see start_bot.bat, which
rem does exactly this same "call venv\Scripts\activate.bat" before running
rem anything. Without this, `python -m pip install pyinstaller` and
rem `pyinstaller ...` below would run against the GLOBAL Python, which does
rem not have dotenv/pandas/requests installed -- PyInstaller can only bundle
rem what's actually importable in the environment it's invoked from, so the
rem built .exe would crash immediately with
rem "ModuleNotFoundError: No module named 'dotenv'" (exactly what happened
rem before this fix, twice -- the first fix attempt, adding
rem hiddenimports=["dotenv"] to the .spec, did not help, because the real
rem problem was never PyInstaller's import *detection*, it was that dotenv
rem was not installed at all in the Python that ran pyinstaller).
if not exist "venv\Scripts\activate.bat" (
    echo venv not found next to this file. Run the setup steps from the
    echo instructions first ^(python -m venv venv, pip install -r requirements.txt^)
    echo before building the .exe -- PyInstaller needs to run inside the SAME
    echo environment that already has pandas/requests/python-dotenv installed.
    pause
    exit /b 1
)
call venv\Scripts\activate.bat

echo Installing PyInstaller (one-time, skips if already installed)...
python -m pip install --upgrade pyinstaller
if errorlevel 1 (
    echo.
    echo Could not install PyInstaller. Check your internet connection / pip setup and try again.
    pause
    exit /b 1
)

echo.
echo Building SMCSignalBotPanel.exe ...
rem 2026-09-08: --noconfirm --clean added after a real repro on the user's
rem machine -- PyInstaller's own incremental-build cache decided nothing
rem needed rebuilding except the final EXE-wrapping step ("Rebuilding
rem EXE-00.toc because pkg is more recent"), and silently reused an OLDER
rem cached copy of the windows_app/static folder (datas= in the .spec)
rem instead of picking up freshly-edited index.html/server.py -- so the
rem resulting .exe kept showing yesterday's design no matter how many times
rem it was rebuilt. --clean wipes PyInstaller's own cache + this project's
rem build\ folder before every build, forcing a full re-scan of datas= every
rem single time (slightly slower, but a stale bundle is a much worse
rem failure mode than a few extra seconds). --noconfirm skips the
rem interactive "replace existing dist\...exe?" prompt, which would
rem otherwise silently hang build_exe.bat waiting for a keypress that never
rem comes when it's run non-interactively.
python -m PyInstaller --noconfirm --clean windows_app\SMCSignalBotPanel.spec
if errorlevel 1 (
    echo.
    echo Build failed -- see the error above. This exact build was not tested on a real
    echo Windows machine ahead of time (see windows_app/README.md), so please share the
    echo error output if you'd like help fixing it.
    pause
    exit /b 1
)

echo.
echo Build finished: dist\SMCSignalBotPanel.exe
echo IMPORTANT: copy dist\SMCSignalBotPanel.exe into THIS folder (next to main.py) before
echo running it -- it needs to sit next to trade_keys.json/watchlist.json/etc to see the
echo same data as the rest of this bot, not off in a separate dist\ subfolder.
copy /Y "dist\SMCSignalBotPanel.exe" "%~dp0SMCSignalBotPanel.exe"
echo Copied to %~dp0SMCSignalBotPanel.exe -- double-click it to run the panel.
pause
