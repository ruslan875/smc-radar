# Тест: перенос стопа в безубыток (+1R / +1.5R) для Пробоя канала 4h и Donchian 20 по тренду 4h
import sys, glob, os, numpy as np, pandas as pd
C = sys.argv[1]
def load(p):
    d=pd.read_csv(p); d.index=pd.to_datetime(d.t,unit='ms')
    return d[['o','h','l','c']].astype(float).resample('4h').agg({'o':'first','h':'max','l':'min','c':'last'}).dropna()
def chan_sig(d,N=100):
    c=d.c.values; out={}; x=np.arange(N); xm=x.mean()
    mid=np.full(len(c),np.nan); sd=mid.copy()
    for i in range(N-1,len(c)):
        y=c[i-N+1:i+1]; b=((x-xm)*(y-y.mean())).sum()/((x-xm)**2).sum(); a=y.mean()-b*xm
        mid[i]=a+b*(N-1); sd[i]=np.sqrt(((y-a-b*x)**2).mean())
    for i in range(N,len(c)):
        if c[i]>mid[i]+2*sd[i] and c[i-1]<=mid[i-1]+2*sd[i-1]: out[i]=(1,mid[i])
        elif c[i]<mid[i]-2*sd[i] and c[i-1]>=mid[i-1]-2*sd[i-1]: out[i]=(-1,mid[i])
    return out,2.0
def don_sig(d,N=20):
    h,l,c=d.h.values,d.l.values,d.c.values; e=d.c.ewm(span=200,adjust=False).mean().values; out={}
    for i in range(200,len(c)):
        up,lo=h[i-N:i].max(),l[i-N:i].min(); m=(up+lo)/2
        if c[i]>up and c[i]>e[i]: out[i]=(1,m)
        elif c[i]<lo and c[i]<e[i]: out[i]=(-1,m)
    return out,3.0
def run(d,sig,rr,be):
    H,L,Cc=d.h.values,d.l.values,d.c.values; res=[]; i=0; n=len(Cc)
    keys=sorted(sig)
    nxt=0
    for i in keys:
        if i<nxt: continue
        s,st=sig[i]; e=Cc[i]; risk=abs(e-st)
        if risk<=0: continue
        sl=st; tp=e+s*rr*risk; moved=False; r=None
        for j in range(i+1,min(n,i+101)):
            if (s==1 and L[j]<=sl) or (s==-1 and H[j]>=sl): r=(0.0 if moved else -1.0); break
            if (s==1 and H[j]>=tp) or (s==-1 and L[j]<=tp): r=rr; break
            if be and not moved and ((s==1 and H[j]>=e+be*risk) or (s==-1 and L[j]<=e-be*risk)):
                sl=e+s*0.1*risk; moved=True   # безубыток +0.1R (покрыть комиссию)
                if moved: pass
        else:
            j=min(n-1,i+100); r=s*(Cc[j]-e)/risk
        if moved and r==0.0: r=0.1
        r-=0.0011*e/risk; res.append((d.index[i],r)); nxt=j+1
    return pd.DataFrame(res,columns=['t','r'])
files=sorted(glob.glob(os.path.join(C,'binance','*_1h.csv')))
data={os.path.basename(f)[:-7]:load(f) for f in files}
for name,fn in (('Пробой канала 4h 2R',chan_sig),('Donchian 20 тренд 4h 3R',don_sig)):
    sigs={k:fn(d) for k,d in data.items()}
    for be in (None,1.0,1.5):
        tot=[];h1=h2=0;ok=0
        for k,d in data.items():
            sg,rr=sigs[k]; t=run(d,sg,rr,be); mid=d.index[0]+(d.index[-1]-d.index[0])/2
            a,b=t[t.t<mid].r.sum(),t[t.t>=mid].r.sum(); h1+=a;h2+=b; ok+=(a>0 and b>0); tot.append(t)
        t=pd.concat(tot)
        print(f"{name:26} БУ {'нет' if be is None else f'при +{be}R':8} сделок {len(t):5}  R {t.r.sum():+7.1f}  {t.r.mean():+.3f}/сд  в плюсе {100*(t.r>0).mean():.0f}%  H1 {h1:+.0f} H2 {h2:+.0f}  ок {ok}/{len(data)}")
