"""Проверка прав API-ключей Bybit — ТОЛЬКО ЧТЕНИЕ.

Что делает: для каждого ключа, настроенного в trade_keys.json, спрашивает
у самой биржи её же мнение о правах этого ключа (эндпоинт /v5/user/query-api)
и печатает результат.

Чего НЕ делает: не ставит и не отменяет ордера, не меняет плечо, не трогает
позиции, не меняет ни одной настройки. Ни ключ, ни секрет на экран не
выводятся — только первые 6 символов публичной части, чтобы можно было
сопоставить со списком в кабинете Bybit.

Запуск из папки проекта:
    venv\\Scripts\\python.exe check_api_keys.py
"""
from __future__ import annotations

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from app.config import TRADE_KEYS_FILE
from app.trade_keys_store import TradeKeysStore
from app.exchanges.bybit import _signed_get
from app.data import DataError

# Те же id стратегий, что использует сам бот в get_for_strategy(...)
STRATEGIES = ["latuserge", "kc_roc"]
EXCH = "bybit"


def mask(api_key: str) -> str:
    return (api_key[:6] + "…") if api_key else "(пусто)"


def describe(api_key: str, api_secret: str) -> str:
    """Спрашивает биржу о правах ключа. Только GET, ничего не меняет."""
    try:
        payload = _signed_get("/v5/user/query-api", api_key, api_secret, {})
    except DataError as exc:
        return f"ОШИБКА при опросе биржи: {exc}"
    except Exception as exc:                       # noqa: BLE001
        return f"ОШИБКА (неожиданная): {exc.__class__.__name__}: {exc}"

    r = payload.get("result", {}) or {}
    ro = r.get("readOnly")
    ro_txt = {0: "НЕТ (можно торговать)", 1: "ДА — ТОЛЬКО ЧТЕНИЕ"}.get(ro, f"неизвестно ({ro!r})")

    perms = r.get("permissions", {}) or {}
    granted = {k: v for k, v in perms.items() if v}

    lines = [f"read-only: {ro_txt}"]
    if granted:
        lines.append("разрешения: " + "; ".join(f"{k}={','.join(v)}" for k, v in granted.items()))
    else:
        lines.append("разрешения: (пусто)")

    ips = r.get("ips") or []
    lines.append("ограничение по IP: " + (", ".join(ips) if ips else "нет"))
    if r.get("expiredAt"):
        lines.append(f"истекает: {r['expiredAt']}")
    return "\n      ".join(lines)


def main() -> int:
    print(f"Файл ключей: {TRADE_KEYS_FILE}")
    if not Path(TRADE_KEYS_FILE).exists():
        print("НЕ НАЙДЕН — ключи ещё не сохранены.")
        return 1

    store = TradeKeysStore(Path(TRADE_KEYS_FILE))

    print("\n" + "=" * 70)
    print("ОБЩИЙ ключ (используется, если у стратегии нет своего)")
    print("=" * 70)
    shared = store.get_all().get(EXCH)
    if not shared:
        print("  не задан")
    else:
        print(f"  ключ {mask(shared.get('api_key', ''))}")
        print(f"      {describe(shared['api_key'], shared['api_secret'])}")

    for sid in STRATEGIES:
        print("\n" + "=" * 70)
        print(f"Стратегия: {sid}")
        print("=" * 70)
        own = store.has_dedicated_key(sid, EXCH)
        creds = store.get_for_strategy(sid, EXCH)
        if creds is None:
            print("  ключа нет вообще — бот НЕ сможет торговать")
            continue
        print(f"  свой ключ: {'ДА' if own else 'НЕТ — берётся общий'}")
        print(f"  бот реально возьмёт: {mask(creds.get('api_key', ''))}")
        print(f"      {describe(creds['api_key'], creds['api_secret'])}")

    print("\n" + "=" * 70)
    print("ЧТО ДОЛЖНО БЫТЬ: у строки «бот реально возьмёт» для ОБЕИХ стратегий")
    print("read-only должно быть «НЕТ (можно торговать)». Если там «ТОЛЬКО")
    print("ЧТЕНИЕ» — именно поэтому ордера отклоняются с ошибкой 10005.")
    print("=" * 70)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
