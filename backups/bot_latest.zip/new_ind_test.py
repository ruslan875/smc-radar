# -*- coding: utf-8 -*-
"""Честный тест 4 присланных индикаторов (2026-10-08): SMC Bot Logic, Scalp (iTradeALG), Cipher B, SCALP Algo V3.
Вход по закрытию свечи сигнала. Для индикаторов без выхода: стоп по логике индикатора, тейк 2R.
SCALP Algo — свои выходы (TP 0.9/1.8/3.6/5 %, SL 3% от линии, разворот по встречному сигналу).
Комиссия: крипта 0.055%/сторона, TradFi 0.005%/сторона. Половины истории считаются отдельно."""
import os, sys, glob
import numpy as np, pandas as pd
try: sys.stdout.reconfigure(encoding="utf-8")
except Exception: pass
HERE = os.path.dirname(os.path.abspath(__file__))
CACHE = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "market_cache")

def load(p, tf):
    d = pd.read_csv(p); d.index = pd.to_datetime(d.t.astype("int64"), unit="ms")
    d = d[["o", "h", "l", "c"]].astype(float)
    d = d[(d.h > 0) & (d.l > 0)]
    if tf != "raw":
        d = d.resample(tf).agg({"o": "first", "h": "max", "l": "min", "c": "last"}).dropna()
    return d

def rma(x, n): return pd.Series(x).ewm(alpha=1 / n, adjust=False).mean().values
def atr(d, n=14):
    tr = np.maximum(d.h - d.l, np.maximum((d.h - d.c.shift()).abs(), (d.l - d.c.shift()).abs()))
    return rma(tr.fillna(d.h - d.l).values, n)
def rsi(c, n=14):
    ch = np.diff(c, prepend=c[0]); up = rma(np.maximum(ch, 0), n); dn = rma(np.maximum(-ch, 0), n)
    return 100 - 100 / (1 + up / np.where(dn == 0, 1e-12, dn))

# ---------- общий симулятор: сигналы (i, side, stop) -> R ----------
def sim_r(d, sigs, rr, fee):
    H, L, C = d.h.values, d.l.values, d.c.values; out = []; busy = -1
    for i, s, st in sigs:
        if i <= busy or i >= len(C) - 1: continue
        e = C[i]; risk = abs(e - st)
        if risk <= 0 or risk / e > 0.15 or (st - e) * s > 0: continue
        tp = e + s * rr * risk; r = None; j = i + 1
        while j < len(C):
            if (L[j] <= st) if s > 0 else (H[j] >= st): r = -1.0; break
            if (H[j] >= tp) if s > 0 else (L[j] <= tp): r = rr; break
            j += 1
        if r is None: r = s * (C[-1] - e) / risk; j = len(C) - 1
        out.append((d.index[i], r - 2 * fee * e / risk)); busy = j
    return out

# ---------- 1. SMC Bot Logic ----------
def swing_state(d, L=3, R=3):
    H, Lo = d.h.values, d.l.values; n = len(H)
    h1 = np.full(n, np.nan); l1 = np.full(n, np.nan); dr = np.zeros(n)
    a = b = c_ = e = np.nan
    for i in range(n):
        k = i - R
        if k - L >= 0:
            if H[k] == H[k - L:i + 1].max() and (H[k - L:k] < H[k]).all() and (H[k + 1:i + 1] < H[k]).all(): b, a = a, H[k]
            if Lo[k] == Lo[k - L:i + 1].min() and (Lo[k - L:k] > Lo[k]).all() and (Lo[k + 1:i + 1] > Lo[k]).all(): e, c_ = c_, Lo[k]
        h1[i], l1[i] = a, c_
        if not np.isnan([a, b, c_, e]).any():
            dr[i] = 1 if (a > b and c_ > e) else -1 if (a < b and c_ < e) else 0
    return dr, h1, l1

def smc(d, htf, mode):
    O, H, L, C = d.o.values, d.h.values, d.l.values, d.c.values; A = atr(d)
    dr, h1, l1 = swing_state(d)
    hd = np.zeros(len(C))
    if htf:
        hh = d.resample(htf).agg({"o": "first", "h": "max", "l": "min", "c": "last"}).dropna()
        hdir = pd.Series(swing_state(hh)[0], index=hh.index).shift(1)   # только закрытые свечи HTF
        hd = hdir.reindex(d.index, method="ffill").fillna(0).values
    ok = lambda s, i: hd[i] == 0 or hd[i] == s
    sigs, pend = [], []
    for i in range(1, len(C)):
        if np.isnan(A[i]): continue
        # реакция от зон
        keep = []
        for z in pend:
            s, top, bot, t0 = z
            if i - t0 > 60: continue
            if L[i] <= top and H[i] >= bot and abs(C[i] - O[i]) >= 0.35 * A[i] and \
               ((s > 0 and C[i] > (top + bot) / 2 and C[i] >= O[i]) or (s < 0 and C[i] < (top + bot) / 2 and C[i] <= O[i])):
                if mode in ("zone", "all"): sigs.append((i, s, bot - 0.15 * A[i] if s > 0 else top + 0.15 * A[i]))
                continue
            keep.append(z)
        pend = keep
        # слом структуры -> новая зона
        if not np.isnan(h1[i]) and not np.isnan(l1[i]):
            s = 1 if (C[i] > h1[i] and C[i - 1] <= h1[i]) else -1 if (C[i] < l1[i] and C[i - 1] >= l1[i]) else 0
            if s and ok(s, i):
                ob = next((k for k in range(12) if i - k >= 0 and ((C[i - k] < O[i - k]) if s > 0 else (C[i - k] > O[i - k]))), -1)
                if ob >= 0:
                    top, bot = H[i - ob], L[i - ob]
                    for c in range(1, ob):
                        if s > 0 and H[i - c - 1] < L[i - c + 1]: ft, fb = L[i - c + 1], H[i - c - 1]
                        elif s < 0 and L[i - c - 1] > H[i - c + 1]: ft, fb = L[i - c - 1], H[i - c + 1]
                        else: continue
                        if fb <= top and ft >= bot: top, bot = max(top, ft), min(bot, fb)
                        break
                    pend.append((s, top, bot, i))
        # снятие ликвидности
        if mode in ("sweep", "all"):
            if not np.isnan(h1[i]) and H[i] > h1[i] and C[i] < h1[i] and C[i] < O[i] and ok(-1, i): sigs.append((i, -1, H[i] + 0.1 * A[i]))
            elif not np.isnan(l1[i]) and L[i] < l1[i] and C[i] > l1[i] and C[i] > O[i] and ok(1, i): sigs.append((i, 1, L[i] - 0.1 * A[i]))
    return sigs

# ---------- 2. Scalp (iTradeALG): возврат после пробоя 14-барного экстремума ----------
def scalp(d, n=14):
    hh = d.h.rolling(n).max().shift().values; ll = d.l.rolling(n).min().shift().values
    C, H, L = d.c.values, d.h.values, d.l.values
    bull = C > hh; bear = C < ll; sigs = []
    for i in range(n + 2, len(C)):
        if bear[i - 1] and not bear[i]: sigs.append((i, 1, L[i - n:i + 1].min()))
        elif bull[i - 1] and not bull[i]: sigs.append((i, -1, H[i - n:i + 1].max()))
    return sigs

# ---------- 3. Cipher B: большие точки WaveTrend (пересечение в перепроданности/перекупленности) ----------
def ema(x, n): return pd.Series(x).ewm(span=n, adjust=False).mean().values
def cipher(d, dots_only=True):
    src = ((d.h + d.l + d.c) / 3).values
    esa = ema(src, 9); de = ema(np.abs(src - esa), 9); ci = (src - esa) / (0.015 * np.where(de == 0, 1e-12, de))
    w1 = ema(ci, 12); w2 = pd.Series(w1).rolling(3).mean().values; A = atr(d); C = d.c.values
    sigs = []
    for i in range(60, len(C)):
        cross = (w1[i] - w2[i]) * (w1[i - 1] - w2[i - 1]) < 0
        if cross and w1[i] > w2[i] and w2[i] <= -53: sigs.append((i, 1, C[i] - 1.5 * A[i]))
        elif cross and w1[i] < w2[i] and w2[i] >= 53: sigs.append((i, -1, C[i] + 1.5 * A[i]))
    return sigs

# ---------- 4. SCALP Algo V3 (стратегия со своими выходами) ----------
def scalp_algo(d, fee, sens=200, tps=(0.9, 1.8, 3.6, 5.0), qtys=(0.30, 0.30, 0.15, 0.25), slp=3.0):
    O, H, L, C = d.o.values, d.h.values, d.l.values, d.c.values
    hl = d.h.rolling(sens).max().values; ll = d.l.rolling(sens).min().values; rg = hl - ll
    f236 = hl - rg * 0.236; f5 = hl - rg * 0.5; f786 = hl - rg * 0.786
    R = np.trunc(rsi(C) * 100) / 100; a5 = atr(d, 5); am = pd.Series(a5).rolling(5).mean().values
    filt = (a5 >= am) & ((R > 45) | (R < 10))
    lt = st_ = False; pos = None; out = []
    def close(p, px, i, part=1.0):
        return p["side"] * (px - p["e"]) / p["e"] * 100 * part - fee * 100 * part
    for i in range(sens, len(C) - 1):
        # выходы по открытой позиции на этой свече
        if pos:
            s = pos["side"]
            for k in range(pos["k"], 4):
                lvl = pos["e"] * (1 + s * tps[k] / 100)
                if (H[i] >= lvl) if s > 0 else (L[i] <= lvl):
                    pos["pnl"] += close(pos, lvl, i, qtys[k]); pos["left"] -= qtys[k]; pos["k"] = k + 1
                else: break
            if pos["left"] <= 1e-9:
                out.append((pos["t"], pos["pnl"] - fee * 100)); pos = None
            elif (L[i] < pos["sl"]) if s > 0 else (H[i] > pos["sl"]):
                pos["pnl"] += close(pos, O[i + 1], i, pos["left"]); out.append((pos["t"], pos["pnl"] - fee * 100)); pos = None
        cl = C[i] >= f5[i] and C[i] >= f236[i] and not lt and filt[i]
        cs = C[i] <= f5[i] and C[i] <= f786[i] and not st_ and filt[i]
        sig = 1 if cl else -1 if cs else 0
        if cl: lt, st_ = True, False
        elif cs: st_, lt = True, False
        if sig:
            if pos and pos["side"] != sig:
                pos["pnl"] += close(pos, O[i + 1], i, pos["left"]); out.append((pos["t"], pos["pnl"] - fee * 100)); pos = None
            if not pos:
                e = O[i + 1]; line = f5[i]
                pos = {"side": sig, "e": e, "t": d.index[i], "sl": line - sig * e * slp / 100, "k": 0, "left": 1.0, "pnl": 0.0}
    return out

# ---------- прогон ----------
def summarize(name, group, per):
    p = pd.DataFrame(per, columns=["sym", "n", "tot", "h1", "h2", "gw", "gl"])
    if p.empty or p.n.sum() == 0: return None
    ok = ((p.h1 > 0) & (p.h2 > 0)).sum(); pf = p.gw.sum() / max(p.gl.sum(), 1e-9)
    v = "✅" if p.h1.sum() > 0 and p.h2.sum() > 0 and ok > len(p) / 2 else "❌"
    return dict(вердикт=v, система=name, рынок=group, сделок=int(p.n.sum()), PF=round(pf, 2), итог=round(p.tot.sum(), 1),
                на_сделку=round(p.tot.sum() / p.n.sum(), 3), половина1=round(p.h1.sum(), 1), половина2=round(p.h2.sum(), 1),
                инстр_ok=f"{ok}/{len(p)}", лучшие=", ".join(f"{a}{b:+.0f}" for a, b in p.sort_values("tot", ascending=False)[["sym", "tot"]].head(3).values))

def main():
    Y = os.path.join(CACHE, "yahoo"); B = os.path.join(CACHE, "binance")
    sets = [
        ("TradFi 1h", [os.path.join(Y, f) for f in ("GC_F_1h.csv", "EURUSD_X_1h.csv")], "raw", 0.00005, "4h"),
        ("TradFi 4h", [os.path.join(Y, f) for f in ("GC_F_1h.csv", "EURUSD_X_1h.csv")], "4h", 0.00005, "1D"),
        ("TradFi 1D", sorted(glob.glob(os.path.join(Y, "*_1d.csv"))), "raw", 0.00005, "W"),
        ("Крипта 1h", sorted(glob.glob(os.path.join(B, "*_1h.csv"))), "raw", 0.00055, "4h"),
        ("Крипта 4h", sorted(glob.glob(os.path.join(B, "*_1h.csv"))), "4h", 0.00055, "1D"),
    ]
    systems = [
        ("SMC: реакция от OB/FVG, 2R", lambda d, f, h: sim_r(d, smc(d, h, "zone"), 2, f)),
        ("SMC: снятие ликвидности, 2R", lambda d, f, h: sim_r(d, smc(d, h, "sweep"), 2, f)),
        ("SMC: всё вместе, 2R", lambda d, f, h: sim_r(d, smc(d, h, "all"), 2, f)),
        ("Scalp: возврат после пробоя 14, 2R", lambda d, f, h: sim_r(d, scalp(d), 2, f)),
        ("Cipher B: большие точки WT, 2R", lambda d, f, h: sim_r(d, cipher(d), 2, f)),
        ("SCALP Algo V3 (свои TP/SL, % на сделку)", lambda d, f, h: scalp_algo(d, f)),
    ]
    rows = []
    for gname, files, tf, fee, htf in sets:
        data = {}
        for f in files:
            if os.path.exists(f):
                d = load(f, tf)
                if len(d) > 300: data[os.path.basename(f).split("_")[0].replace("USDT", "")] = d
        for sname, fn in systems:
            per = []
            for sym, d in data.items():
                t = pd.DataFrame(fn(d, fee, htf), columns=["t", "r"])
                if t.empty: continue
                mid = d.index[0] + (d.index[-1] - d.index[0]) / 2
                per.append((sym, len(t), t.r.sum(), t[t.t < mid].r.sum(), t[t.t >= mid].r.sum(), t.r[t.r > 0].sum(), -t.r[t.r < 0].sum()))
            s = summarize(sname, gname, per)
            if s:
                rows.append(s)
                print(f"{s['вердикт']} {gname:10} {sname:42} сд {s['сделок']:5} PF {s['PF']:5} итог {s['итог']:+8.1f} ({s['на_сделку']:+.3f}) H1 {s['половина1']:+7.1f} H2 {s['половина2']:+7.1f} ок {s['инстр_ok']}  [{s['лучшие']}]", flush=True)
    pd.DataFrame(rows).to_csv(os.path.join(HERE, "new_indicators_test.csv"), index=False, encoding="utf-8-sig")

if __name__ == "__main__":
    main()
