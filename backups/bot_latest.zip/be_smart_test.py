# Умный безубыток: после +1R переносим стоп в БУ ТОЛЬКО если рынок показывает слабость (проверка на закрытии каждой 4h свечи)
import sys, glob, os, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from be_test import load, chan_sig, don_sig
C = sys.argv[1]
def feats(d):
    c=d.c; dl=c.diff(); up=dl.clip(lower=0).ewm(alpha=1/14,adjust=False).mean(); dn=(-dl.clip(upper=0)).ewm(alpha=1/14,adjust=False).mean()
    rsi=(100-100/(1+up/dn)).values; ema=c.ewm(span=20,adjust=False).mean().values
    rng=(d.h-d.l).replace(0,np.nan); uw=((d.h-d[['o','c']].max(axis=1))/rng).fillna(0).values; lw=((d[['o','c']].min(axis=1)-d.l)/rng).fillna(0).values
    return dict(rsi=rsi,ema=ema,uw=uw,lw=lw)
def weak(rule,f,j,s,C):
    if rule=='rsi': return (f['rsi'][j]>75) if s==1 else (f['rsi'][j]<25)
    if rule=='wick': return (f['uw'][j]>0.5) if s==1 else (f['lw'][j]>0.5)
    if rule=='ema': return (C[j]<f['ema'][j]) if s==1 else (C[j]>f['ema'][j])
    if rule=='any': return weak('rsi',f,j,s,C) or weak('wick',f,j,s,C) or weak('ema',f,j,s,C)
def run(d,sig,rr,rule,f):
    H,L,Cc=d.h.values,d.l.values,d.c.values; res=[]; n=len(Cc); nxt=0
    for i in sorted(sig):
        if i<nxt: continue
        s,st=sig[i]; e=Cc[i]; risk=abs(e-st)
        if risk<=0: continue
        sl=st; tp=e+s*rr*risk; armed=moved=False; r=None
        for j in range(i+1,min(n,i+101)):
            if (s==1 and L[j]<=sl) or (s==-1 and H[j]>=sl): r=0.1 if moved else -1.0; break
            if (s==1 and H[j]>=tp) or (s==-1 and L[j]<=tp): r=rr; break
            if not armed and ((s==1 and H[j]>=e+risk) or (s==-1 and L[j]<=e-risk)): armed=True
            if rule and armed and not moved and weak(rule,f,j,s,Cc): sl=e+s*0.1*risk; moved=True
        else:
            j=min(n-1,i+100); r=s*(Cc[j]-e)/risk
        r-=0.0011*e/risk; res.append((d.index[i],r)); nxt=j+1
    return pd.DataFrame(res,columns=['t','r'])
data={os.path.basename(f)[:-7]:load(f) for f in sorted(glob.glob(os.path.join(C,'binance','*_1h.csv')))}
F={k:feats(d) for k,d in data.items()}
for name,fn in (('Пробой канала 2R',chan_sig),('Donchian 20 тренд 3R',don_sig)):
    sigs={k:fn(d) for k,d in data.items()}
    for rule in (None,'rsi','wick','ema','any'):
        tot=[];h1=h2=0;ok=0
        for k,d in data.items():
            sg,rr=sigs[k]; t=run(d,sg,rr,rule,F[k]); mid=d.index[0]+(d.index[-1]-d.index[0])/2
            a,b=t[t.t<mid].r.sum(),t[t.t>=mid].r.sum(); h1+=a;h2+=b; ok+=(a>0 and b>0); tot.append(t)
        t=pd.concat(tot)
        print(f"{name:22} {str(rule):5} R {t.r.sum():+7.1f}  {t.r.mean():+.3f}/сд  в плюсе {100*(t.r>0).mean():.0f}%  H1 {h1:+.0f} H2 {h2:+.0f} ок {ok}/10")
