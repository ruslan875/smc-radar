@echo off
cd /d %~dp0
if exist venv\Scripts\python.exe (venv\Scripts\python.exe lux_fbo_test.py) else (python lux_fbo_test.py)
