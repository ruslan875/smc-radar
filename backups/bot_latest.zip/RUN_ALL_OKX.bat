@echo off
chcp 65001 >nul
title ВСЕ ТЕСТЫ OKX (одно окно)
cd /d D:\VANTORIX\bot
if exist venv\Scripts\python.exe (set PY="%CD%\venv\Scripts\python.exe") else (set PY=python)
if not exist strats_okx\cache mkdir strats_okx\cache
if not exist okx_native_cache mkdir okx_native_cache
set LOG=%CD%\ALL_OKX_REPORT.txt
echo ВСЕ ТЕСТЫ OKX %date% %time% > "%LOG%"

echo.
echo [1/3] Родные настройки: Pavlova и R4 ...
%PY% okx_native_run.py
type okx_native_report.txt >> "%LOG%"

echo.
echo [2/3] 13 стратегий движка (Larry, SR Power, Ichimoku, VSA ...) ...
pushd strats_okx
%PY% run_ex.py
popd
if exist strats_okx\strats_okx_bybit_report.txt type strats_okx\strats_okx_bybit_report.txt >> "%LOG%"

echo.
echo [3/3] Порты (Third Eye, Gaussian, LiqTherm, Order Block ...) на 10 монетах, 1h и 4h ...
set SYM=BTC/USDT ETH/USDT SOL/USDT XRP/USDT DOGE/USDT BNB/USDT ADA/USDT LINK/USDT AVAX/USDT HYPE/USDT
for %%T in (1h 4h) do (
  echo ===== ПОРТЫ %%T ===== >> "%LOG%"
  %PY% run_backtests.py --symbols %SYM% --timeframe %%T --exchange okx --market swap --start 2024-01-01 --end 2026-09-30 --commission 0.05 --slippage-pct 0.03 --suffix _okx_%%T >> "%LOG%" 2>&1
)

echo.
echo ГОТОВО. Пришлите один файл: ALL_OKX_REPORT.txt
pause
