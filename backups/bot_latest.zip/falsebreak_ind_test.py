"""falsebreak_ind_test.py — 2026-10-05. Индикатор «False Breakouts» (TradingView, vikprimus) — точный перенос логики и проверка на истории.
Логика индикатора: уровни — развороты 15/15 (ta.pivothigh/pivotlow, подтверждаются через 15 свечей), последний уровень каждого типа.
  ЛП-1 (одна свеча): тень проколола уровень, закрытие обратно, прошлое закрытие тоже по эту сторону.
  ЛП-2 (две свечи): закрылись за уровнем ровно 1 свечу, затем закрытие обратно.
  ЛП-М (несколько): держались за уровнем 2..5 свечей, затем вернулись.
  RSI-подтверждение (по умолчанию ВКЛ): медвежий — RSI14 ≥ 70, бычий — RSI14 ≤ 30.
Сам индикатор не даёт стопа и тейка, поэтому добавлены: вход по закрытию сигнальной свечи, стоп за крайней точкой
выхода за уровень + 0.1 ATR, тейк 1R / 2R / 3R, лимит 60 свечей.
Рынки: крипта (12 монет Binance с 2019; 1h, 4h; комиссия 0.11%) и TradFi (16 инструментов Yahoo; 4h, 1D; 0.03%).
Честно: история пополам, ✅ = плюс в обеих половинах и больше чем на половине инструментов. Итог — falsebreak_ind_test.csv.
"""
import sys as _sys
try:
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace"); _sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass
import csv
import numpy as np
import pandas as pd

L_LEN = R_LEN = 15
MAX_HOLD = 5


def signals(d, use_rsi):
    o, h, l, c = d.o.values, d.h.values, d.l.values, d.c.values; n = len(c)
    pc = np.r_[c[0], c[:-1]]; tr = np.maximum(h - l, np.maximum(abs(h - pc), abs(l - pc)))
    atr = pd.Series(tr).ewm(alpha=1 / 14, adjust=False).mean().values
    dl = pd.Series(c).diff(); up = dl.clip(lower=0).ewm(alpha=1 / 14, adjust=False).mean(); dn = (-dl.clip(upper=0)).ewm(alpha=1 / 14, adjust=False).mean()
    rsi = (100 - 100 / (1 + up / dn.replace(0, 1e-12))).values
    res = sup = np.nan; rb = sb = False; ra = sa = 0; rext = sext = 0.0; out = []
    for i in range(L_LEN + R_LEN, n):
        k = i - R_LEN                                           # разворот на k подтверждается на свече i
        if h[k] == h[k - L_LEN:i + 1].max() and (h[k - L_LEN:k] < h[k]).all() and (h[k + 1:i + 1] < h[k]).all(): res = h[k]
        if l[k] == l[k - L_LEN:i + 1].min() and (l[k - L_LEN:k] > l[k]).all() and (l[k + 1:i + 1] > l[k]).all(): sup = l[k]
        bear_ok = (not use_rsi) or rsi[i] >= 70; bull_ok = (not use_rsi) or rsi[i] <= 30
        if not np.isnan(res):
            if h[i] > res and c[i] < res and c[i - 1] < res and not rb and bear_ok:
                out.append((i, -1, h[i] + 0.1 * atr[i], "1"))
            if c[i] > res and c[i - 1] <= res: rb, ra, rext = True, 1, h[i]
            elif rb and c[i] > res: ra += 1; rext = max(rext, h[i])
            if rb and c[i] < res:
                rext = max(rext, h[i])
                if ra == 1 and bear_ok: out.append((i, -1, rext + 0.1 * atr[i], "2"))
                elif ra <= MAX_HOLD and bear_ok: out.append((i, -1, rext + 0.1 * atr[i], "M"))
                rb, ra = False, 0
        if not np.isnan(sup):
            if l[i] < sup and c[i] > sup and c[i - 1] > sup and not sb and bull_ok:
                out.append((i, 1, l[i] - 0.1 * atr[i], "1"))
            if c[i] < sup and c[i - 1] >= sup: sb, sa, sext = True, 1, l[i]
            elif sb and c[i] < sup: sa += 1; sext = min(sext, l[i])
            if sb and c[i] > sup:
                sext = min(sext, l[i])
                if sa == 1 and bull_ok: out.append((i, 1, sext - 0.1 * atr[i], "2"))
                elif sa <= MAX_HOLD and bull_ok: out.append((i, 1, sext - 0.1 * atr[i], "M"))
                sb, sa = False, 0
    return out


def sim(d, S, rr, cost):
    h, l, c, t = d.h.values, d.l.values, d.c.values, d.t.values; n = len(c); out = []; busy = -1
    for i, side, stop, _typ in S:
        if i <= busy or i >= n - 1: continue
        e = c[i]; risk = abs(e - stop)
        if risk <= 0 or risk / e > 0.15: continue
        tp = e + side * rr * risk; r = None; k = i
        for k in range(i + 1, min(n, i + 61)):
            if (l[k] <= stop) if side > 0 else (h[k] >= stop): r = -1.0; break
            if (h[k] >= tp) if side > 0 else (l[k] <= tp): r = rr; break
        if r is None: r = side * (c[k] - e) / risk
        out.append((t[i], r - cost * e / risk)); busy = k
    return out


if __name__ == "__main__":
    import kvoo_longtest as K
    import fx_channel_test as F
    sets = {}
    for s in K.COINS:
        for tf in ("1h", "4h"):
            d = K.load(s, tf)
            if d is not None and len(d) > 600: sets[("Крипта", tf, s.replace("USDT", ""))] = d
    for name, sym in F.SYMS.items():
        print("загрузка", name)
        try:
            sets[("TradFi", "4h", name)] = F.to4h(F.yahoo(sym, "1h", "730d"))
            dd = F.yahoo(sym, "1d", "max"); sets[("TradFi", "1D", name)] = dd[dd.t >= 1104537600000].reset_index(drop=True)
        except Exception as exc:  # noqa: BLE001
            print("  пропуск:", exc)
    print("\nсчитаю…")
    rows = []
    for mkt, tfs, cost in (("Крипта", ("1h", "4h"), 0.0011), ("TradFi", ("4h", "1D"), 0.0003)):
        for tf in tfs:
            for use_rsi in (True, False):
                sig = {k: signals(v.reset_index(drop=True), use_rsi) for k, v in sets.items() if k[0] == mkt and k[1] == tf}
                for typ in ("все", "1", "2", "M"):
                    for rr in (1.0, 2.0, 3.0):
                        a = b = 0.0; nt = wins = plus = 0; per = {}
                        for key, S in sig.items():
                            d = sets[key].reset_index(drop=True); cut = d.t.iat[len(d) // 2]
                            S2 = S if typ == "все" else [x for x in S if x[3] == typ]
                            tr = sim(d, S2, rr, cost); rs = sum(r for _, r in tr); per[key[2]] = round(rs, 1); plus += rs > 0
                            for tt, r in tr:
                                nt += 1; wins += r > 0
                                if tt < cut: a += r
                                else: b += r
                        ok = "✅" if nt >= 30 and a > 0 and b > 0 and plus > len(per) / 2 else "  "
                        tn = {"все": "все типы", "1": "1 свеча", "2": "2 свечи", "M": "несколько"}[typ]
                        row = {"рынок": mkt, "tf": tf, "RSI": "да" if use_rsi else "нет", "тип": tn, "тейк": f"{rr:.0f}R", "сделок": nt,
                               "WR%": round(100 * wins / max(1, nt), 1), "R_1я": round(a, 1), "R_2я": round(b, 1),
                               "R_на_сделку": round((a + b) / max(1, nt), 3), "в_плюсе": f"{plus}/{len(per)}", "прошла": ok.strip(), **per}
                        rows.append(row)
                        print(f"{ok} {mkt:6} {tf:2} | RSI {'да ' if use_rsi else 'нет'} | {tn:9} | тейк {rr:.0f}R | сделок {nt:5} WR {row['WR%']:5}% | "
                              f"1-я {a:+7.1f}R | 2-я {b:+7.1f}R | {row['R_на_сделку']:+.3f}R/сд | в плюсе {plus}/{len(per)}")
    keys = list(dict.fromkeys(k for r in rows for k in r))
    with open(F.BASE / "falsebreak_ind_test.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=keys, delimiter=";"); w.writeheader(); w.writerows(rows)
    print("\n✅ = плюс в обеих половинах, больше чем на половине инструментов, не меньше 30 сделок.")
    print("Готово. Пришлите строки с ✅ (или скрин) либо falsebreak_ind_test.csv")
    input("Enter — закрыть")
