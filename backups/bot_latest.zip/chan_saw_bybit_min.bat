@echo off
cd /d D:\VANTORIX\bot
venv\Scripts\python.exe chan_saw_bybit_min.py 300
pause
