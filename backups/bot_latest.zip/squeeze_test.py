"""squeeze_test.py — 2026-11-01. «Поджатие к уровню, потом импульс» (идея из канала): цена W свечей ходит в узком
диапазоне (≤ q ATR), затем закрытие выше максимума/ниже минимума этого диапазона. Сравнение с тем же пробоем БЕЗ поджатия.
Стоп за противоположной границей диапазона (не дальше 3 ATR), выход: тейк 2R / 3R или обратный пробой 10 свечей. Комиссия 0.08%."""
import sys, time
import numpy as np, pandas as pd
sys.path.insert(0, ".")
BASE = __import__("pathlib").Path(__file__).resolve().parent; sys.path.insert(0, str(BASE))
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass
import recheck_recent as RR, kvoo_longtest as K
FEE = 0.0008; now = int(time.time() * 1000)

def run(d, W, q, squeeze, tp, side_mode):
    c, h, l = d.c.values, d.h.values, d.l.values
    pc = np.r_[c[0], c[:-1]]; atr = pd.Series(np.maximum(h - l, np.maximum(abs(h - pc), abs(l - pc)))).ewm(alpha=1/14, adjust=False).mean().values
    hh = d.h.rolling(W).max().shift(1).values; ll = d.l.rolling(W).min().shift(1).values
    h10 = d.h.rolling(10).max().shift(1).values; l10 = d.l.rolling(10).min().shift(1).values
    t = d.t.values; out = []; i = 210; n = len(c)
    while i < n - 1:
        s = 1 if c[i] > hh[i] else -1 if c[i] < ll[i] else 0
        if side_mode == "long" and s < 0: s = 0
        if s == 0 or not atr[i] > 0 or (squeeze and (hh[i] - ll[i]) > q * atr[i]): i += 1; continue
        e = c[i]; stp = ll[i] if s > 0 else hh[i]; risk = abs(e - stp)
        if risk > 3 * atr[i] or risk < 0.3 * atr[i]: risk = min(max(risk, 0.3 * atr[i]), 3 * atr[i]); stp = e - s * risk
        tpp = e + s * tp * risk if tp else None; res = None
        for j in range(i + 1, min(n, i + 200)):
            if (l[j] <= stp) if s > 0 else (h[j] >= stp): res = (j, -1.0); break
            if tpp and ((h[j] >= tpp) if s > 0 else (l[j] <= tpp)): res = (j, float(tp)); break
            if not tp and ((c[j] < l10[j]) if s > 0 else (c[j] > h10[j])): res = (j, s * (c[j] - e) / risk); break
        if res is None: j = min(n - 1, i + 199); res = (j, s * (c[j] - e) / risk)
        out.append((int(t[i]), res[1] - FEE * e / risk)); i = res[0] + 1
    return out

lines = []
for tf in ("1h", "2h", "4h"):
    data = [(s, RR.load(s, tf)) for s in K.COINS]; data = [(s, d.reset_index(drop=True)) for s, d in data if d is not None and len(d) > 600]
    t0 = min(int(d.t.iloc[0]) for _, d in data); mid = (t0 + now) // 2
    lines.append(f"\n=== {tf} ===  сд · R/сд · всё · 1пол · 2пол · 180д · 90д · монет+")
    for side_mode in ("both", "long"):
        for tp in (2, 3, None):
            for W in (10, 20, 30):
                for q, sq in ((3, True), (5, True), (0, False)):
                    al = []; pos = 0
                    for s, d in data:
                        r = run(d, W, q, sq, tp, side_mode); al += r; pos += sum(x for _, x in r) > 0
                    if not al: continue
                    w = lambda D: sum(x for tt, x in al if tt >= now - D * 86400_000)
                    h1 = sum(x for tt, x in al if tt < mid); h2 = sum(x for tt, x in al if tt >= mid)
                    ok = h1 > 0 and h2 > 0 and w(180) > 0 and pos >= 8
                    nm = f"поджатие≤{q}ATR" if sq else "без поджатия"
                    lines.append(f"{'✅' if ok else '❌'} {side_mode:4} тейк {tp or 'выход10'} W{W:<2} {nm:<14} {len(al):5} · {sum(x for _, x in al)/len(al):+.3f} · {sum(x for _, x in al):+6.0f} · {h1:+5.0f} · {h2:+5.0f} · {w(180):+5.0f} · {w(90):+5.0f} · {pos}/{len(data)}")
    print(f"{tf} done", flush=True)
open(BASE / "bt_lab_bots" / "squeeze_test.txt", "w", encoding="utf-8").write("\n".join(lines) + "\n")
