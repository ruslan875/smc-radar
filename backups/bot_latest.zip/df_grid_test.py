# -*- coding: utf-8 -*-
"""Честный тест сетки в стиле DF / DragonFly / DF GOLD на крипте и TradFi (свечи 1h).
Вход: направление по EMA15 (замена закрытого DF Channel), добор против цены каждые STEP*ATR,
лот * MULT, общий тейк корзины TP*ATR от средней, комиссия. Счёт 10 000 $.
Внутри свечи сначала худший ход (против корзины), потом тейк — консервативно.
"""
import os, sys, glob
import numpy as np, pandas as pd
try: sys.stdout.reconfigure(encoding="utf-8")
except Exception: pass

HERE = os.path.dirname(os.path.abspath(__file__))
CACHE = os.path.join(HERE, "market_cache") if os.path.isdir(os.path.join(HERE, "market_cache")) else sys.argv[1]
DEP = 10_000.0

VARIANTS = {
    # имя: (mult, max_orders, first_notional_%_deposit, basket_stop_%_equity or None)
    "DF оригинал x2, 11 орд, без стопа": (2.0, 11, 10, None),
    "DF/FixLot x1.5, 15 орд, без стопа":  (1.5, 15, 10, None),
    "Безопасный x1.5, 6 орд, стоп -10%":  (1.5, 6, 10, 10),
    "Мягкий x1.3, 5 орд, стоп -5%":       (1.3, 5, 5, 5),
}
STEP_ATR, TP_ATR = 2.0, 1.2

def load(path):
    d = pd.read_csv(path)
    d = d[(d.h > d.l) | (d.v > 0)]
    d.index = pd.to_datetime(d.t, unit="ms")
    return d[["o", "h", "l", "c"]].astype(float)

def atr(d, n=14):
    tr = pd.concat([d.h - d.l, (d.h - d.c.shift()).abs(), (d.l - d.c.shift()).abs()], axis=1).max(axis=1)
    return tr.ewm(alpha=1 / n, adjust=False).mean()

def sim(d, mult, maxo, first_pct, stop_pct, fee):
    H, L, C = d.h.values, d.l.values, d.c.values
    A = atr(d).values; E = d.c.ewm(span=15, adjust=False).mean().values
    eq = DEP; peak = DEP; mdd = 0; eqs = np.full(len(C), np.nan)
    pos = None; baskets = []; blown = None
    for i in range(20, len(C)):
        if pos is None:
            if eq <= 0: break
            side = 1 if C[i] > E[i] else -1
            n0 = eq * first_pct / 100
            pos = dict(side=side, q=n0 / C[i], cost=n0, n=1, last=C[i], step=STEP_ATR * A[i], tp=TP_ATR * A[i], t0=i)
            eq -= n0 * fee; eqs[i] = eq; continue
        s = pos["side"]
        adv = L[i] if s == 1 else H[i]        # худшая цена свечи
        # доборы
        while pos["n"] < maxo:
            px = pos["last"] - s * pos["step"]
            if (s == 1 and adv <= px) or (s == -1 and adv >= px):
                lot_n = pos.get("lastn", pos["cost"]) * mult
                pos["q"] += lot_n / px; pos["cost"] += lot_n; pos["n"] += 1; pos["last"] = px; pos["lastn"] = lot_n
                eq -= lot_n * fee
            else: break
        avg = pos["cost"] / pos["q"]
        upnl_adv = s * pos["q"] * (adv - avg)
        e_adv = eq + upnl_adv
        mdd = max(mdd, (peak - e_adv) / peak * 100)
        if e_adv <= 0:
            blown = d.index[i]; baskets.append((pos["t0"], i, -eq, pos["n"], "СЛИВ")); eq = 0; eqs[i] = 0; break
        if stop_pct and upnl_adv <= -eq * stop_pct / 100:
            loss = -eq * stop_pct / 100 - pos["q"] * avg * fee
            eq += loss; baskets.append((pos["t0"], i, loss, pos["n"], "стоп")); pos = None
            peak = max(peak, eq); eqs[i] = eq; continue
        tgt = avg + s * pos["tp"]
        fav = H[i] if s == 1 else L[i]
        if (s == 1 and fav >= tgt) or (s == -1 and fav <= tgt):
            pnl = pos["q"] * pos["tp"] - pos["q"] * tgt * fee
            eq += pnl; baskets.append((pos["t0"], i, pnl, pos["n"], "тейк")); pos = None
            peak = max(peak, eq)
        eqs[i] = eq
    b = pd.DataFrame(baskets, columns=["i0", "i1", "pnl", "n", "why"])
    return eq, mdd, blown, b, pd.Series(eqs, index=d.index).ffill()

def main():
    files = sorted(glob.glob(os.path.join(CACHE, "binance", "*_1h.csv")))
    files += [os.path.join(CACHE, "yahoo", f) for f in ("GC_F_1h.csv", "EURUSD_X_1h.csv")]
    rows = []
    for f in files:
        if not os.path.exists(f): continue
        name = os.path.basename(f).replace("_1h.csv", "").replace("USDT", "").replace("_F", " gold").replace("_X", "")
        d = load(f); crypto = "binance" in f
        fee = 0.00055 if crypto else 0.00003
        mid = d.index[0] + (d.index[-1] - d.index[0]) / 2
        for vn, (m, mo, fp, sp) in VARIANTS.items():
            eq, mdd, blown, b, es = sim(d, m, mo, fp, sp, fee)
            e_mid = es[es.index <= mid].iloc[-1] if (es.index <= mid).any() else DEP
            h1 = (e_mid / DEP - 1) * 100
            h2 = (eq / e_mid - 1) * 100 if e_mid > 0 else -100
            rows.append(dict(инструмент=name, вариант=vn, годы=f"{d.index[0]:%Y}-{d.index[-1]:%Y}",
                             итог_pct=round((eq / DEP - 1) * 100, 1), макс_просадка=round(mdd, 1),
                             слив=(f"{blown:%Y-%m-%d}" if blown is not None else "нет"),
                             корзин=len(b), стопов=int((b.why == "стоп").sum()) if len(b) else 0,
                             макс_ордеров=int(b.n.max()) if len(b) else 0,
                             половина1=round(h1, 1), половина2=round(h2, 1)))
            print(f"{name:8} | {vn:36} | {rows[-1]['итог_pct']:>9}% | DD {mdd:5.1f}% | слив {rows[-1]['слив']} | H1 {h1:+.0f}% H2 {h2:+.0f}%")
    df = pd.DataFrame(rows)
    df.to_csv(os.path.join(HERE, "df_grid_test.csv"), index=False, encoding="utf-8-sig")
    print("\nСВОДКА по вариантам (сколько инструментов: слив / плюс в обеих половинах из всех):")
    for vn, g in df.groupby("вариант", sort=False):
        ok = ((g.половина1 > 0) & (g.половина2 > 0) & (g.слив == "нет")).sum()
        print(f"  {vn:36}  слив {int((g.слив!='нет').sum())}/{len(g)}   ✅ {ok}/{len(g)}   медиана DD {g.макс_просадка.median():.0f}%")

if __name__ == "__main__":
    main()
