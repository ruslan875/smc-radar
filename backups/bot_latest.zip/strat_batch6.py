"""strat_batch6.py — 2026-10-29. Проверка на прочность «Черепах» (вход пробой N, выход противоположный пробой M, стоп k·ATR).
Соседние настройки (не одна удачная), половины истории, просадка портфеля 12 монет в R, худшая серия стопов, 1h/2h/4h.
Если результат держится на соседях — это не подгонка. Пишет bt_lab_bots/strat_batch6.txt
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import recheck_recent as RR  # noqa: E402
import strat_batch5 as B5  # noqa: E402


def turtle(N, M, k):
    def en(I, i):
        hh, ll = I[f"hh{N}"][i], I[f"ll{N}"][i]
        return 1 if I["c"][i] > hh else (-1 if I["c"][i] < ll else 0)

    def ex(I, j, s):
        return I["c"][j] < I[f"ll{M}"][j] if s > 0 else I["c"][j] > I[f"hh{M}"][j]
    return en, ex, k


def add_ch(d, I, ns):
    for n in ns:
        if f"hh{n}" not in I:
            I[f"hh{n}"] = d.h.rolling(n).max().shift(1).values; I[f"ll{n}"] = d.l.rolling(n).min().shift(1).values


GRID = [(N, M, k) for N in (40, 55, 70, 100) for M in (15, 20, 30) for k in (1.5, 2.0, 3.0)]


def main():
    import kvoo_longtest as K  # noqa: PLC0415
    now = int(time.time() * 1000); lines = []
    for tf in ("2h", "4h", "1h"):
        data = []
        for s in K.COINS:
            d = RR.load(s, tf)
            if d is not None and len(d) > 600:
                I = B5.ind(d); add_ch(d, I, (15, 20, 30, 40, 55, 70, 100)); data.append((s, d, I))
        t0 = min(int(d.t.iloc[0]) for _s, d, _I in data); mid = (t0 + now) // 2
        lines.append(f"\n=== {tf} ===  (R; вся · 1-я пол · 2-я пол · 180д · 90д · 30д · монет+ · макс. просадка портфеля · серия стопов)")
        res = []
        for N, M, k in GRID:
            en, ex, kk = turtle(N, M, k)
            allt = []; pos = 0
            for _s, d, I in data:
                tr = B5.sim(d, I, en, ex, kk, None, 400); allt += tr; pos += sum(r for _t, r in tr) > 0
            allt.sort()
            eq = np.cumsum([r for _t, r in allt]); dd = float((eq - np.maximum.accumulate(np.r_[0, eq])[1:]).min()) if len(eq) else 0
            run = mx = 0
            for _t, r in allt:
                run = run + 1 if r < 0 else 0; mx = max(mx, run)
            w = lambda days: sum(r for t, r in allt if t >= now - days * 86400_000)  # noqa: E731
            h1 = sum(r for t, r in allt if t < mid); h2 = sum(r for t, r in allt if t >= mid)
            row = (N, M, k, len(allt), w(99999), h1, h2, w(180), w(90), w(30), pos, dd, mx)
            res.append(row)
            ok = h1 > 0 and h2 > 0 and w(180) > 0 and w(90) > 0 and pos >= 8
            line = (f"{'✅' if ok else '❌'} вход {N:>3} / выход {M:>2} / стоп {k}ATR · {len(allt):>5} сд · всё {w(99999):+7.0f} · "
                    f"{h1:+6.0f} · {h2:+6.0f} · {w(180):+6.0f} · {w(90):+6.0f} · {w(30):+6.0f} · {pos}/{len(data)} · {dd:+6.0f} · {mx}")
            print(line, flush=True); lines.append(line)
        okc = sum(1 for r in res if r[5] > 0 and r[6] > 0 and r[7] > 0 and r[8] > 0 and r[10] >= 8)
        lines.append(f"→ {tf}: прошли {okc} из {len(res)} соседних настроек")
        print(lines[-1], flush=True)
    (BASE / "bt_lab_bots" / "strat_batch6.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("готово")


if __name__ == "__main__":
    main()
