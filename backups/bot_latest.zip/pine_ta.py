#!/usr/bin/env python3
"""
Pine Script indicator primitives, reimplemented faithfully in pandas
=====================================================================

Written 21.09.2026, before porting the remaining four strategies.

WHY THIS FILE EXISTS

The first five ports each carried their own copy of whatever indicators they
needed. That was survivable at five, but four more scripts need ADX, ATR,
RSI, MFI, SuperTrend, linear regression and Choppiness *between them*, and
four independent implementations of Wilder smoothing is four chances to get
the seeding wrong in a way nobody notices - and a comparison table where one
strategy's ADX is seeded with an SMA and another's with the first value is
measuring the seeding, not the strategies.

FAITHFULNESS NOTES - the places Pine differs from the textbook

* ta.rma is Wilder smoothing seeded with the SMA of the first `length` values,
  not with the first value and not with an EMA. ta.atr, ta.rsi and ta.dmi all
  build on it, so getting this wrong shifts every one of them.
* ta.stdev is the POPULATION standard deviation (divide by N). pandas .std()
  defaults to the sample version (N-1) and would run slightly wide.
* ta.highest / ta.lowest INCLUDE the current bar.
* ta.percentrank looks at the `length` PREVIOUS bars only, current bar excluded
  from the population, and counts `<=`.
* ta.supertrend returns direction -1 for UPtrend and +1 for downtrend. This is
  counterintuitive and at least one of the scripts being ported has the plot
  colours backwards because of it.
* Series are returned with the input's index and leading NaN where Pine would
  have `na`; callers must not treat NaN as False without saying so.
"""

from __future__ import annotations

import numpy as np
import pandas as pd


# ---------------------------------------------------------------------------
# basics
# ---------------------------------------------------------------------------

def change(src: pd.Series, length: int = 1) -> pd.Series:
    """ta.change"""
    return src - src.shift(length)


def highest(src: pd.Series, length: int) -> pd.Series:
    """ta.highest - includes the current bar"""
    return src.rolling(length, min_periods=length).max()


def lowest(src: pd.Series, length: int) -> pd.Series:
    """ta.lowest - includes the current bar"""
    return src.rolling(length, min_periods=length).min()


def sma(src: pd.Series, length: int) -> pd.Series:
    return src.rolling(length, min_periods=length).mean()


def ema(src: pd.Series, length: int) -> pd.Series:
    """ta.ema - Pine seeds with the SMA of the first `length` values."""
    out = src.ewm(span=length, adjust=False).mean()
    # Pine's ema is na until `length` bars exist, and its first value is the
    # SMA. ewm(adjust=False) instead starts from the first observation.
    seed = src.rolling(length, min_periods=length).mean()
    first = seed.first_valid_index()
    if first is None:
        return pd.Series(np.nan, index=src.index)
    vals = src.to_numpy(dtype=float)
    res = np.full(len(src), np.nan)
    pos = src.index.get_loc(first)
    res[pos] = seed.iloc[pos]
    alpha = 2.0 / (length + 1.0)
    for i in range(pos + 1, len(src)):
        res[i] = alpha * vals[i] + (1 - alpha) * res[i - 1]
    return pd.Series(res, index=src.index)


def rma(src: pd.Series, length: int) -> pd.Series:
    """ta.rma - Wilder smoothing, seeded with the SMA of the first `length`.

    This is the one every derived indicator depends on. alpha = 1/length.
    """
    vals = src.to_numpy(dtype=float)
    n = len(vals)
    res = np.full(n, np.nan)
    # first index where `length` non-NaN values are available
    valid = ~np.isnan(vals)
    csum = np.cumsum(valid.astype(int))
    start = None
    for i in range(n):
        if csum[i] >= length and valid[i]:
            start = i
            break
    if start is None:
        return pd.Series(res, index=src.index)
    window = vals[start - length + 1:start + 1]
    res[start] = np.nanmean(window)
    alpha = 1.0 / length
    for i in range(start + 1, n):
        x = vals[i]
        if np.isnan(x):
            res[i] = res[i - 1]
        else:
            res[i] = alpha * x + (1 - alpha) * res[i - 1]
    return pd.Series(res, index=src.index)


def stdev(src: pd.Series, length: int) -> pd.Series:
    """ta.stdev - POPULATION standard deviation (ddof=0)."""
    return src.rolling(length, min_periods=length).std(ddof=0)


def cum(src: pd.Series) -> pd.Series:
    """ta.cum"""
    return src.fillna(0.0).cumsum()


def crossover(a: pd.Series, b: pd.Series) -> pd.Series:
    return (a > b) & (a.shift(1) <= b.shift(1))


def crossunder(a: pd.Series, b: pd.Series) -> pd.Series:
    return (a < b) & (a.shift(1) >= b.shift(1))


# ---------------------------------------------------------------------------
# range / volatility
# ---------------------------------------------------------------------------

def true_range(df: pd.DataFrame, handle_na: bool = True) -> pd.Series:
    """ta.tr(handle_na).

    With handle_na=True the first bar uses high-low instead of na, which is
    what `ta.tr(true)` does and what ta.atr uses internally.
    """
    prev_close = df["close"].shift(1)
    hl = df["high"] - df["low"]
    hc = (df["high"] - prev_close).abs()
    lc = (df["low"] - prev_close).abs()
    tr = pd.concat([hl, hc, lc], axis=1).max(axis=1)
    if handle_na:
        tr = tr.where(prev_close.notna(), hl)
    else:
        tr = tr.where(prev_close.notna(), np.nan)
    return tr


def atr(df: pd.DataFrame, length: int) -> pd.Series:
    """ta.atr"""
    return rma(true_range(df, handle_na=True), length)


def natr(df: pd.DataFrame, length: int) -> pd.Series:
    return 100.0 * atr(df, length) / df["close"]


def choppiness(df: pd.DataFrame, length: int) -> pd.Series:
    """Choppiness Index, in the exact form the Pavlova script computes it.

    Note it does NOT use plain highest(high)/lowest(low): it takes the
    high/low merged with the previous close, which is the true-range-aware
    variant. Reproduced as written.
    """
    tr_sum = true_range(df, handle_na=True).rolling(length, min_periods=length).sum()
    prev_close = df["close"].shift(1)
    low_m = np.where(df["low"] <= prev_close, df["low"], prev_close)
    high_m = np.where(df["high"] >= prev_close, df["high"], prev_close)
    low_m = pd.Series(low_m, index=df.index).fillna(df["low"])
    high_m = pd.Series(high_m, index=df.index).fillna(df["high"])
    lo = low_m.rolling(length, min_periods=length).min()
    hi = high_m.rolling(length, min_periods=length).max()
    height = hi - lo
    out = 100.0 * (np.log10(tr_sum / height) / np.log10(length))
    return out.where((height > 0) & (tr_sum > 0))


# ---------------------------------------------------------------------------
# oscillators
# ---------------------------------------------------------------------------

def rsi(src: pd.Series, length: int) -> pd.Series:
    """ta.rsi - built on rma, so it inherits the SMA seeding."""
    delta = src.diff()
    up = rma(delta.clip(lower=0.0), length)
    down = rma((-delta).clip(lower=0.0), length)
    rs = up / down
    out = 100.0 - 100.0 / (1.0 + rs)
    out = out.where(down != 0, 100.0)
    out = out.where(up != 0, 0.0)
    return out


def mfi(df: pd.DataFrame, src: pd.Series, length: int) -> pd.Series:
    """ta.mfi(src, length)"""
    ch = src.diff()
    vol = df["volume"]
    upper = (vol * np.where(ch <= 0, 0.0, src)).rolling(length, min_periods=length).sum()
    lower = (vol * np.where(ch >= 0, 0.0, src)).rolling(length, min_periods=length).sum()
    with np.errstate(divide="ignore", invalid="ignore"):
        out = 100.0 - (100.0 / (1.0 + upper / lower))
    return pd.Series(out, index=df.index)


def percentrank(src: pd.Series, length: int) -> pd.Series:
    """ta.percentrank - share of the PREVIOUS `length` values that are <= now."""
    vals = src.to_numpy(dtype=float)
    n = len(vals)
    out = np.full(n, np.nan)
    for i in range(length, n):
        window = vals[i - length:i]          # previous `length`, current excluded
        cur = vals[i]
        if np.isnan(cur) or np.isnan(window).any():
            continue
        out[i] = (window <= cur).sum() / length * 100.0
    return pd.Series(out, index=src.index)


def linreg(src: pd.Series, length: int, offset: int = 0) -> pd.Series:
    """ta.linreg(source, length, offset).

    Least squares over the last `length` bars with x = 0 (oldest) .. length-1
    (newest); the value returned is the regression line at x = length-1-offset.
    Computed with rolling sums rather than a per-bar fit, which matters because
    ZLSMA runs it twice over ~17k bars per symbol.
    """
    n = length
    y = src.astype(float)
    idx = pd.Series(np.arange(len(src), dtype=float), index=src.index)

    sum_y = y.rolling(n, min_periods=n).sum()
    sum_jy = (idx * y).rolling(n, min_periods=n).sum()
    # position of the window's oldest bar
    j0 = idx - (n - 1)
    sum_xy = sum_jy - j0 * sum_y            # x = j - j0

    sum_x = n * (n - 1) / 2.0
    sum_xx = (n - 1) * n * (2 * n - 1) / 6.0

    denom = n * sum_xx - sum_x * sum_x
    slope = (n * sum_xy - sum_x * sum_y) / denom
    intercept = (sum_y - slope * sum_x) / n
    return intercept + slope * (n - 1 - offset)


def zlsma(src: pd.Series, length: int, offset: int = 0) -> pd.Series:
    """Zero-lag LSMA: linreg applied twice, then the lag added back."""
    l1 = linreg(src, length, offset)
    l2 = linreg(l1, length, offset)
    return l1 + (l1 - l2)


def connors_rsi(df: pd.DataFrame, rsi_len: int = 3, streak_len: int = 2,
                rank_len: int = 100) -> pd.Series:
    """Connors RSI, in the form the rsi_connors script writes it.

    The streak counter is a `var` in Pine; reproduced here as an explicit loop
    because a vectorised version of "consecutive up/down days" is easy to get
    subtly wrong at the sign flips.
    """
    close = df["close"].to_numpy(dtype=float)
    n = len(close)
    streak = np.zeros(n)
    for i in range(1, n):
        if close[i] > close[i - 1]:
            streak[i] = max(streak[i - 1] + 1, 1)
        elif close[i] < close[i - 1]:
            streak[i] = min(streak[i - 1] - 1, -1)
        else:
            streak[i] = 0.0
    streak_s = pd.Series(streak, index=df.index)

    r1 = rsi(df["close"], rsi_len)
    r2 = rsi(streak_s.abs(), streak_len)
    roc = df["close"] / df["close"].shift(1) - 1.0
    pr = percentrank(roc, rank_len)
    return (r1 + r2 + pr) / 3.0


# ---------------------------------------------------------------------------
# trend
# ---------------------------------------------------------------------------

def dmi(df: pd.DataFrame, di_length: int, adx_smoothing: int):
    """ta.dmi(diLength, adxSmoothing) -> (plusDI, minusDI, adx)"""
    up_move = df["high"].diff()
    down_move = -df["low"].diff()
    plus_dm = np.where((up_move > down_move) & (up_move > 0), up_move, 0.0)
    minus_dm = np.where((down_move > up_move) & (down_move > 0), down_move, 0.0)
    plus_dm = pd.Series(plus_dm, index=df.index)
    minus_dm = pd.Series(minus_dm, index=df.index)

    tr_s = rma(true_range(df, handle_na=True), di_length)
    plus_di = 100.0 * rma(plus_dm, di_length) / tr_s
    minus_di = 100.0 * rma(minus_dm, di_length) / tr_s
    di_sum = plus_di + minus_di
    dx = 100.0 * (plus_di - minus_di).abs() / di_sum.where(di_sum != 0)
    return plus_di, minus_di, rma(dx.fillna(0.0), adx_smoothing)


def adx(df: pd.DataFrame, length: int) -> pd.Series:
    return dmi(df, length, length)[2]


def supertrend(df: pd.DataFrame, factor: float, atr_period: int):
    """ta.supertrend(factor, atrPeriod) -> (line, direction).

    direction is -1 for UPTREND and +1 for downtrend, per the Pine reference.
    """
    a = atr(df, atr_period).to_numpy(dtype=float)
    hl2 = ((df["high"] + df["low"]) / 2.0).to_numpy(dtype=float)
    close = df["close"].to_numpy(dtype=float)
    n = len(close)

    upper = hl2 + factor * a
    lower = hl2 - factor * a
    st = np.full(n, np.nan)
    direction = np.full(n, np.nan)

    prev_upper = np.nan
    prev_lower = np.nan
    prev_st = np.nan
    for i in range(n):
        if np.isnan(a[i]):
            prev_upper, prev_lower = upper[i], lower[i]
            continue
        lb = lower[i]
        ub = upper[i]
        pl = prev_lower if not np.isnan(prev_lower) else lb
        pu = prev_upper if not np.isnan(prev_upper) else ub
        prev_close = close[i - 1] if i > 0 else close[i]

        lb = lb if (lb > pl or prev_close < pl) else pl
        ub = ub if (ub < pu or prev_close > pu) else pu

        if i == 0 or np.isnan(a[i - 1]):
            d = 1.0
        elif prev_st == pu:
            d = -1.0 if close[i] > ub else 1.0
        else:
            d = 1.0 if close[i] < lb else -1.0

        s = lb if d == -1 else ub
        st[i], direction[i] = s, d
        prev_upper, prev_lower, prev_st = ub, lb, s

    return pd.Series(st, index=df.index), pd.Series(direction, index=df.index)


def zscore(src: pd.Series, length: int) -> pd.Series:
    basis = sma(src, length)
    dev = stdev(src, length)
    return ((src - basis) / dev).where(dev != 0)
