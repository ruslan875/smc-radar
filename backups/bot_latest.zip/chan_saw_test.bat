@echo off
cd /d D:\VANTORIX\bot
venv\Scripts\python.exe chan_saw_test.py
pause
