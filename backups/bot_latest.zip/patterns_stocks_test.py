"""patterns_stocks_test.py — 2026-11-09. Классические фигуры и свечные паттерны на дневках и неделях: 98 акций США + индексы/сырьё."""
import sys, time
from pathlib import Path
import numpy as np, pandas as pd
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import stocks_test as ST  # noqa: E402
import patterns as P  # noqa: E402
res = {}
syms = [(s, s) for s in ST.STOCKS] + list(ST.OTHER.items())
for k_, (name, sym) in enumerate(syms, 1):
    d = ST.yahoo(sym)
    if d is None:
        continue
    for tf in ("1D", "1W"):
        g = d if tf == "1D" else d.set_index(pd.to_datetime(d.t, unit="ms")).resample("W").agg({"o": "first", "h": "max", "l": "min", "c": "last"}).dropna()
        o, h, l, c = g.o.values, g.h.values, g.l.values, g.c.values; N = len(c)
        if N < 260:
            continue
        S = {**P.candles(o, h, l, c), **P.figures(o, h, l, c)}
        S["Случайный вход (база)"] = P.random_sigs(o, h, l, c, max(50, N // 40))
        for k, sg in S.items():
            for tr in (False, True):
                for rr in (2.0, 3.0):
                    for i, r in P.backtest(o, h, l, c, sg, rr=rr, trend=tr, cost=0.0005):
                        res.setdefault((tf, k, tr, rr), []).append((name, i / N, r))
    print(f"[{k_}/{len(syms)}] {name}", flush=True)
rows = []
for (tf, k, tr, rr), v in res.items():
    a = np.array([z[2] for z in v]); fr = np.array([z[1] for z in v]); co = {}
    for z in v:
        co[z[0]] = co.get(z[0], 0) + z[2]
    if len(a) < 15:
        continue
    rows.append((tf, k, "тренд" if tr else "—", rr, len(a), round(a.mean(), 3), round(a[a > 0].sum() / max(1e-9, -a[a < 0].sum()), 2),
                 round(a[fr < .5].sum(), 1), round(a[fr >= .5].sum(), 1), sum(1 for q in co.values() if q > 0), len(co)))
R = pd.DataFrame(rows, columns=["tf", "pattern", "filter", "rr", "n", "rpt", "pf", "h1", "h2", "pos", "inst"])
R["ok"] = (R.h1 > 0) & (R.h2 > 0) & (R.pf > 1.15) & (R.pos >= R.inst * 0.6)
R.sort_values(["ok", "rpt"], ascending=False).to_csv(BASE / "patterns_stocks.csv", index=False, encoding="utf-8-sig")
(BASE / "patterns_stocks.txt").write_text(R.sort_values(["ok", "rpt"], ascending=False).to_string(), encoding="utf-8")
print(R.sort_values(["ok", "rpt"], ascending=False).head(30).to_string())
