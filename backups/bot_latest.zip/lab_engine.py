"""Движок сигнальных бэктестов (из облачной проверки 2026-09-26), используется bt_lab.py."""
"""Простой честный бэктестер: сигналы на закрытии свечи, вход по close,
стоп/тейк проверяются на следующих свечах по high/low (если в одной свече
задеты оба — считаем стоп). Комиссия 0.055% за сторону + 0.02% проскальзывание.
Размер позиции фиксирован (1x депозита, без реинвеста) — чтобы сравнивать
стратегии, а не сложный процент."""
import numpy as np
import pandas as pd

FEE = 0.00055
SLIP = 0.0002
DATA = "/mnt/user-data/uploads/VANTORIX/bot/market_cache"


def load(sym, tf):
    base = "15m" if tf in ("15m",) else "1h"
    df = pd.read_csv(f"{DATA}/bybit_swap_{sym}USDT_{base}.csv", parse_dates=["timestamp"]).set_index("timestamp")
    if tf in ("15m", "1h"):
        return df
    rule = {"4h": "4h", "2h": "2h", "1d": "1D"}[tf]
    return df.resample(rule).agg({"open": "first", "high": "max", "low": "min", "close": "last", "volume": "sum"}).dropna()


# ---------- индикаторы (как в Pine) ----------
def rma(s, n):
    return s.ewm(alpha=1 / n, adjust=False).mean()


def atr(df, n):
    pc = df.close.shift()
    tr = pd.concat([df.high - df.low, (df.high - pc).abs(), (df.low - pc).abs()], axis=1).max(axis=1)
    return rma(tr, n)


def rsi(s, n):
    d = s.diff()
    up, dn = rma(d.clip(lower=0), n), rma(-d.clip(upper=0), n)
    return 100 - 100 / (1 + up / dn)


def sma(s, n):
    return s.rolling(n).mean()


def ema(s, n):
    return s.ewm(span=n, adjust=False).mean()


def adx(df, n):
    up, dn = df.high.diff(), -df.low.diff()
    pdm = pd.Series(np.where((up > dn) & (up > 0), up, 0.0), df.index)
    mdm = pd.Series(np.where((dn > up) & (dn > 0), dn, 0.0), df.index)
    a = atr(df, n)
    pdi, mdi = 100 * rma(pdm, n) / a, 100 * rma(mdm, n) / a
    dx = 100 * (pdi - mdi).abs() / (pdi + mdi)
    return rma(dx, n)


# ---------- симулятор ----------
def simulate(df, sig):
    """sig: DataFrame с колонками side(1/-1/0), sl, tp (абс. цены или NaN),
    exit (bool — закрыть по close), trail_fn опционально не используется.
    Одна позиция за раз. Возвращает список сделок (pnl доля)."""
    o, h, l, c = df.open.values, df.high.values, df.low.values, df.close.values
    side_a, sl_a, tp_a = sig.side.values, sig.sl.values, sig.tp.values
    ex_a = sig.exit.values if "exit" in sig else np.zeros(len(df), bool)
    upd = sig["sl_update"].values if "sl_update" in sig else None
    tmax = sig.attrs.get("max_bars")
    trades = []
    pos = 0; ep = sl = tp = 0.0; eb = 0
    for i in range(len(df)):
        if pos:
            # intrabar stop / take
            hit = None
            if pos == 1:
                if not np.isnan(sl) and l[i] <= sl: hit = min(sl, o[i])
                elif not np.isnan(tp) and h[i] >= tp: hit = max(tp, o[i])
            else:
                if not np.isnan(sl) and h[i] >= sl: hit = max(sl, o[i])
                elif not np.isnan(tp) and l[i] <= tp: hit = min(tp, o[i])
            closed = False
            if hit is not None:
                trades.append((df.index[eb], df.index[i], pos, pos * (hit / ep - 1) - 2 * (FEE + SLIP))); closed = True
            elif ex_a[i] == pos or ex_a[i] == 2 or (tmax and i - eb >= tmax):
                trades.append((df.index[eb], df.index[i], pos, pos * (c[i] / ep - 1) - 2 * (FEE + SLIP))); closed = True
            if closed:
                pos = 0
            elif upd is not None and not np.isnan(upd[i]):
                sl = max(sl, upd[i]) if pos == 1 else min(sl, upd[i])
            if pos and sig.attrs.get("manage"):
                ns = sig.attrs["manage"](i, pos, ep, sl)
                if ns is not None and not np.isnan(ns):
                    sl = max(sl, ns) if pos == 1 else min(sl, ns)
        if not pos and side_a[i] != 0:
            pos = int(side_a[i]); ep = c[i]; eb = i; sl = sl_a[i]; tp = tp_a[i]
        elif pos and side_a[i] == -pos and sig.attrs.get("reverse"):
            trades.append((df.index[eb], df.index[i], pos, pos * (c[i] / ep - 1) - 2 * (FEE + SLIP)))
            pos = int(side_a[i]); ep = c[i]; eb = i; sl = sl_a[i]; tp = tp_a[i]
    return pd.DataFrame(trades, columns=["entry", "exit", "side", "pnl"])


def stats(t):
    if len(t) == 0:
        return dict(n=0, ret=0.0, pf=np.nan, win=np.nan, dd=0.0)
    eq = t.pnl.cumsum()
    dd = (eq.cummax().clip(lower=0) - eq).max()
    g, lo = t.pnl[t.pnl > 0].sum(), -t.pnl[t.pnl < 0].sum()
    return dict(n=len(t), ret=round(eq.iloc[-1] * 100, 1), pf=round(g / lo, 2) if lo else np.inf,
                win=round((t.pnl > 0).mean() * 100, 1), dd=round(dd * 100, 1))
