@echo off
cd /d "%~dp0"
venv\Scripts\python.exe bot_services.py restart-lab
timeout /t 10
