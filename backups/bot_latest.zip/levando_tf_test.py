"""levando_tf_test.py — 2026-10-28. LE VAN DO (HA ×18, переворот) — ЧЕСТНАЯ версия на всех таймфреймах 1m…4h.
Тот же расчёт, что levando_test.py (вариант «ЧЕСТНО, переворот»), плюс отдельная строка «последние 90 дней».
История: 1m — 180 дней, 5m — 365, 15m/30m — 2 года, 1h/2h/4h — с 2019. Свечи Binance Futures (кэш в market_cache_tf).
Комиссия+проскальзывание 0.11% за круг — на младших ТФ она съедает много, это и проверяем.
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass

import numpy as np
import pandas as pd
import requests

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import levando_test as L  # noqa: E402

CACHE = BASE / "market_cache_tf"
COINS = ["BTCUSDT", "ETHUSDT", "XRPUSDT", "DOGEUSDT", "ADAUSDT", "SOLUSDT", "LINKUSDT", "LTCUSDT", "BNBUSDT", "AVAXUSDT", "TAOUSDT", "HYPEUSDT"]
TF = {"1m": (60_000, 180), "5m": (300_000, 365), "15m": (900_000, 730), "30m": (1_800_000, 730),
      "1h": (3_600_000, 2600), "2h": (7_200_000, 2600), "4h": (14_400_000, 2600)}


def load(sym, tf):
    ms, days = TF[tf]
    CACHE.mkdir(exist_ok=True)
    f = CACHE / f"{sym}_{tf}.csv"
    rows = pd.read_csv(f).values.tolist() if f.exists() else []
    start = int(rows[-1][0]) + ms if rows else int(time.time() * 1000) - days * 86400_000
    now = int(time.time() * 1000)
    while start < now - ms:
        try:
            k = requests.get("https://fapi.binance.com/fapi/v1/klines",
                             params={"symbol": sym, "interval": tf, "startTime": start, "limit": 1500}, timeout=20).json()
        except Exception as exc:  # noqa: BLE001
            print("  сеть:", exc); time.sleep(3); continue
        if not isinstance(k, list) or not k:
            break
        rows += [[int(x[0]), float(x[1]), float(x[2]), float(x[3]), float(x[4]), float(x[5])] for x in k]
        start = int(k[-1][0]) + ms
        print(f"\r  {sym} {tf}: {pd.to_datetime(start, unit='ms'):%Y-%m-%d}   ", end="")
        time.sleep(0.12)
    print()
    if not rows:
        return None
    d = pd.DataFrame(rows, columns=["t", "o", "h", "l", "c", "v"]).drop_duplicates("t").sort_values("t").reset_index(drop=True)
    d.to_csv(f, index=False)
    return d


def main():
    lines = []
    now = int(time.time() * 1000); last90 = now - 90 * 86400_000
    for tf, (ms, _days) in TF.items():
        allt, coins_pos, n = [], 0, 0
        for s in COINS:
            d = load(s, tf)
            if d is None or len(d) < 500:
                continue
            (_lo, _lc), (ho, hc) = L.ha_htf(d, ms)
            up, dn = L.sig(ho, hc)
            tr = L.run_reverse(d, up, dn)
            allt += tr; n += 1; coins_pos += sum(x[1] for x in tr) > 0
        if not allt:
            continue
        t0 = min(x[0] for x in allt); mid = (t0 + now) // 2
        txt, ok = L.summary(allt, mid)
        r90 = [x[1] for x in allt if x[0] >= last90]
        s90 = f"последние 90 дн: {len(r90)} сд, {sum(r90) * 100:+.0f}%"
        mark = "✅" if ok and coins_pos >= 8 and sum(r90) > 0 else ("⚠️" if ok and coins_pos >= 8 else "❌")
        lines.append(f"{mark} {tf:>3} (старший ×18 = {ms * 18 // 60000} мин): {txt} | монет в плюсе {coins_pos}/{n} | {s90}")
        print(lines[-1])
    txt = "\n".join(lines)
    print("\n" + "=" * 30 + "\n" + txt)
    print("\n✅ — плюс в обеих половинах, ≥8/12 монет И в плюсе за последние 90 дней. ⚠️ — история в плюсе, но последние 90 дней в минусе.")
    print("Суммы — сложенные % по 12 монетам (по 1 позиции на монету, без плеча), комиссия 0.11% за круг учтена.")
    (BASE / "levando_tf_test.txt").write_text(txt + "\n", encoding="utf-8")
    input("\nEnter — закрыть")


if __name__ == "__main__":
    main()
