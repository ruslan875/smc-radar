"""okx_bx_adapter.py — 2026-11-02. Прослойка: функции «как у app.exchanges.bybit», но торгуют на OKX.

Нужна, чтобы живой скрипт Latuserge (написан под Bybit) работал на OKX без переписывания логики.
Все объёмы снаружи — в МОНЕТАХ (как у Bybit), внутри переводятся в контракты OKX через ctVal.
Пароль API (passphrase) задаётся один раз при старте: okx_bx_adapter.PASS = "...".
Позиции — isolated, стоп привязан к каждому ордеру (attachAlgoOrds, цена mark).
"""
from __future__ import annotations

import pandas as pd

from app.data import DataError  # noqa: F401  (живой скрипт ловит DataError)
from app.exchanges import okx

PASS: str | None = None
TRADE_BASE = "okx"   # чтобы проверка демо-режима в живом скрипте не падала


def get_instrument_info(symbol: str, category: str | None = None, **_kw) -> dict:
    i = okx.get_instrument(symbol)
    return {"tick_size": i["tickSz"], "qty_step": i["lotSz"] * i["ctVal"], "min_order_qty": i["minSz"] * i["ctVal"]}


def get_last_price(symbol: str, category: str | None = None, **_kw) -> float:
    return okx.get_last_price(symbol)


def set_leverage(api_key, api_secret, symbol, leverage, **_kw) -> None:
    okx.set_leverage(api_key, api_secret, symbol, int(leverage), passphrase=PASS, mgn_mode="isolated")


def place_order(api_key, api_secret, symbol, side, qty, stop_loss, take_profit=None, **_kw) -> dict:
    return okx.place_order(api_key, api_secret, symbol, side, float(qty), float(stop_loss), take_profit, passphrase=PASS)


def _cancel_algos(api_key, api_secret, inst_id: str) -> None:
    for ot in ("oco", "conditional"):
        try:
            pl = okx._signed_get_once("/api/v5/trade/orders-algo-pending", api_key, api_secret, PASS,  # noqa: SLF001
                                      {"instType": "SWAP", "ordType": ot})
        except Exception:  # noqa: BLE001
            continue
        ids = [{"algoId": a["algoId"], "instId": inst_id} for a in pl.get("data") or [] if a.get("instId") == inst_id]
        if ids:
            okx._signed_post("/api/v5/trade/cancel-algos", api_key, api_secret, PASS, ids)  # noqa: SLF001


def cancel_all_open_orders(api_key, api_secret, symbol, **_kw) -> None:
    inst_id = okx.to_inst_id(symbol)
    try:
        pl = okx._signed_get_once("/api/v5/trade/orders-pending", api_key, api_secret, PASS,  # noqa: SLF001
                                  {"instType": "SWAP", "instId": inst_id})
        for o in pl.get("data") or []:
            okx._signed_post("/api/v5/trade/cancel-order", api_key, api_secret, PASS,  # noqa: SLF001
                             {"instId": inst_id, "ordId": o["ordId"]})
    except Exception:  # noqa: BLE001
        pass
    _cancel_algos(api_key, api_secret, inst_id)


def close_position(api_key, api_secret, symbol, side, qty, **_kw) -> None:
    pos = okx.fetch_position(api_key, api_secret, PASS, symbol)
    if not pos:
        return
    okx.close_position(api_key, api_secret, PASS, symbol, mgn_mode=pos.get("mgn_mode") or "isolated",
                       pos_side=pos.get("pos_side") if pos.get("pos_side") in ("long", "short") else None)
    _cancel_algos(api_key, api_secret, okx.to_inst_id(symbol))   # хвосты стопов от долитых ног


def fetch_open_positions(api_key, api_secret, *_a, **_kw) -> pd.DataFrame:
    df = okx.fetch_open_positions(api_key, api_secret, PASS)
    if df is None or df.empty:
        return pd.DataFrame(columns=["symbol", "qty", "avg_entry_price"])
    df = df.copy()
    df["qty"] = [float(q) * okx.get_instrument(s)["ctVal"] for s, q in zip(df["symbol"], df["qty"])]   # контракты -> монеты
    return df


def fetch_closed_trades(api_key, api_secret, *_a, lookback_days: int = 2, **_kw) -> pd.DataFrame:
    return okx.fetch_closed_trades(api_key, api_secret, PASS, lookback_days=lookback_days)
