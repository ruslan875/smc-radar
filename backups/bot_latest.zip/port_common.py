#!/usr/bin/env python3
"""
Shared scaffolding for the ported-strategy backtests
=====================================================

Everything that is identical across ports and has nothing to do with any
particular strategy: loading candles, writing the run manifest, printing the
per-symbol summary, and the deal-log schema the analyzer reads.

THE DEAL LOG SCHEMA - do not change it casually

    entry_time, exit_time, side, entry_price, exit_price, gross_pnl_pct, reason

`analyze_external_strategies.py` requires exactly these columns. Despite the
name, gross_pnl_pct is NET: commission and slippage are already inside it.
The name is historical and the analyzer's header says so out loud; renaming it
now would silently break every deal log already on disk.

`reason` should be one of: stop_loss, take_profit, reverse, signal_exit,
partial, timeout, end_of_data. The analyzer counts stop_loss and take_profit
by name for its stop/target split, so a new port inventing its own spelling
disappears from that breakdown without erroring.
"""

from __future__ import annotations

import datetime as _dt
import json as _json
import sys
from pathlib import Path

import pandas as pd

DEAL_COLUMNS = ["entry_time", "exit_time", "side", "entry_price",
                "exit_price", "gross_pnl_pct", "reason"]


# ---------------------------------------------------------------------------
# data
# ---------------------------------------------------------------------------

def load_from_csv(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    df.columns = [c.lower() for c in df.columns]
    ts_col = "timestamp" if "timestamp" in df.columns else df.columns[0]
    df[ts_col] = pd.to_datetime(df[ts_col], errors="coerce")
    df = df.set_index(ts_col).sort_index()
    return df[["open", "high", "low", "close", "volume"]]


def load_from_ccxt(symbol: str, timeframe: str, start: str, end: str,
                   exchange_id: str = "bybit", market: str = "swap") -> pd.DataFrame:
    """Delegates to market_data.load_ohlcv - the cached, retrying, perp-aware
    loader. Kept as a thin wrapper so the ports read the same as the older
    five, which call `load_from_ccxt`."""
    try:
        from market_data import load_ohlcv
    except ImportError:
        print("ERROR: market_data.py must sit next to this script.", file=sys.stderr)
        raise
    return load_ohlcv(symbol, timeframe, start, end,
                      exchange_id=exchange_id, market=market)


def load_sources(args, parser) -> dict:
    """Resolve --csv / --symbol / --symbols into {name: ohlcv frame}."""
    if getattr(args, "csv", None):
        name = Path(args.csv).stem
        return {name: load_from_csv(args.csv)}

    symbols = getattr(args, "symbols", None) or (
        [args.symbol] if getattr(args, "symbol", None) else None)
    if not symbols:
        parser.error("Provide --symbol, --symbols, or --csv")

    out = {}
    for sym in symbols:
        print(f"Fetching {sym} {args.timeframe} from {args.exchange} "
              f"({args.start} -> {args.end})...")
        out[sym] = load_from_ccxt(sym, args.timeframe, args.start, args.end,
                                  args.exchange, args.market)
    return out


# ---------------------------------------------------------------------------
# run manifest
# ---------------------------------------------------------------------------

def manifest_symbols(args) -> list:
    """Symbols for the manifest, taken from the ARGUMENTS, not from loaded data.

    The output folder is created before the fetch in several of these scripts,
    and an earlier version of this read the loaded frames there - which raised
    UnboundLocalError in exactly the two scripts that created the folder first.
    """
    syms = list(getattr(args, "symbols", None) or [])
    if not syms and getattr(args, "symbol", None):
        syms = [args.symbol]
    if not syms and getattr(args, "csv", None):
        syms = [Path(args.csv).stem]
    return syms


def write_manifest(out_dir: Path, script: str, args, extra_keys=()) -> None:
    """Record the conditions this run happened under, next to its deal logs.

    Two runs with different timeframes once landed in the same folder and the
    second overwrote the first; the comparison table then showed numbers from
    settings nobody could reconstruct. The analyzer reads this file and prints
    the conditions beside the metrics, so a mismatched folder says so.
    """
    man = {
        "strategy": script,
        "run_at": _dt.datetime.now().astimezone().isoformat(timespec="seconds"),
        "symbols": manifest_symbols(args),
        "timeframe": getattr(args, "timeframe", None),
        "start": getattr(args, "start", None),
        "end": getattr(args, "end", None),
        "exchange": getattr(args, "exchange", None),
        "market": getattr(args, "market", None),
        "commission_pct": getattr(args, "commission", None),
        "slippage_pct": getattr(args, "slippage_pct", None),
        "source": "csv" if getattr(args, "csv", None) else "exchange",
    }
    for k in extra_keys:
        if hasattr(args, k):
            man[k] = getattr(args, k)
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "_run.json").write_text(_json.dumps(man, indent=2), encoding="utf-8")


# ---------------------------------------------------------------------------
# deals
# ---------------------------------------------------------------------------

def net_pnl_pct(side: str, entry: float, exit_: float,
                commission_pct: float, slippage_pct: float) -> float:
    """Percent return on the position, after both fills' costs.

    Slippage is applied as a haircut on each side rather than being baked into
    the prices, so the deal log still shows the price level the rule fired at.
    """
    gross = (exit_ / entry - 1.0) if side == "long" else (1.0 - exit_ / entry)
    return (gross * 100.0) - 2.0 * commission_pct - 2.0 * slippage_pct


def deals_frame(deals: list) -> pd.DataFrame:
    df = pd.DataFrame(deals)
    if df.empty:
        return pd.DataFrame(columns=DEAL_COLUMNS)
    missing = set(DEAL_COLUMNS) - set(df.columns)
    if missing:
        raise ValueError(f"deal log is missing columns: {sorted(missing)}")
    extra = [c for c in df.columns if c not in DEAL_COLUMNS]
    return df[DEAL_COLUMNS + extra]


def print_summary(symbol: str, deals: pd.DataFrame, note: str = "") -> None:
    n = len(deals)
    if n == 0:
        print(f"  {symbol:14s}:    0 trades")
        return
    pnl = deals["gross_pnl_pct"].astype(float)
    wins, losses = pnl[pnl > 0], pnl[pnl <= 0]
    gp, gl = wins.sum(), -losses.sum()
    pf = (gp / gl) if gl > 0 else float("inf")
    total = ((1 + pnl / 100).prod() - 1) * 100
    print(f"  {symbol:14s}: {n:4d} trades | avg P&L {pnl.mean():+6.2f}% | "
          f"win rate {len(wins) / n * 100:5.1f}% | PF {pf:6.2f} | total {total:8.2f}%")
    counts = deals["reason"].value_counts().to_dict()
    print(f"                  exits: {counts}" + (f" | {note}" if note else ""))
