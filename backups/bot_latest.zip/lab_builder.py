"""Конструктор стратегий из индикаторов для «🔍 Автоподбора». 2026-09-26.

Стратегия = ТРИГГЕР (событие: пересечение/пробой) + 0–2 ФИЛЬТРА (состояние:
тренд, сила, объём) + ВЫХОД (стоп/тейк в ATR, максимум N свечей), отдельно
для LONG и SHORT, на 15m / 1h / 4h.

Перебор: 18 триггеров × (без фильтра + 12 фильтров + пары фильтров) × 2 стороны
× 4 выхода × 3 ТФ ≈ 30 000 вариантов. Чтобы не подогнать под историю, период
делится 60/40: стратегия проходит, только если прибыльна И на первых 60%
(где искали), И на последних 40% (которые перебор «не видел»).

Исполнение как везде: сигнал на закрытии свечи, вход по close, стоп/тейк по
high/low следующих свечей (оба в одной свече -> стоп), комиссия 0.055% +
проскальзывание 0.02% на сторону.
"""
from __future__ import annotations

import itertools
import math

import numpy as np
import pandas as pd

COST = 2 * (0.00055 + 0.0002)
EXITS = [(1.0, 2.0), (1.5, 2.0), (1.5, 3.0), (2.0, 4.0),     # (стоп, тейк) в ATR
         (2.0, 0.0), (3.0, 0.0)]                             # тейк 0 = ТРЕЙЛИНГ: стоп k·ATR за экстремумом
TRAIL_HOLD = 240                                             # трейлинг держит дольше (до 240 свечей)
MAX_HOLD = 96
# скальп на 5m: короткие стоп/тейк, не дольше 6 свечей (30 минут)
EXITS_SCALP = [(0.5, 1.0), (0.75, 1.5), (1.0, 1.0), (1.0, 2.0)]
HOLD_SCALP = 6
COST_MAKER = 2 * 0.0002 + 0.0002          # лимитки: 0.02% × 2 + запас на неисполнение/проскальзывание


def plan(tf):
    return (EXITS_SCALP, HOLD_SCALP) if tf in ("1m", "5m") else (EXITS, MAX_HOLD)
SPLIT = 0.6
# 2026-10-10: проверка показала, что 60/40 не защищает (2 из 3 «прошедших» сборок теряли на новых данных).
# Теперь последние 25% истории подбор НЕ видит вовсе; вердикт ставится по ним.
HOLD = 0.25


def verdict(pf_hold, n_hold, coins_share=None):
    if n_hold < 8:
        return "⚠️ мало сделок в проверке", "в отложенных 25% истории меньше 8 сделок — оценить нельзя"
    if pf_hold < 1.05:
        return "❌ подгонка", f"на отложенных 25% истории (их подбор не видел) PF {pf_hold:.2f} — на новых данных не работает"
    if coins_share is not None and coins_share < 0.7:
        return "⚠️ только на этой монете", f"на других монетах в плюсе лишь {coins_share * 100:.0f}% — похоже на случайность"
    return "✅ кандидат на бумагу", f"в плюсе и на отложенной истории (PF {pf_hold:.2f})" + (
        f" и на {coins_share * 100:.0f}% других монет" if coins_share is not None else "") + " — проверить paper-ботом"


# ---------- 34 индикатора терминала (тот же движок, lab_js/indicatorEngine.js) ----------
ENGINE_W = 520          # хватает всем 34 (EMA500 нужно >500), на 15% быстрее 600


def engine_signals(d: pd.DataFrame, sym: str, tf: str, prog=None):
    """Сигналы 34 индикаторов «Мозга» на каждой свече d (int8 n×34) + имена.
    Кеш market_cache/signals/<SYM>_<tf>.npz, досчитываются только новые свечи."""
    import json, shutil, subprocess, tempfile
    from pathlib import Path
    base = Path(__file__).resolve().parent
    node = shutil.which("node")
    if not node:
        # 2026-10-03: процессы, запущенные без окна, иногда не видят PATH с node —
        # тогда «⚙»-индикаторы молча не срабатывали и paper-бот сидел с 0 сделок.
        import os as _o
        for cand in (r"C:\Program Files\nodejs\node.exe", r"C:\Program Files (x86)\nodejs\node.exe",
                     _o.path.expandvars(r"%APPDATA%\nvm\current\node.exe"),
                     _o.path.expandvars(r"%LOCALAPPDATA%\Programs\nodejs\node.exe")):
            if _o.path.isfile(cand):
                node = cand
                break
    if not node:
        raise RuntimeError("не найден node.exe — индикаторы «⚙» не считаются (установи Node.js)")
    cdir = base / "market_cache" / "signals"; cdir.mkdir(parents=True, exist_ok=True)
    cf = cdir / f"{sym}_{tf}.npz"
    t = d.t.to_numpy().astype("int64")
    have_t = np.array([], dtype="int64"); have_s = np.zeros((0, 34), dtype=np.int8); names = []
    if cf.exists():
        # другой процесс мог в этот момент переписывать кеш — пробуем ещё раз, иначе считаем заново
        for _try in range(5):
            try:
                with np.load(cf, allow_pickle=True) as z:
                    have_t, have_s, names = z["t"], z["sig"], list(z["names"])
                break
            except Exception:  # noqa: BLE001 -- "File is not a zip file" при одновременной записи
                import time as _t; _t.sleep(0.5 + _try * 0.5)
    known = set(have_t.tolist())
    # первые 60 свечей движок не считает (разогрев) — их не ждём в кеше, иначе пересчёт каждый раз
    new_idx = [i for i in range(60, len(t)) if int(t[i]) not in known]
    if new_idx:
        s0 = new_idx[0]; lo = max(0, s0 - ENGINE_W)
        with tempfile.TemporaryDirectory() as td:
            inp, outp = Path(td) / "in.csv", Path(td) / "out.json"
            d.iloc[lo:][["t", "open", "high", "low", "close", "volume"]].to_csv(inp, index=False)
            if prog:
                prog(f"34 индикатора терминала: {len(t) - s0} свечей {tf} (один раз, дальше из кеша)…")
            subprocess.run([node, str(base / "lab_js" / "lab_signals.js"), str(inp), str(outp), str(ENGINE_W), str(s0 - lo)],
                           check=True, capture_output=True, timeout=3600)
            r = json.loads(outp.read_text(encoding="utf-8"))
        names = r["names"]
        nt = np.array(r["t"], dtype="int64"); ns = np.array(r["sig"], dtype=np.int8).reshape(-1, len(names))
        keep = ~np.isin(have_t, nt)
        have_t = np.concatenate([have_t[keep], nt]); have_s = np.concatenate([have_s[keep], ns])
        o = np.argsort(have_t); have_t, have_s = have_t[o], have_s[o]
        import os as _os, time as _t
        tmp = cf.with_name(f"{cf.stem}.{_os.getpid()}.tmp.npz")   # пишем во временный, потом атомарно заменяем
        np.savez_compressed(tmp, t=have_t, sig=have_s, names=np.array(names, dtype=object))
        for _try in range(8):
            try:
                tmp.replace(cf); break
            except PermissionError:
                _t.sleep(0.4 + _try * 0.4)
        else:
            try: tmp.unlink()
            except OSError: pass
    pos = {int(x): i for i, x in enumerate(have_t)}
    out = np.zeros((len(t), len(names)), dtype=np.int8)
    for i, x in enumerate(t):
        j = pos.get(int(x))
        if j is not None:
            out[i] = have_s[j]
    return out, names


def engine_features(eng, names):
    """Из сигналов движка: триггеры (момент появления LONG/SHORT) и фильтры (состояние)."""
    trig, filt = {}, {}
    if eng is None:
        return trig, filt
    for k, nm in enumerate(names):
        s = eng[:, k]; prev = np.concatenate([[0], s[:-1]])
        if (s != 0).sum() < 10:
            continue
        trig[f"⚙ {nm}"] = ((s == 1) & (prev != 1), (s == -1) & (prev != -1))
        filt[f"⚙ {nm}"] = (s == 1, s == -1)
    score = (eng == 1).sum(axis=1) - (eng == -1).sum(axis=1)
    score = score / max(len(names), 1)
    L, S = score > 0.15, score < -0.15
    pL, pS = np.concatenate([[False], L[:-1]]), np.concatenate([[False], S[:-1]])
    trig["🧠 Мозг: консенсус 34"] = (L & ~pL, S & ~pS)
    filt["🧠 Мозг: консенсус 34"] = (L, S)
    return trig, filt


# ---------- индикаторы ----------
def _rma(s, n): return s.ewm(alpha=1 / n, adjust=False).mean()
def _ema(s, n): return s.ewm(span=n, adjust=False).mean()


def _atr(d, n=14):
    pc = d.close.shift()
    tr = pd.concat([d.high - d.low, (d.high - pc).abs(), (d.low - pc).abs()], axis=1).max(axis=1)
    return _rma(tr, n)


def _rsi(c, n=14):
    x = c.diff()
    return 100 - 100 / (1 + _rma(x.clip(lower=0), n) / _rma(-x.clip(upper=0), n))


def _up(a, b):   # a пересёк b снизу вверх (b — ряд или число)
    bs = b.shift() if isinstance(b, pd.Series) else b
    return (a > b) & (a.shift() <= bs)


def _supertrend(d, n=10, m=3.0):
    atr = _atr(d, n).to_numpy(); hl2 = ((d.high + d.low) / 2).to_numpy(); c = d.close.to_numpy()
    up, dn = hl2 - m * atr, hl2 + m * atr
    fu, fd = up.copy(), dn.copy(); dirn = np.ones(len(c))
    for i in range(1, len(c)):
        fu[i] = max(up[i], fu[i - 1]) if c[i - 1] > fu[i - 1] else up[i]
        fd[i] = min(dn[i], fd[i - 1]) if c[i - 1] < fd[i - 1] else dn[i]
        dirn[i] = 1 if c[i] > fd[i - 1] else (-1 if c[i] < fu[i - 1] else dirn[i - 1])
    return pd.Series(dirn, d.index)


def features(d: pd.DataFrame):
    """-> triggers {name: (long, short)}, filters {name: (long, short)} — numpy bool."""
    c, h, l, v = d.close, d.high, d.low, d.volume
    rsi = _rsi(c)
    macd = _ema(c, 12) - _ema(c, 26); sig = _ema(macd, 9)
    e9, e21, e20, e50, e200 = _ema(c, 9), _ema(c, 21), _ema(c, 20), _ema(c, 50), _ema(c, 200)
    bm = c.rolling(20).mean(); bs = c.rolling(20).std(ddof=0); bu, bl = bm + 2 * bs, bm - 2 * bs
    atr = _atr(d)
    kcu, kcl = e20 + 2 * atr, e20 - 2 * atr
    tp = (h + l + c) / 3
    # CCI: среднее отклонение окнами numpy (в 50–100 раз быстрее rolling.apply на 5m-истории)
    from numpy.lib.stride_tricks import sliding_window_view as _swv
    _tpv = tp.to_numpy(dtype=float); _md = np.full(len(_tpv), np.nan)
    if len(_tpv) >= 20:
        _w = _swv(_tpv, 20); _md[19:] = np.abs(_w - _w.mean(axis=1, keepdims=True)).mean(axis=1)
    cci = (tp - tp.rolling(20).mean()) / (0.015 * pd.Series(_md, tp.index))
    ll, hh = l.rolling(14).min(), h.rolling(14).max()
    k = 100 * (c - ll) / (hh - ll); kd = k.rolling(3).mean()
    wr = -100 * (hh - c) / (hh - ll)
    mf = tp * v; pos = mf.where(tp > tp.shift(), 0).rolling(14).sum(); neg = mf.where(tp < tp.shift(), 0).rolling(14).sum()
    mfi = 100 - 100 / (1 + pos / neg)
    dch, dcl = h.rolling(20).max().shift(), l.rolling(20).min().shift()
    st = _supertrend(d)
    up_, dn_ = h.diff(), -l.diff()
    pdm = pd.Series(np.where((up_ > dn_) & (up_ > 0), up_, 0.0), d.index)
    mdm = pd.Series(np.where((dn_ > up_) & (dn_ > 0), dn_, 0.0), d.index)
    pdi, mdi = 100 * _rma(pdm, 14) / atr, 100 * _rma(mdm, 14) / atr
    adx = _rma(100 * (pdi - mdi).abs() / (pdi + mdi), 14)
    diff = c.diff(); cmo = 100 * (diff.clip(lower=0).rolling(9).sum() - (-diff.clip(upper=0)).rolling(9).sum()) / diff.abs().rolling(9).sum()
    roc = c.pct_change(9) * 100
    tenkan = (h.rolling(9).max() + l.rolling(9).min()) / 2; kijun = (h.rolling(26).max() + l.rolling(26).min()) / 2
    spa = ((tenkan + kijun) / 2).shift(26); spb = ((h.rolling(52).max() + l.rolling(52).min()) / 2).shift(26)
    atrp = atr / c * 100
    trig = {
        "RSI выход из 30/70": (_up(rsi, 30), (rsi < 70) & (rsi.shift() >= 70)),
        "RSI пересёк 50": (_up(rsi, 50), (rsi < 50) & (rsi.shift() >= 50)),
        "MACD × сигнальная": (_up(macd, sig), _up(sig, macd)),
        "MACD × ноль": (_up(macd, 0 * macd), (macd < 0) & (macd.shift() >= 0)),
        "EMA 9 × 21": (_up(e9, e21), _up(e21, e9)),
        "EMA 20 × 50": (_up(e20, e50), _up(e50, e20)),
        "Supertrend разворот": ((st == 1) & (st.shift() == -1), (st == -1) & (st.shift() == 1)),
        "BB возврат в канал": (_up(c, bl), _up(bu, c)),
        "BB пробой": (_up(c, bu), _up(bl, c)),
        "Donchian 20 пробой": (_up(c, dch), _up(dcl, c)),
        "Stoch × в зоне": (_up(k, kd) & (k < 25), _up(kd, k) & (k > 75)),
        "CCI выход из ±100": (_up(cci, -100 + 0 * cci), (cci < 100) & (cci.shift() >= 100)),
        "Williams %R выход": (_up(wr, -80 + 0 * wr), (wr < -20) & (wr.shift() >= -20)),
        "Keltner возврат": (_up(c, kcl), _up(kcu, c)),
        "MFI выход из 20/80": (_up(mfi, 20 + 0 * mfi), (mfi < 80) & (mfi.shift() >= 80)),
        "ROC пересёк 0": (_up(roc, 0 * roc), (roc < 0) & (roc.shift() >= 0)),
        "Цена × EMA50": (_up(c, e50), _up(e50, c)),
        "Ichimoku TK-кросс": (_up(tenkan, kijun), _up(kijun, tenkan)),
    }
    both = lambda x: (x, x)  # noqa: E731
    filt = {
        "выше/ниже EMA200": (c > e200, c < e200),
        "выше/ниже EMA50": (c > e50, c < e50),
        "ADX > 20": both(adx > 20),
        "ADX > 25": both(adx > 25),
        "+DI/−DI по стороне": (pdi > mdi, mdi > pdi),
        "RSI по стороне 50": (rsi > 50, rsi < 50),
        "MACD по стороне 0": (macd > 0, macd < 0),
        "Supertrend по стороне": (st == 1, st == -1),
        "ATR% выше медианы": both(atrp > atrp.rolling(100).median()),
        "Объём > 1.5× среднего": both(v > 1.5 * v.rolling(20).mean()),
        "CMO по стороне": (cmo > 0, cmo < 0),
        "над/под облаком Ichimoku": (c > np.maximum(spa, spb), c < np.minimum(spa, spb)),
    }
    np_ = lambda t: (np.nan_to_num(t[0].to_numpy(dtype=float)).astype(bool), np.nan_to_num(t[1].to_numpy(dtype=float)).astype(bool))  # noqa: E731
    return {k: np_(x) for k, x in trig.items()}, {k: np_(x) for k, x in filt.items()}, atr.to_numpy()


# ---------- исходы входов (одна раскладка на все комбинации) ----------
def outcomes(d, atr, cand, side, sl_m, tp_m, H=MAX_HOLD, cost=COST):
    """Для каждого бара-кандидата: индекс выхода и чистая доходность (векторно, окнами по 96 свечей)."""
    from numpy.lib.stride_tricks import sliding_window_view as swv
    o, h, l, c = (d[k].to_numpy(dtype=float) for k in ("open", "high", "low", "close"))
    n = len(c)
    ex_i = np.full(n, -1); ret = np.zeros(n); why = np.zeros(n, dtype=np.int8)
    pad = lambda x, v: np.concatenate([x, np.full(H + 1, v)])  # noqa: E731
    hp, lp = pad(h, np.nan), pad(l, np.nan)
    Wh, Wl = swv(hp[1:], H), swv(lp[1:], H)          # строка i = свечи i+1 .. i+H
    idx = np.flatnonzero(cand & (atr > 0))
    idx = idx[idx < n - 1]
    for a in range(0, len(idx), 20000):
        ii = idx[a:a + 20000]
        e = c[ii]; A = atr[ii]
        if tp_m <= 0:
            # трейлинг (chandelier): стоп = экстремум ПРЕДЫДУЩИХ свечей сделки ∓ k·ATR входа, не хуже начального
            if side > 0:
                ext = np.maximum.accumulate(np.nan_to_num(Wh[ii], nan=-np.inf), axis=1)
                prev = np.concatenate([e[:, None], np.maximum(ext[:, :-1], e[:, None])], axis=1)
                stp = np.maximum(prev - sl_m * A[:, None], (e - sl_m * A)[:, None])
                hs = Wl[ii] <= stp
            else:
                ext = np.minimum.accumulate(np.nan_to_num(Wl[ii], nan=np.inf), axis=1)
                prev = np.concatenate([e[:, None], np.minimum(ext[:, :-1], e[:, None])], axis=1)
                stp = np.minimum(prev + sl_m * A[:, None], (e + sl_m * A)[:, None])
                hs = Wh[ii] >= stp
            s_ = np.where(hs.any(1), hs.argmax(1), 10**9)
            stop = s_ < 10**9
            j = np.minimum(np.where(stop, ii + 1 + np.minimum(s_, H - 1), np.minimum(ii + H, n - 1)), n - 1)
            lvl = stp[np.arange(len(ii)), np.minimum(s_, H - 1)]
            oj = o[j]
            px = np.where(stop, (np.minimum(lvl, oj) if side > 0 else np.maximum(lvl, oj)), c[j])
            r_ = side * (px / e - 1)
            ex_i[ii] = j; ret[ii] = r_ - cost
            why[ii] = np.where(stop, np.where(r_ > 0, 4, 1), 3)
            continue
        if side > 0:
            sl, tp = e - sl_m * A, e + tp_m * A
            hs, ht = Wl[ii] <= sl[:, None], Wh[ii] >= tp[:, None]
        else:
            sl, tp = e + sl_m * A, e - tp_m * A
            hs, ht = Wh[ii] >= sl[:, None], Wl[ii] <= tp[:, None]
        s_ = np.where(hs.any(1), hs.argmax(1), 10**9); t_ = np.where(ht.any(1), ht.argmax(1), 10**9)
        last = np.minimum(ii + H, n - 1)
        stop = (s_ <= t_) & (s_ < 10**9); take = (t_ < s_)
        j = np.where(stop, ii + 1 + np.minimum(s_, H), np.where(take, ii + 1 + np.minimum(t_, H), last))
        j = np.minimum(j, n - 1)
        oj = o[j]
        if side > 0:
            px = np.where(stop, np.minimum(sl, oj), np.where(take, np.maximum(tp, oj), c[j]))
        else:
            px = np.where(stop, np.maximum(sl, oj), np.where(take, np.minimum(tp, oj), c[j]))
        ex_i[ii] = j; ret[ii] = side * (px / e - 1) - cost; why[ii] = np.where(stop, 1, np.where(take, 2, 3))
    return ex_i, ret, why


def pick_trades(entries, ex_i):
    """Одна позиция за раз: берём вход, пропускаем сигналы до его выхода."""
    out = []; busy = -1
    for i in entries:
        if i <= busy or ex_i[i] < 0:
            continue
        out.append(i); busy = ex_i[i]
    return out


def _pf(r):
    w = r[r > 0].sum(); l_ = -r[r <= 0].sum()
    return w / l_ if l_ > 0 else (9.99 if w > 0 else 0.0)


def search(frames: dict, prog, top=40, engines=None, cost=COST):
    """frames: {tf: DataFrame сигнального ТФ}; engines: {tf: (eng, names)}. -> лучшие стратегии."""
    res = []
    total = len(frames) * 2 * len(EXITS); k = 0
    min_tr = 25
    for tf, d in frames.items():
        trig, filt, atr = features(d)
        core = list(filt)                                   # классические фильтры (тренд/сила/объём)
        et, ef = engine_features(*(engines or {}).get(tf, (None, [])))
        trig.update(et); filt.update(ef)
        hi = int(len(d) * (1 - HOLD))
        split = int(hi * SPLIT)
        fnames = list(filt)
        # пары: только «классический фильтр + любой другой» — иначе вариантов миллионы
        pairs = [(a, b) for a, b in itertools.combinations(fnames, 2) if a in core or b in core]
        fsets = [()] + [(f,) for f in fnames] + pairs
        for side in (1, -1):
            s_ = 0 if side > 0 else 1
            cand = np.zeros(len(d), bool)
            for t in trig.values():
                cand |= t[s_]
            exits, hold = plan(tf)
            for sl_m, tp_m in exits:
                k += 1
                prog(k / total, f"конструктор {tf} {'LONG' if side > 0 else 'SHORT'} стоп {sl_m} ATR · {'трейлинг' if tp_m <= 0 else f'тейк {tp_m} ATR'}")
                h_ = TRAIL_HOLD if tp_m <= 0 else hold
                ex_i, ret, _w = outcomes(d, atr, cand, side, sl_m, tp_m, h_, cost)
                valid = ex_i >= 0
                fl = {f: v[s_] for f, v in filt.items()}
                for tname, tv in trig.items():
                    ent0 = np.flatnonzero(tv[s_] & valid)
                    if len(ent0) < 25:
                        continue
                    for fs in fsets:
                        sel = ent0
                        for f in fs:
                            sel = sel[fl[f][sel]]
                            if len(sel) < 25:
                                break
                        if len(sel) < 25:
                            continue
                        # быстрый отсев по всем сигналам (без учёта «одна позиция за раз»)
                        r0 = ret[sel]; isa = sel < split; isb = (sel >= split) & (sel < hi)
                        if _pf(r0[isa]) < 1.05 or _pf(r0[isb]) < 1.0:
                            continue
                        tr = np.array(pick_trades(sel, ex_i))
                        if len(tr) < 25:
                            continue
                        r = ret[tr]; a = r[tr < split]; b = r[(tr >= split) & (tr < hi)]; hh = r[tr >= hi]
                        if len(a) < 15 or len(b) < 8:
                            continue
                        pa, pb = _pf(a), _pf(b)
                        if pa < 1.1 or pb < 1.05:
                            continue
                        res.append({"tf": tf, "side": side, "trigger": tname, "filters": list(fs), "sl": sl_m, "tp": tp_m,
                                    "hold": h_, "cost": cost,
                                    "pf_hold": round(_pf(hh), 2) if len(hh) else 0.0, "n_hold": int(len(hh)),
                                    "trades": int(len(r)), "pf": round(_pf(r), 2), "pf1": round(pa, 2), "pf2": round(pb, 2),
                                    "ret": round(float(r.sum() * 100), 1), "win": round(float((r > 0).mean() * 100), 1),
                                    "score": round(min(pa, pb) * math.log(len(r)), 3)})
    res.sort(key=lambda x: -x["score"])
    # не больше 3 вариантов одного триггера на ТФ/сторону — иначе топ забит клонами
    # 2026-09-27: раньше брался общий топ-40, и 15m (где PF ниже из-за комиссии) вытеснялись
    # сборками 4h/1h. Теперь квота: до 20 лучших на КАЖДЫЙ ТФ и сторону (LONG/SHORT отдельно).
    seen, cnt, out = {}, {}, []
    per = max(top // 2, 10)
    for r in res:
        key = (r["tf"], r["side"], r["trigger"])
        if seen.get(key, 0) >= 3:
            continue
        grp = (r["tf"], r["side"])
        if cnt.get(grp, 0) >= per:
            continue
        seen[key] = seen.get(key, 0) + 1
        cnt[grp] = cnt.get(grp, 0) + 1
        out.append(r)
    return out


def search_pooled(coin_frames: dict, prog, engines=None, cost=COST, min_month=20.0, top=40):
    """Портфельный автоподбор: одна сборка проверяется СРАЗУ на всех монетах.

    coin_frames: {sym: {tf: DataFrame}}; engines: {sym: {tf: (eng, names)}}.
    Проходит, только если: суммарный PF по всем монетам > 1.1 на 60% истории и > 1.05 на 40%,
    прибыльна (PF > 1) больше чем на половине монет, где были сделки, и даёт по портфелю
    не меньше min_month сделок в месяц. Так частота берётся из числа монет, а не из шума."""
    syms = list(coin_frames)
    tfs = sorted({tf for fr in coin_frames.values() for tf in fr})
    res = []
    # подготовка по монетам: признаки + месяцы истории
    prep = {}; HOLD_AT = {}
    months = 0.0
    for k, sym in enumerate(syms):
        for tf, d in coin_frames[sym].items():
            trig, filt, atr = features(d)
            core = set(filt)
            et, ef = engine_features(*((engines or {}).get(sym, {}).get(tf, (None, []))))
            trig.update(et); filt.update(ef)
            _hi = int(len(d) * (1 - HOLD)); HOLD_AT[(sym, tf)] = _hi
            prep[(sym, tf)] = (d, trig, filt, core, atr, int(_hi * SPLIT))
            months = max(months, (int(d.t.iloc[-1]) - int(d.t.iloc[0])) / 86_400_000 / 30.4)
        prog(0.15 * (k + 1) / len(syms), f"признаки {sym} ({k + 1}/{len(syms)})")
    months = max(months, 1.0)
    total = sum(2 * len(plan(tf)[0]) for tf in tfs); step = 0
    for tf in tfs:
        keys = [(s_, tf) for s_ in syms if (s_, tf) in prep]
        if not keys:
            continue
        # общие имена: только те триггеры/фильтры, что есть у большинства монет
        from collections import Counter
        tc = Counter(t for kk in keys for t in prep[kk][1]); fc = Counter(f for kk in keys for f in prep[kk][2])
        need = max(1, int(len(keys) * 0.7))
        tnames = [t for t, c in tc.items() if c >= need]
        fnames = [f for f, c in fc.items() if c >= need]
        core = set.intersection(*(prep[kk][3] for kk in keys))
        pairs = [(a, b) for a, b in itertools.combinations(fnames, 2) if a in core or b in core]
        fsets = [()] + [(f,) for f in fnames] + pairs
        exits, hold = plan(tf)
        for side in (1, -1):
            si = 0 if side > 0 else 1
            for sl_m, tp_m in exits:
                step += 1
                prog(0.15 + 0.83 * step / total,
                     f"портфель {tf} {'LONG' if side > 0 else 'SHORT'} стоп {sl_m} ATR · {'трейлинг' if tp_m <= 0 else f'тейк {tp_m} ATR'} · {len(keys)} монет")
                h_ = TRAIL_HOLD if tp_m <= 0 else hold
                per = {}
                for kk in keys:
                    d, trig, filt, _c, atr, split = prep[kk]
                    cand = np.zeros(len(d), bool)
                    for t in tnames:
                        if t in trig:
                            cand |= trig[t][si]
                    ex_i, ret, _w = outcomes(d, atr, cand, side, sl_m, tp_m, h_, cost)
                    per[kk] = (ex_i, ret, ex_i >= 0, {f: v[si] for f, v in filt.items()}, trig, split)
                for tname in tnames:
                    base = {}
                    for kk, (ex_i, ret, valid, fl, trig, split) in per.items():
                        if tname in trig:
                            base[kk] = np.flatnonzero(trig[tname][si] & valid)
                    if sum(len(v) for v in base.values()) < 60:
                        continue
                    for fs in fsets:
                        # быстрый отсев по всем сигналам всех монет
                        r_a, r_b, sels = [], [], {}
                        for kk, e0 in base.items():
                            ex_i, ret, valid, fl, trig, split = per[kk]
                            sel = e0
                            for f in fs:
                                if f not in fl:
                                    sel = sel[:0]; break
                                sel = sel[fl[f][sel]]
                                if not len(sel):
                                    break
                            if len(sel):
                                sels[kk] = sel
                                r_a.append(ret[sel[sel < split]]); r_b.append(ret[sel[(sel >= split) & (sel < HOLD_AT[kk])]])
                        if not sels:
                            continue
                        ra, rb = np.concatenate(r_a), np.concatenate(r_b)
                        if len(ra) + len(rb) < min_month * months * 0.8 or _pf(ra) < 1.05 or _pf(rb) < 1.0:
                            continue
                        # честный расчёт: одна позиция за раз на каждой монете
                        A, B, n_tr, ok_c, act_c, per_coin = [], [], 0, 0, 0, {}; HH, hok, hn = [], 0, 0
                        for kk, sel in sels.items():
                            ex_i, ret, valid, fl, trig, split = per[kk]
                            tr = np.array(pick_trades(sel, ex_i), dtype=int)
                            if not len(tr):
                                continue
                            r = ret[tr]; n_tr += len(r); act_c += 1
                            _h = HOLD_AT[kk]; A.append(r[tr < split]); B.append(r[(tr >= split) & (tr < _h)]); _x = r[tr >= _h]; HH.append(_x)
                            if len(_x) >= 3:
                                hn += 1; hok += int(_pf(_x) > 1.0)
                            if _pf(r) > 1.0:
                                ok_c += 1
                            per_coin[kk[0]] = round(float(r.sum() * 100), 1)
                        if not act_c:
                            continue
                        a_, b_ = np.concatenate(A), np.concatenate(B)
                        pm = n_tr / months
                        if pm < min_month or len(a_) < 30 or len(b_) < 15:
                            continue
                        pa, pb = _pf(a_), _pf(b_)
                        share = ok_c / act_c
                        if pa < 1.1 or pb < 1.05 or share <= 0.5:
                            continue
                        allr = np.concatenate([a_, b_])
                        good = sorted([c for c, v in per_coin.items() if v > 0])
                        res.append({"tf": tf, "side": side, "trigger": tname, "filters": list(fs), "sl": sl_m, "tp": tp_m,
                                    "hold": h_, "cost": cost, "trades": int(n_tr), "per_month": round(pm, 1),
                                    "pf_hold": round(_pf(np.concatenate(HH)), 2) if HH and len(np.concatenate(HH)) else 0.0, "n_hold": int(sum(len(x) for x in HH)), "hold_coins_share": round(hok / hn, 2) if hn else 0.0,
                                    "coins_ok": ok_c, "coins_n": act_c, "coins": good,
                                    "pf": round(_pf(allr), 2), "pf1": round(pa, 2), "pf2": round(pb, 2),
                                    "ret": round(float(allr.sum() * 100 / act_c), 1),
                                    "win": round(float((allr > 0).mean() * 100), 1),
                                    "score": round(min(pa, pb) * share * math.log(n_tr), 3)})
    res.sort(key=lambda x: -x["score"])
    seen, out = {}, []
    for r in res:
        key = (r["tf"], r["side"], r["trigger"])
        if seen.get(key, 0) >= 3:
            continue
        seen[key] = seen.get(key, 0) + 1
        out.append(r)
        if len(out) >= top:
            break
    return out


def run_spec(d: pd.DataFrame, spec: dict, eng=None, names=(), with_open=False):
    """Одна собранная стратегия -> сделки (для полного теста, графика и paper-бота)."""
    trig, filt, atr = features(d)
    et, ef = engine_features(eng, list(names))
    trig.update(et); filt.update(ef)
    if spec["trigger"] not in trig or any(f not in filt for f in spec.get("filters", [])):
        raise RuntimeError("индикатор из сборки недоступен (нет Node.js для 34 индикаторов терминала?)")
    s_ = 0 if spec["side"] > 0 else 1
    m = trig[spec["trigger"]][s_].copy()
    for f in spec.get("filters", []):
        m &= filt[f][s_]
    cost = float(spec.get("cost") or COST); hold = int(spec.get("hold") or plan(spec.get("tf", "1h"))[1])
    ex_i, ret, why = outcomes(d, atr, m, spec["side"], spec["sl"], spec["tp"], hold, cost)
    tr = pick_trades(np.flatnonzero(m), ex_i)
    c = d.close.to_numpy(); t = d.t.to_numpy(); n = len(c)
    names = {1: "стоп", 2: "тейк", 3: "время", 4: "трейлинг"}
    # сделка, у которой ещё не вышло время и не задет стоп/тейк, — ОТКРЫТА (раньше она
    # «закрывалась» на последней свече, и paper-бот писал её дважды)
    unfinished = [i for i in tr if int(why[i]) == 3 and i + hold > n - 1]
    closed = [i for i in tr if i not in unfinished]
    rows = [{"side": spec["side"], "t_in": int(t[i]), "t_out": int(t[ex_i[i]]), "px_in": float(c[i]),
             "px_out": float(c[i] * (1 + spec["side"] * (ret[i] + cost))), "pct": float(ret[i] * 100),
             "why": names.get(int(why[i]), "")} for i in closed]
    if not with_open:
        return rows
    op = None
    if unfinished:
        i = unfinished[-1]; e = float(c[i]); a = float(atr[i]); sd = spec["side"]
        step = int(t[1] - t[0]) if n > 1 else 3_600_000
        op = {"side": sd, "t_in": int(t[i]), "entry": e, "sl": e - sd * spec["sl"] * a, "tp": (e + sd * spec["tp"] * a) if spec["tp"] > 0 else None,
              "deadline": int(t[i]) + (hold + 1) * step, "bar_ms": step}
    return rows, op
