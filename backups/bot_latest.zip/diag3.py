"""Диагностика туннеля: версия cloudflared, свой тестовый туннель (http2 и quic) с полным выводом, проверка снаружи."""
import os, re, subprocess, threading, time, requests, shutil, sys
from pathlib import Path
B = Path(__file__).resolve().parent
sys.path.insert(0, str(B))
try:
    from app.config import Settings  # noqa
    st = Settings.load(); cf = st.cloudflared_path
except Exception as e:
    print("settings err", e); cf = os.getenv("CLOUDFLARED_PATH") or "cloudflared"
print("CF PATH", cf, "exists:", Path(cf).exists() if os.sep in cf or "/" in cf else shutil.which(cf))
try:
    print("VERSION", subprocess.run([cf, "--version"], capture_output=True, text=True, timeout=15).stdout.strip())
except Exception as e:
    print("VERSION ERR", e)
for proto in ("http2",):
    p = subprocess.Popen([cf, "tunnel", "--protocol", proto, "--no-autoupdate", "--url", "http://127.0.0.1:8766"],
                         stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace")
    lines = []; url = None
    def rd():
        for ln in p.stdout:
            lines.append(ln.rstrip())
    threading.Thread(target=rd, daemon=True).start()
    t0 = time.time()
    while time.time() - t0 < 25:
        for ln in lines:
            m = re.search(r"https://[a-z0-9-]+\.trycloudflare\.com", ln)
            if m: url = m.group(0)
        if url and any("Registered tunnel connection" in l for l in lines): break
        time.sleep(1)
    time.sleep(3)
    print("PROTO", proto, "URL", url)
    for l in lines[-25:]:
        print("  |", l[-170:])
    if url:
        try:
            r = requests.options(url + "/api/settings", timeout=20); print("  OUTSIDE OPTIONS", r.status_code)
        except Exception as e:
            print("  OUTSIDE ERR", e)
    p.kill()
