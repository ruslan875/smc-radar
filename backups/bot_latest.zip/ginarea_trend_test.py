"""ginarea_trend_test.py — 2026-11-02. Сетка GinArea «Sui long 5min» + ФИЛЬТР ТРЕНДА (EMA200 1h/4h) и шорт-бот.

Те же настройки сетки, что в ginarea_sui_test.py (30 орд. × шаг, цель 0.25% на ордер, трейлинг 0.01/0.1%, тейк бота 8 $).
Лонг: старт цикла, только если RSI5m<35, ATR%1m>0.14 И цена выше EMA200 (закрытая свеча 1h/4h).
Шорт (зеркально): RSI5m>65, ATR%1m>0.14 И цена ниже EMA200; доборы выше, выход при падении на цель.
Каждый вариант — без стопа и со стоп-лоссом бота −5 $; шаг 0.05% и 0.2%. Свечи из кеша market_cache/okx_<COIN>_1m.pkl.
Запуск: ginarea_trend_test.bat [дней=180] [монета=SUI] → bt_lab_bots/ginarea_trend_test_<COIN>.txt
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import pandas as pd

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
from ginarea_sui_test import okx_1m  # noqa: E402
from ginarea_lot import fl, lot  # noqa: E402

LINES = []


def say(s=""):
    print(s, flush=True); LINES.append(s)


def gates(d, side, trend_tf):
    ix = pd.to_datetime(d.t, unit="ms")
    cs = pd.Series(d.c.to_numpy(), index=ix)
    c5 = cs.resample("5min").last().dropna(); dl = c5.diff()
    up = dl.clip(lower=0).ewm(alpha=1 / 14, adjust=False).mean(); dn = (-dl.clip(upper=0)).ewm(alpha=1 / 14, adjust=False).mean()
    r = (100 - 100 / (1 + up / dn.replace(0, 1e-12))).reindex(ix.dt.floor("5min") - pd.Timedelta("5min")).to_numpy()
    pc = d.c.shift(1)
    tr = pd.concat([d.h - d.l, (d.h - pc).abs(), (d.l - pc).abs()], axis=1).max(axis=1)
    atr_ok = ((tr.ewm(alpha=1 / 10, adjust=False).mean() / d.c * 100).shift(1) > 0.14).to_numpy()
    g = (r < 35) if side == "long" else (r > 65)
    g = g & atr_ok
    if trend_tf:
        ct = cs.resample(trend_tf).last().dropna()
        ema = ct.ewm(span=200, adjust=False).mean()
        k = ix.dt.floor(trend_tf) - pd.Timedelta(trend_tf)          # последняя ЗАКРЫТАЯ свеча
        above = (ct > ema).reindex(k).to_numpy()
        ok = above == True if side == "long" else above == False  # noqa: E712
        g = g & ok
    return g


def run(d, gate, side, P, fee=0.0005):
    t, o, h, l, c = (d[k].to_numpy() for k in ("t", "o", "h", "l", "c"))
    sg = 1 if side == "long" else -1
    lots, total, sess, tp = [], 0.0, 0.0, P["tp0"]
    R = {"cycles": 0, "deals": 0, "sl": 0, "worst": 0.0, "hang_h": 0.0, "fees": 0.0}
    monthly = {}; q_next = P["qty"]; t0 = None

    def book(x, ts):
        nonlocal total, sess
        total += x; sess += x
        m = pd.to_datetime(ts, unit="ms").strftime("%Y-%m"); monthly[m] = monthly.get(m, 0.0) + x

    def pnl(px, x):
        return sg * (px - x["px"]) * x["q"]

    for i in range(1, len(c)):
        if not lots:
            if not gate[i]:
                continue
            R["cycles"] += 1; t0 = t[i]; q_next = P["qty"]
            qa = fl(q_next, P); lots.append({"px": o[i], "q": qa, "stop": None}); R["fees"] += o[i] * qa * fee; book(-o[i] * qa * fee, t[i])
            q_next = min(q_next * P["mult"], P["qmax"])
        while len(lots) < P["n"]:
            edge = min(x["px"] for x in lots) if sg > 0 else max(x["px"] for x in lots)
            nxt = edge * (1 - sg * P["step"])
            if (sg > 0 and l[i] <= nxt) or (sg < 0 and h[i] >= nxt):
                qa = fl(q_next, P); lots.append({"px": nxt, "q": qa, "stop": None}); R["fees"] += nxt * qa * fee; book(-nxt * qa * fee, t[i])
                q_next = min(q_next * P["mult"], P["qmax"])
            else:
                break
        adv = l[i] if sg > 0 else h[i]
        un_w = sum(pnl(adv, x) for x in lots)
        R["worst"] = min(R["worst"], un_w)
        if P.get("sl") is not None and sess + un_w <= P["sl"]:
            for x in lots:
                R["fees"] += adv * x["q"] * fee; book(pnl(adv, x) - adv * x["q"] * fee, t[i])
            lots = []; R["sl"] += 1; sess, tp = 0.0, P["tp0"]
            R["hang_h"] = max(R["hang_h"], (t[i] - t0) / 3_600_000)
            continue
        keep = []
        for x in lots:
            trig = x["px"] * (1 + sg * P["target"])
            fav = h[i] if sg > 0 else l[i]
            if x["stop"] is None and sg * (fav - trig) >= 0:
                x["stop"] = trig * (1 - sg * P["min_stop"])
            if x["stop"] is not None:
                x["stop"] = max(x["stop"], fav * (1 - P["max_stop"])) if sg > 0 else min(x["stop"], fav * (1 + P["max_stop"]))
                if (sg > 0 and l[i] <= x["stop"]) or (sg < 0 and h[i] >= x["stop"]):
                    R["fees"] += x["stop"] * x["q"] * fee; book(pnl(x["stop"], x) - x["stop"] * x["q"] * fee, t[i]); R["deals"] += 1
                    continue
            keep.append(x)
        lots = keep
        if not lots and t0 is not None:
            R["hang_h"] = max(R["hang_h"], (t[i] - t0) / 3_600_000)
        un = sum(pnl(c[i], x) for x in lots)
        if sess + un >= tp:
            for x in lots:
                R["fees"] += c[i] * x["q"] * fee; book(pnl(c[i], x) - c[i] * x["q"] * fee, t[i])
            lots = []; sess = 0.0; tp += P["tp_inc"]
    if lots and t0 is not None:
        R["hang_h"] = max(R["hang_h"], (t[-1] - t0) / 3_600_000)
    R["open_un"] = sum(pnl(c[-1], x) for x in lots); R["open_lots"] = len(lots)
    R["total"] = total; R["all"] = total + R["open_un"]; R["monthly"] = monthly
    return R


def line(name, r):
    say(f"{name:<44} ИТОГО {r['all']:+7.2f} $ (закрыто {r['total']:+6.2f}, висит {r['open_lots']:2d} орд. {r['open_un']:+6.2f}) · "
        f"худшая {r['worst']:7.2f} · циклов {r['cycles']:3d} · стопов {r['sl']} · дольше всего {r['hang_h']:.0f} ч")


def main():
    days = int(sys.argv[1]) if len(sys.argv) > 1 else 180
    coin = (sys.argv[2] if len(sys.argv) > 2 else "SUI").upper()
    say(f"Сетка GinArea + фильтр тренда · OKX {coin} 1m · {days} дн. · комиссия 0.05% · {time.strftime('%Y-%m-%d %H:%M')}")
    d = okx_1m(coin, days)
    if len(d) < 10000:
        say("мало свечей"); return
    say(f"{pd.to_datetime(d.t.iloc[0], unit='ms'):%Y-%m-%d} → {pd.to_datetime(d.t.iloc[-1], unit='ms'):%Y-%m-%d} · "
        f"{coin} {d.c.iloc[0]:.4f} → {d.c.iloc[-1]:.4f} ({(d.c.iloc[-1] / d.c.iloc[0] - 1) * 100:+.0f}%)")
    base = dict(n=30, step=0.0005, qty=1.0, mult=1.01, qmax=2.0, target=0.0025, min_stop=0.0001, max_stop=0.001,
                tp0=8.0, tp_inc=0.2, sl=None, lot=lot(coin))
    G = {}
    for side in ("long", "short"):
        for tf in (None, "1h", "4h"):
            G[(side, tf)] = gates(d, side, tf)
    best = []
    for step in (0.0005, 0.002):
        for sl in (None, -5.0):
            P = {**base, "step": step, "sl": sl}
            say(""); say(f"===== шаг {step * 100:.2f}% · {'без стопа' if sl is None else 'стоп-лосс бота −5 $'} =====")
            res = {}
            for side in ("long", "short"):
                for tf in (None, "1h", "4h"):
                    nm = f"{'ЛОНГ' if side == 'long' else 'ШОРТ'} · {'без фильтра' if not tf else 'по тренду EMA200 ' + tf}"
                    if side == "short" and not tf:
                        nm = "ШОРТ · без фильтра (RSI>65)"
                    r = run(d, G[(side, tf)], side, P); res[(side, tf)] = r; line(nm, r)
                    best.append((r["all"], f"шаг {step * 100:.2f}% {'без стопа' if sl is None else 'SL −5'} · {nm}", r))
            for tf in ("1h", "4h"):
                a, b = res[("long", tf)], res[("short", tf)]
                say(f"{'ОБА бота по тренду EMA200 ' + tf:<44} ИТОГО {a['all'] + b['all']:+7.2f} $ (лонг {a['all']:+.2f} + шорт {b['all']:+.2f})")
    best.sort(key=lambda x: -x[0])
    say(""); say("===== ЛУЧШИЕ 5 =====")
    for v, nm, r in best[:5]:
        say(f"{v:+7.2f} $ · {nm} · худшая {r['worst']:.2f} · по месяцам: " + "  ".join(f"{m[5:]} {x:+.1f}" for m, x in sorted(r["monthly"].items())))
    say(""); say("Приближение алгоритма GinArea. Плюс одного периода — не доказательство: проверять на другой монете/годе.")
    out = BASE / "bt_lab_bots" / f"ginarea_trend_test_{coin}.txt"
    out.parent.mkdir(exist_ok=True); out.write_text("\n".join(LINES), encoding="utf-8")
    print(f"\nОтчёт: {out}")


if __name__ == "__main__":
    main()
