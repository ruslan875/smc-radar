@echo off
setlocal enabledelayedexpansion

REM VANTORIX Strategy Testing Batch Script
REM Запуск: Test_Strategies.bat CE_ZLSMA XRPUSDT OKX

set STRATEGY=%1
set SYMBOL=%2
set EXCHANGE=%3

if "%STRATEGY%"=="" (
    set STRATEGY=CE_ZLSMA
)
if "%SYMBOL%"=="" (
    set SYMBOL=XRPUSDT
)
if "%EXCHANGE%"=="" (
    set EXCHANGE=OKX
)

echo.
echo ========================================
echo VANTORIX Strategy Tester
echo ========================================
echo Strategy: %STRATEGY%
echo Symbol: %SYMBOL% (%EXCHANGE%)
echo Timeframe: 1H (60 min)
echo.

REM 1. Создать папку для результатов
if not exist "D:\VANTORIX\bot\backtest_results" mkdir "D:\VANTORIX\bot\backtest_results"

REM 2. Запустить TradingView
echo [1/4] Запуск TradingView...
for /f "tokens=*" %%i in ('powershell -Command "(Get-AppxPackage -Name 'TradingView.Desktop').InstallLocation"') do set TV_PATH=%%i

if "%TV_PATH%"=="" (
    echo ERROR: TradingView не найден
    exit /b 1
)

start "" "%TV_PATH%\TradingView.exe" --remote-debugging-port=9222
timeout /t 5 /nobreak

REM 3. Загрузить стратегию через tv CLI
echo [2/4] Установка символа %SYMBOL%...
call tv symbol %EXCHANGE%:%SYMBOL%
timeout /t 2 /nobreak

echo [3/4] Загрузка стратегии %STRATEGY%...
call tv timeframe 60
timeout /t 2 /nobreak

REM 4. Сделать скриншот
echo [4/4] Сбор результатов...
set TIMESTAMP=%date:~-4,4%-%date:~-10,2%-%date:~-7,2%_%time:~0,2%-%time:~3,2%
set SCREENSHOT=D:\VANTORIX\bot\backtest_results\%TIMESTAMP%_%STRATEGY%_%SYMBOL%.png

call tv screenshot --output=%SCREENSHOT%

if exist "%SCREENSHOT%" (
    echo.
    echo ✅ Screenshot saved: %SCREENSHOT%
) else (
    echo ⚠️ Screenshot не сохранён - проверьте tv CLI
)

echo.
echo ========================================
echo ✅ Test completed
echo ========================================
echo.
endlocal
