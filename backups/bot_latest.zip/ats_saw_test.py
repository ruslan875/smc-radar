"""ats_saw_test.py — 2026-10-17. «Пила» таймфреймов 1h…12h (шаг 1 ч) для ATS-Multi v7 и v9 на свечах OKX.

Часовая история OKX SWAP (~3 года, 12 монет) собирается в свечи k часов (pack_strats_test.resample, корзины от 00:00 UTC).
На каждом ТФ: ATS-Multi v7 (3 голоса, стоп 2.5%) и v9 (голоса 60%, трейл) из chat_scripts_okx_test,
для сравнения — ETH RSI (okx_cand_paper.eth_rsi_run, комиссия 0.05% на сторону).
В клетке: средний % на монету · ✅ = в плюсе, ≥ 8/12 монет в плюсе и обе половины истории > 0.
Устойчивая стратегия — ✅ подряд на соседних ТФ; одиночный ✅ среди минусов — случайность. Ничего не торгует.
Запуск: ats_saw_test.bat → bt_lab_bots/ats_saw_test.txt
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))

import chat_scripts_okx_test as CS  # noqa: E402  (импортирует okx_current_test: свечи OKX и комиссии OKX)
import pack_strats_test as PS  # noqa: E402

OUT = BASE / "bt_lab_bots" / "ats_saw_test.txt"
COINS = CS.COINS
HOURS = 3 * 365 * 24
LINES = []


def say(s=""):
    print(s, flush=True)
    LINES.append(s)


def eth_rsi(d):
    import pandas as pd  # noqa: PLC0415
    from windows_app import okx_cand_paper as OCP  # noqa: PLC0415
    df = pd.DataFrame({"t": d["t"], "o": d["o"], "h": d["h"], "l": d["l"], "c": d["c"], "v": d["v"]},
                      index=pd.to_datetime(d["t"].astype(np.int64), unit="ms"))
    t = OCP.eth_rsi_run(df, CS.TK)
    return (float(t["r"].sum()) if len(t) else 0.0), len(t)


TESTS = {
    "ATS-Multi v7 (3 голоса, стоп 2.5%)": lambda d: CS.ats(d, False),
    "ATS-Multi v9 (голоса 60%, трейл)": lambda d: CS.ats(d, True),
    "ETH RSI (для сравнения)": eth_rsi,
}


def main():
    t0 = time.time()
    say(f"«Пила» ТФ 1h…12h · ATS-Multi на OKX · {time.strftime('%Y-%m-%d %H:%M')} · комиссия тейкер {CS.TK*100:.2f}%")
    say("В клетке: средний % на монету · ✅ = в плюсе, ≥8/12 монет и обе половины > 0")
    raw = {}
    for s in COINS:
        try:
            raw[s] = CS.okx_klines(s, "60", HOURS)
        except Exception as exc:  # noqa: BLE001
            say(f"  {s}: ошибка загрузки {exc}"[:120])
    raw = {s: d for s, d in raw.items() if len(d["c"]) >= 3000}
    if not raw:
        say("Нет данных"); return
    days = np.median([(d["t"][-1] - d["t"][0]) / 86400000 for d in raw.values()])
    say(f"Монет {len(raw)} · часовой истории ~{days:.0f} дней")
    KS = list(range(1, 13))
    res = {n: {} for n in TESTS}
    for k in KS:
        data = {s: PS.resample(d, k) for s, d in raw.items()}
        data = {s: d for s, d in data.items() if len(d["c"]) >= 300}
        for name, fn in TESTS.items():
            full, h1, h2, nn = [], [], [], 0
            for s, d in data.items():
                CS.CTX["tick"] = CS.TICKS.get(s)
                try:
                    a = fn(d); full.append(a[0]); nn += a[1]
                    h1.append(fn(CS.half(d, 0))[0]); h2.append(fn(CS.half(d, 1))[0])
                except Exception as exc:  # noqa: BLE001
                    print(f"  {name} {s} {k}h: {exc}", flush=True)
            CS.CTX["tick"] = None
            if len(full) < 6:
                continue
            avg = np.mean(full) * 100; plus = sum(x > 0 for x in full)
            ok = avg > 0 and plus >= 8 and np.mean(h1) > 0 and np.mean(h2) > 0
            res[name][k] = (avg, plus, ok, nn)
        print(f"  {k}h готово ({time.time() - t0:.0f} с)", flush=True)
    say("")
    say(f"  {'стратегия':<34}" + "".join(f"{str(k) + 'h':>9}" for k in KS) + "   ✅ из 12")
    for name, row in res.items():
        cells = "".join(f"{row[k][0]:+7.0f}{'✅' if row[k][2] else ' '} " if k in row else f"{'—':>9}" for k in KS)
        say(f"  {name[:34]:<34}{cells}   {sum(1 for v in row.values() if v[2])}")
    say("")
    say("Монет в плюсе / сделок всего по ТФ:")
    for name, row in res.items():
        say(f"  {name[:34]:<34}" + "".join(f"{f'{row[k][1]}/{row[k][3]}':>9}" if k in row else f"{'—':>9}" for k in KS))
    say("")
    say("Как читать: устойчивая стратегия — ✅ подряд на нескольких соседних ТФ (например 3h–6h).")
    say("Один ✅ среди минусов вокруг = случайность. Подряд 3+ ✅ — кандидат на бумажного бота на центральном ТФ.")
    OUT.parent.mkdir(exist_ok=True)
    OUT.write_text("\n".join(LINES), encoding="utf-8")
    print(f"\nОтчёт: {OUT}  ({time.time() - t0:.0f} с)")


if __name__ == "__main__":
    main()
