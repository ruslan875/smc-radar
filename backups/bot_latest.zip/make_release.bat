@echo off
cd /d "%~dp0"
echo TRADEOS release build...
echo Folder: %cd%
if not exist "venv\Scripts\python.exe" (
  echo ERROR: venv\Scripts\python.exe not found
  pause
  exit /b 1
)
"venv\Scripts\python.exe" -u make_release.py
echo.
echo Exit code: %errorlevel%
pause
