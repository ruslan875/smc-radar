"""chan_saw_all_min.py — 2026-10-20. Пробой канала 100 (тейк 2R, стоп у центра) на минутных ТФ на ВСЕХ биржах:
Binance, Bitget, KuCoin, MEXC (+ Bybit и OKX из кеша прошлых тестов). ТФ 1m / 3m / 5m / 15m / 30m / 1h,
минутки за DAYS дней (по умолч. 120 — 300 дней на 6 биржах качались бы сутки), 12 монет.
Комиссия — тейкер каждой биржи (ориентир, базовый уровень; поправь FEES, если у тебя другая) + общая 0.05% для сравнения.
✅ = итог > 0, ≥ 2/3 монет в плюсе, обе половины > 0. Ничего не торгует.
Запуск: chan_saw_all_min.bat [дней] → bt_lab_bots/chan_saw_all_min.txt (кеш: market_cache/<биржа>_<SYM>_1m.pkl)
"""
from __future__ import annotations
import pickle, sys, time
from pathlib import Path
import numpy as np
import requests
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import chan_speed_test as CS  # noqa: E402
OUT = BASE / "bt_lab_bots" / "chan_saw_all_min.txt"
CDIR = BASE / "market_cache"
DAYS = int(sys.argv[1]) if len(sys.argv) > 1 else 120
COINS = ["BTC", "ETH", "SOL", "XRP", "DOGE", "ADA", "SUI", "LINK", "AVAX", "BNB", "NEAR", "HYPE"]
FEES = {"Binance": 0.0005, "Bitget": 0.0006, "KuCoin": 0.0006, "MEXC": 0.0002, "Bybit": 0.00055, "OKX": 0.0005}
MIN = 60_000
LINES = []
def say(s=""):
    print(s, flush=True); LINES.append(s)

def _get(url, params):
    for a in range(5):
        try:
            return requests.get(url, params=params, timeout=20).json()
        except (requests.RequestException, ValueError):
            time.sleep(2 * (a + 1))
    return None

# каждая функция: (coin, end_ms) -> список (t_ms, h, l, c) ЗАКРЫТЫХ минут, заканчивающихся до end_ms (вниз по времени)
def f_binance(coin, end):
    j = _get("https://fapi.binance.com/fapi/v1/klines", {"symbol": coin + "USDT", "interval": "1m", "limit": 1500, "endTime": end})
    return [(int(r[0]), float(r[2]), float(r[3]), float(r[4])) for r in (j or []) if isinstance(r, list)]

def f_bitget(coin, end):
    j = _get("https://api.bitget.com/api/v2/mix/market/history-candles",
             {"symbol": coin + "USDT", "productType": "usdt-futures", "granularity": "1m", "endTime": end, "limit": 200})
    return [(int(r[0]), float(r[2]), float(r[3]), float(r[4])) for r in ((j or {}).get("data") or [])]

def f_kucoin(coin, end):
    sym = ("XBT" if coin == "BTC" else coin) + "USDTM"
    j = _get("https://api-futures.kucoin.com/api/v1/kline/query", {"symbol": sym, "granularity": 1, "from": end - 500 * MIN, "to": end})
    return [(int(r[0]), float(r[2]), float(r[3]), float(r[4])) for r in ((j or {}).get("data") or [])]

def f_mexc(coin, end):
    j = _get(f"https://contract.mexc.com/api/v1/contract/kline/{coin}_USDT",
             {"interval": "Min1", "start": (end - 2000 * MIN) // 1000, "end": end // 1000})
    d = (j or {}).get("data") or {}
    return [(int(t) * 1000, float(h), float(l), float(c)) for t, h, l, c in zip(d.get("time", []), d.get("high", []), d.get("low", []), d.get("close", []))]

EXCH = {"Binance": f_binance, "Bitget": f_bitget, "KuCoin": f_kucoin, "MEXC": f_mexc}

def load(ex, coin, days):
    path = CDIR / f"{ex.lower()}_{coin}_1m.pkl"
    have = pickle.loads(path.read_bytes()) if path.exists() else {}
    now = int(time.time() * 1000) // MIN * MIN
    need_from = now - days * 86400_000
    def walk(end, stop):
        k = 0
        while end > stop:
            rows = EXCH[ex](coin, end)
            rows = [r for r in rows if r[0] < end]
            if not rows:
                break
            for t, h, l, c in rows:
                have[t] = (h, l, c)
            end = min(r[0] for r in rows); k += 1
            if k % 100 == 0:
                print(f"  {ex} {coin}: {time.strftime('%Y-%m-%d', time.gmtime(end / 1000))}", flush=True)
            time.sleep(0.1)
    walk(now, max(have) if have else need_from)
    if have and min(have) > need_from + MIN:
        walk(min(have), need_from)
    if have:
        CDIR.mkdir(exist_ok=True); path.write_bytes(pickle.dumps(have))
    ts = np.array(sorted(t for t in have if need_from <= t and t + MIN <= now), dtype=np.int64)
    if not len(ts):
        return None
    a = np.array([have[t] for t in ts])
    return {"t": ts, "h": a[:, 0], "l": a[:, 1], "c": a[:, 2]}

def load_cached(ex, coin, days):
    """Bybit / OKX — из кеша прошлых тестов (chan_saw_bybit_min / GinArea)."""
    now = int(time.time() * 1000); need_from = now - days * 86400_000
    if ex == "Bybit":
        p = CDIR / f"bybit_{coin}USDT_1m.pkl"
        if not p.exists():
            return None
        have = pickle.loads(p.read_bytes())
        ts = np.array(sorted(t for t in have if t >= need_from), dtype=np.int64)
        a = np.array([have[t] for t in ts])
        return {"t": ts, "h": a[:, 0], "l": a[:, 1], "c": a[:, 2]} if len(ts) else None
    p = CDIR / f"okx_{coin}_1m.pkl"
    if not p.exists():
        return None
    import pandas as pd  # noqa: PLC0415
    m = pd.read_pickle(p); m = m[m.t >= need_from]
    return {"t": m.t.to_numpy().astype(np.int64), "h": m.h.to_numpy(float), "l": m.l.to_numpy(float), "c": m.c.to_numpy(float)} if len(m) else None

def table(name, data, fee, months):
    CS.FEE = fee
    say(f"  {'ТФ':<5}{'итог R':>10}{'R/мес':>9}{'монет +':>9}{'1-я':>10}{'2-я':>10}{'сделок':>8}")
    for mm in (1, 3, 5, 15, 30, 60):
        tot = h1 = h2 = 0.0; plus = n = 0
        for d0 in data.values():
            d = CS.rs(d0, mm * MIN) if mm > 1 else d0
            tr = CS.chan_trades(d, 2.0, 1.0)
            if not tr:
                continue
            mid = d["t"][len(d["t"]) // 2]
            r = sum(x[1] for x in tr); tot += r; n += len(tr); plus += r > 0
            h1 += sum(x[1] for x in tr if x[0] < mid); h2 += sum(x[1] for x in tr if x[0] >= mid)
        ok = tot > 0 and plus * 3 >= 2 * len(data) and h1 > 0 and h2 > 0
        say(f"  {(f'{mm}m' if mm < 60 else '1h'):<5}{tot:>+10.1f}{tot / months:>+9.2f}{f'{plus}/{len(data)}':>9}{h1:>+10.1f}{h2:>+10.1f}{n:>8}  {'✅' if ok else '❌'}")

def main():
    say(f"Пробой канала 100 (2R, стоп центр) · минутные ТФ · все биржи · {DAYS} дн. · {time.strftime('%Y-%m-%d %H:%M')}")
    for ex in ["Binance", "Bitget", "KuCoin", "MEXC", "Bybit", "OKX"]:
        data = {}
        for c in COINS:
            try:
                d = load(ex, c, DAYS) if ex in EXCH else load_cached(ex, c, DAYS)
            except Exception as exc:  # noqa: BLE001
                print(f"  {ex} {c}: {exc}", flush=True); d = None
            if d is not None and len(d["c"]) > 20000:
                data[c] = d
        say("")
        if len(data) < 4:
            say(f"=== {ex}: мало данных ({len(data)} монет) — пропуск" + (" (сначала запусти chan_saw_bybit_min.bat / GinArea-тесты)" if ex in ("Bybit", "OKX") else ""))
            continue
        months = np.median([(d["t"][-1] - d["t"][0]) / (30.4 * 864e5) for d in data.values()])
        say(f"=== {ex} · {len(data)} монет ({', '.join(data)}) · ~{months * 30.4:.0f} дн. ===")
        say(f" комиссия биржи {FEES[ex] * 100:.3f}% на сторону:"); table(ex, data, FEES[ex], months)
        if FEES[ex] != 0.0005:
            say(" для сравнения 0.05%:"); table(ex, data, 0.0005, months)
    say(""); say("Комиссии — базовый тейкер (ориентир на 2026; у тебя может быть другая — поправь FEES в начале файла).")
    OUT.parent.mkdir(exist_ok=True); OUT.write_text("\n".join(LINES), encoding="utf-8"); print(f"\nОтчёт: {OUT}")

if __name__ == "__main__":
    main()
