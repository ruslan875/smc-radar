"""signal_quality_test.py — 2026-11-01. Какие сигналы пробоя/Donchian чаще дают стоп: проверка признаков на всей истории.
Признак считаем «слабым», только если средний R у него хуже среднего ВЕЗДЕ: в 1-й и 2-й половине истории и за 180 дней,
и при этом без него итог стратегии не падает. 12 монет, 2h/4h, комиссия 0.08% (Hash Hedge). Пишет bt_lab_bots/signal_quality.txt"""
from __future__ import annotations

import sys
import time
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import recheck_recent as RR  # noqa: E402
import challenge_sim as CS  # noqa: E402

DAY = CS.DAY


def feats(d):
    c = d.c.values; h = d.h.values; l = d.l.values
    pc = np.r_[c[0], c[:-1]]
    tr = pd.Series(np.maximum(h - l, np.maximum(abs(h - pc), abs(l - pc))))
    a14 = tr.ewm(alpha=1 / 14, adjust=False).mean().values; a100 = tr.rolling(100).mean().values
    ema200 = pd.Series(c).ewm(span=200, adjust=False).mean().values
    ema50 = pd.Series(c).ewm(span=50, adjust=False).mean().values
    dc = np.diff(c, prepend=c[0]); up = pd.Series(np.clip(dc, 0, None)).ewm(alpha=1 / 14, adjust=False).mean()
    dn = pd.Series(np.clip(-dc, 0, None)).ewm(alpha=1 / 14, adjust=False).mean(); rsi = (100 - 100 / (1 + up / dn.replace(0, 1e-12))).values
    ext = (c - ema50) / np.where(a14 > 0, a14, np.nan)          # насколько цена ушла от EMA50 в ATR
    return {int(t): (a14[i] / a100[i] if a100[i] > 0 else np.nan, 1 if c[i] > ema200[i] else -1, rsi[i], ext[i])
            for i, t in enumerate(d.t.values)}


def main():
    import kvoo_longtest as K  # noqa: PLC0415
    CS.FEE = 0.0008
    now = int(time.time() * 1000); lines = []
    btc = {tf: feats(RR.load("BTCUSDT", tf).reset_index(drop=True)) for tf in ("2h", "4h")}
    for name, tf in (("chan2h", "2h"), ("chan4h", "4h"), ("donch", "4h")):
        rows = []
        for s in K.COINS:
            d = RR.load(s, tf)
            if d is None or len(d) < 400:
                continue
            d = d.reset_index(drop=True); F = feats(d)
            for x in CS.trades("chan2h" if name.startswith("chan") else name, d, s):
                f = F.get(x["t_in"]); b = btc[tf].get(x["t_in"])
                if f is None or b is None:
                    continue
                rows.append({"t": x["t_in"], "t_out": x["t_out"], "s": x["s"], "R": x["R"], "stop": x["stop_pct"] * 100,
                             "volx": f[0], "own_trend": f[1] == x["s"], "btc_trend": b[1] == x["s"], "rsi": f[2], "ext": f[3] * x["s"]})
        df = pd.DataFrame(rows).sort_values("t").reset_index(drop=True)
        # сколько стопов в ту же сторону закрылось за 24 ч до входа (по всем монетам)
        stops = df[df.R < 0][["t_out", "s"]].values
        df["recent_stops"] = [int(((stops[:, 1] == s) & (stops[:, 0] <= t) & (stops[:, 0] > t - DAY)).sum()) for t, s in zip(df.t, df.s)]
        t0 = df.t.min(); mid = (t0 + now) // 2; base = df.R.mean()
        lines.append(f"\n=== {name} · {len(df)} сделок · в среднем {base:+.3f}R ===")
        tests = {
            "стоп уже 2%": df.stop < 2, "стоп шире 6%": df.stop > 6,
            "против своего тренда EMA200": ~df.own_trend, "против тренда BTC": ~df.btc_trend,
            "волатильность падает (ATR14<ATR100)": df.volx < 1, "RSI перегрет (>75 лонг / <25 шорт)": ((df.s > 0) & (df.rsi > 75)) | ((df.s < 0) & (df.rsi < 25)),
            "цена далеко от EMA50 (>4 ATR)": df.ext > 4, "≥2 стопа в ту же сторону за 24 ч": df.recent_stops >= 2,
            "≥4 стопа в ту же сторону за 24 ч": df.recent_stops >= 4,
        }
        for nm, m in tests.items():
            g = df[m]; o = df[~m]
            if len(g) < 50:
                continue
            a = lambda q: q.R.mean() if len(q) else np.nan  # noqa: E731
            h1, h2, r180 = a(g[g.t < mid]), a(g[g.t >= mid]), a(g[g.t >= now - 180 * DAY])
            b1, b2, b180 = a(o[o.t < mid]), a(o[o.t >= mid]), a(o[o.t >= now - 180 * DAY])
            weak = h1 < b1 and h2 < b2 and (np.isnan(r180) or r180 < b180) and a(g) < 0.5 * base
            gain = -g.R.sum()          # на сколько R вырастет итог, если такие сигналы пропускать
            line = (f"{'⚠ СЛАБЫЙ' if weak else '   норм  '} {nm:<40} {len(g):>5} сд ({len(g) / len(df) * 100:3.0f}%) · "
                    f"{a(g):+.3f}R против {a(o):+.3f} · половины {h1:+.2f}/{h2:+.2f} (без них {b1:+.2f}/{b2:+.2f}) · 180д {r180:+.2f} · "
                    f"пропуск даст {gain:+.0f}R")
            print(line, flush=True); lines.append(line)
    (BASE / "bt_lab_bots" / "signal_quality.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("готово")


if __name__ == "__main__":
    main()
