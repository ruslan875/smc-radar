#!/usr/bin/env python3
"""
Liquidity Thermal Map MOD - Standalone Backtest Runner
======================================================

Hand-ported from strategies/Liq_Therm_Map_Strategy.pine (Pine v6).

WHY THIS IS HAND-PORTED, NOT RUN THROUGH pine\\run_pine.py:
The project's pine_transpiler.py cannot handle this script at all: it is built
almost entirely on `var`-persisted cross-bar state (last pivot high/low and
their bar indices, the `trend` flip flag, the pending-retest latch) plus
nested per-bar loops that rebuild a 31-bucket volume profile over the last
`period` bars. None of that survives a vector-style translation - the signal
sequence itself depends on the order in which the state mutates inside a bar.
So this is a direct, bar-by-bar re-implementation of the Pine logic.

!!! FILL-TIMING WARNING - READ BEFORE TRUSTING ANY NUMBER FROM THIS FILE !!!
The Pine source sets `process_orders_on_close = true` and
`calc_on_order_fills = true`, which means every entry is filled at the CLOSE
of the very bar that produced the signal. This port reproduces that exactly,
because the goal is parity with the Pine report. In LIVE trading you cannot do
this: the signal is only known once the bar has closed, so the real fill is at
the OPEN of the NEXT bar. Expect live results to be MEANINGFULLY WORSE than
this backtest, especially in "Aggressive" entry mode where the signal bar is
the breakout bar itself (its close is already extended in the signal
direction). Treat this backtest as an upper bound, not a forecast.

USAGE (same conventions as gaussian_channel_backtest.py):

    pip install pandas numpy ccxt

    python liq_therm_map_backtest.py --symbol BTC/USDT --timeframe 1h \\
        --start 2023-01-01 --end 2025-12-31 --out backtest_out_liqtherm

    python liq_therm_map_backtest.py --symbols BTC/USDT ETH/USDT SOL/USDT \\
        --timeframe 1h --start 2023-01-01 --end 2025-12-31 --out backtest_out_liqtherm

    python liq_therm_map_backtest.py --csv data/BTCUSDT_1h.csv \\
        --entry-mode Aggressive --tp-mode "Liquidity TP B"

Output: <out>/<SYMBOL>_deals.csv - same schema as gaussian_channel_backtest.py
        and third_eye_backtest.py
        (entry_time, exit_time, side, entry_price, exit_price, gross_pnl_pct, reason)
        so analyze_external_strategies.py works unchanged on either output folder.

WHAT THE STRATEGY DOES (summary of the Pine, verified line by line):
  1. Market structure: ta.pivothigh(10,10) / ta.pivotlow(10,10) keep the last
     confirmed pivot high `ph` and pivot low `pl` plus their bar indices.
  2. A bullish break is ta.crossover(high, ph) while trend == false; a bearish
     break is ta.crossunder(low, pl) while trend == true. The break flips
     `trend`, so breaks - and therefore signals - STRICTLY ALTERNATE:
     a long break is always followed by a short break, never two in a row.
  3. The "zone level" of a bullish break is the LOWEST low from the pivot-high
     bar through the break bar; for a bearish break it is the HIGHEST high from
     the pivot-low bar through the break bar.
  4. Entry mode "Aggressive" enters on the break bar itself. Entry mode
     "Confirmed" (the Pine default) arms a pending retest and enters on the
     first later bar, within 20 bars, that wicks back to the zone level and
     closes back on the right side of it.
  5. Exit: a single strategy.exit with both a stop and a limit, computed once at
     entry. Stop mode "Zone" (default) puts the stop just past the zone extreme
     with a 0.10% buffer, capped at 3% risk; over the cap it falls back to a
     flat 1% (or skips the trade, configurable). Stop mode "Percent" is a flat
     1%. TP mode "RR" (default) is 2.0x the stop distance; "Percent" is 2%; the
     three "Liquidity TP" modes snap the target to the 31-bucket volume profile.
  6. Volume profile: the last `period` bars (300 by default) are bucketed into
     31 price bins between the running highest high and lowest low; each bar's
     volume is added to every bin whose midpoint is within one `step` of that
     bar's close.

PARITY NOTES (what's faithful vs. what's a documented simplification):
  FAITHFUL, LINE FOR LINE:
  - `trend`, `ph`/`pl`, `ph_index`/`pl_index` and the pending-retest latch are
    carried as real mutable state through a single forward pass over the bars,
    mutated in exactly the Pine order (pivot update -> break test -> zone level
    -> trend flip -> pending latch -> expiry -> confirmed test -> entry).
  - ta.crossover(high, ph) is reproduced as `high > ph and high[1] <= ph[1]`
    using the PREVIOUS BAR's value of the `var` series ph, not the current one.
    Same for ta.crossunder(low, pl). When ph[1] is na the crossover is false,
    matching Pine's na-comparison semantics.
  - The zone-level scan reproduces the Pine loop bounds exactly, including
    `math.max(0, math.min(bar_index - ph_index, 1499))`.
  - The retest window is `bar_index > pendingBar` and expiry is
    `bar_index - pendingBar > maxRetestBars`, checked BEFORE the confirmed test
    on the same bar - so the usable retest bars are pendingBar+1 .. pendingBar+20.
  - f_finalize_stop / f_finalize_tp / f_find_liquidity_target are transcribed
    one-to-one, including the tie-breaking and loop directions: TP A keeps the
    FIRST bucket that strictly beats the running best (`v > bestVol`), TP B
    scans ascending for longs and descending from bin 30 for shorts, TP C scans
    bins 1..29 ascending for longs and 29..1 descending for shorts with
    localPeak = `v > v[i-1] and v >= v[i+1]`.
  - The liquidity offset is applied on the correct side
    (`long: target * (1 - off/100)`, `short: target * (1 + off/100)`), and the
    fallback to RR/Percent fires whenever the resulting target lands on the
    wrong side of entry - same as the Pine `validSide` check.
  - The volume profile keeps Pine's OVERLAPPING buckets. The Pine condition is
    `math.abs(close[k] - mid) < step` - note `step`, NOT `step / 2` - so each
    close is counted into roughly TWO adjacent bins. This looks like a bug in
    the original but it is reproduced as written, because it changes which bin
    is the "fattest" and therefore changes the Liquidity TP targets.
  - Entry validity gates are reproduced: a signal that produces an invalid stop
    (na, wrong side, or over the cap with fallback "Skip Trade") or an invalid
    TP produces NO trade, and - importantly - does NOT close an existing
    opposite position either, because in Pine the strategy.close() sits inside
    the same validity block as the strategy.entry().

  SIMPLIFIED / DELIBERATELY DIFFERENT:
  - Everything cosmetic is dropped: the heatmap plots and fills, the zone
    boxes/polylines/labels, the SL/TP history lines, the delta-volume labels,
    the zonesLimit/tradeLinesLimit housekeeping. None of it feeds a trade
    decision - the zone objects in `ms_levels` are only drawn and deleted, the
    trade levels come from `pendingLongLevel`/`bullZoneLevel`, not from the
    line objects. `gradient()`, `sensitivityMode` and the colour inputs are
    likewise purely visual and are not ported.
  - The volume profile is computed with numpy over a rolling window instead of
    a 31 x 300 nested Pine loop per bar. The bucket membership test is still
    evaluated literally (`abs(close - mid) < step`) per candidate bin, so the
    result is identical; only the enumeration is smarter (a close can satisfy
    the test for at most 2 bins, so only 2 candidates per bar are tested
    instead of 31). The profile is also built LAZILY - only when a Liquidity TP
    mode is selected, since nothing else in the strategy reads it.
  - H/L use partial windows on the first `period-1` bars (pandas min_periods=1).
    Pine's ta.highest(period) returns na there, which would make `step` na and
    leave every bucket at 0; that only matters for Liquidity TP modes on the
    first 300 bars of history. Documented, not considered worth reproducing.
  - ta.pivothigh/ta.pivotlow are implemented as STRICTLY greater/less than every
    bar in both the left and the right window. Pine's exact tie-handling is not
    published; on real float price data exact ties are vanishingly rare, but on
    synthetic or heavily rounded data this can shift a pivot by a bar.
  - Exit orders are evaluated from the bar AFTER the entry bar. In Pine the
    strategy.exit is placed on the entry bar, but with
    process_orders_on_close = true the entry itself only fills at that bar's
    close, so there is no remaining price action on the entry bar for the stop
    or limit to trade against.
  - INTRABAR AMBIGUITY: if a single bar touches BOTH the stop and the target,
    this port always takes the STOP. That is the conservative choice and it is
    also what TradingView does by default when it cannot resolve the intrabar
    sequence. It means the equity curve here is a pessimistic bound on those
    specific bars.
  - The Pine source specifies NEITHER commission NOR slippage, i.e. both are
    zero, which flatters the result. This port defaults --commission to 0.055
    (Bybit taker, per side; charged as a round trip in gross_pnl_pct) and
    exposes --slippage-pct. Set both to 0 to reproduce the raw Pine report.
  - Slippage is applied to the FILL price only. The stop and target are still
    derived from the raw bar close, exactly as Pine's `entryPrice = close`
    does, so that the SET of trades the strategy takes does not change when you
    change the slippage assumption - only the P&L of those trades does.
  - A position still open on the last bar is simply dropped, not marked to
    market - same as gaussian_channel_backtest.py.
"""

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd

CONFIG = {
    # Liquidity Thermal Map
    "profile_type": "Balanced Profile",  # Shallow Profile | Balanced Profile | Deep Profile
    "period": 300,                       # derived from profile_type: 100 / 300 / 600
    "bins": 31,
    # Structure
    "pivot_len": 10,
    "max_retest_bars": 20,
    # Entry
    "entry_mode": "Confirmed",           # Aggressive | Confirmed
    # Stop Loss
    "sl_mode": "Zone",                   # Percent | Zone
    "sl_pct": 1.0,
    "zone_buffer_pct": 0.10,
    "max_zone_stop_pct": 3.0,
    "zone_stop_fallback": "Percent",     # Percent | Skip Trade
    # Take Profit
    "tp_mode": "RR",                     # Percent | RR | Liquidity TP A | Liquidity TP B | Liquidity TP C
    "tp_pct": 2.0,
    "rr_mult": 2.0,
    "liq_threshold": 0.70,
    "liq_offset_pct": 0.10,
    "liquidity_tp_fallback": "RR",       # RR | Percent
}

PROFILE_PERIODS = {
    "Shallow Profile": 100,
    "Balanced Profile": 300,
    "Deep Profile": 600,
}

LIQ_TP_MODES = ("Liquidity TP A", "Liquidity TP B", "Liquidity TP C")


# ============================================================================
# STRUCTURE: ta.pivothigh(len, len) / ta.pivotlow(len, len)
# A pivot at bar p is CONFIRMED on bar p + len - that is when Pine returns a
# non-na value and when `ph_index := bar_index[len]` gets assigned.
# ============================================================================

def pivot_flags(high: np.ndarray, low: np.ndarray, length: int):
    """Returns (is_pivot_high, is_pivot_low) boolean arrays indexed by the
    PIVOT bar (not by the confirmation bar)."""
    sh, sl = pd.Series(high), pd.Series(low)

    # max/min of the `length` bars strictly to the LEFT of each bar
    left_max = sh.rolling(length).max().shift(1).to_numpy()
    left_min = sl.rolling(length).min().shift(1).to_numpy()
    # max/min of the `length` bars strictly to the RIGHT of each bar
    right_max = sh.rolling(length).max().shift(-length).to_numpy()
    right_min = sl.rolling(length).min().shift(-length).to_numpy()

    with np.errstate(invalid="ignore"):
        is_ph = (high > left_max) & (high > right_max)
        is_pl = (low < left_min) & (low < right_min)
    return np.nan_to_num(is_ph, nan=False).astype(bool), np.nan_to_num(is_pl, nan=False).astype(bool)


# ============================================================================
# LIQUIDITY MAP (volume profile)
#
# Pine, rebuilt on EVERY bar:
#     H = ta.highest(period); L = ta.lowest(period)
#     step = (H - L) / 31
#     for i = 0 to 30:
#         mid = L + step*i + step/2
#         for k = 0 to min(period-1, bar_index):
#             if math.abs(close[k] - mid) < step:      <-- `step`, not step/2
#                 volBins[i] += volume[k]
#
# The buckets therefore OVERLAP: each close falls inside the +/- step band of
# about two adjacent midpoints. Since |close - mid| < step maps to
# d - 1.5 < i < d + 0.5 with d = (close - L)/step - an open interval of width
# 2 - at most TWO bin indices can ever qualify. We enumerate those two
# candidates and re-test the literal Pine inequality on each, so the numbers
# match while the cost drops from 31*period to 2*period per bar.
# ============================================================================

def compute_volume_profile(df: pd.DataFrame, period: int, bins: int = 31):
    close = df["close"].to_numpy(dtype=float)
    vol = df["volume"].to_numpy(dtype=float)
    n = len(df)

    H = df["high"].rolling(period, min_periods=1).max().to_numpy()
    L = df["low"].rolling(period, min_periods=1).min().to_numpy()
    rng = H - L
    # Pine: step = rangeHL != 0 ? rangeHL / 31 : syminfo.mintick
    step = np.where(rng != 0, rng / bins, 1e-8)

    vol_bins = np.zeros((n, bins), dtype=float)

    for t in range(n):
        lo = max(0, t - period + 1)          # == math.min(period - 1, bar_index) lookback
        c = close[lo:t + 1]
        v = vol[lo:t + 1]
        st = step[t]
        base = L[t]

        d = (c - base) / st
        i0 = np.floor(d - 1.5) + 1           # smallest integer strictly above d - 1.5
        row = vol_bins[t]
        for off in (0.0, 1.0):
            idx = (i0 + off).astype(np.int64)
            in_range = (idx >= 0) & (idx < bins)
            if not in_range.any():
                continue
            idx_c = np.clip(idx, 0, bins - 1)
            mid = base + st * idx_c + st / 2
            ok = in_range & (np.abs(c - mid) < st)   # literal Pine test
            if ok.any():
                np.add.at(row, idx_c[ok], v[ok])

    return vol_bins, L, step


def _bin_mid(base: float, step: float, idx: int) -> float:
    """f_bin_mid(_idx) => levels.get(_idx) + step / 2, levels[i] = L + step*i"""
    return base + step * idx + step / 2


# ============================================================================
# STOP / TAKE PROFIT (f_finalize_stop / f_finalize_tp, transcribed)
# ============================================================================

def f_percent_stop(entry: float, is_long: bool, cfg: dict) -> float:
    p = cfg["sl_pct"] / 100
    return entry * (1 - p) if is_long else entry * (1 + p)


def f_percent_tp(entry: float, is_long: bool, cfg: dict) -> float:
    p = cfg["tp_pct"] / 100
    return entry * (1 + p) if is_long else entry * (1 - p)


def f_rr_tp(entry: float, is_long: bool, stop: float, cfg: dict) -> float:
    risk = abs(entry - stop)
    return entry + risk * cfg["rr_mult"] if is_long else entry - risk * cfg["rr_mult"]


def _is_na(x) -> bool:
    return x is None or (isinstance(x, float) and np.isnan(x))


def f_finalize_stop(entry: float, is_long: bool, zone_level, cfg: dict):
    """Returns (final_stop, ok) - mirrors the Pine tuple [finalStop, ok]."""
    if cfg["sl_mode"] == "Percent":
        return f_percent_stop(entry, is_long, cfg), True

    # slMode == "Zone"
    zone_stop = None
    if not _is_na(zone_level):
        buf = cfg["zone_buffer_pct"] / 100
        zone_stop = zone_level * (1 - buf) if is_long else zone_level * (1 + buf)

    valid_side = zone_stop is not None and (zone_stop < entry if is_long else zone_stop > entry)
    valid_dist = False
    if valid_side:
        dist_pct = abs(entry - zone_stop) / entry * 100
        valid_dist = dist_pct <= cfg["max_zone_stop_pct"]

    if valid_dist:
        return zone_stop, True
    if cfg["zone_stop_fallback"] == "Percent":
        return f_percent_stop(entry, is_long, cfg), True
    return None, False   # "Skip Trade"


def f_find_liquidity_target(entry: float, is_long: bool, mode: str,
                            bins_row: np.ndarray, base: float, step: float, cfg: dict):
    """Transcription of f_find_liquidity_target. Returns a price or None."""
    max_vol = float(bins_row.max()) if bins_row.size else 0.0
    if not (max_vol > 0):
        return None

    target = None
    n = bins_row.size  # 31

    if mode == "Liquidity TP A":
        # fattest bucket in the trade direction; ties keep the FIRST one
        best_vol = None
        for j in range(0, n):
            mid = _bin_mid(base, step, j)
            v = bins_row[j]
            in_direction = (mid > entry) if is_long else (mid < entry)
            if in_direction:
                if best_vol is None or v > best_vol:
                    best_vol = v
                    target = mid

    elif mode == "Liquidity TP B":
        threshold_vol = max_vol * cfg["liq_threshold"]
        if is_long:
            for j in range(0, n):
                mid = _bin_mid(base, step, j)
                if mid > entry and bins_row[j] >= threshold_vol:
                    target = mid
                    break
        else:
            for j in range(0, n):
                idx = (n - 1) - j
                mid = _bin_mid(base, step, idx)
                if mid < entry and bins_row[idx] >= threshold_vol:
                    target = mid
                    break

    elif mode == "Liquidity TP C":
        if is_long:
            for j in range(1, n - 1):        # Pine: for j = 1 to 29
                mid = _bin_mid(base, step, j)
                v, vl, vr = bins_row[j], bins_row[j - 1], bins_row[j + 1]
                local_peak = v > vl and v >= vr
                if mid > entry and local_peak:
                    target = mid
                    break
        else:
            for j in range(0, n - 2):        # Pine: for j = 0 to 28, idx = 29 - j
                idx = (n - 2) - j
                mid = _bin_mid(base, step, idx)
                v, vl, vr = bins_row[idx], bins_row[idx - 1], bins_row[idx + 1]
                local_peak = v > vl and v >= vr
                if mid < entry and local_peak:
                    target = mid
                    break

    return target


def f_finalize_tp(entry: float, is_long: bool, stop: float, cfg: dict,
                  bins_row=None, base=None, step=None):
    mode = cfg["tp_mode"]
    if mode == "Percent":
        return f_percent_tp(entry, is_long, cfg)
    if mode == "RR":
        return f_rr_tp(entry, is_long, stop, cfg)

    final_tp = None
    if bins_row is not None:
        liq_target = f_find_liquidity_target(entry, is_long, mode, bins_row, base, step, cfg)
        if liq_target is not None:
            off = cfg["liq_offset_pct"] / 100
            final_tp = liq_target * (1 - off) if is_long else liq_target * (1 + off)

    valid_side = final_tp is not None and (final_tp > entry if is_long else final_tp < entry)
    if not valid_side:
        final_tp = (f_rr_tp(entry, is_long, stop, cfg)
                    if cfg["liquidity_tp_fallback"] == "RR"
                    else f_percent_tp(entry, is_long, cfg))
    return final_tp


# ============================================================================
# BACKTEST ENGINE
#
# Single forward pass. Per-bar order of operations mirrors the Pine file:
#   1. pivot confirmation -> ph/pl + their indices
#   2. bullBreak / bearBreak (crossover against the PREVIOUS value of ph/pl)
#   3. zone level scan, trend flip
#   4. pending-retest latch, expiry, confirmed test
#   5. broker: stop / limit checked against THIS bar (never the entry bar)
#   6. entry at this bar's close (process_orders_on_close = true)
#
# Unlike gaussian_channel_backtest.py the stop and target are NOT global
# percentages: every trade carries its own levels, computed once at entry from
# the zone extreme / RR / liquidity profile and stored on the position dict.
# ============================================================================

def run_backtest(df: pd.DataFrame, cfg: dict = CONFIG,
                 commission_pct: float = 0.055, slippage_pct: float = 0.0) -> pd.DataFrame:
    commission = commission_pct / 100
    slip = slippage_pct / 100

    h = df["high"].to_numpy(dtype=float)
    l = df["low"].to_numpy(dtype=float)
    c = df["close"].to_numpy(dtype=float)
    times = df.index.to_numpy()
    n = len(df)

    plen = cfg["pivot_len"]
    is_ph, is_pl = pivot_flags(h, l, plen)

    need_profile = cfg["tp_mode"] in LIQ_TP_MODES
    if need_profile:
        vol_bins, prof_base, prof_step = compute_volume_profile(df, cfg["period"], cfg["bins"])
    else:
        vol_bins = prof_base = prof_step = None

    # ---------------- Pine `var` state ----------------
    ph = pl = np.nan
    ph_index = pl_index = None
    trend = False

    pending_long = False
    pending_short = False
    pending_long_level = np.nan
    pending_short_level = np.nan
    pending_long_bar = None
    pending_short_bar = None

    position = None
    deals = []

    def record_exit(pos, ts, exit_price, reason):
        entry = pos["entry_price"]
        if pos["side"] == "long":
            pnl = (exit_price / entry - 1) * 100 - commission * 200
        else:
            pnl = (entry / exit_price - 1) * 100 - commission * 200
        deals.append({
            "entry_time": pos["entry_time"],
            "exit_time": ts,
            "side": pos["side"],
            "entry_price": entry,
            "exit_price": exit_price,
            "gross_pnl_pct": pnl,
            "reason": reason,
        })

    for t in range(n):
        ts = times[t]

        # ---- 1. pivots: ph[1]/pl[1] must be captured BEFORE the update ----
        ph_prev, pl_prev = ph, pl
        if t - plen >= 0:
            if is_ph[t - plen]:
                ph_index = t - plen
                ph = h[t - plen]
            if is_pl[t - plen]:
                pl_index = t - plen
                pl = l[t - plen]

        # ---- 2. breaks: ta.crossover(high, ph) / ta.crossunder(low, pl) ----
        bull_break = False
        bear_break = False
        if t > 0:
            crossover = (not np.isnan(ph) and not np.isnan(ph_prev)
                         and h[t] > ph and h[t - 1] <= ph_prev)
            crossunder = (not np.isnan(pl) and not np.isnan(pl_prev)
                          and l[t] < pl and l[t - 1] >= pl_prev)
            bull_break = bool(crossover and ph_index is not None and not trend)
            bear_break = bool(crossunder and pl_index is not None and trend)

        # ---- 3. zone levels + trend flip ----
        # bullBreak and bearBreak are mutually exclusive by construction:
        # one needs trend == false, the other trend == true.
        bull_zone_level = np.nan
        bear_zone_level = np.nan

        if bull_break:
            span_up = max(0, min(t - ph_index, 1499))
            bull_zone_level = float(l[t - span_up:t + 1].min())
            trend = True

        if bear_break:
            span_dn = max(0, min(t - pl_index, 1499))
            bear_zone_level = float(h[t - span_dn:t + 1].max())
            trend = False

        # ---- 4. pending retest latch / expiry / confirmation ----
        if bull_break:
            pending_long = True
            pending_long_level = bull_zone_level
            pending_long_bar = t
            pending_short = False
            pending_short_level = np.nan
            pending_short_bar = None

        if bear_break:
            pending_short = True
            pending_short_level = bear_zone_level
            pending_short_bar = t
            pending_long = False
            pending_long_level = np.nan
            pending_long_bar = None

        if pending_long and pending_long_bar is not None and t - pending_long_bar > cfg["max_retest_bars"]:
            pending_long = False
            pending_long_level = np.nan
            pending_long_bar = None

        if pending_short and pending_short_bar is not None and t - pending_short_bar > cfg["max_retest_bars"]:
            pending_short = False
            pending_short_level = np.nan
            pending_short_bar = None

        long_confirmed = (pending_long and not np.isnan(pending_long_level)
                          and pending_long_bar is not None and t > pending_long_bar
                          and l[t] <= pending_long_level and c[t] > pending_long_level)
        short_confirmed = (pending_short and not np.isnan(pending_short_level)
                           and pending_short_bar is not None and t > pending_short_bar
                           and h[t] >= pending_short_level and c[t] < pending_short_level)

        aggressive = cfg["entry_mode"] == "Aggressive"
        long_signal = bull_break if aggressive else long_confirmed
        short_signal = bear_break if aggressive else short_confirmed
        long_zone = bull_zone_level if aggressive else pending_long_level
        short_zone = bear_zone_level if aggressive else pending_short_level

        # ---- 5. broker: stop / limit for an already-open position ----
        # Never on the entry bar itself: with process_orders_on_close = true the
        # entry fills AT that bar's close, so no price action is left on it.
        # INTRABAR AMBIGUITY: if the bar touches both levels we take the STOP
        # (conservative - we cannot know the intrabar order from OHLC alone).
        if position is not None and t > position["entry_bar"]:
            side = position["side"]
            exit_price = None
            reason = None
            if side == "long":
                if l[t] <= position["stop"]:
                    exit_price, reason = position["stop"], "stop_loss"
                elif h[t] >= position["target"]:
                    exit_price, reason = position["target"], "take_profit"
            else:
                if h[t] >= position["stop"]:
                    exit_price, reason = position["stop"], "stop_loss"
                elif l[t] <= position["target"]:
                    exit_price, reason = position["target"], "take_profit"
            if reason is not None:
                record_exit(position, ts, exit_price, reason)
                position = None

        # ---- 6. entries at this bar's close ----
        # Pine guards: `strategy.position_size <= 0` (long) / `>= 0` (short).
        bins_row = vol_bins[t] if need_profile else None
        base = prof_base[t] if need_profile else None
        stp = prof_step[t] if need_profile else None

        if long_signal and (position is None or position["side"] == "short"):
            entry_ref = c[t]           # Pine: float entryPrice = close
            stop, ok = f_finalize_stop(entry_ref, True, long_zone, cfg)
            if ok and stop is not None and stop < entry_ref:
                tp = f_finalize_tp(entry_ref, True, stop, cfg, bins_row, base, stp)
                if tp is not None and tp > entry_ref:
                    # the Pine strategy.close() lives INSIDE this validity block:
                    # an invalid stop/tp leaves an opposite position untouched.
                    if position is not None:
                        record_exit(position, ts, c[t], "opposite_signal")
                        position = None
                    position = {
                        "side": "long",
                        "entry_time": ts,
                        "entry_bar": t,
                        "entry_price": entry_ref * (1 + slip),
                        "stop": stop,
                        "target": tp,
                    }
                    pending_long = False
                    pending_long_level = np.nan
                    pending_long_bar = None

        if short_signal and (position is None or position["side"] == "long"):
            entry_ref = c[t]
            stop, ok = f_finalize_stop(entry_ref, False, short_zone, cfg)
            if ok and stop is not None and stop > entry_ref:
                tp = f_finalize_tp(entry_ref, False, stop, cfg, bins_row, base, stp)
                if tp is not None and tp < entry_ref:
                    if position is not None:
                        record_exit(position, ts, c[t], "opposite_signal")
                        position = None
                    position = {
                        "side": "short",
                        "entry_time": ts,
                        "entry_bar": t,
                        "entry_price": entry_ref * (1 - slip),
                        "stop": stop,
                        "target": tp,
                    }
                    pending_short = False
                    pending_short_level = np.nan
                    pending_short_bar = None

    cols = ["entry_time", "exit_time", "side", "entry_price",
            "exit_price", "gross_pnl_pct", "reason"]
    deals_df = pd.DataFrame(deals)
    if deals_df.empty:
        deals_df = pd.DataFrame(columns=cols)
    else:
        deals_df = deals_df[cols]
    return deals_df


# ============================================================================
# DATA LOADING (identical pattern to gaussian_channel_backtest.py)
# ============================================================================

def load_from_csv(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    df.columns = [c.lower() for c in df.columns]
    ts_col = "timestamp" if "timestamp" in df.columns else df.columns[0]
    df[ts_col] = pd.to_datetime(df[ts_col], errors="coerce")
    df = df.set_index(ts_col).sort_index()
    return df[["open", "high", "low", "close", "volume"]]


def load_from_ccxt(symbol: str, timeframe: str, start: str, end: str,
                   exchange_id: str = "bybit", market: str = "swap") -> pd.DataFrame:
    """Delegates to the shared loader in market_data.py - perpetuals by
    default, rate limited, retried, paged properly and cached to disk."""
    from market_data import load_ohlcv
    return load_ohlcv(symbol, timeframe, start, end,
                      exchange_id=exchange_id, market=market)

def print_summary(symbol: str, deals: pd.DataFrame):
    if deals.empty:
        print(f"  {symbol:12s}: 0 trades")
        return
    n = len(deals)
    wins = deals[deals["gross_pnl_pct"] > 0]
    losses = deals[deals["gross_pnl_pct"] <= 0]
    win_rate = len(wins) / n * 100
    avg_pnl = deals["gross_pnl_pct"].mean()
    gp, gl = wins["gross_pnl_pct"].sum(), abs(losses["gross_pnl_pct"].sum())
    pf = (gp / gl) if gl > 0 else float("inf")
    print(f"  {symbol:12s}: {n:4d} trades | avg P&L {avg_pnl:+6.2f}% | win rate {win_rate:5.1f}% | PF {pf:6.2f}")


def _manifest_symbols(args) -> list:
    syms = list(getattr(args, "symbols", None) or [])
    if not syms and getattr(args, "symbol", None):
        syms = [args.symbol]
    if not syms and getattr(args, "csv", None):
        syms = [Path(args.csv).stem]
    return syms


def main():
    p = argparse.ArgumentParser(description="Liquidity Thermal Map MOD standalone backtester")
    p.add_argument("--symbol")
    p.add_argument("--symbols", nargs="+")
    p.add_argument("--csv")
    p.add_argument("--exchange", default="okx")
    p.add_argument("--market", default="swap", choices=["swap", "spot"],
                   help="swap = USDT perpetual (what the bots trade)")
    p.add_argument("--timeframe", default="1h")
    p.add_argument("--start", default="2023-01-01")
    p.add_argument("--end", default="2025-12-31")
    p.add_argument("--out", default="backtest_out_liqtherm")
    p.add_argument("--commission", type=float, default=0.055,
                   help="Per-side commission %% (default 0.055 = Bybit taker; the Pine source has NONE)")
    p.add_argument("--slippage-pct", type=float, default=0.0,
                   help="Slippage %% applied to the fill price (the Pine source has NONE)")
    # --- strategy inputs -------------------------------------------------
    p.add_argument("--profile-depth", default="Balanced Profile",
                   choices=list(PROFILE_PERIODS), help="Pine 'Profile Depth'")
    p.add_argument("--period", type=int, default=None,
                   help="Override the profile lookback implied by --profile-depth")
    p.add_argument("--pivot-len", type=int, default=10)
    p.add_argument("--max-retest-bars", type=int, default=20)
    p.add_argument("--entry-mode", default="Confirmed", choices=["Aggressive", "Confirmed"])
    p.add_argument("--sl-mode", default="Zone", choices=["Percent", "Zone"])
    p.add_argument("--sl-pct", type=float, default=1.0)
    p.add_argument("--zone-buffer-pct", type=float, default=0.10)
    p.add_argument("--max-zone-stop-pct", type=float, default=3.0)
    p.add_argument("--zone-stop-fallback", default="Percent", choices=["Percent", "Skip Trade"])
    p.add_argument("--tp-mode", default="RR",
                   choices=["Percent", "RR", "Liquidity TP A", "Liquidity TP B", "Liquidity TP C"])
    p.add_argument("--tp-pct", type=float, default=2.0)
    p.add_argument("--rr-mult", type=float, default=2.0)
    p.add_argument("--liq-threshold", type=float, default=0.70)
    p.add_argument("--liq-offset-pct", type=float, default=0.10)
    p.add_argument("--liquidity-tp-fallback", default="RR", choices=["RR", "Percent"])
    args = p.parse_args()

    cfg = dict(CONFIG)
    cfg["profile_type"] = args.profile_depth
    cfg["period"] = args.period if args.period else PROFILE_PERIODS[args.profile_depth]
    cfg["pivot_len"] = args.pivot_len
    cfg["max_retest_bars"] = args.max_retest_bars
    cfg["entry_mode"] = args.entry_mode
    cfg["sl_mode"] = args.sl_mode
    cfg["sl_pct"] = args.sl_pct
    cfg["zone_buffer_pct"] = args.zone_buffer_pct
    cfg["max_zone_stop_pct"] = args.max_zone_stop_pct
    cfg["zone_stop_fallback"] = args.zone_stop_fallback
    cfg["tp_mode"] = args.tp_mode
    cfg["tp_pct"] = args.tp_pct
    cfg["rr_mult"] = args.rr_mult
    cfg["liq_threshold"] = args.liq_threshold
    cfg["liq_offset_pct"] = args.liq_offset_pct
    cfg["liquidity_tp_fallback"] = args.liquidity_tp_fallback

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    import json as _json, datetime as _dt
    _manifest = {
        "strategy": Path(__file__).stem,
        "run_at": _dt.datetime.now().astimezone().isoformat(timespec="seconds"),
        "symbols": _manifest_symbols(args),
        "timeframe": getattr(args, "timeframe", None),
        "start": getattr(args, "start", None),
        "end": getattr(args, "end", None),
        "exchange": getattr(args, "exchange", None),
        "market": getattr(args, "market", None),
        "commission_pct": getattr(args, "commission", None),
        "slippage_pct": getattr(args, "slippage_pct", None),
        "entry_mode": getattr(args, "entry_mode", None),
        "sl_mode": getattr(args, "sl_mode", None),
        "tp_mode": getattr(args, "tp_mode", None),
        "source": "csv" if getattr(args, "csv", None) else "exchange",
    }
    (out_dir / "_run.json").write_text(_json.dumps(_manifest, indent=2), encoding="utf-8")

    if args.csv:
        symbols = [Path(args.csv).stem]
        sources = {symbols[0]: load_from_csv(args.csv)}
    else:
        symbols = args.symbols or ([args.symbol] if args.symbol else None)
        if not symbols:
            p.error("Provide --symbol, --symbols, or --csv")
        sources = {}
        for sym in symbols:
            print(f"Fetching {sym} {args.timeframe} from {args.exchange} ({args.start} -> {args.end})...")
            sources[sym] = load_from_ccxt(sym, args.timeframe, args.start, args.end,
                                          args.exchange, args.market)

    print("\n" + "=" * 100)
    print("LIQUIDITY THERMAL MAP MOD - BACKTEST RESULTS")
    print(f"entry={cfg['entry_mode']} | SL={cfg['sl_mode']} | TP={cfg['tp_mode']} | "
          f"pivot={cfg['pivot_len']} | profile={cfg['period']} bars | "
          f"commission={args.commission}%/side | slippage={args.slippage_pct}%")
    print("NOTE: entries fill at the signal bar's CLOSE (Pine process_orders_on_close);")
    print("      live fills happen at the NEXT bar's open, so live will be worse.")
    print("=" * 100)

    min_bars = max(cfg["period"], 2 * cfg["pivot_len"]) + 10
    for sym, ohlcv in sources.items():
        if len(ohlcv) < min_bars:
            print(f"  {sym:12s}: insufficient data ({len(ohlcv)} bars)")
            continue
        deals = run_backtest(ohlcv, cfg, commission_pct=args.commission,
                             slippage_pct=args.slippage_pct)
        safe_name = sym.replace("/", "")
        deals.to_csv(out_dir / f"{safe_name}_deals.csv", index=False)
        print_summary(sym, deals)

    print("=" * 100)
    print(f"\nDeal logs written to: {out_dir}/  (compatible with analyze_external_strategies.py)")


if __name__ == "__main__":
    main()
