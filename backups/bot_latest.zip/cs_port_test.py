"""cs_port_test.py — 2026-11-01. Перенесённые 1-в-1 индикаторы [Crypto-Scalping] (cs_port.py) на истории: 12 монет, 1h/2h/4h
(+15m если есть кэш), вход по закрытию сигнального бара, стоп 1.5 ATR (для Forecasting ещё вариант «стоп за уровнем sup/res»),
тейк 1R/2R/3R, комиссия 0.06% за круг (тейкер Hash Hedge). Пишет bt_lab_bots/cs_port_test.txt"""
from __future__ import annotations
import sys, time
from pathlib import Path
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import recheck_recent as RR  # noqa: E402
import cs_port as P  # noqa: E402
FEE = 0.0006


def sim(d, ent, sl_of, tp_r, hold=200):
    c, h, l, t = d.c.values, d.h.values, d.l.values, d.t.values; n = len(c); out = []; i = 210
    while i < n - 1:
        s = ent[i]
        if not s:
            i += 1; continue
        e = c[i]; stp = sl_of(i, s)
        if stp is None or not np.isfinite(stp) or (stp - e) * s >= 0:
            i += 1; continue
        risk = abs(e - stp); tp = e + s * tp_r * risk; res = None
        for j in range(i + 1, min(n, i + hold)):
            if (l[j] <= stp) if s > 0 else (h[j] >= stp): res = (j, -1.0); break
            if (h[j] >= tp) if s > 0 else (l[j] <= tp): res = (j, float(tp_r)); break
        if res is None:
            j = min(n - 1, i + hold - 1); res = (j, s * (c[j] - e) / risk)
        out.append((int(t[i]), res[1] - FEE * e / risk, risk / e)); i = res[0] + 1
    return out


def main():
    import kvoo_longtest as K  # noqa: PLC0415
    now = int(time.time() * 1000); lines = []
    for tf in ("15m", "1h", "2h", "4h"):
        data = []
        for s in K.COINS:
            try:
                d = RR.load(s, tf)
            except Exception:  # noqa: BLE001
                d = None
            if d is None or len(d) < 600:
                continue
            d = d.reset_index(drop=True).iloc[-12000:].reset_index(drop=True)
            c, h, l = d.c.values, d.h.values, d.l.values
            pc = np.r_[c[0], c[:-1]]; atr = pd.Series(np.maximum(h - l, np.maximum(abs(h - pc), abs(l - pc)))).ewm(alpha=1 / 14, adjust=False).mean().values
            F = P.forecasting(d); G = P.grsi(d)
            data.append((s, d, atr, F, G)); print(tf, s, "ok", int(F["buy"].sum()), int(F["tr_long"].sum()), int(G["long"].sum()), flush=True)
        if not data:
            lines.append(f"\n=== {tf}: нет данных ==="); continue
        t0 = min(int(d.t.iloc[0]) for _s, d, *_ in data); mid = (t0 + now) // 2
        lines.append(f"\n=== {tf} · {len(data)} монет ===  сд · стоп% · R/сд · всё · 1пол · 2пол · 180д · монет+")
        V = {
            "Forecasting+ (BuyAlert) стоп 1.5ATR": (lambda F, G: np.where(F["buy"], 1, np.where(F["sell"], -1, 0)), "atr"),
            "Forecasting+ (BuyAlert) стоп за sup/res": (lambda F, G: np.where(F["buy"], 1, np.where(F["sell"], -1, 0)), "lvl"),
            "Twin Range Long/Short стоп 1.5ATR": (lambda F, G: np.where(F["tr_long"], 1, np.where(F["tr_short"], -1, 0)), "atr"),
            "G-RSI Heiken Ashi стоп 1.5ATR": (lambda F, G: np.where(G["long"], 1, np.where(G["short"], -1, 0)), "atr"),
        }
        for nm, (fe, st) in V.items():
            for tp in (1, 2, 3):
                allt = []; pos = 0
                for s, d, atr, F, G in data:
                    ent = fe(F, G)
                    if st == "atr":
                        slf = lambda i, sd, a=atr, c=d.c.values: c[i] - sd * 1.5 * a[i]
                    else:
                        slf = lambda i, sd, F=F: F["sup"][i] if sd > 0 else F["res"][i]
                    tr = sim(d, ent, slf, tp); allt += tr; pos += sum(r for _t, r, _p in tr) > 0
                if not allt:
                    continue
                tot = sum(r for _t, r, _p in allt); h1 = sum(r for t, r, _p in allt if t < mid); h2 = tot - h1
                w180 = sum(r for t, r, _p in allt if t >= now - 180 * 86400_000)
                ok = h1 > 0 and h2 > 0 and pos >= 0.6 * len(data)
                line = (f"{'✅' if ok else '❌'} {nm:<40} тейк {tp}R {len(allt):5} · {np.median([p for *_x, p in allt]) * 100:.2f}% · "
                        f"{tot / len(allt):+.3f} · {tot:+7.1f} · {h1:+6.1f} · {h2:+6.1f} · {w180:+6.1f} · {pos}/{len(data)}")
                print(line, flush=True); lines.append(line)
    (BASE / "bt_lab_bots" / "cs_port_test.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("готово")


if __name__ == "__main__":
    main()
