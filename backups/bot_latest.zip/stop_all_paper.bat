@echo off
cd /d "%~dp0"
chcp 65001 >nul
rem Ostanovit vse PAPER-processy. Realnye boty i panel ne trogaet.
venv\Scripts\python.exe bot_services.py stop-paper
pause
