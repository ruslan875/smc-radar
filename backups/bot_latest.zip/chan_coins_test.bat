@echo off
chcp 65001 >nul
cd /d "D:\VANTORIX\bot"
echo Channel breakout coin test. ~10 min, no trading.
python chan_coins_test.py
echo.
pause
