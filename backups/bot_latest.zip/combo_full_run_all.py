import sys, glob
sys.path.insert(0, '/mnt/user-data/outputs/combo')
from combo_full import *
U='/root/.claude/uploads/5c5df0e5-b78a-50c9-a5ca-e598bf9c16f8/'
subs={'SUB1':load_settings_csv(glob.glob(U+'661836af-*.csv')[0])[0],'SUB2':load_settings_csv(glob.glob(U+'80db0568-*.csv')[0])[0]}
c=subs['SUB1']; print({k:c[k] for k in ['zSrc','rsiSrc','cciSrc','rsiLen','lossesBeforePause','rvolTFLong','chopDoAvg','zLen','zCompSym','shadowControlStateSource','pivotRightBars']})
ref=load('BTC'); data={}
def go(name,cfg,sym,s,e,**kw):
    if sym not in data: data[sym]=load(sym)
    tr,dd,fin,st=run(data[sym],cfg,ref,s,e,**kw); r=summarize(tr,dd,fin)
    line=f"| {name} | {sym} | {s}..{e} | {r['net']:+.1f}% | {r['dd']:.1f}% | {r['trades']} | {r['win']:.1f}% | {r['pf']:.2f} | {st['shadow_trades']} |"
    print(line, flush=True); return line
rows=[]
for nm,cfg in subs.items():
    for s,e in [('2024-01-01','2026-09-23'),('2024-01-01','2025-01-01'),('2025-01-01','2026-09-23'),('2019-01-01','2024-01-01')]:
        rows.append(go(nm,cfg,'XRP',s,e))
    c2=dict(cfg); c2['shadowLockActive']=False
    rows.append(go(nm+' (shadow lock OFF)',c2,'XRP','2024-01-01','2026-09-23'))
for nm,cfg in subs.items():
    for sym in ['BTC','ETH','SOL','DOGE','ADA','LINK','LTC','BNB','AVAX']:
        rows.append(go(nm,cfg,sym,'2024-01-01','2026-09-23'))
rows.append(go('Pine defaults',default_config(),'XRP','2024-01-01','2026-09-23'))
open('/mnt/user-data/outputs/combo/_rows.txt','w').write('\n'.join(rows))
