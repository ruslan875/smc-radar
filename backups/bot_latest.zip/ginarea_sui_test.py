"""ginarea_sui_test.py — 2026-11-02. Приближённый бэктест бота GinArea «Sui long 5min» (Indicator grid, LONG).

Настройки со скриншотов:
  вход: RSI(14) на 5m < 35  И  ATR%(10) на 1m > 0.14 · «разовая проверка» ВКЛ (условие — только для старта цикла)
  сетка: 30 ордеров, шаг 0.05% · размер 1 SUI × 1.01, макс. 2 SUI
  выход (% режим): цель 0.25% от цены IN (выход по средней ВЫКЛ — каждый ордер закрывается сам),
     мин. стоп 0.01%, макс. стоп 0.1% (трейлинг), Instop 0.02%
  тейк бота 8 $ (+0.2 после каждого), стоп-лосса НЕТ, остановка «30 мин И 50 $» (почти никогда).
Модель (алгоритм GinArea закрыт — приближение, сверяй с бэктестом GinArea):
  * цикл стартует, когда закрытые свечи дают RSI5m<35 и ATR%1m>0.14 → IN по открытию минуты;
  * следующий IN — на 0.05% ниже самого нижнего открытого ордера (до 30 одновременно);
  * каждый ордер: цена ≥ IN×1.0025 → стоп-профит, тянется за ценой на 0.1% (не ближе 0.01% от триггера);
  * когда все ордера закрыты — цикл кончился, новый только по условию индикатора.
Комиссии: taker 0.05% (OKX) и 0.055% (Bybit) с обеих сторон. Ничего не торгует.
Запуск: ginarea_sui_test.bat [дней=180] [монета=SUI] → bt_lab_bots/ginarea_sui_test.txt
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd
import requests

from ginarea_lot import fl, lot  # 2026-11-03: размер ордера округляется вниз до лота OKX

BASE = Path(__file__).resolve().parent
CACHE = BASE / "market_cache"
OUT = BASE / "bt_lab_bots" / "ginarea_sui_test.txt"
LINES = []


def say(s=""):
    print(s, flush=True); LINES.append(s)


def okx_1m(coin, days):
    CACHE.mkdir(exist_ok=True)
    path = CACHE / f"okx_{coin}_1m.pkl"
    old = pd.read_pickle(path) if path.exists() else pd.DataFrame(columns=["t", "o", "h", "l", "c"])
    need_from = int((time.time() - days * 86400) * 1000)
    have_new = int(old.t.max()) if len(old) else 0
    have_old = int(old.t.min()) if len(old) else None

    def pull(after, stop):
        rows, k = [], 0
        while True:
            q = {"instId": f"{coin}-USDT-SWAP", "bar": "1m", "limit": 100}
            if after:
                q["after"] = after
            j = None
            for tr in range(6):
                try:
                    j = requests.get("https://www.okx.com/api/v5/market/history-candles", params=q, timeout=20).json()
                    if j.get("code") == "0":
                        break
                except requests.RequestException:
                    pass
                time.sleep(1.5 * (tr + 1))
            lst = (j or {}).get("data") or []
            if not lst:
                break
            rows += [r for r in lst if len(r) < 9 or r[8] == "1"]
            after = lst[-1][0]; k += 1
            if k % 200 == 0:
                print(f"  качаю OKX {coin} 1m: {pd.to_datetime(int(after), unit='ms'):%Y-%m-%d}", flush=True)
            if int(after) <= stop or len(lst) < 100:
                break
            time.sleep(0.11)
        return rows

    rows = pull(None, max(have_new, need_from))
    if have_old is not None and have_old > need_from + 60_000:
        rows += pull(str(have_old), need_from)
    if rows:
        a = pd.DataFrame([[int(r[0])] + [float(x) for x in r[1:5]] for r in rows], columns=["t", "o", "h", "l", "c"])
        old = pd.concat([old, a]).drop_duplicates("t").sort_values("t").reset_index(drop=True)
        old.to_pickle(path)
    return old[old.t >= need_from].reset_index(drop=True)


def gates(d, rsi_lvl=35.0, atr_min=0.14):
    ix = pd.to_datetime(d.t, unit="ms")
    c5 = pd.Series(d.c.to_numpy(), index=ix).resample("5min").last().dropna()
    dl = c5.diff()
    up = dl.clip(lower=0).ewm(alpha=1 / 14, adjust=False).mean()
    dn = (-dl.clip(upper=0)).ewm(alpha=1 / 14, adjust=False).mean()
    r = 100 - 100 / (1 + up / dn.replace(0, 1e-12))
    key = ix.dt.floor("5min") - pd.Timedelta("5min")            # последняя ЗАКРЫТАЯ 5m
    g_rsi = r.reindex(key).to_numpy() < rsi_lvl
    pc = d.c.shift(1)
    tr = pd.concat([d.h - d.l, (d.h - pc).abs(), (d.l - pc).abs()], axis=1).max(axis=1)
    atrp = (tr.ewm(alpha=1 / 10, adjust=False).mean() / d.c * 100).shift(1)   # закрытая 1m
    g_atr = (atrp > atr_min).to_numpy()
    return g_rsi & g_atr


def run(d, gate, fee, P):
    t, o, h, l, c = (d[k].to_numpy() for k in ("t", "o", "h", "l", "c"))
    lots, total, sess, tp = [], 0.0, 0.0, P["tp0"]
    R = {"cycles": 0, "deals": 0, "bot_tp": 0, "fees": 0.0, "max_lots": 0, "max_notional": 0.0, "worst": 0.0,
         "worst_t": None, "hang_h": 0.0, "sl": 0}
    monthly = {}
    q_next = P["qty"]; cyc_t0 = None

    def book(x, ts):
        nonlocal total, sess
        total += x; sess += x
        m = pd.to_datetime(ts, unit="ms").strftime("%Y-%m"); monthly[m] = monthly.get(m, 0.0) + x

    for i in range(1, len(c)):
        if not lots:
            if not gate[i]:
                continue
            R["cycles"] += 1; cyc_t0 = t[i]; q_next = P["qty"]
            qa = fl(q_next, P); lots.append({"px": o[i], "q": qa, "stop": None}); R["fees"] += o[i] * qa * fee; book(-o[i] * qa * fee, t[i])
            q_next = min(q_next * P["mult"], P["qmax"])
        # доборы ниже самого нижнего ордера
        while len(lots) < P["n"] and l[i] <= min(x["px"] for x in lots) * (1 - P["step"]):
            px = min(x["px"] for x in lots) * (1 - P["step"])
            qa = fl(q_next, P); lots.append({"px": px, "q": qa, "stop": None}); R["fees"] += px * qa * fee; book(-px * qa * fee, t[i])
            q_next = min(q_next * P["mult"], P["qmax"])
        R["max_lots"] = max(R["max_lots"], len(lots))
        R["max_notional"] = max(R["max_notional"], sum(x["q"] for x in lots) * c[i])
        un_l = sum((l[i] - x["px"]) * x["q"] for x in lots)
        if un_l < R["worst"]:
            R["worst"], R["worst_t"] = un_l, t[i]
        if P.get("sl") is not None and sess + un_l <= P["sl"]:           # опц. стоп-лосс бота
            for x in lots:
                R["fees"] += l[i] * x["q"] * fee; book((l[i] - x["px"]) * x["q"] - l[i] * x["q"] * fee, t[i])
            lots = []; R["sl"] += 1; sess, tp = 0.0, P["tp0"]
            continue
        keep = []
        for x in lots:                                                    # каждый ордер — свой трейлинг-выход
            trig = x["px"] * (1 + P["target"])
            if x["stop"] is None and h[i] >= trig:
                x["stop"] = trig * (1 - P["min_stop"])
            if x["stop"] is not None:
                x["stop"] = max(x["stop"], h[i] * (1 - P["max_stop"]))
                if l[i] <= x["stop"]:
                    R["fees"] += x["stop"] * x["q"] * fee
                    book((x["stop"] - x["px"]) * x["q"] - x["stop"] * x["q"] * fee, t[i]); R["deals"] += 1
                    continue
            keep.append(x)
        lots = keep
        if not lots and cyc_t0 is not None:
            R["hang_h"] = max(R["hang_h"], (t[i] - cyc_t0) / 3_600_000)
        un = sum((c[i] - x["px"]) * x["q"] for x in lots)
        if sess + un >= tp:                                               # тейк бота: закрыть всё, перезапуск
            for x in lots:
                R["fees"] += c[i] * x["q"] * fee; book((c[i] - x["px"]) * x["q"] - c[i] * x["q"] * fee, t[i])
            lots = []; R["bot_tp"] += 1; sess = 0.0; tp += P["tp_inc"]
    if lots and cyc_t0 is not None:
        R["hang_h"] = max(R["hang_h"], (t[-1] - cyc_t0) / 3_600_000)
    R["open_un"] = sum((c[-1] - x["px"]) * x["q"] for x in lots)
    R["open_lots"] = len(lots)
    R["total"], R["monthly"] = total, monthly
    return R


def report(name, r):
    say(f"--- {name}")
    say(f"  закрыто {r['total']:+.2f} $ · сейчас висит {r['open_lots']} орд. {r['open_un']:+.2f} $ · ИТОГО {r['total'] + r['open_un']:+.2f} $")
    say(f"  сделок (пар IN→OUT) {r['deals']} · циклов {r['cycles']} · тейков бота {r['bot_tp']} · стоп-лоссов {r['sl']} · комиссии {r['fees']:.2f} $")
    say(f"  макс. ордеров {r['max_lots']} (позиция до {r['max_notional']:.1f} $) · худшая просадка {r['worst']:.2f} $"
        + (f" ({pd.to_datetime(r['worst_t'], unit='ms'):%Y-%m-%d})" if r["worst_t"] else "") + f" · самый долгий цикл {r['hang_h']:.0f} ч")
    say("  по месяцам: " + "  ".join(f"{m} {v:+.2f}" for m, v in sorted(r["monthly"].items())))


def main():
    days = int(sys.argv[1]) if len(sys.argv) > 1 else 180
    coin = (sys.argv[2] if len(sys.argv) > 2 else "SUI").upper()
    say(f"GinArea Indicator grid «Sui long 5min» — приближённый бэктест · OKX {coin} 1m · {days} дн. · {time.strftime('%Y-%m-%d %H:%M')}")
    d = okx_1m(coin, days)
    if len(d) < 10000:
        say("мало свечей — OKX не отдал историю"); return
    say(f"Свечей {len(d)} · {pd.to_datetime(d.t.iloc[0], unit='ms'):%Y-%m-%d} → {pd.to_datetime(d.t.iloc[-1], unit='ms'):%Y-%m-%d} · "
        f"{coin} {d.c.iloc[0]:.4f} → {d.c.iloc[-1]:.4f} ({(d.c.iloc[-1] / d.c.iloc[0] - 1) * 100:+.0f}%)")
    g = gates(d)
    say(f"Минут, где условие входа выполнено: {g.sum()} из {len(g)}")
    base = dict(n=30, step=0.0005, qty=1.0, mult=1.01, qmax=2.0, target=0.0025, min_stop=0.0001, max_stop=0.001,
                tp0=8.0, tp_inc=0.2, sl=None, lot=lot(coin))
    say(f"Лот OKX {coin}: шаг {base['lot'][0]:g}, минимум {base['lot'][1]:g} монет (размер ордера округляется вниз)")
    say(f"Сетка покрывает падение всего ≈ {(1 - (1 - base['step']) ** 29) * 100:.2f}% от первого ордера")
    for fee, fn in ((0.0005, "OKX taker 0.05%"), (0.00055, "Bybit taker 0.055%")):
        say(""); say(f"===== комиссия {fn} =====")
        report("как у тебя (30 × 0.05%, цель 0.25%, без стопа)", run(d, g, fee, base))
    fee = 0.0005
    say(""); say("===== варианты (OKX 0.05%) =====")
    report("цель 0.5% вместо 0.25%", run(d, g, fee, {**base, "target": 0.005}))
    report("шаг 0.2% (сетка шире, ≈ 5.6%)", run(d, g, fee, {**base, "step": 0.002}))
    report("стоп-лосс бота −5 $", run(d, g, fee, {**base, "sl": -5.0}))
    report("без фильтра ATR% (только RSI<35)", run(d, gates(d, atr_min=-1), fee, base))
    say(""); say("Комиссия съедает: вход+выход 0.10% от цели 0.25% — 40% прибыли каждой сделки.")
    say("Это приближение: сверяй с бэктестом GinArea (тики).")
    OUT.parent.mkdir(exist_ok=True); OUT.write_text("\n".join(LINES), encoding="utf-8")
    print(f"\nОтчёт: {OUT}")


if __name__ == "__main__":
    main()
