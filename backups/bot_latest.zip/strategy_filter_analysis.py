#!/usr/bin/env python3
"""
Tests concrete "make the strategy more accurate" hypotheses against
backtest.py's per-trade CSVs, without touching live code or needing any
network access -- pure post-hoc filtering of trades that already fired.

Answers: if we'd only taken a subset of the setups that actually fired
(e.g. drop BTCUSDT, or only take CHoCH, or only take OB+FVG-confluence
zones), does win rate / average R actually improve, or does the sample
just get smaller with no real edge gain?

Run after backtest.py has produced CSVs in backtest_out/:
    python strategy_filter_analysis.py
    python strategy_filter_analysis.py --dir backtest_out
"""
from __future__ import annotations

import argparse
import csv
from pathlib import Path


def load_trades(directory: Path) -> list:
    trades = []
    for path in sorted(directory.glob("*_trades.csv")):
        with path.open(newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                if row.get("r") in (None, "", "None"):
                    continue
                try:
                    row["r"] = float(row["r"])
                except (TypeError, ValueError):
                    continue
                trades.append(row)
    return trades


def stats(trades: list) -> dict:
    if not trades:
        return {"n": 0, "win_rate": float("nan"), "avg_r": float("nan")}
    wins = sum(1 for t in trades if t["r"] > 0)
    return {
        "n": len(trades),
        "win_rate": wins / len(trades) * 100,
        "avg_r": sum(t["r"] for t in trades) / len(trades),
    }


def report(label: str, trades: list, baseline: dict) -> None:
    s = stats(trades)
    if s["n"] == 0:
        print(f"  {label:32s} n=0 (no trades match this filter)")
        return
    delta = s["avg_r"] - baseline["avg_r"] if baseline["n"] else float("nan")
    print(f"  {label:32s} n={s['n']:4d}  win rate={s['win_rate']:5.1f}%  avg R={s['avg_r']:+.3f}  "
          f"(vs baseline {delta:+.3f})")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--dir", default="backtest_out")
    args = parser.parse_args()

    directory = Path(args.dir)
    trades = load_trades(directory)
    if not trades:
        print(f"No resolved trades found in {directory.resolve()} -- run backtest.py first.")
        return

    baseline = stats(trades)
    print(f"Loaded {len(trades)} resolved trades from {directory.resolve()}")
    print(f"\nBaseline (everything the code actually fired):")
    print(f"  n={baseline['n']}  win rate={baseline['win_rate']:.1f}%  avg R={baseline['avg_r']:+.3f}")

    print(f"\n--- By symbol, excluding one at a time ---")
    symbols = sorted({t["symbol"] for t in trades})
    for sym in symbols:
        subset = [t for t in trades if t["symbol"] != sym]
        report(f"exclude {sym}", subset, baseline)

    print(f"\n--- By event type (only) ---")
    for event in ("BOS", "CHoCH", "SWEEP"):
        subset = [t for t in trades if t["event"] == event]
        report(f"only {event}", subset, baseline)

    print(f"\n--- By event type (excluding one) ---")
    for event in ("BOS", "CHoCH", "SWEEP"):
        subset = [t for t in trades if t["event"] != event]
        report(f"exclude {event}", subset, baseline)

    print(f"\n--- By zone confluence (OB vs OB+FVG), sweeps have no zone_kind so excluded here ---")
    for kind in ("OB", "OB+FVG"):
        subset = [t for t in trades if t.get("zone_kind") == kind]
        report(f"only zone_kind={kind}", subset, baseline)

    print(f"\n--- Combined: drop worst symbol + only CHoCH/SWEEP (example compound filter) ---")
    if symbols:
        worst_symbol = min(symbols, key=lambda s: stats([t for t in trades if t["symbol"] == s])["avg_r"])
        compound = [t for t in trades if t["symbol"] != worst_symbol and t["event"] in ("CHoCH", "SWEEP")]
        report(f"exclude {worst_symbol} + drop BOS", compound, baseline)

    print(
        "\nReading this: a filter that raises avg R AND keeps a decent n (not just "
        "shrinks to a handful of lucky trades) is a real candidate. A filter that "
        "raises win rate but drops avg R is not an improvement -- it's just fewer, "
        "smaller wins. Cross-check anything promising here against fee_analysis.py "
        "too, since the fee-adjusted R is what actually matters, not the raw one."
    )


if __name__ == "__main__":
    main()
