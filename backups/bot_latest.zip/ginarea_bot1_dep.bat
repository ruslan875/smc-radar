@echo off
cd /d D:\VANTORIX\bot
venv\Scripts\python.exe ginarea_bot1_test.py %1 %2 %3
pause
