#!/usr/bin/env python3
"""
Gaussian Channel Strategy - Standalone Backtest Runner
========================================================

Hand-ported from gaussian_channel_strategy.pine (RezzoRedPriest, open-source,
https://www.tradingview.com/script/erJi1tWf-Gaussian-Channel-Strategy/).

WHY THIS IS HAND-PORTED, NOT RUN THROUGH pine\\run_pine.py:
The project's pine_transpiler.py fails on this script (named-argument syntax
in strategy(...) isn't parsed). Even if that were fixed, the transpiler does
not implement `var`-persisted recursive state, which this script's Gaussian
filter depends on completely (f_filt9x recurses on its own past output).
So this is a direct, faithful re-implementation of the Pine math in numpy.

USAGE (same conventions as third_eye_backtest.py):

    pip install pandas numpy ccxt

    python gaussian_channel_backtest.py --symbol BTC/USDT --timeframe 1h \\
        --start 2023-01-01 --end 2025-12-31 --out backtest_out_gaussian

    python gaussian_channel_backtest.py --symbols BTC/USDT ETH/USDT SOL/USDT \\
        --timeframe 1h --start 2023-01-01 --end 2025-12-31 --out backtest_out_gaussian

    # Pine has NO built-in TP/SL (author says so explicitly) - test with one:
    python gaussian_channel_backtest.py --symbol BTC/USDT --timeframe 1h --tp 3.0 --sl 1.5

Output: <out>/<SYMBOL>_deals.csv - same schema as third_eye_backtest.py
        (entry_time, exit_time, side, entry_price, exit_price, gross_pnl_pct, reason)
        so analyze_external_strategies.py works unchanged on either output folder.

PARITY NOTES (what's faithful vs. what's a documented simplification):
  - The N-pole Gaussian/Ehlers recursive filter (f_filt9x/f_pole) is
    reproduced exactly via math.comb-based binomial recursion per pole
    order 1..N, matching the Pine source's hardcoded coefficient tables.
  - beta/alpha derivation matches the Pine formula exactly, including the
    literal 1.414 constant in the beta formula (NOT the user's `mult` input
    - that's a separate, coincidentally-same-default parameter used only
      for band width, exactly as in the source).
  - Default inputs match the Pine script's defaults: Source=hlc3, N=4,
    Sampling Period=144, Filtered TR Multiplier=1.414, both signal lines
    default to "Filter (middle)", Long=Cross Up, Short=Cross Down,
    lookback=3, both directions enabled, reverse-on-opposite=true.
  - Pine has NO stop-loss / take-profit by default (author's own README
    says "feel free to add with strategy.exit"). This script adds OPTIONAL
    --tp/--sl flags (both 0 = disabled by default) purely for practical
    testing; with them at 0 the engine only flips position on the opposite
    signal, exactly like the Pine default.
  - "Reduced Lag Mode" / "Fast Response Mode" are implemented but default
    off, matching Pine defaults.
"""

import argparse
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd

CONFIG = {
    "poles": 4,
    "sampling_period": 144,
    "mult": 1.414,
    "reduced_lag": False,
    "fast_response": False,
    "sig_line_long": "filter",   # filter | upper | lower
    "sig_line_short": "filter",
    "dir_long": "cross_up",      # cross_up | cross_down
    "dir_short": "cross_down",
    "trade_long": True,
    "trade_short": True,
    "reverse_on_opposite": True,
    "lookback": 3,
}


# ============================================================================
# GAUSSIAN N-POLE RECURSIVE FILTER (faithful port of f_filt9x / f_pole)
# ============================================================================

def _pole_series(alpha: float, src: np.ndarray, order: int) -> np.ndarray:
    """
    One pole-`order` recursive filter, matching f_filt9x(alpha, src, order):
        f[t] = a^order * src[t]
             + order*(1-a)*f[t-1]
             - C(order,2)*(1-a)^2*f[t-2]
             + C(order,3)*(1-a)^3*f[t-3]
             - ... alternating up to k=order
    Each pole order keeps its OWN independent recursive history, exactly as
    Pine's `var` state is per call-site (f_filt9x called separately for
    i=1..N inside f_pole).
    """
    n = len(src)
    x = 1 - alpha
    f = np.zeros(n)
    coeffs = [((-1) ** (k + 1)) * math.comb(order, k) * (x ** k) for k in range(1, order + 1)]

    for t in range(n):
        val = (alpha ** order) * (src[t] if not np.isnan(src[t]) else 0.0)
        for k in range(1, order + 1):
            if t - k >= 0:
                val += coeffs[k - 1] * f[t - k]
        f[t] = val
    return f


def _f_pole(alpha: float, src: np.ndarray, N: int):
    """Returns (filtN, filt1) matching f_pole(alpha, src, N)."""
    filt1 = _pole_series(alpha, src, 1)
    filtN = _pole_series(alpha, src, N) if N > 1 else filt1
    return filtN, filt1


def gaussian_channel(df: pd.DataFrame, cfg: dict = CONFIG):
    src = ((df["high"] + df["low"] + df["close"]) / 3).to_numpy()  # hlc3, Pine default source

    N = cfg["poles"]
    per = cfg["sampling_period"]
    mult = cfg["mult"]

    beta = (1 - math.cos(4 * math.asin(1) / per)) / (math.pow(1.414, 2 / N) - 1)
    alpha = -beta + math.sqrt(beta * beta + 2 * beta)
    lag = int((per - 1) / (2 * N))

    if cfg["reduced_lag"] and lag > 0:
        src_shift = np.roll(src, lag)
        src_shift[:lag] = np.nan
        src_data = src + (src - src_shift)
    else:
        src_data = src

    prev_close = df["close"].shift(1).to_numpy()
    tr = np.maximum.reduce([
        (df["high"] - df["low"]).to_numpy(),
        np.abs(df["high"].to_numpy() - prev_close),
        np.abs(df["low"].to_numpy() - prev_close),
    ])
    tr = np.nan_to_num(tr, nan=0.0)

    if cfg["reduced_lag"] and lag > 0:
        tr_shift = np.roll(tr, lag)
        tr_shift[:lag] = 0.0
        tr_data = tr + (tr - tr_shift)
    else:
        tr_data = tr

    filtN, filt1 = _f_pole(alpha, src_data, N)
    filtNtr, filt1tr = _f_pole(alpha, tr_data, N)

    if cfg["fast_response"]:
        filt = (filtN + filt1) / 2
        filt_tr = (filtNtr + filt1tr) / 2
    else:
        filt = filtN
        filt_tr = filtNtr

    h_band = filt + filt_tr * mult
    l_band = filt - filt_tr * mult

    out = df.copy()
    out["filt"] = filt
    out["h_band"] = h_band
    out["l_band"] = l_band
    return out


def _get_line(df: pd.DataFrame, which: str) -> pd.Series:
    return {"filter": df["filt"], "upper": df["h_band"], "lower": df["l_band"]}[which]


def generate_signals(df: pd.DataFrame, cfg: dict = CONFIG) -> pd.DataFrame:
    out = df.copy()
    src = (out["high"] + out["low"] + out["close"]) / 3

    sig_l = _get_line(out, cfg["sig_line_long"])
    sig_s = _get_line(out, cfg["sig_line_short"])

    long_up = (src > sig_l) & (src.shift(1) <= sig_l.shift(1))
    long_down = (src < sig_l) & (src.shift(1) >= sig_l.shift(1))
    short_up = (src > sig_s) & (src.shift(1) <= sig_s.shift(1))
    short_down = (src < sig_s) & (src.shift(1) >= sig_s.shift(1))

    def bars_since(cond: pd.Series) -> pd.Series:
        idx = np.arange(len(cond))
        last_true = np.where(cond.to_numpy(), idx, -1)
        last_true = np.maximum.accumulate(last_true)
        return pd.Series(idx - last_true, index=cond.index)

    lb = cfg["lookback"]
    if cfg["dir_long"] == "cross_up":
        long_cond = long_up | ((src > sig_l) & (bars_since(long_up) <= lb))
    else:
        long_cond = long_down | ((src < sig_l) & (bars_since(long_down) <= lb))

    if cfg["dir_short"] == "cross_up":
        short_cond = short_up | ((src > sig_s) & (bars_since(short_up) <= lb))
    else:
        short_cond = short_down | ((src < sig_s) & (bars_since(short_down) <= lb))

    out["long_signal"] = long_cond.fillna(False) & cfg["trade_long"]
    out["short_signal"] = short_cond.fillna(False) & cfg["trade_short"]
    return out


# ============================================================================
# BACKTEST ENGINE
# strategy.entry/close semantics: reverse-on-opposite by default, one
# position at a time. Optional TP/SL since Pine has none built in.
# ============================================================================

def run_backtest(df: pd.DataFrame, cfg: dict = CONFIG,
                  tp_pct: float = 0.0, sl_pct: float = 0.0,
                  commission_pct: float = 0.05, slippage_pct: float = 0.0) -> pd.DataFrame:
    commission = commission_pct / 100
    position = None
    deals = []

    for ts, row in df.iterrows():
        c = row["close"]
        long_sig, short_sig = bool(row["long_signal"]), bool(row["short_signal"])

        if position is not None:
            side = position["side"]
            exit_now, reason, exit_price = False, None, None

            if sl_pct > 0:
                if side == "long" and row["low"] <= position["stop"]:
                    exit_now, reason, exit_price = True, "stop_loss", position["stop"]
                elif side == "short" and row["high"] >= position["stop"]:
                    exit_now, reason, exit_price = True, "stop_loss", position["stop"]
            if not exit_now and tp_pct > 0:
                if side == "long" and row["high"] >= position["target"]:
                    exit_now, reason, exit_price = True, "take_profit", position["target"]
                elif side == "short" and row["low"] <= position["target"]:
                    exit_now, reason, exit_price = True, "take_profit", position["target"]

            # opposite signal: close (and possibly reverse) per Pine logic
            if not exit_now:
                if side == "long" and short_sig:
                    exit_now, reason, exit_price = True, "opposite_signal", c
                elif side == "short" and long_sig:
                    exit_now, reason, exit_price = True, "opposite_signal", c

            if exit_now:
                entry = position["entry_price"]
                if side == "long":
                    pnl = (exit_price / entry - 1) * 100 - commission * 200
                else:
                    pnl = (entry / exit_price - 1) * 100 - commission * 200
                deals.append({**position, "exit_time": ts, "exit_price": exit_price,
                              "gross_pnl_pct": pnl, "reason": reason})
                position = None
                # reverse immediately into the opposite signal, matching
                # reverseOnOpp=true in the Pine source
                if reason == "opposite_signal" and cfg["reverse_on_opposite"]:
                    if short_sig and cfg["trade_short"]:
                        entry_price = c * (1 - slippage_pct / 100)
                        position = {"side": "short", "entry_time": ts, "entry_price": entry_price,
                                    "stop": entry_price * (1 + sl_pct / 100) if sl_pct > 0 else None,
                                    "target": entry_price * (1 - tp_pct / 100) if tp_pct > 0 else None}
                    elif long_sig and cfg["trade_long"]:
                        entry_price = c * (1 + slippage_pct / 100)
                        position = {"side": "long", "entry_time": ts, "entry_price": entry_price,
                                    "stop": entry_price * (1 - sl_pct / 100) if sl_pct > 0 else None,
                                    "target": entry_price * (1 + tp_pct / 100) if tp_pct > 0 else None}

        if position is None:
            if long_sig and cfg["trade_long"]:
                entry_price = c * (1 + slippage_pct / 100)
                position = {"side": "long", "entry_time": ts, "entry_price": entry_price,
                            "stop": entry_price * (1 - sl_pct / 100) if sl_pct > 0 else None,
                            "target": entry_price * (1 + tp_pct / 100) if tp_pct > 0 else None}
            elif short_sig and cfg["trade_short"]:
                entry_price = c * (1 - slippage_pct / 100)
                position = {"side": "short", "entry_time": ts, "entry_price": entry_price,
                            "stop": entry_price * (1 + sl_pct / 100) if sl_pct > 0 else None,
                            "target": entry_price * (1 - tp_pct / 100) if tp_pct > 0 else None}

    deals_df = pd.DataFrame(deals)
    if not deals_df.empty:
        deals_df = deals_df[["entry_time", "exit_time", "side", "entry_price",
                              "exit_price", "gross_pnl_pct", "reason"]]
    return deals_df


# ============================================================================
# DATA LOADING (identical pattern to third_eye_backtest.py)
# ============================================================================

def load_from_csv(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    df.columns = [c.lower() for c in df.columns]
    ts_col = "timestamp" if "timestamp" in df.columns else df.columns[0]
    df[ts_col] = pd.to_datetime(df[ts_col], errors="coerce")
    df = df.set_index(ts_col).sort_index()
    return df[["open", "high", "low", "close", "volume"]]


def load_from_ccxt(symbol: str, timeframe: str, start: str, end: str,
                   exchange_id: str = "bybit", market: str = "swap") -> pd.DataFrame:
    """Delegates to the shared loader in market_data.py.

    2026-09-20: this function used to be a private copy inside every backtest
    script, and every copy carried the same three defects. It fetched SPOT
    candles while the bots trade USDT PERPETUALS (ccxt's bybit defaults to
    spot, and the wrong market never showed up in any output). It fired
    requests with no rate limit and no retry, so a long pull - a year of 15m
    candles is ~117 sequential pages - died partway with RequestTimeout. And
    it stopped paging on the first short page, which can end a run quietly on
    partial history. All three are fixed once, in market_data.load_ohlcv,
    which also caches to disk so repeat runs cost nothing.
    """
    from market_data import load_ohlcv
    return load_ohlcv(symbol, timeframe, start, end,
                      exchange_id=exchange_id, market=market)


def print_summary(symbol: str, deals: pd.DataFrame):
    if deals.empty:
        print(f"  {symbol:12s}: 0 trades")
        return
    n = len(deals)
    wins = deals[deals["gross_pnl_pct"] > 0]
    losses = deals[deals["gross_pnl_pct"] <= 0]
    win_rate = len(wins) / n * 100
    avg_pnl = deals["gross_pnl_pct"].mean()
    gp, gl = wins["gross_pnl_pct"].sum(), abs(losses["gross_pnl_pct"].sum())
    pf = (gp / gl) if gl > 0 else float("inf")
    print(f"  {symbol:12s}: {n:4d} trades | avg P&L {avg_pnl:+6.2f}% | win rate {win_rate:5.1f}% | PF {pf:6.2f}")


def _effective_commission(args):
    """The commission the run ACTUALLY used.

    In third_eye_backtest.py `--commission` is an optional override defaulting
    to None, with the real value living in CONFIG. Recording the raw argument
    wrote "null" into the manifest for runs that did charge 0.05% - the exact
    kind of quiet inaccuracy this manifest exists to prevent.
    """
    value = getattr(args, "commission", None)
    if value is None:
        cfg = globals().get("CONFIG")
        if isinstance(cfg, dict):
            value = cfg.get("commission_pct")
    return value


def _manifest_symbols(args) -> list:
    """Symbols for the run manifest, taken from the arguments rather than from
    the loaded data: in some of these scripts the output folder is created
    before the data is fetched, and reading `sources` there raised
    UnboundLocalError. Arguments are always available."""
    syms = list(getattr(args, "symbols", None) or [])
    if not syms and getattr(args, "symbol", None):
        syms = [args.symbol]
    if not syms and getattr(args, "csv", None):
        syms = [Path(args.csv).stem]
    return syms


def main():
    p = argparse.ArgumentParser(description="Gaussian Channel Strategy standalone backtester")
    p.add_argument("--symbol")
    p.add_argument("--symbols", nargs="+")
    p.add_argument("--csv")
    p.add_argument("--exchange", default="okx")
    p.add_argument("--market", default="swap", choices=["swap", "spot"],
                   help="swap = USDT perpetual (what the bots trade); "
                        "spot = spot market. Everything before 2026-09-20 silently used spot.")
    p.add_argument("--timeframe", default="1h")
    p.add_argument("--start", default="2023-01-01")
    p.add_argument("--end", default="2025-12-31")
    p.add_argument("--out", default="backtest_out_gaussian")
    p.add_argument("--tp", type=float, default=0.0, help="Optional TP %% (Pine has none built-in; 0=disabled)")
    p.add_argument("--sl", type=float, default=0.0, help="Optional SL %% (Pine has none built-in; 0=disabled)")
    p.add_argument("--commission", type=float, default=0.05)
    p.add_argument("--slippage-pct", type=float, default=0.0)
    p.add_argument("--poles", type=int, default=4)
    p.add_argument("--period", type=int, default=144)
    p.add_argument("--mult", type=float, default=1.414)
    args = p.parse_args()

    cfg = dict(CONFIG)
    cfg["poles"], cfg["sampling_period"], cfg["mult"] = args.poles, args.period, args.mult

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    # 2026-09-20: write down the conditions this run happened under.
    # Two runs with different timeframes once landed in the same folder and
    # the second silently overwrote the first - the comparison table then
    # showed numbers from settings nobody could reconstruct. The analyzer
    # reads this file and prints the conditions next to the metrics, so a
    # mismatched folder announces itself instead of quietly lying.
    import json as _json, datetime as _dt
    _manifest = {
        "strategy": Path(__file__).stem,
        "run_at": _dt.datetime.now().astimezone().isoformat(timespec="seconds"),
        "symbols": _manifest_symbols(args),
        "timeframe": getattr(args, "timeframe", None),
        "start": getattr(args, "start", None),
        "end": getattr(args, "end", None),
        "exchange": getattr(args, "exchange", None),
        "market": getattr(args, "market", None),
        "commission_pct": _effective_commission(args),
        "slippage_pct": getattr(args, "slippage_pct", None),
        "source": "csv" if getattr(args, "csv", None) else "exchange",
    }
    for _extra in ("tp", "sl", "entry_next_open", "len", "poles", "period", "mult"):
        if hasattr(args, _extra):
            _manifest[_extra] = getattr(args, _extra)
    (out_dir / "_run.json").write_text(_json.dumps(_manifest, indent=2), encoding="utf-8")

    if args.csv:
        symbols = [Path(args.csv).stem]
        sources = {symbols[0]: load_from_csv(args.csv)}
    else:
        symbols = args.symbols or ([args.symbol] if args.symbol else None)
        if not symbols:
            p.error("Provide --symbol, --symbols, or --csv")
        sources = {}
        for sym in symbols:
            print(f"Fetching {sym} {args.timeframe} from {args.exchange} ({args.start} -> {args.end})...")
            sources[sym] = load_from_ccxt(sym, args.timeframe, args.start, args.end,
                                          args.exchange, args.market)

    print("\n" + "=" * 100)
    print("GAUSSIAN CHANNEL STRATEGY - BACKTEST RESULTS")
    print("=" * 100)

    for sym, ohlcv in sources.items():
        if len(ohlcv) < cfg["sampling_period"] + 10:
            print(f"  {sym:12s}: insufficient data ({len(ohlcv)} bars)")
            continue
        df = gaussian_channel(ohlcv, cfg)
        df = generate_signals(df, cfg)
        deals = run_backtest(df, cfg, tp_pct=args.tp, sl_pct=args.sl,
                              commission_pct=args.commission, slippage_pct=args.slippage_pct)
        safe_name = sym.replace("/", "")
        deals.to_csv(out_dir / f"{safe_name}_deals.csv", index=False)
        print_summary(sym, deals)

    print("=" * 100)
    print(f"\nDeal logs written to: {out_dir}/  (compatible with analyze_external_strategies.py)")


if __name__ == "__main__":
    main()
