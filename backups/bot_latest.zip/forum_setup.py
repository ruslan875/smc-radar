"""forum_setup.py — 2026-10-10. Однократное оформление группы «TRADEOS Сигналы» (как CryptoFORA):
аватар, описание, все темы с цветами и закреплённым описанием в каждой. Запуск: forum_setup.bat. Повторный запуск безопасен."""
import json, os, sys
from pathlib import Path
import requests
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
from windows_app import risk_center as rc  # noqa: E402

BLUE, YELLOW, PURPLE, GREEN, PINK, RED = 7322096, 16766590, 13338331, 9367192, 16749490, 16478047
INFO = {
    "📐 Пробой канала": (GREEN, "Основная стратегия челленджа: пробой регрессионного канала 4h.\nСигнал → вход, стоп, тейк, график. Безубыток и результат приходят ОТВЕТОМ на сигнал.\nТеги: #ПробойКанала #монета #результат"),
    "🔴 Реальные боты": (RED, "Сделки ботов с реальными ордерами (Latuserge, KC/ROC грид): входы, выходы, ошибки биржи."),
    "⛔ Риск и лимиты": (RED, "Дневной стоп, лимит позиций, предупреждения риск-центра. Если здесь сообщение — читать сразу."),
    "👀 Подготовка": (YELLOW, "Цена подошла к границе канала — сигнала ЕЩЁ НЕТ, ждём закрытия свечи. Только для внимания."),
    "💼 Портфель": (BLUE, "Сигналы собранных стратегий с кнопками «Открыть» (кнопки — в личке бота). Сделка только после «✅ Открыть»."),
    "🧪 R4 HYPE": (PURPLE, "Бумажный тест R4 Mirror Fibo на HYPE 1h (родные настройки OKX). История: PF 1.47, +299%. Реальных ордеров нет."),
    "🧪 Pavlova": (PURPLE, "Бумажный тест Pavlova Combo на BTC 1h и XRP 1h. История: PF 1.52 / 1.25. Реальных ордеров нет."),
    "🧪 ETH RSI": (PURPLE, "Бумажный тест ETH RSI 4h на ETH и XRP. История: PF ~1.5 в обеих половинах. Реальных ордеров нет."),
    "🧪 Donchian": (PURPLE, "Бумажный тест Donchian 20 по тренду 4h, тейк 3R, 10 монет. Реальных ордеров нет."),
    "🧪 Combo OTM": (PURPLE, "Бумажный тест Combo OTM SUB2 на XRP 1h. Реальных ордеров нет."),
    "🧠 ИИ-фильтр": (PINK, "Оценка сигналов ИИ (только наблюдение, сделки не трогает) и переобучение своей модели."),
    "📊 Отчёты": (BLUE, "Утренний отчёт, сводки по ботам и балансам."),
    "🗂 Старые тесты": (PINK, "Старый paper-тест 10 стратегий (#Paper10) и прочие эксперименты. Можно не читать."),
}

def main():
    tok, _main, _paper = rc._tg_conf()
    chat = os.getenv("TELEGRAM_FORUM_CHAT_ID", "").strip()
    if not tok or not chat:
        print("Нет TELEGRAM_FORUM_CHAT_ID в .env — сначала запустите set_forum_group.bat"); return
    api = f"https://api.telegram.org/bot{tok}/"
    av = BASE / "windows_app" / "forum_avatar.png"
    if av.exists():
        r = requests.post(api + "setChatPhoto", data={"chat_id": chat}, files={"photo": av.open("rb")}, timeout=30).json()
        print("аватар:", "ок" if r.get("ok") else r.get("description"))
    r = requests.post(api + "setChatDescription", data={"chat_id": chat, "description":
        "Сигналы и тесты TRADEOS. 📐 — челлендж, 🔴 — реальные боты, 🧪 — бумажные тесты (без денег)."}, timeout=20).json()
    print("описание:", "ок" if r.get("ok") else r.get("description"))
    f = rc._TOPIC_FILE
    try: cache = json.loads(f.read_text(encoding="utf-8"))
    except Exception: cache = {}
    for name, _keys in rc._TOPICS:
        color, text = INFO.get(name, (BLUE, ""))
        key = f"{chat}:{name}"
        if key not in cache:
            r = requests.post(api + "createForumTopic", data={"chat_id": chat, "name": name, "icon_color": color}, timeout=20).json()
            if not r.get("ok"):
                print(name, "— ошибка:", r.get("description"), "(нужно право «Управление темами»)"); continue
            cache[key] = r["result"]["message_thread_id"]
            f.parent.mkdir(exist_ok=True); f.write_text(json.dumps(cache, ensure_ascii=False, indent=1), encoding="utf-8")
            m = requests.post(api + "sendMessage", data={"chat_id": chat, "message_thread_id": cache[key],
                              "text": f"<b>{name}</b>\n\n{text}", "parse_mode": "HTML"}, timeout=20).json()
            if m.get("ok"):
                requests.post(api + "pinChatMessage", data={"chat_id": chat, "message_id": m["result"]["message_id"],
                              "disable_notification": True}, timeout=20)
            print("тема создана:", name)
        else:
            print("уже есть:", name)
    print("\nГотово. Откройте группу «TRADEOS Сигналы».")

if __name__ == "__main__":
    main()
