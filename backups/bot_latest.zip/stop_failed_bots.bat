@echo off
REM 2026-10-26: останавливает «Paper 10 стратегий» (все 10 не прошли проверку). Реальные и демо-боты не трогаются.
cd /d D:\VANTORIX\bot
venv\Scripts\python.exe bot_services.py stop paper10
echo.
echo Gotovo. Paper10 ostanovlen i ne budet zapuskatsya storozhem (logs\paper10.off).
pause
