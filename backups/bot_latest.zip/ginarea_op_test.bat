@echo off
cd /d D:\VANTORIX\bot
venv\Scripts\python.exe ginarea_op_test.py 300
pause
