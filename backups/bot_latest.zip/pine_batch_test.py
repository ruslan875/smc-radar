"""pine_batch_test.py — 2026-11-02. Пачка: каждый сигнальный индикатор из tg_candidates/signals (+ strategies) → стратегия.
Pine → Python нашим переводчиком (bot/pine). Сигналы берутся из plotshape/alertcondition: заголовок с buy/long/bull/лонг… = вход в лонг,
sell/short/bear/шорт… = вход в шорт. Вход по закрытию бара, стоп 1.5 ATR14, тейк 2R или 3R, комиссия 0.06% (Hash Hedge).
12 монет, 2h и 4h (последние ~8000 баров). Проходит: обе половины истории > 0, ≥ 8/12 монет в плюсе, 180 дней > 0, ≥ 100 сделок.
Чтобы отсеять случайные удачи: «надёжный» — только если прошёл И на 2h, И на 4h.
Продолжает с места (bt_lab_bots/pine_batch.json), итог — bt_lab_bots/pine_batch.txt"""
from __future__ import annotations
import json, re, sys, time, traceback
from pathlib import Path
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE)); sys.path.insert(0, str(BASE / "pine"))
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import recheck_recent as RR  # noqa: E402
import pine_transpiler  # noqa: E402
import pine_runtime  # noqa: E402,F401
FEE = 0.0006
LONG_RE = re.compile(r"buy|long|bull|\bup\b|лонг|покуп|вверх|бычий|рост", re.I)
SHORT_RE = re.compile(r"sell|short|bear|\bdown\b|\bdn\b|шорт|продаж|вниз|медвеж|паден", re.I)
STATE = BASE / "bt_lab_bots" / "pine_batch.json"

# Терпимый перевод: цвета #RRGGBB не мешают; строка, которую переводчик не понял, даёт NaN и считается «пропуском».
# Скрипт без пропусков = «чистый перевод» (ему можно верить), с пропусками = «частичный» (логика могла исказиться).
_FAILS = {"n": 0}
_tok0 = pine_transpiler.tokenize
def _tok(src):
    src = re.sub(r"#[0-9A-Fa-f]{6,8}", "0", src)
    src = re.sub(r"\b(?:simple|series|const)\s+(?:int|float|bool|string|color)\s+(?=[A-Za-z_])", "", src)
    try:
        return _tok0(src)
    except SyntaxError:
        _FAILS["n"] += 1
        return [("NAME", "_BAD_")]
pine_transpiler.tokenize = _tok
_parse0 = pine_transpiler.ExprParser.parse
def _parse(self):
    try:
        return _parse0(self)
    except Exception:  # noqa: BLE001
        _FAILS["n"] += 1
        return "_np.nan"
pine_transpiler.ExprParser.parse = _parse
_tr0 = pine_transpiler.transpile
def _transpile(src):
    src = re.sub(r"\b(?:simple|series|const)\s+(?:int|float|bool|string|color)\s+(?=[A-Za-z_])", "", src)
    src = re.sub(r"(?m)^(\s*)(?:var\s+|varip\s+)?(?:float|int|bool|string|color)\s+(?=[A-Za-z_]\w*\s*:?=)", r"\1", src)
    src = re.sub(r"(\(|,\s*)(?:float|int|bool|string|color)\s+(?=[A-Za-z_]\w*\s*[,)=])", r"\1", src)
    return _tr0(src)
pine_transpiler.transpile = _transpile
def _stoch(src, high, low, length):
    import pandas as _p  # noqa: PLC0415
    lo = _p.Series(low).rolling(int(length)).min(); hi = _p.Series(high).rolling(int(length)).max()
    return 100 * (_p.Series(src) - lo) / (hi - lo).replace(0, float("nan"))
pine_runtime.stoch = _stoch
pine_transpiler.SIMPLE_FUNCS.setdefault("ta.stoch", "stoch")


def frames():
    import kvoo_longtest as K  # noqa: PLC0415
    out = {}
    for tf in ("2h", "4h"):
        lst = []
        for s in K.COINS:
            try:
                d = RR.load(s, tf)
            except Exception:  # noqa: BLE001
                d = None
            if d is None or len(d) < 1500:
                continue
            d = d.reset_index(drop=True).iloc[-8000:].reset_index(drop=True)
            df = pd.DataFrame({"open_time": pd.to_datetime(d.t.values, unit="ms", utc=True), "open": d.o.values.astype(float),
                               "high": d.h.values.astype(float), "low": d.l.values.astype(float), "close": d.c.values.astype(float),
                               "volume": d.v.values.astype(float) if "v" in d else 0.0})
            c, h, l = df.close.values, df.high.values, df.low.values
            pc = np.r_[c[0], c[:-1]]
            atr = pd.Series(np.maximum(h - l, np.maximum(abs(h - pc), abs(l - pc)))).ewm(alpha=1 / 14, adjust=False).mean().values
            lst.append((s, df, d.t.values.astype("int64"), atr))
        out[tf] = lst
    return out


def sim(t, c, h, l, atr, ent, tp_r, hold=200):
    n = len(c); out = []; i = 210
    idx = np.flatnonzero(ent)
    k = 0
    while k < len(idx):
        i = idx[k]
        if i < 210 or i >= n - 1 or not atr[i] > 0:
            k += 1; continue
        s = int(ent[i]); e = c[i]; risk = 1.5 * atr[i]; stp = e - s * risk; tp = e + s * tp_r * risk; res = None
        for j in range(i + 1, min(n, i + hold)):
            if (l[j] <= stp) if s > 0 else (h[j] >= stp): res = (j, -1.0); break
            if (h[j] >= tp) if s > 0 else (l[j] <= tp): res = (j, float(tp_r)); break
        if res is None:
            j = min(n - 1, i + hold - 1); res = (j, s * (c[j] - e) / risk)
        out.append((int(t[i]), res[1] - FEE * e / risk))
        while k < len(idx) and idx[k] <= res[0]:
            k += 1
    return out


def entries(sig: dict, n: int):
    lo = np.zeros(n, bool); sh = np.zeros(n, bool); nl = ns = 0
    for title, ser in sig.items():
        if not isinstance(ser, pd.Series):
            continue
        a = ser.fillna(False).to_numpy()
        try:
            a = a.astype(bool)
        except Exception:  # noqa: BLE001
            continue
        if len(a) != n:
            continue
        tl, ts = bool(LONG_RE.search(title)), bool(SHORT_RE.search(title))
        if tl and not ts:
            lo |= a; nl += 1
        elif ts and not tl:
            sh |= a; ns += 1
    ent = np.where(lo & ~sh, 1, np.where(sh & ~lo, -1, 0))
    return ent, nl, ns


def main():
    now = int(time.time() * 1000)
    files = sorted((BASE / "tg_candidates" / "signals").glob("*.txt")) + sorted((BASE / "tg_candidates" / "strategies").glob("*.txt"))
    try:
        state = json.loads(STATE.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        state = {}
    F = frames()
    print(f"скриптов {len(files)}, уже проверено {len(state)}; монет 2h {len(F['2h'])}, 4h {len(F['4h'])}", flush=True)
    for nfile, f in enumerate(files):
        key = f.parent.name + "/" + f.name
        if key in state:
            continue
        rec = {"name": f.name}
        try:
            _FAILS["n"] = 0
            code = pine_transpiler.transpile(f.read_text(encoding="utf-8", errors="replace"))
            rec["fails"] = _FAILS["n"]
            ns: dict = {"_BAD_": float("nan")}
            exec(compile(code, key, "exec"), ns)
            run = ns["run"]
        except Exception as exc:  # noqa: BLE001
            rec["err"] = "перевод: " + str(exc)[:100]; state[key] = rec; continue
        t0s = time.time()
        for tf, lst in F.items():
            per = {2: [], 3: []}; pos = {2: 0, 3: 0}; nsig = 0; bad = None
            for s, df, t, atr in lst:
                try:
                    r = run(df.copy(), {})
                    ent, nl, nsh = entries(r.get("signals", {}), len(df))
                except Exception as exc:  # noqa: BLE001
                    bad = "расчёт: " + str(exc)[:100]; break
                if nl + nsh == 0:
                    bad = "нет сигналов buy/sell в заголовках"; break
                nsig += int((ent != 0).sum())
                c, h, l = df.close.values, df.high.values, df.low.values
                for tp in (2, 3):
                    tr = sim(t, c, h, l, atr, ent, tp); per[tp] += tr; pos[tp] += sum(x for _t, x in tr) > 0
                if time.time() - t0s > 240:
                    bad = "слишком долго"; break
            if bad:
                rec["err"] = bad; break
            mid = (min(int(x[2][0]) for x in lst) + now) // 2
            for tp in (2, 3):
                al = per[tp]
                if not al:
                    continue
                tot = sum(x for _t, x in al); h1 = sum(x for tt, x in al if tt < mid); w180 = sum(x for tt, x in al if tt >= now - 180 * 86400_000)
                rec[f"{tf}_tp{tp}"] = [len(al), round(tot / len(al), 4), round(tot, 1), round(h1, 1), round(tot - h1, 1), round(w180, 1), pos[tp], len(lst)]
        state[key] = rec
        if nfile % 5 == 0:
            STATE.write_text(json.dumps(state, ensure_ascii=False, default=float), encoding="utf-8")
            print(f"{nfile}/{len(files)} {f.name[:50]} → {rec.get('err') or 'ок'}", flush=True)
    STATE.write_text(json.dumps(state, ensure_ascii=False, default=float), encoding="utf-8")

    def ok(v):
        return v and v[0] >= 100 and v[3] > 0 and v[4] > 0 and v[5] > 0 and v[6] >= 8 and v[1] >= 0.03
    lines = []; nerr = sum(1 for r in state.values() if "err" in r)
    lines.append(f"Скриптов {len(state)}: не перевелись/без сигналов {nerr}, посчитано {len(state) - nerr} (из них чистый перевод {sum(1 for r in state.values() if 'err' not in r and not r.get('fails'))})")
    from collections import Counter  # noqa: PLC0415
    lines.append("Причины отсева: " + "; ".join(f"{a} ×{b}" for a, b in Counter((r.get('err') or '')[:40] for r in state.values() if 'err' in r).most_common(6)))
    rows = []
    for k, r in state.items():
        for tp in (2, 3):
            a, b = r.get(f"2h_tp{tp}"), r.get(f"4h_tp{tp}")
            if ok(a) or ok(b):
                rows.append((("НАДЁЖНЫЙ" if ok(a) and ok(b) else "один ТФ") + ("" if not r.get("fails") else f" (частичный перевод, {r['fails']} пропусков)"), k, tp, a, b))
    rows.sort(key=lambda x: (not x[0].startswith("НАДЁЖНЫЙ"), "частичн" in x[0], -max((x[3] or [0, 0])[1], (x[4] or [0, 0])[1])))
    lines.append("сорт · скрипт · тейк · 2h [сд, R/сд, всё, 1пол, 2пол, 180д, монет+] · 4h [...]")
    for row in rows:
        lines.append(f"{row[0]:<9} {row[1][:70]:<70} {row[2]}R · 2h {row[3]} · 4h {row[4]}")
    (BASE / "bt_lab_bots" / "pine_batch.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines[:60])); print("готово")


if __name__ == "__main__":
    main()
