"""chan_protect_test.py — 2026-10-26. Пробой канала 100 (вход по закрытию, стоп у центра, тейк 2R) + ЗАЩИТА сделки.
Вопрос: оживает ли 1h (и улучшаются ли 2h/4h), если добавить безубыток или трейлинг.
Варианты:
  нет        — как сейчас
  БУ +1R     — при +1R стоп в БУ (+0.1R)
  умный БУ   — после +1R, если свеча закрылась обратно за EMA20 → стоп в БУ (+0.1R) (как в боте 4h)
  трейл ATR  — после +1R стоп тянется за ценой закрытия на 2×ATR14, тейк 2R остаётся
  ATR б/тейка— то же, но без тейка (даём тренду бежать, максимум 100 свечей)
  трейл центр— после +1R стоп тянется за центром канала, тейк 2R остаётся
Свечи: те же кеши, что у chan_recent_test (OKX 0.05%, Bybit 0.055% и 0.09%), 12 монет, ~3 года.
✅ = за 3 года плюс, обе половины плюс, ≥ 8/12 монет; и отдельно — свежие 3/6/10 мес.
Ничего не торгует. Запуск: chan_protect_test.bat → bt_lab_bots/chan_protect_test.txt
"""
from __future__ import annotations
import pickle, sys, time
from pathlib import Path
import numpy as np
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
OUT = BASE / "bt_lab_bots" / "chan_protect_hh.txt"   # 2026-11-03: Hash Hedge — taker 0.03%, maker 0.01%
OKX_CACHE = BASE / "market_cache" / "okx_1h_3y_12coins.pkl"
BYB_CACHE = BASE / "market_cache" / "bybit_1h_3y_12coins.pkl"
N, RR, MAXBARS = 100, 2.0, 100
VARIANTS = ["нет", "БУ +1R", "умный БУ", "трейл ATR", "ATR б/тейка", "трейл центр"]
WINDOWS = [3, 6, 10]
LINES = []
def say(s=""):
    print(s, flush=True); LINES.append(s)

def rs(d, ms):
    b = (np.asarray(d["t"]) // ms).astype(np.int64)
    cut = np.r_[0, np.flatnonzero(np.diff(b)) + 1]
    end = np.r_[cut[1:] - 1, len(b) - 1]
    return {"t": np.asarray(d["t"])[cut], "h": np.maximum.reduceat(np.asarray(d["h"], float), cut),
            "l": np.minimum.reduceat(np.asarray(d["l"], float), cut), "c": np.asarray(d["c"], float)[end]}

def channel(c):
    n = len(c); x = np.arange(n, dtype=float)
    cs = lambda a: np.r_[0.0, np.cumsum(a)]  # noqa: E731
    Sy, Sxy, Syy = cs(c), cs(c * x), cs(c * c)
    sx = N * (N - 1) / 2; sxx = (N - 1) * N * (2 * N - 1) / 6; varx = sxx - sx * sx / N
    mid = np.full(n, np.nan); sd = np.full(n, np.nan)
    i = np.arange(N - 1, n); s0 = i - N + 1
    sy = Sy[i + 1] - Sy[s0]; sxy = (Sxy[i + 1] - Sxy[s0]) - s0 * sy; syy = Syy[i + 1] - Syy[s0]
    b = (sxy - sx * sy / N) / varx; a = sy / N - b * sx / N
    mid[i] = a + b * (N - 1)
    sd[i] = np.sqrt(np.maximum(syy - sy * sy / N - b * (sxy - sx * sy / N), 0) / N)
    return mid, mid + 2 * sd, mid - 2 * sd

def ema(c, n=20):
    out = np.empty_like(c); k = 2 / (n + 1); out[0] = c[0]
    for i in range(1, len(c)):
        out[i] = out[i - 1] + k * (c[i] - out[i - 1])
    return out

def atr(h, l, c, n=14):
    pc = np.r_[c[0], c[:-1]]
    tr = np.maximum(h - l, np.maximum(abs(h - pc), abs(l - pc)))
    out = np.empty_like(tr); out[0] = tr[0]
    for i in range(1, len(tr)):
        out[i] = out[i - 1] + (tr[i] - out[i - 1]) / n
    return out

def trades(d, variant, fee):
    t, h, l, c = d["t"], d["h"], d["l"], d["c"]
    n = len(c)
    if n < N + 50:
        return []
    mid, up, lo = channel(c); e20 = ema(c); a14 = atr(h, l, c)
    out, k = [], N
    use_tp = variant != "ATR б/тейка"
    while k < n:
        side = 1 if (c[k] > up[k] and c[k - 1] <= up[k - 1]) else -1 if (c[k] < lo[k] and c[k - 1] >= lo[k - 1]) else 0
        if not side or np.isnan(mid[k]):
            k += 1; continue
        e = c[k]; risk = abs(e - mid[k])
        if risk <= 0:
            k += 1; continue
        sl, tp = e - side * risk, e + side * RR * risk
        armed = moved = False; r = None; j = k + 1
        while j < n and j <= k + MAXBARS:
            if (l[j] <= sl) if side > 0 else (h[j] >= sl):
                r = side * (sl - e) / risk; break
            if use_tp and ((h[j] >= tp) if side > 0 else (l[j] <= tp)):
                r = RR; break
            if not armed and ((h[j] >= e + risk) if side > 0 else (l[j] <= e - risk)):
                armed = True
            if armed:  # перенос стопа по закрытию свечи j (действует со следующей свечи)
                be = e + side * 0.1 * risk
                if variant == "БУ +1R" and not moved:
                    sl = be; moved = True
                elif variant == "умный БУ" and not moved and ((c[j] < e20[j]) if side > 0 else (c[j] > e20[j])):
                    sl = be; moved = True
                elif variant in ("трейл ATR", "ATR б/тейка"):
                    cand = c[j] - side * 2 * a14[j]
                    sl = max(sl, cand) if side > 0 else min(sl, cand)
                elif variant == "трейл центр" and not np.isnan(mid[j]):
                    sl = max(sl, mid[j]) if side > 0 else min(sl, mid[j])
            j += 1
        if r is None:
            j = min(j, n - 1); r = side * (c[j] - e) / risk
        out.append((t[k], r - 2 * fee * e / risk))
        k = j + 1
    return out

def load(p):
    raw = pickle.loads(p.read_bytes()) if p.exists() else {}
    return {s: d for s, d in raw.items() if len(d["c"]) >= 3000}

def report(title, raw, fee, tfs=(1, 2, 4)):
    now = max(int(d["t"][-1]) for d in raw.values())
    say(""); say(f"=== {title} · комиссия {fee * 100:.3f}% · монет {len(raw)} ===")
    say(f"{'ТФ':<4}{'защита':<13}{'3 года R':>9}{'1-я':>8}{'2-я':>8}{'монет+':>8}"
        + "".join(f"{f'{m} мес':>9}" for m in WINDOWS) + f"{'монет+6м':>10}{'винрейт':>9}  итог")
    for k in tfs:
        data = {s: (rs(d, k * 3600_000) if k > 1 else {kk: np.asarray(v, float) if kk != "t" else np.asarray(v)
                for kk, v in d.items() if kk in ("t", "h", "l", "c")}) for s, d in raw.items()}
        for v in VARIANTS:
            tot = h1 = h2 = 0.0; plus = 0; win = []; wins = {m: 0.0 for m in WINDOWS}; plus6 = 0
            for s, d in data.items():
                tr = trades(d, v, fee)
                if not tr:
                    continue
                mt = d["t"][len(d["t"]) // 2]
                rr = [x[1] for x in tr]; tot += sum(rr); win += rr; plus += sum(rr) > 0
                h1 += sum(x[1] for x in tr if x[0] < mt); h2 += sum(x[1] for x in tr if x[0] >= mt)
                for m in WINDOWS:
                    wins[m] += sum(x[1] for x in tr if x[0] >= now - m * 30.4 * 864e5)
                plus6 += sum(x[1] for x in tr if x[0] >= now - 6 * 30.4 * 864e5) > 0
            ok = tot > 0 and h1 > 0 and h2 > 0 and plus >= 8
            fresh = wins[6] > 0 and wins[10] > 0 and plus6 >= 7
            mark = ("✅" if ok else "❌") + (" свежий ✅" if fresh else " свежий ❌")
            wr = np.mean(np.array(win) > 0) * 100 if win else 0
            say(f"{str(k) + 'h':<4}{v:<13}{tot:>+9.1f}{h1:>+8.1f}{h2:>+8.1f}{f'{plus}/{len(data)}':>8}"
                + "".join(f"{wins[m]:>+9.1f}" for m in WINDOWS) + f"{f'{plus6}/{len(data)}':>10}{wr:>8.0f}%  {mark}")
        say("")

def main():
    t0 = time.time()
    say(f"Пробой канала 100 · 2R · стоп центр + защита сделки · {time.strftime('%Y-%m-%d %H:%M')}")
    say("R — в рисках на сделку, сумма по 12 монетам. «свежий ✅» = плюс за 6 и 10 мес и ≥ 7/12 монет за 6 мес.")
    okx, byb = load(OKX_CACHE), load(BYB_CACHE)
    if not okx and not byb:
        say("Нет кешей свечей — сначала запусти chan_recent_test.bat (он их скачает)."); return
    if byb:
        report("Hash Hedge · вход/стоп рынком (taker 0.03%)", byb, 0.0003)
        report("Hash Hedge · тейк лимиткой (≈ средняя 0.02%)", byb, 0.0002)
    say("Как читать: защита полезна, если поднимает и 3 года, и свежий период, и число монет в плюсе.")
    say("Включать 1h обратно — только если у какого-то варианта и «✅», и «свежий ✅» на OKX и Bybit.")
    say(f"Время расчёта: {time.time() - t0:.0f} с")
    OUT.parent.mkdir(exist_ok=True); OUT.write_text("\n".join(LINES), encoding="utf-8"); print(f"\nОтчёт: {OUT}")

if __name__ == "__main__":
    main()
