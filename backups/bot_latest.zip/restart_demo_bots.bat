@echo off
REM 2026-10-25: perezapusk TOLKO demo-kopiy (processy s --demo). Realnye boty ne trogayutsya.
cd /d D:\VANTORIX\bot
echo === Ostanavlivayu demo-botov ===
powershell -NoProfile -Command "$ps=@(Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -match '--demo' -and $_.CommandLine -match 'latuserge_live|kc_roc_cci_wt_grid_live' }); foreach($p in $ps){ & taskkill /PID $p.ProcessId /T /F *>$null }; Write-Host ('  ostanovleno: ' + $ps.Count)"
timeout /t 3 /nobreak >nul
del /q .latuserge_demo.lock 2>nul
del /q .kc_roc_demo.lock 2>nul
echo === Zapuskayu demo-botov ===
call start_demo_bots.bat
