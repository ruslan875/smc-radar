Сюда экспорт канала Dragonfly из Telegram Desktop
