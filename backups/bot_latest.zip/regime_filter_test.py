import pandas as pd,numpy as np,glob,os
D='/mnt/user-data/uploads/VANTORIX/bot/market_cache_tf/'
def ld(f):
    d=pd.read_csv(f);d['t']=pd.to_datetime(d.t,unit='ms');return d.set_index('t')
def atr(d,n=14):
    tr=pd.concat([d.h-d.l,(d.h-d.c.shift()).abs(),(d.l-d.c.shift()).abs()],axis=1).max(axis=1);return tr.ewm(alpha=1/n).mean()
def adx(d,n=14):
    up=d.h.diff();dn=-d.l.diff();pdm=np.where((up>dn)&(up>0),up,0);ndm=np.where((dn>up)&(dn>0),dn,0)
    a=atr(d,n);p=100*pd.Series(pdm,d.index).ewm(alpha=1/n).mean()/a;m=100*pd.Series(ndm,d.index).ewm(alpha=1/n).mean()/a
    return (100*(p-m).abs()/(p+m)).ewm(alpha=1/n).mean()
b=ld(D+'BTCUSDT_4h.csv');R=pd.DataFrame(index=b.index)
R['bt']=np.sign(b.c.ewm(span=50).mean()-b.c.ewm(span=200).mean());R['adx']=adx(b)
R['atrp']=atr(b)/b.c*100
def sim(d,N,X,strat):
    a=atr(d);hi=d.h.rolling(N).max().shift();lo=d.l.rolling(N).min().shift()
    xh=d.h.rolling(X).max().shift();xl=d.l.rolling(X).min().shift()
    e50=d.c.ewm(span=50).mean();e200=d.c.ewm(span=200).mean()
    out=[];pos=0
    c=d.c.values;h=d.h.values;l=d.l.values;A=a.values
    for i in range(210,len(d)):
        if pos:
            if pos==1:
                ex=None
                if l[i]<=sl: ex=sl
                elif c[i]<xl.iloc[i]: ex=c[i]
            else:
                ex=None
                if h[i]>=sl: ex=sl
                elif c[i]>xh.iloc[i]: ex=c[i]
            if ex is not None:
                r=(ex-en)*pos/risk-0.0011*en/risk; out.append((d.index[ei],pos,r,coin_tr));pos=0
            continue
        s=1 if c[i]>hi.iloc[i] else -1 if c[i]<lo.iloc[i] else 0
        if s:
            pos=s;en=c[i];risk=2*A[i];sl=en-s*risk;ei=i;coin_tr=np.sign(e50.iloc[i]-e200.iloc[i])
    return out
rows=[]
for f in sorted(glob.glob(D+'*_4h.csv')):
    sym=os.path.basename(f)[:-7];d=ld(f)
    for name,N,X in [('donch20',20,10),('chan55',55,20)]:
        for t,s,r,ct in sim(d,N,X,name): rows.append((name,sym,t,s,r,ct))
T=pd.DataFrame(rows,columns=['st','sym','t','side','r','ctr']).sort_values('t')
T=T.join(R,on='t')
F={'без фильтра':lambda x:x.r==x.r,
 'по тренду BTC':lambda x:x.side==x.bt,
 'ADX BTC>20':lambda x:x.adx>20,
 'тренд BTC + ADX>20':lambda x:(x.side==x.bt)&(x.adx>20),
 'по тренду монеты':lambda x:x.side==x.ctr,
 'против тренда BTC (контроль)':lambda x:x.side!=x.bt}
def dd(r):
    c=r.cumsum();return (c-c.cummax()).min()
lines=[]
for st in ['donch20','chan55']:
    S=T[T.st==st];lines.append(f'\n=== {st} (4h, 12 монет, {S.t.min():%Y-%m} … {S.t.max():%Y-%m}) ===')
    lines.append(f"{'фильтр':30}{'сделок':>7}{'R/сд':>7}{'всего R':>9}{'просадка':>9}{'R/сд до 2023':>13}{'R/сд 2023+':>11}{'R/сд 2025+':>11}")
    for k,fn in F.items():
        x=S[fn(S)];a=x[x.t<'2023'];bq=x[x.t>='2023'];c=x[x.t>='2025']
        lines.append(f"{k:30}{len(x):7}{x.r.mean():7.3f}{x.r.sum():9.0f}{dd(x.r):9.0f}{a.r.mean():13.3f}{bq.r.mean():11.3f}{c.r.mean():11.3f}")
print('\n'.join(lines))
