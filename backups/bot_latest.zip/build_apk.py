"""build_apk.py — 2026-11-02. Сборка APK TRADEOS прямо на ПК, без Android Studio и без Gradle.
Шаги (каждый пропускается, если уже сделан):
  1) JDK 17 (Microsoft OpenJDK zip) → D:\\VANTORIX\\mobile\\tools\\jdk
  2) Android command-line tools → tools\\android-sdk\\cmdline-tools\\latest
  3) sdkmanager: build-tools;34.0.0 и platforms;android-34 (лицензии принимаются автоматически)
  4) javac → d8 (dex) → aapt2 (ресурсы+манифест) → zipalign → apksigner (свой ключ, создаётся один раз)
Результат: D:\\VANTORIX\\mobile\\TRADEOS.apk (+ копия для автообновления в bot\\mobile\\www\\app.apk)."""
import os, sys, shutil, subprocess, zipfile, time, urllib.request, glob, json
from pathlib import Path

BOT = Path(__file__).resolve().parent
MOB = BOT.parent / "mobile"
TOOLS = MOB / "tools"; SDK = TOOLS / "android-sdk"; PRJ = MOB / "android"; OUT = MOB / "build"
BT = "34.0.0"; PLAT = "android-34"

def log(*a):
    print(time.strftime("%H:%M:%S"), *a, flush=True)

def dl(url, dst):
    dst = Path(dst); dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists() and dst.stat().st_size > 1_000_000:
        log("уже скачано:", dst.name); return dst
    log("скачиваю", url)
    tmp = dst.with_suffix(".part")
    for attempt in range(5):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=60) as r, open(tmp, "wb") as f:
                total = int(r.headers.get("Content-Length") or 0); got = 0; last = 0
                while True:
                    ch = r.read(1 << 20)
                    if not ch: break
                    f.write(ch); got += len(ch)
                    if got - last > 20 << 20:
                        last = got; log(f"  {got >> 20} МБ" + (f" из {total >> 20} МБ" if total else ""))
            tmp.replace(dst); log("готово:", dst.name, dst.stat().st_size >> 20, "МБ"); return dst
        except Exception as e:
            log(f"  ошибка ({attempt + 1}/5): {e}"); time.sleep(5 * (attempt + 1))
    raise SystemExit("не удалось скачать " + url)

def unzip(z, to):
    log("распаковываю", Path(z).name); to = Path(to); to.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(z) as zf: zf.extractall(to)

def run(cmd, **kw):
    log("$", " ".join(str(c) for c in cmd)[:300])
    r = subprocess.run([str(c) for c in cmd], capture_output=True, text=True, encoding="utf-8", errors="replace", **kw)
    out = (r.stdout + r.stderr).strip()
    if out: print(out[-3000:], flush=True)
    if r.returncode != 0: raise SystemExit(f"команда завершилась с ошибкой {r.returncode}")
    return out

# ---------- 1. JDK ----------
def jdk_home():
    for p in sorted(TOOLS.glob("jdk/*/bin/javac.exe")):
        return p.parent.parent
    return None
if not jdk_home():
    z = dl("https://aka.ms/download-jdk/microsoft-jdk-17-windows-x64.zip", TOOLS / "dl" / "jdk17.zip")
    unzip(z, TOOLS / "jdk")
JH = jdk_home(); log("JDK:", JH)
env = dict(os.environ, JAVA_HOME=str(JH), PATH=str(JH / "bin") + os.pathsep + os.environ.get("PATH", ""))

# ---------- 2. cmdline-tools ----------
SM = SDK / "cmdline-tools" / "latest" / "bin" / "sdkmanager.bat"
if not SM.exists():
    z = dl("https://dl.google.com/android/repository/commandlinetools-win-11076708_latest.zip", TOOLS / "dl" / "cmdtools.zip")
    unzip(z, TOOLS / "ct_tmp")
    (SDK / "cmdline-tools").mkdir(parents=True, exist_ok=True)
    if (SDK / "cmdline-tools" / "latest").exists(): shutil.rmtree(SDK / "cmdline-tools" / "latest")
    shutil.move(str(TOOLS / "ct_tmp" / "cmdline-tools"), str(SDK / "cmdline-tools" / "latest"))
    shutil.rmtree(TOOLS / "ct_tmp", ignore_errors=True)

# ---------- 3. build-tools + platform ----------
BTD = SDK / "build-tools" / BT; AJ = SDK / "platforms" / PLAT / "android.jar"
if not (BTD / "aapt2.exe").exists() or not AJ.exists():
    log("sdkmanager: лицензии и пакеты (несколько минут)…")
    p = subprocess.run([str(SM), f"--sdk_root={SDK}", "--licenses"], input="y\n" * 30, capture_output=True, text=True, env=env)
    log("лицензии:", (p.stdout or "")[-200:].strip())
    run([SM, f"--sdk_root={SDK}", f"build-tools;{BT}", f"platforms;{PLAT}"], env=env, input="y\n" * 10)
log("SDK готов")

# ---------- 4. сборка ----------
if OUT.exists(): shutil.rmtree(OUT)
(OUT / "classes").mkdir(parents=True); (OUT / "dex").mkdir(); (OUT / "res").mkdir()
srcs = [str(p) for p in PRJ.glob("src/**/*.java")]
run([JH / "bin" / "javac.exe", "-encoding", "UTF-8", "-source", "8", "-target", "8", "-nowarn", "-classpath", AJ, "-d", OUT / "classes", *srcs], env=env)
classes = [str(p) for p in (OUT / "classes").rglob("*.class")]
run([BTD / "d8.bat", "--release", "--min-api", "24", "--lib", AJ, "--output", OUT / "dex", *classes], env=env)
run([BTD / "aapt2.exe", "compile", "--dir", PRJ / "res", "-o", OUT / "res.zip"])
run([BTD / "aapt2.exe", "link", "-o", OUT / "base.apk", "-I", AJ, "--manifest", PRJ / "AndroidManifest.xml",
     "-A", PRJ / "assets", "--min-sdk-version", "24", "--target-sdk-version", "34", OUT / "res.zip"])
with zipfile.ZipFile(OUT / "base.apk", "a", zipfile.ZIP_DEFLATED) as z:
    z.write(OUT / "dex" / "classes.dex", "classes.dex")
run([BTD / "zipalign.exe", "-f", "-p", "4", OUT / "base.apk", OUT / "aligned.apk"])
KS = MOB / "tradeos-release.jks"          # ключ подписи: создаётся один раз, хранить! (без него обновления не встанут поверх)
if not KS.exists():
    run([JH / "bin" / "keytool.exe", "-genkeypair", "-keystore", KS, "-alias", "tradeos", "-keyalg", "RSA", "-keysize", "2048",
         "-validity", "10000", "-storepass", "tradeos-local", "-keypass", "tradeos-local", "-dname", "CN=TRADEOS, O=Personal, C=XX"], env=env)
final = MOB / "TRADEOS.apk"
run([BTD / "apksigner.bat", "sign", "--ks", KS, "--ks-pass", "pass:tradeos-local", "--key-pass", "pass:tradeos-local",
     "--out", final, OUT / "aligned.apk"], env=env)
run([BTD / "apksigner.bat", "verify", final], env=env)
www = BOT / "mobile" / "www"; www.mkdir(parents=True, exist_ok=True)
shutil.copy2(final, www / "app.apk")
ver = 1
try:
    import re
    ver = int(re.search(r"APP_VERSION = (\d+)", (PRJ / "src/com/tradeos/app/MainActivity.java").read_text(encoding="utf-8")).group(1))
except Exception: pass
(www / "version.json").write_text(json.dumps({"apk": ver, "url": "/m/app.apk", "built": time.strftime("%Y-%m-%d %H:%M")}), encoding="utf-8")
log(f"✅ ГОТОВО: {final}  ({final.stat().st_size >> 10} КБ), версия {ver}")
