# DGL (Distribution-Gated Ladder Grid) — порт на Python, честный тест. Настройки как на скриншоте.
import sys, glob, os, numpy as np, pandas as pd
C=sys.argv[1]; TF=sys.argv[2] if len(sys.argv)>2 else '1h'
W,HB,EP,TP_,K,EMA=21,1500,1.0,1.0,0.85,200; NL=[2,4,5,7]; SR,PG,MG=0.3,0.4,0.65; EXP,SLM,SPK=100,1.0,2.2; FEE=0.0005+0.0002
def load(p):
    d=pd.read_csv(p); d.index=pd.to_datetime(d.t,unit='ms'); d=d[['o','h','l','c']].astype(float)
    return d if TF=='1h' else d.resample(TF).agg({'o':'first','h':'max','l':'min','c':'last'}).dropna()
def run(d):
    c=d.c; ret=c/c.shift(W)-1
    rank=ret.rolling(HB).rank(pct=True)*100; med=ret.abs().rolling(HB).median()
    qlo=ret.rolling(HB).quantile(TP_/100); qhi=ret.rolling(HB).quantile(1-TP_/100)
    tr=pd.concat([d.h-d.l,(d.h-c.shift()).abs(),(d.l-c.shift()).abs()],axis=1).max(axis=1)
    a14=tr.ewm(alpha=1/14,adjust=False).mean(); a100=tr.ewm(alpha=1/100,adjust=False).mean(); ema=c.ewm(span=EMA,adjust=False).mean()
    O,H,L,Cc=d.o.values,d.h.values,d.l.values,c.values; R,M,QL,QH,A,S,E_=ret.values,rank.values,qlo.values,qhi.values,a14.values,(a14/a100).values,ema.values
    eq=10000.0; peak=eq; mdd=0; res=[]; i=HB+W+1; n=len(Cc)
    while i<n-1:
        sg=0
        if not np.isnan(M[i]) and S[i]<=SPK:
            if R[i]<0 and M[i]<=EP and Cc[i]>E_[i]: sg=1
            elif R[i]>0 and M[i]>=100-EP and Cc[i]<E_[i]: sg=-1
        if not sg: i+=1; continue

        p0=K*Cc[i]*Mabs[i]; reach=abs(QL[i] if sg==1 else QH[i])*Cc[i]
        units=1+sum(1+x*SR for x in NL); lot0=eq*EXP/100/Cc[i]/units
        lv=[];tps=[p0];sl_=lot0;acc=0;pd_=0
        for k,x in enumerate(NL,1):
            ln=lot0*(1+x*SR); s2=sl_+ln; pn=p0*(1+PG*k); dn=(pn*s2-acc)/(2*ln)
            if dn<pd_+MG*p0: dn=pd_+MG*p0; pn=(acc+2*ln*dn)/s2
            if dn>reach: break
            sl_=s2; acc+=ln*dn; pd_=dn; lv.append((Cc[i]-sg*dn,ln)); tps.append(pn)
        stop=Cc[i]-sg*(pd_+SLM*A[i])
        e0=O[i+1]; q=lot0; cost=lot0*e0; fees=cost*FEE; filled=0; pnl=None
        for j in range(i+1,min(n,i+1+W)):
            for (px,ln) in lv[filled:]:
                if (sg==1 and L[j]<=px) or (sg==-1 and H[j]>=px): q+=ln; cost+=ln*px; fees+=ln*px*FEE; filled+=1
                else: break
            avg=cost/q; tp=avg+sg*tps[min(filled,len(tps)-1)]
            adv=L[j] if sg==1 else H[j]; mdd=max(mdd,(peak-(eq+sg*q*(adv-avg)))/peak*100)
            if (sg==1 and L[j]<=stop) or (sg==-1 and H[j]>=stop): pnl=sg*q*(stop-avg); why='SL'; break
            if (sg==1 and H[j]>=tp) or (sg==-1 and L[j]<=tp): pnl=sg*q*(tp-avg); why='TP'; break
        if pnl is None: pnl=sg*q*(Cc[j]-avg); why='EXP'
        fees+=q*abs(avg)*FEE; eq+=pnl-fees; peak=max(peak,eq); res.append((d.index[i],(pnl-fees),why,filled)); i=j+1
    return eq,mdd,pd.DataFrame(res,columns=['t','p','why','n'])
for f in sorted(glob.glob(os.path.join(C,'binance','*_1h.csv'))):
    d=load(f); c=d.c; globals()['Mabs']=(c/c.shift(W)-1).abs().rolling(HB).median().values
    eq,mdd,t=run(d); mid=d.index[0]+(d.index[-1]-d.index[0])/2
    if t.empty: print(os.path.basename(f)[:-7],'нет сделок'); continue
    pf=t.p[t.p>0].sum()/max(-t.p[t.p<0].sum(),1e-9)
    print(f"{os.path.basename(f)[:-7]:9} сделок {len(t):4} итог {eq/100-100:+7.1f}%  DD {mdd:5.1f}%  PF {pf:.2f}  в плюсе {100*(t.p>0).mean():.0f}%  H1 {t[t.t<mid].p.sum():+7.0f}$ H2 {t[t.t>=mid].p.sum():+7.0f}$  {dict(t.why.value_counts())}")
