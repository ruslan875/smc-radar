#!/usr/bin/env python3
"""
Fee-aware, no-lookahead backtester for the THIRD Veles Finance bot seen
this round: share code DcHGj, named in Veles' own UI "SOL | #SURVIVE1010
| VOLGOFLINT" -- i.e. a DIFFERENT SURVIVE1010 contest entrant (Volgoflint,
not Влад) than kc_roc_cci_wt_grid_backtest.py's bot or
cci_rsi_wr_signal_grid_backtest.py's (Влад/XWvCF). Do not confuse the
three -- this one is architecturally very different: 6 confluence entry
filters across 3 timeframes, but only ONE order (no averaging grid at
all), exiting on a Parabolic SAR trend-flip signal + a minimum-P&L floor,
with no stop-loss whatsoever.

Read directly off the live Veles "Создание бота" page via the
Claude-in-Chrome extension (DOM text + input values, not screenshots --
more reliable than eyeballing screenshots, which is how the two prior
scripts' numbers were read).

CONFIRMED from the live page (DOM values, not guessed):
  - LONG only, SOL/USDT, 2x leverage, cross margin, reinvest OFF.
  - Условия открытия сделки -- 6 filters, presumably ALL must be true
    (edge-triggered, same convention as this project's other multi-filter
    entries; Veles doesn't expose AND/OR choice in what was inspected):
      Filter 1: Полосы Боллинджера (Bollinger Bands), 1m,  на закрытии бара
      Filter 2: ROC,                                   5m,  на закрытии бара, Меньше -0.75
      Filter 3: ATR%,                                  1m,  на закрытии бара, Больше 0.3
      Filter 4: ADX,                                   1m,  на закрытии бара, Больше 25
      Filter 5: ADX,                                   5m,  на закрытии бара, Больше 20
      Filter 6: Канал Дончиана (Donchian Channel),     1h,  на закрытии бара
    Filters 1, 6 (Bollinger, Donchian) render with NO separate
    Меньше/Больше+value row in the DOM -- confirmed absent, not just
    unread -- so whatever condition they express is baked into the
    indicator/type choice itself, not a plain threshold. See ASSUMED
    below for how this script fills that gap.
  - Ордера сделки: режим "Свой" (Custom, confirmed via the highlighted
    tab), only 1/40 orders configured -- 0% offset, 100% volume. NO
    averaging grid at all (unlike Влад's XWvCF bot). "Подтяжка сетки"
    0.1% is irrelevant with a single order. "Остановить бота после
    завершения сделок" and "Включать позицию на бирже в сделку": both
    OFF (confirmed via toggle color, not the DOM's misleading
    value="on" attribute every checkbox carries regardless of state --
    see the note in this project's chat log about that gotcha).
  - Выход из сделки: Тейк-профит режим "Сигнал" (confirmed highlighted),
    Filter 1 = Смена тренда SAR (Parabolic SAR trend flip), 1m, на
    закрытии бара -- also renders with no separate threshold row (a
    trend-flip is inherently a crossover event, not a level). Валюта
    профита USDT. Минимальный P&L: 0.5%. All three stop-loss toggles
    (СТОП-ЛОСС, СТОП-ЛОСС ПО СИГНАЛУ, ОСТАНОВИТЬ БОТА ПОСЛЕ...):
    confirmed OFF by toggle color.

ASSUMED (Veles' UI genuinely doesn't expose these anywhere that was
inspected -- override via CLI flags):
  - Bollinger Bands condition/direction: defaults to "close BELOW the
    lower band" (--bb-condition below|above), paired with length 20 /
    mult 2.0 (--bb-length, --bb-mult, standard TradingView defaults).
    Reasoned from the surrounding filters (ROC already deeply negative,
    ATR%/ADX both elevated) reading like a sharp-pullback-within-a-
    strong-move setup, not a breakout -- but this is inference, not a
    read value.
  - Donchian Channel condition/direction: defaults to "close AT/BELOW
    the channel's own lowest low" (--donchian-condition below|above),
    length 20 on the confirmed 1h interval (--donchian-length). Same
    reasoning as Bollinger -- could just as easily be the opposite
    (breakout above), hence the flag.
  - ROC length (--roc-length, default 9), ATR% length (--atr-length,
    default 14), ADX di-length/smoothing (--adx-di-length,
    --adx-smoothing, default 14/14 for both the 1m and 5m ADX filters):
    Veles never exposed a period field in what was inspected -- these
    are the standard/TradingView-default periods, not confirmed
    Veles-specific values.
  - Parabolic SAR parameters (--sar-af-start/--sar-af-step/--sar-af-max,
    default 0.02/0.02/0.2): Wilder's original defaults, which is almost
    certainly what "Смена тренда SAR" uses under the hood, but Veles
    never showed a parameters panel for it in what was inspected.

No stop-loss, no grid, no pull-up ambiguity this time (single order) --
this is a structurally simpler bot than the other two, just with far
more entry filters.

Needs network access to Bybit's public API -- run on your own machine:

    python bb_roc_atr_adx_donchian_sar_backtest.py --symbol SOLUSDT --bars 200000
"""
from __future__ import annotations

import argparse
import csv
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np
import pandas as pd
import requests

from app.data import BYBIT_BASE, INTERVAL_MAP, DataError
from app.indicators.common import sma, stdev, atr, dmi_adx
from app.indicators.veles_style import rate_of_change, atr_percent, htf_closed_series

# CONFIRMED 2026-09-04 from real account fee screenshots (both exchanges,
# futures only -- this account does not trade spot). Round-trip rates
# (entry+exit combined), replacing the old generic placeholder guess.
# Bybit futures, "Обычный пользователь" tier, 10% MNT discount currently
# ACTIVE: maker 0.0324%, taker 0.0900% per fill.
# OKX futures, "Обычные пользователи" tier, no discount toggle shown:
# maker 0.0200%, taker 0.0500% per fill.
FEE_SCENARIOS = {
    "bybit_taker+taker": 0.0018,
    "bybit_taker+maker": 0.001224,
    "bybit_maker+maker": 0.000648,
    "okx_taker+taker": 0.0010,
    "okx_taker+maker": 0.0007,
    "okx_maker+maker": 0.0004,
}


# --------------------------------------------------------------- data --

def _fetch_page(params: dict, symbol: str, retries: int = 4, timeout: float = 15.0) -> dict:
    # Hardened 2026-09-05 after a real incident: running a heavy multi-symbol
    # backtest at the same time as the live bot on the same API key hit
    # Bybit's rate limit ("Too many visits. Exceeded the API Rate Limit."),
    # which comes back as a normal HTTP 200 with retCode != 0 -- the original
    # code only retried on network exceptions, so a rate-limit hit raised
    # DataError immediately with zero retries. Now retries on retCode != 0
    # too, with the same backoff as network errors.
    last_exc: Exception | None = None
    for attempt in range(retries):
        try:
            resp = requests.get(f"{BYBIT_BASE}/v5/market/kline", params=params, timeout=timeout)
            resp.raise_for_status()
            payload = resp.json()
            if payload.get("retCode") == 0:
                return payload
            last_exc = RuntimeError(f"retCode={payload.get('retCode')} {payload.get('retMsg')}")
        except requests.RequestException as exc:
            last_exc = exc
        if attempt < retries - 1:
            time.sleep(1.5 * (attempt + 1))
    raise DataError(f"Bybit request failed for {symbol} after {retries} attempts: {last_exc}")


def fetch_history(symbol: str, timeframe: str, total_bars: int, category: str = "linear") -> pd.DataFrame:
    interval = INTERVAL_MAP[timeframe]
    all_rows: list = []
    end = None
    while len(all_rows) < total_bars:
        params = {"category": category, "symbol": symbol, "interval": interval, "limit": 1000}
        if end is not None:
            params["end"] = end
        payload = _fetch_page(params, symbol)
        if payload.get("retCode") != 0:
            raise DataError(f"Bybit API error for {symbol}: {payload.get('retMsg')}")
        rows = payload["result"]["list"]
        if not rows:
            break
        all_rows.extend(rows)
        oldest_ts = int(rows[-1][0])
        end = oldest_ts - 1
        if len(rows) < 1000:
            break
        time.sleep(0.6)

    if not all_rows:
        raise DataError(f"No kline data returned for {symbol} {timeframe}")

    df = pd.DataFrame(all_rows, columns=["open_time", "open", "high", "low", "close", "volume", "turnover"])
    df["open_time"] = df["open_time"].astype("int64")
    df = df.drop_duplicates(subset="open_time")
    for col in ("open", "high", "low", "close", "volume", "turnover"):
        df[col] = df[col].astype(float)
    df["open_time"] = pd.to_datetime(df["open_time"], unit="ms", utc=True)
    df = df.sort_values("open_time").reset_index(drop=True)
    if len(df) > total_bars:
        df = df.tail(total_bars).reset_index(drop=True)

    # Diagnostic added 2026-09-04: surface the real fetched date range and
    # flag any gaps in the candle series. Triggered by a real finding --
    # a run requesting the same --bars 200000 for six symbols produced a
    # ~139-day span for three (SUI/INJ/TIA, newer listings) but a ~345-day
    # span for the other three (ETH/SOL/ARB, deep history) despite an
    # identical bar count, implying non-contiguous/gappy data rather than
    # a genuine 200000-consecutive-minute window for the latter three.
    if len(df) > 1:
        step_seconds = df["open_time"].diff().dt.total_seconds()
        expected_step = step_seconds.median()
        max_gap = step_seconds.max()
        max_gap_idx = step_seconds.idxmax()
        span_days = (df["open_time"].iloc[-1] - df["open_time"].iloc[0]).days
        print(f"  [fetch_history] {symbol}: {len(df)} bars, "
              f"{df['open_time'].iloc[0]} -> {df['open_time'].iloc[-1]} "
              f"({span_days} days)")
        if pd.notna(max_gap) and max_gap > expected_step * 3:
            print(f"  [fetch_history] WARNING: {symbol} has a gap of "
                  f"{max_gap/60:.1f} min (expected ~{expected_step/60:.1f} min "
                  f"between bars) right before "
                  f"{df['open_time'].iloc[max_gap_idx]} -- data is likely "
                  f"NON-CONTIGUOUS, treat this run's results as unreliable "
                  f"until re-fetched.")
    return df


# ----------------------------------------------------------- indicators --

def bollinger_bands(close: pd.Series, length: int, mult: float) -> tuple[pd.Series, pd.Series, pd.Series]:
    basis = sma(close, length)
    dev = mult * stdev(close, length)
    return basis, basis + dev, basis - dev


def donchian_channel(df: pd.DataFrame, length: int) -> tuple[pd.Series, pd.Series]:
    upper = df["high"].rolling(length, min_periods=length).max()
    lower = df["low"].rolling(length, min_periods=length).min()
    return upper, lower


def parabolic_sar(df: pd.DataFrame, af_start: float, af_step: float, af_max: float) -> pd.Series:
    """Wilder's classic Parabolic SAR, hand-rolled (inherently recursive --
    each bar's SAR depends on the previous bar's state, so this can't be
    vectorized the way every other indicator in this project's
    common.py/veles_style.py is). Returns the SAR value series; use
    sar_bearish_flip() below for the trend-change signal this bot's
    take-profit actually gates on."""
    high = df["high"].to_numpy(dtype=float)
    low = df["low"].to_numpy(dtype=float)
    n = len(df)
    sar = np.full(n, np.nan)
    if n < 2:
        return pd.Series(sar, index=df.index)

    uptrend = df["close"].iloc[1] >= df["close"].iloc[0]
    af = af_start
    if uptrend:
        sar_val = low[0]
        ep = high[0]
    else:
        sar_val = high[0]
        ep = low[0]
    sar[0] = sar_val

    for i in range(1, n):
        prev_sar = sar_val
        sar_val = prev_sar + af * (ep - prev_sar)

        if uptrend:
            sar_val = min(sar_val, low[i - 1], low[i - 2] if i >= 2 else low[i - 1])
            if low[i] < sar_val:
                uptrend = False
                sar_val = ep
                ep = low[i]
                af = af_start
            else:
                if high[i] > ep:
                    ep = high[i]
                    af = min(af + af_step, af_max)
        else:
            sar_val = max(sar_val, high[i - 1], high[i - 2] if i >= 2 else high[i - 1])
            if high[i] > sar_val:
                uptrend = True
                sar_val = ep
                ep = high[i]
                af = af_start
            else:
                if low[i] < ep:
                    ep = low[i]
                    af = min(af + af_step, af_max)

        sar[i] = sar_val

    return pd.Series(sar, index=df.index)


def sar_bearish_flip(df: pd.DataFrame, af_start: float, af_step: float, af_max: float) -> pd.Series:
    """True on the bar where SAR flips from below price (uptrend) to
    above price (downtrend) -- "Смена тренда SAR" for a long exit."""
    sar = parabolic_sar(df, af_start, af_step, af_max)
    below = sar < df["close"]
    flip = below.shift(1).fillna(False) & ~below.fillna(False)
    return flip.fillna(False)


# ------------------------------------------------------------- params --

@dataclass
class Params:
    bb_length: int
    bb_mult: float
    bb_condition: str       # "below" | "above"
    roc_length: int
    atr_length: int
    adx_di_length: int
    adx_smoothing: int
    donchian_length: int
    donchian_condition: str  # "below" | "above"
    sar_af_start: float
    sar_af_step: float
    sar_af_max: float
    min_pnl_pct: float
    max_deal_bars: int


@dataclass
class Deal:
    symbol: str
    entry_time: pd.Timestamp
    exit_time: pd.Timestamp | None
    entry_price: float
    exit_price: float | None
    reason: str  # "TP" | "TIMEOUT" | "OPEN_AT_CUTOFF"
    bars_held: int
    gross_pnl_pct: float | None
    meta: dict = field(default_factory=dict)


def compute_indicators(df: pd.DataFrame, p: Params) -> dict:
    _, bb_upper, bb_lower = bollinger_bands(df["close"], p.bb_length, p.bb_mult)
    bb_cond = (df["close"] < bb_lower) if p.bb_condition == "below" else (df["close"] > bb_upper)

    roc_5m = htf_closed_series(df, 5, lambda h: rate_of_change(h["close"], p.roc_length))
    roc_cond = roc_5m < -0.75

    atr_pct_1m = atr_percent(df, p.atr_length)
    atr_cond = atr_pct_1m > 0.3

    adx_1m = dmi_adx(df, p.adx_di_length, p.adx_smoothing)
    adx_1m_cond = adx_1m > 25

    adx_5m = htf_closed_series(df, 5, lambda h: dmi_adx(h, p.adx_di_length, p.adx_smoothing))
    adx_5m_cond = adx_5m > 20

    donch_upper_1h, donch_lower_1h = None, None
    donch_upper_1h = htf_closed_series(df, 60, lambda h: donchian_channel(h, p.donchian_length)[0])
    donch_lower_1h = htf_closed_series(df, 60, lambda h: donchian_channel(h, p.donchian_length)[1])
    donch_cond = (df["close"] <= donch_lower_1h) if p.donchian_condition == "below" else (df["close"] >= donch_upper_1h)

    entry_raw = (bb_cond.fillna(False) & roc_cond.fillna(False) & atr_cond.fillna(False) &
                 adx_1m_cond.fillna(False) & adx_5m_cond.fillna(False) & donch_cond.fillna(False))
    entry_signal = entry_raw & ~entry_raw.shift(1).fillna(False)

    entry_defined = (bb_lower.notna() & roc_5m.notna() & atr_pct_1m.notna() &
                      adx_1m.notna() & adx_5m.notna() & donch_lower_1h.notna())

    exit_signal = sar_bearish_flip(df, p.sar_af_start, p.sar_af_step, p.sar_af_max)

    return {"entry_signal": entry_signal, "entry_defined": entry_defined, "exit_signal": exit_signal}


# --------------------------------------------------------- walk-forward --

def simulate_symbol(df: pd.DataFrame, symbol: str, p: Params) -> list[Deal]:
    ind = compute_indicators(df, p)
    entry_signal = ind["entry_signal"]
    entry_defined = ind["entry_defined"]
    exit_signal = ind["exit_signal"]

    n = len(df)
    first_valid = entry_defined.idxmax() if entry_defined.any() else None
    if first_valid is None:
        return []

    close = df["close"].to_numpy()
    deals: list[Deal] = []
    i = int(first_valid)
    in_deal = False
    entry_price = 0.0
    deal_start_bar = -1

    while i < n:
        if not in_deal:
            if bool(entry_signal.iloc[i]):
                entry_price = close[i]
                deal_start_bar = i
                in_deal = True
            i += 1
            continue

        pnl_now = (close[i] - entry_price) / entry_price * 100.0
        closed = False
        if bool(exit_signal.iloc[i]) and pnl_now >= p.min_pnl_pct:
            deals.append(Deal(
                symbol=symbol, entry_time=df["open_time"].iloc[deal_start_bar],
                exit_time=df["open_time"].iloc[i], entry_price=entry_price, exit_price=close[i],
                reason="TP", bars_held=i - deal_start_bar, gross_pnl_pct=pnl_now,
            ))
            closed = True
        elif (i - deal_start_bar) >= p.max_deal_bars:
            deals.append(Deal(
                symbol=symbol, entry_time=df["open_time"].iloc[deal_start_bar],
                exit_time=df["open_time"].iloc[i], entry_price=entry_price, exit_price=close[i],
                reason="TIMEOUT", bars_held=i - deal_start_bar, gross_pnl_pct=pnl_now,
            ))
            closed = True

        if closed:
            in_deal = False
        i += 1

    if in_deal:
        last_close = close[-1]
        gross = (last_close - entry_price) / entry_price * 100.0
        deals.append(Deal(
            symbol=symbol, entry_time=df["open_time"].iloc[deal_start_bar],
            exit_time=df["open_time"].iloc[-1], entry_price=entry_price, exit_price=last_close,
            reason="OPEN_AT_CUTOFF", bars_held=(n - 1) - deal_start_bar, gross_pnl_pct=gross,
        ))

    return deals


# --------------------------------------------------------------- report --

def net_pnl_pct(deal: Deal, fee_rate: float) -> float | None:
    if deal.gross_pnl_pct is None:
        return None
    return deal.gross_pnl_pct - fee_rate * 100.0


def summarize(deals: list[Deal], label: str) -> None:
    if not deals:
        print(f"\n{label}: no deals opened in this window.")
        return
    resolved = [d for d in deals if d.reason in ("TP", "TIMEOUT")]
    still_open = [d for d in deals if d.reason == "OPEN_AT_CUTOFF"]
    wins = [d for d in resolved if d.gross_pnl_pct is not None and d.gross_pnl_pct > 0]
    win_rate = (len(wins) / len(resolved) * 100) if resolved else float("nan")
    avg_gross = (sum(d.gross_pnl_pct for d in resolved) / len(resolved)) if resolved else float("nan")
    avg_bars = (sum(d.bars_held for d in deals) / len(deals)) if deals else float("nan")

    print(f"\n{label}")
    print(f"  Total deals opened:      {len(deals)}")
    print(f"  Resolved (TP/timeout):   {len(resolved)}   Still open at cutoff: {len(still_open)}")
    print(f"  Avg bars held/deal:      {avg_bars:.1f}")
    print(f"  Gross win rate:          {win_rate:.1f}%")
    print(f"  Gross avg P&L% :         {avg_gross:+.3f}%")
    reasons = {}
    for d in resolved:
        reasons[d.reason] = reasons.get(d.reason, 0) + 1
    print(f"  Exit reasons: {reasons}")

    for label_fee, fee_rate in FEE_SCENARIOS.items():
        nets = [net_pnl_pct(d, fee_rate) for d in resolved]
        nets = [x for x in nets if x is not None]
        if not nets:
            continue
        net_wins = sum(1 for x in nets if x > 0)
        print(f"    net P&L% after {label_fee:12s} fees: {sum(nets)/len(nets):+.3f}%  "
              f"win rate {net_wins/len(nets)*100:.1f}%")


def save_csv(deals: list[Deal], path: Path) -> None:
    if not deals:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = ["symbol", "entry_time", "exit_time", "entry_price",
                  "exit_price", "reason", "bars_held", "gross_pnl_pct"]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for d in deals:
            writer.writerow({k: getattr(d, k) for k in fieldnames})


def split_sample(deals: list[Deal]) -> tuple[list[Deal], list[Deal]]:
    resolved = sorted([d for d in deals if d.reason in ("TP", "TIMEOUT")], key=lambda d: d.entry_time)
    if len(resolved) < 4:
        return resolved, []
    mid = len(resolved) // 2
    return resolved[:mid], resolved[mid:]


# -------------------------------------------------------------------- --

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--symbol", nargs="+", default=["SOLUSDT"])
    parser.add_argument("--timeframe", default="1m")
    parser.add_argument("--bars", type=int, default=200000)
    parser.add_argument("--out", default="bb_roc_atr_adx_donchian_sar_backtest_out")

    parser.add_argument("--bb-length", type=int, default=20, help="ASSUMED")
    parser.add_argument("--bb-mult", type=float, default=2.0, help="ASSUMED")
    parser.add_argument("--bb-condition", choices=["below", "above"], default="below", help="ASSUMED direction -- see module docstring")

    parser.add_argument("--roc-length", type=int, default=9, help="ASSUMED")
    parser.add_argument("--atr-length", type=int, default=14, help="ASSUMED")
    parser.add_argument("--adx-di-length", type=int, default=14, help="ASSUMED")
    parser.add_argument("--adx-smoothing", type=int, default=14, help="ASSUMED")

    parser.add_argument("--donchian-length", type=int, default=20, help="ASSUMED")
    parser.add_argument("--donchian-condition", choices=["below", "above"], default="below", help="ASSUMED direction -- see module docstring")

    parser.add_argument("--sar-af-start", type=float, default=0.02, help="ASSUMED (Wilder default)")
    parser.add_argument("--sar-af-step", type=float, default=0.02, help="ASSUMED (Wilder default)")
    parser.add_argument("--sar-af-max", type=float, default=0.2, help="ASSUMED (Wilder default)")

    parser.add_argument("--min-pnl-pct", type=float, default=0.5, help="CONFIRMED from the live page")
    parser.add_argument("--max-deal-bars", type=int, default=50000, help="safety timeout only, not part of the real bot")

    args = parser.parse_args()
    p = Params(
        bb_length=args.bb_length, bb_mult=args.bb_mult, bb_condition=args.bb_condition,
        roc_length=args.roc_length, atr_length=args.atr_length,
        adx_di_length=args.adx_di_length, adx_smoothing=args.adx_smoothing,
        donchian_length=args.donchian_length, donchian_condition=args.donchian_condition,
        sar_af_start=args.sar_af_start, sar_af_step=args.sar_af_step, sar_af_max=args.sar_af_max,
        min_pnl_pct=args.min_pnl_pct, max_deal_bars=args.max_deal_bars,
    )

    print(__doc__)
    print("=" * 78)

    out_dir = Path(args.out)
    all_deals: list[Deal] = []
    for symbol in args.symbol:
        symbol = symbol.upper()
        print(f"\nFetching + simulating {symbol} ({args.bars} bars of {args.timeframe})...")
        try:
            df = fetch_history(symbol, args.timeframe, args.bars)
            deals = simulate_symbol(df, symbol, p)
        except DataError as exc:
            print(f"  [SKIP] {symbol}: {exc}")
            continue
        print(f"  {len(df)} bars, {df['open_time'].iloc[0]} .. {df['open_time'].iloc[-1]}")
        summarize(deals, symbol)
        save_csv(deals, out_dir / f"{symbol}_deals.csv")

        early, late = split_sample(deals)
        if early and late:
            summarize(early, f"  {symbol} -- EARLY half (split-sample)")
            summarize(late, f"  {symbol} -- LATE half (split-sample)")

        all_deals.extend(deals)
        time.sleep(2.0)  # 2026-09-05: avoid a rate-limit collision with the live bot on the same API key

    summarize(all_deals, "=== COMBINED (all symbols) ===")
    print(f"\nPer-deal CSVs written to {out_dir.resolve()}")


if __name__ == "__main__":
    main()
