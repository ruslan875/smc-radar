@echo off
cd /d %~dp0
python midas_check.py
