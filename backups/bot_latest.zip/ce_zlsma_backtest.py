#!/usr/bin/env python3
"""
Chandelier Exit + ZLSMA - Python port of CE_ZLSMA.pine
=======================================================

SOURCE: strategies/CE_ZLSMA.pine  ("Chandelier Exit with ZLSMA Strategy", v6)

WHAT IT DOES

Chandelier Exit gives the direction: a trailing level at
highest(close,22) - 3*ATR(22) for longs and lowest(close,22) + 3*ATR(22) for
shorts, each ratcheting one way only. `dir` flips when price crosses the
opposite level. ZLSMA (linear regression run twice, with the lag added back,
length 32) is the confirmation: a CE flip up is taken only if close is above
ZLSMA, a flip down only if below.

Three ways out, and they can disagree:
  - close crossing back through ZLSMA (a market exit)
  - a stop at the previous bar's low (long) / high (short)
  - a fixed 1% take-profit from the entry price

THE BUG THIS PORT FIXES

The Pine sets its protective orders as TWO separate exits on the same entry:

    strategy.exit("Long SL", "Long", stop = sl_price)
    strategy.exit("Long TP", "Long", limit = tp_price)

Each of those closes the FULL position and neither cancels the other. This is
a known Pine anti-pattern: the broker emulator can fill both, closing more
size than exists and printing phantom trades in the report. Whatever the
TradingView numbers for this script say, they are not the numbers of the
strategy as described.

Here it is one exit carrying both levels, which is what the author meant. When
a single bar touches both, the stop is taken first - the conservative
assumption, since a 1% target and a stop at the previous low are close enough
together that this happens regularly and assuming the target would flatter
the result.

OTHER DEVIATIONS, STATED OUT LOUD

* Entries fill at the NEXT bar's open. The Pine does not set
  process_orders_on_close, so this matches it.
* The Pine arms its exits one bar late: they are placed on the bar where the
  position change is detected, so they only become live on the bar after that,
  leaving the entry bar unprotected. This port arms them on the entry bar,
  which is what a live bot does. Pass --pine-exit-delay to reproduce the gap.
* `sl_price = low[1] - syminfo.mintick * 5`. Tick size varies per symbol and
  is not available here; the buffer is exposed as --sl-buffer-pct and defaults
  to 0, i.e. the stop sits exactly on the previous bar's low. Five ticks is
  worth well under a basis point on these instruments.
* The Pine charges no commission at all. Cost comes from --commission and
  --slippage-pct, as in every other port.

USAGE
    python ce_zlsma_backtest.py --symbols BTC/USDT ETH/USDT --timeframe 1h \
        --start 2024-01-01 --end 2025-12-31 --commission 0.055 --out out_ce
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

import pine_ta as ta
from port_common import (deals_frame, load_sources, net_pnl_pct, print_summary,
                         write_manifest)

DEFAULTS = {
    "ce_length": 22,
    "ce_mult": 3.0,
    "ce_use_close": True,
    "zl_length": 32,
    "zl_offset": 0,
    "tp_long_pct": 1.0,
    "tp_short_pct": 1.0,
}


# ---------------------------------------------------------------------------
# indicators
# ---------------------------------------------------------------------------

def chandelier_exit(df: pd.DataFrame, length: int, mult: float, use_close: bool):
    """Returns (long_stop, short_stop, direction).

    Reproduces the Pine line for line, including that `dir` is compared
    against the PREVIOUS bar's stop levels (ce_longStopPrev / ce_shortStopPrev),
    not the current ones.
    """
    atr_mult = (mult * ta.atr(df, length)).to_numpy(dtype=float)
    hi_src = df["close"] if use_close else df["high"]
    lo_src = df["close"] if use_close else df["low"]
    raw_long = (ta.highest(hi_src, length).to_numpy(dtype=float) - atr_mult)
    raw_short = (ta.lowest(lo_src, length).to_numpy(dtype=float) + atr_mult)
    close = df["close"].to_numpy(dtype=float)
    n = len(df)

    long_stop = np.full(n, np.nan)
    short_stop = np.full(n, np.nan)
    direction = np.full(n, np.nan)
    d = 1.0

    for i in range(n):
        if np.isnan(raw_long[i]) or np.isnan(raw_short[i]):
            continue
        ls_prev = long_stop[i - 1] if i > 0 and not np.isnan(long_stop[i - 1]) else raw_long[i]
        ss_prev = short_stop[i - 1] if i > 0 and not np.isnan(short_stop[i - 1]) else raw_short[i]
        prev_close = close[i - 1] if i > 0 else close[i]

        ls = max(raw_long[i], ls_prev) if prev_close > ls_prev else raw_long[i]
        ss = min(raw_short[i], ss_prev) if prev_close < ss_prev else raw_short[i]

        if close[i] > ss_prev:
            d = 1.0
        elif close[i] < ls_prev:
            d = -1.0
        long_stop[i], short_stop[i], direction[i] = ls, ss, d

    idx = df.index
    return (pd.Series(long_stop, index=idx), pd.Series(short_stop, index=idx),
            pd.Series(direction, index=idx))


def compute_signals(df: pd.DataFrame, cfg: dict) -> pd.DataFrame:
    out = df.copy()
    ls, ss, d = chandelier_exit(out, cfg["ce_length"], cfg["ce_mult"], cfg["ce_use_close"])
    out["ce_long_stop"], out["ce_short_stop"], out["ce_dir"] = ls, ss, d
    out["zlsma"] = ta.zlsma(out["close"], cfg["zl_length"], cfg["zl_offset"])

    prev_d = out["ce_dir"].shift(1)
    buy_flip = (out["ce_dir"] == 1) & (prev_d == -1)
    sell_flip = (out["ce_dir"] == -1) & (prev_d == 1)

    out["long_signal"] = buy_flip & (out["close"] > out["zlsma"])
    out["short_signal"] = sell_flip & (out["close"] < out["zlsma"])
    return out


# ---------------------------------------------------------------------------
# backtest
# ---------------------------------------------------------------------------

def run_backtest(df: pd.DataFrame, cfg: dict, commission_pct: float,
                 slippage_pct: float, sl_buffer_pct: float,
                 pine_exit_delay: bool) -> pd.DataFrame:
    deals = []
    pos = None            # dict(side, entry_time, entry_price, stop, target, armed_from)
    pending = None        # ("long"|"short"|"flat", reason) -> acted on at next open

    idx = df.index
    o = df["open"].to_numpy(dtype=float)
    h = df["high"].to_numpy(dtype=float)
    l = df["low"].to_numpy(dtype=float)
    c = df["close"].to_numpy(dtype=float)
    zl = df["zlsma"].to_numpy(dtype=float)
    long_sig = df["long_signal"].to_numpy(dtype=bool)
    short_sig = df["short_signal"].to_numpy(dtype=bool)

    def close_pos(exit_price, ts, reason):
        nonlocal pos
        deals.append({
            "entry_time": pos["entry_time"], "exit_time": ts, "side": pos["side"],
            "entry_price": pos["entry_price"], "exit_price": exit_price,
            "gross_pnl_pct": net_pnl_pct(pos["side"], pos["entry_price"], exit_price,
                                         commission_pct, slippage_pct),
            "reason": reason,
        })
        pos = None

    def open_pos(side, price, ts, i):
        nonlocal pos
        prev_low = l[i - 1] if i > 0 else l[i]
        prev_high = h[i - 1] if i > 0 else h[i]
        if side == "long":
            stop = prev_low * (1 - sl_buffer_pct / 100)
            target = price * (1 + cfg["tp_long_pct"] / 100)
        else:
            stop = prev_high * (1 + sl_buffer_pct / 100)
            target = price * (1 - cfg["tp_short_pct"] / 100)
        pos = {"side": side, "entry_time": ts, "entry_price": price,
               "stop": stop, "target": target,
               "armed_from": i + 1 if pine_exit_delay else i}

    for i in range(len(df)):
        ts = idx[i]

        # --- act on what the previous bar decided, at this bar's open --------
        if pending is not None:
            action = pending
            pending = None
            if pos is not None and action[0] != pos["side"]:
                close_pos(o[i], ts, action[1])
            if action[0] in ("long", "short") and pos is None:
                open_pos(action[0], o[i], ts, i)

        if pos is None:
            # --- signals decide the NEXT bar's open -------------------------
            if long_sig[i]:
                pending = ("long", "entry")
            elif short_sig[i]:
                pending = ("short", "entry")
            continue

        # --- protective levels, intrabar ------------------------------------
        if i >= pos["armed_from"]:
            if pos["side"] == "long":
                if l[i] <= pos["stop"]:
                    close_pos(pos["stop"], ts, "stop_loss")
                elif h[i] >= pos["target"]:
                    close_pos(pos["target"], ts, "take_profit")
            else:
                if h[i] >= pos["stop"]:
                    close_pos(pos["stop"], ts, "stop_loss")
                elif l[i] <= pos["target"]:
                    close_pos(pos["target"], ts, "take_profit")

        if pos is None:
            if long_sig[i]:
                pending = ("long", "entry")
            elif short_sig[i]:
                pending = ("short", "entry")
            continue

        # --- ZLSMA exit and reversals are market orders: next bar's open ----
        if long_sig[i] and pos["side"] == "short":
            pending = ("long", "reverse")
        elif short_sig[i] and pos["side"] == "long":
            pending = ("short", "reverse")
        elif pos["side"] == "long" and not np.isnan(zl[i]) and c[i] < zl[i]:
            pending = ("flat", "signal_exit")
        elif pos["side"] == "short" and not np.isnan(zl[i]) and c[i] > zl[i]:
            pending = ("flat", "signal_exit")

    if pos is not None:
        close_pos(c[-1], idx[-1], "end_of_data")

    return deals_frame(deals)


# ---------------------------------------------------------------------------

def main():
    p = argparse.ArgumentParser(description="Chandelier Exit + ZLSMA backtester")
    p.add_argument("--symbol")
    p.add_argument("--symbols", nargs="+")
    p.add_argument("--csv")
    p.add_argument("--exchange", default="bybit")
    p.add_argument("--market", default="swap", choices=["swap", "spot"])
    p.add_argument("--timeframe", default="1h")
    p.add_argument("--start", default="2024-01-01")
    p.add_argument("--end", default="2025-12-31")
    p.add_argument("--out", default="backtest_out_ce_zlsma")
    p.add_argument("--commission", type=float, default=0.055)
    p.add_argument("--slippage-pct", type=float, default=0.0)
    p.add_argument("--ce-length", type=int, default=DEFAULTS["ce_length"])
    p.add_argument("--ce-mult", type=float, default=DEFAULTS["ce_mult"])
    p.add_argument("--zl-length", type=int, default=DEFAULTS["zl_length"])
    p.add_argument("--tp-pct", type=float, default=DEFAULTS["tp_long_pct"],
                   help="take profit %%, applied to both directions (Pine has one per side)")
    p.add_argument("--sl-buffer-pct", type=float, default=0.0,
                   help="buffer below prev low / above prev high, standing in for "
                        "the Pine's 5 ticks")
    p.add_argument("--pine-exit-delay", action="store_true",
                   help="reproduce the Pine's unprotected entry bar")
    args = p.parse_args()

    cfg = dict(DEFAULTS)
    cfg.update(ce_length=args.ce_length, ce_mult=args.ce_mult,
               zl_length=args.zl_length,
               tp_long_pct=args.tp_pct, tp_short_pct=args.tp_pct)

    out_dir = Path(args.out)
    write_manifest(out_dir, Path(__file__).stem, args,
                   extra_keys=("ce_length", "ce_mult", "zl_length", "tp_pct",
                               "sl_buffer_pct", "pine_exit_delay"))

    sources = load_sources(args, p)

    print("\n" + "=" * 100)
    print("CHANDELIER EXIT + ZLSMA - BACKTEST RESULTS")
    print(f"CE {cfg['ce_length']}/{cfg['ce_mult']} | ZLSMA {cfg['zl_length']} | "
          f"TP {args.tp_pct}% | SL = prev bar extreme"
          f"{f' -{args.sl_buffer_pct}%' if args.sl_buffer_pct else ''} | "
          f"commission {args.commission}%/side | slippage {args.slippage_pct}%")
    print("FIXED vs Pine: one exit carrying stop AND target, instead of two "
          "full-size exits that do not cancel each other.")
    if args.pine_exit_delay:
        print("NOTE: --pine-exit-delay is on; the entry bar is unprotected, as in the Pine.")
    print("=" * 100)

    need = max(cfg["ce_length"], cfg["zl_length"] * 2) + 10
    for sym, ohlcv in sources.items():
        if len(ohlcv) < need:
            print(f"  {sym:14s}: insufficient data ({len(ohlcv)} bars, need {need})")
            continue
        df = compute_signals(ohlcv, cfg)
        deals = run_backtest(df, cfg, args.commission, args.slippage_pct,
                             args.sl_buffer_pct, args.pine_exit_delay)
        deals.to_csv(out_dir / f"{sym.replace('/', '')}_deals.csv", index=False)
        print_summary(sym, deals)

    print("=" * 100)
    print(f"\nDeal logs + _run.json written to: {out_dir}/")


if __name__ == "__main__":
    main()
