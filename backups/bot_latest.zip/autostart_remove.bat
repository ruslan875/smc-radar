@echo off
set "SU=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
if exist "%SU%\TRADEOS_start.bat" del "%SU%\TRADEOS_start.bat"
echo Avtozapusk TRADEOS ubran.
pause
