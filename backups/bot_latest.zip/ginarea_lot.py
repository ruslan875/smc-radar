"""ginarea_lot.py — 2026-11-03. Минимальный лот OKX USDT-SWAP (в монетах) и округление размера ордера ВНИЗ до лота,
как в калькуляторе MoneyMaker/BlindScalper и на самой бирже. Кеш: market_cache/okx_lots.json."""
from __future__ import annotations

import json
import math
from pathlib import Path

import requests

CACHE = Path(__file__).resolve().parent / "market_cache" / "okx_lots.json"


def lot(coin: str) -> tuple[float, float]:
    """(шаг лота, минимальный размер) в монетах."""
    coin = coin.upper()
    try:
        c = json.loads(CACHE.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        c = {}
    if coin not in c:
        try:
            r = requests.get("https://www.okx.com/api/v5/public/instruments",
                             params={"instType": "SWAP", "instId": f"{coin}-USDT-SWAP"}, timeout=15).json()["data"][0]
            cv = float(r["ctVal"]); c[coin] = [float(r["lotSz"]) * cv, float(r["minSz"]) * cv]
            CACHE.parent.mkdir(exist_ok=True); CACHE.write_text(json.dumps(c), encoding="utf-8")
        except Exception:  # noqa: BLE001
            return (0.0, 0.0)
    return tuple(c[coin])


def fl(q: float, P: dict) -> float:
    """Размер ордера, округлённый вниз до лота (не меньше минимального)."""
    step, mn = P.get("lot") or (0.0, 0.0)
    if not step:
        return q
    return max(mn, math.floor(q / step + 1e-9) * step)
