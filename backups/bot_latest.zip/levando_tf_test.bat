@echo off
cd /d "%~dp0"
set "PY=python"
if exist venv\Scripts\python.exe set "PY=venv\Scripts\python.exe"
"%PY%" -X utf8 levando_tf_test.py
