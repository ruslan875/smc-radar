@echo off
cd /d "%~dp0"
"%~dp0venv\Scripts\python.exe" bots_saw_test.py %*
pause
