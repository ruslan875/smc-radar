@echo off
rem update_mobile_www.bat — бэкап index.html перед правкой + проверка, что шлюз (порт 8770) отдаёт актуальный файл.
rem Подробности: MOBILE_WWW_UPDATE.md в этой же папке.
setlocal
set WWW=%~dp0
set BK=D:\VANTORIX\bot\_backups
if not exist "%BK%" mkdir "%BK%"

for /f %%i in ('powershell -NoProfile -Command "Get-Date -Format yyyy-MM-dd_HHmmss"') do set TS=%%i
copy /y "%WWW%index.html" "%BK%\mobile_www_index_%TS%.html" >nul
echo [1/2] Бэкап: %BK%\mobile_www_index_%TS%.html

powershell -NoProfile -Command ^
  "$f=(Get-FileHash '%WWW%index.html' -Algorithm MD5).Hash;" ^
  "try{$r=Invoke-WebRequest -UseBasicParsing -TimeoutSec 5 http://127.0.0.1:8770/m/;" ^
  "$s=[System.BitConverter]::ToString([System.Security.Cryptography.MD5]::Create().ComputeHash([System.Text.Encoding]::UTF8.GetBytes($r.Content))).Replace('-','');" ^
  "if($f -eq $s){'[2/2] Шлюз 8770 отдаёт актуальный index.html — OK'}else{'[2/2] ВНИМАНИЕ: шлюз отдаёт ДРУГУЮ версию файла!'}}" ^
  "catch{'[2/2] Шлюз 8770 не отвечает — приложение на телефоне покажет экран настройки.'}"
endlocal
