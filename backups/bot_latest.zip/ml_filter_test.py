"""ml_filter_test.py — 2026-10-05. «ИИ, который учится на индикаторах»: модель машинного обучения смотрит на ~40 признаков
(все популярные индикаторы терминала: EMA/SMA, RSI, MACD, Боллинджер, ATR, ADX, Стохастик, CCI, MFI, OBV, объём, Дончиан,
канал регрессии, старший ТФ, время) в момент каждого сигнала «пробой канала 4h» и учится отличать пробои, дошедшие до тейка.
ЧЕСТНО: обучение только на сигналах ДО 2024, проверка на 2024–2026 (модель их не видела).
Итог: сколько R на сделку без фильтра и если брать только сигналы с высокой оценкой модели; какие индикаторы важнее.
Если фильтр не улучшает проверку — значит, индикаторы ничего не добавляют, и ставить его не нужно. Результат — ml_filter_test.csv.
"""
import sys as _sys
try:
    _sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass
import csv
import numpy as np
import pandas as pd

CUT = pd.Timestamp("2024-01-01", tz="UTC").value // 10**6
COST, N, RR = 0.0011, 100, 2.0


def feats(d):
    o, h, l, c, v = (d[k].astype(float) for k in "ohlcv")
    f = pd.DataFrame(index=d.index)
    pc = c.shift(1); tr = pd.concat([h - l, (h - pc).abs(), (l - pc).abs()], axis=1).max(axis=1)
    atr = tr.ewm(alpha=1 / 14, adjust=False).mean()
    for n in (20, 50, 200):
        e = c.ewm(span=n, adjust=False).mean(); f[f"ema{n}_dist"] = (c - e) / atr; f[f"ema{n}_slope"] = e.pct_change(5) * 100
    f["sma200_dist"] = (c / c.rolling(200).mean() - 1) * 100
    dl = c.diff(); up = dl.clip(lower=0).ewm(alpha=1 / 14, adjust=False).mean(); dn = (-dl.clip(upper=0)).ewm(alpha=1 / 14, adjust=False).mean()
    f["rsi14"] = 100 - 100 / (1 + up / dn.replace(0, 1e-12))
    m = c.ewm(span=12, adjust=False).mean() - c.ewm(span=26, adjust=False).mean(); sg = m.ewm(span=9, adjust=False).mean()
    f["macd"] = m / atr; f["macd_hist"] = (m - sg) / atr
    ma, sd = c.rolling(20).mean(), c.rolling(20).std()
    f["bb_pos"] = (c - ma) / (2 * sd); f["bb_width"] = 4 * sd / c * 100
    f["atr_pct"] = atr / c * 100; f["atr_ratio"] = atr / atr.rolling(100).mean()
    pdm = (h.diff()).where((h.diff() > -l.diff()) & (h.diff() > 0), 0.0); ndm = (-l.diff()).where((-l.diff() > h.diff()) & (-l.diff() > 0), 0.0)
    pdi = 100 * pdm.ewm(alpha=1 / 14, adjust=False).mean() / atr; ndi = 100 * ndm.ewm(alpha=1 / 14, adjust=False).mean() / atr
    f["adx"] = (100 * (pdi - ndi).abs() / (pdi + ndi).replace(0, 1e-9)).ewm(alpha=1 / 14, adjust=False).mean(); f["di_diff"] = pdi - ndi
    ll, hh = l.rolling(14).min(), h.rolling(14).max(); f["stoch"] = 100 * (c - ll) / (hh - ll).replace(0, 1e-9)
    tp = (h + l + c) / 3; f["cci"] = (tp - tp.rolling(20).mean()) / (0.015 * tp.rolling(20).std().replace(0, 1e-9))
    mf = tp * v; pos = mf.where(tp > tp.shift(1), 0.0).rolling(14).sum(); neg = mf.where(tp < tp.shift(1), 0.0).rolling(14).sum()
    f["mfi"] = 100 - 100 / (1 + pos / neg.replace(0, 1e-9))
    obv = (np.sign(c.diff()) * v).cumsum(); f["obv_slope"] = (obv - obv.shift(10)) / (v.rolling(10).sum() + 1e-9)
    f["vol_ratio"] = v / v.rolling(20).mean(); f["vol_ratio5"] = v.rolling(5).mean() / v.rolling(50).mean()
    f["donch_pos"] = (c - l.rolling(55).min()) / (h.rolling(55).max() - l.rolling(55).min()).replace(0, 1e-9)
    for k in (1, 5, 20, 60):
        f[f"ret{k}"] = c.pct_change(k) * 100
    f["body"] = (c - o) / atr; f["upper_wick"] = (h - np.maximum(o, c)) / atr; f["lower_wick"] = (np.minimum(o, c) - l) / atr
    # старший ТФ (1D из 4h ≈ 6 свечей)
    f["htf_trend"] = (c.rolling(6 * 20).mean() - c.rolling(6 * 50).mean()) / atr
    f["htf_rsi"] = f["rsi14"].rolling(6).mean()
    t = pd.to_datetime(d.t, unit="ms", utc=True); f["hour"] = t.dt.hour; f["dow"] = t.dt.dayofweek
    # канал регрессии
    x = pd.Series(np.arange(len(c), dtype=float), index=d.index)
    sx, sy, sxy, sxx, syy = x.rolling(N).sum(), c.rolling(N).sum(), (x * c).rolling(N).sum(), (x * x).rolling(N).sum(), (c * c).rolling(N).sum()
    b = (N * sxy - sx * sy) / (N * sxx - sx * sx); a = (sy - b * sx) / N; mid = a + b * x
    sdc = np.sqrt(((syy - 2 * a * sy - 2 * b * sxy + N * a * a + 2 * a * b * sx + b * b * sxx).clip(lower=0) / N))
    f["ch_slope"] = b / atr * 10; f["ch_width"] = 4 * sdc / c * 100; f["break_depth"] = (c - mid).abs() / (2 * sdc.replace(0, 1e-9))
    return f, mid.values, sdc.values


def signals(d, coin):
    f, mid, sd = feats(d)
    h, l, c, t = d.h.values, d.l.values, d.c.values, d.t.values
    rows = []; busy = -1
    for i in range(N + 300, len(c) - 1):
        up, lo, pu, pl = mid[i] + 2 * sd[i], mid[i] - 2 * sd[i], mid[i - 1] + 2 * sd[i - 1], mid[i - 1] - 2 * sd[i - 1]
        side = 1 if (c[i] > up and c[i - 1] <= pu) else -1 if (c[i] < lo and c[i - 1] >= pl) else 0
        if not side or i <= busy: continue
        e, stop = c[i], mid[i]; risk = abs(e - stop)
        if risk <= 0: continue
        tp = e + side * RR * risk; r = None; k = i
        for k in range(i + 1, min(len(c), i + 101)):
            if (l[k] <= stop) if side > 0 else (h[k] >= stop): r = -1.0; break
            if (h[k] >= tp) if side > 0 else (l[k] <= tp): r = RR; break
        if r is None: r = side * (c[k] - e) / risk
        busy = k
        x = f.iloc[i].to_dict()
        for key in list(x):                       # признаки направленные — приводим к стороне сделки
            if key in ("ema20_dist", "ema50_dist", "ema200_dist", "ema20_slope", "ema50_slope", "ema200_slope", "sma200_dist", "macd",
                       "macd_hist", "bb_pos", "di_diff", "obv_slope", "ret1", "ret5", "ret20", "ret60", "body", "htf_trend", "ch_slope"):
                x[key] = x[key] * side
        x.update({"side": side, "coin": coin, "t": int(t[i]), "r": r - COST * e / risk})
        rows.append(x)
    return rows


def fit_predict(Xtr, ytr, Xte):
    try:
        from sklearn.ensemble import HistGradientBoostingClassifier  # noqa: PLC0415
        mdl = HistGradientBoostingClassifier(max_depth=3, learning_rate=0.05, max_iter=200, l2_regularization=1.0,
                                             min_samples_leaf=40, random_state=1)
        mdl.fit(Xtr, ytr)
        try:
            from sklearn.inspection import permutation_importance  # noqa: PLC0415
            imp = permutation_importance(mdl, Xtr, ytr, n_repeats=3, random_state=1).importances_mean
        except Exception:  # noqa: BLE001
            imp = np.zeros(Xtr.shape[1])
        return mdl.predict_proba(Xte)[:, 1], imp, "градиентный бустинг (sklearn)"
    except ImportError:
        mu, sdv = Xtr.mean(0), Xtr.std(0) + 1e-9; A = (Xtr - mu) / sdv; w = np.zeros(A.shape[1]); b0 = 0.0
        for _ in range(400):
            p = 1 / (1 + np.exp(-(A @ w + b0))); g = p - ytr
            w -= 0.05 * (A.T @ g / len(ytr) + 0.01 * w); b0 -= 0.05 * g.mean()
        return 1 / (1 + np.exp(-(((Xte - mu) / sdv) @ w + b0))), np.abs(w), "логистическая регрессия (numpy)"


if __name__ == "__main__":
    import kvoo_longtest as K
    rows = []
    for s in K.COINS:
        d = K.load(s, "4h")
        if d is None or len(d) < 800: continue
        print("признаки и сигналы:", s); rows += signals(d.reset_index(drop=True), s.replace("USDT", ""))
    df = pd.DataFrame(rows).replace([np.inf, -np.inf], np.nan).fillna(0)
    fcols = [c for c in df.columns if c not in ("coin", "t", "r")]
    tr, te = df[df.t < CUT], df[df.t >= CUT]
    print(f"\nСигналов: всего {len(df)}, обучение (до 2024) {len(tr)}, проверка (2024–26) {len(te)}")
    p, imp, kind = fit_predict(tr[fcols].values, (tr.r > 0).astype(int).values, te[fcols].values)
    te = te.assign(p=p)
    base = te.r.mean()
    out = [("без фильтра (все сигналы)", len(te), te.r.mean(), (te.r > 0).mean(), te.r.sum())]
    for q in (0.3, 0.5, 0.7):
        th = np.quantile(p, q); sel = te[te.p >= th]
        out.append((f"только лучшие {int((1 - q) * 100)}% по оценке модели", len(sel), sel.r.mean(), (sel.r > 0).mean(), sel.r.sum()))
    worst = te[te.p < np.quantile(p, 0.3)]
    out.append(("худшие 30% (то, что фильтр отбросил)", len(worst), worst.r.mean(), (worst.r > 0).mean(), worst.r.sum()))
    print(f"\nМодель: {kind}. ПРОВЕРКА на 2024–2026 (модель эти сигналы не видела):")
    for name, n, m, wr, s in out:
        print(f"  {name:42} | сделок {n:4} | WR {wr * 100:5.1f}% | {m:+.3f}R на сделку | итог {s:+7.1f}R")
    best = max(out[1:4], key=lambda x: x[2])
    gain = best[2] - base
    print("\nВЫВОД:", f"фильтр УЛУЧШАЕТ: {best[0]} → {best[2]:+.3f}R против {base:+.3f}R (+{gain:.3f}R). Можно ставить в сигналы как «оценку модели»."
          if gain > 0.05 and best[1] >= 60 and out[-1][2] < base
          else "фильтр НЕ даёт надёжного улучшения — индикаторы почти ничего не добавляют к самому пробою. Ставить не нужно.")
    order = np.argsort(-imp)[:12]
    print("\nКакие индикаторы модель считает важными (топ-12):")
    for j in order:
        print(f"  {fcols[j]:14} {imp[j]:.4f}")
    with open(K.BASE / "ml_filter_test.csv", "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f, delimiter=";"); w.writerow(["вариант", "сделок", "R_на_сделку", "WR", "итог_R"])
        for r in out: w.writerow([r[0], r[1], round(r[2], 3), round(r[3] * 100, 1), round(r[4], 1)])
    input("\nEnter — закрыть")
