"""cup_stocks_test.py — 2026-11-09. «Чашка с ручкой» на дневках акций/индексов/сырья (те же 110 инструментов, что stocks_test)."""
import sys, time
from pathlib import Path
import numpy as np
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import stocks_test as ST  # noqa: E402
import cup_handle as CH  # noqa: E402
syms = [(s, s) for s in ST.STOCKS] + list(ST.OTHER.items())
L = [f"Чашка с ручкой — дневки, {time.strftime('%Y-%m-%d %H:%M')}"]
for mode in ("depth", "fib", "r3", "trail"):
    A, T, pos, n = [], [], 0, 0
    for name, sym in syms:
        d = ST.yahoo(sym)
        if d is None:
            continue
        tr = CH.trades(d, mode, cost=0.0005); r = [q["r"] for q in tr]
        A += r; T += [q["in_t"] for q in tr]
        if r:
            n += 1; pos += sum(r) > 0
    a = np.array(A); ti = np.array(T); mid = np.median(ti)
    L.append(f"{mode:6s} сделок {len(a):5d} · R/сд {a.mean():+.3f} · PF {a[a > 0].sum() / max(1e-9, -a[a < 0].sum()):.2f} · win {(a > 0).mean() * 100:.0f}% · "
             f"половины {a[ti < mid].sum():+.1f}/{a[ti >= mid].sum():+.1f} · инструментов в плюсе {pos}/{n}")
    print(L[-1], flush=True)
(BASE / "cup_stocks_test.txt").write_text("\n".join(L), encoding="utf-8")
