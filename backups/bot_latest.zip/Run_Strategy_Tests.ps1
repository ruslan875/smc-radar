# VANTORIX Strategy Tester v1.0
# Автоматическое тестирование всех стратегий через TradingView CLI

param(
    [string]$Strategy = "CE_ZLSMA",
    [string]$Symbol = "XRPUSDT",
    [int]$Timeframe = 60,  # 1H
    [string]$FromDate = "2026-03-20",
    [string]$ToDate = "2026-09-20",
    [string]$Exchange = "OKX"
)

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "VANTORIX Strategy Tester" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Strategy: $Strategy"
Write-Host "Symbol: $Symbol ($Exchange)"
Write-Host "Timeframe: $Timeframe min"
Write-Host "Period: $FromDate to $ToDate"
Write-Host ""

# 1. Запустить TradingView
Write-Host "[1/5] Запуск TradingView Desktop..." -ForegroundColor Yellow
$tvPath = (Get-AppxPackage -Name 'TradingView.Desktop').InstallLocation
if ($tvPath) {
    & "$tvPath\TradingView.exe" --remote-debugging-port=9222
    Start-Sleep -Seconds 5
} else {
    Write-Host "⚠️  TradingView не найден в AppxPackage" -ForegroundColor Red
    exit 1
}

# 2. Установить символ
Write-Host "[2/5] Установка символа $Symbol..." -ForegroundColor Yellow
tv symbol "$Exchange:$Symbol"
Start-Sleep -Seconds 2

# 3. Установить таймфрейм
Write-Host "[3/5] Установка таймфрейма $Timeframe min..." -ForegroundColor Yellow
tv timeframe $Timeframe
Start-Sleep -Seconds 2

# 4. Добавить стратегию
Write-Host "[4/5] Загрузка стратегии $Strategy..." -ForegroundColor Yellow
tv indicator add "file:///D:/VANTORIX/bot/strategies/$Strategy.pine"
Start-Sleep -Seconds 3

# 5. Скриншот результатов (через CDP)
Write-Host "[5/5] Сбор результатов..." -ForegroundColor Yellow
$screenshotPath = "D:\VANTORIX\bot\backtest_results\$(Get-Date -Format 'yyyy-MM-dd_HH-mm')_${Strategy}_${Symbol}.png"
New-Item -ItemType Directory -Path "D:\VANTORIX\bot\backtest_results" -Force | Out-Null

# Попытка получить скриншот через Chrome DevTools Protocol
try {
    $response = Invoke-WebRequest -Uri "http://127.0.0.1:9222/json" -Method GET
    Write-Host "✅ Connected to TradingView CDP" -ForegroundColor Green
} catch {
    Write-Host "⚠️  Could not connect to CDP, taking manual screenshot..." -ForegroundColor Yellow
}

# Альтернатива: использовать встроенную функцию screenshot в tv CLI
tv screenshot --output=$screenshotPath
Write-Host "📸 Screenshot saved: $screenshotPath" -ForegroundColor Green

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "✅ Test completed" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
