"""chan_coins_test.py — 2026-10-12. Какие ещё монеты добавить в пробой канала 4h (челлендж), не испортив результат.

Правила — как у бота челленджа (chan_paper): канал регрессии 100 свечей 4h, ±2σ, вход по закрытию свечи пробоя,
стоп = центр канала, тейк 2R, не дольше 100 свечей. Комиссия 0.11% за круг. Ничего не торгует.
Для каждой монеты из топа Bybit по обороту: сделки, итог в R, 1-я / 2-я половина истории и последние 12 месяцев.
Годится монета, если плюс в ОБЕИХ половинах И за последний год, и сделок ≥ 20.
Запуск: chan_coins_test.bat → отчёт bt_lab_bots/chan_coins_test.txt
"""
from __future__ import annotations

import time
from pathlib import Path

import requests

BASE = Path(__file__).resolve().parent
OUT = BASE / "bt_lab_bots" / "chan_coins_test.txt"
CURRENT = ["BTCUSDT", "ETHUSDT", "XRPUSDT", "DOGEUSDT", "ADAUSDT", "SOLUSDT", "LINKUSDT", "LTCUSDT", "BNBUSDT",
           "AVAXUSDT", "TAOUSDT", "HYPEUSDT"]
FEE = 0.0011
N, RR, H4 = 100, 2.0, 4 * 3600 * 1000
YEAR = 365 * 86400 * 1000
LINES = []


def say(s=""):
    print(s)
    LINES.append(s)


def top_coins(n=45):
    r = requests.get("https://api.bybit.com/v5/market/tickers", params={"category": "linear"}, timeout=20).json()["result"]["list"]
    r = [x for x in r if x["symbol"].endswith("USDT") and not x["symbol"].startswith(("1000", "10000"))]
    r.sort(key=lambda x: -float(x.get("turnover24h") or 0))
    return [x["symbol"] for x in r[:n]]


def klines(sym, total=6000):
    rows, end = [], None
    while len(rows) < total:
        p = {"category": "linear", "symbol": sym, "interval": "240", "limit": 1000}
        if end:
            p["end"] = end
        j = None
        for k in range(4):
            try:
                j = requests.get("https://api.bybit.com/v5/market/kline", params=p, timeout=20).json()
                break
            except requests.RequestException:
                time.sleep(2 * (k + 1))
        lst = (j or {}).get("result", {}).get("list") or []
        if not lst:
            break
        rows += lst
        end = int(lst[-1][0]) - 1
        if len(lst) < 1000:
            break
        time.sleep(0.15)
    rows = sorted({int(r[0]): r for r in rows}.values(), key=lambda r: int(r[0]))
    return [(int(r[0]), float(r[2]), float(r[3]), float(r[4])) for r in rows]


def channel(rows):
    c = [r[3] for r in rows]
    mid, sd = [None] * len(c), [None] * len(c)
    xm = (N - 1) / 2
    den = sum((x - xm) ** 2 for x in range(N))
    for i in range(N - 1, len(c)):
        ys = c[i - N + 1:i + 1]
        ym = sum(ys) / N
        b = sum((x - xm) * (y - ym) for x, y in enumerate(ys)) / den
        a = ym - b * xm
        mid[i] = a + b * (N - 1)
        sd[i] = (sum((y - a - b * x) ** 2 for x, y in enumerate(ys)) / N) ** 0.5
    out, deal = [], None
    for i in range(N, len(c)):
        t, h, l, cl = rows[i]
        if deal:
            d = deal["side"]; r = None
            if (l <= deal["sl"]) if d > 0 else (h >= deal["sl"]):
                r = -1.0
            elif (h >= deal["tp"]) if d > 0 else (l <= deal["tp"]):
                r = RR
            elif t - deal["t"] >= 100 * H4:
                r = d * (cl - deal["entry"]) / deal["risk"]
            if r is not None:
                out.append((deal["t"], r - FEE * deal["entry"] / deal["risk"]))
                deal = None
            continue
        up, lo, pu, plo = mid[i] + 2 * sd[i], mid[i] - 2 * sd[i], mid[i - 1] + 2 * sd[i - 1], mid[i - 1] - 2 * sd[i - 1]
        side = 1 if (cl > up and c[i - 1] <= pu) else -1 if (cl < lo and c[i - 1] >= plo) else 0
        if side and abs(cl - mid[i]) > 0:
            risk = abs(cl - mid[i])
            deal = {"side": side, "t": t, "entry": cl, "risk": risk, "sl": mid[i], "tp": cl + side * RR * risk}
    return out


def main():
    say(f"Пробой канала 4h — проверка монет · {time.strftime('%Y-%m-%d %H:%M')} · комиссия 0.11% за круг")
    coins = list(dict.fromkeys(CURRENT + top_coins()))
    now = int(time.time() * 1000)
    res = []
    for s in coins:
        try:
            rows = klines(s)
        except Exception as exc:  # noqa: BLE001
            say(f"{s}: ошибка {exc}"[:120]); continue
        if len(rows) < N + 300:
            continue
        tr = channel(rows)
        if not tr:
            continue
        rs = [r for _, r in tr]
        h = len(rs) // 2
        last = [r for t, r in tr if t >= now - YEAR]
        months = (rows[-1][0] - rows[0][0]) / (30.4 * 86400000)
        ok = len(rs) >= 20 and sum(rs[:h]) > 0 and sum(rs[h:]) > 0 and sum(last) > 0
        res.append((s, len(rs), sum(rs), sum(rs[:h]), sum(rs[h:]), sum(last), len(last), len(rs) / months, ok))
    res.sort(key=lambda x: (not x[8], -x[2] / max(x[1], 1)))
    say(f"{'монета':<14}{'сделок':>7}{'итог R':>9}{'R/сд':>7}{'1-я пол':>9}{'2-я пол':>9}{'год R':>8}{'сд/мес':>8}  вывод")
    for s, n, tot, a, b, y, ny, pm, ok in res:
        tag = ("✅ годится" if ok else "❌") + (" (уже торгуем)" if s in CURRENT else "")
        say(f"{s:<14}{n:>7}{tot:>+9.1f}{tot / n:>+7.2f}{a:>+9.1f}{b:>+9.1f}{y:>+8.1f}{pm:>8.1f}  {tag}")
    good = [r for r in res if r[8]]
    say("")
    say(f"Годятся: {len(good)} монет, вместе ≈ {sum(r[7] for r in good):.1f} сделок в месяц "
        f"(сейчас 12 монет ≈ {sum(r[7] for r in res if r[0] in CURRENT):.1f}).")
    say("Монеты из списка «уже торгуем», которые не прошли, — кандидаты на удаление.")
    OUT.parent.mkdir(exist_ok=True)
    OUT.write_text("\n".join(LINES), encoding="utf-8")
    print(f"\nОтчёт: {OUT}")


if __name__ == "__main__":
    main()
