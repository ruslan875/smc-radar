"""ginarea_hype_test.py — 2026-10-28. Приближённый бэктест бота GinArea «HYPE DCA 0,20_c_c» (Indicator grid, OKX HYPE, LONG).
Настройки со скриншотов: RSI(14) 5m < 90 (почти всегда), разовая проверка ВКЛ, 55 ордеров, шаг 0.2% × множитель шага 1.02,
размер 0.1 HYPE × 1.1, максимум 0.2, цель 0.6% от средней, инстоп 0.2, мин. стоп 0.05%, макс. стоп 0.6%, выход по средней,
комиссия тейкера 0.03%, ТП/СЛ бота не заданы, остановка «30 мин + 50 $» не моделируется (с 0.1 HYPE 50 $ — очень редко).
Модель — та же, что ginarea_ind_test.py (алгоритм GinArea закрыт — приближение). Инстоп (вход стоп-ордером) не моделируется.
Ничего не торгует. Запуск: ginarea_hype_test.bat [дней, по умолч. 365] → bt_lab_bots/ginarea_hype_test.txt
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import requests  # noqa: E402
CACHE = BASE / "market_cache"


def okx_1m(days, inst="HYPE-USDT-SWAP"):
    CACHE.mkdir(exist_ok=True)
    path = CACHE / "okx_HYPE_1m.pkl"
    old = pd.read_pickle(path) if path.exists() else pd.DataFrame(columns=["t", "o", "h", "l", "c"])
    need_from = int((time.time() - days * 86400) * 1000)
    have_new = int(old.t.max()) if len(old) else 0
    have_old = int(old.t.min()) if len(old) else None

    def pull(after, stop):
        rows, k = [], 0
        while True:
            q = {"instId": inst, "bar": "1m", "limit": 100}
            if after:
                q["after"] = after
            j = None
            for tr in range(6):
                try:
                    j = requests.get("https://www.okx.com/api/v5/market/history-candles", params=q, timeout=20).json()
                    if j.get("code") == "0":
                        break
                except requests.RequestException:
                    pass
                time.sleep(1.5 * (tr + 1))
            lst = (j or {}).get("data") or []
            if not lst:
                break
            rows += [r for r in lst if len(r) < 9 or r[8] == "1"]
            after = lst[-1][0]
            k += 1
            if k % 100 == 0:
                print(f"  качаю OKX HYPE 1m: {pd.to_datetime(int(after), unit='ms'):%Y-%m-%d %H:%M}", flush=True)
            if int(after) <= stop or len(lst) < 100:
                break
            time.sleep(0.1)
        return rows

    rows = pull(None, max(have_new, need_from))
    if have_old is not None and have_old > need_from + 60_000:
        rows += pull(str(have_old), need_from)
    if rows:
        a = pd.DataFrame([[int(r[0])] + [float(x) for x in r[1:5]] for r in rows], columns=["t", "o", "h", "l", "c"])
        old = pd.concat([old, a]).drop_duplicates("t").sort_values("t").reset_index(drop=True)
        old["t"] = old["t"].astype("int64")
        old.to_pickle(path)
    old = old.astype({"t": "int64", "o": "float64", "h": "float64", "l": "float64", "c": "float64"})
    return old[old.t >= need_from].reset_index(drop=True)



OUT = BASE / "bt_lab_bots" / "ginarea_hype_test.txt"
P = dict(rsi_len=14, rsi_tf="5min", rsi_lvl=90, n_orders=55, step=0.002, step_mult=1.02, qty=0.1, mult=1.1, qmax=0.2,
         target=0.006, min_stop=0.0005, max_stop=0.006, tp0=1e9, tp_inc=0.0)
LINES = []


def say(s=""):
    print(s, flush=True)
    LINES.append(s)


def rsi_gate(d):
    """True на минуте i, если последняя ЗАКРЫТАЯ 5m-свеча имеет RSI14 < уровня."""
    ix = pd.to_datetime(d.t, unit="ms")
    c5 = pd.Series(d.c.to_numpy(), index=ix).resample(P["rsi_tf"]).last().dropna()
    dl = c5.diff()
    up = dl.clip(lower=0).ewm(alpha=1 / P["rsi_len"], adjust=False).mean()
    dn = (-dl.clip(upper=0)).ewm(alpha=1 / P["rsi_len"], adjust=False).mean()
    r = 100 - 100 / (1 + up / dn.replace(0, 1e-12))
    key = ix.dt.floor(P["rsi_tf"]) - pd.Timedelta(P["rsi_tf"])
    return (r.reindex(key).to_numpy() < P["rsi_lvl"])


def run(d, fee, gate):
    t, o, h, l, c = (d[k].to_numpy() for k in ("t", "o", "h", "l", "c"))
    res = {"cycles": 0, "bot_tp": 0, "fees": 0.0, "max_orders": 0, "max_notional": 0.0, "worst_unreal": 0.0,
           "worst_t": None, "longest_h": 0.0}
    monthly, total, sess, tp = {}, 0.0, 0.0, P["tp0"]
    pos = None

    def book(x, ts):
        nonlocal total, sess
        total += x; sess += x
        m = pd.to_datetime(ts, unit="ms").strftime("%Y-%m")
        monthly[m] = monthly.get(m, 0.0) + x

    def fill(px, q, ts):
        res["fees"] += px * q * fee
        book(-px * q * fee, ts)

    def close(px, ts):
        nonlocal pos
        fill(px, pos["qty"], ts)
        book((px - pos["avg"]) * pos["qty"], ts)
        res["longest_h"] = max(res["longest_h"], (ts - pos["t0"]) / 3_600_000)
        pos = None

    for i in range(1, len(c)):
        if pos is None:
            if not gate[i]:
                continue
            q = P["qty"]
            fill(o[i], q, t[i])
            pos = {"qty": q, "avg": o[i], "last": o[i], "n": 1, "q": q, "stop": None, "t0": t[i]}
            res["cycles"] += 1
        while pos["n"] < P["n_orders"] and l[i] <= pos["last"] * (1 - P["step"] * P["step_mult"] ** (pos["n"] - 1)):
            px = pos["last"] * (1 - P["step"] * P["step_mult"] ** (pos["n"] - 1))
            q = min(P["qmax"], pos["q"] * P["mult"])
            pos["avg"] = (pos["avg"] * pos["qty"] + px * q) / (pos["qty"] + q)
            pos["qty"] += q; pos["q"] = q; pos["last"] = px; pos["n"] += 1
            fill(px, q, t[i])
        res["max_orders"] = max(res["max_orders"], pos["n"])
        res["max_notional"] = max(res["max_notional"], pos["qty"] * c[i])
        un_w = (l[i] - pos["avg"]) * pos["qty"]
        if un_w < res["worst_unreal"]:
            res["worst_unreal"], res["worst_t"] = un_w, t[i]
        if P.get("sl") and sess + un_w - l[i] * pos["qty"] * fee <= P["sl"]:   # опц. стоп-лосс бота
            close(l[i], t[i])
            res["bot_sl"] = res.get("bot_sl", 0) + 1
            sess, tp = 0.0, P["tp0"]
            continue
        trig = pos["avg"] * (1 + P["target"])
        if pos["stop"] is None and h[i] >= trig:
            pos["stop"] = trig * (1 - P["min_stop"])
        if pos["stop"] is not None:
            pos["stop"] = max(pos["stop"], h[i] * (1 - P["max_stop"]))
            if c[i] <= pos["stop"] or l[i] <= pos["stop"]:
                close(pos["stop"], t[i])
        un = 0.0 if pos is None else (c[i] - pos["avg"]) * pos["qty"] - c[i] * pos["qty"] * fee
        if sess + un >= tp:
            if pos is not None:
                close(c[i], t[i])
            res["bot_tp"] += 1
            sess, tp = 0.0, tp + P["tp_inc"]
    open_un = 0.0
    if pos is not None:
        open_un = (c[-1] - pos["avg"]) * pos["qty"]
        res["open"] = f"открыта: {pos['n']} орд., средняя {pos['avg']:.3f}, PnL {open_un:+.2f} $"
    res["total"], res["monthly"], res["open_un"] = total, monthly, open_un
    return res


def main():
    days = int(sys.argv[1]) if len(sys.argv) > 1 else 365
    say(f"GinArea Indicator grid «HYPE DCA 0,20_c_c» — приближённый бэктест · OKX HYPE 1m · {days} дн. · {time.strftime('%Y-%m-%d %H:%M')}")
    say(f"Настройки: {P}")
    d = okx_1m(days)
    if len(d) < 10000:
        say("мало свечей — OKX не отдал историю"); return
    say(f"Свечей: {len(d)} · {pd.to_datetime(d.t.iloc[0], unit='ms'):%Y-%m-%d} → "
        f"{pd.to_datetime(d.t.iloc[-1], unit='ms'):%Y-%m-%d} · HYPE {d.c.iloc[0]:.2f} → {d.c.iloc[-1]:.2f}")
    full = sum(min(P["qmax"], P["qty"] * P["mult"] ** k) for k in range(P["n_orders"]))
    cov = 1.0
    for k in range(P["n_orders"] - 1):
        cov *= 1 - P["step"] * P["step_mult"] ** k
    say(f"Полная сетка: {full:.2f} HYPE ≈ {full * d.c.iloc[-1]:.0f} $, покрывает падение ≈ {(1 - cov) * 100:.1f}% от старта")
    gate = rsi_gate(d)
    for fee, fname in ((0.0003, "как в боте 0.03%"), (0.0005, "taker OKX 0.05%")):
        r = run(d, fee, gate)
        say(""); say(f"=== комиссия {fname} ===")
        say(f"  итог закрытых {r['total']:+.2f} $ · открытая {r['open_un']:+.2f} $ · тейков бота {r['bot_tp']} · циклов {r['cycles']} · "
            f"комиссии {r['fees']:.2f} $")
        say(f"  макс. ордеров {r['max_orders']} (позиция до {r['max_notional']:.0f} $) · худшая просадка позиции "
            f"{r['worst_unreal']:.2f} $" + (f" ({pd.to_datetime(r['worst_t'], unit='ms'):%Y-%m-%d})" if r["worst_t"] else "")
            + f" · самый долгий цикл {r['longest_h']:.0f} ч")
        if r.get("open"):
            say("  " + r["open"])
        say("  по месяцам: " + "  ".join(f"{m} {v:+.2f}" for m, v in sorted(r["monthly"].items())))
    say("")
    say("Стопа у бота нет: при падении HYPE больше ~19% сетка кончается и позиция висит в минусе до возврата цены.")
    say("Это приближение: сверяй с историей бота в GinArea.")
    OUT.parent.mkdir(exist_ok=True)
    OUT.write_text("\n".join(LINES), encoding="utf-8")
    print(f"\nОтчёт: {OUT}")


if __name__ == "__main__":
    main()
