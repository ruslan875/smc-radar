"""ofi_download.py — 2026-11-07. Скачивает ленту сделок Bybit (public.bybit.com/trading) за ~2 года по 8 монетам
и сразу сворачивает каждый день в 4-часовые итоги потока ордеров: объём агрессивных покупок/продаж, число сделок.
Сырые файлы не сохраняются (только итоги, мегабайты). Повторный запуск продолжает с того места, где остановился.
Итог: market_cache/ofi/<SYM>_4h.csv (t, buy, sell, buy_usd, sell_usd, n). Лог: logs/ofi_download.log
"""
from __future__ import annotations

import datetime as dt
import gzip
import io
import json
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

import pandas as pd
import requests

BASE = Path(__file__).resolve().parent
OUT = BASE / "market_cache" / "ofi"
STATE = OUT / "_done.json"
COINS = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT", "DOGEUSDT", "BNBUSDT", "ADAUSDT", "AVAXUSDT"]
START = dt.date(2024, 11, 1)
H4 = 4 * 3600


def log(msg: str) -> None:
    print(time.strftime("%H:%M:%S"), msg, flush=True)


def one(sym: str, day: dt.date):
    url = f"https://public.bybit.com/trading/{sym}/{sym}{day.isoformat()}.csv.gz"
    for k in range(4):
        try:
            r = requests.get(url, timeout=120)
            if r.status_code == 404:
                return sym, day, None, "нет файла"
            r.raise_for_status()
            d = pd.read_csv(io.BytesIO(gzip.decompress(r.content)), usecols=["timestamp", "side", "size", "price"])
            d["b"] = (d.timestamp.astype(float) // H4 * H4).astype("int64") * 1000
            d["usd"] = d["size"] * d["price"]
            buy = d.side == "Buy"
            g = pd.DataFrame({"t": d.b, "buy": d["size"].where(buy, 0.0), "sell": d["size"].where(~buy, 0.0),
                              "buy_usd": d.usd.where(buy, 0.0), "sell_usd": d.usd.where(~buy, 0.0), "n": 1}).groupby("t").sum().reset_index()
            return sym, day, g, None
        except Exception as exc:  # noqa: BLE001
            err = str(exc)[:120]; time.sleep(3 * (k + 1))
    return sym, day, None, err


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    done = set(json.loads(STATE.read_text())) if STATE.exists() else set()
    end = dt.date.today() - dt.timedelta(days=1)
    days = [START + dt.timedelta(days=i) for i in range((end - START).days + 1)]
    todo = [(s, d) for s in COINS for d in days if f"{s}:{d}" not in done]
    log(f"всего дней×монет {len(days) * len(COINS)}, осталось {len(todo)}")
    t0 = time.time(); k = 0
    with ThreadPoolExecutor(4) as ex:
        for sym, day, g, err in ex.map(lambda x: one(*x), todo):
            k += 1
            if g is not None:
                f = OUT / f"{sym}_4h.csv"
                g.to_csv(f, mode="a", header=not f.exists(), index=False)
                done.add(f"{sym}:{day}")
            elif err == "нет файла":
                done.add(f"{sym}:{day}")
            else:
                log(f"{sym} {day}: ошибка {err}")
            if k % 20 == 0 or k == len(todo):
                STATE.write_text(json.dumps(sorted(done)))
                el = time.time() - t0
                log(f"{k}/{len(todo)} · {sym} {day} · прошло {el / 60:.0f} мин · осталось ~{el / k * (len(todo) - k) / 60:.0f} мин")
    STATE.write_text(json.dumps(sorted(done)))
    for sym in COINS:   # убрать дубли (повторные запуски) и отсортировать
        f = OUT / f"{sym}_4h.csv"
        if f.exists():
            d = pd.read_csv(f).drop_duplicates(subset="t", keep="last").sort_values("t"); d.to_csv(f, index=False)
    log("ГОТОВО")


if __name__ == "__main__":
    sys.exit(main())
