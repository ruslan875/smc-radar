@echo off
cd /d D:\VANTORIX\bot
venv\Scripts\python.exe my_strategy_test.py
pause
