#!/usr/bin/env python3
"""
Same engine as long_strategy15_latuserge_backtest.py (LONG_STRATEGY 15 by
platform user latuserge), extended 2026-09-05 to answer the one
question that's kept latuserge from being trusted for real leveraged
futures trading despite it being this project's strongest validated
result: what does its DCA grid actually do to a leveraged account's
liquidation risk during a real drawdown?

WHY THIS EXISTS: every P&L number this project has produced for latuserge
(and every other DCA bot) is a PERCENT-RETURN number computed as if the
position could never be forcibly closed early. On leveraged futures that
assumption can be wrong -- if price moves far enough against an open
position before the DCA grid's averaging orders (or the exit) can save
it, the exchange liquidates the position at a loss that has nothing to do
with the backtest's own TP/TIMEOUT exit logic. The blog's own published
config for this bot uses 20x leverage; this project's user has confirmed
using 2-5x for their own DCA/grid bots on real futures accounts. No
backtest in this project (for latuserge or any of the other 3 DCA
scripts) has modeled this until now.

WHAT'S NEW vs the original script (strategy logic is UNCHANGED -- this is
purely additive instrumentation, not a re-tune):
  - Deal gains two new fields: `worst_mae_pct` and `worst_mae_time`.
    `worst_mae_pct` is the deal's worst-ever percent drawdown relative to
    the ACTUAL average entry price AT THAT MOMENT (i.e., using only the
    grid orders that had already filled by that point in time -- not the
    deal's final blended average applied retroactively, which would be
    optimistic since the position was smaller and less-averaged earlier
    in the drawdown). This is computed bar-by-bar during the existing
    walk-forward simulation loop, using the same low[] series the grid's
    own order-fill logic already reads -- no re-fetch, no separate pass.
  - A new `leverage_risk_summary()` translates that MAE% into an
    ASSUMED/approximate liquidation-risk read at several leverage levels
    (2x/3x/5x -- the user's own confirmed real usage -- plus 20x, the
    blog's own published leverage, for comparison). The liquidation
    threshold used is the standard simplified formula
    approx_liq_move_pct = 100/leverage, which ignores maintenance-margin
    rate (typically ~0.4-1% for major linear perpetuals on Bybit/OKX --
    small next to the gaps between 2x/3x/5x/20x, but it does mean the
    real liquidation threshold is a little TIGHTER than this number, not
    looser) and assumes ISOLATED margin sized so that leverage is the
    only lever on liquidation distance -- CROSS margin (still an
    unconfirmed, open question for this project's actual account
    per claude/dca-bot-reverse-engineering-2026-09-04.md) can behave very
    differently, since other account equity can absorb the same drawdown
    without triggering liquidation at all. Treat every leverage-risk
    number in this script's output as a DIRECTIONAL estimate of relative
    risk across leverage levels and across the 4 DCA bots, not a precise
    real-money liquidation forecast.

Needs network access to Bybit's public API -- run on your own machine:

    python long_strategy15_latuserge_mae_backtest.py --symbol ETHUSDT SOLUSDT ARBUSDT INJUSDT TIAUSDT --bars 500000
"""
from __future__ import annotations

import argparse
import csv
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import numpy as np
import pandas as pd
import requests

from app.data import BYBIT_BASE, INTERVAL_MAP, DataError
from app.indicators.common import cci, rsi, ema, sma, stdev, dmi_adx
from app.indicators.veles_style import atr_percent, keltner_channel, htf_closed_series

# CONFIRMED 2026-09-04 from real account fee screenshots (both exchanges,
# futures only -- this account does not trade spot). Round-trip rates
# (entry+exit combined), replacing the old generic placeholder guess.
FEE_SCENARIOS = {
    "bybit_taker+taker": 0.0018,
    "bybit_taker+maker": 0.001224,
    "bybit_maker+maker": 0.000648,
    "okx_taker+taker": 0.0010,
    "okx_taker+maker": 0.0007,
    "okx_maker+maker": 0.0004,
}

# ASSUMED/approximate leverage levels to evaluate liquidation risk at.
# 2/3/5x = user's own confirmed real usage on this project's live
# accounts. 20x = the latuserge blog post's own published config, kept
# here purely as a reference point for "what if run exactly as published."
LEVERAGES_TO_CHECK = [2, 3, 5, 20]


# --------------------------------------------------------------- data --

def _fetch_page(params: dict, symbol: str, retries: int = 4, timeout: float = 15.0) -> dict:
    # Same rate-limit-aware retry patch as every other script in this
    # project (2026-09-05): Bybit's rate limit error is a normal HTTP 200
    # with retCode != 0, not a network exception -- retry on both.
    last_exc: Exception | None = None
    for attempt in range(retries):
        try:
            resp = requests.get(f"{BYBIT_BASE}/v5/market/kline", params=params, timeout=timeout)
            resp.raise_for_status()
            payload = resp.json()
            if payload.get("retCode") == 0:
                return payload
            last_exc = RuntimeError(f"retCode={payload.get('retCode')} {payload.get('retMsg')}")
        except requests.RequestException as exc:
            last_exc = exc
        if attempt < retries - 1:
            time.sleep(1.5 * (attempt + 1))
    raise DataError(f"Bybit request failed for {symbol} after {retries} attempts: {last_exc}")


def fetch_history(symbol: str, timeframe: str, total_bars: int, category: str = "linear") -> pd.DataFrame:
    interval = INTERVAL_MAP[timeframe]
    all_rows: list = []
    end = None
    while len(all_rows) < total_bars:
        params = {"category": category, "symbol": symbol, "interval": interval, "limit": 1000}
        if end is not None:
            params["end"] = end
        payload = _fetch_page(params, symbol)
        if payload.get("retCode") != 0:
            raise DataError(f"Bybit API error for {symbol}: {payload.get('retMsg')}")
        rows = payload["result"]["list"]
        if not rows:
            break
        all_rows.extend(rows)
        oldest_ts = int(rows[-1][0])
        end = oldest_ts - 1
        if len(rows) < 1000:
            break
        time.sleep(0.6)

    if not all_rows:
        raise DataError(f"No kline data returned for {symbol} {timeframe}")

    df = pd.DataFrame(all_rows, columns=["open_time", "open", "high", "low", "close", "volume", "turnover"])
    df["open_time"] = df["open_time"].astype("int64")
    df = df.drop_duplicates(subset="open_time")
    for col in ("open", "high", "low", "close", "volume", "turnover"):
        df[col] = df[col].astype(float)
    df["open_time"] = pd.to_datetime(df["open_time"], unit="ms", utc=True)
    df = df.sort_values("open_time").reset_index(drop=True)
    if len(df) > total_bars:
        df = df.tail(total_bars).reset_index(drop=True)

    if len(df) > 1:
        step_seconds = df["open_time"].diff().dt.total_seconds()
        expected_step = step_seconds.median()
        max_gap = step_seconds.max()
        max_gap_idx = step_seconds.idxmax()
        span_days = (df["open_time"].iloc[-1] - df["open_time"].iloc[0]).days
        print(f"  [fetch_history] {symbol}: {len(df)} bars, "
              f"{df['open_time'].iloc[0]} -> {df['open_time'].iloc[-1]} "
              f"({span_days} days)")
        if pd.notna(max_gap) and max_gap > expected_step * 3:
            print(f"  [fetch_history] WARNING: {symbol} has a gap of "
                  f"{max_gap/60:.1f} min (expected ~{expected_step/60:.1f} min "
                  f"between bars) right before "
                  f"{df['open_time'].iloc[max_gap_idx]} -- data is likely "
                  f"NON-CONTIGUOUS, treat this run's results as unreliable "
                  f"until re-fetched.")
    return df


# ----------------------------------------------------------- indicators --

def cmo(close: pd.Series, length: int) -> pd.Series:
    diff = close.diff()
    up = diff.clip(lower=0)
    down = -diff.clip(upper=0)
    sum_up = up.rolling(length, min_periods=length).sum()
    sum_down = down.rolling(length, min_periods=length).sum()
    total = (sum_up + sum_down).replace(0, np.nan)
    return 100.0 * (sum_up - sum_down) / total


def williams_r(df: pd.DataFrame, length: int) -> pd.Series:
    hh = df["high"].rolling(length, min_periods=length).max()
    ll = df["low"].rolling(length, min_periods=length).min()
    return (hh - df["close"]) / (hh - ll).replace(0, np.nan) * -100.0


def bollinger_lower(close: pd.Series, length: int, mult: float) -> pd.Series:
    basis = sma(close, length)
    return basis - mult * stdev(close, length)


# ------------------------------------------------------------- params --

GRID = [
    (0.04, 6.66),
    (6.0, 8.0),
    (15.0, 13.0),
    (28.0, 16.0),
    (40.0, 30.0),
    (65.0, 26.34),
]


@dataclass
class Params:
    cci_length: int
    cmo_length: int
    wr_length: int
    bb_length: int
    bb_mult: float
    atr_length: int
    adx_di_length: int
    adx_smoothing: int
    kc_length: int
    kc_mult: float
    cci_order_threshold: float
    mrc_length: int
    min_pnl_pct: float
    use_rsi_filter: bool
    rsi_length: int
    max_deal_bars: int


@dataclass
class Deal:
    symbol: str
    entry_time: pd.Timestamp
    exit_time: pd.Timestamp | None
    orders_filled: int
    filled_pct: float
    avg_entry_price: float
    exit_price: float | None
    reason: str  # "TP" | "TIMEOUT" | "OPEN_AT_CUTOFF"
    bars_held: int
    gross_pnl_pct: float | None
    worst_mae_pct: float  # NEW 2026-09-05: worst-ever %% underwater vs. the
                           # actual running average entry price at that moment
    meta: dict = field(default_factory=dict)


def compute_indicators(df: pd.DataFrame, p: Params) -> dict:
    cci_1h = htf_closed_series(df, 60, lambda h: cci((h["high"] + h["low"] + h["close"]) / 3, p.cci_length))
    cmo_30m = htf_closed_series(df, 30, lambda h: cmo(h["close"], p.cmo_length))
    wr_30m = htf_closed_series(df, 30, lambda h: williams_r(h, p.wr_length))
    bb_low_15m = htf_closed_series(df, 15, lambda h: bollinger_lower(h["close"], p.bb_length, p.bb_mult))
    close_15m = htf_closed_series(df, 15, lambda h: h["close"])
    atr_pct_5m = htf_closed_series(df, 5, lambda h: atr_percent(h, p.atr_length))

    entry_raw = (
        (cci_1h < 80) & (cmo_30m > -90) & (wr_30m < -80) &
        (close_15m < bb_low_15m) & (atr_pct_5m > 0.5)
    )
    if p.use_rsi_filter:
        rsi_1m = rsi(df["close"], p.rsi_length)
        entry_raw = entry_raw & (rsi_1m < 30)
    entry_raw = entry_raw.fillna(False)
    entry_signal = entry_raw & ~entry_raw.shift(1).fillna(False)

    defined_parts = [cci_1h.notna(), cmo_30m.notna(), wr_30m.notna(), bb_low_15m.notna(), atr_pct_5m.notna()]
    entry_defined = defined_parts[0]
    for d in defined_parts[1:]:
        entry_defined = entry_defined & d

    adx_15m = htf_closed_series(df, 15, lambda h: dmi_adx(h, p.adx_di_length, p.adx_smoothing))
    bb_low_5m = htf_closed_series(df, 5, lambda h: bollinger_lower(h["close"], p.bb_length, p.bb_mult))
    close_5m = htf_closed_series(df, 5, lambda h: h["close"])
    kc_low_5m_htf = htf_closed_series(df, 5, lambda h: keltner_channel(h, length=p.kc_length, mult=p.kc_mult)[2])
    cci_1m = cci((df["high"] + df["low"] + df["close"]) / 3, p.cci_length)

    order_conditions: dict[int, pd.Series] = {
        2: ((adx_15m > 40) & (cmo_30m > -90)).fillna(False),
        3: ((close_5m < bb_low_5m) & (cmo_30m > -90)).fillna(False),
        4: ((df["close"] < kc_low_5m_htf) & (cmo_30m > -90)).fillna(False),
        5: ((cci_1m < p.cci_order_threshold) & (cmo_30m > -90)).fillna(False),
        6: ((cci_1m < p.cci_order_threshold) & (cmo_30m > -90)).fillna(False),
    }

    mrc_basis_5m = htf_closed_series(df, 5, lambda h: ema(h["close"], p.mrc_length))
    tp_signal = (df["close"] > mrc_basis_5m).fillna(False)

    return {
        "entry_signal": entry_signal, "entry_defined": entry_defined,
        "order_conditions": order_conditions, "tp_signal": tp_signal,
    }


# --------------------------------------------------------- walk-forward --

def simulate_symbol(df: pd.DataFrame, symbol: str, p: Params) -> list[Deal]:
    ind = compute_indicators(df, p)
    entry_signal = ind["entry_signal"]
    entry_defined = ind["entry_defined"]
    order_conditions = ind["order_conditions"]
    tp_signal = ind["tp_signal"]

    n = len(df)
    first_valid = entry_defined.idxmax() if entry_defined.any() else None
    if first_valid is None:
        return []

    close = df["close"].to_numpy()
    low = df["low"].to_numpy()

    deals: list[Deal] = []
    i = int(first_valid)
    in_deal = False
    orders: list[dict] = []
    next_order_idx = 2
    base_price = 0.0
    deal_start_bar = -1
    worst_mae_pct = 0.0

    def avg_entry_and_filled_pct():
        total_vol = sum(o["vol_pct"] for o in orders)
        weighted = sum(o["vol_pct"] * o["price"] for o in orders)
        return (weighted / total_vol), total_vol

    while i < n:
        if not in_deal:
            if bool(entry_signal.iloc[i]):
                base_price = close[i]
                orders = [{"price": base_price, "vol_pct": GRID[0][1]}]
                next_order_idx = 2
                deal_start_bar = i
                in_deal = True
                # NEW: capture any intrabar dip on the entry bar itself,
                # against the only order that exists at that instant
                # (order 1, i.e. base_price).
                worst_mae_pct = max(0.0, (base_price - low[i]) / base_price * 100.0)
            i += 1
            continue

        if next_order_idx <= len(GRID):
            eff_offset, vol_pct = GRID[next_order_idx - 1]
            limit_price = base_price * (1 - eff_offset / 100.0)
            cond = order_conditions.get(next_order_idx)
            cond_true = bool(cond.iloc[i]) if cond is not None else True
            if low[i] <= limit_price and cond_true:
                orders.append({"price": limit_price, "vol_pct": vol_pct})
                next_order_idx += 1

        avg_entry, filled_pct = avg_entry_and_filled_pct()

        # NEW: this bar's drawdown vs. the ACTUAL average entry price as of
        # THIS point in time (only orders filled so far) -- not the deal's
        # eventual final average, which would understate how underwater
        # the position was before later grid orders filled and averaged
        # the cost basis down.
        bar_dd_pct = (avg_entry - low[i]) / avg_entry * 100.0
        if bar_dd_pct > worst_mae_pct:
            worst_mae_pct = bar_dd_pct

        pnl_now = (close[i] - avg_entry) / avg_entry * 100.0

        closed = False
        if bool(tp_signal.iloc[i]) and pnl_now >= p.min_pnl_pct:
            deals.append(Deal(
                symbol=symbol, entry_time=df["open_time"].iloc[deal_start_bar],
                exit_time=df["open_time"].iloc[i], orders_filled=len(orders),
                filled_pct=filled_pct, avg_entry_price=avg_entry, exit_price=close[i],
                reason="TP", bars_held=i - deal_start_bar, gross_pnl_pct=pnl_now,
                worst_mae_pct=worst_mae_pct,
            ))
            closed = True
        elif (i - deal_start_bar) >= p.max_deal_bars:
            deals.append(Deal(
                symbol=symbol, entry_time=df["open_time"].iloc[deal_start_bar],
                exit_time=df["open_time"].iloc[i], orders_filled=len(orders),
                filled_pct=filled_pct, avg_entry_price=avg_entry, exit_price=close[i],
                reason="TIMEOUT", bars_held=i - deal_start_bar, gross_pnl_pct=pnl_now,
                worst_mae_pct=worst_mae_pct,
            ))
            closed = True

        if closed:
            in_deal = False
            orders = []
            worst_mae_pct = 0.0
        i += 1

    if in_deal:
        avg_entry, filled_pct = avg_entry_and_filled_pct()
        last_close = close[-1]
        gross = (last_close - avg_entry) / avg_entry * 100.0
        deals.append(Deal(
            symbol=symbol, entry_time=df["open_time"].iloc[deal_start_bar],
            exit_time=df["open_time"].iloc[-1], orders_filled=len(orders),
            filled_pct=filled_pct, avg_entry_price=avg_entry, exit_price=last_close,
            reason="OPEN_AT_CUTOFF", bars_held=(n - 1) - deal_start_bar, gross_pnl_pct=gross,
            worst_mae_pct=worst_mae_pct,
        ))

    return deals


# --------------------------------------------------------------- report --

def net_pnl_pct(deal: Deal, fee_rate: float) -> float | None:
    if deal.gross_pnl_pct is None:
        return None
    return deal.gross_pnl_pct - fee_rate * 100.0


def summarize(deals: list[Deal], label: str) -> None:
    if not deals:
        print(f"\n{label}: no deals opened in this window.")
        return
    resolved = [d for d in deals if d.reason in ("TP", "TIMEOUT")]
    still_open = [d for d in deals if d.reason == "OPEN_AT_CUTOFF"]
    wins = [d for d in resolved if d.gross_pnl_pct is not None and d.gross_pnl_pct > 0]
    win_rate = (len(wins) / len(resolved) * 100) if resolved else float("nan")
    avg_gross = (sum(d.gross_pnl_pct for d in resolved) / len(resolved)) if resolved else float("nan")
    avg_orders = (sum(d.orders_filled for d in deals) / len(deals)) if deals else float("nan")

    print(f"\n{label}")
    print(f"  Total deals opened:      {len(deals)}")
    print(f"  Resolved (TP/timeout):   {len(resolved)}   Still open at cutoff: {len(still_open)}")
    print(f"  Avg orders filled/deal:  {avg_orders:.2f}")
    print(f"  Gross win rate:          {win_rate:.1f}%")
    print(f"  Gross avg P&L% (invested):{avg_gross:+.2f}%")
    reasons = {}
    for d in resolved:
        reasons[d.reason] = reasons.get(d.reason, 0) + 1
    print(f"  Exit reasons: {reasons}")

    for label_fee, fee_rate in FEE_SCENARIOS.items():
        nets = [net_pnl_pct(d, fee_rate) for d in resolved]
        nets = [x for x in nets if x is not None]
        if not nets:
            continue
        net_wins = sum(1 for x in nets if x > 0)
        print(f"    net P&L% after {label_fee:12s} fees: {sum(nets)/len(nets):+.2f}%  "
              f"win rate {net_wins/len(nets)*100:.1f}%")


def leverage_risk_summary(deals: list[Deal], label: str, leverages=LEVERAGES_TO_CHECK) -> None:
    """NEW 2026-09-05. Translates each deal's worst_mae_pct into an
    ASSUMED/approximate liquidation-risk read at several leverage levels.
    See module docstring for the exact approximation and its caveats
    (ignores maintenance margin, assumes isolated margin) -- this is a
    directional risk comparison across leverage levels, not a precise
    real-money liquidation forecast."""
    if not deals:
        return
    maes = [d.worst_mae_pct for d in deals]
    n = len(maes)
    avg_mae = sum(maes) / n
    max_mae = max(maes)
    worst_deal = max(deals, key=lambda d: d.worst_mae_pct)

    print(f"\n  --- LEVERAGE RISK (MAE-based, ASSUMED/approximate) -- {label} ---")
    print(f"  n={n}  avg worst-MAE/deal={avg_mae:.2f}%  max worst-MAE={max_mae:.2f}% "
          f"(symbol={worst_deal.symbol}, entry={worst_deal.entry_time})")
    for lev in leverages:
        approx_liq_pct = 100.0 / lev
        at_risk = [d for d in deals if d.worst_mae_pct >= approx_liq_pct]
        pct_at_risk = len(at_risk) / n * 100.0
        print(f"    {lev:>3}x leverage (approx. liq. move ~{approx_liq_pct:5.2f}%): "
              f"{len(at_risk):4d}/{n} deals ({pct_at_risk:5.2f}%) would have breached "
              f"this threshold at some point")


def save_csv(deals: list[Deal], path: Path) -> None:
    if not deals:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = ["symbol", "entry_time", "exit_time", "orders_filled", "filled_pct",
                  "avg_entry_price", "exit_price", "reason", "bars_held", "gross_pnl_pct",
                  "worst_mae_pct"]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for d in deals:
            writer.writerow({k: getattr(d, k) for k in fieldnames})


def split_sample(deals: list[Deal]) -> tuple[list[Deal], list[Deal]]:
    resolved = sorted([d for d in deals if d.reason in ("TP", "TIMEOUT")], key=lambda d: d.entry_time)
    if len(resolved) < 4:
        return resolved, []
    mid = len(resolved) // 2
    return resolved[:mid], resolved[mid:]


# -------------------------------------------------------------------- --

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--symbol", nargs="+", default=["SOLUSDT"])
    parser.add_argument("--timeframe", default="1m")
    parser.add_argument("--bars", type=int, default=200000)
    parser.add_argument("--out", default="long_strategy15_latuserge_mae_backtest_out")

    parser.add_argument("--cci-length", type=int, default=20, help="ASSUMED")
    parser.add_argument("--cmo-length", type=int, default=14, help="ASSUMED")
    parser.add_argument("--wr-length", type=int, default=14, help="ASSUMED")
    parser.add_argument("--bb-length", type=int, default=20, help="ASSUMED")
    parser.add_argument("--bb-mult", type=float, default=2.0, help="ASSUMED")
    parser.add_argument("--atr-length", type=int, default=14, help="ASSUMED")
    parser.add_argument("--adx-di-length", type=int, default=14, help="ASSUMED")
    parser.add_argument("--adx-smoothing", type=int, default=14, help="ASSUMED")
    parser.add_argument("--kc-length", type=int, default=20, help="ASSUMED")
    parser.add_argument("--kc-mult", type=float, default=2.0, help="ASSUMED")
    parser.add_argument("--cci-order-threshold", type=float, default=-100.0, help="ASSUMED -- see module docstring")
    parser.add_argument("--mrc-length", type=int, default=50, help="APPROXIMATED -- see module docstring")

    parser.add_argument("--min-pnl-pct", type=float, default=1.0, help="CONFIRMED from blog post")
    parser.add_argument("--use-rsi-filter", action="store_true")
    parser.add_argument("--rsi-length", type=int, default=14)
    parser.add_argument("--max-deal-bars", type=int, default=50000, help="safety timeout only, not part of the real bot")

    args = parser.parse_args()
    p = Params(
        cci_length=args.cci_length, cmo_length=args.cmo_length, wr_length=args.wr_length,
        bb_length=args.bb_length, bb_mult=args.bb_mult, atr_length=args.atr_length,
        adx_di_length=args.adx_di_length, adx_smoothing=args.adx_smoothing,
        kc_length=args.kc_length, kc_mult=args.kc_mult,
        cci_order_threshold=args.cci_order_threshold, mrc_length=args.mrc_length,
        min_pnl_pct=args.min_pnl_pct, use_rsi_filter=args.use_rsi_filter, rsi_length=args.rsi_length,
        max_deal_bars=args.max_deal_bars,
    )

    print(__doc__)
    print("=" * 78)

    out_dir = Path(args.out)
    all_deals: list[Deal] = []
    for symbol in args.symbol:
        symbol = symbol.upper()
        print(f"\nFetching + simulating {symbol} ({args.bars} bars of {args.timeframe})...")
        try:
            df = fetch_history(symbol, args.timeframe, args.bars)
            deals = simulate_symbol(df, symbol, p)
        except DataError as exc:
            print(f"  [SKIP] {symbol}: {exc}")
            continue
        print(f"  {len(df)} bars, {df['open_time'].iloc[0]} .. {df['open_time'].iloc[-1]}")
        summarize(deals, symbol)
        leverage_risk_summary(deals, symbol)
        save_csv(deals, out_dir / f"{symbol}_deals.csv")

        early, late = split_sample(deals)
        if early and late:
            summarize(early, f"  {symbol} -- EARLY half (split-sample)")
            summarize(late, f"  {symbol} -- LATE half (split-sample)")

        all_deals.extend(deals)
        time.sleep(2.0)  # avoid a rate-limit collision with the live bot on the same API key

    summarize(all_deals, "=== COMBINED (all symbols) ===")
    leverage_risk_summary(all_deals, "COMBINED (all symbols)")
    print(f"\nPer-deal CSVs written to {out_dir.resolve()}")


if __name__ == "__main__":
    main()
