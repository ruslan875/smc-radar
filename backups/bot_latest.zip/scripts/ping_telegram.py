"""
One-off sanity check: confirms TELEGRAM_BOT_TOKEN + TELEGRAM_CHAT_ID in .env
actually work, without waiting for a real market setup to fire.

Run from the project root (venv activated):
    python scripts/ping_telegram.py
"""
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from dotenv import load_dotenv

load_dotenv()

from app.telegram_client import TelegramClient, TelegramError  # noqa: E402

token = os.environ.get("TELEGRAM_BOT_TOKEN", "")
chat_id = os.environ.get("TELEGRAM_CHAT_ID", "")

if not token or "AAExample" in token:
    print("TELEGRAM_BOT_TOKEN is missing or still the placeholder -- check .env")
    sys.exit(1)
if not chat_id or chat_id == "-1001234567890":
    print("TELEGRAM_CHAT_ID is missing or still the placeholder -- check .env")
    sys.exit(1)

client = TelegramClient(token, chat_id)

try:
    me = client.test_connection()
    print(f"getMe OK: bot is @{me['username']} (id {me['id']})")
except TelegramError as e:
    print(f"getMe FAILED: {e}")
    sys.exit(1)

try:
    client.send_message("✅ Тестовое сообщение: SMC-бот подключён и может писать в этот чат.")
    print("sendMessage OK -- check your Telegram chat now.")
except TelegramError as e:
    print(f"sendMessage FAILED: {e}")
    sys.exit(1)