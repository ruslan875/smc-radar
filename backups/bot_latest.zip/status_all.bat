@echo off
cd /d "%~dp0"
chcp 65001 >nul
venv\Scripts\python.exe bot_services.py status
pause
