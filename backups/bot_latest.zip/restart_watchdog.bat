@echo off
cd /d "%~dp0"
venv\Scripts\python.exe bot_services.py stop watchdog
timeout /t 2 >nul
venv\Scripts\python.exe bot_services.py start watchdog
venv\Scripts\python.exe bot_services.py stop panel
timeout /t 2 >nul
venv\Scripts\python.exe bot_services.py start panel
timeout /t 5
