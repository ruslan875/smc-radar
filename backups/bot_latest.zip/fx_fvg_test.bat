@echo off
cd /d %~dp0
if exist venv\Scripts\python.exe (venv\Scripts\python.exe fx_fvg_test.py) else (python fx_fvg_test.py)
