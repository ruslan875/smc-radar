@echo off
chcp 65001 >nul
cd /d D:\VANTORIX\bot
if exist venv\Scripts\python.exe (venv\Scripts\python.exe forum_setup.py) else (python forum_setup.py)
pause
