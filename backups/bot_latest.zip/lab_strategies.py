"""Стратегии из проверки 25 стратегий пользователя (сентябрь 2026) для вкладки «Бэктест» (bt_lab.py)."""
import numpy as np
import pandas as pd
from lab_engine import atr, rsi, sma, ema, adx, rma

NAN = np.nan


def _frame(df):
    s = pd.DataFrame(index=df.index)
    s["side"] = 0; s["sl"] = NAN; s["tp"] = NAN; s["exit"] = 0
    return s


def pivot_high(x, L, R):
    v = x.values; out = np.full(len(v), NAN)
    for i in range(L + R, len(v)):
        c = v[i - R]
        if c == max(v[i - R - L:i + 1]) and c > max(v[i - R + 1:i + 1], default=-np.inf) and c >= max(v[i - R - L:i - R], default=-np.inf):
            out[i] = c
    return pd.Series(out, x.index)


def pivot_low(x, L, R):
    return -pivot_high(-x, L, R)


# 1) Larry Williams Donchian Breakout V4 (без пирамидинга)
def larry_v4(df, rr=2.0, sl_off=0.10, flatN=3, be_trig=1.5, be_off=0.1, tr_trig=2.0, time_exit=50):
    ph = pivot_high(df.high, 2, 4).shift(1).ffill().fillna(0)
    pl = pivot_low(df.low, 2, 4).shift(1).ffill().fillna(0)
    top = np.maximum(ph.rolling(20).max(), df.high.rolling(20).max())
    bot = np.minimum(pl.rolling(20).min(), df.low.rolling(20).min())
    mid = (top + bot) / 2
    flatT = (top.shift(1) == top.shift(2)) & (top.shift(2) == top.shift(3))
    flatB = (bot.shift(1) == bot.shift(2)) & (bot.shift(2) == bot.shift(3))
    brL = flatT & (df.high > top.shift(1)) & (df.high.shift(1) <= top.shift(2))
    brS = flatB & (df.low < bot.shift(1)) & (df.low.shift(1) >= bot.shift(2))
    brL &= (df.high - top.shift(1)) / top.shift(1) * 100 >= 0.2
    brS &= (bot.shift(1) - df.low) / bot.shift(1) * 100 >= 0.2
    lw = sma(df.close - df.close.shift(8), 8) / atr(df, 8) * 50 + 50
    volok = df.volume > sma(df.volume, 30)
    slL, slS = mid * (1 - sl_off / 100), mid * (1 + sl_off / 100)
    chan = (top - bot) / mid * 100 >= 2.0
    L = brL & (lw > 50) & volok & ((df.close - slL).abs() / df.close * 100 <= 3) & chan & (slL < df.close)
    S = brS & (lw <= 50) & volok & ((slS - df.close).abs() / df.close * 100 <= 3) & chan & (slS > df.close)
    s = _frame(df)
    s.loc[L, "side"] = 1; s.loc[L, "sl"] = slL[L]; s.loc[L, "tp"] = df.close[L] + rr * (df.close[L] - slL[L])
    s.loc[S & ~L, "side"] = -1; s.loc[S & ~L, "sl"] = slS[S]; s.loc[S & ~L, "tp"] = df.close[S] - rr * (slS[S] - df.close[S])
    c, m = df.close.values, mid.values

    def manage(i, pos, ep, sl):
        new = NAN
        if pos == 1:
            if c[i] >= ep * (1 + be_trig / 100): new = ep * (1 + be_off / 100)
            if c[i] >= ep * (1 + tr_trig / 100): new = max(new if not np.isnan(new) else -1e18, m[i])
        else:
            if c[i] <= ep * (1 - be_trig / 100): new = ep * (1 - be_off / 100)
            if c[i] <= ep * (1 - tr_trig / 100): new = min(new if not np.isnan(new) else 1e18, m[i])
        return new
    s.attrs["manage"] = manage; s.attrs["max_bars"] = time_exit
    return s


# 2) Gaussian Channel v6 (только лонг)
def _gauss(src, alpha, poles):
    x = 1 - alpha; v = src.values; f = np.zeros(len(v))
    from math import comb
    for i in range(len(v)):
        acc = alpha ** poles * (0 if np.isnan(v[i]) else v[i])
        for k in range(1, poles + 1):
            if i - k >= 0:
                acc += (-1) ** (k + 1) * comb(poles, k) * x ** k * f[i - k]
        f[i] = acc
    return pd.Series(f, src.index)


def gaussian(df, poles=4, per=144, mult=1.414):
    beta = (1 - np.cos(4 * np.arcsin(1) / per)) / (1.414 ** (2 / poles) - 1)
    alpha = -beta + np.sqrt(beta ** 2 + 2 * beta)
    hlc3 = (df.high + df.low + df.close) / 3
    pc = df.close.shift()
    tr = pd.concat([df.high - df.low, (df.high - pc).abs(), (df.low - pc).abs()], axis=1).max(axis=1)
    f, ft = _gauss(hlc3, alpha, poles), _gauss(tr, alpha, poles)
    up = f + ft * mult
    r = rsi(df.close, 14)
    k = sma(100 * (r - r.rolling(14).min()) / (r.rolling(14).max() - r.rolling(14).min()), 3)
    L = (f > f.shift()) & (df.close > up) & ((k >= 80) | (k <= 20))
    s = _frame(df)
    s.loc[L, "side"] = 1
    s.loc[(df.close < up) & (df.close.shift() >= up.shift()), "exit"] = 1
    return s


# 3) Chandelier Exit + ZLSMA
def ce_zlsma(df, n=22, mult=3.0, zl=32, tp_pct=1.0):
    a = mult * atr(df, n)
    hc, lc = df.close.rolling(n).max(), df.close.rolling(n).min()
    ls_raw, ss_raw = (hc - a).values, (lc + a).values
    c = df.close.values
    ls = np.copy(ls_raw); ss = np.copy(ss_raw); d = np.ones(len(c), int)
    for i in range(1, len(c)):
        lp = ls[i - 1] if not np.isnan(ls[i - 1]) else ls[i]
        sp = ss[i - 1] if not np.isnan(ss[i - 1]) else ss[i]
        if c[i - 1] > lp: ls[i] = max(ls[i], lp)
        if c[i - 1] < sp: ss[i] = min(ss[i], sp)
        d[i] = 1 if c[i] > sp else (-1 if c[i] < lp else d[i - 1])
    d = pd.Series(d, df.index)
    buy, sell = (d == 1) & (d.shift() == -1), (d == -1) & (d.shift() == 1)

    def linreg(s, n):
        idx = np.arange(n)
        return s.rolling(n).apply(lambda y: np.polyval(np.polyfit(idx, y, 1), n - 1), raw=True)
    l1 = linreg(df.close, zl); l2 = linreg(l1, zl); z = l1 + (l1 - l2)
    L, S = buy & (df.close > z), sell & (df.close < z)
    s = _frame(df)
    s.loc[L, "side"] = 1; s.loc[L, "sl"] = df.low.shift()[L] * 0.9999; s.loc[L, "tp"] = df.close[L] * (1 + tp_pct / 100)
    s.loc[S, "side"] = -1; s.loc[S, "sl"] = df.high.shift()[S] * 1.0001; s.loc[S, "tp"] = df.close[S] * (1 - tp_pct / 100)
    s.loc[df.close < z, "exit"] = 1; s.loc[df.close > z, "exit"] = -1
    return s


# 4) High-Low Cloud Trend (cloud-retest, только по тренду, переворот)
def hl_cloud(df, n=35):
    H, Lw = df.high.rolling(n).max(), df.low.rolling(n).min()
    H1, L1 = df.high.rolling(round(n / 4)).max(), df.low.rolling(round(n / 4)).min()
    piv = np.full(len(df), NAN); hv, lv, hh, ll = df.high.values, df.low.values, H.values, Lw.values
    for i in range(len(df)):
        prev = 0 if i == 0 or np.isnan(piv[i - 1]) else piv[i - 1]
        piv[i] = hh[i] if lv[i] == ll[i] else (ll[i] if hv[i] == hh[i] else prev)
    piv = pd.Series(piv, df.index)
    up = df.close > piv
    band = np.where(up, Lw, H); band1 = pd.Series(np.where(up, L1, H1), df.index); band = pd.Series(band, df.index)
    bull = up & (df.close > band) & (df.low <= band1) & (df.low.shift() > band1.shift()) & (df.close > df.open)
    bear = ~up & (df.close < band) & (df.high >= band1) & (df.high.shift() < band1.shift()) & (df.close < df.open)
    s = _frame(df)
    s.loc[bull, "side"] = 1; s.loc[bear, "side"] = -1
    s.attrs["reverse"] = True
    return s


# 5) Ichimoku Cross > EMA (всегда в рынке)
def ichimoku(df, conv=20, base=60, emaN=142):
    dc = lambda n: (df.low.rolling(n).min() + df.high.rolling(n).max()) / 2
    cl, bl, e = dc(conv), dc(base), ema(df.close, emaN)
    L, S = (cl > bl) & (df.close > e), (cl < bl) & (df.close < e)
    s = _frame(df)
    s.loc[L, "side"] = 1; s.loc[S, "side"] = -1
    s.loc[S, "exit"] = 1; s.loc[L, "exit"] = -1
    return s


# 6) S&R Power — система B ("ромб"), фильтр зоны, тейк/стоп % (15m набор из отчёта)
def sr_power(df, length=130, tpL=1.3, slL=0.65, tpS=1.3, slS=0.65):
    a = atr(df, 200) * 0.5
    mx, mn = df.high.rolling(length).max(), df.low.rolling(length).min()
    buyTop, sellBot = mn + a, mx - a
    dL = (df.low.shift(1) > buyTop) & (df.low.shift(2) <= buyTop)
    dS = (df.high.shift(1) < sellBot) & (df.high.shift(2) >= sellBot)
    s = _frame(df)
    s.loc[dL, "side"] = 1; s.loc[dL, "sl"] = df.close[dL] * (1 - slL / 100); s.loc[dL, "tp"] = df.close[dL] * (1 + tpL / 100)
    s.loc[dS & ~dL, "side"] = -1; s.loc[dS, "sl"] = df.close[dS] * (1 + slS / 100); s.loc[dS, "tp"] = df.close[dS] * (1 - tpS / 100)
    s.loc[dS, "exit"] = 1; s.loc[dL, "exit"] = -1  # "Close" на встречный сигнал
    return s


# 7) ETH RSI Trend Filter — ИСПРАВЛЕНО: настоящий стоп 2*ATR, трейлинг 1.5 ATR после +2 ATR, выход RSI 50
def eth_rsi(df):
    r, m, a = rsi(df.close, 14), sma(df.close, 20), atr(df, 14)
    L = (r > 70) & (r.shift() <= 70) & (df.close > m)
    S = (r < 30) & (r.shift() >= 30) & (df.close < m)
    s = _frame(df)
    s.loc[L, "side"] = 1; s.loc[L, "sl"] = (df.close - 2 * a)[L]
    s.loc[S, "side"] = -1; s.loc[S, "sl"] = (df.close + 2 * a)[S]
    s.loc[(r < 50) & (r.shift() >= 50), "exit"] = 1
    s.loc[(r > 50) & (r.shift() <= 50), "exit"] = -1
    c, h, l, av = df.close.values, df.high.values, df.low.values, a.values
    def manage(i, pos, ep, sl):
        if pos == 1 and h[i] >= ep + 2 * av[i]: return h[i] - 1.5 * av[i]
        if pos == -1 and l[i] <= ep - 2 * av[i]: return l[i] + 1.5 * av[i]
        return NAN
    s.attrs["manage"] = manage
    return s


# 8) VSA Precision — ИСПРАВЛЕНО: трейлинг только подтягивается
def vsa(df):
    vma = sma(df.volume, 20); a = atr(df, 14)
    vr = df.volume / vma
    hv = vr > df.volume.rolling(100).quantile(0.75) / vma
    uhv = vr > 2.5
    rng = df.high - df.low
    wide, narrow = rng >= a * 1.2, rng <= a * 0.8
    body = (df.close - df.open).abs(); up, dn = df.close > df.open, df.close < df.open
    e20 = ema(df.close, 20); tu, td = df.close > e20, df.close < e20
    lo10, hi10, lo20 = df.low.rolling(10).min(), df.high.rolling(10).max(), df.low.rolling(20).min()
    mid = (df.high + df.low) / 2
    L = td & ((dn & wide & hv & (df.close > df.low)) | ((df.low <= lo10) & dn & hv & (df.close > df.low)) |
              (dn & narrow & uhv & (df.low <= lo20) & (df.close > df.low) & (body > rng * 0.2)) |
              (narrow & (df.close < df.close.shift()) & hv & ((df.close - mid).abs() <= rng * 0.2)))
    S = tu & ((up & wide & hv & (df.close < df.high)) | ((df.high >= hi10) & up & hv & (df.close < df.high)) |
              (narrow & (df.close > df.close.shift()) & hv & ((df.close - mid).abs() <= rng * 0.2)))
    s = _frame(df)
    s.loc[L, "side"] = 1; s.loc[L, "sl"] = (df.close - 1.5 * a)[L]
    s.loc[S & ~L, "side"] = -1; s.loc[S & ~L, "sl"] = (df.close + 1.5 * a)[S & ~L]
    h, l = df.high.values, df.low.values
    def manage(i, pos, ep, sl):
        if pos == 1 and h[i] >= ep * 1.005: return h[i] * 0.99
        if pos == -1 and l[i] <= ep * 0.995: return l[i] * 1.01
        return NAN
    s.attrs["manage"] = manage
    return s


# 9) ATS Multi v7 (упрощённо: ATR-trail 3 линии + Alligator + KAMA + VWMA + GST-подобный фильтр опущен; вес>=3; стоп 2.5% по close)
def ats_multi(df):
    def trail(p, m):
        src = df.close.values; sl = (m * atr(df, p)).values; t = np.zeros(len(src))
        for i in range(1, len(src)):
            pt = t[i - 1]
            if src[i] > pt and src[i - 1] > pt: t[i] = max(pt, src[i] - sl[i])
            elif src[i] < pt and src[i - 1] < pt: t[i] = min(pt, src[i] + sl[i])
            else: t[i] = src[i] - sl[i] if src[i] > pt else src[i] + sl[i]
        return pd.Series(t, df.index)
    f, md, sl_ = trail(5, 0.5), trail(10, 1.5), trail(20, 3.0)
    atrst = np.where((md > sl_) & (f > md), 1, np.where((md < sl_) & (f < md), -1, 0))
    hl2 = (df.high + df.low) / 2
    jaw, teeth, lips = rma(hl2, 13), rma(hl2, 8), rma(hl2, 5)
    allg = np.where((lips > teeth) & (teeth > jaw) & (df.close > lips), 1, np.where((lips < teeth) & (teeth < jaw) & (df.close < lips), -1, 0))
    vw = (df.close * df.volume).rolling(20).sum() / df.volume.rolling(20).sum()
    vws = np.sign(df.close - vw)
    k1, k2 = ema(df.close, 10), ema(df.close, 24)
    ks = np.sign(k1 - k2)
    lc = 2 * (atrst == 1) + (allg == 1) + (vws > 0) + (ks > 0)
    sc = 2 * (atrst == -1) + (allg == -1) + (vws < 0) + (ks < 0)
    s = _frame(df)
    L, S = lc >= 3, sc >= 3
    s.loc[L, "side"] = 1; s.loc[L, "sl"] = df.close[L] * 0.975
    s.loc[S & ~L, "side"] = -1; s.loc[S & ~L, "sl"] = df.close[S & ~L] * 1.025
    s.loc[S, "exit"] = 1; s.loc[L, "exit"] = -1
    return s


# 10) LE VAN DO — ядро (Heikin Ashi open/close cross) БЕЗ подглядывания, стоп 2 ATR, выход по обратному
def levando_core(df):
    hac = (df.open + df.high + df.low + df.close) / 4
    hao = hac.copy(); v = hac.values; o = np.zeros(len(v)); o[0] = (df.open.iloc[0] + df.close.iloc[0]) / 2
    for i in range(1, len(v)): o[i] = (o[i - 1] + v[i - 1]) / 2
    hao = pd.Series(o, df.index)
    L, S = (hac > hao) & (hac.shift() <= hao.shift()), (hac < hao) & (hac.shift() >= hao.shift())
    a = atr(df, 14)
    s = _frame(df)
    s.loc[L, "side"] = 1; s.loc[L, "sl"] = (df.close - 2 * a)[L]
    s.loc[S, "side"] = -1; s.loc[S, "sl"] = (df.close + 2 * a)[S]
    s.attrs["reverse"] = True
    return s


# 11) S&R Power полный: ромб + фильтр зоны в окне ожидания 3 бара, Close на встречный (15m пресет из отчёта)
def sr_power_full(df, length=130, tp=1.3, sl=0.65, wait=3):
    a = atr(df, 200) * 0.5
    mx, mn = df.high.rolling(length).max(), df.low.rolling(length).min()
    buyTop, sellBot = mn + a, mx - a
    dL = ((df.low.shift(1) > buyTop) & (df.low.shift(2) <= buyTop)).values
    dS = ((df.high.shift(1) < sellBot) & (df.high.shift(2) >= sellBot)).values
    okL, okS = (df.low <= buyTop).values, (df.high >= sellBot).values
    side = np.zeros(len(df), int); pl = ps = -10**9
    for i in range(len(df)):
        if dL[i]: pl = i
        if dS[i]: ps = i
        if i - pl < wait and okL[i]: side[i] = 1; pl = -10**9
        elif i - ps < wait and okS[i]: side[i] = -1; ps = -10**9
    s = _frame(df); c = df.close
    s["side"] = side
    L, S = s.side == 1, s.side == -1
    s.loc[L, "sl"] = c[L] * (1 - sl / 100); s.loc[L, "tp"] = c[L] * (1 + tp / 100)
    s.loc[S, "sl"] = c[S] * (1 + sl / 100); s.loc[S, "tp"] = c[S] * (1 - tp / 100)
    s.loc[S, "exit"] = 1; s.loc[L, "exit"] = -1
    return s
