#!/usr/bin/env python3
"""
Prints the current top-N Bybit USDT perps by 24h turnover (BTC excluded,
same source main.py's top100 scan mode uses), minus the 5 symbols already
in the validated watchlist -- so you get a ready-to-paste --symbol list
for backtest.py that extends the CHoCH+OB+FVG test beyond the original 5
without re-testing what's already known.

Run on your own machine (needs Bybit network access):

    python print_top_symbols.py --top 20
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from app.data import get_top_symbols

ALREADY_VALIDATED = {"ETHUSDT", "SOLUSDT", "ARBUSDT", "INJUSDT", "TIAUSDT"}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--top", type=int, default=20, help="how many top-by-volume symbols to fetch before excluding the already-validated 5")
    args = parser.parse_args()

    symbols = get_top_symbols(args.top, include_btc=False)
    new_symbols = [s for s in symbols if s not in ALREADY_VALIDATED]

    print(f"Top {args.top} by 24h turnover (BTC excluded): {symbols}")
    print(f"\nAlready validated, excluded: {sorted(ALREADY_VALIDATED & set(symbols))}")
    print(f"\nNEW symbols to test ({len(new_symbols)}):")
    print(" ".join(new_symbols))
    print(f"\nReady-to-paste backtest.py command (start small, ~3 months, before committing to a long run):")
    print(f"  python backtest.py --symbol {' '.join(new_symbols)} --bars 8760 --out backtest_out_ext")


if __name__ == "__main__":
    main()
