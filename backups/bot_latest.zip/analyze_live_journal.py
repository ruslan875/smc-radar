#!/usr/bin/env python3
"""
Analyzes the manually-kept `live_trade_journal.csv` log of REAL trades
taken from the `otc_helper_bot_01` Telegram signal cards (the live
delivery layer for `app/smc.py`'s exact entry rule -- see
smc-bot-backtest-2026-08-17.md's "Context" section) after the user's own
manual chart confirmation.

Why this exists: the 2-year backtest of this exact signal logic (Run 10,
`smc-bot-backtest-2026-08-17.md`) found the best-validated version
(OB+FVG confluence + exclude BOS) net-negative in BOTH out-of-sample
halves at every fee scenario, ~25-26% raw win rate -- the standing
recommendation is "screener/discipline-enforcer, not autotrader", i.e.
don't take a card at face value, confirm on the chart first. That manual
confirmation step was never itself backtested (it can't be -- it's a
human judgment call, not a mechanical rule) -- this script measures its
REAL, live, after-the-fact effect: does requiring your own chart
confirmation actually lift the win rate / net R above what the raw
mechanical rule produced, or is it statistically indistinguishable once
enough trades accumulate?

Net R here is computed from REAL numbers (actual entry/stop/qty and
Bybit's own net P&L, already after real fees/funding -- not the
taker+taker/taker+maker/maker+maker fee-scenario assumptions used
throughout the rest of this project for indicators that were never
actually traded). This is more accurate than anything else in the
project, but only once there's enough of it -- see the trust-threshold
warning below.

Usage:

    python analyze_live_journal.py
    python analyze_live_journal.py --journal my_journal.csv --min-split 40
"""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd

# Reference point: Run 10 in smc-bot-backtest-2026-08-17.md, the
# best-validated (still losing) version of this exact entry rule on the
# full 2-year out-of-sample backtest (OB+FVG confluence + exclude BOS,
# n=6514 total setups before filtering, ~246-257 per half after both
# filters). NOT re-derived here -- just quoted as a comparison anchor.
BACKTEST_REFERENCE = {
    "win_rate_pct": 25.5,       # raw mechanical rule, approx across all runs
    "net_r_maker_maker": -0.008,  # closest-to-breakeven half found, still negative
}

MIN_TRUST_N = 20   # same "≥20 trades per half" threshold used everywhere else in this project


def load_journal(path: Path) -> pd.DataFrame:
    df = pd.read_csv(path)
    is_example = df["notes"].fillna("").str.contains("ПРИМЕР", case=False) | \
        df["reason_taken"].fillna("").str.contains("ПРИМЕР", case=False)
    n_example = int(is_example.sum())
    if n_example:
        print(f"[note] Excluding {n_example} example row(s) marked \"ПРИМЕР\" -- "
              f"delete them from the CSV once you have real trades logged.")
    df = df[~is_example].copy()
    df = df[df["symbol"].notna() & (df["symbol"].astype(str).str.strip() != "")]
    return df.reset_index(drop=True)


def compute_stats(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["date_opened"] = pd.to_datetime(df["date_opened"])
    risk_per_unit = (df["entry"] - df["stop_loss"]).abs()
    df["risk_usdt"] = df["qty"].astype(float) * risk_per_unit.astype(float)
    df["net_r"] = np.where(df["risk_usdt"] > 0, df["net_pnl_usdt"] / df["risk_usdt"], np.nan)
    return df


def summarize(df: pd.DataFrame, label: str) -> None:
    n = len(df)
    if n == 0:
        print(f"\n{label}: нет сделок.")
        return
    valid_r = df["net_r"].dropna()
    win_rate = (df["net_pnl_usdt"] > 0).mean() * 100
    total_pnl = df["net_pnl_usdt"].sum()
    avg_r = valid_r.mean() if len(valid_r) else float("nan")
    print(f"\n{label}")
    print(f"  Сделок: {n}   (с валидным R: {len(valid_r)})")
    print(f"  Win rate: {win_rate:.1f}%")
    print(f"  Суммарный net P&L: {total_pnl:+.2f} USDT")
    print(f"  Средний net R (реальный, из факта P&L): {avg_r:+.3f}" if len(valid_r) else "  Средний net R: н/д")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--journal", default="live_trade_journal.csv")
    parser.add_argument("--min-split", type=int, default=2 * MIN_TRUST_N,
                         help="Minimum total trades before attempting an early/late split-sample check")
    args = parser.parse_args()

    path = Path(args.journal)
    if not path.exists():
        print(f"Не найден {path} -- сначала заполни журнал (см. live_trade_journal.csv).")
        return

    raw = load_journal(path)
    df = compute_stats(raw)

    print("=" * 70)
    print(f"Ориентир из 2-летнего бэктеста этой же логики (smc-bot-backtest, Run 10):")
    print(f"  win rate ~{BACKTEST_REFERENCE['win_rate_pct']:.1f}%, "
          f"net R @ maker+maker ~{BACKTEST_REFERENCE['net_r_maker_maker']:+.3f} "
          f"(лучшая найденная версия, всё ещё в минусе)")
    print("=" * 70)

    summarize(df, "ВСЕ РЕАЛЬНЫЕ СДЕЛКИ (после твоего ручного подтверждения)")

    n = len(df)
    if n < MIN_TRUST_N:
        print(f"\n{n} сделок -- меньше {MIN_TRUST_N}, порога доверия, который использовался "
              f"по всему проекту. Любой вывод сейчас будет шумом, не сигналом. Продолжай вести журнал.")
        return

    if n < args.min_split:
        print(f"\n{n} сделок -- достаточно для грубой оценки, но мало для сплит-теста "
              f"(нужно {args.min_split}+, по {MIN_TRUST_N}+ на половину). Продолжай вести журнал.")
        return

    df_sorted = df.sort_values("date_opened")
    cutoff = df_sorted["date_opened"].iloc[len(df_sorted) // 2]
    early = df[df["date_opened"] < cutoff]
    late = df[df["date_opened"] >= cutoff]
    print(f"\n{'=' * 70}\nСПЛИТ-ВАЛИДАЦИЯ (раздел на {cutoff})\n{'=' * 70}")
    summarize(early, "Ранняя половина")
    summarize(late, "Поздняя половина")

    if len(early) < MIN_TRUST_N or len(late) < MIN_TRUST_N:
        print(f"\nОдна из половин меньше {MIN_TRUST_N} сделок -- сплиту пока нельзя доверять, "
              f"но общая цифра выше уже кое-что говорит.")
    else:
        early_r = early["net_r"].dropna().mean()
        late_r = late["net_r"].dropna().mean()
        both_positive = early_r > 0 and late_r > 0
        print(f"\nОбе половины net-положительны: {'ДА' if both_positive else 'НЕТ'} "
              f"(тот же критерий доверия, что и везде в проекте)")


if __name__ == "__main__":
    main()
