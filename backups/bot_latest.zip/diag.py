import json, requests, time
from pathlib import Path
B = Path(__file__).resolve().parent
for path in ("/api/signal_gate", "/api/trade"):
    try:
        r = requests.post("http://127.0.0.1:8766" + path, json={"symbol": "BTCUSDT"}, timeout=10, headers={"Origin": "https://ruslan875.github.io"})
        print("LOCAL", path, r.status_code, r.text[:120], dict((k, v) for k, v in r.headers.items() if "Access" in k))
    except Exception as e:
        print("LOCAL", path, "ERR", e)
try:
    u = requests.get("https://ruslan875.github.io/smc-radar/server_url.json", timeout=20).json().get("url")
    print("URL", u)
    r = requests.options(u + "/api/signal_gate", timeout=20, headers={"Origin": "https://ruslan875.github.io", "Access-Control-Request-Method": "POST"})
    print("TUNNEL OPTIONS", r.status_code, dict(r.headers))
    r = requests.post(u + "/api/signal_gate", json={"symbol": "BTCUSDT"}, timeout=20, headers={"Origin": "https://ruslan875.github.io"})
    print("TUNNEL POST", r.status_code, r.text[:150])
except Exception as e:
    print("TUNNEL ERR", e)
try:
    r = requests.get("https://api.bybit.com/v5/market/time", timeout=15); print("BYBIT", r.status_code)
    r = requests.get("https://api.bybit.com/v5/position/list?category=linear", timeout=15); print("BYBIT private (no key)", r.status_code, r.text[:80])
except Exception as e:
    print("BYBIT ERR", e)
