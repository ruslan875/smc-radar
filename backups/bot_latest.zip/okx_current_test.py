"""okx_current_test.py — 2026-10-17. Все стратегии, которые сейчас стоят на бумаге, — на данных OKX с комиссиями OKX.

Данные: свечи бессрочных контрактов OKX (XXX-USDT-SWAP), публичный API /api/v5/market/history-candles.
Комиссии пользователя на OKX: мейкер 0.02%, тейкер 0.05% (на Bybit было 0.0324% / 0.09%).
Логика стратегий — те же функции, что в тестах Bybit (tg_strats_test3/4, smc_fvg_pack_test, pack_strats_test,
chan_coins_test, high_low_cloud_backtest), меняются только свечи и комиссии.

Стратегии (как у бумажных ботов):
  WhiteBox ShiftMA 1h · QFL DCA 4h · DCA Bot 1h и 4h · DCA Strategy 4h · Ranged Volume DCA 4h
  ChoCh разворот 1h и 4h · RSI+BB лонг 4h + стоп −15% · Liquidity Range MACD 3h (и 2h/4h для сравнения)
  High-Low Cloud 1h + фильтр тренда (SMA 1200) · Пробой канала 4h (N=100, тейк 2R)
2026-10-17 — добавлены ВСЕ остальные бумажные/живые боты (код берётся из самих ботов, где можно):
  Donchian 20 тренд 4h, 3R + умный безубыток (windows_app/donch_paper: _signals, _ema20; цикл = step)
  KVOO волны 4h, 2·ATR, тейк 2R (windows_app/kvoo_paper._signals)
  KC/ROC/CCI/WT грид 1m, последние 30 дней (kc_roc_cci_wt_grid_backtest.simulate_symbol, параметры живого бота):
      новые монеты ADA/LINK/TAO/DOGE/XRP · live ETH/SOL/ARB/INJ/TIA/HYPE · TradFi XAU/XAG/CL · и все 12 монет
  Latuserge (long strategy 15) live 1m, 30 дней (long_strategy15_latuserge_backtest.simulate_symbol) — монеты live, и все 12
  FVG по тренду EMA200 1D, 3R (fvg_test.run = fvg_tradfi_paper.replay) — TradFi OKX и крипта
  Ложный пробой 2 свечи 1D, 3R (windows_app/fb2_tradfi_paper.replay; нужен falsebreak_ind_test)
  Combo OTM XRP 1h, сборка подписчика №2 (combo_full.run + combo_sub2.csv) — XRP и все монеты
  OKX кандидаты: R4 Mirror Fibo HYPE 1h (okx_native_run.r4_run), Pavlova BTC/XRP 1h (pavlova_native.run),
      ETH RSI ETH/XRP 4h (okx_cand_paper.eth_rsi_run) — и на всех монетах для устойчивости
  Генератор: две стратегии библиотеки (strategy_library.json, strategy_gen._entries/_sim, HOLD 96 ч)
  Paper10 (paper_live.py): все 10 родных адаптеров на 1h, комиссия OKX тейкер, проскальзывание 0.03%
Тесты с «только своими монетами» (7-е поле кортежа only=[…]): ✅ = в среднем плюс, обе половины > 0 и ≥ 60% монет в плюсе.
Комиссии OKX: по рынку тейкер 0.05%, лимитки (тейк 3R, сетки, вход FVG в зону) мейкер 0.02%. Вход — как у самого бота
(donch/kvoo/генератор/fb2 — по закрытию сигнальной свечи; combo/paper10 — как в их движках).
Невозможно проверить на истории свечей:
  • бот стакана / отскока от стен (wall_paper, DOM) — нужен живой стакан заявок, в свечах его нет;
  • демо-ручная торговля и webhook-демо (demo_trades, webhook_demo) — это не стратегии, а исполнение чужих/ручных сигналов.
Приближения: стоп Latuserge −75% от цены входа в бэктест-модуле не моделируется (за 30 дней практически недостижим);
сделка, открытая в конце окна, считается по последнему закрытию (KC/ROC, Latuserge);
у R4 нет открытого интереса OKX (передаётся None, фильтр nOI пропускает).
Для каждой: средний % на монету (у канала — R), монет в плюсе, 1-я и 2-я половины истории отдельно.
✅ — в плюсе, ≥ 8/12 монет и обе половины > 0. Ничего не торгует.
Запуск: okx_current_test.bat → bt_lab_bots/okx_current_test.txt
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import numpy as np
import requests

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
OUT = BASE / "bt_lab_bots" / "okx_current_test.txt"
MK, TK = 0.0002, 0.0005
BAR = {"1": "1m", "5": "5m", "15": "15m", "60": "1H", "120": "2H", "240": "4H", "360": "6H", "720": "12H", "D": "1Dutc"}
LINES = []
_cache = {}


def say(s=""):
    print(s, flush=True)
    LINES.append(s)


def okx_klines(sym, code, total):
    """Свечи OKX SWAP, по возрастанию, только закрытые. Формат как у tg_strats_test.klines."""
    key = (sym, code, total)
    if key in _cache:
        return _cache[key]
    inst = sym.replace("USDT", "") + "-USDT-SWAP"
    rows, after = [], None
    while len(rows) < total:
        p = {"instId": inst, "bar": BAR[code], "limit": 100}
        if after:
            p["after"] = after
        j = None
        for k in range(5):
            try:
                j = requests.get("https://www.okx.com/api/v5/market/history-candles", params=p, timeout=20).json()
                if j.get("code") == "0":
                    break
                time.sleep(1.5)
            except requests.RequestException:
                time.sleep(2 * (k + 1))
        lst = (j or {}).get("data") or []
        if not lst:
            break
        rows += [r for r in lst if len(r) < 9 or r[8] == "1"]
        after = lst[-1][0]
        if len(lst) < 100:
            break
        time.sleep(0.11)
    rows = sorted({int(r[0]): r for r in rows}.values(), key=lambda r: int(r[0]))
    if not rows:
        d = {k: np.zeros(0) for k in "tohlcv"}
    else:
        a = np.array([[float(x) for x in r[:6]] for r in rows])
        d = {"t": a[:, 0], "o": a[:, 1], "h": a[:, 2], "l": a[:, 3], "c": a[:, 4], "v": a[:, 5]}
    _cache[key] = d
    return d


# ---------- подмена данных и комиссий в модулях тестов ----------
import tg_strats_test as T  # noqa: E402

T.klines = okx_klines
T.FEE = TK
import tg_strats_test3 as T3  # noqa: E402
import tg_strats_test4 as T4  # noqa: E402
import smc_fvg_pack_test as SM  # noqa: E402
import pack_strats_test as PS  # noqa: E402
import chan_coins_test as CH  # noqa: E402

for m in (T3, T4):
    m.TK, m.MK = TK, MK
SM.TK = TK
PS.TK = TK
CH.FEE = 2 * TK


def half(d, w):
    n = len(d["c"]); m = n // 2; sl = slice(0, m) if w == 0 else slice(m, n)
    return {k: v[sl] for k, v in d.items()}


def acct(fn):          # стратегии tg_strats_test3/4 возвращают кривую счёта
    return lambda d: (fn(d) or [1.0])[-1] - 1


def hlc_trend(d):
    import pandas as pd  # noqa: PLC0415
    import high_low_cloud_backtest as m  # noqa: PLC0415
    idx = pd.to_datetime(d["t"].astype(np.int64), unit="ms", utc=True)
    df = pd.DataFrame({"open": d["o"], "high": d["h"], "low": d["l"], "close": d["c"], "volume": d["v"]}, index=idx)
    df["time"] = df.index
    deals = m.run_backtest(m.compute_signals(df, m.CONFIG), m.CONFIG, tp_pct=0.0, sl_pct=0.0,
                           commission_pct=TK * 100, slippage_pct=0.03, entry_next_open=False)
    if deals is None or len(deals) == 0:
        return 0.0
    sma = PS.sma(d["c"], 1200); tot = 0.0
    for r in deals.to_dict("records"):
        if str(r.get("reason", "")).lower() in ("end_of_data", "eob", "end", "open"):
            continue
        et = pd.Timestamp(r["entry_time"]); et = et.tz_localize("UTC") if et.tzinfo is None else et.tz_convert("UTC")
        i = int(idx.searchsorted(et, side="right")) - 1
        side = 1 if str(r["side"]).lower().startswith("l") else -1
        if i < 0 or np.isnan(sma[i]) or not ((d["c"][i] > sma[i]) if side > 0 else (d["c"][i] < sma[i])):
            continue
        tot += float(r["gross_pnl_pct"]) / 100
    return tot


def chan(d):
    rows = [(int(t), h, l, c) for t, h, l, c in zip(d["t"], d["h"], d["l"], d["c"])]
    return sum(r for _, r in CH.channel(rows))


R3 = lambda d: PS.resample(d, 3)  # noqa: E731
# (название, ТФ-код, свечей, функция → число, единица, преобразование данных)
TESTS = [
    ("WhiteBox ShiftMA 1h", "60", 15000, acct(T3.TESTS["WhiteBox ShiftMA"]), "%", None),
    ("QFL DCA 4h", "240", 6000, acct(T3.TESTS["QFL DCA"]), "%", None),
    ("DCA Bot 1h", "60", 15000, acct(T4.TESTS["DCA Bot"]), "%", None),
    ("DCA Bot 4h", "240", 6000, acct(T4.TESTS["DCA Bot"]), "%", None),
    ("DCA Strategy 4h", "240", 6000, acct(T4.TESTS["DCA Strategy"]), "%", None),
    ("Ranged Volume DCA 4h", "240", 6000, acct(T4.TESTS["Ranged Volume DCA"]), "%", None),
    ("ChoCh разворот 1h", "60", 15000, lambda d: SM.choch(d, 10)[0], "%", None),
    ("ChoCh разворот 4h", "240", 6000, lambda d: SM.choch(d, 10)[0], "%", None),
    ("RSI+BB лонг 4h + стоп −15%", "240", 6000, lambda d: SM.rsi_bb(d, 1, 0.15)[0], "%", None),
    ("Liquidity Range MACD 2h", "120", 9000, lambda d: PS.run_reverse(d, PS.lrm_signals(d))[0], "%", None),
    ("Liquidity Range MACD 3h", "60", 15000, lambda d: PS.run_reverse(d, PS.lrm_signals(d))[0], "%", R3),
    ("Liquidity Range MACD 4h", "240", 6000, lambda d: PS.run_reverse(d, PS.lrm_signals(d))[0], "%", None),
    ("High-Low Cloud 1h + тренд", "60", 15000, hlc_trend, "%", None),
    ("Пробой канала 4h (N100, 2R)", "240", 6000, chan, "R", None),
]


# =====================================================================================================
# 2026-10-17 · остальные бумажные/живые боты. Модули ботов импортируются лениво внутри функций:
# если модуля нет — ошибка по монете, остальной прогон идёт дальше.
# =====================================================================================================
if str(BASE) not in sys.path:
    sys.path.insert(0, str(BASE))


def _idx(d, tz=True):
    import pandas as pd  # noqa: PLC0415
    ix = pd.to_datetime(d["t"].astype(np.int64), unit="ms", utc=True)
    return ix if tz else ix.tz_localize(None)


def df_open_time(d):          # формат kc_roc / latuserge: колонка open_time + open..volume, RangeIndex
    import pandas as pd  # noqa: PLC0415
    return pd.DataFrame({"open_time": _idx(d), "open": d["o"], "high": d["h"], "low": d["l"], "close": d["c"],
                         "volume": d["v"]}).reset_index(drop=True)


def df_paper10(d):            # формат paper_live: DatetimeIndex UTC + колонка time
    import pandas as pd  # noqa: PLC0415
    df = pd.DataFrame({"open": d["o"], "high": d["h"], "low": d["l"], "close": d["c"], "volume": d["v"]}, index=_idx(d))
    df["time"] = df.index
    return df


def df_naive(d):              # формат combo_full: наивный DatetimeIndex, open..volume
    import pandas as pd  # noqa: PLC0415
    return pd.DataFrame({"open": d["o"], "high": d["h"], "low": d["l"], "close": d["c"], "volume": d["v"]},
                        index=_idx(d, False)).astype(float)


def df_short(d):              # формат okx_cand_paper / fvg_test: колонки t,o,h,l,c,v, наивный DatetimeIndex
    import pandas as pd  # noqa: PLC0415
    return pd.DataFrame({"t": d["t"].astype(np.int64), "o": d["o"], "h": d["h"], "l": d["l"], "c": d["c"], "v": d["v"]},
                        index=_idx(d, False))


def _ref(sym, code, nb, d):
    """Свечи опорной монеты (BTC), выровненные по времени d (для половин истории тоже)."""
    b = okx_klines(sym, code, nb)
    keep = (b["t"] >= d["t"][0]) & (b["t"] <= d["t"][-1])
    return {k: v[keep] for k, v in b.items()}


# ---------- 1. Donchian 20 по тренду 4h, тейк 3R (+ умный безубыток) — windows_app/donch_paper ----------
def r_loop(rows, sig, rr, be_ema=None):
    """Пошаговая логика бумажных ботов donch/kvoo: вход по закрытию сигнальной свечи, стоп/тейк по high/low
    следующих свечей (стоп проверяется первым), на свече закрытия новый вход не открывается.
    Комиссии OKX: вход по рынку (TK), тейк лимиткой (MK), стоп/безубыток по рынку (TK). Возврат — сумма R."""
    tot, deal = 0.0, None
    for i, (_t, h, l, c) in enumerate(rows):
        if deal:
            d = deal["side"]; r = None; fee_out = TK
            if (l <= deal["sl"]) if d > 0 else (h >= deal["sl"]):
                r = 0.1 if deal.get("be") else -1.0
            elif (h >= deal["tp"]) if d > 0 else (l <= deal["tp"]):
                r, fee_out = rr, MK
            if r is None and be_ema is not None and not deal.get("be"):     # donch_paper._be_check
                if not deal.get("armed") and ((h >= deal["entry"] + deal["risk"]) if d > 0 else (l <= deal["entry"] - deal["risk"])):
                    deal["armed"] = True
                if deal.get("armed") and ((c < be_ema[i]) if d > 0 else (c > be_ema[i])):
                    deal["sl"] = deal["entry"] + d * 0.1 * deal["risk"]; deal["be"] = True
            if r is not None:
                tot += r - (TK + fee_out) * deal["entry"] / deal["risk"]
                deal = None
        elif i in sig:
            sd, stp = sig[i]; risk = abs(c - stp)
            if risk > 0:
                deal = {"side": sd, "entry": c, "risk": risk, "sl": stp, "tp": c + sd * rr * risk}
    return tot


def _rows4(d):
    return [(int(t), float(h), float(l), float(c)) for t, h, l, c in zip(d["t"], d["h"], d["l"], d["c"])]


def donch4h(d):
    from windows_app import donch_paper as DP  # noqa: PLC0415
    rows = _rows4(d)
    return r_loop(rows, DP._signals(rows), DP.RR, DP._ema20(rows))  # noqa: SLF001


# ---------- 2. KVOO волны 4h, Свинг 2·ATR, тейк 2R — windows_app/kvoo_paper (= kvoo_longtest.signals) ----------
def kvoo4h(d):
    from windows_app import kvoo_paper as KP  # noqa: PLC0415
    rows = _rows4(d)
    return r_loop(rows, {i: (sd, stp) for i, sd, stp in KP._signals(rows)}, KP.RR)  # noqa: SLF001


# ---------- 3. KC/ROC/CCI/WT грид 1m — kc_roc_cci_wt_grid_backtest.simulate_symbol (как tradfi_fee_test.kcroc) ----------
def kcroc_1m(d):
    import kc_roc_cci_wt_grid_backtest as kb  # noqa: PLC0415
    p = kb.Params(grid=kb.parse_grid("0,3", "65,35"), kc_length=20, kc_mult=2.0, roc_length=14, roc_threshold=-1.0,
                  htf1_minutes=15, atr_length=14, atr_min=0.05, atr_max=5.0, htf2_minutes=30, cci_length=20,
                  cci_threshold=-100.0, wt_n1=10, wt_n2=21, wt_avg_len=4, tp_min_pnl_pct=0.5,
                  stop_loss_pct=4.0, max_deal_bars=20000)
    tot = 0.0
    for x in kb.simulate_symbol(df_open_time(d), "X", p):
        if x.gross_pnl_pct is None:      # открытую в конце окна сделку считаем по последней цене (иначе
            continue                     # убыточные «зависшие» сетки выпадают и результат завышается)
        f_in = 0.65 * TK + 0.35 * MK if x.orders_filled > 1 else TK      # 65% по рынку + 35% лимиткой; выход по рынку
        tot += (x.gross_pnl_pct - (f_in + TK) * 100) / 100 * (x.filled_pct / 100)   # доля депозита сделки, что реально вошла
    return tot


# ---------- 4. Latuserge (long strategy 15) 1m — long_strategy15_latuserge_backtest.simulate_symbol ----------
def latuserge_1m(d):
    import long_strategy15_latuserge_backtest as lb  # noqa: PLC0415
    p = lb.Params(cci_length=20, cmo_length=14, wr_length=14, bb_length=20, bb_mult=2.0, atr_length=14,
                  adx_di_length=14, adx_smoothing=14, kc_length=20, kc_mult=2.0, cci_order_threshold=-100.0,
                  mrc_length=50, min_pnl_pct=1.0, use_rsi_filter=False, rsi_length=14, max_deal_bars=10**9)
    tot = 0.0
    for x in lb.simulate_symbol(df_open_time(d), "X", p):
        if x.gross_pnl_pct is None:      # открытую в конце окна сделку считаем по последней цене (иначе
            continue                     # убыточные «зависшие» сетки выпадают и результат завышается)
        # сетка — лимитки (мейкер), выход по закрытию сигнала MRC — по рынку (тейкер); доля = заполненный объём
        tot += (x.gross_pnl_pct - (MK + TK) * 100) / 100 * (x.filled_pct / 100)
    return tot


# ---------- 5. FVG по тренду EMA200, тейк 3R — fvg_test.run (тот же код, что fvg_tradfi_paper.replay) ----------
def fvg_1d(d):
    import fvg_test as FV  # noqa: PLC0415
    FV.COST = MK + TK                    # вход лимиткой в зону (мейкер), выход стоп/тейк/время — считаем тейкером
    return sum(r for _, r in FV.run(df_short(d).reset_index(drop=True), 3, "trend"))


# ---------- 6. Ложный пробой 2 свечи 1D, 3R — windows_app/fb2_tradfi_paper.replay (нужен falsebreak_ind_test) ----------
def fb2_1d(d):
    from windows_app import fb2_tradfi_paper as FB2  # noqa: PLC0415
    FB2.COST = 2 * TK                    # вход по закрытию по рынку, выход по рынку
    return sum(x["r"] for x in FB2.replay(df_short(d).reset_index(drop=True)) if x["status"] == "closed")


# ---------- 7. Combo OTM XRP 1h, сборка подписчика №2 — combo_full.run + combo_sub2.csv ----------
def combo_xrp(d):
    import combo_full as cf  # noqa: PLC0415
    cfg = cf.load_settings_csv(str(BASE / "combo_sub2.csv"))[0]
    ref = df_naive(_ref("BTCUSDT", "60", 15000, d))
    tr, _dd, _eq, _s = cf.run(df_naive(d), cfg, ref, initial_capital=500.0, commission_pct=TK * 100)
    return float(tr["profit"].sum()) / 500.0 if len(tr) else 0.0     # доходность счёта 500 $, 50% на сделку


# ---------- 8. OKX кандидаты — windows_app/okx_cand_paper ----------
def eth_rsi(d):
    from windows_app import okx_cand_paper as OC  # noqa: PLC0415
    t = OC.eth_rsi_run(df_short(d), TK)
    return float(t["r"].sum()) if len(t) else 0.0


def pavlova_native(d):
    from pavlova_native import run  # noqa: PLC0415
    t = run(df_short(d)[["o", "h", "l", "c", "v"]], TK)
    return float(t["r"].sum()) if len(t) else 0.0


def r4_native(d):
    from okx_native_run import r4_run  # noqa: PLC0415
    btc = df_short(_ref("BTCUSDT", "60", 15000, d))
    t = r4_run(df_short(d)[["o", "h", "l", "c", "v"]], None, btc["c"], True)    # открытого интереса OKX нет → None
    return float(t["r"].sum()) if len(t) else 0.0


# ---------- 9. Генератор стратегий — strategy_gen._feats/_entries/_sim (как gen_paper) ----------
def gen_lib(item_id, trig, p, flt, sl, rr, side=1, tf="1h"):
    def fn(d):
        import pandas as pd  # noqa: PLC0415
        import strategy_gen as G  # noqa: PLC0415
        it = next((x for x in G.lib_list() if x.get("id") == item_id), None) or {}
        G.COST = 2 * TK                  # вход по закрытию по рынку, выход стоп/тейк/время — тейкер (с запасом)
        df = pd.DataFrame({"t": d["t"], "o": d["o"], "h": d["h"], "l": d["l"], "c": d["c"], "v": d["v"]})
        F = G._feats(df)  # noqa: SLF001
        sd = int(it.get("side", side))
        idx = G._entries(F, it.get("trig", trig), sd, it.get("p", p), G.FILTERS[it.get("flt", flt)])  # noqa: SLF001
        return sum(r for _, _, r in G._sim(F, idx, sd, float(it.get("sl", sl)), float(it.get("rr", rr)), G.HOLD[tf]))  # noqa: SLF001
    return fn


# ---------- 10. Paper10 (paper_live.py) — родные адаптеры, комиссия OKX тейкер, проскальзывание 0.03% ----------
def paper10(name):
    def fn(d):
        import paper_live as PL  # noqa: PLC0415
        ad = {n: a for n, _m, a, _s in PL.STRATEGIES}[name]
        closed, _open = PL.split_deals(ad(df_paper10(d), TK * 100, 0.03))
        return sum(float(r["gross_pnl_pct"]) for r in closed) / 100
    return fn


KC_NEW = ["ADAUSDT", "LINKUSDT", "TAOUSDT", "DOGEUSDT", "XRPUSDT"]            # kc_newcoins_paper.SYMBOLS
KC_LIVE = ["ETHUSDT", "SOLUSDT", "ARBUSDT", "INJUSDT", "TIAUSDT", "HYPEUSDT"]  # kc_roc_cci_wt_grid_live.DEFAULT_WATCHLIST
KC_TF = ["XAUUSDT", "XAGUSDT", "CLUSDT"]                                      # kc_tradfi_paper.SYMBOLS
LAT_LIVE = ["ETHUSDT", "SOLUSDT", "ARBUSDT", "INJUSDT", "TIAUSDT"]            # long_strategy15_latuserge_live_params.json
KVOO_C = ["XRPUSDT", "BTCUSDT", "TAOUSDT", "DOGEUSDT", "ADAUSDT"]             # kvoo_paper.COINS
DONCH_C = ["BTCUSDT", "ETHUSDT", "XRPUSDT", "DOGEUSDT", "ADAUSDT", "SOLUSDT", "LINKUSDT", "LTCUSDT", "BNBUSDT", "AVAXUSDT"]
GEN1_C = ["TAOUSDT", "XRPUSDT", "HYPEUSDT", "SUIUSDT", "BNBUSDT", "DOTUSDT", "INJUSDT", "SEIUSDT", "ENAUSDT", "WIFUSDT"]
GEN2_C = ["XRPUSDT", "BTCUSDT", "SOLUSDT", "TAOUSDT"]
M1 = 43200                                                                    # 1m × 30 дней

TESTS += [
    ("Donchian 20 тренд 4h (3R, БУ)", "240", 6000, donch4h, "R", None, DONCH_C),
    ("Donchian 20 тренд 4h · все монеты", "240", 6000, donch4h, "R", None),
    ("KVOO волны 4h (2ATR, 2R)", "240", 6000, kvoo4h, "R", None, KVOO_C),
    ("KVOO волны 4h · все монеты", "240", 6000, kvoo4h, "R", None),
    ("KC/ROC новые монеты 1m (30 дн.)", "1", M1, kcroc_1m, "%", None, KC_NEW),
    ("KC/ROC live 1m (30 дн.)", "1", M1, kcroc_1m, "%", None, KC_LIVE),
    ("KC/ROC 1m (30 дн.) · все монеты", "1", M1, kcroc_1m, "%", None),
    ("KC/ROC TradFi 1m (30 дн.)", "1", M1, kcroc_1m, "%", None, KC_TF),
    ("Latuserge live 1m (30 дн.)", "1", M1, latuserge_1m, "%", None, LAT_LIVE),
    ("Latuserge 1m (30 дн.) · все монеты", "1", M1, latuserge_1m, "%", None),
    ("FVG тренд 1D (3R)", "D", 3000, fvg_1d, "R", None),
    ("Ложный пробой 2 свечи 1D (3R)", "D", 3000, fb2_1d, "R", None),
    ("Combo OTM XRP 1h (сборка 2)", "60", 15000, combo_xrp, "%", None, ["XRPUSDT"]),
    ("Combo OTM сборка 2 1h · все монеты", "60", 15000, combo_xrp, "%", None),
    ("OKX R4 Mirror Fibo HYPE 1h", "60", 15000, r4_native, "%", None, ["HYPEUSDT"]),
    ("OKX R4 Mirror Fibo 1h · все монеты", "60", 15000, r4_native, "%", None),
    ("OKX Pavlova BTC/XRP 1h", "60", 15000, pavlova_native, "%", None, ["BTCUSDT", "XRPUSDT"]),
    ("OKX Pavlova 1h · все монеты", "60", 15000, pavlova_native, "%", None),
    ("OKX ETH RSI ETH/XRP 4h", "240", 6000, eth_rsi, "%", None, ["ETHUSDT", "XRPUSDT"]),
    ("OKX ETH RSI 4h · все монеты", "240", 6000, eth_rsi, "%", None),
    ("Генератор: пробой 55 + EMA200 1h", "60", 15000, gen_lib("82be2071", "breakout", 55, "по тренду EMA200", 2.5, 3), "R", None, GEN1_C),
    ("Генератор: пробой 55 + EMA200 1h · все", "60", 15000, gen_lib("82be2071", "breakout", 55, "по тренду EMA200", 2.5, 3), "R", None),
    ("Генератор: пробой 20 + объём 1h", "60", 15000, gen_lib("2be861a2", "breakout", 20, "объём ×1.5", 2.5, 3), "R", None, GEN2_C),
    ("Генератор: пробой 20 + объём 1h · все", "60", 15000, gen_lib("2be861a2", "breakout", 20, "объём ×1.5", 2.5, 3), "R", None),
    ("Paper10 Gaussian 1h", "60", 15000, paper10("Gaussian Channel"), "%", None),
    ("Paper10 High-Low Cloud 1h", "60", 15000, paper10("High-Low Cloud"), "%", None),
    ("Paper10 LiqTherm MAP 1h (BTC/ETH)", "60", 15000, paper10("LiqTherm MAP"), "%", None, ["BTCUSDT", "ETHUSDT"]),
    ("Paper10 LiqTherm MAP 1h · все", "60", 15000, paper10("LiqTherm MAP"), "%", None),
    ("Paper10 Third Eye 1h", "60", 15000, paper10("Third Eye"), "%", None),
    ("Paper10 Combo OTM 1h", "60", 15000, paper10("Combo OTM"), "%", None),
    ("Paper10 Pavlova 1h", "60", 15000, paper10("Pavlova"), "%", None),
    ("Paper10 CE ZLSMA 1h", "60", 15000, paper10("CE ZLSMA"), "%", None),
    ("Paper10 Order Block 1h", "60", 15000, paper10("Order Block"), "%", None),
    ("Paper10 RSI Connors 1h", "60", 15000, paper10("RSI Connors"), "%", None),
    ("Paper10 HYPE R4 1h", "60", 15000, paper10("HYPE R4"), "%", None),
]


TRADFI = ["XAUUSDT", "XAGUSDT", "XCUUSDT", "CLUSDT", "BZUSDT", "NGUSDT"]   # сырьевые бессрочные OKX (золото, серебро, медь, WTI, Brent, газ)


def main():
    t0 = time.time()
    say(f"Текущие бумажные стратегии на OKX · {time.strftime('%Y-%m-%d %H:%M')} · комиссии OKX мейкер {MK*100:.2f}% / тейкер {TK*100:.2f}%")
    say("Свечи OKX USDT-SWAP: 12 криптомонет и 6 сырьевых контрактов (комиссия TradFi взята как у крипты — уточнить по скрину). Средний результат на монету; 1-я и 2-я половины истории отдельно.")
    rows = []
    for gname, coins, need, minbars in (("КРИПТА · 12 монет", T.COINS, 8, 600), ("TradFi OKX · золото, серебро, медь, нефть WTI/Brent, газ", TRADFI, 4, 300)):
      say(""); say(f"=== {gname} ===")
      tradfi = need == 4
      for test in TESTS:
        name, code, nb, fn, unit, prep = test[:6]
        only = test[6] if len(test) > 6 else None
        syms = [s for s in only if (s in TRADFI) == tradfi] if only else coins
        if not syms:
            continue
        full, h1, h2, days = [], [], [], []
        for s in syms:
            try:
                d = okx_klines(s, code, nb)
                if prep:
                    d = prep(d)
                if len(d["c"]) < minbars:
                    if (tradfi and name == TESTS[0][0]) or only:
                        say(f"  {name} {s}: на OKX мало истории ({len(d['c'])} свечей) — пропуск")
                    continue
                full.append(fn(d)); h1.append(fn(half(d, 0))); h2.append(fn(half(d, 1)))
                days.append((d["t"][-1] - d["t"][0]) / 86400000)
            except Exception as exc:  # noqa: BLE001
                say(f"  {name} {s}: ошибка {type(exc).__name__}: {str(exc)[:90]}")
        if len(full) < (min(len(syms), 1) if only else (6 if need == 8 else 3)) or not full:
            say(f"  {name}: мало инструментов с данными ({len(full)})"); continue
        k = 100 if unit == "%" else 1
        avg, a1, a2 = np.mean(full) * k, np.mean(h1) * k, np.mean(h2) * k
        plus = sum(x > 0 for x in full)
        if only:      # бот только на своих монетах: ≥60% в плюсе
            ok = avg > 0 and a1 > 0 and a2 > 0 and plus >= int(np.ceil(0.6 * len(full)))
        else:
            ok = avg > 0 and plus >= min(need, len(full) - 1) and a1 > 0 and a2 > 0
        rows.append((("TradFi: " if tradfi else "") + name, ok))
        say(f"  {name:<38} {avg:+8.1f}{unit} · в плюсе {plus:>2}/{len(full)} · 1-я {a1:+7.1f} · 2-я {a2:+7.1f}"
            f" · ~{np.median(days):.0f} дн.  {'✅' if ok else '❌'}   ({time.time() - t0:.0f} с)")
    say("")
    say("ИТОГ на OKX: прошли — " + (", ".join(n for n, ok in rows if ok) or "ни одна"))
    say("Не прошли — " + (", ".join(n for n, ok in rows if not ok) or "нет"))
    say("Сравнивай с бэктестами Bybit: если стратегия держится и там, и тут — это не особенность одной биржи.")
    OUT.parent.mkdir(exist_ok=True)
    OUT.write_text("\n".join(LINES), encoding="utf-8")
    print(f"\nОтчёт: {OUT}")


if __name__ == "__main__":
    main()
