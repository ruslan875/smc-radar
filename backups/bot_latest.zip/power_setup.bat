@echo off
rem power_setup.bat — 2026-11-14. Чтобы ПК с TRADEOS не засыпал и не перезагружался сам. Запускать: правый клик → «Запуск от имени администратора».
chcp 65001 >nul
net session >nul 2>&1 || (echo Нужно запустить от имени администратора. & pause & exit /b 1)
echo [1] Сон, гибернация, отключение диска — никогда (от сети)
powercfg /change standby-timeout-ac 0
powercfg /change hibernate-timeout-ac 0
powercfg /change disk-timeout-ac 0
powercfg /change monitor-timeout-ac 10
powercfg /hibernate off
echo [2] Крышка ноутбука и кнопка питания: при закрытии крышки — ничего (от сети)
powercfg /setacvalueindex SCHEME_CURRENT SUB_BUTTONS LIDACTION 0
powercfg /setactive SCHEME_CURRENT
echo [3] Windows Update: не перезагружать, пока пользователь вошёл; активные часы 06-24
reg add "HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" /v NoAutoRebootWithLoggedOnUsers /t REG_DWORD /d 1 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v ActiveHoursStart /t REG_DWORD /d 6 /f >nul
reg add "HKLM\SOFTWARE\Microsoft\WindowsUpdate\UX\Settings" /v ActiveHoursEnd /t REG_DWORD /d 0 /f >nul
echo [4] Автозапуск TRADEOS после входа в Windows
cd /d "%~dp0"
set "SU=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
> "%SU%\TRADEOS_start.bat" echo @echo off
>> "%SU%\TRADEOS_start.bat" echo timeout /t 30 /nobreak ^>nul
>> "%SU%\TRADEOS_start.bat" echo cd /d "%~dp0"
>> "%SU%\TRADEOS_start.bat" echo start "" /min "%~dp0venv\Scripts\pythonw.exe" "%~dp0bot_services.py" start
echo.
echo Готово. Осталось вручную:
echo  - BIOS: Restore on AC Power Loss = Power On (ПК включится сам, когда дадут свет)
echo  - Автовход в Windows: Win+R → netplwiz (или Sysinternals Autologon) — пароль вводишь сам
pause
