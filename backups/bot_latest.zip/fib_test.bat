@echo off
chcp 65001 >nul
cd /d "D:\VANTORIX\bot"
echo Fibonacci pullback backtest. 10-20 min, no trading.
python fib_test.py
echo.
pause
