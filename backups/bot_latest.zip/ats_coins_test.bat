@echo off
cd /d D:\VANTORIX\bot
venv\Scripts\python.exe ats_coins_test.py
pause
