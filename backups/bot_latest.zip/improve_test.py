"""improve_test.py — 2026-10-14. Честный подбор улучшений для Генераторов и Paper10 (бумажные боты в минусе).

Не выключаем — пробуем улучшить. Логика входов НЕ меняется (берётся родной код: strategy_gen для Генераторов,
адаптеры paper_live.py для Paper10). Сверху пробуем три вещи:
  1) ФИЛЬТР ТРЕНДА («не ловить нож»): лонг только если монета выше SMA 50 дней (1200 ч) и/или BTC выше своей
     SMA 50 дней и BTC не упал > 10% за сутки; шорт — зеркально.
  2) ВЫХОД ОТ ВОЛАТИЛЬНОСТИ: стоп k·ATR (1 / 1.5 / 2 / 3) и тейк rr·стоп (1 / 1.5 / 2 / 3), лимит 96 свечей —
     вместо родного выхода. Плюс вариант «родной выход».
  3) Всё вместе.
Итого 4 фильтра × 17 выходов = 68 вариантов на стратегию.

ЧЕСТНОСТЬ: история 1h каждой монеты делится пополам по времени.
  подбор — ТОЛЬКО на 1-й половине (лучший вариант по среднему % на монету);
  экзамен — 2-я половина, которую подбор не видел.
  ✅ «улучшение прошло», если на 2-й половине: средний результат > 0, лучше родного варианта и ≥ 60% монет в плюсе.
Комиссии реальные: 0.09% вход + 0.09% выход + проскальзывание 0.03%×2. Результат — сумма % сделок на монету.
12 монет, 1h, ~2 года. Ничего не торгует. Запуск: improve_test.bat → bt_lab_bots/improve_test.txt
"""
from __future__ import annotations

import sys
import time
import warnings
from pathlib import Path

import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
OUT = BASE / "bt_lab_bots" / "improve_test.txt"
COINS = ["BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT", "DOGEUSDT", "ADAUSDT", "SUIUSDT", "LINKUSDT", "AVAXUSDT",
         "BNBUSDT", "NEARUSDT", "HYPEUSDT"]
FEE_PCT, SLIP_PCT = 0.09, 0.03                       # % на сторону
RT = 2 * (FEE_PCT + SLIP_PCT) / 100                    # доля за круг
HOLD = 96
FILTERS = ["нет", "тренд монеты", "тренд BTC", "оба"]
EXITS = ["родной"] + [(k, rr) for k in (1.0, 1.5, 2.0, 3.0) for rr in (1.0, 1.5, 2.0, 3.0)]
LINES = []


def say(s=""):
    print(s, flush=True)
    LINES.append(s)


# ---------------- данные ----------------
def load_1h(sym):
    d = None
    try:
        import strategy_gen as G  # noqa: PLC0415
        d = G._load(sym, "1h", years=2.0)
    except Exception:  # noqa: BLE001
        d = None
    if d is None or len(d) < 3000:
        import market_data  # noqa: PLC0415
        start = (pd.Timestamp.now("UTC") - pd.Timedelta(days=730)).strftime("%Y-%m-%d")
        end = (pd.Timestamp.now("UTC") + pd.Timedelta(days=1)).strftime("%Y-%m-%d")
        m = market_data.load_ohlcv(sym.replace("USDT", "/USDT"), "1h", start, end, exchange_id="bybit", market="swap")
        if m is None or len(m) < 3000:
            return None
        m = m.copy()
        if "time" in m.columns:
            ts = pd.to_datetime(m["time"], utc=True)
        else:
            ts = pd.to_datetime(m.index, utc=True)
        d = pd.DataFrame({"t": (ts.astype("int64") // 1_000_000).values, "o": m["open"].values, "h": m["high"].values,
                          "l": m["low"].values, "c": m["close"].values, "v": m["volume"].values})
    d = d.dropna().reset_index(drop=True)
    return d.iloc[:-1] if len(d) > 1 else d


def pl_frame(d):
    """DataFrame в формате paper_live (DatetimeIndex + колонка time)."""
    ts = pd.to_datetime(d.t, unit="ms", utc=True)
    df = pd.DataFrame({"open": d.o.values, "high": d.h.values, "low": d.l.values, "close": d.c.values,
                       "volume": d.v.values}, index=ts)
    df["time"] = df.index
    return df


def atr(d, n=14):
    pc = d.c.shift()
    tr = pd.concat([d.h - d.l, (d.h - pc).abs(), (d.l - pc).abs()], axis=1).max(axis=1)
    return tr.ewm(alpha=1 / n, adjust=False).mean().values


# ---------------- источники входов ----------------
# каждый возвращает список (i, side, orig_pct|None): i — индекс свечи, на закрытии которой вход
def gen_entries(item):
    import strategy_gen as G  # noqa: PLC0415

    def f(d, sym):
        F = G._feats(d)
        side = int(item.get("side") or 1)
        idx = G._entries(F, item["trig"], side, item["p"], G.FILTERS[item["flt"]])
        out = []
        for i in idx:
            out.append((int(i), side, None))      # родной выход = ATR item.sl / item.rr (считается ниже)
        return out
    f.native = (float(item["sl"]), float(item["rr"]))
    return f


def pl_entries(adapter, name):
    def f(d, sym):
        df = pl_frame(d)
        if name == "HYPE R4":
            deals = adapter(df, FEE_PCT, SLIP_PCT, sym)
        else:
            deals = adapter(df, FEE_PCT, SLIP_PCT)
        if deals is None or len(deals) == 0:
            return []
        tpos = pd.DatetimeIndex(df.index)
        out = []
        for r in deals.to_dict("records"):
            if str(r.get("reason", "")).strip().lower() in ("end_of_data", "eob", "end", "open"):
                continue
            et = pd.Timestamp(r["entry_time"])
            et = et.tz_localize("UTC") if et.tzinfo is None else et.tz_convert("UTC")
            i = int(tpos.searchsorted(et, side="right")) - 1
            if i < 0:
                continue
            side = 1 if str(r["side"]).lower().startswith("l") else -1
            out.append((i, side, float(r["gross_pnl_pct"]) / 100))
        return out
    f.native = None
    return f


# ---------------- оценка варианта ----------------
def allowed(i, side, ctx, flt):
    if flt == "нет":
        return True
    ok = True
    if flt in ("тренд монеты", "оба"):
        s = ctx["sma"][i]
        ok &= not np.isnan(s) and ((ctx["c"][i] > s) if side > 0 else (ctx["c"][i] < s))
    if flt in ("тренд BTC", "оба"):
        b, bs, b24 = ctx["btc"][i], ctx["btc_sma"][i], ctx["btc24"][i]
        if np.isnan(b) or np.isnan(bs):
            return False
        ok &= ((b > bs and not b24 < -0.10) if side > 0 else (b < bs and not b24 > 0.10))
    return bool(ok)


def run(ents, ctx, flt, ex, lo, hi, native):
    """Сумма % сделок, вход в [lo, hi). Без перекрытия сделок."""
    h, l, c, a = ctx["h"], ctx["l"], ctx["c"], ctx["atr"]
    tot, nxt, n = 0.0, -1, 0
    for i, side, orig in ents:
        if i < lo or i >= hi or i <= nxt or i >= len(c) - 1:
            continue
        if not allowed(i, side, ctx, flt):
            continue
        if ex == "родной" and orig is not None:
            tot += orig; n += 1
            continue
        k, rr = native if ex == "родной" else ex
        e = c[i]; risk = k * a[i]
        if not risk > 0:
            continue
        s, t = e - side * risk, e + side * rr * risk
        res = None
        for j in range(i + 1, min(hi, len(c), i + HOLD)):
            if (l[j] <= s) if side > 0 else (h[j] >= s):
                res = (j, -risk / e); break
            if (h[j] >= t) if side > 0 else (l[j] <= t):
                res = (j, rr * risk / e); break
        if res is None:
            j = min(hi, len(c), i + HOLD) - 1
            res = (j, side * (c[j] / e - 1))
        tot += res[1] - RT; nxt = res[0]; n += 1
    return tot, n


# ---------------- главное ----------------
def main():
    t0 = time.time()
    say(f"Улучшение Генераторов и Paper10 — честный подбор · {time.strftime('%Y-%m-%d %H:%M')}")
    say(f"12 монет · 1h · ~2 года · комиссия {FEE_PCT}%+проск. {SLIP_PCT}% на сторону · подбор на 1-й половине, экзамен на 2-й")
    say("Фильтры: " + ", ".join(FILTERS) + " · выходы: родной + стоп 1/1.5/2/3 ATR × тейк 1/1.5/2/3R")
    data = {}
    for s in COINS:
        try:
            d = load_1h(s)
        except Exception as exc:  # noqa: BLE001
            say(f"  {s}: нет данных ({str(exc)[:80]})"); d = None
        if d is not None:
            data[s] = d
    if "BTCUSDT" not in data:
        say("Нет свечей BTC — запусти download_all_candles.bat"); return
    btc = data["BTCUSDT"].set_index("t").c
    btc_sma = btc.rolling(1200).mean()
    ctxs = {}
    for s, d in data.items():
        b = btc.reindex(d.t).values; bs = btc_sma.reindex(d.t).values
        b24 = np.r_[np.full(24, np.nan), b[24:] / b[:-24] - 1]
        ctxs[s] = {"h": d.h.values, "l": d.l.values, "c": d.c.values, "atr": atr(d),
                   "sma": d.c.rolling(1200).mean().values, "btc": b, "btc_sma": bs, "btc24": b24}
    say(f"Монет с данными: {len(data)} · свечей на монету ~{int(np.median([len(d) for d in data.values()]))}")

    sources = []
    try:
        import strategy_gen as G  # noqa: PLC0415
        for it in G.lib_list():
            if it.get("paper_coins"):
                sources.append((f"Генератор {it['symbol'][:-4]} {it['tf']}: {it['name'][:48]}", gen_entries(it), it.get("tf")))
    except Exception as exc:  # noqa: BLE001
        say(f"Генераторы: ошибка {exc}")
    try:
        import paper_live as P  # noqa: PLC0415
        for name, _m, ad, _s in P.STRATEGIES:
            sources.append((f"Paper10 {name}", pl_entries(ad, name), "1h"))
    except Exception as exc:  # noqa: BLE001
        say(f"Paper10: ошибка {exc}")

    summary = []
    for title, fn, tf in sources:
        if tf and tf != "1h":
            say(f"\n— {title}: ТФ {tf}, тест только 1h — пропуск"); continue
        say(""); say(f"=== {title} ===")
        ents = {}
        for s, d in data.items():
            try:
                ents[s] = fn(d, s)
            except Exception as exc:  # noqa: BLE001
                say(f"  {s}: ошибка стратегии {str(exc)[:90]}")
        ents = {s: e for s, e in ents.items() if e}
        if len(ents) < 6:
            say("  мало монет со сделками — пропуск"); continue
        native = fn.native or (2.0, 2.0)
        res = {}
        for flt in FILTERS:
            for ex in EXITS:
                if ex == "родной" and fn.native is None and not any(e[0][2] is not None for e in ents.values()):
                    continue
                r1, r2, n1, n2 = {}, {}, 0, 0
                for s, e in ents.items():
                    m = len(ctxs[s]["c"]) // 2
                    a, na = run(e, ctxs[s], flt, ex, 0, m, native)
                    b, nb = run(e, ctxs[s], flt, ex, m, len(ctxs[s]["c"]), native)
                    r1[s], r2[s] = a, b; n1 += na; n2 += nb
                res[(flt, ex)] = (np.mean(list(r1.values())) * 100, np.mean(list(r2.values())) * 100,
                                  sum(v > 0 for v in r2.values()), len(r2), n1, n2)
        base = res.get(("нет", "родной"))
        cand = {k: v for k, v in res.items() if v[4] >= 30}           # минимум 30 сделок на подборе
        best_k = max(cand, key=lambda k: cand[k][0]) if cand else None
        def lab(k):
            f, e = k
            return f"фильтр «{f}» · " + ("выход родной" if e == "родной" else f"стоп {e[0]} ATR, тейк {e[1]}R")
        if base:
            say(f"  КАК ЕСТЬ:   1-я {base[0]:+7.1f}% · 2-я {base[1]:+7.1f}% · в плюсе на 2-й {base[2]}/{base[3]} · сделок {base[4]}+{base[5]}")
        if best_k:
            b = res[best_k]
            ok = b[1] > 0 and (base is None or b[1] > base[1]) and b[2] >= 0.6 * b[3]
            say(f"  ЛУЧШЕЕ на подборе: {lab(best_k)}")
            say(f"              1-я {b[0]:+7.1f}% · 2-я (экзамен) {b[1]:+7.1f}% · в плюсе {b[2]}/{b[3]} · сделок {b[4]}+{b[5]}  "
                f"{'✅ улучшение прошло' if ok else '❌ на экзамене не держится'}")
            # вклад каждого улучшения по отдельности (на экзамене)
            for f in FILTERS[1:]:
                v = res.get((f, "родной")) or res.get((f, (native[0], native[1])))
                if v:
                    say(f"    только фильтр «{f}»: 2-я {v[1]:+7.1f}% · в плюсе {v[2]}/{v[3]}")
            summary.append((title, base[1] if base else float("nan"), b[1], ok, lab(best_k)))
        say(f"  ({time.time() - t0:.0f} с)")

    say(""); say("ИТОГ (экзамен = 2-я половина, которую подбор не видел):")
    for t, b0, b1, ok, lb in summary:
        say(f"  {'✅' if ok else '❌'} {t[:52]:<52} было {b0:+7.1f}% → стало {b1:+7.1f}%  [{lb}]")
    say("✅ — ставим эту настройку в бумажного бота. ❌ — настройки не спасают, проблема в самом сигнале.")
    OUT.parent.mkdir(exist_ok=True)
    OUT.write_text("\n".join(LINES), encoding="utf-8")
    print(f"\nОтчёт: {OUT}")


if __name__ == "__main__":
    main()
