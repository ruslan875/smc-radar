#!/usr/bin/env python3
"""
Measure the LIVE bots with the same yardstick as the candidate strategies
=========================================================================

Written 20.09.2026, after a day spent rejecting five TradingView strategies
on break-even win rate and drawdown. The obvious next question is what the
two bots that trade real money score on that same scale - and nothing was
applying it to them, because the live journals use a different schema from
the backtest deal logs.

READS (whichever exist next to this file):
    kc_roc_cci_wt_grid_live_trades.csv
    long_strategy15_latuserge_live_trades.csv
    long_strategy15_latuserge_paper_trades.csv

Journal schema: symbol, entry_time, exit_time, orders_filled, filled_pct,
                avg_entry_price, exit_price, reason, bars_held, gross_pnl_pct

THE ONE THING THAT MATTERS MOST HERE
------------------------------------
`gross_pnl_pct` in these journals is GROSS - the bots record the raw price
move and do not subtract fees. The backtest deal logs this project compares
against already have costs inside them. Reading the two side by side without
netting the live numbers flatters the live bots by the full round-trip
commission, which on a strategy averaging +0.4% a trade is about a quarter
of the whole result. This script subtracts fees and prints gross and net
next to each other so the size of that correction is never invisible.

Default 0.055% per side (Bybit taker, both ways). If grid legs rest as
limit orders they earn the maker fee instead - pass --maker-entry to model
entry at 0.02% and exit at 0.055%.

USAGE
    python analyze_live_bots.py
    python analyze_live_bots.py --commission 0.055 --maker-entry
    python analyze_live_bots.py --files my_journal.csv
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

import pandas as pd

HERE = Path(__file__).resolve().parent

DEFAULT_FILES = [
    ("kc_roc_cci_wt_grid_live_trades.csv", "KC/ROC grid - LIVE"),
    ("long_strategy15_latuserge_live_trades.csv", "Latuserge - LIVE"),
    ("long_strategy15_latuserge_paper_trades.csv", "Latuserge - paper"),
]

JOURNAL_COLS = {"symbol", "entry_time", "exit_time", "reason", "gross_pnl_pct"}


def load_dir(d: Path) -> pd.DataFrame | None:
    """A grid-backtest output folder: one <SYMBOL>_deals.csv per symbol, in the
    very same schema the live journals use - including the fact that
    gross_pnl_pct is gross. Concatenating them gives a frame indistinguishable
    from a live journal, so the identical yardstick applies to backtested grid
    configurations and to real trades."""
    frames = []
    for f in sorted(d.glob("*_deals.csv")):
        one = load_journal(f, quiet=True)
        if one is not None and not one.empty:
            frames.append(one)
    if not frames:
        return None
    return pd.concat(frames).sort_values("entry_time").reset_index(drop=True)


def load_journal(path: Path, quiet: bool = False) -> pd.DataFrame | None:
    try:
        df = pd.read_csv(path)
    except Exception as exc:
        print(f"  ! {path.name}: {exc}", file=sys.stderr)
        return None
    if JOURNAL_COLS - set(df.columns):
        if not quiet:
            print(f"  ! {path.name}: not a live journal - skipped", file=sys.stderr)
        return None
    for c in ("entry_time", "exit_time"):
        df[c] = pd.to_datetime(df[c], errors="coerce", utc=True)
    return df.sort_values("entry_time").reset_index(drop=True)


def net_pnl(df: pd.DataFrame, commission: float, maker_entry: bool) -> pd.Series:
    """Round-trip cost in percentage points, subtracted from the gross move."""
    entry_fee = 0.02 if maker_entry else commission
    cost = entry_fee + commission
    return df["gross_pnl_pct"].astype(float) - cost


def metrics(pnl: pd.Series, df: pd.DataFrame) -> dict:
    n = len(pnl)
    if n == 0:
        return {"trades": 0}
    wins, losses = pnl[pnl > 0], pnl[pnl <= 0]
    gp, gl = wins.sum(), abs(losses.sum())
    avg_win = wins.mean() if len(wins) else 0.0
    avg_loss = abs(losses.mean()) if len(losses) else 0.0
    equity = (1 + pnl / 100).cumprod()
    max_dd = (equity / equity.cummax() - 1).min() * 100

    hold = None
    if "bars_held" in df.columns:
        hold = df["bars_held"].mean()

    # A sample with no losing trades yet cannot produce a break-even bar or a
    # profit factor: both are divisions by zero. Printing "inf" and "0.0%"
    # there reads as a flawless system when it only means "no loss has landed
    # yet" - exactly the misreading this tool exists to prevent.
    no_losses = len(losses) == 0

    # How many more average losses the accumulated gain can absorb before the
    # whole run is back to zero. For a high-win-rate system with fat losses
    # this says more about survival than the profit factor does.
    total_pp = pnl.sum()
    losses_to_zero = (total_pp / avg_loss) if avg_loss > 0 and total_pp > 0 else float("nan")

    return {
        "trades": n,
        "no_losses": no_losses,
        "losses_to_zero": losses_to_zero,
        "win_rate": len(wins) / n * 100,
        # Same definition as analyze_external_strategies.py: the win rate this
        # payoff shape needs just to reach zero.
        "be_win_rate": (avg_loss / (avg_win + avg_loss) * 100) if (avg_win + avg_loss) > 0 else float("nan"),
        "avg": pnl.mean(),
        "avg_win": avg_win,
        "avg_loss": -avg_loss,
        "pf": (gp / gl) if gl > 0 else float("inf"),
        "total": (equity.iloc[-1] - 1) * 100,
        "max_dd": max_dd,
        "bars_held": hold,
    }


def fmt(m: dict) -> str:
    if m["trades"] == 0:
        return "no trades"
    if m.get("no_losses"):
        pf, need = "    -", "    - "
    else:
        pf = f"{m['pf']:5.2f}"
        need = f"{m['be_win_rate']:5.1f}%"
    bars = f"{m['bars_held']:6.0f}" if m.get("bars_held") is not None else "     -"
    return (f"{m['trades']:4d} | {m['avg']:+6.2f}% | {m['win_rate']:5.1f}% | "
            f"{need} | {pf} | {m['max_dd']:6.1f}% | "
            f"{m['total']:+8.1f}% | {bars}")


HEADER = (f"{'symbol':<12} {'trades':>4} | {'avg':>7} | {'WR':>6} | {'need':>6} | "
          f"{'PF':>5} | {'maxDD':>7} | {'total':>9} | {'bars':>6}")


def verdict(m: dict) -> str:
    if m["trades"] < 30:
        extra = " No loss has landed yet, so nothing here measures risk." if m.get("no_losses") else ""
        return (f"{m['trades']} trades - too few to conclude. Reported for "
                f"completeness, not as evidence.{extra}")
    gap = m["win_rate"] - m["be_win_rate"]
    if m["pf"] >= 1.3:
        return f"clears its own break-even bar by {gap:+.1f} pp"
    if m["pf"] >= 1.0:
        return f"marginally above break-even ({gap:+.1f} pp) - thin"
    return f"below break-even by {gap:.1f} pp after costs"


def config_line(d: Path) -> str | None:
    """Grid-config variants are meaningless side by side unless each one says
    what it was. Folders produced before this manifest existed say nothing,
    and that absence is itself worth printing."""
    f = d / "_run.json"
    if not f.exists():
        return ("  config: UNRECORDED - this folder predates the manifest. What "
                "produced it cannot be reconstructed; re-run before comparing.")
    try:
        import json
        m = json.loads(f.read_text(encoding="utf-8"))
    except Exception:
        return "  config: _run.json unreadable"
    bits = []
    if m.get("grid_offsets") is not None:
        bits.append(f"grid {m['grid_offsets']} @ {m.get('grid_volumes')}%")
    if m.get("stop_loss_pct") is not None:
        bits.append(f"stop {m['stop_loss_pct']}%")
    if m.get("tp_min_pnl_pct") is not None:
        bits.append(f"tp-min {m['tp_min_pnl_pct']}%")
    if m.get("bars"):
        bits.append(f"{m['bars']} bars of {m.get('timeframe')}")
    if m.get("run_at"):
        bits.append(f"run {str(m['run_at'])[:16]}")
    return "  config: " + "  |  ".join(bits) if bits else None


def report(df: pd.DataFrame, label: str, commission: float, maker_entry: bool,
           source_dir: Path | None = None):
    pnl_net = net_pnl(df, commission, maker_entry)
    pnl_gross = df["gross_pnl_pct"].astype(float)

    entry_fee = 0.02 if maker_entry else commission
    span = f"{df['entry_time'].min():%Y-%m-%d} -> {df['exit_time'].max():%Y-%m-%d}"

    print()
    print("=" * 104)
    print(f"  {label}")
    print(f"  {span}  |  {df['symbol'].nunique()} symbols  |  "
          f"fees {entry_fee}% entry + {commission}% exit = {entry_fee + commission}% round trip")
    if source_dir is not None:
        line = config_line(source_dir)
        if line:
            print(line)
    print("=" * 104)
    print(HEADER)
    print("-" * 104)

    for sym, g in df.groupby("symbol"):
        m = metrics(net_pnl(g, commission, maker_entry), g)
        print(f"{sym:<12} {fmt(m)}")

    combined = metrics(pnl_net, df)
    print("-" * 104)
    print(f"{'ALL (net)':<12} {fmt(combined)}")
    gross_m = metrics(pnl_gross, df)
    print(f"{'ALL (gross)':<12} {fmt(gross_m)}")

    print()
    print(f"  cost of trading: {gross_m['avg'] - combined['avg']:.2f} pp per trade, "
          f"which is {abs(gross_m['avg'] - combined['avg']) / abs(gross_m['avg']) * 100:.0f}% "
          f"of the gross average")
    if combined.get("no_losses"):
        print(f"  avg win {combined['avg_win']:+.2f}%  |  no losing trade yet - "
              f"break-even bar and profit factor are undefined on this sample")
    else:
        print(f"  avg win {combined['avg_win']:+.2f}%  |  avg loss {combined['avg_loss']:+.2f}%  |  "
              f"one loss undoes {abs(combined['avg_loss'] / combined['avg_win']):.1f} wins")
        ltz = combined.get("losses_to_zero")
        if ltz == ltz and ltz != float("inf"):
            print(f"  cushion: {ltz:.1f} more average losses wipe out everything "
                  f"earned so far ({combined['total']:+.1f}%)")
    reasons = df["reason"].value_counts()
    print(f"  exits: {reasons.to_dict()}")
    print(f"  >> {verdict(combined)}")

    # ---- grid-leg breakdown: unique to these journals ---------------------
    if "orders_filled" in df.columns and df["orders_filled"].nunique() > 1:
        print()
        print("  by grid legs filled (the averaging-down question):")
        print(f"    {'legs':>4} | {'trades':>6} | {'stops':>5} | {'stop rate':>9} | {'avg net':>8}")
        for legs, g in df.groupby("orders_filled"):
            p = net_pnl(g, commission, maker_entry)
            stops = (g["reason"].astype(str).str.upper() == "SL").sum()
            print(f"    {int(legs):>4} | {len(g):6d} | {stops:5d} | "
                  f"{stops / len(g) * 100:8.1f}% | {p.mean():+7.2f}%")

    return combined


def main():
    p = argparse.ArgumentParser(description="Measure the live bots on the candidate yardstick")
    p.add_argument("--files", nargs="+", help="journal CSVs (default: the known ones)")
    p.add_argument("--dirs", nargs="+",
                   help="grid-backtest output folders (one <SYMBOL>_deals.csv each). "
                        "Same schema as the journals, so configurations and real "
                        "trades land on one scale.")
    p.add_argument("--commission", type=float, default=0.055,
                   help="per-side commission %%, Bybit taker default")
    p.add_argument("--symbols", nargs="+",
                   help="restrict every source to these symbols. Grid-config "
                        "variants are often generated over different symbol "
                        "sets, and pooling different sets measures the sets "
                        "rather than the configurations. Use --common to let "
                        "the tool work the intersection out by itself.")
    p.add_argument("--common", action="store_true",
                   help="keep only the symbols present in EVERY source")
    p.add_argument("--maker-entry", action="store_true",
                   help="model the entry leg as a resting limit order (0.02%%)")
    args = p.parse_args()

    targets = []
    if args.files:
        targets += [(f, Path(f).stem, "file") for f in args.files]
    if args.dirs:
        targets += [(d, Path(d).name, "dir") for d in args.dirs]
    if not targets:
        targets = [(f, lbl, "file") for f, lbl in DEFAULT_FILES if (HERE / f).exists()]

    if not targets:
        print("No live journals found next to this script.")
        return

    # Load everything first: the symbol intersection cannot be known until
    # every source has been read.
    loaded = []
    for fname, label, kind in targets:
        path = Path(fname) if Path(fname).is_absolute() else HERE / fname
        df = load_dir(path) if kind == "dir" else load_journal(path)
        if df is None or df.empty:
            print(f"  ! {label}: nothing readable", file=sys.stderr)
            continue
        loaded.append((df, label, path if kind == "dir" else None))

    keep = set(args.symbols) if args.symbols else None
    if args.common and len(loaded) > 1:
        common = set.intersection(*(set(d["symbol"].unique()) for d, _, _ in loaded))
        keep = common if keep is None else keep & common
        dropped = set.union(*(set(d["symbol"].unique()) for d, _, _ in loaded)) - common
        if dropped:
            print(f"\n  restricting all sources to the {len(common)} symbols they share; "
                  f"dropping {', '.join(sorted(dropped))}")

    summary = []
    for df, label, src in loaded:
        if keep is not None:
            df = df[df["symbol"].isin(keep)]
            if df.empty:
                print(f"  ! {label}: no trades left after the symbol filter", file=sys.stderr)
                continue
        m = report(df, label, args.commission, args.maker_entry, src)
        m["label"] = label
        summary.append(m)

    if len(summary) > 1:
        print()
        print("=" * 104)
        print("  SIDE BY SIDE")
        print("=" * 104)
        print(f"{'bot':<24} {'trades':>6} | {'avg net':>8} | {'WR':>6} | {'need':>6} | "
              f"{'PF':>6} | {'maxDD':>7}")
        print("-" * 104)
        for m in sorted(summary, key=lambda x: -x["trades"]):
            pf = "     -" if m.get("no_losses") else f"{m['pf']:6.2f}"
            need = "     - " if m.get("no_losses") else f"{m['be_win_rate']:5.1f}%"
            print(f"{m['label']:<24} {m['trades']:6d} | {m['avg']:+7.2f}% | {m['win_rate']:5.1f}% | "
                  f"{need} | {pf} | {m['max_dd']:6.1f}%")
        print("  (sorted by sample size, not by result: a dash means the sample")
        print("   contains no losses yet, so the ratio is undefined rather than perfect)")

    print()
    print("  need = win rate this payoff shape must reach to break even, computed")
    print("         from its own realized average win and loss. Same definition as")
    print("         analyze_external_strategies.py, so these rows are directly")
    print("         comparable with the candidate strategies tested today.")
    print("  NOTE: journals record GROSS moves; every figure above is net of the")
    print("         fees stated in each header unless the row says gross.")


if __name__ == "__main__":
    main()
