@echo off
chcp 65001 >nul
cd /d D:\VANTORIX\bot
findstr /b /c:"TELEGRAM_FORUM_CHAT_ID=" .env >/dev/null 2>&1 && (powershell -NoProfile -Command "(Get-Content .env) -replace ^TELEGRAM_FORUM_CHAT_ID=.*,TELEGRAM_FORUM_CHAT_ID=-1004339432295 | Set-Content -Encoding UTF8 .env") || (echo.>>.env& echo TELEGRAM_FORUM_CHAT_ID=-1004339432295>>.env)
echo Готово: группа TRADEOS Сигналы подключена. Нажмите в терминале «Перезапуск ботов».
pause
