@echo off
cd /d D:\VANTORIX\bot
venv\Scripts\python.exe chan_1h_coins_test.py
pause
