#!/usr/bin/env python3
"""
Cross-sectional relative-strength / momentum filter test.

Motivation (2026-09-05): every price-structure idea tried in this project so far
(49 Pine indicators, SMC order-block/FVG/BOS/CHoCH/sweep in every combination,
anchored VWAP, session filters, funding/OI as a single-asset filter) has been a
TIME-SERIES signal -- it only ever looks at one symbol's own past price. The one
family of crypto strategy with real, credible academic support (BIS Working
Paper 1087 "Crypto carry"; multiple intraday momentum/reversal studies) is
CROSS-SECTIONAL: rank symbols against EACH OTHER at each point in time and
condition on that rank, rather than looking at each symbol in isolation.

This script does NOT invent a new entry trigger. It takes the structural
setups the bot already fires (already-computed trades CSVs from backtest.py --
CHoCH/BOS/SWEEP x OB/OB+FVG, real entries/stops/outcomes) and asks a narrower,
honest question: does each trade's outcome depend on how strong/weak that
symbol's own recent price momentum was RELATIVE TO THE REST OF THE UNIVERSE at
the moment the setup fired? If yes, momentum-rank is a usable filter on top of
the existing (otherwise non-generalizing) setup. If no, this closes another
lever honestly rather than leaving it as a vague "maybe try momentum" idea.

Requires network access to Bybit (run on the machine with API access, not the
sandbox). Usage:

    python cross_sectional_momentum.py --trades-dir backtest_out_ext --trades-dir backtest_out \
        --lookback-days 7 30 --out momentum_joined

Writes one <symbol>_trades_momentum.csv per input file (original columns +
mom_return_7d, mom_return_30d, mom_rank_7d, mom_rank_30d -- rank is a
0..1 percentile within the universe on that trade's entry date, 1.0 = strongest
momentum in the universe that day), plus a combined summary printed to stdout
bucketing win rate / gross avg R / net avg R by momentum-rank tercile.
"""
from __future__ import annotations

import argparse
import csv
import glob
import os
import statistics
import sys
import time
from datetime import datetime, timedelta, timezone

import requests

BYBIT_KLINE_URL = "https://api.bybit.com/v5/market/kline"

FEE_SCENARIOS = {
    "bybit_taker+taker": 0.0018,
    "bybit_taker+maker": 0.001224,
    "bybit_maker+maker": 0.000648,
    "okx_taker+taker": 0.0010,
    "okx_taker+maker": 0.0007,
    "okx_maker+maker": 0.0004,
}

# Universe = every symbol this project has real backtest data for so far.
# Ideally this would be a full top-100 snapshot per day, but that requires
# reconstructing historical top-100 membership (Bybit's turnover ranking API
# only reflects *current* turnover, not historical), which is a much bigger
# undertaking. Ranking within this ~22-symbol set is an honest, if narrower,
# first test of whether momentum rank matters at all before investing in that
# bigger effort.
UNIVERSE = [
    "ETHUSDT", "SOLUSDT", "ARBUSDT", "INJUSDT", "TIAUSDT",
    "ZECUSDT", "XRPUSDT", "HYPEUSDT", "USELESSUSDT", "SOXLUSDT",
    "SNDKUSDT", "ENAUSDT", "MARSCOINUSDT", "XAUUSDT", "DOGEUSDT",
    "PONSUSDT", "NEARUSDT", "ADAUSDT", "SUIUSDT", "UNIUSDT",
    "LITUSDT", "1000PEPEUSDT",
]


def _get_with_retry(url, params, retries=4, timeout=15.0):
    for attempt in range(retries):
        try:
            resp = requests.get(url, params=params, timeout=timeout)
            if resp.status_code == 200:
                data = resp.json()
                if data.get("retCode") == 0:
                    return data
                print(f"  [retry] Bybit retCode={data.get('retCode')} {data.get('retMsg')}")
            else:
                print(f"  [retry] HTTP {resp.status_code}")
        except requests.exceptions.RequestException as exc:
            print(f"  [retry] {exc}")
        time.sleep(1.5 * (attempt + 1))
    return None


def fetch_daily_closes(symbol: str, start_ms: int, end_ms: int) -> dict[str, float]:
    """Returns {date_str: close_price} for one symbol, daily bars, [start,end]."""
    out = {}
    cursor_end = end_ms
    while True:
        data = _get_with_retry(BYBIT_KLINE_URL, {
            "category": "linear", "symbol": symbol, "interval": "D",
            "end": cursor_end, "limit": 200,
        })
        if not data:
            print(f"  [{symbol}] giving up after retries")
            break
        rows = data["result"]["list"]  # newest first: [start, open, high, low, close, volume, turnover]
        if not rows:
            break
        for r in rows:
            ts_ms = int(r[0])
            if ts_ms < start_ms:
                continue
            dt = datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc)
            out[dt.strftime("%Y-%m-%d")] = float(r[4])
        oldest_ts = int(rows[-1][0])
        if oldest_ts <= start_ms or len(rows) < 200:
            break
        cursor_end = oldest_ts - 1
        time.sleep(0.3)
    return out


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--trades-dir", action="append", required=True, help="directory of *_trades.csv files (repeatable)")
    ap.add_argument("--lookback-days", type=int, nargs="+", default=[7, 30])
    ap.add_argument("--out", default="momentum_joined")
    args = ap.parse_args()

    trade_files = []
    for d in args.trades_dir:
        trade_files.extend(sorted(glob.glob(os.path.join(d, "*_trades.csv"))))
    if not trade_files:
        print("No trades CSVs found.")
        sys.exit(1)

    all_times = []
    trades_by_symbol = {}
    for fp in trade_files:
        sym = os.path.basename(fp).replace("_trades.csv", "")
        rows = []
        with open(fp, newline="") as f:
            for r in csv.DictReader(f):
                if not r.get("r"):
                    continue
                t = datetime.fromisoformat(r["time"])
                rows.append({**r, "_dt": t})
                all_times.append(t)
        trades_by_symbol.setdefault(sym, []).extend(rows)

    if not all_times:
        print("No resolved trades found in the given directories.")
        sys.exit(1)

    max_lookback = max(args.lookback_days)
    start_dt = min(all_times) - timedelta(days=max_lookback + 5)
    end_dt = max(all_times) + timedelta(days=1)
    start_ms = int(start_dt.timestamp() * 1000)
    end_ms = int(end_dt.timestamp() * 1000)

    print(f"Fetching daily closes for {len(UNIVERSE)} symbols, {start_dt.date()} -> {end_dt.date()} ...")
    closes = {}
    for i, sym in enumerate(UNIVERSE):
        print(f"  [{i+1}/{len(UNIVERSE)}] {sym}")
        closes[sym] = fetch_daily_closes(sym, start_ms, end_ms)
        time.sleep(0.5)

    all_dates = sorted({d for s in closes.values() for d in s.keys()})

    # returns[days][date][symbol] = pct return over trailing `days`
    returns = {days: {} for days in args.lookback_days}
    for days in args.lookback_days:
        for date_str in all_dates:
            d = datetime.strptime(date_str, "%Y-%m-%d")
            prior = (d - timedelta(days=days)).strftime("%Y-%m-%d")
            day_returns = {}
            for sym in UNIVERSE:
                c_now = closes[sym].get(date_str)
                c_prior = closes[sym].get(prior)
                if c_now and c_prior and c_prior > 0:
                    day_returns[sym] = (c_now / c_prior) - 1.0
            returns[days][date_str] = day_returns

    def rank_pct(date_str, days, sym):
        day_returns = returns[days].get(date_str, {})
        if sym not in day_returns or len(day_returns) < 5:
            return None
        vals = sorted(day_returns.values())
        idx = vals.index(day_returns[sym])
        return idx / (len(vals) - 1) if len(vals) > 1 else 0.5

    os.makedirs(args.out, exist_ok=True)
    joined_rows = []
    for sym, rows in trades_by_symbol.items():
        out_path = os.path.join(args.out, f"{sym}_trades_momentum.csv")
        fieldnames = list(rows[0].keys() - {"_dt"}) if rows else []
        for days in args.lookback_days:
            fieldnames.append(f"mom_return_{days}d")
            fieldnames.append(f"mom_rank_{days}d")
        with open(out_path, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=[c for c in fieldnames if c != "_dt"])
            w.writeheader()
            for r in rows:
                date_str = r["_dt"].strftime("%Y-%m-%d")
                out_row = {k: v for k, v in r.items() if k != "_dt"}
                for days in args.lookback_days:
                    day_returns = returns[days].get(date_str, {})
                    out_row[f"mom_return_{days}d"] = day_returns.get(sym, "")
                    rp = rank_pct(date_str, days, sym)
                    out_row[f"mom_rank_{days}d"] = f"{rp:.4f}" if rp is not None else ""
                w.writerow(out_row)
                r["_rank_pct"] = {days: rank_pct(date_str, days, sym) for days in args.lookback_days}
                joined_rows.append({**r, "symbol": sym})
        print(f"  wrote {out_path} ({len(rows)} trades)")

    # --- summary: bucket by momentum rank tercile, per lookback window ---
    for days in args.lookback_days:
        print(f"\n=== Momentum lookback = {days}d ===")
        buckets = {"low (bottom third)": [], "mid": [], "high (top third)": []}
        for r in joined_rows:
            rp = r["_rank_pct"].get(days)
            if rp is None:
                continue
            entry = float(r["entry"])
            sl = float(r["stop_loss"])
            risk_pct = abs(entry - sl) / entry
            if risk_pct <= 0:
                continue
            rr = float(r["r"])
            if rp < 1 / 3:
                buckets["low (bottom third)"].append((rr, risk_pct))
            elif rp < 2 / 3:
                buckets["mid"].append((rr, risk_pct))
            else:
                buckets["high (top third)"].append((rr, risk_pct))
        for name, vals in buckets.items():
            n = len(vals)
            if n < 10:
                print(f"  {name:22s} n={n} (too few to read)")
                continue
            wr = len([v for v in vals if v[0] > 0]) / n * 100
            gross = statistics.mean(v[0] for v in vals)
            nets = {fname: statistics.mean(v[0] - frate / v[1] for v in vals) for fname, frate in FEE_SCENARIOS.items()}
            worst, best = min(nets.values()), max(nets.values())
            print(f"  {name:22s} n={n:5d} wr={wr:5.1f}% gross={gross:+.4f} net=[{worst:+.4f},{best:+.4f}]")

    print(f"\nDone. Per-symbol momentum-joined CSVs in {args.out}/")


if __name__ == "__main__":
    main()
