"""Единый запуск фоновых процессов без окон + защита от дублей. 2026-09-27.

    python bot_services.py start      # поднять всё, чего нет (без окон, логи в logs\\)
    python bot_services.py status     # кто работает, кто упал, дубли
    python bot_services.py dedupe     # оставить по одному экземпляру (старший), закрыть пустые окна
    python bot_services.py stop NAME  # остановить один сервис (paper10, tao_bb, eth_rsi, telegram, lab:<id>)
    python bot_services.py stop-paper # остановить все paper-процессы (реальные боты не трогает)

РЕАЛЬНЫЕ боты (Latuserge, KC/ROC grid) здесь не останавливаются и не переводятся в LIVE.
2026-11-16 (по решению владельца): сторож ПОДНИМАЕТ реального бота через панель, только если тот был
запущен в LIVE и не остановлен вручную/риск-центром (real_armed.json) — см. autostart_live().
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from pathlib import Path

BASE = Path(__file__).resolve().parent
LOGS = BASE / "logs"
BOTS = BASE / "bt_lab_bots"
PY = BASE / "venv" / "Scripts" / "python.exe"
PY = str(PY) if PY.exists() else sys.executable
WIN = os.name == "nt"

# name: (подпись, скрипт, аргументы, признак в командной строке помимо скрипта)
SERVICES = {
    "panel":    ("Панель TRADEOS", "windows_app\\run.py", [], None),
    "telegram": ("Telegram-бот (main.py)", "main.py", [], None),
    "paper10":  ("Paper 10 стратегий", "paper_live.py", ["--no-dashboard", "--telegram", "--log-file", "paper_live.log"], None),
    "tao_bb":   ("TAO BB paper x2", "veles_tao_bb.py", ["paper", "--leverage", "2"], " paper"),
    "watchdog": ("Сторож: перезапуск упавших", "bot_services.py", ["watch"], " watch"),
    "eth_rsi":  ("ETH RSI 4h paper", "eth_rsi_paper.py", ["--deposit", "100", "--leverage", "2", "--symbols", "BTC,ETH,SOL,DOGE"], None),
}
LIVE = {  # только статус. 2026-10-26: демо-копии (--demo) — отдельные строки, не «дубли» реальных
    "latuserge": ("Latuserge (LONG_STRATEGY 15)", "long_strategy15_latuserge_live.py", "!--demo"),
    "kcroc":     ("KC/ROC/CCI/WT grid", "kc_roc_cci_wt_grid_live.py", "!--demo"),
    "latuserge_demo": ("Latuserge DEMO (Bybit демо)", "long_strategy15_latuserge_live.py", "--demo"),
    "kcroc_demo":     ("KC/ROC DEMO (Bybit демо)", "kc_roc_cci_wt_grid_live.py", "--demo"),
}


def _procs() -> list[dict]:
    """Все python/cmd процессы: pid, ppid, имя, время старта, командная строка."""
    if not WIN:
        out = subprocess.run(["ps", "-eo", "pid=,ppid=,lstart=,args="], capture_output=True, text=True).stdout
        res = []
        for ln in out.splitlines():
            parts = ln.split(None, 7)
            if len(parts) >= 8:
                res.append({"pid": int(parts[0]), "ppid": int(parts[1]), "name": os.path.basename(parts[7].split()[0]),
                            "start": " ".join(parts[2:7]), "cmd": parts[7]})
        return res
    ps = ("Get-CimInstance Win32_Process -Filter \"Name='python.exe' or Name='pythonw.exe' or Name='cmd.exe'\" | "
          "Select-Object ProcessId,ParentProcessId,Name,@{n='S';e={$_.CreationDate.ToString('o')}},CommandLine | "
          "ConvertTo-Json -Compress")
    r = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    try:
        data = json.loads(r.stdout or "[]")
    except ValueError:
        return []
    if isinstance(data, dict):
        data = [data]
    return [{"pid": d["ProcessId"], "ppid": d["ParentProcessId"], "name": (d["Name"] or "").lower(),
             "start": d.get("S") or "", "cmd": d.get("CommandLine") or ""} for d in data]


def _py(procs):
    return [p for p in procs if p["name"].startswith("python")]


def _match(p, script, extra=None):
    import re
    c = " " + p["cmd"].lower().replace("/", "\\").replace('"', " ")
    ok = re.search(r"[\s\\]" + re.escape(script.lower()) + r"(\s|$)", c) is not None
    # extra — отдельное слово: иначе « watch» совпадал с «stop watchdog» и сторож убивал сам себя
    if ok and extra and extra.startswith("!"):   # «!слово» — в командной строке этого слова НЕТ
        return re.search(r"\s" + re.escape(extra[1:].lower()) + r"(\s|$)", c) is None
    return ok and (extra is None or re.search(r"\s" + re.escape(extra.strip().lower()) + r"(\s|$)", c) is not None)


def _lab_ids():
    ids = []
    if BOTS.exists():
        for f in BOTS.glob("*.json"):
            try:
                st = json.loads(f.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                continue
            if not isinstance(st, dict) or "id" not in st:   # 2026-10-10: служебные файлы (темы группы и т.п.) — не боты
                continue
            if not st.get("stopped") and not st.get("external") and not (BOTS / f"{st['id']}.stop").exists():
                ids.append((st["id"], st))
    return ids


_PANEL_PY = None


def _panel_python():
    """Панель открывается отдельным окном только если в этом python есть pywebview.
    В venv его может не быть (тогда панель уходит в браузер) — берём тот python, где он есть."""
    global _PANEL_PY
    if _PANEL_PY is None:
        _PANEL_PY = PY
        for cand in (PY, "python", "py"):
            try:
                r = subprocess.run([cand, "-c", "import webview"], capture_output=True, timeout=20,
                                   creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                if r.returncode == 0:
                    _PANEL_PY = cand
                    break
            except (OSError, subprocess.SubprocessError):
                continue
    return _PANEL_PY


def _all_defs():
    """Список (name, label, script, extra, argv|None, kind)."""
    out = [(n, lab, s, ex, [(_panel_python() if n == "panel" else PY), "-u", s, *a],
            "paper" if n not in ("panel", "telegram") else "service")
           for n, (lab, s, a, ex) in SERVICES.items()]
    for bid, st in _lab_ids():
        pr = st["params"]
        out.append((f"lab:{bid}", f"Бэктест-бот {pr.get('symbol')} · {pr.get('label') or pr.get('strategy')}"[:90],
                    "lab_paper.py", f"--id {bid}", [PY, "-u", "lab_paper.py", "--id", bid, "--params", json.dumps(pr)], "paper"))
    for n, (lab, s, ex) in LIVE.items():
        out.append((n, lab, s, ex, None, "live"))
    return out


def status() -> list[dict]:
    procs = _procs()
    py = _py(procs)
    rows = []
    for name, label, script, extra, argv, kind in _all_defs():
        m = sorted((p for p in py if _match(p, script, extra) and not _is_child_launcher(p, py, script)),
                   key=lambda p: p["start"])
        row = {"name": name, "label": label, "kind": kind, "running": bool(m), "count": len(m),
               "pids": [p["pid"] for p in m], "log": f"logs/{name.replace(':', '_')}.log"}
        if kind == "live" and m:
            row["mode"] = ("DEMO" if " --demo" in m[0]["cmd"] else "LIVE") if " --live" in m[0]["cmd"] else "PAPER"
        rows.append(row)
    return rows


def _is_child_launcher(p, py, script):
    # venv\Scripts\python.exe на Windows запускает настоящий python дочерним процессом с той же строкой:
    # считаем один экземпляр, если родитель — тот же скрипт.
    return any(q["pid"] == p["ppid"] and _match(q, script) for q in py)


def _kill(pid):
    """Убить ОДИН процесс, без /T. С /T taskkill убивал всё дерево: при остановке панели
    умирали запущенные из неё боты — paper и даже реальные (Latuserge/KC/ROC из «Арсенала»)."""
    if WIN:
        subprocess.run(["taskkill", "/PID", str(pid), "/F"], capture_output=True,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    else:
        try:
            os.kill(pid, 15)
        except OSError:
            pass


def _kill_with_window(p, procs):
    """Убить процесс + его python-копию-потомка с той же командной строкой (лаунчер venv)
    + его окно cmd /k. Остальных потомков (боты, запущенные панелью) не трогаем."""
    script_cmd = p["cmd"]
    for q in procs:
        # лаунчер venv\Scripts\python.exe запускает настоящий python с теми же аргументами
        if (q["ppid"] == p["pid"] and q["name"].startswith("python")
                and q["cmd"].strip()[-60:] == script_cmd.strip()[-60:]):
            _kill(q["pid"])
    _kill(p["pid"])
    parent = next((q for q in procs if q["pid"] == p["ppid"] and q["name"] == "cmd.exe" and "/k" in q["cmd"].lower()), None)
    if parent:
        _kill(parent["pid"])


def rotate_log(log_path, max_bytes=100 * 2**20, keep=5):
    """2026-11-21: ротация толстых логов (panel.log вырос до 544 МБ).
    Если лог больше max_bytes — переименовать в name_YYYYMMDD.log (при совпадении
    даты — _HHMMSS), старых name_*.log держать не больше keep, остальные удалить.
    Вызывать только ДО открытия лога новым процессом (старый уже убит):
    на Windows открытый кем-то файл переименовать нельзя. Ошибки глушим —
    ротация не должна мешать запуску."""
    p = Path(log_path)
    try:
        if not p.exists() or p.stat().st_size <= max_bytes:
            return None
        stamp = time.strftime("%Y%m%d")
        rotated = p.with_name(f"{p.stem}_{stamp}{p.suffix}")
        if rotated.exists():
            rotated = p.with_name(f"{p.stem}_{stamp}_{time.strftime('%H%M%S')}{p.suffix}")
        p.rename(rotated)
        old = sorted(p.parent.glob(f"{p.stem}_2*{p.suffix}"),
                     key=lambda f: f.stat().st_mtime)
        for f in old[:-keep]:
            f.unlink(missing_ok=True)
        return rotated
    except OSError:
        return None


def start(only=None, log=print):
    LOGS.mkdir(exist_ok=True)
    env = {**os.environ, "PYTHONIOENCODING": "utf-8", "PYTHONUTF8": "1"}
    flags = (getattr(subprocess, "CREATE_NO_WINDOW", 0) | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)) if WIN else 0
    st = {r["name"]: r for r in status()}
    for name, label, _s, _e, argv, kind in _all_defs():
        if kind == "live" or (only and name != only):
            continue
        off = LOGS / f"{name.replace(':', '_')}.off"
        if only:
            off.unlink(missing_ok=True)          # явный запуск снимает «выключен вручную»
        elif off.exists():
            continue                             # выключен человеком — сторож его не поднимает
        if st.get(name, {}).get("running"):
            log(f"  уже работает: {label}")
            continue
        log_path = LOGS / f"{name.replace(':', '_')}.log"
        rotated = rotate_log(log_path)
        if rotated:
            log(f"  лог {log_path.name} > 100 МБ — убран в {rotated.name}")
        f = open(log_path, "a", encoding="utf-8")
        f.write(f"\n===== старт {time.strftime('%Y-%m-%d %H:%M:%S')} =====\n"); f.flush()
        subprocess.Popen(argv, cwd=str(BASE), stdout=f, stderr=subprocess.STDOUT, stdin=subprocess.DEVNULL,
                         env=env, creationflags=flags, start_new_session=not WIN)
        log(f"  запущен:      {label}")


def stop(name, log=print):
    if name in LIVE:
        raise SystemExit("Реальные боты останавливаются только из панели («Арсенал» → Стоп).")
    if name != "panel":
        LOGS.mkdir(exist_ok=True)
        (LOGS / f"{name.replace(':', '_')}.off").write_text(time.strftime("%Y-%m-%d %H:%M"), encoding="utf-8")
    if name.startswith("lab:"):
        BOTS.mkdir(exist_ok=True)
        (BOTS / f"{name[4:]}.stop").write_text("stop", encoding="utf-8")
    procs = _procs(); py = _py(procs)
    for n, label, script, extra, _a, _k in _all_defs():
        if n == name:
            for p in py:
                if _match(p, script, extra) and not _is_child_launcher(p, py, script):
                    _kill_with_window(p, procs)
                    log(f"  остановлен: {label} (pid {p['pid']})")


def dedupe(log=print):
    procs = _procs(); py = _py(procs)
    for name, label, script, extra, _a, kind in _all_defs():
        m = sorted((p for p in py if _match(p, script, extra) and not _is_child_launcher(p, py, script)),
                   key=lambda p: p["start"])
        if len(m) > 1:
            if kind == "live":
                log(f"  ⚠ {label}: запущено {len(m)} копий — это РЕАЛЬНЫЙ бот, закрой лишние окна сам "
                    f"(pid {', '.join(str(p['pid']) for p in m[1:])})")
                continue
            for p in m[1:]:
                _kill_with_window(p, procs)
            log(f"  {label}: было {len(m)}, оставлен 1")
    # пустые окна cmd /k от наших .bat, у которых python уже умер
    procs = _procs(); alive = {p["ppid"] for p in procs}
    n = 0
    for p in procs:
        c = p["cmd"].lower()
        if p["name"] == "cmd.exe" and "/k" in c and "python" in c and p["pid"] not in alive:
            _kill(p["pid"]); n += 1
    if n:
        log(f"  закрыто пустых окон: {n}")


def memory() -> dict | None:
    """Занятость оперативной памяти ПК, % и ГБ (без сторонних библиотек)."""
    try:
        if WIN:
            import ctypes

            class MS(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("sullAvailExtendedVirtual", ctypes.c_ulonglong)]
            m = MS(); m.dwLength = ctypes.sizeof(MS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
            tot, av = m.ullTotalPhys, m.ullAvailPhys
        else:
            info = dict(l.split(":", 1) for l in open("/proc/meminfo"))
            tot = int(info["MemTotal"].split()[0]) * 1024; av = int(info["MemAvailable"].split()[0]) * 1024
        return {"used_pct": round((1 - av / tot) * 100, 1), "total_gb": round(tot / 2**30, 1), "free_gb": round(av / 2**30, 1)}
    except Exception:  # noqa: BLE001
        return None


def tail(name, n=80) -> str:
    f = LOGS / f"{name.replace(':', '_')}.log"
    if not f.exists():
        return "(лога нет — процесс запущен не через bot_services, смотри его окно)"
    with open(f, "rb") as fh:
        fh.seek(0, 2); size = fh.tell(); fh.seek(max(0, size - 40_000))
        return "\n".join(fh.read().decode("utf-8", "replace").splitlines()[-n:])


# ---------------------------------------------------------------- 2026-10-22: связь и «тихие» live-боты --
# Сторож раз в 2 минуты проверяет, отвечают ли Telegram, OKX и Bybit. Если связь пропадала дольше 5 минут —
# когда она вернётся, присылает в Telegram «Связи не было с … по …». После 12 минут непрерывной
# недоступности Bybit/OKX шлёт отдельный алерт, никого не перезапуская. И следит за live-ботами по их файлам
# состояния: если файл не обновлялся дольше порога — пишет предупреждение. Автоподъём LIVE — autostart_live().
# Токен берётся из .env и нигде не печатается.
NET_TARGETS = {"Telegram": "https://api.telegram.org", "OKX": "https://www.okx.com/api/v5/public/time",
               "Bybit": "https://api.bybit.com/v5/market/time"}
LIVE_STATE = {  # бот: (файл состояния, порог в минутах)
    "Latuserge": ("long_strategy15_latuserge_live_state.json", 30),
    "KC/ROC грид": ("kc_roc_cci_wt_grid_live_state.json", 30),
    "Combo XRP (OKX)": ("combo_xrp_live_state.json", 90),
}
_NET = {"down": {}, "pending": [], "stale": {}, "last_successful_exchange_sync": {}, "sync_alerted": {}}


def _env():
    try:
        from dotenv import load_dotenv  # noqa: PLC0415
        load_dotenv(BASE / ".env")
    except Exception:  # noqa: BLE001
        pass
    return os.environ.get("TELEGRAM_BOT_TOKEN"), os.environ.get("TELEGRAM_CHAT_ID")


def _tg_send(text):
    token, chat = _env()
    if not token or not chat:
        return False
    try:
        import requests  # noqa: PLC0415
        r = requests.post(f"https://api.telegram.org/bot{token}/sendMessage",
                          data={"chat_id": chat, "text": text}, timeout=15)
        return r.ok
    except Exception:  # noqa: BLE001 -- текст ошибки может содержать адрес с токеном — не печатаем
        return False


def _hm(ts):
    return time.strftime("%d.%m %H:%M", time.localtime(ts))


def net_check(log=print):
    import requests  # noqa: PLC0415
    now = time.time()
    for name, url in NET_TARGETS.items():
        ok = False
        for _ in range(2):
            try:
                requests.get(url, timeout=10); ok = True; break
            except Exception:  # noqa: BLE001
                time.sleep(3)
        down = _NET["down"]
        if not ok and name not in down:
            down[name] = now
            log(f"{time.strftime('%H:%M:%S')} нет связи: {name}")
        elif ok and name in down:
            t0 = down.pop(name)
            mins = (now - t0) / 60
            log(f"{time.strftime('%H:%M:%S')} связь вернулась: {name} (не было {mins:.0f} мин)")
            if mins >= 5:
                _NET["pending"].append(f"• {name}: не было с {_hm(t0)} по {_hm(now)} ({mins:.0f} мин)")
        if ok:
            _NET["last_successful_exchange_sync"][name] = now
            _NET["sync_alerted"].pop(name, None)
        elif name in ("Bybit", "OKX"):
            mins = (now - down[name]) / 60
            if mins >= 12 and name not in _NET["sync_alerted"]:
                _NET["sync_alerted"][name] = now
                log(f"{time.strftime('%H:%M:%S')} {name}: нет успешной синхронизации {mins:.0f} мин — алерт")
                _NET["pending"].append(
                    f"• 🚨 {name}: нет успешной синхронизации {mins:.0f} мин — боты НЕ перезапускаю"
                )
    # live-боты: давно не обновляли файл состояния
    for bot, (fn, lim) in LIVE_STATE.items():
        f = BASE / fn
        if not f.exists():
            continue
        age = (now - f.stat().st_mtime) / 60
        st = _NET["stale"]
        if age > lim and (bot not in st or now - st[bot] > 6 * 3600):
            st[bot] = now
            log(f"{time.strftime('%H:%M:%S')} {bot}: состояние не обновлялось {age:.0f} мин")
            _NET["pending"].append(f"• ⚠️ {bot}: не обновлялся {age:.0f} мин — проверь в панели (возможно, завис)")
        elif age <= lim and bot in st:
            st.pop(bot)
            _NET["pending"].append(f"• ✅ {bot}: снова работает")
    if _NET["pending"] and "Telegram" not in _NET["down"]:
        msg = "🛰 Сторож TRADEOS\n" + "\n".join(_NET["pending"][-15:])
        if "Telegram" in msg or "OKX" in msg or "Bybit" in msg:
            msg += "\n\nПока связи не было, сигналы и ордера могли не пройти. Частая причина — VPN."
        if _tg_send(msg):
            _NET["pending"].clear()



# ---------------------------------------------------------------- 2026-11-16: автоподъём реальных ботов --
# Владелец разрешил: если реальный бот был запущен в LIVE («вооружён» — real_armed.json, флаг ставит панель)
# и его процесса нет (перезагрузка ПК, падение) — сторож поднимает его через панель, тем же путём, что кнопка.
# Не поднимает: остановленных вручную, остановленных риск-центром (флаг снят), больше 3 раз за час (тогда
# снимает флаг и шлёт тревогу). Первые 3 минуты после старта сторожа ждёт, пока поднимется панель.
ARMED_FILE = BASE / "real_armed.json"
ARMED_HISTORY = LOGS / "armed_history.log"
REAL_IDS = {  # id в панели: (подпись, скрипт)
    "latuserge": ("Latuserge", "long_strategy15_latuserge_live.py"),
    "kc_roc": ("KC/ROC грид", "kc_roc_cci_wt_grid_live.py"),
    "combo_xrp": ("Combo XRP (OKX)", "combo_xrp_live.py"),
}
_AUTO = {"t0": time.time(), "hist": {}, "skip": {}}


def _armed() -> dict:
    try:
        return json.loads(ARMED_FILE.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {}


def _append_armed_history(sid, armed, why, source, pid=None):
    now = time.time()
    event = {
        "time": time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(now)),
        "ts": int(now),
        "strategy": sid,
        "armed": bool(armed),
        "why": why,
        "pid": pid,
        "source": source,
        "actor_pid": os.getpid(),
    }
    try:
        ARMED_HISTORY.parent.mkdir(parents=True, exist_ok=True)
        with ARMED_HISTORY.open("a", encoding="utf-8") as history:
            history.write(json.dumps(event, ensure_ascii=False) + "\n")
    except Exception as exc:  # noqa: BLE001 -- журнал не должен мешать работе сторожа
        print(f"[armed_history] {type(exc).__name__}: {exc}", file=sys.stderr)


def _disarm(sid, why):
    _append_armed_history(sid, False, why, "watchdog")
    d = _armed(); d[sid] = {"armed": False, "why": why, "ts": int(time.time())}
    tmp = ARMED_FILE.with_suffix(".tmp"); tmp.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(ARMED_FILE)


def autostart_live(log=print):
    if time.time() - _AUTO["t0"] < 180:
        return
    import urllib.request  # noqa: PLC0415
    procs = _py(_procs())
    for sid, (label, script) in REAL_IDS.items():
        a = _armed().get(sid) or {}
        running = any(_match(p, script, "!--demo") and " --live" in (" " + p["cmd"]) for p in procs)
        if running:
            _AUTO["skip"].pop(sid, None)
        if not a.get("armed"):
            if not running:
                reason = str(a.get("why") or "причина не указана")
                if _AUTO["skip"].get(sid) != reason:
                    log(f"не перезапускаю {sid}: armed=false ({reason})")
                    _AUTO["skip"][sid] = reason
            continue
        if running:
            continue
        _AUTO["skip"].pop(sid, None)
        h = [t for t in _AUTO["hist"].get(sid, []) if time.time() - t < 3600]
        if len(h) >= 3:
            _disarm(sid, "3 автоперезапуска за час")
            _tg_send(f"🚨 Сторож: {label} падает снова и снова (3 перезапуска за час). Автоподъём выключен — "
                     f"проверь логи и запусти вручную.")
            log(f"{label}: 3 перезапуска за час — автоподъём выключен")
            continue
        try:
            req = urllib.request.Request(f"http://127.0.0.1:8765/api/strategies/{sid}/start", method="POST",
                                         data=json.dumps({"mode": "live", "confirm_live": True, "why": "автоподъём сторожем"}).encode(),
                                         headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(req, timeout=40) as r:
                res = json.loads(r.read().decode("utf-8") or "{}")
        except Exception as exc:  # noqa: BLE001
            log(f"{label}: не смог поднять ({type(exc).__name__}: {exc}) — повторю через 2 мин")
            continue
        h.append(time.time()); _AUTO["hist"][sid] = h
        ok = res.get("running")
        log(f"{label}: автоподъём в LIVE — {'ок, pid ' + str(res.get('pid')) if ok else res}")
        _tg_send(f"🔁 Сторож: {label} не работал — поднял в РЕАЛ{' (pid ' + str(res.get('pid')) + ')' if ok else ''}. "
                 f"Проверь позиции и стопы.")


def main():
    a = sys.argv[1:] or ["status"]
    cmd = a[0]
    if cmd == "start":
        print("Дубли и пустые окна…"); dedupe()
        print("Запуск (без окон, логи в папке logs):"); start(a[1] if len(a) > 1 else None)
        time.sleep(3)
    elif cmd == "dedupe":
        dedupe()
    elif cmd == "stop" and len(a) > 1:
        stop(a[1])
    elif cmd == "watch":
        # Сторож: раз в 2 минуты поднимает упавшие paper-боты и сервисы (не реальных ботов,
        # не тех, кого человек остановил сам). Всё, что сделал, — в logs/watchdog.log.
        # 2026-09-28: и сам перезапускает панель, когда меняется её код (windows_app\*.py) —
        # больше не нужно запускать restart_panel.bat после обновлений. Боты при этом не трогаются.
        quiet = []
        code_dir = BASE / "windows_app"
        def code_mtime():
            try:
                return max((f.stat().st_mtime for f in code_dir.glob("*.py")), default=0)
            except OSError:
                return 0
        seen_code = code_mtime()
        last_full = 0.0
        while True:
            try:
                cur = code_mtime()
                if cur > seen_code and time.time() - cur > 15:     # файлы дописаны, не в процессе копирования
                    seen_code = cur
                    print(time.strftime("%H:%M:%S"), "код панели обновлён — перезапускаю панель", flush=True)
                    stop("panel", log=lambda m: None)
                    time.sleep(3)
                    start("panel", log=lambda m: None)
                if time.time() - last_full >= 120:
                    last_full = time.time()
                    try:
                        net_check(log=lambda m: print(m, flush=True))
                    except Exception as exc:  # noqa: BLE001
                        print(time.strftime("%H:%M:%S"), "проверка связи: ошибка", type(exc).__name__, flush=True)
                    start(None, log=lambda m: quiet.append(m) if "запущен" in m else None)
                    try:
                        autostart_live(log=lambda m: print(time.strftime("%H:%M:%S"), "реал:", m, flush=True))
                    except Exception as exc:  # noqa: BLE001
                        print(time.strftime("%H:%M:%S"), "автоподъём реала: ошибка", type(exc).__name__, exc, flush=True)
                    for m in quiet:
                        print(time.strftime("%H:%M:%S"), "поднял упавший:", m.strip(), flush=True)
                    quiet.clear()
            except Exception as exc:  # noqa: BLE001 -- сторож не должен падать
                print(time.strftime("%H:%M:%S"), "ошибка:", exc, flush=True)
            time.sleep(20)
    elif cmd == "restart-lab":
        # перезапуск всех бэктест-ботов (новый код), без файла .stop — они продолжают свой счёт
        procs = _procs(); py = _py(procs)
        for p_ in py:
            if _match(p_, "lab_paper.py") and not _is_child_launcher(p_, py, "lab_paper.py"):
                _kill_with_window(p_, procs)
        time.sleep(2)
        start()
    elif cmd == "stop-paper":
        for r in status():
            if r["kind"] == "paper" and r["running"]:
                stop(r["name"])
    elif cmd == "netcheck":                       # ручная проверка: python bot_services.py netcheck
        net_check(); print(("НЕ отвечают: " + ", ".join(_NET["down"])) if _NET["down"] else "Связь в порядке: Telegram, OKX и Bybit отвечают"); return
    elif cmd == "log" and len(a) > 1:
        print(tail(a[1])); return
    elif cmd != "status":
        print(__doc__); return
    print()
    for r in status():
        mark = "🟢" if r["running"] else "⚪"
        extra = f" · {r['mode']}" if r.get("mode") else ""
        dup = f" · ⚠ копий: {r['count']}" if r["count"] > 1 else ""
        print(f" {mark} {r['label']}{extra}{dup}")


if __name__ == "__main__":
    main()
