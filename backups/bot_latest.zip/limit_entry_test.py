"""limit_entry_test.py — 2026-11-02. Вход лимиткой по сигналам РАБОЧИХ стратегий (Trendilo, EFE, Stocks Algo, TTSS, EMA 50/150 — выход
по обратному сигналу, стоп 2 ATR; Forecasting MACD+ — стоп 1.5 ATR, тейк 3R). Комиссии Hash Hedge: тейкер 0.03%, мейкер 0.01% за сторону.
Способы входа:  M  — по рынку на закрытии сигнальной свечи (0.03% вход);
  L>M k — лимитка на k·ATR лучше закрытия, живёт W свечей; исполнилась (цена прошла СКВОЗЬ уровень) — вход по лимиту (0.01%),
          нет — по рынку на закрытии W-й свечи (0.03%);   L>X k — то же, но не исполнилась — сделку пропускаем.
Стоп/тейк считаются от фактической цены входа; если в свечу исполнения цена дошла и до стопа — считаем стоп (худший случай).
Выход по рынку (0.03%), тейк — лимитом (0.01%). 12 монет, 2h/4h. Пишет bt_lab_bots/limit_entry_test.txt"""
from __future__ import annotations
import sys, time
from pathlib import Path
try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass
BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import numpy as np  # noqa: E402
import recheck_recent as RR  # noqa: E402
import tg_port as T  # noqa: E402
import cs_port as P  # noqa: E402
TK, MK = 0.0003, 0.0001
W = 2


def run(d, a, ent, mode, k, kind, hold=300):
    t, o, h, l, c = d.t.values, d.o.values, d.h.values, d.l.values, d.c.values; n = len(c); out = []; miss = 0
    idx = np.flatnonzero(ent); q = 0; busy_until = -1
    for i in idx:
        if i < 250 or i >= n - W - 1 or i <= busy_until or not a[i] > 0:
            continue
        s = int(ent[i]); fill_i = None; fee_in = TK; e = c[i]
        if mode != "M":
            lim = c[i] - s * k * a[i]
            for j in range(i + 1, i + 1 + W):
                if (l[j] < lim) if s > 0 else (h[j] > lim):
                    fill_i, e, fee_in = j, lim, MK; break
            if fill_i is None:
                if mode == "LX":
                    miss += 1; continue
                fill_i, e = i + W, c[i + W]
        else:
            fill_i = i
        risk = (2.0 if kind == "rev" else 1.5) * a[i]; stp = e - s * risk; tp = e + s * 3 * risk if kind == "tp3" else None
        res = None; start = fill_i
        if mode != "M" and fee_in == MK and ((l[fill_i] <= stp) if s > 0 else (h[fill_i] >= stp)):
            res = (fill_i, -1.0, TK)
        if res is None:
            for j in range(start + 1, min(n, start + hold)):
                if (l[j] <= stp) if s > 0 else (h[j] >= stp): res = (j, -1.0, TK); break
                if tp is not None and ((h[j] >= tp) if s > 0 else (l[j] <= tp)): res = (j, 3.0, MK); break
                if kind == "rev" and ent[j] == -s: res = (j, s * (c[j] - e) / risk, TK); break
        if res is None:
            j = min(n - 1, start + hold - 1); res = (j, s * (c[j] - e) / risk, TK)
        out.append((int(t[i]), res[1] - (fee_in + res[2]) * e / risk)); busy_until = res[0] - (1 if kind == "rev" else 0)
    return out, miss


def main():
    import kvoo_longtest as K  # noqa: PLC0415
    now = int(time.time() * 1000); lines = []
    STR = {"Trendilo": ("rev", lambda d: T.s_trendilo(d)), "SIMPLE EFE": ("rev", lambda d: T.s_efe(d)),
           "Stocks Algo": ("rev", lambda d: T.s_stocks_algo(d)), "Magic TTSS": ("rev", lambda d: T.s_ttss(d)),
           "EMA 50/150": ("rev", lambda d: T.s_ema_50_150(d)),
           "Forecasting MACD+": ("tp3", lambda d: (lambda F: np.where(F["buy"], 1, np.where(F["sell"], -1, 0)))(P.forecasting(d)))}
    MODES = [("M", 0.0)] + [(m, k) for m in ("LM", "LX") for k in (0.1, 0.25, 0.5)]
    for tf in ("2h", "4h"):
        data = []
        for s in K.COINS:
            try:
                d = RR.load(s, tf)
            except Exception:  # noqa: BLE001
                d = None
            if d is None or len(d) < 1500:
                continue
            d = d.reset_index(drop=True).iloc[-12000:].reset_index(drop=True)
            if "v" not in d:
                d["v"] = 0.0
            data.append((s, d, T.atr(d, 14)))
        mid = (min(int(d.t.iloc[0]) for _s, d, _a in data) + now) // 2
        lines.append(f"\n=== {tf} · {len(data)} монет ===  способ входа · сделок (пропущено) · R/сд · всё · 1пол · 2пол · 180д · монет+")
        for nm, (kind, fn) in STR.items():
            ents = [np.asarray(fn(d)) for _s, d, _a in data]
            for mode, k in MODES:
                al = []; pos = 0; miss = 0
                for (s, d, a), ent in zip(data, ents):
                    tr, m = run(d, a, ent, mode, k, kind); al += tr; miss += m; pos += sum(x for _t, x in tr) > 0
                if not al:
                    continue
                tot = sum(x for _t, x in al); h1 = sum(x for tt, x in al if tt < mid); w180 = sum(x for tt, x in al if tt >= now - 180 * 86400_000)
                lab = "по рынку" if mode == "M" else f"{'лимит→рынок' if mode == 'LM' else 'лимит→пропуск'} {k}ATR"
                line = f"{nm:<18} {lab:<22} {len(al):5} ({miss:4}) · {tot / len(al):+.3f} · {tot:+7.1f} · {h1:+6.1f} · {tot - h1:+6.1f} · {w180:+6.1f} · {pos}/{len(data)}"
                print(line, flush=True); lines.append(line)
    (BASE / "bt_lab_bots" / "limit_entry_test.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("готово")


if __name__ == "__main__":
    main()
