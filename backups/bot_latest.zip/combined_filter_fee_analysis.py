#!/usr/bin/env python3
"""
Combines strategy_filter_analysis.py's filtering with fee_analysis.py's
per-trade fee-in-R adjustment, so a candidate filter (e.g. "exclude
BTCUSDT + drop BOS") gets tested under realistic trading costs directly on
its own subset -- not by naively subtracting the unfiltered dataset's
average fee drag, which is wrong once the trade mix changes (e.g. dropping
BTCUSDT, which has unusually tight % stops and therefore an unusually high
fee-in-R, changes the average fee cost of what's left).

Run after backtest.py has produced CSVs in backtest_out/:
    python combined_filter_fee_analysis.py
"""
from __future__ import annotations

import csv
from pathlib import Path

FEE_SCENARIOS = {
    "taker+taker (~0.11%)": 0.0011,
    "taker+maker (~0.075%)": 0.00075,
    "maker+maker (~0.04%)": 0.0004,
}


def load_trades(directory: Path) -> list:
    trades = []
    for path in sorted(directory.glob("*_trades.csv")):
        with path.open(newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                if row.get("r") in (None, "", "None"):
                    continue
                try:
                    row["r"] = float(row["r"])
                    row["entry"] = float(row["entry"])
                    row["stop_loss"] = float(row["stop_loss"])
                except (TypeError, ValueError):
                    continue
                trades.append(row)
    return trades


def gross_stats(trades: list) -> dict:
    if not trades:
        return {"n": 0, "win_rate": float("nan"), "avg_r": float("nan")}
    wins = sum(1 for t in trades if t["r"] > 0)
    return {"n": len(trades), "win_rate": wins / len(trades) * 100,
            "avg_r": sum(t["r"] for t in trades) / len(trades)}


def net_stats(trades: list, fee_rate: float) -> dict:
    net_rs = []
    for t in trades:
        risk_pct = abs(t["entry"] - t["stop_loss"]) / t["entry"]
        if risk_pct <= 0:
            continue
        net_rs.append(t["r"] - fee_rate / risk_pct)
    if not net_rs:
        return {"n": 0, "avg_net_r": float("nan"), "win_rate": float("nan")}
    wins = sum(1 for r in net_rs if r > 0)
    return {"n": len(net_rs), "avg_net_r": sum(net_rs) / len(net_rs),
            "win_rate": wins / len(net_rs) * 100}


def report(label: str, trades: list) -> None:
    g = gross_stats(trades)
    if g["n"] == 0:
        print(f"\n{label}: n=0, skipping")
        return
    print(f"\n{label}")
    print(f"  gross: n={g['n']}  win rate={g['win_rate']:.1f}%  avg R={g['avg_r']:+.3f}")
    for fee_label, fee_rate in FEE_SCENARIOS.items():
        n = net_stats(trades, fee_rate)
        print(f"  net @ {fee_label:22s} avg R={n['avg_net_r']:+.3f}  win rate(net>0)={n['win_rate']:.1f}%")


def main() -> None:
    directory = Path("backtest_out")
    trades = load_trades(directory)
    if not trades:
        print(f"No resolved trades found in {directory.resolve()} -- run backtest.py first.")
        return

    report("Baseline (everything fired)", trades)
    report("Exclude BTCUSDT only", [t for t in trades if t["symbol"] != "BTCUSDT"])
    report("Exclude BOS only", [t for t in trades if t["event"] != "BOS"])
    report("Exclude BTCUSDT + exclude BOS (best gross candidate)",
           [t for t in trades if t["symbol"] != "BTCUSDT" and t["event"] != "BOS"])
    report("Only zone_kind=OB+FVG (smaller n, exploratory)",
           [t for t in trades if t.get("zone_kind") == "OB+FVG"])

    print(
        "\nA candidate is only worth shipping if avg net R is positive at "
        "taker+maker or better AND n stays in the hundreds+ -- maker+maker-only "
        "positive with taker+taker still negative means it only works if every "
        "single entry and exit is a resting limit order, which isn't realistic "
        "for a live discretionary trader reacting to a signal."
    )


if __name__ == "__main__":
    main()
