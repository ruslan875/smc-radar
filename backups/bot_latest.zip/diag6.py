# 2026-11-16 (d): new.html -> index.html (с бэкапом)
import shutil
from pathlib import Path
S = Path(__file__).resolve().parent / "windows_app" / "static"
shutil.copy2(S / "index.html", S / "index.before-tos1116.html")
shutil.copy2(S / "new.html", S / "index.html")
print("ok")
