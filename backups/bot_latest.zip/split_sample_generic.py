#!/usr/bin/env python3
"""
Generic early/late split-sample check for any app/indicators/ module's
output from generic_backtest.py / compare_indicators.py (the SMC bot has
its own dedicated split_sample_validation.py -- this is the same idea,
generalized to any generic_backtest_out/<indicator>/*_trades.csv).

Splits the resolved trades by time at the median into an EARLIER half and
a LATER half, and reports gross/net R (three fee scenarios) separately
for each -- same discipline that revealed parad_wt/parad_rsi's initial
"positive" 31-day result was just one lucky half of a 2-year window, not
a real edge (see pine-indicators-python-port doc). Do not trust a single-
window average; only trust an edge that survives BOTH halves.

Run (after compare_indicators.py has written generic_backtest_out/<name>/):

    python split_sample_generic.py --indicator liquidity_sweep_mss_fvg

For a real verdict (not just directional signal), re-run the backtest
itself on a much longer window first -- the same short-window trap that
initially fooled parad_wt/parad_rsi:

    python compare_indicators.py --indicators liquidity_sweep_mss_fvg --bars 17520
    python split_sample_generic.py --indicator liquidity_sweep_mss_fvg
"""
from __future__ import annotations

import argparse
import csv
from pathlib import Path

FEE_SCENARIOS = {
    "taker+taker (~0.11%)": 0.0011,
    "taker+maker (~0.075%)": 0.00075,
    "maker+maker (~0.04%)": 0.0004,
}


def load_trades(directory: Path) -> list:
    trades = []
    for path in sorted(directory.glob("*_trades.csv")):
        with path.open(newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                if row.get("r") in (None, "", "None") or not row.get("time"):
                    continue
                try:
                    row["r"] = float(row["r"])
                    row["entry"] = float(row["entry"])
                    row["stop_loss"] = float(row["stop_loss"])
                except (TypeError, ValueError):
                    continue
                trades.append(row)
    return trades


def gross_stats(trades: list) -> dict:
    if not trades:
        return {"n": 0, "win_rate": float("nan"), "avg_r": float("nan")}
    wins = sum(1 for t in trades if t["r"] > 0)
    return {"n": len(trades), "win_rate": wins / len(trades) * 100,
            "avg_r": sum(t["r"] for t in trades) / len(trades)}


def net_stats(trades: list, fee_rate: float) -> dict:
    net_rs = []
    for t in trades:
        risk_pct = abs(t["entry"] - t["stop_loss"]) / t["entry"]
        if risk_pct <= 0:
            continue
        net_rs.append(t["r"] - fee_rate / risk_pct)
    if not net_rs:
        return {"n": 0, "avg_net_r": float("nan")}
    return {"n": len(net_rs), "avg_net_r": sum(net_rs) / len(net_rs)}


def report(label: str, trades: list) -> None:
    g = gross_stats(trades)
    if g["n"] == 0:
        print(f"  {label}: n=0, skipping")
        return
    print(f"  {label}")
    print(f"    gross: n={g['n']}  win rate={g['win_rate']:.1f}%  avg R={g['avg_r']:+.3f}")
    for fee_label, fee_rate in FEE_SCENARIOS.items():
        n = net_stats(trades, fee_rate)
        print(f"    net @ {fee_label:22s} avg R={n['avg_net_r']:+.3f}  (n={n['n']})")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--indicator", required=True, help="Module name under app/indicators/ (e.g. liquidity_sweep_mss_fvg)")
    parser.add_argument("--out-dir", default="generic_backtest_out")
    args = parser.parse_args()

    directory = Path(args.out_dir) / args.indicator
    trades = load_trades(directory)
    if not trades:
        print(f"No resolved trades with a time field found in {directory.resolve()} "
              f"-- run compare_indicators.py or generic_backtest.py for this indicator first.")
        return

    times = sorted(t["time"] for t in trades)
    cutoff = times[len(times) // 2]
    print(f"Loaded {len(trades)} resolved trades, {times[0]} .. {times[-1]}")
    print(f"Splitting at midpoint: {cutoff}\n")

    early = [t for t in trades if t["time"] < cutoff]
    late = [t for t in trades if t["time"] >= cutoff]

    for label, half in (("EARLIER half (out-of-sample)", early),
                         ("LATER half (closer to 'now')", late)):
        print(f"=== {label} ===")
        report(f"{args.indicator}", half)
        print()

    print(
        "Reading this: only trust the indicator if net R is positive (at taker+maker "
        "or maker+maker) in BOTH halves. Positive only in the LATER half is the exact "
        "shape that fooled the initial parad_wt/parad_rsi read on the 31-day window -- "
        "re-run with more bars (--bars 17520) before drawing any conclusion from a short "
        "window's split."
    )


if __name__ == "__main__":
    main()
