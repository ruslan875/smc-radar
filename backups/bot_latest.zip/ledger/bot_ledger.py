"""bot_ledger.py — 2026-10-25. Свой учёт позиции у каждого бота на ОБЩЕМ счёте (как в GinArea).

Проблема: на одном счёте (one-way) биржа сливает сделки ботов по одной монете в ОДНУ позицию.
Решение: у каждого бота своя «виртуальная позиция» (объём, средняя, стоп, id своего стоп-ордера):
  • вход/добор — обычный ордер; объём записывается боту, который его поставил (по orderLinkId/clOrdId);
  • выход — reduce-only ордер РОВНО на свой объём, а не «закрыть позицию»;
  • стоп — ОТДЕЛЬНЫЙ условный reduce-only ордер на свой объём (Bybit: tpslMode=Partial, slSize; OKX: algo sz);
  • сверка: сумма объёмов ботов должна совпадать с позицией на бирже; расхождение → тревога и стоп новых входов;
  • встречная сторона на one-way запрещена: шорт одного бота «съел» бы лонг другого.
Этот модуль — ТОЛЬКО логика учёта. Ордера отправляет адаптер биржи (в тесте — симулятор).
"""
from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from pathlib import Path

EPS = 1e-9


@dataclass
class BotPos:
    bot: str
    side: int = 0            # +1 лонг, −1 шорт, 0 нет позиции
    qty: float = 0.0
    avg: float = 0.0
    sl: float | None = None
    sl_order: str | None = None   # id своего стоп-ордера на бирже
    realized: float = 0.0


@dataclass
class Ledger:
    """Учёт по одной монете на одном счёте. Хранится в файле, переживает перезапуск."""
    symbol: str
    bots: dict[str, BotPos] = field(default_factory=dict)
    alerts: list[str] = field(default_factory=list)
    blocked: bool = False      # True после расхождения со счётом — новые входы запрещены до разбора

    # ---------- хранение ----------
    def save(self, path: Path) -> None:
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps({"symbol": self.symbol, "blocked": self.blocked, "alerts": self.alerts[-50:],
                                   "bots": {k: asdict(v) for k, v in self.bots.items()}}, ensure_ascii=False, indent=1), "utf-8")
        tmp.replace(path)

    @classmethod
    def load(cls, path: Path, symbol: str) -> "Ledger":
        if not path.exists():
            return cls(symbol)
        d = json.loads(path.read_text("utf-8"))
        return cls(d["symbol"], {k: BotPos(**v) for k, v in d["bots"].items()}, d.get("alerts", []), d.get("blocked", False))

    # ---------- запросы ----------
    def pos(self, bot: str) -> BotPos:
        return self.bots.setdefault(bot, BotPos(bot))

    def net(self) -> float:
        return sum(p.side * p.qty for p in self.bots.values())

    def can_open(self, bot: str, side: int) -> tuple[bool, str]:
        if self.blocked:
            return False, "учёт расходится со счётом — новые входы остановлены до сверки"
        for p in self.bots.values():
            if p.bot != bot and p.qty > EPS and p.side != side:
                return False, f"у бота {p.bot} открыта встречная позиция — на общем счёте (one-way) они бы взаимно закрылись"
        return True, ""

    # ---------- события от исполнения ордеров ----------
    def on_fill(self, bot: str, side: int, qty: float, price: float, reduce: bool) -> None:
        p = self.pos(bot)
        if not reduce:
            if p.qty > EPS and p.side != side:
                raise ValueError("встречный вход своего же бота — сначала закрыть")
            p.avg = (p.avg * p.qty + price * qty) / (p.qty + qty)
            p.qty += qty
            p.side = side
        else:
            q = min(qty, p.qty)
            p.realized += (price - p.avg) * q * p.side
            p.qty -= q
            if p.qty <= EPS:
                p.qty, p.side, p.avg, p.sl, p.sl_order = 0.0, 0, 0.0, None, None

    # ---------- сверка со счётом ----------
    def reconcile(self, exch_net: float, tol: float = 1e-6) -> bool:
        diff = exch_net - self.net()
        if abs(diff) > tol * max(1.0, abs(exch_net)):
            self.blocked = True
            self.alerts.append(f"{self.symbol}: на бирже {exch_net:+.6g}, по учёту ботов {self.net():+.6g} "
                               f"(разница {diff:+.6g}) — новые входы остановлены")
            return False
        return True
