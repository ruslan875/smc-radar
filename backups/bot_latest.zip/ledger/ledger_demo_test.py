"""ledger_demo_test.py — 2026-10-25. Проверка «каждый бот — свой объём» на ДЕМО-счёте Bybit (api-demo.bybit.com).

Только демо: адрес биржи зашит api-demo.bybit.com — реальные деньги этим скриптом тронуть нельзя.
Ключ вводится в окне при запуске (не сохраняется, не печатается, никуда не отправляется, кроме Bybit Demo).

Что проверяем на настоящей бирже (режим one-way, ETHUSDT, мелкий объём):
 1. «Бот A» покупает 0.02 ETH, «бот B» — 0.01 ETH: на бирже одна позиция 0.03.
 2. Каждый ставит СВОЙ частичный стоп (tpslMode=Partial): A — на 0.02, B — на 0.01.
 3. На бирже два отдельных стоп-ордера с этими объёмами.
 4. A закрывает свои 0.02 (reduce-only) и снимает свой стоп → позиция 0.01, стоп B на месте и на 0.01.
 5. Уборка: B закрывает своё, стопы снимаются, позиция 0.
Отчёт: ledger_demo_report.txt
"""
from __future__ import annotations

import getpass, hashlib, hmac, json, time, uuid
from pathlib import Path

import requests

BASE = "https://api-demo.bybit.com"      # ТОЛЬКО ДЕМО
SYM, CAT = "ETHUSDT", "linear"
OUT = Path(__file__).with_name("ledger_demo_report.txt")
LINES: list[str] = []
K = {"key": "", "sec": ""}


def say(s=""):
    print(s, flush=True); LINES.append(s)


OFFSET = {"ms": 0}   # поправка часов ПК к часам Bybit


def sync_time() -> None:
    """Часы ПК могут отставать/спешить — подписи Bybit тогда отклоняет (10002). Берём время сервера."""
    t0 = time.time()
    r = requests.get(f"{BASE}/v5/market/time", timeout=30).json()
    srv = int(r["result"]["timeNano"]) // 1_000_000 if r.get("result", {}).get("timeNano") else int(r["time"])
    OFFSET["ms"] = srv - int((t0 + time.time()) / 2 * 1000)


def call(method: str, path: str, params: dict | None = None) -> dict:
    params = params or {}
    rw = "60000"   # связь через VPN бывает с задержкой 20+ с
    if method == "GET":
        payload = "&".join(f"{k}={v}" for k, v in params.items())
        url, body = f"{BASE}{path}" + (f"?{payload}" if payload else ""), None
    else:
        payload = json.dumps(params, separators=(",", ":")); url, body = f"{BASE}{path}", payload
    last = None
    for att in range(6):                       # 2026-10-25: связь с Bybit через VPN рвётся — повторы
        ts = str(int(time.time() * 1000) + OFFSET["ms"])     # подпись — заново на каждую попытку (иначе «устаревает»)
        sign = hmac.new(K["sec"].encode(), (ts + K["key"] + rw + payload).encode(), hashlib.sha256).hexdigest()
        h = {"X-BAPI-API-KEY": K["key"], "X-BAPI-SIGN": sign, "X-BAPI-TIMESTAMP": ts, "X-BAPI-RECV-WINDOW": rw,
             "Content-Type": "application/json"}
        try:
            r = requests.request(method, url, headers=h, data=body, timeout=30).json()
        except (requests.RequestException, ValueError) as e:
            last = e
            print(f"   связь с Bybit Demo: попытка {att + 1}/6 не удалась, повторяю…", flush=True)
            time.sleep(3 * (att + 1)); continue
        if r.get("retCode") == 10002 and att < 5:            # время разошлось — пересинхронизироваться и повторить
            try:
                sync_time()
            except Exception:  # noqa: BLE001
                pass
            continue
        break
    else:
        raise RuntimeError(f"нет связи с api-demo.bybit.com ({type(last).__name__}) — проверь VPN и запусти снова")
    if r.get("retCode") != 0:
        raise RuntimeError(f"{path}: {r.get('retCode')} {r.get('retMsg')}")
    return r.get("result") or {}


def position() -> float:
    lst = call("GET", "/v5/position/list", {"category": CAT, "symbol": SYM}).get("list") or []
    return sum(float(p["size"]) * (1 if p["side"] == "Buy" else -1) for p in lst if float(p.get("size") or 0))


def stops() -> list[dict]:
    lst = call("GET", "/v5/order/realtime", {"category": CAT, "symbol": SYM, "orderFilter": "StopOrder"}).get("list") or []
    lst += call("GET", "/v5/order/realtime", {"category": CAT, "symbol": SYM, "orderFilter": "tpslOrder"}).get("list") or []
    seen, out = set(), []
    for o in lst:
        if o["orderId"] not in seen and "Stop" in (o.get("stopOrderType") or ""):
            seen.add(o["orderId"]); out.append(o)
    return out


def market(tag: str, side: str, qty: float, reduce: bool = False) -> None:
    # один и тот же orderLinkId при повторе: если первый запрос дошёл, Bybit откажет в дубле (ошибка «дубль» = уже исполнен)
    link = f"{tag}-{uuid.uuid4().hex[:10]}"
    try:
        call("POST", "/v5/order/create", {"category": CAT, "symbol": SYM, "side": side, "orderType": "Market",
                                          "qty": str(qty), "reduceOnly": reduce, "positionIdx": 0, "orderLinkId": link})
    except RuntimeError as e:
        if "duplicate" not in str(e).lower() and "110072" not in str(e):
            raise
    time.sleep(1.5)


def partial_sl(qty: float, price: float) -> str:
    before = {o["orderId"] for o in stops()}
    call("POST", "/v5/position/trading-stop", {"category": CAT, "symbol": SYM, "positionIdx": 0, "tpslMode": "Partial",
                                               "stopLoss": f"{price:.2f}", "slSize": str(qty), "slTriggerBy": "MarkPrice",
                                               "slOrderType": "Market"})
    time.sleep(1.5)
    new = [o for o in stops() if o["orderId"] not in before]
    return new[0]["orderId"] if new else ""


def cancel(oid: str) -> None:
    if oid:
        try:
            call("POST", "/v5/order/cancel", {"category": CAT, "symbol": SYM, "orderId": oid})
        except Exception as e:  # noqa: BLE001
            say(f"   (отмена {oid}: {e})")
        time.sleep(1)


def check(name: str, ok: bool, det: str = "") -> bool:
    say(f"{'✅' if ok else '❌'} {name}" + (f" — {det}" if det else "")); return ok


def main() -> None:
    print("Проверка на ДЕМО-счёте Bybit. Ключ демо-торговли (не реальный!). Ввод не отображается.")
    K["key"] = getpass.getpass("API Key (демо): ").strip()
    K["sec"] = getpass.getpass("API Secret (демо): ").strip()
    say(f"Демо-проверка учёта ботов · {SYM} · {time.strftime('%Y-%m-%d %H:%M')} · {BASE}")
    try:                                        # связь до начала: без неё лучше не начинать
        sync_time()
        say(f"Часы ПК отличаются от Bybit на {OFFSET['ms'] / 1000:+.1f} с — учтено")
    except Exception:  # noqa: BLE001
        say("⛔ Нет связи с api-demo.bybit.com. Включи/переключи VPN (сайт bybit.com должен открываться) и запусти снова.")
        OUT.write_text("\n".join(LINES), encoding="utf-8"); return
    res = []
    a_sl = b_sl = ""
    try:
        try:
            call("POST", "/v5/position/switch-mode", {"category": CAT, "symbol": SYM, "mode": 0})
        except RuntimeError:
            pass                                              # уже one-way
        try:
            call("POST", "/v5/position/set-leverage", {"category": CAT, "symbol": SYM, "buyLeverage": "5", "sellLeverage": "5"})
        except RuntimeError:
            pass
        if abs(position()) > 0 or stops():   # остатки от прерванного прогона — это ДЕМО, убираем сами
            p0 = position()
            say(f"Остатки прошлого прогона на демо: позиция {p0}, стопов {len(stops())} — убираю")
            for o in stops():
                cancel(o["orderId"])
            if abs(p0) > 0:
                market("cleanup", "Sell" if p0 > 0 else "Buy", abs(p0), reduce=True)
            if abs(position()) > 0:
                say("Не удалось убрать — закрой ETHUSDT на демо вручную и запусти снова."); return
        px = float(call("GET", "/v5/market/tickers", {"category": CAT, "symbol": SYM})["list"][0]["markPrice"])
        say(f"Цена ETH ≈ {px:.2f}")

        market("A", "Buy", 0.02); market("B", "Buy", 0.01)
        res.append(check("1. A купил 0.02, B купил 0.01 → одна позиция 0.03", abs(position() - 0.03) < 1e-9, f"позиция {position()}"))

        a_sl = partial_sl(0.02, px * 0.97); b_sl = partial_sl(0.01, px * 0.95)
        st = {o["orderId"]: o for o in stops()}
        qa = float(st.get(a_sl, {}).get("qty") or 0); qb = float(st.get(b_sl, {}).get("qty") or 0)
        res.append(check("2. Два отдельных частичных стопа: A на 0.02, B на 0.01",
                         abs(qa - 0.02) < 1e-9 and abs(qb - 0.01) < 1e-9, f"стопов на бирже {len(st)}: A {qa} @ {st.get(a_sl, {}).get('triggerPrice')}, B {qb} @ {st.get(b_sl, {}).get('triggerPrice')}"))

        market("A", "Sell", 0.02, reduce=True); cancel(a_sl); a_sl = ""
        st = {o["orderId"]: o for o in stops()}
        res.append(check("3. A закрыл свои 0.02 reduce-only и снял свой стоп → позиция 0.01",
                         abs(position() - 0.01) < 1e-9, f"позиция {position()}"))
        res.append(check("4. Стоп B на месте и всё ещё на 0.01 (не тронут ботом A)",
                         b_sl in st and abs(float(st[b_sl]["qty"]) - 0.01) < 1e-9, f"стопов {len(st)}"))

        market("B", "Sell", 0.01, reduce=True); cancel(b_sl); b_sl = ""
        res.append(check("5. B закрыл своё — позиция 0, висящих стопов нет", abs(position()) < 1e-9 and not stops(),
                         f"позиция {position()}, стопов {len(stops())}"))
    except Exception as e:  # noqa: BLE001
        say(f"⛔ Ошибка: {e}")
    finally:
        try:                                                  # уборка: ничего не оставить на демо
            p = position()
            if abs(p) > 0:
                market("cleanup", "Sell" if p > 0 else "Buy", abs(p), reduce=True)
            for o in stops():
                cancel(o["orderId"])
        except Exception as e:  # noqa: BLE001
            say(f"уборка: {e}")
    say(f"\nИтог: {sum(res)}/5 проверок" if res else "\nПроверка не дошла до конца — см. ошибку выше")
    OUT.write_text("\n".join(LINES), encoding="utf-8"); print(f"Отчёт: {OUT}")


if __name__ == "__main__":
    main()
