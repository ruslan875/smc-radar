"""ledger_test.py — 2026-10-25. Прогон учёта «каждый бот — свой объём» на симуляторе биржи one-way.

Симулятор ведёт себя как Bybit/OKX в режиме one-way: одна чистая позиция на монету, reduce-only не может
открыть встречную позицию и обрезается до размера позиции, условные (стоп) ордера частичные — на свой объём.
Боты отправляют ордера с меткой (как orderLinkId/clOrdId), учёт обновляется по исполнению.
Проверяется ИНВАРИАНТ: позиция на бирже = сумма объёмов ботов, стоп одного бота не трогает объём другого.
Запуск: python ledger_test.py  → печатает отчёт.
"""
from __future__ import annotations

import itertools
import tempfile
from pathlib import Path

from bot_ledger import EPS, Ledger

_ids = itertools.count(1)


class Exchange:
    """One-way: одна позиция на монету. Стопы — частичные условные reduce-only ордера."""
    def __init__(self):
        self.net = 0.0            # >0 лонг, <0 шорт
        self.stops: dict[str, dict] = {}
        self.fills: list[dict] = []

    def market(self, tag: str, side: int, qty: float, price: float, reduce: bool = False) -> float:
        if reduce:
            if self.net * side >= 0:          # reduce-only по направлению позиции — нечего сокращать
                return 0.0
            qty = min(qty, abs(self.net))     # биржа обрезает reduce-only до размера позиции
        self.net += side * qty
        if abs(self.net) < EPS:
            self.net = 0.0
        self.fills.append({"tag": tag, "side": side, "qty": qty, "price": price, "reduce": reduce})
        return qty

    def place_stop(self, tag: str, side: int, qty: float, trigger: float) -> str:
        oid = f"S{next(_ids)}"
        self.stops[oid] = {"tag": tag, "side": side, "qty": qty, "trigger": trigger}
        return oid

    def cancel(self, oid: str | None) -> None:
        if oid:
            self.stops.pop(oid, None)

    def tick(self, price: float) -> list[tuple[str, str, float]]:
        """Цена дошла — срабатывают стопы. Возвращает (oid, tag, исполненный объём)."""
        done = []
        for oid, s in list(self.stops.items()):
            hit = price <= s["trigger"] if s["side"] < 0 else price >= s["trigger"]
            if hit:
                q = self.market(s["tag"], s["side"], s["qty"], s["trigger"], reduce=True)
                self.stops.pop(oid)
                done.append((oid, s["tag"], q))
        return done


class Bot:
    def __init__(self, name: str, ex: Exchange, led: Ledger):
        self.name, self.ex, self.led = name, ex, led

    def enter(self, side: int, qty: float, price: float, sl: float) -> str:
        ok, why = self.led.can_open(self.name, side)
        if not ok:
            return f"вход отклонён: {why}"
        q = self.ex.market(self.name, side, qty, price)
        self.led.on_fill(self.name, side, q, price, reduce=False)
        self.set_stop(sl)
        return "ok"

    def set_stop(self, sl: float) -> None:
        p = self.led.pos(self.name)
        self.ex.cancel(p.sl_order)                                    # старый стоп — на старый объём
        p.sl = sl
        p.sl_order = self.ex.place_stop(self.name, -p.side, p.qty, sl) if p.qty > EPS else None

    def close_part(self, frac: float, price: float) -> None:
        p = self.led.pos(self.name)
        old_stop, sl = p.sl_order, p.sl          # ВАЖНО: запомнить ДО учёта — при полном закрытии учёт обнуляет id
        q = self.ex.market(self.name, -p.side, p.qty * frac, price, reduce=True)
        self.led.on_fill(self.name, -p.side, q, price, reduce=True)
        self.ex.cancel(old_stop)                  # старый стоп был на старый объём — снять всегда
        p.sl_order = None
        if p.qty > EPS:
            p.sl = sl
            p.sl_order = self.ex.place_stop(self.name, -p.side, p.qty, sl)   # новый — на остаток

    def on_stop(self, oid: str, q: float, price: float) -> None:
        p = self.led.pos(self.name)
        if p.sl_order == oid:
            p.sl_order = None
            self.led.on_fill(self.name, -p.side, q, price, reduce=True)


def route_stops(ex: Exchange, bots: dict[str, Bot], price: float) -> None:
    for oid, tag, q in ex.tick(price):
        bots[tag].on_stop(oid, q, price)


RESULTS: list[tuple[str, bool, str]] = []


def check(name: str, cond: bool, detail: str = "") -> None:
    RESULTS.append((name, cond, detail))


def setup():
    ex, led = Exchange(), Ledger("ETHUSDT")
    return ex, led, {"A": Bot("A", ex, led), "B": Bot("B", ex, led)}


def inv(ex: Exchange, led: Ledger) -> bool:
    return abs(ex.net - led.net()) < 1e-9


def main() -> None:
    # 1. Оба лонг по одной монете, стоп A срабатывает — B не тронут
    ex, led, b = setup()
    b["A"].enter(+1, 1.0, 3000, sl=2940); b["B"].enter(+1, 0.5, 3010, sl=2900)
    route_stops(ex, b, 2930)
    check("1. Стоп бота A закрыл только его 1.0, у B осталось 0.5 и его стоп",
          led.pos("A").qty == 0 and abs(led.pos("B").qty - 0.5) < EPS and abs(ex.net - 0.5) < EPS and led.pos("B").sl_order in ex.stops,
          f"биржа {ex.net:+}, A {led.pos('A').qty}, B {led.pos('B').qty}")
    check("   инвариант: биржа = сумма ботов", inv(ex, led))

    # 2. A берёт тейк reduce-only на свой объём — B не задет
    ex, led, b = setup()
    b["A"].enter(+1, 1.0, 3000, sl=2940); b["B"].enter(+1, 0.5, 3000, sl=2900)
    b["A"].close_part(1.0, 3100)
    check("2. Тейк A (reduce-only 1.0) — у B 0.5 и стоп на месте",
          led.pos("A").qty == 0 and abs(ex.net - 0.5) < EPS and led.pos("B").sl_order in ex.stops and not any(s["tag"] == "A" for s in ex.stops.values()),
          f"биржа {ex.net:+}, стопов на бирже {len(ex.stops)}")
    check("   прибыль A посчитана только на его объём", abs(led.pos("A").realized - 100.0) < 1e-6, f"{led.pos('A').realized}")

    # 3. Добор B (сетка) — его стоп пересоздан на новый объём
    ex, led, b = setup()
    b["A"].enter(+1, 1.0, 3000, sl=2940); b["B"].enter(+1, 0.5, 3000, sl=2900)
    b["B"].enter(+1, 0.5, 2950, sl=2880)
    sB = ex.stops[led.pos("B").sl_order]
    check("3. Добор B: стоп B на 1.0 (весь его объём), стоп A по-прежнему 1.0",
          abs(sB["qty"] - 1.0) < EPS and abs(ex.stops[led.pos("A").sl_order]["qty"] - 1.0) < EPS and len(ex.stops) == 2,
          f"стоп B {sB['qty']} @ {sB['trigger']}, средняя B {led.pos('B').avg:.1f}")

    # 4. Оба стопа на одной свече
    ex, led, b = setup()
    b["A"].enter(+1, 1.0, 3000, sl=2940); b["B"].enter(+1, 0.5, 3000, sl=2950)
    route_stops(ex, b, 2900)
    check("4. Оба стопа на одной свече — позиция 0, оба учёта 0, стопов не осталось",
          ex.net == 0 and led.net() == 0 and not ex.stops, f"биржа {ex.net}, стопов {len(ex.stops)}")

    # 5. Встречная сторона запрещена
    ex, led, b = setup()
    b["A"].enter(+1, 1.0, 3000, sl=2940)
    r = b["B"].enter(-1, 0.5, 3000, sl=3060)
    check("5. Шорт B при открытом лонге A — отклонён (на one-way закрыл бы лонг A)",
          r.startswith("вход отклонён") and abs(ex.net - 1.0) < EPS, r)

    # 6. Человек закрыл всю позицию вручную на бирже — расхождение замечено, входы остановлены
    ex, led, b = setup()
    b["A"].enter(+1, 1.0, 3000, sl=2940); b["B"].enter(+1, 0.5, 3000, sl=2900)
    ex.market("manual", -1, 1.5, 3020, reduce=True)
    ok = led.reconcile(ex.net)
    check("6. Ручное закрытие на бирже — сверка нашла расхождение и остановила входы",
          not ok and led.blocked and b["A"].enter(+1, 0.1, 3020, 2990).startswith("вход отклонён"), led.alerts[-1] if led.alerts else "")
    # оставшиеся стопы reduce-only — не могут открыть встречную позицию
    route_stops(ex, b, 2800)
    check("   висящие стопы reduce-only не открыли встречную позицию", ex.net == 0, f"биржа {ex.net}")

    # 7. Перезапуск: учёт читается из файла и совпадает
    ex, led, b = setup()
    b["A"].enter(+1, 1.0, 3000, sl=2940); b["B"].enter(+1, 0.5, 3000, sl=2900)
    with tempfile.TemporaryDirectory() as d:
        f = Path(d) / "ledger_ETHUSDT.json"; led.save(f); led2 = Ledger.load(f, "ETHUSDT")
    check("7. Перезапуск: учёт из файла, сверка со счётом проходит",
          led2.reconcile(ex.net) and led2.pos("A").sl_order == led.pos("A").sl_order)

    # 8. Частичный тейк A 50% — стоп A пересоздан на остаток
    ex, led, b = setup()
    b["A"].enter(+1, 1.0, 3000, sl=2940); b["B"].enter(+1, 0.5, 3000, sl=2900)
    b["A"].close_part(0.5, 3060)
    check("8. Частичный тейк A 50%: стоп A на 0.5, у B без изменений",
          abs(ex.stops[led.pos("A").sl_order]["qty"] - 0.5) < EPS and abs(led.pos("B").qty - 0.5) < EPS and abs(ex.net - 1.0) < EPS)

    # 9. Случайный стресс-прогон: 2000 шагов, проверка инварианта на каждом
    import random
    rnd = random.Random(7); ex, led, b = setup(); px = 3000.0; bad = 0
    for _ in range(2000):
        px *= 1 + rnd.uniform(-0.006, 0.006)
        route_stops(ex, b, px)
        name = rnd.choice("AB"); bot = b[name]; p = led.pos(name); act = rnd.random()
        if p.qty < EPS and act < 0.3:
            bot.enter(+1, round(rnd.uniform(0.1, 1.0), 3), px, sl=px * 0.98)
        elif p.qty > EPS and act < 0.15:
            bot.enter(+1, round(rnd.uniform(0.1, 0.5), 3), px, sl=px * 0.975)
        elif p.qty > EPS and act < 0.25:
            bot.close_part(rnd.choice([0.5, 1.0]), px)
        if not inv(ex, led):
            bad += 1
        st = sum(s["qty"] for s in ex.stops.values())
        if st - abs(ex.net) > 1e-9:
            bad += 1
    check("9. Стресс: 2000 случайных шагов — инвариант ни разу не нарушен, стопов не больше позиции", bad == 0, f"нарушений: {bad}")

    print("Учёт «каждый бот — свой объём» на общем счёте (one-way) · симулятор\n")
    for name, ok, det in RESULTS:
        print(f"{'✅' if ok else '❌'} {name}" + (f"  — {det}" if det else ""))
    n_ok = sum(1 for _, ok, _ in RESULTS if ok)
    print(f"\nИтог: {n_ok}/{len(RESULTS)} проверок пройдено")


if __name__ == "__main__":
    main()
