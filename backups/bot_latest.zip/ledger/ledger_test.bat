@echo off
cd /d D:\VANTORIX\bot\ledger
..\venv\Scripts\python.exe ledger_test.py
pause
