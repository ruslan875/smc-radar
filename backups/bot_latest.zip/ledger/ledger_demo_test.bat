@echo off
cd /d D:\VANTORIX\bot\ledger
..\venv\Scripts\python.exe ledger_demo_test.py
pause
