#!/usr/bin/env python3
"""
High-Low Cloud Trend Strategy - Standalone Backtest Runner
===========================================================

Hand-ported from strategies/High_Low_cloud_trend.pine
(RezzoRedPriest, "Strategy [High-Low Cloud Trend] (v6, perf-safe)").

WHY THIS IS HAND-PORTED, NOT RUN THROUGH pine\\run_pine.py:
The project's transpiler does not implement `var`-persisted state between
bars, and this strategy is built entirely on one such variable: `pivot`
holds the opposite extreme captured at the moment price tagged a channel
edge, and every later bar's trend direction is decided against it. Feed
that through a stateless transpile and the trend flag becomes noise.
The trade counter (`tradesToday`) is `var` as well.

USAGE (same conventions as third_eye_backtest.py / gaussian_channel_backtest.py):

    pip install pandas numpy ccxt

    python high_low_cloud_backtest.py --symbol BTC/USDT --exchange bybit \\
        --timeframe 1h --start 2024-01-01 --end 2025-12-31 \\
        --commission 0.055 --slippage-pct 0.03 --out backtest_out_hlcloud

    python high_low_cloud_backtest.py --symbols BTC/USDT ETH/USDT SOL/USDT \\
        --exchange bybit --timeframe 1h --out backtest_out_hlcloud

    # The Pine source has NO stop and NO take-profit - it is a pure reversal
    # system. Test it with one bolted on:
    python high_low_cloud_backtest.py --csv data.csv --tp 3.0 --sl 1.5

Output: <out>/<SYMBOL>_deals.csv with the shared schema
        (entry_time, exit_time, side, entry_price, exit_price,
         gross_pnl_pct, reason)
        so analyze_external_strategies.py reads this folder unchanged.

READ THIS BEFORE TRUSTING ANY NUMBER
------------------------------------
1. The Pine source sets NEITHER commission NOR slippage, so its Strategy
   Tester figures are gross. Here commission defaults to 0.055 (Bybit
   taker, round-trip applied) and slippage is a real argument. Expect the
   honest result to sit well below whatever TradingView showed.

2. The Pine source has `process_orders_on_close = true`: the fill happens
   at the close of the very bar that produced the signal. That is
   reproduced here faithfully, but it is NOT reachable live - in practice
   the fill lands at the next bar's open. Treat every result as an
   optimistic bound, and re-check the edge with --entry-next-open.

3. There is no stop loss anywhere in the original. A position is held
   until the opposite signal appears, however far price travels against
   it. On a leveraged perp that means the drawdown column is not a
   discomfort, it is a liquidation distance. --sl is provided precisely
   so this can be measured rather than assumed.

PARITY NOTES (faithful vs. deliberate deviation)
------------------------------------------------
  - `pivot` is reproduced exactly, including Pine's `nz(pivot[1])`, which
    substitutes 0 (not na) before the first assignment. That zero makes
    `close > pivot` true, so the strategy starts life believing the trend
    is up. Kept, because changing it would change signal timing.
  - Channel maths is literal: highest/lowest over `len` (35) and over
    `math.round(len / 4)` (9 at the default). Pine rounds 8.75 to 9.
  - All three signal families are implemented (cloud retest, mean
    reversion, cloud cross) with the source's default toggles: retest on,
    the other two off.
  - `tradesToday` and its reset on day change are reproduced, including
    the quirk that the counter increments even when the entry itself is
    swallowed by `pyramiding = 1` (already in that direction).
  - DEVIATION: `inRange` is dropped. In the source it reads
    `bar_index >= ta.max(bar_index) - visBars`, and `ta.max(bar_index)`
    is simply the current bar_index, so the expression is always true -
    the author's intent (only compute on the last 500 bars) never takes
    effect. Dropping a constant-true term changes nothing.
  - DEVIATION: rolling windows use min_periods = length, so the first
    `len` bars emit no signal at all. Pine fills those from partial
    history. Warm-up bars should not be traded either way; this only
    makes the boundary explicit.
  - Intrabar ambiguity: when an optional --tp and --sl are both touched
    inside one bar, the STOP is taken. Conservative, and stated here
    because the choice is not neutral.
"""

import argparse
import sys
from pathlib import Path

import numpy as np
import pandas as pd


# ============================================================================
# CONFIG - mirrors the Pine inputs, same defaults
# ============================================================================

CONFIG = {
    "len": 35,                       # "Look-back period"
    "take_cloud_retest": True,       # "Take cloud-retest signals"
    "take_mean_rev_signals": False,  # "Take mean-reversion signals"
    "take_cross_signals": False,     # "Take cloud-cross signals"
    "only_trend": True,              # "Trade only with trend"
    "max_trades_per_day": 5,         # "Max trades per day"
}


# ============================================================================
# Pine series helpers
# ============================================================================

def crossover(a: pd.Series, b: pd.Series) -> pd.Series:
    """ta.crossover: was at or below on the previous bar, is above now."""
    return (a.shift(1) <= b.shift(1)) & (a > b)


def crossunder(a: pd.Series, b: pd.Series) -> pd.Series:
    """ta.crossunder: was at or above on the previous bar, is below now."""
    return (a.shift(1) >= b.shift(1)) & (a < b)


def cross(a: pd.Series, b: pd.Series) -> pd.Series:
    """ta.cross: either direction."""
    return crossover(a, b) | crossunder(a, b)


# ============================================================================
# SIGNALS
# ============================================================================

def compute_signals(df: pd.DataFrame, cfg: dict = CONFIG) -> pd.DataFrame:
    out = df.copy()
    ln = int(cfg["len"])
    ln1 = int(round(ln / 4))  # Pine math.round(35 / 4) -> 9

    out["highest"] = out["high"].rolling(ln, min_periods=ln).max()
    out["lowest"] = out["low"].rolling(ln, min_periods=ln).min()
    out["highest1"] = out["high"].rolling(ln1, min_periods=ln1).max()
    out["lowest1"] = out["low"].rolling(ln1, min_periods=ln1).min()

    # ---- pivot: the one piece of genuine bar-to-bar state -----------------
    # pivot := low  == lowest  ? highest
    #        : high == highest ? lowest
    #        : nz(pivot[1])
    # nz() turns the initial na into 0, so the first bars read as "uptrend".
    low_v = out["low"].to_numpy(dtype=float)
    high_v = out["high"].to_numpy(dtype=float)
    hi_v = out["highest"].to_numpy(dtype=float)
    lo_v = out["lowest"].to_numpy(dtype=float)

    pivot = np.zeros(len(out), dtype=float)
    carried = 0.0
    for i in range(len(out)):
        if not (np.isnan(hi_v[i]) or np.isnan(lo_v[i])):
            if low_v[i] == lo_v[i]:
                carried = hi_v[i]
            elif high_v[i] == hi_v[i]:
                carried = lo_v[i]
        pivot[i] = carried
    out["pivot"] = pivot

    bull = out["close"] > out["pivot"]
    out["band"] = np.where(bull, out["lowest"], out["highest"])
    out["band1"] = np.where(bull, out["lowest1"], out["highest1"])
    out["trend_dir"] = np.where(bull, 1, -1)

    band = out["band"]
    band1 = out["band1"]
    band1_prev = band1.shift(1)

    # ---- cloud retest (the only family enabled by default) ----------------
    bull_retest = (
        (out["trend_dir"] > 0)
        & (out["close"] > band)
        & (out["low"] <= band1)
        & (out["low"].shift(1) > band1_prev)
        & (out["close"] > out["open"])
    )
    bear_retest = (
        (out["trend_dir"] < 0)
        & (out["close"] < band)
        & (out["high"] >= band1)
        & (out["high"].shift(1) < band1_prev)
        & (out["close"] < out["open"])
    )

    # ---- mean reversion (off by default) ----------------------------------
    band_flat = band.shift(1) == band
    no_band_cross = ~cross(out["close"], band)

    mean_rev_dn = (
        crossunder(out["high"], band1_prev)
        & (band1_prev == out["high"].shift(1))
        & (out["high"] != band1)
        & no_band_cross
        & band_flat
    )
    mean_rev_up = (
        crossover(out["low"], band1_prev)
        & (band1_prev == out["low"].shift(1))
        & (out["low"] != band1)
        & no_band_cross
        & band_flat
    )

    # ---- cloud cross (off by default) -------------------------------------
    cloud_x_up = crossover(out["close"], band) & (band == out["highest"])
    cloud_x_dn = crossunder(out["close"], band) & (band == out["lowest"])

    long_sig = pd.Series(False, index=out.index)
    short_sig = pd.Series(False, index=out.index)
    if cfg["take_cloud_retest"]:
        long_sig |= bull_retest.fillna(False)
        short_sig |= bear_retest.fillna(False)
    if cfg["take_mean_rev_signals"]:
        long_sig |= mean_rev_up.fillna(False)
        short_sig |= mean_rev_dn.fillna(False)
    if cfg["take_cross_signals"]:
        long_sig |= cloud_x_up.fillna(False)
        short_sig |= cloud_x_dn.fillna(False)

    if cfg["only_trend"]:
        long_sig &= out["trend_dir"] > 0
        short_sig &= out["trend_dir"] < 0

    out["long_signal"] = long_sig.fillna(False)
    out["short_signal"] = short_sig.fillna(False)
    return out


# ============================================================================
# BACKTEST ENGINE
# Pine semantics: reversal system, one position at a time, no built-in
# stop or target. `tradesToday` gates entries and resets each day.
# ============================================================================

def run_backtest(df: pd.DataFrame, cfg: dict = CONFIG,
                 tp_pct: float = 0.0, sl_pct: float = 0.0,
                 commission_pct: float = 0.055, slippage_pct: float = 0.0,
                 entry_next_open: bool = False) -> pd.DataFrame:
    commission = commission_pct / 100
    position = None
    deals = []

    trades_today = 0
    current_day = None
    pending = None  # (side, signal_timestamp) when filling at next open

    def open_position(side: str, price: float, ts) -> dict:
        slip = slippage_pct / 100
        entry_price = price * (1 + slip) if side == "long" else price * (1 - slip)
        return {
            "side": side,
            "entry_time": ts,
            "entry_price": entry_price,
            "stop": (entry_price * (1 - sl_pct / 100) if side == "long"
                     else entry_price * (1 + sl_pct / 100)) if sl_pct > 0 else None,
            "target": (entry_price * (1 + tp_pct / 100) if side == "long"
                       else entry_price * (1 - tp_pct / 100)) if tp_pct > 0 else None,
        }

    def close_position(pos: dict, exit_price: float, ts, reason: str):
        entry = pos["entry_price"]
        if pos["side"] == "long":
            pnl = (exit_price / entry - 1) * 100 - commission * 200
        else:
            pnl = (entry / exit_price - 1) * 100 - commission * 200
        deals.append({**pos, "exit_time": ts, "exit_price": exit_price,
                      "gross_pnl_pct": pnl, "reason": reason})

    for ts, row in df.iterrows():
        day = ts.date() if hasattr(ts, "date") else ts
        if day != current_day:
            current_day = day
            trades_today = 0  # Pine: reset on dayofweek change

        o, h, l, c = row["open"], row["high"], row["low"], row["close"]

        # --- a signal from the previous bar fills at this bar's open -------
        if pending is not None:
            side = pending
            pending = None
            if position is not None and position["side"] != side:
                close_position(position, o, ts, "opposite_signal")
                position = None
            if position is None:
                position = open_position(side, o, ts)

        long_sig, short_sig = bool(row["long_signal"]), bool(row["short_signal"])

        # --- optional protective exits, checked before new signals ---------
        if position is not None and (sl_pct > 0 or tp_pct > 0):
            side = position["side"]
            exit_now, reason, exit_price = False, None, None
            # Stop wins a bar that touches both - see PARITY NOTES.
            if sl_pct > 0:
                if side == "long" and l <= position["stop"]:
                    exit_now, reason, exit_price = True, "stop_loss", position["stop"]
                elif side == "short" and h >= position["stop"]:
                    exit_now, reason, exit_price = True, "stop_loss", position["stop"]
            if not exit_now and tp_pct > 0:
                if side == "long" and h >= position["target"]:
                    exit_now, reason, exit_price = True, "take_profit", position["target"]
                elif side == "short" and l <= position["target"]:
                    exit_now, reason, exit_price = True, "take_profit", position["target"]
            if exit_now:
                close_position(position, exit_price, ts, reason)
                position = None

        # --- trading logic -------------------------------------------------
        if not (long_sig or short_sig):
            continue
        if trades_today >= cfg["max_trades_per_day"]:
            continue

        side = "long" if long_sig else "short"

        # Pine increments the counter on every accepted signal, even when
        # pyramiding = 1 swallows the entry because we are already in that
        # direction. Reproduced deliberately.
        trades_today += 1

        if position is not None and position["side"] == side:
            continue  # pyramiding = 1: the extra entry is ignored

        if entry_next_open:
            pending = side
            continue

        # process_orders_on_close = true: fill at this bar's close
        if position is not None:
            close_position(position, c, ts, "opposite_signal")
            position = None
        position = open_position(side, c, ts)

    deals_df = pd.DataFrame(deals)
    if not deals_df.empty:
        deals_df = deals_df[["entry_time", "exit_time", "side", "entry_price",
                             "exit_price", "gross_pnl_pct", "reason"]]
    return deals_df


# ============================================================================
# DATA LOADING (identical pattern to third_eye_backtest.py)
# ============================================================================

def load_from_csv(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    df.columns = [c.lower() for c in df.columns]
    ts_col = "timestamp" if "timestamp" in df.columns else df.columns[0]
    df[ts_col] = pd.to_datetime(df[ts_col], errors="coerce")
    df = df.set_index(ts_col).sort_index()
    return df[["open", "high", "low", "close", "volume"]]


def load_from_ccxt(symbol: str, timeframe: str, start: str, end: str,
                   exchange_id: str = "bybit", market: str = "swap") -> pd.DataFrame:
    """Delegates to the shared loader in market_data.py.

    2026-09-20: this function used to be a private copy inside every backtest
    script, and every copy carried the same three defects. It fetched SPOT
    candles while the bots trade USDT PERPETUALS (ccxt's bybit defaults to
    spot, and the wrong market never showed up in any output). It fired
    requests with no rate limit and no retry, so a long pull - a year of 15m
    candles is ~117 sequential pages - died partway with RequestTimeout. And
    it stopped paging on the first short page, which can end a run quietly on
    partial history. All three are fixed once, in market_data.load_ohlcv,
    which also caches to disk so repeat runs cost nothing.
    """
    from market_data import load_ohlcv
    return load_ohlcv(symbol, timeframe, start, end,
                      exchange_id=exchange_id, market=market)


def print_summary(symbol: str, deals: pd.DataFrame):
    if deals.empty:
        print(f"  {symbol:12s}: 0 trades")
        return
    n = len(deals)
    wins = deals[deals["gross_pnl_pct"] > 0]
    losses = deals[deals["gross_pnl_pct"] <= 0]
    win_rate = len(wins) / n * 100
    avg_pnl = deals["gross_pnl_pct"].mean()
    gp, gl = wins["gross_pnl_pct"].sum(), abs(losses["gross_pnl_pct"].sum())
    pf = (gp / gl) if gl > 0 else float("inf")
    stop_rate = (deals["reason"] == "stop_loss").sum() / n * 100
    print(f"  {symbol:12s}: {n:4d} trades | avg P&L {avg_pnl:+6.2f}% | "
          f"win rate {win_rate:5.1f}% | stop rate {stop_rate:5.1f}% | PF {pf:6.2f}")


def _effective_commission(args):
    """The commission the run ACTUALLY used.

    In third_eye_backtest.py `--commission` is an optional override defaulting
    to None, with the real value living in CONFIG. Recording the raw argument
    wrote "null" into the manifest for runs that did charge 0.05% - the exact
    kind of quiet inaccuracy this manifest exists to prevent.
    """
    value = getattr(args, "commission", None)
    if value is None:
        cfg = globals().get("CONFIG")
        if isinstance(cfg, dict):
            value = cfg.get("commission_pct")
    return value


def _manifest_symbols(args) -> list:
    """Symbols for the run manifest, taken from the arguments rather than from
    the loaded data: in some of these scripts the output folder is created
    before the data is fetched, and reading `sources` there raised
    UnboundLocalError. Arguments are always available."""
    syms = list(getattr(args, "symbols", None) or [])
    if not syms and getattr(args, "symbol", None):
        syms = [args.symbol]
    if not syms and getattr(args, "csv", None):
        syms = [Path(args.csv).stem]
    return syms


def main():
    p = argparse.ArgumentParser(description="High-Low Cloud Trend backtest")
    p.add_argument("--symbol")
    p.add_argument("--symbols", nargs="+")
    p.add_argument("--csv")
    p.add_argument("--exchange", default="bybit")
    p.add_argument("--market", default="swap", choices=["swap", "spot"],
                   help="swap = USDT perpetual (what the bots trade); "
                        "spot = spot market. Everything before 2026-09-20 silently used spot.")
    p.add_argument("--timeframe", default="1h")
    p.add_argument("--start", default="2024-01-01")
    p.add_argument("--end", default="2025-12-31")
    p.add_argument("--out", default="backtest_out_hlcloud")
    p.add_argument("--tp", type=float, default=0.0,
                   help="Optional TP %% (Pine has none built in; 0=disabled)")
    p.add_argument("--sl", type=float, default=0.0,
                   help="Optional SL %% (Pine has none built in; 0=disabled)")
    p.add_argument("--commission", type=float, default=0.055,
                   help="Per-side commission %%, applied round-trip (Bybit taker)")
    p.add_argument("--slippage-pct", type=float, default=0.0)
    p.add_argument("--entry-next-open", action="store_true",
                   help="Fill at the next bar's open instead of the signal bar's "
                        "close. Slower but reachable in live trading.")
    p.add_argument("--len", type=int, default=CONFIG["len"])
    p.add_argument("--max-trades-per-day", type=int, default=CONFIG["max_trades_per_day"])
    p.add_argument("--mean-rev", action="store_true", help="Also take mean-reversion signals")
    p.add_argument("--cloud-cross", action="store_true", help="Also take cloud-cross signals")
    args = p.parse_args()

    cfg = dict(CONFIG)
    cfg["len"] = args.len
    cfg["max_trades_per_day"] = args.max_trades_per_day
    cfg["take_mean_rev_signals"] = args.mean_rev
    cfg["take_cross_signals"] = args.cloud_cross

    sources = {}
    if args.csv:
        sources[Path(args.csv).stem] = load_from_csv(args.csv)
    else:
        syms = args.symbols or ([args.symbol] if args.symbol else [])
        if not syms:
            p.error("give --symbol, --symbols or --csv")
        for sym in syms:
            print(f"Fetching {sym} {args.timeframe} from {args.exchange} "
                  f"({args.start} -> {args.end})...")
            sources[sym] = load_from_ccxt(sym, args.timeframe, args.start,
                                          args.end, args.exchange, args.market)

    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)

    # 2026-09-20: write down the conditions this run happened under.
    # Two runs with different timeframes once landed in the same folder and
    # the second silently overwrote the first - the comparison table then
    # showed numbers from settings nobody could reconstruct. The analyzer
    # reads this file and prints the conditions next to the metrics, so a
    # mismatched folder announces itself instead of quietly lying.
    import json as _json, datetime as _dt
    _manifest = {
        "strategy": Path(__file__).stem,
        "run_at": _dt.datetime.now().astimezone().isoformat(timespec="seconds"),
        "symbols": _manifest_symbols(args),
        "timeframe": getattr(args, "timeframe", None),
        "start": getattr(args, "start", None),
        "end": getattr(args, "end", None),
        "exchange": getattr(args, "exchange", None),
        "market": getattr(args, "market", None),
        "commission_pct": _effective_commission(args),
        "slippage_pct": getattr(args, "slippage_pct", None),
        "source": "csv" if getattr(args, "csv", None) else "exchange",
    }
    for _extra in ("tp", "sl", "entry_next_open", "len", "poles", "period", "mult"):
        if hasattr(args, _extra):
            _manifest[_extra] = getattr(args, _extra)
    (out_dir / "_run.json").write_text(_json.dumps(_manifest, indent=2), encoding="utf-8")

    print()
    print("=" * 100)
    print("HIGH-LOW CLOUD TREND - BACKTEST RESULTS")
    if args.sl == 0 and args.tp == 0:
        print("  (no stop, no target - reversal only, exactly as the Pine source)")
    print("=" * 100)

    for sym, raw in sources.items():
        if raw is None or len(raw) < cfg["len"] * 3:
            print(f"  {sym:12s}: insufficient data")
            continue
        sig = compute_signals(raw, cfg)
        deals = run_backtest(sig, cfg, tp_pct=args.tp, sl_pct=args.sl,
                             commission_pct=args.commission,
                             slippage_pct=args.slippage_pct,
                             entry_next_open=args.entry_next_open)
        print_summary(sym, deals)
        safe = sym.replace("/", "").replace(":", "")
        deals.to_csv(out_dir / f"{safe}_deals.csv", index=False)

    print("=" * 100)
    print(f"\nDeal logs written to: {out_dir}/  "
          f"(compatible with analyze_external_strategies.py)")


if __name__ == "__main__":
    main()
