"""recheck_improve.py — 2026-10-29. Можно ли улучшить пробой канала (2h, 4h) и Donchian 4h фильтрами «режима рынка»,
не подгоняя под последний месяц. Каждый вариант считается на ВСЕЙ истории и отдельно за 180 / 90 / 30 дней.
Принимаем фильтр, только если он лучше базы и на всей истории (≥ 90% базы), и за 180, и за 90 дней.
Фильтры: ADX14 > 20 / > 25 · расширение волатильности ATR14 > ATR100 · тренд BTC (лонг только если BTC выше EMA200, шорт — ниже)
· безубыток после +1R · сочетания. Пишет bt_lab_bots/recheck_improve.txt
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
import recheck_recent as RR  # noqa: E402

FEE = 0.0011


def adx(d, n=14):
    h, l, c = d.h, d.l, d.c
    up = h.diff(); dn = -l.diff()
    p = pd.Series(np.where((up > dn) & (up > 0), up, 0.0)); m = pd.Series(np.where((dn > up) & (dn > 0), dn, 0.0))
    tr = pd.concat([h - l, (h - c.shift()).abs(), (l - c.shift()).abs()], axis=1).max(axis=1)
    a = tr.ewm(alpha=1 / n, adjust=False).mean()
    pdi = 100 * p.ewm(alpha=1 / n, adjust=False).mean() / a; mdi = 100 * m.ewm(alpha=1 / n, adjust=False).mean() / a
    dx = 100 * (pdi - mdi).abs() / (pdi + mdi).replace(0, 1e-12)
    return dx.ewm(alpha=1 / n, adjust=False).mean().values, tr


def sim(d, sigs, rr, hold, be=False):
    h, l, c, t = d.h.values, d.l.values, d.c.values, d.t.values
    out = []; nxt = 0
    for i, sd_, stp in sigs:
        if i < nxt or i >= len(c) - 1:
            continue
        e = c[i]; risk = abs(e - stp)
        if risk <= 0:
            continue
        tp = e + sd_ * rr * risk; s = stp; res = None; moved = False
        for j in range(i + 1, min(len(c), i + hold + 1)):
            if (l[j] <= s) if sd_ > 0 else (h[j] >= s):
                res = (j, 0.0 if moved else -1.0); break
            if (h[j] >= tp) if sd_ > 0 else (l[j] <= tp):
                res = (j, rr); break
            if be and not moved and ((h[j] >= e + risk) if sd_ > 0 else (l[j] <= e - risk)):
                s = e; moved = True
        if res is None:
            j = min(len(c) - 1, i + hold); res = (j, sd_ * (c[j] - e) / risk)
        out.append((int(t[res[0]]), res[1] - FEE * e / risk)); nxt = res[0] + 1
    return out


def chan_sigs(d):
    c = d.c.values; mid, sd = RR.rolling_reg(c); up, lo = mid + 2 * sd, mid - 2 * sd; s = []
    for i in range(101, len(c)):
        if c[i] > up[i] and c[i - 1] <= up[i - 1]:
            s.append((i, 1, mid[i]))
        elif c[i] < lo[i] and c[i - 1] >= lo[i - 1]:
            s.append((i, -1, mid[i]))
    return s


def donch_sigs(d):
    h, l, c = d.h.values, d.l.values, d.c.values
    e = pd.Series(c).ewm(span=200, adjust=False).mean().values
    hh = pd.Series(h).rolling(20).max().shift(1).values; ll = pd.Series(l).rolling(20).min().shift(1).values; s = []
    for i in range(201, len(c)):
        if c[i] > hh[i] and c[i] > e[i]:
            s.append((i, 1, (hh[i] + ll[i]) / 2))
        elif c[i] < ll[i] and c[i] < e[i]:
            s.append((i, -1, (hh[i] + ll[i]) / 2))
    return s


def filt(sigs, d, kind, btc_trend):
    if kind == "нет":
        return sigs
    ad, tr = adx(d)
    atr14 = tr.ewm(alpha=1 / 14, adjust=False).mean().values; atr100 = tr.rolling(100).mean().values
    bt = btc_trend(d.t.values)
    out = []
    for i, sd_, stp in sigs:
        ok = True
        if "adx20" in kind:
            ok &= ad[i] > 20
        if "adx25" in kind:
            ok &= ad[i] > 25
        if "vol" in kind:
            ok &= atr14[i] > atr100[i]
        if "btc" in kind:
            ok &= (bt[i] > 0) if sd_ > 0 else (bt[i] < 0)
        if ok:
            out.append((i, sd_, stp))
    return out


VARS = [("база", "нет", False), ("ADX > 20", "adx20", False), ("ADX > 25", "adx25", False), ("волатильность растёт", "vol", False),
        ("тренд BTC", "btc", False), ("безубыток +1R", "нет", True), ("ADX>20 + БУ", "adx20", True),
        ("тренд BTC + БУ", "btc", True), ("ADX>20 + тренд BTC", "adx20 btc", False), ("волат. + тренд BTC", "vol btc", False)]
STR = [("Пробой канала", "2h", chan_sigs, 2.0, 100), ("Пробой канала", "4h", chan_sigs, 2.0, 100), ("Donchian 20", "4h", donch_sigs, 3.0, 300)]


def main():
    import kvoo_longtest as K  # noqa: PLC0415
    now = int(time.time() * 1000); lines = []
    btc = {}
    for tf in ("2h", "4h"):
        b = RR.load("BTCUSDT", tf); e = b.c.ewm(span=200, adjust=False).mean()
        btc[tf] = pd.Series(np.sign(b.c.values - e.values), index=b.t.values)

    for name, tf, sfn, rr, hold in STR:
        data = {s: RR.load(s, tf) for s in K.COINS}
        bser = btc[tf]
        btf = lambda ts, bser=bser: bser.reindex(ts, method="ffill").fillna(0).values  # noqa: E731
        lines.append(f"\n=== {name} {tf} ===  (R, 12 монет; ✅ = лучше базы везде)")
        base = None
        for vname, kind, be in VARS:
            allt = []
            for s, d in data.items():
                if d is None or len(d) < 400:
                    continue
                allt += sim(d, filt(sfn(d), d, kind, btf), rr, hold, be)
            w = {lab: sum(r for t, r in allt if t >= now - days * 86400_000) for lab, days in (("all", 99999), ("180", 180), ("90", 90), ("30", 30))}
            n = len(allt)
            if base is None:
                base = w; mark = "  "
            else:
                good = w["all"] >= 0.9 * base["all"] and w["180"] > base["180"] and w["90"] > base["90"]
                mark = "✅" if good else "  "
            line = (f"{mark} {vname:<22} сд {n:>5} · всё {w['all']:+7.1f} · 180д {w['180']:+6.1f} · 90д {w['90']:+6.1f} · 30д {w['30']:+6.1f}")
            print(line, flush=True); lines.append(line)
    (BASE / "bt_lab_bots" / "recheck_improve.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("готово")


if __name__ == "__main__":
    main()
