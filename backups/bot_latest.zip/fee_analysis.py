#!/usr/bin/env python3
"""
Post-hoc fee/slippage adjustment for backtest.py's per-trade CSVs.

backtest.py measures raw R (stop distance = 1R) with no trading costs. This
script reads backtest_out/*_trades.csv and recomputes what average R looks
like after subtracting realistic round-trip Bybit futures fees.

A fee that's a fixed percent of position size costs MORE R on a trade with
a tight percentage stop than on one with a wide stop, so a flat "-0.1R"
adjustment across all trades would be wrong. Each trade gets its own
fee-in-R conversion instead:

    fee_in_R = round_trip_fee_rate / (abs(entry - stop_loss) / entry)

Run after backtest.py has produced CSVs in backtest_out/:
    python fee_analysis.py
    python fee_analysis.py --dir backtest_out --fee-bps 11
    python fee_analysis.py --fee-bps 4
"""
from __future__ import annotations

import argparse
import csv
from pathlib import Path

FEE_SCENARIOS = {
    "taker+taker (market in, market out), about 0.11 percent round trip": 0.0011,
    "taker+maker (market in, limit TP or SL), about 0.075 percent round trip": 0.00075,
    "maker+maker (both limit orders), about 0.04 percent round trip": 0.0004,
}


def load_trades(directory: Path) -> list:
    trades = []
    for path in sorted(directory.glob("*_trades.csv")):
        with path.open(newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                if row.get("r") in (None, "", "None"):
                    continue
                try:
                    row["r"] = float(row["r"])
                    row["entry"] = float(row["entry"])
                    row["stop_loss"] = float(row["stop_loss"])
                except (TypeError, ValueError):
                    continue
                trades.append(row)
    return trades


def analyze(trades: list, fee_rate: float) -> dict:
    net_rs = []
    for t in trades:
        risk_pct = abs(t["entry"] - t["stop_loss"]) / t["entry"]
        if risk_pct <= 0:
            continue
        fee_in_r = fee_rate / risk_pct
        net_rs.append(t["r"] - fee_in_r)
    if not net_rs:
        return {"n": 0, "avg_net_r": float("nan"), "win_rate": float("nan")}
    wins = sum(1 for r in net_rs if r > 0)
    return {
        "n": len(net_rs),
        "avg_net_r": sum(net_rs) / len(net_rs),
        "win_rate": wins / len(net_rs) * 100,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Fee-adjust backtest.py trade CSVs")
    parser.add_argument("--dir", default="backtest_out")
    parser.add_argument("--fee-bps", type=float, default=None,
                         help="Round-trip fee in basis points (1 bps = 0.01 percent). "
                              "If omitted, prints three standard scenarios instead.")
    args = parser.parse_args()

    directory = Path(args.dir)
    trades = load_trades(directory)
    if not trades:
        print(f"No resolved trades found in {directory.resolve()} -- run backtest.py first.")
        return

    times = [t.get("time", "") for t in trades if t.get("time")]
    print(f"Loaded {len(trades)} resolved trades from {directory.resolve()}")
    if times:
        print(f"Date range: {min(times)} .. {max(times)}")
    print()

    gross_avg = sum(t["r"] for t in trades) / len(trades)
    gross_wins = sum(1 for t in trades if t["r"] > 0)
    print(f"Gross (no fees): avg R = {gross_avg:+.3f}, win rate = {gross_wins / len(trades) * 100:.1f}%, n = {len(trades)}")
    print()

    if args.fee_bps is not None:
        scenarios = {f"{args.fee_bps:g} bps round trip": args.fee_bps / 10000}
    else:
        scenarios = FEE_SCENARIOS

    for label, fee_rate in scenarios.items():
        result = analyze(trades, fee_rate)
        print(f"{label}:")
        print(f"  avg net R = {result['avg_net_r']:+.3f}   win rate (net R>0) = {result['win_rate']:.1f}%   n = {result['n']}")
        print()

    default_fee = args.fee_bps / 10000 if args.fee_bps is not None else 0.0011
    print(f"Per-symbol breakdown (fee = {default_fee * 100:.3f} percent round trip):")
    by_symbol: dict = {}
    for t in trades:
        by_symbol.setdefault(t["symbol"], []).append(t)
    for symbol, sym_trades in sorted(by_symbol.items()):
        result = analyze(sym_trades, default_fee)
        print(f"  {symbol:10s} n={result['n']:4d}  avg net R = {result['avg_net_r']:+.3f}")


if __name__ == "__main__":
    main()
