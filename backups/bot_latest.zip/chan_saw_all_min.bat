@echo off
cd /d D:\VANTORIX\bot
venv\Scripts\python.exe chan_saw_all_min.py 120
pause
