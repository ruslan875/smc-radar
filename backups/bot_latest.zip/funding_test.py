"""funding_test.py — 2026-10-27. Честная проверка «бота на фандинге» (кэрри / арбитраж фандинга), как у Veles/3Commas/Bitsgap.
Идея: когда фандинг сильно положительный, держим ЛОНГ спот + ШОРТ перп на ту же сумму (цена не важна — позиции гасят друг друга)
и каждые 8 ч (у части монет 4/1 ч) получаем фандинг от лонгистов. Риск — фандинг разворачивается, комиссии, разница цен спот/перп.

Данные: история фандинга Bybit /v5/market/funding/history за ~365 дней, монеты с парой на споте и оборотом перпа ≥ 20 млн $.
Правило: вход, когда последний фандинг ≥ ВХОД; выход, когда фандинг < ВЫХОД (или отрицательный). Деньги считаются на ВЕСЬ капитал
(половина на споте, половина маржа перпа при плече 1 — без риска ликвидации). Комиссии: спот 0.1%×2 + перп 0.055%×2 на половину капитала каждый
= 0.155% капитала за круг + 0.1% на разницу цен спот/перп при входе и выходе. Только чтение публичных данных.
"""
from __future__ import annotations

import sys
import json
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor

try:
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except Exception:  # noqa: BLE001
    pass

API = "https://api.bybit.com/v5/market"
DAYS = 365
COST = 0.00155 + 0.001          # за полный круг, доля капитала
RULES = [(0.0003, 0.0001), (0.0005, 0.0001), (0.001, 0.0002), (0.0002, 0.0)]   # (вход, выход) за один платёж


def get(url: str):
    for k in range(3):
        try:
            with urllib.request.urlopen(url, timeout=20) as r:
                return json.loads(r.read().decode())
        except Exception:  # noqa: BLE001
            time.sleep(1 + k)
    return {}


def universe() -> list[str]:
    spot = {x["symbol"] for x in get(f"{API}/tickers?category=spot").get("result", {}).get("list", [])}
    lin = get(f"{API}/tickers?category=linear").get("result", {}).get("list", [])
    out = [(x["symbol"], float(x.get("turnover24h") or 0)) for x in lin if x["symbol"].endswith("USDT") and x["symbol"] in spot]
    return [s for s, t in sorted(out, key=lambda z: -z[1]) if t >= 2e7][:80]


def funding(sym: str) -> list[tuple[int, float]]:
    end = int(time.time() * 1000); start = end - DAYS * 86400_000; rows = {}
    cur = end
    while cur > start:
        lst = get(f"{API}/funding/history?category=linear&symbol={sym}&endTime={cur}&limit=200").get("result", {}).get("list", [])
        if not lst:
            break
        for x in lst:
            rows[int(x["fundingRateTimestamp"])] = float(x["fundingRate"])
        cur = int(lst[-1]["fundingRateTimestamp"]) - 1
        if len(lst) < 200:
            break
    return sorted((t, f) for t, f in rows.items() if t >= start)


def sim(fr, ent, ex):
    """Вход по факту прошлого платежа (решение после того, как он известен) — без заглядывания вперёд."""
    pos, pnl, trades, held, log = False, 0.0, 0, 0, []
    for i in range(1, len(fr)):
        prev = fr[i - 1][1]
        if not pos and prev >= ent:
            pos = True; pnl -= COST / 2; trades += 1
        elif pos and prev < ex:
            pos = False; pnl -= COST / 2
        if pos:
            pnl += fr[i][1] / 2          # фандинг идёт на перп = половина капитала
            held += 1
        log.append((fr[i][0], pnl))
    if pos:
        pnl -= COST / 2
    return pnl, trades, held, log


if __name__ == "__main__":
    syms = universe()
    print(f"монет со спотом и перпом: {len(syms)}, фандинг за {DAYS} дней…")
    with ThreadPoolExecutor(6) as ex:
        data = dict(zip(syms, ex.map(funding, syms)))
    mid = int(time.time() * 1000) - DAYS * 86400_000 // 2
    lines = []
    for ent, exi in RULES:
        res = []
        for s, fr in data.items():
            if len(fr) < 100:
                continue
            pnl, n, held, log = sim(fr, ent, exi)
            h1 = next((p for t, p in reversed(log) if t < mid), 0.0)
            res.append((s, pnl, n, held, h1, pnl - h1))
        if not res:
            continue
        # портфель: капитал поровну на все монеты (так честнее, чем выбирать лучшие задним числом)
        tot = sum(r[1] for r in res) / len(res); h1 = sum(r[4] for r in res) / len(res); h2 = sum(r[5] for r in res) / len(res)
        pos = sum(1 for r in res if r[1] > 0)
        best = sorted(res, key=lambda r: -r[1])[:5]
        ok = h1 > 0 and h2 > 0
        lines.append(f"{'✅' if ok else '❌'} вход ≥{ent * 100:.2f}% / выход <{exi * 100:.2f}% за платёж: портфель {tot * 100:+.2f}% за год "
                     f"(1-я половина {h1 * 100:+.2f}%, 2-я {h2 * 100:+.2f}%), монет в плюсе {pos}/{len(res)}, "
                     f"входов в среднем {sum(r[2] for r in res) / len(res):.1f}\n"
                     f"   лучшие (задним числом, не выбирать по ним): "
                     + ", ".join(f"{r[0].replace('USDT', '')} {r[1] * 100:+.1f}%" for r in best))
    # справка: средний фандинг
    allf = [f for fr in data.values() for _t, f in fr]
    lines.append(f"\nСредний фандинг по всем монетам: {sum(allf) / max(1, len(allf)) * 100:.4f}% за платёж; "
                 f"доля платежей ≥0.03%: {sum(1 for f in allf if f >= 0.0003) / max(1, len(allf)) * 100:.1f}%")
    txt = "\n".join(lines)
    print("\n" + txt)
    print("\n✅ = плюс в обеих половинах года после комиссий. Доход — на весь капитал (спот + перп).")
    print("Для сравнения: USDT в Earn на биржах обычно 3–8% годовых без этой возни.")
    with open("funding_test.txt", "w", encoding="utf-8") as f:
        f.write(txt + "\n")
    input("\nEnter — закрыть")
