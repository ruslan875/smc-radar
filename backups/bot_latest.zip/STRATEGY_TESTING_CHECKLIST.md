# 📋 VANTORIX Strategy Testing Checklist

## Этап 1: Подготовка (5 минут)

- [ ] TradingView Desktop запущен
- [ ] Интернет подключен (нужны данные с OKX)
- [ ] Папка `D:\VANTORIX\bot\strategies\` содержит все 25 файлов
- [ ] Создана папка `D:\VANTORIX\bot\backtest_results\` для сохранения результатов
- [ ] `tv` CLI работает (проверить: `tv status` в PowerShell)

---

## Этап 2: Тестирование Tier 1 (простые стратегии) — 30 минут

### Test 1: CE_ZLSMA на XRP 1H

```powershell
# Способ 1: Через batch скрипт
cd D:\VANTORIX\bot
.\Test_Strategies.bat CE_ZLSMA XRPUSDT OKX
```

**Чек-лист:**
- [ ] TradingView открывается
- [ ] Символ переключается на XRP/USDT (OKX)
- [ ] Таймфрейм устанавливается на 1H
- [ ] Стратегия CE_ZLSMA добавляется на график
- [ ] Видны сигналы (стрелки, линии)
- [ ] Скриншот сохраняется в `backtest_results`

**Что смотреть:**
- Видны ли сигналы на графике? (зелёные стрелки = лонг, красные = шорт)
- Есть ли drawdown между сигналами?
- Стоп-линии (ZLSMA) работают?

**Результат:** 📸 Screenshot → сохранить как `001_CE_ZLSMA_XRP_1H.png`

---

### Test 2: High_Low_cloud_trend на XRP 1H

```powershell
.\Test_Strategies.bat High_Low_cloud_trend XRPUSDT OKX
```

**Чек-лист:**
- [ ] Облако (aqua/orange) видно на графике
- [ ] Стрелки cloud-retest работают
- [ ] Фон меняет цвет (зелёный/красный при retests)

**Результат:** 📸 Screenshot → `002_HighLowCloud_XRP_1H.png`

---

### Test 3: Gaussian_channel_strategy на BTC 1H

```powershell
.\Test_Strategies.bat gaussian_channel_strategy BTCUSDT OKX
```

**Чек-лист:**
- [ ] Канал (3 линии) видно на графике
- [ ] Входы срабатывают при пересечениях
- [ ] Нет явного мусора сигналов

**Результат:** 📸 Screenshot → `003_GaussianChannel_BTC_1H.png`

---

## Этап 3: Тестирование Tier 2 (с конфигурациями) — 45 минут

### Test 4: Combo_OTM_v3.2 на XRP 1H (с конфигом)

```powershell
# Сначала посмотреть конфиг
cat "D:\VANTORIX\bot\strategies\Combo_OTM_XRP-1H_OKX.csv" | head -20

# Затем загрузить стратегию
.\Test_Strategies.bat Combo_OTM_v3.2 XRPUSDT OKX
```

**Чек-лист:**
- [ ] Стратегия загружается (может быть медленно, ~10 сек)
- [ ] Видны сигналы (может быть много линий/меток)
- [ ] Нет ошибок в консоли TradingView

**Результат:** 📸 Screenshot → `004_ComboOTM_XRP_1H.png`

---

### Test 5: Pavlova на BTC 1H (с конфигом)

```powershell
cat "D:\VANTORIX\bot\strategies\PAVLOVA_BTC_1H_OKX.csv" | head -10
.\Test_Strategies.bat Pavlova BTCUSDT OKX
```

**Чек-лист:**
- [ ] Order Block уровни видны
- [ ] Trend Catcher линия видна
- [ ] HMA видна (быстрая MA)

**Результат:** 📸 Screenshot → `005_Pavlova_BTC_1H.png`

---

### Test 6: Liquidity_thermal_map_Strategy на ETH 1H

```powershell
.\Test_Strategies.bat Liq_Therm_Map_Strategy ETHUSDT OKX
```

**Чек-лист:**
- [ ] Тепловая карта видна (цветные полосы)
- [ ] Красные зоны (высокий объём) видны
- [ ] Синие зоны (низкий объём) видны

**Результат:** 📸 Screenshot → `006_LiqThermalMap_ETH_1H.png`

---

## Этап 4: Сбор результатов — 10 минут

После каждого теста:

1. **Скриншот** → сохранить в `backtest_results\`
2. **Метрики** → заполнить таблицу ниже:

### Таблица результатов:

| № | Стратегия | Пара | TF | Win Rate | Profit Factor | Drawdown | Trades | Verdict |
|---|-----------|------|----|---------:|---------------:|---------:|-------:|---------|
| 1 | CE_ZLSMA | XRP | 1H | ? | ? | ? | ? | ⏳ |
| 2 | High-Low Cloud | XRP | 1H | ? | ? | ? | ? | ⏳ |
| 3 | Gaussian Channel | BTC | 1H | ? | ? | ? | ? | ⏳ |
| 4 | Combo OTM | XRP | 1H | ? | ? | ? | ? | ⏳ |
| 5 | Pavlova | BTC | 1H | ? | ? | ? | ? | ⏳ |
| 6 | Liq Thermal Map | ETH | 1H | ? | ? | ? | ? | ⏳ |

**Как заполнить (из Strategy Tester статистики):**
- **Win Rate** = Profitable Trades / Total Trades × 100%
- **Profit Factor** = Gross Profit / Gross Loss
- **Drawdown** = Max Drawdown % (из Statistics)
- **Trades** = Total number of trades

---

## Этап 5: Анализ результатов

### Хорошие результаты (✅ keep testing):
- Win Rate > 50%
- Profit Factor > 1.5
- Drawdown < 20%

### Так-себе (⚠️ needs tuning):
- Win Rate 45-50%
- Profit Factor 1.0-1.5
- Drawdown 20-30%

### Плохие (❌ skip):
- Win Rate < 45%
- Profit Factor < 1.0
- Drawdown > 30%

---

## Этап 6: Paper Trading (опционально)

Для TOP-3 стратегий по результатам:

1. Включить **Paper Trading** в TradingView Desktop
2. Установить Paper Balance = $10,000
3. Запустить на **реальных данных** в real-time (хотя бы 7 дней)
4. Собрать метрики

---

## Команды для быстрого ввода:

```powershell
# Все в одной строке:
$strategies = @("CE_ZLSMA", "High_Low_cloud_trend", "gaussian_channel_strategy", "Combo_OTM_v3.2", "Pavlova", "Liq_Therm_Map_Strategy")
$symbols = @("XRPUSDT", "XRPUSDT", "BTCUSDT", "XRPUSDT", "BTCUSDT", "ETHUSDT")

for ($i=0; $i -lt $strategies.Count; $i++) {
    Write-Host "Testing $($strategies[$i]) on $($symbols[$i])..."
    .\Test_Strategies.bat $strategies[$i] $symbols[$i] OKX
    Start-Sleep -Seconds 30
}
```

---

## 📞 Troubleshooting:

**Ошибка: "tv: command not found"**
- Убедитесь, что `npm link` выполнен в `D:\tradingview-mcp`
- Добавьте путь в PATH: `npm config get prefix` → добавьте в PATH

**Ошибка: "Strategy не загружается"**
- Проверьте путь: `D:\VANTORIX\bot\strategies\`
- Проверьте имя файла (case-sensitive)
- Перезагрузите TradingView

**Нет сигналов на графике**
- Проверьте таймфрейм (должен быть 1H по умолчанию)
- Проверьте дату исторических данных (может быть ещё нет)
- Убедитесь, что стратегия добавлена как Strategy, не как Indicator

---

**Начните с Test 1, если всё OK → переходите на Test 2-3.**

Good luck! 🚀

