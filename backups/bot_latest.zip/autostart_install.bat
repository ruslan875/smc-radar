@echo off
REM 2026-10-21: автозапуск после входа в Windows — ВСЁ, а не только сторож и панель:
REM   1) bot_services.py start  — сторож + панель (как раньше);
REM   2) через 60 с restart_all.bat --live — Telegram-бот main.py, KC/ROC грид (LIVE),
REM      Latuserge (LIVE, --capital-per-deal 300).
REM Combo XRP (OKX) сам НЕ стартует: его LIVE требует подтверждения в панели («Реал» с галочкой).
REM Убрать автозапуск: autostart_remove.bat
cd /d "%~dp0"
set "SU=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
> "%SU%\TRADEOS_start.bat" echo @echo off
>> "%SU%\TRADEOS_start.bat" echo cd /d "%~dp0"
>> "%SU%\TRADEOS_start.bat" echo start "" /min "%~dp0venv\Scripts\pythonw.exe" "%~dp0bot_services.py" start
>> "%SU%\TRADEOS_start.bat" echo timeout /t 60 /nobreak ^>nul
>> "%SU%\TRADEOS_start.bat" echo start "TRADEOS live bots" /min cmd /c "%~dp0restart_all.bat" --live
if exist "%SU%\TRADEOS_start.bat" (
  echo Gotovo: posle vhoda v Windows zapustyatsya storozh, panel, Telegram-bot, KC/ROC i Latuserge ^(LIVE^).
  echo Combo XRP zapuskay v paneli knopkoy "Real".
  echo Fail: %SU%\TRADEOS_start.bat
) else (
  echo OSHIBKA: ne udalos zapisat v papku Avtozagruzka.
)
pause
