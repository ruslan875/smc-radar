@echo off
cd /d %~dp0
if exist venv\Scripts\python.exe (venv\Scripts\python.exe fx_multi_test.py) else (python fx_multi_test.py)
