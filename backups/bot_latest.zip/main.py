#!/usr/bin/env python3
"""
Trading-assistant Telegram bot -- general control surface for the user's
account: owner-only chat commands, an AI assistant (/ai, /aiidea,
/aichart), autopilot breakeven/partial-take advisories, a daily digest,
account-health publishing to the Mini App, an instant-trade command
(/trade), and a psychology-check heuristic layer. See app/*.py for each
feature's own module docstring.

RETIRED 2026-09-06: this file used to ALSO be the CHoCH+Order Block+FVG
("SMC") signal detector + its /autotrade auto-trading worker (see
app/smc.py's own docstring, and
claude/dca-bot-reverse-engineering-2026-09-04.md's "2026-09-06: live-bot
decision" section in the project notes) -- that setup was found to be
losing money / thin-edge in real trading and has been removed from this
file entirely: the two-stage structure-break/zone-reaction state machine,
_is_validated_setup's CHoCH+OB+FVG filter, _send_signal, process_symbol,
the /autotrade command + _autotrade_worker background thread, and /ideas
(which only ever showed that detector's zones/signals) are all gone. The
strategy's replacement is a SEPARATE, standalone live script
(long_strategy15_latuserge_live.py) -- it does not run inside this
process. app/smc.py itself is kept on disk (not deleted) because
app/state.py's StateStore still deserializes PendingZone from old state
data; it is otherwise unused. /scan and its ScanSettings watchlist picker
are left in place but are now functionally vestigial (their only real
consumer was this same removed detector) -- a candidate for a future
cleanup pass, not touched here.

One-time invite-code access gate, 2026-08-22 (see app/access.py): message
this bot from YOUR OWN chat (TELEGRAM_CHAT_ID) with /newcode to generate a
fresh 6-character code, valid 24h or until first use. Hand it to exactly
one new person; the first chat that sends that code back gets added to the
signal-delivery list, and the code is then dead (can't be reused by anyone
else who might see it later). Your own chat is always authorized
automatically, regardless of the gate. If GITHUB_TOKEN is set in .env, the
current active code's hash is also published to the Mini App's repo so
the same code can unlock the website -- see app/github_sync.py and the
miniapp project doc for how that sync works and its limits.

Usage:
  python main.py --once          one pass (health publish, access-code
                                  upkeep, etc.), then exit
  python main.py                 run forever, polling every POLL_SECONDS
  python main.py --dry-run       compute but don't call Telegram
"""
from __future__ import annotations

import argparse
import html as html_lib
import json
import re
import os
from pathlib import Path
import sys
import threading
import uuid
import time
import traceback
from datetime import datetime, timedelta, timezone

import requests


# 2026-10-21: токен Telegram-бота попадал в логи открытым текстом (URL в тексте ошибок requests).
# Всё, что печатает этот процесс, проходит через фильтр: bot<id>:<секрет> → bot<id>:***
class _MaskTokens:
    _re = re.compile(r"(bot\d{6,}):[A-Za-z0-9_-]{20,}")

    def __init__(self, stream):
        self._s = stream

    def write(self, text):
        try:
            text = self._re.sub(r"\1:***", text)
        except Exception:  # noqa: BLE001
            pass
        return self._s.write(text)

    def __getattr__(self, name):
        return getattr(self._s, name)


if not isinstance(sys.stdout, _MaskTokens) and sys.stdout is not None:
    sys.stdout = _MaskTokens(sys.stdout)
if not isinstance(sys.stderr, _MaskTokens) and sys.stderr is not None:
    sys.stderr = _MaskTokens(sys.stderr)

import publish_health
from app import chart
from app.access import AccessStore
from app.ai_assistant import (answer_question, build_market_context, daily_digest, explain_report,
                               generate_chart_annotation, resolve_api_key)
# generate_entry_idea убран из импорта 2026-09-13 вместе с переписанным /aiidea:
# эта команда больше не спрашивает языковую модель, она считает движок индикаторов.
# Сама функция в app/ai_assistant.py осталась — на случай, если свободная
# гипотеза понадобится отдельной командой.
from app.ai_key_store import AiKeyStore
from app.autopilot import decide_breakeven_moves, decide_partial_take_advisories
from app.autopilot_settings import AutopilotSettings
from app.config import (
    ACCESS_FILE,
    AI_KEY_FILE,
    AUTOPILOT_SETTINGS_FILE,
    DAILY_REPORT_STATE_FILE,
    EXCHANGE_KEYS_FILE,
    INSTANT_TRADE_SETTINGS_FILE,
    KC_GRID_MAX_DEALS_FILE,
    LATUSERGE_MAX_DEALS_FILE,
    LIVE_JOURNAL_FILE,
    PARTIAL_TAKE_STATE_FILE,
    PSYCHO_STATE_FILE,
    SCAN_SETTINGS_FILE,
    STATE_FILE,
    TRADE_KEYS_FILE,
    Settings,
)
from app.daily_report_state import DailyReportState
from app import trader_brain
from app.data import DataError, get_klines, get_last_price
from app.exchange_keys_store import ExchangeKeysStore
from app.exchanges import REGISTRY as EXCHANGE_REGISTRY
from app.exchanges.base import ExchangeAuthError
from app.github_sync import GitHubSyncError, push_binary_file, push_json_file
from app.instant_trade_settings import InstantTradeSettings
from app.live_bot_settings import MaxConcurrentDealsSettings
from app.partial_take_state import PartialTakeAlertState
from app.psycho_heuristics import check_alerts as check_psycho_alerts
from app.psycho_state import PsychoAlertState
from app.scan_settings import SCAN_MODE_LABELS, SCAN_MODES, ScanSettings
from app import single_instance
from app import manual_trade, notify_prefs, signal_journal
from app.state import StateStore
from app.telegram_client import TelegramClient, TelegramError
from app.trade_executor import execute_trade
from app.trade_keys_store import TradeKeysStore
from app.trade_server import maybe_start_trade_server
from app.vantorix_signal import SignalError, fetch_ai_pick, fetch_signal

HEALTH_PUBLISH_INTERVAL_SECONDS = 15 * 60  # how often to recompute + republish health.json
_last_health_publish_at = 0.0

# Commands the OWNER's own chat can send to request a fresh one-time
# invite code (see app/access.py). Several spellings accepted since this
# is meant to be usable without remembering exact slash-command syntax --
# only the owner's chat can trigger this, so a stray match is harmless
# (worst case: one extra unused code that just expires in 24h).
# "🔑 новый код" (2026-08-26, round 17) is the lowercased BTN_NEWCODE
# persistent-keyboard button label defined further below -- kept as a
# literal here (rather than referencing BTN_NEWCODE) purely because this
# set is defined before that constant; keep the two in sync if either
# wording ever changes.
OWNER_CODE_COMMANDS = {"/newcode", "/code", "код", "новый код", "новый", "🔑 новый код"}
ACCESS_JSON_PATH = "access.json"  # file pushed to the Mini App's repo root

# Commands the OWNER's own chat can send to open the scan-universe picker
# (see app/scan_settings.py). Same "accept several spellings" reasoning as
# OWNER_CODE_COMMANDS above. "⚙️ сканирование" (round 17) is the lowercased
# BTN_SCAN button label, same "defined before that constant" note as above.
OWNER_SCAN_COMMANDS = {"/scan", "настройки", "режим сканирования", "сканирование", "охват", "⚙️ сканирование"}

# A wider scan universe means more Bybit requests per pass; floor the
# effective poll interval so POLL_SECONDS=60 (the default) can't quietly
# turn into hammering the public API every minute once top50/top100 is
# selected. 0 = no floor beyond whatever's in .env.
SCAN_POLL_FLOORS = {"watchlist": 0, "top25": 45, "top50": 90, "top100": 180}


def _publish_active_code(access: AccessStore, settings: Settings) -> None:
    """Push the current active code's hash to the Mini App's repo, if
    GITHUB_TOKEN is configured. Failure here is logged but never raised --
    the bot's own Telegram gate must keep working even if GitHub is
    unreachable or the token is wrong/expired."""
    if not settings.github_token:
        return
    try:
        push_json_file(
            settings.github_token, settings.github_repo, ACCESS_JSON_PATH,
            access.active_code_payload(),
            message="chore: update access code (automated)",
        )
    except GitHubSyncError as exc:
        print(f"[ACCESS] GitHub sync failed (site code check may be stale): {exc}", file=sys.stderr)


# Telegram's "/" command menu (2026-08-22) -- see _register_bot_commands.
# Guests only ever see /start; the owner's chat additionally gets /newcode
# and /scan, so those show up as tappable menu items instead of needing to
# be remembered/typed from scratch.
BOT_COMMANDS_GUEST = [
    {"command": "start", "description": "Начать / ввести код-приглашение"},
]
BOT_COMMANDS_OWNER = [
    {"command": "menu", "description": "📋 Показать меню кнопок"},
    {"command": "newcode", "description": "🔑 Новый код-приглашение"},
    {"command": "scan", "description": "⚙️ Что сканировать (5 монет / топ-25/50/100)"},
    {"command": "report", "description": "📊 Отчёт по торговле (Вера)"},
    {"command": "autopilot", "description": "🤖 Автопилот безубытка вкл/выкл (Вера)"},
    {"command": "maxdeals", "description": "🔢 Лимит одновременных сделок latuserge/kc_roc"},
    {"command": "instanttrade", "description": "⚡ Мгновенное исполнение ордеров вкл/выкл"},
    {"command": "ai", "description": "🧠 Спросить ИИ про свою торговлю"},
    {"command": "aiidea", "description": "✅ Сигнал проверенных стратегий по монете"},
    {"command": "aipick", "description": "🧠 Подобрать ИИ: перебор конфигов стратегии по истории"},
    {"command": "aichart", "description": "🖼 График: зоны бота + экспериментальная ИИ-гипотеза"},
    {"command": "signals", "description": "🎯 Точность сигналов /aiidea и /aipick"},
    {"command": "buy", "description": "🟢 Лонг: /buy SOL 20 sl 1 tp 2 trail 0.7 x3"},
    {"command": "sell", "description": "🔴 Шорт: /sell SOL 20 sl 1 tp 2"},
    {"command": "chart", "description": "📈 График монеты: /chart SOL 1h"},
    {"command": "notify", "description": "🔔 Какие уведомления присылать"},
    {"command": "setaikey", "description": "🔐 Добавить ключ ИИ (Anthropic)"},
    {"command": "start", "description": "Начать"},
]


# 2026-08-26, round 17: persistent reply-keyboard button menu, so the owner
# doesn't have to type slash-commands from memory. A tap on one of these
# buttons arrives to the bot as an ordinary incoming text message whose
# text is exactly the button's label -- see _handle_access_message below,
# which matches these exact strings (in addition to the existing slash
# commands) and calls the SAME handler function the slash command already
# calls. No logic is duplicated anywhere for this menu; every button is a
# thin routing alias onto code that already existed before this round.
BTN_REPORT = "📊 Отчёт"
BTN_NEWCODE = "🔑 Новый код"
BTN_SCAN = "⚙️ Сканирование"
BTN_AUTOPILOT = "🛡 Автопилот"
BTN_INSTANTTRADE = "⚡ Мгновенная торговля"
BTN_OTHER = "ℹ️ Другие команды"

OWNER_MENU_COMMANDS = {"/menu", "меню", "☰ меню"}
BTN_MENU = "☰ Меню"
# 2026-09-23: одна маленькая постоянная кнопка внизу вместо набора кнопок —
# открывает меню-баннер одним нажатием, команду вводить не нужно.
MENU_BUTTON_KEYBOARD = {"keyboard": [[{"text": BTN_MENU}]], "resize_keyboard": True,
                        "is_persistent": True, "input_field_placeholder": "Сообщение или ☰ Меню"}
_menu_button_sent: set[str] = set()
_last_menu_msg: dict[str, int] = {}


# 2026-09-23: меню бота по структуре TRADEOS (та же, что боковое меню Mini
# App). Раздел открывается в том же сообщении, «‹ Назад» возвращает к
# списку. Каждое действие вызывает уже существующий обработчик команды.
# Разделы, которым нужен экран (обучение, калькуляторы, журнал), открывают
# Mini App: кнопками чата их не сделать.
# 2026-09-25: убраны дубли (отчёт был в трёх разделах, автопилот и точность
# сигналов — в двух, «Режим сканирования» — в двух, хотя сам скан выведен из
# работы 06.09). Каждое действие теперь в одном месте.
MENU_SECTIONS = [
    ("signals", "📊 Сигналы", [
        ("🪙 Сигнал по монете (24 монеты)", "coins:aiidea:signals"), ("🎯 Точность сигналов", "act:signals"),
    ]),
    ("auto", "🤖 Автоторговля", [
        ("🟢 Открыть сделку (/buy /sell)", "act:buyhelp"), ("🛡 Автопилот", "act:autopilot"),
        ("⚡ Мгновенная торговля", "act:instanttrade"), ("🔢 Лимит сделок", "act:maxdeals"),
    ]),
    ("analytics", "📈 Аналитика", [
        ("🧠 Подбор ИИ — выбрать монету", "coins:aipick:analytics"),
        ("📈 График монеты", "coins:chart:analytics"),
        ("🖼 График ИИ — выбрать монету", "coins:aichart:analytics"), ("💬 Спросить ИИ", "act:askai"),
    ]),
    ("portfolio", "💼 Портфель и риск", [("📊 Позиции, P&L и риск", "act:report")]),
    ("exchanges", "🔗 Биржи", [("🔑 Торговые ключи", "act:tradekey"), ("ℹ️ Как подключить биржу", "act:other")]),
    ("market", "🌐 Рынок", "app"),
    ("learn", "🎓 Обучение", "app"),
    ("tools", "🛠 Инструменты", "app"),
    ("premium", "👑 Premium", "app"),
    ("settings", "⚙️ Настройки", [("🔔 Уведомления", "ntf:show"), ("🔑 Новый код доступа", "act:newcode")]),
    ("help", "❓ Помощь", [("ℹ️ Все команды", "act:other")]),
]
_MENU_BY_KEY = {k: (title, items) for k, title, items in MENU_SECTIONS}

# 2026-09-23: монеты для выбора в меню (было всего 3 — BTC/ETH/SOL).
# Топ по объёму на Bybit USDT-фьючерсах; любую другую — командой вручную.
MENU_COINS = ["BTC", "ETH", "SOL", "XRP", "BNB", "DOGE", "ADA", "TON", "AVAX", "LINK", "SUI", "TRX",
              "DOT", "LTC", "BCH", "NEAR", "APT", "ARB", "OP", "INJ", "TIA", "HYPE", "PEPE", "WIF"]
_COIN_ACTION_TITLE = {"aiidea": "📊 Сигнал 1ч", "aipick": "🧠 Подбор ИИ 1ч", "aichart": "🖼 График ИИ",
                      "chart": "📈 График 1ч"}


def _menu_coins_keyboard(action: str, back: str) -> dict:
    rows, row = [], []
    for c in MENU_COINS:
        row.append({"text": c, "callback_data": f"menu:act:{action}:{c}USDT"})
        if len(row) == 4:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    rows.append([{"text": "‹ Назад", "callback_data": f"menu:sec:{back}"}])
    return {"inline_keyboard": rows}


def _mini_app_button() -> dict | None:
    url = os.getenv("MINI_APP_URL", "").strip()
    return {"text": "📱 Открыть TRADEOS", "web_app": {"url": url}} if url.startswith("https://") else None


def _menu_inline_keyboard() -> dict:
    """Главный экран меню: разделы по два в ряд + кнопка Mini App."""
    rows, row = [], []
    for key, title, _ in MENU_SECTIONS:
        row.append({"text": title, "callback_data": f"menu:sec:{key}"})
        if len(row) == 2:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    app = _mini_app_button()
    if app:
        rows.append([app])
    rows.append([{"text": "✖ Закрыть", "callback_data": "menu:close"}])
    return {"inline_keyboard": rows}


def _menu_section_keyboard(key: str) -> dict:
    _, items = _MENU_BY_KEY[key]
    rows = []
    if items == "app":
        app = _mini_app_button()
        if app:
            rows.append([app])
    else:
        rows = [[{"text": label, "callback_data": f"menu:{target}"}] for label, target in items]
    rows.append([{"text": "‹ Назад", "callback_data": "menu:home"}])
    return {"inline_keyboard": rows}


MENU_HOME_TEXT = "<b>TRADEOS</b> · выбери раздел"

# 2026-09-23: баннер над меню. file_id запоминается после первой загрузки,
# дальше Telegram не перекачивает картинку при каждом /menu.
MENU_BANNER_PATH = Path(__file__).resolve().parent / "mini_app" / "brand" / "banner_1280x640.png"
_menu_banner_file_id: str | None = None


def _send_menu(telegram: TelegramClient, chat_id: str) -> None:
    """Меню-баннер. Предыдущее меню в этом чате удаляется, чтобы не копились."""
    old = _last_menu_msg.pop(chat_id, None)
    if old:
        _try_delete_message(telegram, chat_id, old)
    resp = _send_menu_raw(telegram, chat_id)
    mid = ((resp or {}).get("result") or {}).get("message_id")
    if mid:
        _last_menu_msg[chat_id] = mid


def _send_menu_raw(telegram: TelegramClient, chat_id: str) -> dict | None:
    global _menu_banner_file_id
    markup = _menu_inline_keyboard()
    if MENU_BANNER_PATH.exists():
        try:
            if _menu_banner_file_id:
                return telegram.send_photo(None, MENU_HOME_TEXT, chat_id=chat_id, reply_markup=markup,
                                           file_id=_menu_banner_file_id)
            else:
                resp = telegram.send_photo(MENU_BANNER_PATH.read_bytes(), MENU_HOME_TEXT,
                                           chat_id=chat_id, reply_markup=markup)
                photos = ((resp.get("result") or {}).get("photo") or [])
                if photos:
                    _menu_banner_file_id = photos[-1].get("file_id")
                return resp
        except (TelegramError, requests.exceptions.RequestException, OSError) as exc:
            print(f"[MENU] banner failed, sending text menu: {exc}", file=sys.stderr)
            _menu_banner_file_id = None
    return telegram.send_message(MENU_HOME_TEXT, chat_id=chat_id, reply_markup=markup)


def _autopilot_menu_keyboard() -> dict:
    """Inline keyboard attached to /autopilot's no-argument status reply
    (2026-08-26, round 17) -- shown both when the owner types a bare
    /autopilot and when they tap the "🛡 Автопилот" persistent-keyboard
    button (see _handle_access_message), since both paths call the exact
    same _handle_autopilot_command. Tapping either button here fires a
    callback_query handled by _handle_autopilot_callback, which is itself
    just a thin dispatcher back into _handle_autopilot_command with a
    synthetic "/autopilot on"/"off" -- the real toggle logic lives in
    exactly ONE place, never duplicated for the button path."""
    return {"inline_keyboard": [[
        {"text": "✅ Включить", "callback_data": "autopilot:on"},
        {"text": "⛔ Выключить", "callback_data": "autopilot:off"},
    ], [
        {"text": "↗️ Трейлинг ВКЛ", "callback_data": "autopilot:trail_on"},
        {"text": "Трейлинг выкл", "callback_data": "autopilot:trail_off"},
    ]]}


def _instanttrade_menu_keyboard() -> dict:
    """Same pattern as _autopilot_menu_keyboard, for /instanttrade -- see
    that function's docstring."""
    return {"inline_keyboard": [[
        {"text": "✅ Включить", "callback_data": "instanttrade:on"},
        {"text": "⛔ Выключить", "callback_data": "instanttrade:off"},
    ]]}


def _handle_other_commands_button(telegram: TelegramClient, chat_id: str) -> None:
    """"ℹ️ Другие команды" button (2026-08-26, round 17) -- a plain
    reference message for the commands that were deliberately NOT turned
    into one-tap buttons, because each one either carries a secret
    (api_key/api_secret/passphrase) or needs free-form text (a question, a
    trade's exact numbers) that a button can't collect. Purely informational
    -- doesn't call anything, doesn't change any state."""
    telegram.send_message(
        "ℹ️ <b>Остальные команды</b> (наберите вручную -- содержат секреты или свободный текст, "
        "поэтому не сделаны кнопками):\n\n"
        "<code>/ai вопрос</code>\n  спросить ИИ про свою торговлю, например <code>/ai как у меня с риском?</code>\n\n"
        "<code>/aiidea СИМВОЛ [ТАЙМФРЕЙМ]</code>\n  сигнал движка VANTORIX: консенсус 34 индикаторов, кто как проголосовал, вход/стоп/тейк от ATR и бэктест этой связки. Например <code>/aiidea BTCUSDT</code> или <code>/aiidea ETHUSDT 4h</code>\n\n"
        "<code>/aipick СИМВОЛ [ТАЙМФРЕЙМ] [итераций]</code>\n  подбор ИИ: перебирает случайные наборы индикаторов и пороги, показывает топ-5 по истории. Например <code>/aipick BTCUSDT</code> или <code>/aipick BTCUSDT 4h 400</code>\n\n"
        "<code>/aichart СИМВОЛ</code>\n  график: реальные зоны/уровни бота + отдельно помеченная "
        "экспериментальная ИИ-гипотеза, например <code>/aichart BTCUSDT</code>\n\n"
        "<code>/trade биржа символ buy|sell объём плечо stop_loss [take_profit] [gate] [entry=цена]</code>\n"
        "  открыть реальный ордер, например <code>/trade bybit BTCUSDT buy 0.001 5 61500 64000</code>\n\n"
        "<code>/tradekey биржа api_key api_secret [passphrase]</code>\n"
        "  добавить общий торговый ключ биржи (нужен для /trade и автопилота)\n\n"
        "<code>/tradekey latuserge|kcroc биржа api_key api_secret [passphrase]</code>\n"
        "  добавить ОТДЕЛЬНЫЙ ключ только для одной стратегии (свой аккаунт/риск-бюджет); "
        "без аргументов <code>/tradekey</code> показывает, у какой стратегии какой ключ сейчас в силе\n\n"
        "<code>/setkey биржа api_key api_secret [passphrase]</code>\n"
        "  добавить ключ для чтения (для вкладки «Здоровье»)\n\n"
        "<code>/setaikey api_key</code>\n  добавить ключ ИИ (Anthropic, с console.anthropic.com)\n\n"
        "<code>/maxdeals</code>\n  посмотреть лимит одновременных сделок latuserge/kc_roc, например "
        "<code>/maxdeals latuserge 3</code> чтобы задать",
        chat_id=chat_id,
    )


def _ai_escape(text: str) -> str:
    """2026-08-24, round 10: AI-generated text is free-form and NOT
    guaranteed to be free of characters that would break a
    parse_mode="HTML" Telegram message (a stray "<"/"&" is enough to make
    sendMessage fail outright, see app/ai_assistant.py's module docstring)
    -- every AI string gets escaped through this before being interpolated
    into an HTML message. Doesn't escape quotes (Telegram's HTML subset
    doesn't need that outside of tag attributes, which nothing here
    produces)."""
    return html_lib.escape(text, quote=False)


def _register_bot_commands(settings: Settings) -> None:
    """Registers the command menus above. Failure here is logged but never
    raised -- purely a UX nicety (Telegram's "/" menu button), the bot's
    actual gate/scan-picker logic works fine via typed text either way."""
    try:
        telegram = TelegramClient(settings.telegram_token, settings.telegram_chat_id)
        telegram.set_my_commands(BOT_COMMANDS_GUEST)
        telegram.set_my_commands(BOT_COMMANDS_OWNER, chat_id=settings.telegram_chat_id)
    except (TelegramError, requests.exceptions.RequestException) as exc:
        print(f"[INFO] couldn't register bot command menu: {exc}", file=sys.stderr)


def _effective_poll_seconds(base: int, mode: str) -> int:
    return max(base, SCAN_POLL_FLOORS.get(mode, 0))


def _scan_menu_keyboard(current_mode: str) -> dict:
    buttons = []
    for mode, label in SCAN_MODE_LABELS.items():
        prefix = "✅ " if mode == current_mode else ""
        buttons.append([{"text": f"{prefix}{label}", "callback_data": f"scan:{mode}"}])
    return {"inline_keyboard": buttons}


def _handle_scan_callback(telegram: TelegramClient, access: AccessStore, scan: ScanSettings, cq: dict) -> None:
    """One button press from the /scan menu. Owner-only -- anyone else's
    tap is just acknowledged (removes their loading spinner) and ignored,
    same "don't even hint this exists to non-owners" posture as the rest
    of the gate.

    2026-08-23 bugfix: Telegram rejects answerCallbackQuery once a button
    press is "too old" (observed live: happens well within a single
    60-180s scan cycle, since _handle_access_updates only checks for new
    updates once per pass, not on a fast dedicated poll). That used to be
    an uncaught TelegramError that killed the entire bot process -- the
    mode switch itself (scan.set_mode below) had already succeeded and
    persisted, but the crash meant no confirmation ever reached the user
    and the whole scan loop stopped until they noticed and restarted it
    by hand. Every Telegram call in here is now wrapped so a stale/failed
    acknowledgment or message send is logged, never fatal."""
    msg = cq.get("message") or {}
    chat = msg.get("chat") or cq.get("from") or {}
    chat_id = str(chat.get("id", ""))
    data = cq.get("data") or ""

    def _ack(text: str | None = None) -> None:
        try:
            telegram.answer_callback_query(cq["id"], text=text)
        except TelegramError as exc:
            print(f"[SCAN] couldn't acknowledge button press (likely just expired -- harmless): {exc}",
                  file=sys.stderr)

    if not access.is_owner(chat_id) or not data.startswith("scan:"):
        _ack()
        return

    mode = data.split("scan:", 1)[1]
    if mode not in SCAN_MODES:
        _ack(text="Неизвестный режим")
        return

    scan.set_mode(mode)
    label = SCAN_MODE_LABELS[mode]
    _ack(text=f"Режим: {label}")
    try:
        telegram.send_message(f"✅ Режим сканирования: {label}", chat_id=chat_id)
    except TelegramError as exc:
        print(f"[SCAN] mode switched to {mode} (saved) but confirmation message failed to send: {exc}",
              file=sys.stderr)
    print(f"[SCAN] owner switched scan mode -> {mode}")


def _handle_autopilot_callback(telegram: TelegramClient, access: AccessStore, settings: Settings, cq: dict) -> None:
    """One button press from the "🛡 Автопилот" inline menu
    (2026-08-26, round 17 -- see _autopilot_menu_keyboard). Owner-only,
    same posture as _handle_scan_callback above: anyone else's tap is just
    acknowledged (clears their loading spinner) and otherwise ignored, no
    hint the feature even exists to a non-owner chat.

    THIN WRAPPER ONLY, by design (this toggles the single highest-risk
    real-money feature in this whole project): this function does nothing
    except parse which button was tapped and hand off to
    _handle_autopilot_command with the exact same "/autopilot on"/"off"
    text the typed command already accepts -- the actual enable/disable
    logic lives in exactly one place and can never drift between the two
    entry points."""
    msg = cq.get("message") or {}
    chat = msg.get("chat") or cq.get("from") or {}
    chat_id = str(chat.get("id", ""))
    data = cq.get("data") or ""

    def _ack(text: str | None = None) -> None:
        try:
            telegram.answer_callback_query(cq["id"], text=text)
        except (TelegramError, requests.exceptions.RequestException) as exc:
            print(f"[AUTOPILOT] couldn't acknowledge button press (likely just expired -- harmless): {exc}",
                  file=sys.stderr)

    if not access.is_owner(chat_id) or not data.startswith("autopilot:"):
        _ack()
        return

    arg = data.split("autopilot:", 1)[1]
    if arg not in ("on", "off", "trail_on", "trail_off"):
        _ack(text="Неизвестное действие")
        return
    _ack()
    _handle_autopilot_command(telegram, chat_id, f"/autopilot {arg.replace('_', ' ')}", settings)


def _handle_instanttrade_callback(telegram: TelegramClient, access: AccessStore, settings: Settings, cq: dict) -> None:
    """One button press from the "⚡ Мгновенная торговля" inline menu
    (2026-08-26, round 17 -- see _instanttrade_menu_keyboard). Same
    owner-only posture and same THIN-WRAPPER-ONLY discipline as
    _handle_autopilot_callback above -- hands off to
    _handle_instanttrade_command with a synthetic "/instanttrade on"/"off"
    text, never reimplements the toggle."""
    msg = cq.get("message") or {}
    chat = msg.get("chat") or cq.get("from") or {}
    chat_id = str(chat.get("id", ""))
    data = cq.get("data") or ""

    def _ack(text: str | None = None) -> None:
        try:
            telegram.answer_callback_query(cq["id"], text=text)
        except (TelegramError, requests.exceptions.RequestException) as exc:
            print(f"[INSTANTTRADE] couldn't acknowledge button press (likely just expired -- harmless): {exc}",
                  file=sys.stderr)

    if not access.is_owner(chat_id) or not data.startswith("instanttrade:"):
        _ack()
        return

    arg = data.split("instanttrade:", 1)[1]
    if arg not in ("on", "off"):
        _ack(text="Неизвестное действие")
        return
    _ack()
    _handle_instanttrade_command(telegram, chat_id, f"/instanttrade {arg}", settings)


def _issue_new_code(telegram: TelegramClient, access: AccessStore, settings: Settings, chat_id: str) -> None:
    """Общий код для /newcode и кнопки меню «Новый код» (вынесен 2026-09-22)."""
    code = access.create_code()
    _publish_active_code(access, settings)
    telegram.send_message(
        f"🔑 Новый одноразовый код: <code>{code}</code>\n"
        f"Действует 24 часа или до первого использования (кем бы то ни было -- ботом или сайтом).",
        chat_id=chat_id,
    )
    print(f"[ACCESS] owner requested new invite code")


def _handle_menu_callback(telegram: TelegramClient, access: AccessStore, scan: ScanSettings,
                           settings: Settings, state: StateStore, cq: dict) -> None:
    """Нажатие в меню TRADEOS (2026-09-23). menu:home / menu:sec:<раздел>
    листают одно и то же сообщение; menu:act:<действие>[:арг] закрывает меню
    и вызывает существующий обработчик команды. Только для владельца."""
    msg = cq.get("message") or {}
    chat = msg.get("chat") or cq.get("from") or {}
    chat_id = str(chat.get("id", ""))
    message_id = msg.get("message_id")
    data = cq.get("data") or ""

    try:
        telegram.answer_callback_query(cq["id"])
    except (TelegramError, requests.exceptions.RequestException) as exc:
        print(f"[MENU] couldn't acknowledge button press (harmless): {exc}", file=sys.stderr)

    if not access.is_owner(chat_id) or not data.startswith("menu:"):
        return
    parts = data.split(":")

    def _edit(text: str, markup: dict) -> None:
        try:
            if msg.get("photo"):
                telegram.edit_message_caption(chat_id, message_id, text, reply_markup=markup)
            else:
                telegram.edit_message_text(chat_id, message_id, text, reply_markup=markup)
        except (TelegramError, requests.exceptions.RequestException) as exc:
            # "message is not modified" и подобное -- просто пришлём заново
            print(f"[MENU] edit failed, resending: {exc}", file=sys.stderr)
            telegram.send_message(text, chat_id=chat_id, reply_markup=markup)

    if parts[1] == "home":
        _edit(MENU_HOME_TEXT, _menu_inline_keyboard())
        return
    if parts[1] == "close":
        _last_menu_msg.pop(chat_id, None)
        _try_delete_message(telegram, chat_id, message_id)
        return
    if parts[1] == "coins" and len(parts) > 3 and parts[2] in _COIN_ACTION_TITLE:
        _edit(f"<b>{_COIN_ACTION_TITLE[parts[2]]}</b> · выбери монету\n"
              f"<i>Другая монета — командой, например</i> <code>/{parts[2]} PEPEUSDT 4h</code>",
              _menu_coins_keyboard(parts[2], parts[3]))
        return
    if parts[1] == "ntf":
        # 2026-09-24: переключатели уведомлений — меняем в том же сообщении
        if len(parts) > 2 and parts[2] != "show":
            try:
                notify_prefs.toggle(parts[2])
            except KeyError:
                pass
        _edit(_notify_text(), _notify_keyboard(back="menu:sec:settings"))
        return
    if parts[1] == "sec" and len(parts) > 2 and parts[2] in _MENU_BY_KEY:
        title, items = _MENU_BY_KEY[parts[2]]
        if items == "app":
            text = (f"<b>{title}</b>\nЭтот раздел — экран в приложении TRADEOS "
                    f"(кнопка «SMC Radar» слева от поля ввода).")
        else:
            text = f"<b>{title}</b>"
        _edit(text, _menu_section_keyboard(parts[2]))
        return
    if parts[1] != "act" or len(parts) < 3:
        print(f"[MENU] unrecognized menu data {data!r}", file=sys.stderr)
        return

    action, arg = parts[2], (parts[3] if len(parts) > 3 else "")
    _last_menu_msg.pop(chat_id, None)
    _try_delete_message(telegram, chat_id, message_id)

    if action == "report":
        _handle_report_command(telegram, chat_id, settings)
    elif action == "newcode":
        _issue_new_code(telegram, access, settings, chat_id)
    elif action == "scan":
        telegram.send_message("Что сканировать?", chat_id=chat_id, reply_markup=_scan_menu_keyboard(scan.mode))
    elif action == "autopilot":
        _handle_autopilot_command(telegram, chat_id, "/autopilot", settings)
    elif action == "instanttrade":
        _handle_instanttrade_command(telegram, chat_id, "/instanttrade", settings)
    elif action == "maxdeals":
        _handle_maxdeals_command(telegram, chat_id, "/maxdeals")
    elif action == "tradekey":
        _handle_tradekey_command(telegram, chat_id, "/tradekey")
    elif action == "aiidea" and arg:
        _handle_aiidea_command(telegram, chat_id, f"/aiidea {arg} 1h", settings, state)
    elif action == "aipick" and arg:
        _handle_aipick_command(telegram, chat_id, f"/aipick {arg} 1h", settings, state)
    elif action == "aichart" and arg:
        _handle_aichart_command(telegram, chat_id, f"/aichart {arg}", settings, state)
    elif action == "buyhelp":
        telegram.send_message(BUY_SELL_HELP.format(d=MANUAL_DEFAULT_USDT), chat_id=chat_id)
    elif action == "chart" and arg:
        _handle_chart_command(telegram, chat_id, f"/chart {arg} 1h")
    elif action == "signals":
        _handle_signals_command(telegram, chat_id, "/signals")
    elif action == "askai":
        telegram.send_message("Напиши вопрос после команды, например:\n<code>/ai как у меня с риском?</code>",
                              chat_id=chat_id)
    elif action == "other":
        _handle_other_commands_button(telegram, chat_id)
    else:
        print(f"[MENU] unrecognized menu action {action!r}", file=sys.stderr)


def _notify_text() -> str:
    return ("🔔 <b>Уведомления</b>\nНажми, чтобы включить или выключить. Действует сразу, "
            "без перезапуска ботов.\n<i>Предупреждения ботов лучше не выключать — там сообщения "
            "об отклонённых ордерах и пропавших позициях.</i>")


def _notify_keyboard(back: str | None = None) -> dict:
    prefs = notify_prefs.all_prefs()
    rows = [[{"text": ("✅ " if prefs[k] else "🔕 ") + label, "callback_data": f"menu:ntf:{k}"}]
            for k, label in notify_prefs.CATEGORIES]
    if back:
        rows.append([{"text": "‹ Назад", "callback_data": back}])
    return {"inline_keyboard": rows}


# ─── Ручные сделки и графики из Telegram (2026-09-24) ─────────────────────────
# Тот же путь, что кнопка LIVE в терминале: app/manual_trade.py -> execute_trade.
# Любая сделка сначала показывается превью (график + объём, стоп, тейк, риск)
# с кнопками «Открыть» / «Отмена»; превью живёт 2 минуты.
_PENDING_TRADES: dict = {}
_SIGNAL_DRAFTS: dict = {}
MANUAL_DEFAULT_USDT = float(os.getenv("MANUAL_DEFAULT_USDT", "20"))


def _tf_for_klines(timeframe: str) -> str:
    lbl = _TF_LABELS.get(str(timeframe), str(timeframe)).lower()
    return lbl if lbl in ("1m", "3m", "5m", "15m", "30m", "1h", "4h", "1d") else "1h"


def _levels_chart(symbol: str, timeframe: str, side: str, entry: float, sl: float | None,
                  tp: float | None) -> bytes | None:
    try:
        tf = _tf_for_klines(timeframe)
        df = get_klines(symbol, tf, limit=150)
        return chart.render_position_chart(df=df, symbol_label=symbol.replace("USDT", ""), timeframe=tf,
                                           side="buy" if side == "LONG" else "sell", entry=entry,
                                           stop_loss=sl, take_profit=tp, mark_price=float(df["close"].iloc[-1]))
    except Exception as exc:  # noqa: BLE001 -- без картинки тоже можно
        print(f"[CHART] {symbol}: {exc}", file=sys.stderr)
        return None


def _send_signal_chart(telegram: TelegramClient, chat_id: str, symbol: str, timeframe: str, side: str,
                       entry: float, tp: float, sl: float, source: str) -> None:
    """График сигнала с уровнями + кнопка «Открыть сделку» (через превью)."""
    did = uuid.uuid4().hex[:8]
    _SIGNAL_DRAFTS[did] = {"symbol": symbol, "side": side, "entry": entry, "tp": tp, "sl": sl,
                           "tf": timeframe, "at": time.time()}
    icon = "🟢" if side == "LONG" else "🔴"
    caption = (f"{icon} <b>{symbol} {_TF_LABELS.get(str(timeframe), timeframe)} — {side}</b> ({source})\n"
               f"Вход <code>{_fmt_price(entry)}</code> · тейк <code>{_fmt_price(tp)}</code> "
               f"({(tp / entry - 1) * 100:+.2f}%) · стоп <code>{_fmt_price(sl)}</code> ({(sl / entry - 1) * 100:+.2f}%)")
    kb = {"inline_keyboard": [[{"text": f"{icon} Открыть {side} {MANUAL_DEFAULT_USDT:g}$",
                                "callback_data": f"mtrade:sig:{did}:{MANUAL_DEFAULT_USDT:g}"},
                               {"text": f"{MANUAL_DEFAULT_USDT * 2:g}$",
                                "callback_data": f"mtrade:sig:{did}:{MANUAL_DEFAULT_USDT * 2:g}"}]]}
    png = _levels_chart(symbol, timeframe, side, entry, sl, tp)
    try:
        if png:
            telegram.send_photo(png, caption, chat_id=chat_id, reply_markup=kb)
        else:
            telegram.send_message(caption, chat_id=chat_id, reply_markup=kb)
    except Exception as exc:  # noqa: BLE001
        print(f"[CHART] send failed: {exc}", file=sys.stderr)


def _preview_caption(p: dict, note: str = "") -> str:
    icon = "🟢" if p["side"] == "LONG" else "🔴"
    lines = [f"{icon} <b>Проверь сделку · {p['symbol']} {p['side']}</b> · Bybit, {p['account']}"]
    if note:
        lines.append(f"<i>{note}</i>")
    lines += [
        f"Объём {p['qty']:g} ≈ <b>{p['notional']} USDT</b> · плечо x{p['leverage']} · маржа {p['margin']} USDT",
        f"Цена сейчас {_fmt_price(p['price'])}",
        f"Стоп <code>{_fmt_price(p['stop_loss'])}</code> (−{p['sl_pct']:g}%) · риск ≈ <b>{p['risk_usdt']} USDT</b>",
        f"Тейк <code>{_fmt_price(p['take_profit'])}</code> (+{p['tp_pct']:g}%)" if p["take_profit"] else "Тейк: нет",
        (f"Трейлинг {p['trailing']['pct']:g}% — включится при {_fmt_price(p['trailing']['active_price'])}"
         if p.get("trailing") else "Трейлинг: нет"),
        "",
        "Реальные деньги. Открыть? (превью действует 2 минуты)",
    ]
    return "\n".join(lines)


def _send_trade_preview(telegram: TelegramClient, chat_id: str, params: dict, settings: Settings,
                        note: str = "", timeframe: str = "60") -> None:
    try:
        p = manual_trade.prepare(params["symbol"], params["side"], params["usdt"], params["leverage"],
                                 params["sl_pct"], params.get("tp_pct"), params.get("trail_pct"), settings)
    except manual_trade.ManualTradeError as exc:
        telegram.send_message(f"⛔ {html_lib.escape(exc.message)}", chat_id=chat_id)
        return
    pid = uuid.uuid4().hex[:8]
    _PENDING_TRADES[pid] = {"params": params, "at": time.time(), "chat": chat_id}
    trail_btn = ({"text": "Убрать трейлинг", "callback_data": f"mtrade:tr:{pid}"} if p.get("trailing") else
                 {"text": f"↗️ Добавить трейлинг {min(max(p['sl_pct'], 0.2), 10):g}%",
                  "callback_data": f"mtrade:tr:{pid}"})
    kb = {"inline_keyboard": [[{"text": "✅ Открыть", "callback_data": f"mtrade:ok:{pid}"},
                               {"text": "✖ Отмена", "callback_data": f"mtrade:no:{pid}"}],
                              [trail_btn]]}
    caption = _preview_caption(p, note)
    png = _levels_chart(p["symbol"], timeframe, p["side"], p["price"], p["stop_loss"], p["take_profit"])
    if png:
        telegram.send_photo(png, caption, chat_id=chat_id, reply_markup=kb)
    else:
        telegram.send_message(caption, chat_id=chat_id, reply_markup=kb)


def _parse_buy_sell(text: str) -> dict:
    """/buy SOL 20 sl 1 tp 2 trail 0.7 x3  (порядок после монеты любой).
    Сумма — размер позиции в USDT (можно «20$»); sl/tp/trail — проценты."""
    parts = text.replace("=", " ").split()
    if len(parts) < 2:
        raise manual_trade.ManualTradeError("укажи монету")
    out = {"side": "LONG" if parts[0].lower().startswith("/buy") else "SHORT",
           "symbol": parts[1], "usdt": MANUAL_DEFAULT_USDT, "leverage": 3, "sl_pct": None,
           "tp_pct": None, "trail_pct": None}
    rest = parts[2:]
    i = 0
    while i < len(rest):
        t = rest[i].lower().rstrip("%")
        if t in ("sl", "tp", "trail") and i + 1 < len(rest):
            out[f"{t}_pct"] = rest[i + 1].rstrip("%").replace(",", ".")
            i += 2
            continue
        if t.startswith("x") and t[1:].isdigit():
            out["leverage"] = int(t[1:])
        else:
            out["usdt"] = t.rstrip("$").replace(",", ".")
        i += 1
    if out["sl_pct"] is None:
        out["sl_pct"] = "1"
    return out


BUY_SELL_HELP = ("Формат: <code>/buy SOL 20 sl 1 tp 2</code> или <code>/sell BTC 50 sl 0.8 tp 1.5 trail 0.6 x3</code>\n"
                 "20 — размер позиции в USDT (по умолчанию {d:g}), sl/tp/trail — проценты от цены, "
                 "x3 — плечо (по умолчанию 3). Стоп обязателен (по умолчанию 1%). "
                 "Сначала придёт превью с графиком и кнопкой «Открыть».")


def _handle_buy_sell_command(telegram: TelegramClient, chat_id: str, text: str, settings: Settings) -> None:
    try:
        params = _parse_buy_sell(text)
    except manual_trade.ManualTradeError:
        telegram.send_message(BUY_SELL_HELP.format(d=MANUAL_DEFAULT_USDT), chat_id=chat_id)
        return
    _send_trade_preview(telegram, chat_id, params, settings)


def _handle_chart_command(telegram: TelegramClient, chat_id: str, text: str) -> None:
    """/chart SOL [1h] — свечи; если по монете есть открытая позиция на бирже
    или активный сигнал — с линиями входа/стопа/тейка."""
    parts = text.split()
    if len(parts) < 2:
        telegram.send_message("Формат: <code>/chart SOL</code> или <code>/chart BTC 4h</code>", chat_id=chat_id)
        return
    symbol = manual_trade.norm_symbol(parts[1])
    tf = _normalize_timeframe(parts[2] if len(parts) > 2 else "")
    side, entry, sl, tp, what = "LONG", None, None, None, "без открытых позиций и сигналов"
    for r in reversed(signal_journal.all_rows()):
        if r.get("symbol") == symbol and r.get("status") == "open":
            side, entry, sl, tp = r["side"], r["entry"], r["sl"], r["tp"]
            what = f"активный сигнал /{r['source']} {r['side']}"
            break
    try:
        df = get_klines(symbol, _tf_for_klines(tf), limit=150)
    except Exception as exc:  # noqa: BLE001
        telegram.send_message(f"⚠️ Нет свечей по {symbol}: {html_lib.escape(str(exc))}", chat_id=chat_id)
        return
    last = float(df["close"].iloc[-1])
    png = chart.render_position_chart(df=df, symbol_label=symbol.replace("USDT", ""), timeframe=_tf_for_klines(tf),
                                      side="buy" if side == "LONG" else "sell", entry=entry or last,
                                      stop_loss=sl, take_profit=tp, mark_price=last)
    telegram.send_photo(png, f"📈 <b>{symbol} {_TF_LABELS.get(tf, tf)}</b> · цена {_fmt_price(last)}\n<i>{what}</i>",
                        chat_id=chat_id)


def _lab_signal_draft(key: str) -> dict | None:
    """2026-09-27: сигналы paper-ботов из вкладки «Бэктест» (lab_paper.py) — отдельный процесс,
    поэтому черновик лежит файлом bt_lab_bots/signals/<id>.json. Кнопка ведёт в то же превью
    «Проверь сделку» с подтверждением «✅ Открыть» — сам бот реальных ордеров не ставит."""
    if not re.fullmatch(r"[0-9a-f]{8,16}", key or ""):
        return None
    f = Path(__file__).resolve().parent / "bt_lab_bots" / "signals" / f"{key}.json"
    try:
        d = json.loads(f.read_text(encoding="utf-8"))
        d["at"] = float(d.get("at") or 0)
        return d
    except (OSError, ValueError):
        return None


def _handle_mtrade_callback(telegram: TelegramClient, access: AccessStore, settings: Settings, cq: dict) -> None:
    msg = cq.get("message") or {}
    chat_id = str((msg.get("chat") or cq.get("from") or {}).get("id", ""))
    message_id = msg.get("message_id")
    parts = (cq.get("data") or "").split(":")
    try:
        telegram.answer_callback_query(cq["id"])
    except (TelegramError, requests.exceptions.RequestException):
        pass
    if not access.is_owner(chat_id) or len(parts) < 3:
        return
    action, key = parts[1], parts[2]

    def _caption(text: str) -> None:
        try:
            if msg.get("photo"):
                telegram.edit_message_caption(chat_id, message_id, text, reply_markup={"inline_keyboard": []})
            else:
                telegram.edit_message_text(chat_id, message_id, text, reply_markup={"inline_keyboard": []})
        except (TelegramError, requests.exceptions.RequestException):
            telegram.send_message(text, chat_id=chat_id)

    if action == "sig":
        d = _SIGNAL_DRAFTS.get(key) or _lab_signal_draft(key)
        if not d or time.time() - d["at"] > 3600:
            telegram.send_message("⌛ Сигнал устарел — запроси /aiidea заново.", chat_id=chat_id)
            return
        try:
            px = get_last_price(d["symbol"])
        except Exception:  # noqa: BLE001
            px = d["entry"]
        sl_pct = round(abs(px - d["sl"]) / px * 100, 2)
        trail = d.get("tp") is None               # сборка с трейлинг-выходом (без тейка)
        tp_pct = None if trail else round(abs(d["tp"] - px) / px * 100, 2)
        moved = ((d["side"] == "LONG" and (px <= d["sl"] or (not trail and px >= d["tp"])))
                 or (d["side"] == "SHORT" and (px >= d["sl"] or (not trail and px <= d["tp"]))))
        if moved:
            telegram.send_message(f"⌛ Цена {_fmt_price(px)} уже за стопом или тейком сигнала — вход не актуален.",
                                  chat_id=chat_id)
            return
        usdt = parts[3] if len(parts) > 3 else MANUAL_DEFAULT_USDT
        _send_trade_preview(telegram, chat_id, {"symbol": d["symbol"], "side": d["side"], "usdt": usdt,
                                                "leverage": int(d.get("leverage") or 3), "sl_pct": max(sl_pct, 0.2), "tp_pct": tp_pct,
                                                "trail_pct": min(max(sl_pct, 0.2), 10) if trail else None}, settings,
                            note="уровни сигнала пересчитаны от текущей цены", timeframe=d["tf"])
        return

    pend = _PENDING_TRADES.pop(key, None)
    if action == "tr":
        # 2026-09-26: трейлинг одной кнопкой в превью (в т.ч. «Открыть сделку»
        # под /aiidea и /aipick). Расстояние = стоп сделки (1R), включается
        # при прибыли = стопу -- та же логика, что в терминале.
        if not pend or time.time() - pend["at"] > 120:
            _caption("⌛ Превью устарело (больше 2 минут) — отправь команду ещё раз.")
            return
        pr = dict(pend["params"])
        pr["trail_pct"] = None if pr.get("trail_pct") else min(max(float(pr["sl_pct"]), 0.2), 10)
        _caption("↗️ Трейлинг добавлен — новое превью ниже." if pr["trail_pct"] else "Трейлинг убран — новое превью ниже.")
        _send_trade_preview(telegram, chat_id, pr, settings)
        return
    if action == "no":
        _caption("✖ Отменено.")
        return
    if action != "ok":
        return
    if not pend or time.time() - pend["at"] > 120:
        _caption("⌛ Превью устарело (больше 2 минут) — отправь команду ещё раз.")
        return
    _caption("⏳ Отправляю ордер на Bybit…")

    def _worker() -> None:
        pr = pend["params"]
        try:
            p = manual_trade.prepare(pr["symbol"], pr["side"], pr["usdt"], pr["leverage"], pr["sl_pct"],
                                     pr.get("tp_pct"), pr.get("trail_pct"), settings)
            r = manual_trade.execute(p, source="Telegram", settings=settings)
            _caption(f"✅ Открыто: {r['symbol']} {r['side']} {r['qty']:g} · стоп {_fmt_price(r['stop_loss'])}"
                     + (f" · тейк {_fmt_price(r['take_profit'])}" if r["take_profit"] else "")
                     + (f"\n{r['trailing_note']}" if r.get("trailing_note") else ""))
        except manual_trade.ManualTradeError as exc:
            _caption(f"⛔ Не открыто: {html_lib.escape(exc.message)}")
        except Exception as exc:  # noqa: BLE001
            _caption(f"⚠️ Ошибка — проверь позиции на Bybit вручную: {html_lib.escape(str(exc))}")

    threading.Thread(target=_worker, name="mtrade", daemon=True).start()


def _handle_signals_command(telegram: TelegramClient, chat_id: str, text: str) -> None:
    """/signals — точность сигналов /aiidea и /aipick по журналу."""
    rows = signal_journal.all_rows()
    st = signal_journal.stats(rows)
    t = st["total"]
    if not rows:
        telegram.send_message("🎯 Сигналов в журнале пока нет. Они записываются сами после "
                              "/aiidea и /aipick, если есть направление (LONG/SHORT).", chat_id=chat_id)
        return

    def line(name, a):
        hr = f"{a['hit_rate']:.0f}%" if a["hit_rate"] is not None else "—"
        ar = f"{a['avg_r']:+.2f}R" if a["avg_r"] is not None else "—"
        return (f"{name}: {a['n']} · тейк {a['tp']} · стоп {a['sl']} · истёк {a['expired']} · "
                f"точность <b>{hr}</b> · в среднем {ar} · сумма {a['sum_pct']:+.1f}%")

    out = [f"🎯 <b>Точность сигналов</b> · закрыто {t['n']}, ждут исхода {st['open']}"]
    if t["n"]:
        out.append(line("Всего", t))
        for src, a in st["by_source"].items():
            out.append(line("/" + src, a))
        best = sorted(st["by_symbol"].items(), key=lambda kv: -kv[1]["n"])[:6]
        if best:
            out.append("")
            out.append("<b>По монетам</b>")
            out += [line(sym.replace("USDT", ""), a) for sym, a in best]
    last = [r for r in rows if r["status"] != "open"][-8:]
    if last:
        out += ["", "<b>Последние</b>"]
        icon = {"tp": "✅", "sl": "❌", "expired": "⌛"}
        for r in reversed(last):
            out.append(f"{icon.get(r['status'], '•')} {r['symbol'].replace('USDT', '')} "
                       f"{signal_journal.tf_label(r['tf'])} {r['side']} /{r['source']}{(' ' + r['note']) if r.get('note') else ''}"
                       f" · {r['pnl_pct']:+.2f}% ({r['r']:+.1f}R)")
    opened = [r for r in rows if r["status"] == "open"][-6:]
    if opened:
        out += ["", "<b>Ждут исхода</b>"]
        for r in opened:
            out.append(f"⏳ {r['symbol'].replace('USDT', '')} {signal_journal.tf_label(r['tf'])} {r['side']} "
                       f"/{r['source']} · вход {_fmt_price(r['entry'])} · TP {_fmt_price(r['tp'])} · SL {_fmt_price(r['sl'])}")
    out.append("")
    out.append("<i>Точность = тейки / (тейки + стопы). Если свеча задела и тейк, и стоп — считается стоп. "
               "Итог в % — уже за вычетом комиссии и проскальзывания (0.15% на сделку).</i>")
    telegram.send_message("\n".join(out), chat_id=chat_id)


SIGNAL_TRACK_SECONDS = 300


def _signal_tracker_worker(settings: Settings) -> None:
    """Раз в 5 минут проверяет открытые сигналы журнала по свечам Bybit и
    сообщает, чем закончились (если «Итоги сигналов» не выключены в /notify)."""
    telegram = TelegramClient(settings.telegram_token, settings.telegram_chat_id)
    icon = {"tp": "✅ Тейк", "sl": "❌ Стоп", "expired": "⌛ Истёк срок"}
    while True:
        try:
            for r in signal_journal.check_open():
                print(f"[SIGNALS] {r['symbol']} {r['side']} /{r['source']} -> {r['status']} {r['pnl_pct']:+.2f}%")
                if not notify_prefs.is_enabled("signal_results"):
                    continue
                _safe_send(telegram,
                           f"{icon.get(r['status'], r['status'])} · <b>{r['symbol']}</b> "
                           f"{signal_journal.tf_label(r['tf'])} {r['side']} (/{r['source']}"
                           f"{(' ' + r['note']) if r.get('note') else ''})\n"
                           f"Вход {_fmt_price(r['entry'])} → {_fmt_price(r['exit'])} · "
                           f"<b>{r['pnl_pct']:+.2f}%</b> ({r['r']:+.1f}R)\n<i>Точность всех сигналов — /signals</i>",
                           settings.telegram_chat_id)
        except Exception:
            print("[SIGNALS] tracker pass failed", file=sys.stderr)
            traceback.print_exc()
        time.sleep(SIGNAL_TRACK_SECONDS)


def _try_delete_message(telegram: TelegramClient, chat_id: str, message_id: int | None) -> None:
    """Best-effort cleanup (2026-08-23) so a guest's typed invite code (or,
    2026-08-23 round 5, a /setkey command carrying a real exchange secret)
    doesn't sit around in the chat afterward, right or wrong. Failure is
    logged, never raised -- purely tidiness, not something the actual
    access logic depends on.

    2026-08-23, round 5 follow-up: this previously only caught
    TelegramError (an explicit "ok": false from Telegram) and logged
    nothing on success, which made a live failure invisible -- a bad
    deleteMessage call could silently do nothing and there'd be no trace
    in the log pointing at it. Now also catches
    requests.exceptions.RequestException (matching the pattern already
    used elsewhere in this file for network-level failures) and logs a
    clear success line too, so the console makes it obvious either way
    instead of failing silently."""
    if message_id is None:
        return
    try:
        telegram.delete_message(chat_id, message_id)
        print(f"[ACCESS] deleted message {message_id} in chat {chat_id}")
    except (TelegramError, requests.exceptions.RequestException) as exc:
        print(f"[ACCESS] couldn't delete message {message_id} in chat {chat_id}: {exc}", file=sys.stderr)


def _handle_setkey_command(telegram: TelegramClient, chat_id: str, text: str) -> None:
    """/setkey <exchange> <api_key> <api_secret> [<passphrase>] -- adds or
    updates one exchange's credentials live (2026-08-23, round 5), via
    app/exchange_keys_store.py, without touching .env or restarting the
    bot. The Mini App's Settings tab builds this exact command and opens
    a pre-filled chat with it for the owner to review and send -- see
    _handle_access_message for why a deep link is the only realistic way
    to get the form's values here (menu-button Mini Apps can't
    WebApp.sendData()). Split out of _handle_access_message so the
    parsing/validation isn't buried in that already-long function, and so
    the caller can unconditionally delete the message afterward
    regardless of outcome (the secret shouldn't linger in chat history
    either way)."""
    parts = text.split()
    if len(parts) not in (4, 5):
        telegram.send_message(
            "Формат: <code>/setkey биржа api_key api_secret [passphrase]</code>\n"
            "Проще добавить через вкладку «Настройки» в Mini App -- она сама соберёт команду.",
            chat_id=chat_id,
        )
        return

    exch_key = parts[1].strip().lower()
    module = EXCHANGE_REGISTRY.get(exch_key)
    if module is None:
        known = ", ".join(EXCHANGE_REGISTRY.keys())
        telegram.send_message(f"Неизвестная биржа «{parts[1]}». Доступные: {known}.", chat_id=chat_id)
        return

    api_key, api_secret = parts[2], parts[3]
    passphrase = parts[4] if len(parts) == 5 else None
    if module.REQUIRES_PASSPHRASE and not passphrase:
        telegram.send_message(
            f"{module.DISPLAY_NAME} требует passphrase третьим значением: "
            f"<code>/setkey {exch_key} api_key api_secret passphrase</code>",
            chat_id=chat_id,
        )
        return

    ExchangeKeysStore(EXCHANGE_KEYS_FILE).set_key(exch_key, api_key, api_secret, passphrase)
    telegram.send_message(
        f"✅ Ключ для {module.DISPLAY_NAME} сохранён. Вкладка «Здоровье» подхватит его в течение "
        f"{HEALTH_PUBLISH_INTERVAL_SECONDS // 60} мин (без перезапуска бота).",
        chat_id=chat_id,
    )
    print(f"[ACCESS] owner added/updated exchange key: {exch_key}")


# Alias -> canonical strategy id for /tradekey's per-strategy form, same
# pattern (and same aliases) as _MAXDEALS_BOTS above -- kept as a separate
# dict here (rather than reusing _MAXDEALS_BOTS directly) because that one
# maps to (label, max-deals-file-path) pairs, not a bare canonical id, and
# /tradekey needs the id itself to call TradeKeysStore.*_for_strategy().
_TRADEKEY_STRATEGY_ALIASES = {
    "latuserge": "latuserge",
    "ls15": "latuserge",
    "long_strategy15": "latuserge",
    "kcroc": "kc_roc",
    "kc_roc": "kc_roc",
    "kc": "kc_roc",
    "comboxrp": "combo_xrp",   # 2026-10-17: Combo OTM XRP · OKX (combo_xrp_live.py)
    "combo_xrp": "combo_xrp",
    "grid": "kc_roc",
}
_TRADEKEY_STRATEGY_LABELS = {
    "latuserge": "Latuserge (LONG_STRATEGY 15)",
    "kc_roc": "KC/ROC/CCI/WT грид",
    "combo_xrp": "Combo OTM XRP · OKX",
}


def _handle_tradekey_command(telegram: TelegramClient, chat_id: str, text: str) -> None:
    """/tradekey <exchange> <api_key> <api_secret> [<passphrase>] -- sets the
    SHARED/DEFAULT trading key, used by any strategy that has no dedicated
    key of its own. This is the original 2026-08-23 round-8 behaviour and
    stays unchanged: the trading-permission counterpart to /setkey above,
    deliberately a SEPARATE command/store (app/trade_keys_store.py) rather
    than reusing /setkey's exchange_keys.json -- that store's own docs
    promise its keys are read-only; a key saved here needs Trade/Orders
    rights on the exchange (NOT withdrawal/transfer) since
    _handle_trade_command uses it to place real orders.

    /tradekey <latuserge|kcroc> <exchange> <api_key> <api_secret> [<passphrase>]
    -- 2026-09-06 addition: sets a DEDICATED key for just that one strategy
    (aliases mirror _MAXDEALS_BOTS/_TRADEKEY_STRATEGY_ALIASES above),
    overriding the shared default for that strategy only -- see
    app/trade_keys_store.py's module docstring for the full rationale
    (separate accounts/risk buckets per live bot). Detected by checking
    whether the token right after /tradekey is a known strategy alias
    (exchange names never collide with these aliases); once recognised,
    that token is dropped and the rest of this function's parsing is
    byte-for-byte identical to the shared-key path, just routed to
    set_key_for_strategy() instead of set_key() at the end.

    /tradekey with no arguments -- shows which strategies currently have a
    dedicated key vs. fall back to the shared default. Never echoes an
    actual secret back into the chat, only which exchange(s) are configured.
    """
    parts = text.split()

    if len(parts) == 1:
        store = TradeKeysStore(TRADE_KEYS_FILE)
        shared = store.get_all()
        lines = ["Торговые ключи сейчас:"]
        if shared:
            lines.append(f"• Общий ключ по умолчанию: задан для {', '.join(sorted(shared.keys()))}.")
        else:
            lines.append("• Общий ключ по умолчанию: не задан.")
        for strat_id, label in _TRADEKEY_STRATEGY_LABELS.items():
            dedicated = store.get_all_for_strategy(strat_id)
            if dedicated:
                lines.append(f"• {label}: свой ключ ({', '.join(sorted(dedicated.keys()))}).")
            else:
                lines.append(f"• {label}: свой ключ не задан -- использует общий по умолчанию.")
        lines.append("")
        lines.append(
            "Задать общий: <code>/tradekey биржа api_key api_secret [passphrase]</code>\n"
            "Задать только для стратегии: <code>/tradekey latuserge биржа api_key api_secret [passphrase]</code> "
            "или <code>/tradekey kcroc биржа api_key api_secret [passphrase]</code>."
        )
        telegram.send_message("\n".join(lines), chat_id=chat_id)
        return

    strategy_id = None
    first_arg = parts[1].strip().lower()
    if first_arg in _TRADEKEY_STRATEGY_ALIASES:
        strategy_id = _TRADEKEY_STRATEGY_ALIASES[first_arg]
        parts = parts[:1] + parts[2:]  # drop the strategy token; reuse the shared-key parsing below unchanged

    if len(parts) not in (4, 5):
        telegram.send_message(
            "Формат: <code>/tradekey биржа api_key api_secret [passphrase]</code> -- общий ключ по умолчанию\n"
            "или <code>/tradekey &lt;latuserge|kcroc|comboxrp&gt; биржа api_key api_secret [passphrase]</code> -- "
            "отдельный ключ только для этой стратегии.\n"
            "Это ОТДЕЛЬНЫЙ ключ от /setkey -- нужен с правами Trade/Orders (НЕ read-only, "
            "и НЕ withdrawal/transfer). Проще добавить через вкладку «Торговля» в Mini App.",
            chat_id=chat_id,
        )
        return

    exch_key = parts[1].strip().lower()
    module = EXCHANGE_REGISTRY.get(exch_key)
    if module is None or not hasattr(module, "place_order"):
        available = [k for k, m in EXCHANGE_REGISTRY.items() if hasattr(m, "place_order")]
        telegram.send_message(
            f"Реальная торговля пока поддерживается только для: {', '.join(available) or '(пока ни для одной биржи)'}.",
            chat_id=chat_id,
        )
        return

    api_key, api_secret = parts[2], parts[3]
    passphrase = parts[4] if len(parts) == 5 else None
    if module.REQUIRES_PASSPHRASE and not passphrase:
        telegram.send_message(
            f"{module.DISPLAY_NAME} требует passphrase третьим значением: "
            f"<code>/tradekey {exch_key} api_key api_secret passphrase</code>",
            chat_id=chat_id,
        )
        return

    store = TradeKeysStore(TRADE_KEYS_FILE)
    if strategy_id is not None:
        store.set_key_for_strategy(strategy_id, exch_key, api_key, api_secret, passphrase)
        label = _TRADEKEY_STRATEGY_LABELS[strategy_id]
        telegram.send_message(
            f"✅ Отдельный торговый ключ для {label} ({module.DISPLAY_NAME}) сохранён. Подхватится этим ботом "
            f"без перезапуска. Убедись, что на бирже у этого ключа НЕТ прав на вывод/перевод средств.",
            chat_id=chat_id,
        )
        print(f"[ACCESS] owner added/updated TRADE key for strategy={strategy_id}: {exch_key}")
    else:
        store.set_key(exch_key, api_key, api_secret, passphrase)
        telegram.send_message(
            f"✅ Общий торговый ключ для {module.DISPLAY_NAME} сохранён (его используют все стратегии без "
            f"своего отдельного ключа). Команда <code>/trade</code> подхватит его сразу, без перезапуска бота. "
            f"Убедись, что на бирже у этого ключа НЕТ прав на вывод/перевод средств.",
            chat_id=chat_id,
        )
        print(f"[ACCESS] owner added/updated shared TRADE key: {exch_key}")


def _handle_trade_command(telegram: TelegramClient, chat_id: str, text: str,
                           settings: Settings, state: StateStore) -> None:
    """/trade <exchange> <symbol> <buy|sell> <qty> <leverage> <stop_loss>
    [<take_profit>] [gate] [entry=<price>] -- 2026-08-23, round 8: places a
    REAL order with a mandatory stop-loss. The optional trailing "gate"
    token (case-insensitive) requires an active, direction-matching,
    recent signal (see app/state.py's latest_active_signal) before the
    order is allowed -- this is the "торговать только по сигналу" toggle
    from the Mini App's Торговля tab; omitting it places the order
    unconditionally (still subject to every OTHER guard below, which are
    never optional).

    2026-08-25, round 14: this function is now just command-text parsing
    + formatting a Telegram reply -- every guard and the actual exchange
    call moved into app/trade_executor.execute_trade(), which the new
    local trade-server (app/trade_server.py) ALSO calls for its instant,
    no-chat execution path. Splitting it out means those two entry points
    can never quietly diverge on what they allow; this function's
    observable behavior (exact same messages, same guard order) is
    unchanged from before the split.

    2026-08-25, round 16: added the optional trailing "entry=<price>"
    token (case-insensitive, may appear before or after "gate" in either
    order) -- when given, places a GTC Limit order at that price instead
    of a Market order at the live price. Omitting it keeps the exact
    original Market-order behavior. There is currently no /cancel command
    for a still-pending limit order -- cancel it directly on the exchange
    if it doesn't fill."""
    parts = text.split()
    gate_requested = False
    entry_price: float | None = None
    while parts:
        tail = parts[-1].strip()
        if tail.lower() == "gate":
            gate_requested = True
            parts = parts[:-1]
            continue
        if tail.lower().startswith("entry="):
            try:
                entry_price = float(tail.split("=", 1)[1])
            except ValueError:
                telegram.send_message("Цена входа (entry=...) должна быть числом.", chat_id=chat_id)
                return
            parts = parts[:-1]
            continue
        break

    if len(parts) not in (7, 8):
        telegram.send_message(
            "Формат: <code>/trade биржа символ buy|sell объём плечо stop_loss [take_profit] [gate] [entry=цена]</code>\n"
            "Например: <code>/trade bybit BTCUSDT buy 0.001 5 61500 64000</code>\n"
            "Добавь <code>gate</code> в конец, чтобы разрешить сделку только при активном сигнале.\n"
            "Добавь <code>entry=63000</code>, чтобы выставить лимитный ордер по конкретной цене вместо рыночного.\n"
            "Проще открыть через вкладку «Торговля» в Mini App -- она сама соберёт команду.",
            chat_id=chat_id,
        )
        return

    exch_key = parts[1].strip().lower()
    symbol = parts[2].strip().upper()
    side = parts[3].strip().lower()
    if side not in ("buy", "sell"):
        telegram.send_message("Направление должно быть <code>buy</code> (лонг) или <code>sell</code> (шорт).", chat_id=chat_id)
        return

    try:
        qty = float(parts[4])
        leverage = int(float(parts[5]))
        stop_loss = float(parts[6])
        take_profit = float(parts[7]) if len(parts) == 8 else None
    except ValueError:
        telegram.send_message("Объём/плечо/stop_loss/take_profit должны быть числами.", chat_id=chat_id)
        return

    try:   # 2026-11-02: режим «только по сигналу» действует и для команды /trade
        from windows_app import challenge_guard as _cg  # noqa: PLC0415
        _ok, _why = _cg.allow(symbol, side)
        if not _ok:
            telegram.send_message(_why, chat_id=chat_id)
            return
    except Exception as _exc:  # noqa: BLE001
        print(f"[TRADE] guard: {_exc}", file=sys.stderr)
    result = execute_trade(exch_key, symbol, side, qty, leverage, stop_loss, take_profit,
                            gate_requested, settings, state, entry_price=entry_price)
    if result.get("ok"):
        try:
            _cg.record_be(symbol, side)
        except Exception:  # noqa: BLE001
            pass

    if not result["ok"]:
        telegram.send_message(f"⛔ {result['reason']}", chat_id=chat_id)
        return

    direction_ru = "ЛОНГ" if result["side"] == "buy" else "ШОРТ"
    order_kind = (f"лимитный ордер по цене {result['entry_price']:g}" if result.get("entry_price") is not None
                  else "ордер по рынку")
    telegram.send_message(
        f"✅ Отправлен {order_kind}: {result['symbol']} {direction_ru}, объём {result['qty']:g}, "
        f"плечо {result['leverage']}x, SL {result['stop_loss']:g}"
        + (f", TP {result['take_profit']:g}" if result.get("take_profit") else "") + ".\n"
        f"ID ордера: <code>{result.get('order_id')}</code>. Проверь на {result['exchange_display']}."
        + ("\n(Лимитный ордер может не исполниться сразу или вообще -- отменить его пока можно "
           "только вручную на бирже.)" if result.get("entry_price") is not None else ""),
        chat_id=chat_id,
    )


def _handle_report_command(telegram: TelegramClient, chat_id: str, settings: Settings) -> None:
    """/report -- 2026-08-23, round 9 ("Вера" trading-assistant features):
    an on-demand digest of the SAME numbers already computed for the
    Здоровье tab (publish_health.build_health()), pushed straight to the
    chat instead of only being visible if the owner happens to open the
    Mini App. Read-only, no exchange writes -- safe to run as often as
    wanted."""
    try:
        health = publish_health.build_health(settings, journal_path=LIVE_JOURNAL_FILE, recent_n=10)
    except Exception as exc:
        telegram.send_message(f"Не удалось посчитать отчёт: {exc}", chat_id=chat_id)
        return

    lines = ["📊 <b>Отчёт по торговле</b>"]
    for key, h in health.get("sources", {}).items():
        name = h.get("display_name", key)
        lines.append(f"\n<b>{name}</b> -- {h.get('state_label', '?')}")
        if not h.get("trades_total"):
            lines.append(h.get("note") or "Нет закрытых сделок за этот период.")
        else:
            wr = h.get("win_rate_pct")
            lines.append(f"Сделок: {h['trades_total']}, винрейт: {wr}%" if wr is not None else f"Сделок: {h['trades_total']}")
            lines.append(f"Серия убытков: {h.get('losing_streak', 0)}")
        # 2026-09-06: the two new live-bot sources (see publish_health.py's
        # compute_health_from_live_bot_logs()) always report a 0 risk
        # budget in USDT -- they log %-P&L per deal, not a dollar figure,
        # so there's nothing real to show here. Skipping these two lines
        # when the budget is 0 avoids a noisy "риск 0% от 0 USDT" under
        # every DCA-bot section; unaffected for exchange/journal sources,
        # which only ever hit 0 if the user genuinely configured no budget.
        if h.get("risk_budget_usdt"):
            lines.append(f"Риск за неделю: {h.get('risk_used_pct', 0)}% от {h.get('risk_budget_usdt', 0):g} USDT")
        if h.get("daily_risk_limit_usdt"):
            lines.append(f"Риск за сегодня: {h.get('daily_risk_used_pct', 0)}% от {h.get('daily_risk_limit_usdt', 0):g} USDT")
        open_positions = h.get("open_positions") or []
        if open_positions:
            lines.append(f"Открытых позиций: {len(open_positions)}")
            for pos in open_positions:
                upnl = pos.get("unrealized_pnl")
                lines.append(f"  {pos.get('symbol')} {pos.get('side')}: PnL {upnl:+.2f} USDT" if upnl is not None
                             else f"  {pos.get('symbol')} {pos.get('side')}")
                # 2026-08-24, round 13: stop_loss/take_profit have been in
                # open_positions since round 9 (see app/exchanges/base.py's
                # OPEN_POSITION_COLUMNS docstring), but were only ever read
                # internally by the breakeven-autopilot -- never actually
                # shown to the owner anywhere. Surfacing them here too now.
                sl, tp = pos.get("stop_loss"), pos.get("take_profit")
                if sl is not None or tp is not None:
                    sl_txt = f"{sl:g}" if sl is not None else "не задан"
                    tp_txt = f"{tp:g}" if tp is not None else "не задан"
                    lines.append(f"    Стоп: {sl_txt}, Тейк: {tp_txt}")
    if health.get("exchanges_failed"):
        lines.append(f"\n⚠️ Не удалось обновить: {', '.join(health['exchanges_failed'])}")

    report_text = "\n".join(lines)

    # 2026-08-24, round 10: optional AI paragraph on top of the SAME
    # numbers above -- only attempted if a key is configured (via
    # /setaikey or ANTHROPIC_API_KEY), so someone who never sets one up
    # sees exactly the same /report as before round 10, no nagging. If a
    # key IS configured but the call itself fails (network/API error),
    # explain_report returns None and a short one-line note is added
    # instead of silently pretending nothing was supposed to happen.
    if resolve_api_key(settings):
        explanation = explain_report(report_text, settings)
        if explanation:
            report_text += "\n\n🧠 <b>Пояснение (ИИ):</b>\n" + _ai_escape(explanation)
        else:
            report_text += "\n\n⚠️ Пояснение от ИИ сейчас недоступно (проверь ключ или попробуй позже)."

    telegram.send_message(report_text, chat_id=chat_id)


# 2026-08-29: real live bug -- Telegram's sendMessage rejects anything
# over ~4096 chars with a plain "Bad Request: message is too long", and
# that failure was silent from the owner's side (only logged to stderr).
# /ideas hit this once the scan universe grew to top-100 and dozens of
# zones got armed at once. Any handler building a message from a
# variable-length list (zone digests, AI text, etc.) should run its final
# text through this before calling send_message, not just cap the list
# up front -- an appended AI paragraph can push a message over the limit
# even when the list itself was kept short.
TELEGRAM_MESSAGE_SAFE_LIMIT = 4000  # real cap is 4096; small margin for safety


def _truncate_for_telegram(text: str, limit: int = TELEGRAM_MESSAGE_SAFE_LIMIT) -> str:
    """Cuts at the last newline before `limit` so a line is never chopped
    mid-word, and always says so explicitly rather than silently dropping
    the tail. Returns `text` unchanged if it already fits."""
    if len(text) <= limit:
        return text
    cut = text.rfind("\n", 0, limit)
    if cut <= 0:
        cut = limit
    return text[:cut] + "\n\n… (сообщение обрезано, было слишком длинным для Telegram)"


def _handle_autopilot_command(telegram: TelegramClient, chat_id: str, text: str, settings: Settings) -> None:
    """/autopilot [on|off] -- 2026-08-23, round 9: live on/off switch for
    the breakeven-autopilot loop (see app/autopilot.py + _autopilot_worker
    below). No argument = report current status. Owner-only, checked by
    the caller (_handle_access_message) same as every other command here.

    This is the single highest-stakes toggle in this whole project: turning
    it on lets the bot amend a live stop-loss on the exchange with NO
    per-action confirmation from here on (unlike /trade, which always
    waits for a reviewed Send). Default is OFF (see
    app/autopilot_settings.py) -- this command is the ONLY way to turn it
    on, there's no .env flag for it.

    `settings` is only used to read autopilot_breakeven_trigger_r for the
    status message below -- the on/off toggle itself doesn't touch
    Settings at all (it's the JSON-file AutopilotSettings)."""
    autopilot = AutopilotSettings(AUTOPILOT_SETTINGS_FILE)
    parts = text.split()
    arg = parts[1].strip().lower() if len(parts) > 1 else None

    tradeable = [k for k, m in EXCHANGE_REGISTRY.items() if hasattr(m, "amend_stop_loss")]

    if arg == "trail":
        sub = parts[2].strip().lower() if len(parts) > 2 else None
        if sub not in ("on", "off"):
            telegram.send_message("Формат: <code>/autopilot trail on</code> или <code>/autopilot trail off</code>.",
                                  chat_id=chat_id)
            return
        autopilot.set_trail(sub == "on")
        if sub == "on":
            telegram.send_message(
                "↗️ Трейлинг автопилота ВКЛЮЧЁН. Когда бот переносит стоп в безубыток (+"
                f"{settings.autopilot_breakeven_trigger_r:.1f}R), он сразу ставит на Bybit трейлинг-стоп на "
                "расстоянии 1R от цены: стоп дальше сам идёт за ценой и только в сторону прибыли. "
                "Трейлинг живёт на бирже и работает даже при выключенном компьютере."
                + ("" if autopilot.is_enabled() else "\n⚠️ Сам автопилот сейчас выключен — включи: /autopilot on"),
                chat_id=chat_id)
        else:
            telegram.send_message("Трейлинг автопилота выключен: стоп будет только переноситься в безубыток. "
                                  "Уже поставленные трейлинги на бирже остаются.", chat_id=chat_id)
        return

    if arg not in (None, "on", "off"):
        telegram.send_message("Формат: <code>/autopilot</code>, <code>/autopilot on|off</code>, "
                              "<code>/autopilot trail on|off</code>.", chat_id=chat_id)
        return

    if arg is None:
        status = "включён 🟢" if autopilot.is_enabled() else "выключен 🔴"
        status += (" · трейлинг после безубытка: ВКЛ ↗️" if autopilot.is_trail()
                   else " · трейлинг после безубытка: выкл")
        telegram.send_message(
            f"Автопилот безубытка: {status}.\n"
            f"Поддерживается для: {', '.join(tradeable) or '(пока ни для одной биржи)'} "
            f"(нужен торговый ключ через /tradekey).\n"
            f"Правило: как только цена ушла в прибыль на {settings.autopilot_breakeven_trigger_r:.1f}R и больше "
            f"от твоего стопа, бот САМ переставит стоп в безубыток (без подтверждения) и пришлёт сообщение об "
            f"этом.\n"
            f"Совет (НЕ автоматически): с {settings.autopilot_partial_take_trigger_r:.1f}R бот также предложит "
            f"подумать о частичной фиксации прибыли -- решение и действие всегда твои.\n"
            f"Включить: <code>/autopilot on</code>. Выключить: <code>/autopilot off</code>.",
            chat_id=chat_id,
            # 2026-08-26, round 17: an inline keyboard alongside the status
            # text -- tapping either button fires a callback_query handled
            # by _handle_autopilot_callback, which just calls THIS SAME
            # function again with a synthetic "/autopilot on"/"off" text, so
            # the toggle logic below is never duplicated for the button path.
            reply_markup=_autopilot_menu_keyboard(),
        )
        return

    autopilot.set_enabled(arg == "on")
    if arg == "on":
        telegram.send_message(
            f"🟢 Автопилот безубытка ВКЛЮЧЁН. С этого момента бот будет САМ (без запроса подтверждения) "
            f"переставлять стоп-лосс в безубыток на открытых позициях, как только прибыль достигнет "
            f"настроенного порога (по умолчанию +{settings.autopilot_breakeven_trigger_r:.1f}R). Каждое такое "
            f"действие пришлёт сюда сообщение. Частичная фиксация прибыли остаётся только советом в чат -- "
            f"бот её не делает сам. Выключить в любой момент: /autopilot off.",
            chat_id=chat_id,
        )
    else:
        telegram.send_message("🔴 Автопилот безубытка ВЫКЛЮЧЕН. Стопы теперь не переставляются автоматически.",
                               chat_id=chat_id)


# 2026-09-06, user request: live control over how many deals
# long_strategy15_latuserge_live.py / kc_roc_cci_wt_grid_live.py may hold
# open at once across their whole watchlist -- was CLI-only
# (--max-concurrent-deals, default 2 on both, baked in at process start)
# before this, so changing it meant stopping and restarting that live
# bot. Each live bot now re-reads its own settings file every poll cycle
# (see app/live_bot_settings.py), so this command's only job is to write
# to that same file -- the live bot itself picks the change up on its own,
# nothing here talks to that process directly (same "own JSON file,
# no restart, no IPC" pattern as /autopilot on|off and /scan above).
_MAXDEALS_BOTS = {
    "latuserge": ("Latuserge (LONG_STRATEGY 15)", LATUSERGE_MAX_DEALS_FILE),
    "ls15": ("Latuserge (LONG_STRATEGY 15)", LATUSERGE_MAX_DEALS_FILE),
    "long_strategy15": ("Latuserge (LONG_STRATEGY 15)", LATUSERGE_MAX_DEALS_FILE),
    "kcroc": ("KC/ROC/CCI/WT грид", KC_GRID_MAX_DEALS_FILE),
    "kc_roc": ("KC/ROC/CCI/WT грид", KC_GRID_MAX_DEALS_FILE),
    "kc": ("KC/ROC/CCI/WT грид", KC_GRID_MAX_DEALS_FILE),
    "grid": ("KC/ROC/CCI/WT грид", KC_GRID_MAX_DEALS_FILE),
}
_MAXDEALS_DEFAULT = 2  # matches both live scripts' own --max-concurrent-deals default


def _handle_maxdeals_command(telegram: TelegramClient, chat_id: str, text: str) -> None:
    """/maxdeals -- show current cap for both live bots.
    /maxdeals <latuserge|kcroc> <N> -- set one bot's cap (0 = без ограничения).

    Only writes a JSON settings file; does not touch a running process. If
    the target bot isn't running right now, this just seeds/updates the file
    for whenever it's next started (both live scripts also seed this same
    file with their own --max-concurrent-deals CLI value on first run, so
    the file always reflects a real, non-fabricated number, never a guess)."""
    parts = text.split()

    if len(parts) == 1:
        lines = ["Лимит одновременных сделок сейчас:"]
        # _MAXDEALS_BOTS has several aliases pointing at the same (label,
        # path) pair (e.g. "latuserge"/"ls15"/"long_strategy15") -- dedupe
        # by path via dict.fromkeys so each real bot is only listed once,
        # in insertion order (latuserge first, kc_roc second).
        unique_bots = list(dict.fromkeys(_MAXDEALS_BOTS.values()))
        for label, path in unique_bots:
            if path.exists():
                value = MaxConcurrentDealsSettings(path, default=_MAXDEALS_DEFAULT).get()
                value_str = "без ограничения" if value == 0 else str(value)
            else:
                value_str = f"бот ещё не запускался -- дефолт {_MAXDEALS_DEFAULT}"
            lines.append(f"• {label}: {value_str}")
        lines.append("")
        lines.append("Изменить: <code>/maxdeals latuserge 3</code> или <code>/maxdeals kcroc 1</code> "
                      "(0 = снять лимит полностью). Вступает в силу на следующем цикле опроса того бота "
                      "(без перезапуска).")
        telegram.send_message("\n".join(lines), chat_id=chat_id)
        return

    if len(parts) != 3:
        telegram.send_message(
            "Формат: <code>/maxdeals</code> (посмотреть) или "
            "<code>/maxdeals &lt;latuserge|kcroc&gt; &lt;N&gt;</code> (задать, 0 = без лимита).",
            chat_id=chat_id)
        return

    bot_key = parts[1].strip().lower()
    if bot_key not in _MAXDEALS_BOTS:
        telegram.send_message(
            f"Не узнал бота '{parts[1]}'. Варианты: latuserge, kcroc.",
            chat_id=chat_id)
        return

    try:
        value = int(parts[2])
    except ValueError:
        telegram.send_message("Нужно целое число (0 = без лимита).", chat_id=chat_id)
        return
    if value < 0:
        telegram.send_message("Число должно быть 0 или больше.", chat_id=chat_id)
        return

    label, path = _MAXDEALS_BOTS[bot_key]
    MaxConcurrentDealsSettings(path, default=_MAXDEALS_DEFAULT).set(value)
    value_str = "без ограничения" if value == 0 else str(value)
    telegram.send_message(
        f"✅ {label}: лимит одновременных сделок теперь {value_str}. Подхватится тем ботом на "
        f"следующем цикле опроса (обычно в течение минуты), перезапуск не нужен -- если бот сейчас "
        f"не запущен, значение просто сохранено на момент следующего старта.",
        chat_id=chat_id)


def _handle_instanttrade_command(telegram: TelegramClient, chat_id: str, text: str, settings: Settings) -> None:
    """/instanttrade [on|off] -- 2026-08-25, round 14: live kill switch for
    the local trade-server's instant (no chat review) order execution --
    see app/trade_server.py's module docstring for the full picture. This
    is deliberately a SEPARATE toggle from TRADE_SERVER_ENABLED in .env
    (which only controls whether the HTTP server + Cloudflare Tunnel start
    at process launch): this one is checked on EVERY incoming request from
    the Mini App, so turning it off here takes effect on the very next tap
    -- no restart, no waiting for a poll cycle. This is the fastest way to
    shut off instant execution if anything about it ever looks wrong live.

    No argument = report current status (and whether the server/tunnel are
    even running at all, since instant execution needs both this AND
    TRADE_SERVER_ENABLED=true to actually work end-to-end)."""
    instant = InstantTradeSettings(INSTANT_TRADE_SETTINGS_FILE)
    parts = text.split()
    arg = parts[1].strip().lower() if len(parts) > 1 else None

    if arg not in (None, "on", "off"):
        telegram.send_message(
            "Формат: <code>/instanttrade</code>, <code>/instanttrade on</code> или <code>/instanttrade off</code>.",
            chat_id=chat_id,
        )
        return

    if arg is None:
        status = "включено 🟢" if instant.is_enabled() else "выключено 🔴"
        server_status = "запущен (TRADE_SERVER_ENABLED=true)" if settings.trade_server_enabled else \
            "НЕ запущен (TRADE_SERVER_ENABLED не установлен в .env -- этот переключатель ничего не даст, пока сервер не включён)"
        telegram.send_message(
            f"Мгновенное исполнение ордеров (без подтверждения в чате): {status}.\n"
            f"Локальный сервер: {server_status}.\n"
            f"Включить: <code>/instanttrade on</code>. Выключить: <code>/instanttrade off</code>.\n"
            f"⚠️ Во включённом состоянии тап «Отправить ордер» в Mini App сразу открывает РЕАЛЬНУЮ позицию, "
            f"без единого подтверждающего действия здесь -- проверка стоп-лосса, плеча и риск-бюджета по-прежнему "
            f"работает как обычно, пропадает только шаг «нажать Отправить в чате».",
            chat_id=chat_id,
            # 2026-08-26, round 17: same inline-keyboard-on-the-status-message
            # pattern as _handle_autopilot_command above -- see its comment.
            reply_markup=_instanttrade_menu_keyboard(),
        )
        return

    instant.set_enabled(arg == "on")
    if arg == "on":
        telegram.send_message(
            "🟢 Мгновенное исполнение ВКЛЮЧЕНО. С этого момента тап «Отправить ордер» на вкладке «Торговля» "
            "сразу отправит РЕАЛЬНЫЙ ордер на биржу, без захода в этот чат. Все проверки (стоп-лосс обязателен, "
            "плечо, риск-бюджет) продолжают действовать как раньше. Выключить в любой момент: /instanttrade off.",
            chat_id=chat_id,
        )
    else:
        telegram.send_message(
            "🔴 Мгновенное исполнение ВЫКЛЮЧЕНО. Кнопка на вкладке «Торговля» снова только собирает команду "
            "для отправки через чат Telegram.",
            chat_id=chat_id,
        )


def _build_ai_context_bundle(settings: Settings, scan: ScanSettings, state: StateStore) -> str:
    """2026-08-24, round 10: plain-text data bundle for `/ai`'s free-form
    chat -- built from publish_health.build_health(), just reformatted as
    compact plain text instead of an HTML Telegram message. This is model
    input, not something a human reads directly, so it skips the
    emoji/HTML formatting the chat commands use for their own output.

    2026-09-06: the zones/recent-signals paragraph that used to follow
    (fed by the now-removed CHoCH+OB+FVG detector's StateStore lookups)
    was dropped -- state.all_pending_zones()/recent_signals() are
    permanently empty once nothing calls add_zone()/mark_sent() anymore,
    so it would only ever have said "0 zones, 0 signals"."""
    parts: list[str] = []
    try:
        health = publish_health.build_health(settings, journal_path=LIVE_JOURNAL_FILE, recent_n=10)
    except Exception as exc:
        health = None
        parts.append(f"(не удалось посчитать health: {exc})")
    if health:
        for key, h in health.get("sources", {}).items():
            name = h.get("display_name", key)
            parts.append(
                f"Источник {name}: состояние {h.get('state_label', '?')}, сделок {h.get('trades_total', 0)}, "
                f"серия убытков {h.get('losing_streak', 0)}, риск за неделю {h.get('risk_used_pct', 0)}% от "
                f"{h.get('risk_budget_usdt', 0):g} USDT, риск за сегодня {h.get('daily_risk_used_pct', 0)}% от "
                f"{h.get('daily_risk_limit_usdt', 0):g} USDT."
            )
            for pos in h.get("open_positions") or []:
                parts.append(f"  Открытая позиция {pos.get('symbol')} {pos.get('side')}: "
                              f"PnL {pos.get('unrealized_pnl')}.")
        if health.get("exchanges_failed"):
            parts.append(f"Не удалось обновить: {', '.join(health['exchanges_failed'])}.")

    return "\n".join(parts) if parts else "(данных пока нет)"


def _handle_setaikey_command(telegram: TelegramClient, chat_id: str, text: str) -> None:
    """/setaikey <api_key> -- 2026-08-24, round 10: adds/updates the
    Anthropic API key that powers every AI feature, live, via
    app/ai_key_store.py -- mirrors _handle_setkey_command's shape (a
    single value here, no exchange/passphrase to parse). Caller always
    deletes the triggering message afterward, same secret hygiene as
    /setkey/tradekey."""
    parts = text.split()
    if len(parts) != 2:
        telegram.send_message(
            "Формат: <code>/setaikey api_key</code>\n"
            "Ключ можно получить на console.anthropic.com → API Keys (это отдельная, платная по расходу вещь, "
            "не связана с подпиской на Claude).",
            chat_id=chat_id,
        )
        return
    AiKeyStore(AI_KEY_FILE).set_key(parts[1])
    telegram.send_message(
        "✅ Ключ ИИ сохранён, работает сразу (без перезапуска бота). Проверь: <code>/ai привет</code>.",
        chat_id=chat_id,
    )
    print("[ACCESS] owner added/updated AI (Anthropic) key")


def _handle_ai_command(telegram: TelegramClient, chat_id: str, text: str, settings: Settings,
                        scan: ScanSettings, state: StateStore) -> None:
    """/ai <вопрос> -- 2026-08-24, round 10: free-form chat grounded in
    the owner's own data (see app/ai_assistant.answer_question's
    docstring). A separate command from /report and /ideas (not a mode of
    them) so a plain question doesn't need any special syntax."""
    rest = text.split(None, 1)
    question = rest[1].strip() if len(rest) > 1 else ""
    if not question:
        telegram.send_message(
            "Формат: <code>/ai твой вопрос</code>, например "
            "<code>/ai как у меня дела с риском на этой неделе?</code>",
            chat_id=chat_id,
        )
        return
    if not resolve_api_key(settings):
        telegram.send_message(
            "ИИ ещё не настроен. Добавь ключ командой <code>/setaikey sk-ant-...</code> "
            "(получить на console.anthropic.com → API Keys).",
            chat_id=chat_id,
        )
        return

    context_bundle = _build_ai_context_bundle(settings, scan, state)
    try:
        context_bundle += "\n\n" + trader_brain.context()   # 2026-10-05: мозг трейдера
    except Exception as exc:  # noqa: BLE001
        print(f"[BRAIN] context failed: {exc}", file=sys.stderr)
    answer = answer_question(question, context_bundle, settings)
    if not answer:
        telegram.send_message("⚠️ ИИ сейчас недоступен (ошибка запроса). Попробуй ещё раз чуть позже.",
                               chat_id=chat_id)
        return
    telegram.send_message("🧠 " + _ai_escape(answer), chat_id=chat_id)


# Таймфреймы Bybit: то, что человек пишет в команде, -> то, что понимает API.
_TF_ALIASES = {
    "1m": "1", "3m": "3", "5m": "5", "15m": "15", "30m": "30",
    "1h": "60", "2h": "120", "4h": "240", "6h": "360", "12h": "720",
    "1d": "D", "d": "D", "1w": "W", "w": "W", "1M": "M",
}
_TF_LABELS = {
    "1": "1m", "3": "3m", "5": "5m", "15": "15m", "30": "30m",
    "60": "1h", "120": "2h", "240": "4h", "360": "6h", "720": "12h",
    "D": "1D", "W": "1W", "M": "1M",
}


def _normalize_timeframe(raw: str) -> str:
    raw = (raw or "").strip()
    if not raw:
        return "60"
    if raw in _TF_LABELS:
        return raw
    return _TF_ALIASES.get(raw.lower(), _TF_ALIASES.get(raw, "60"))


def _fmt_price(value) -> str:
    """Цены у монет разного масштаба: 77234.5 и 0.4287 нельзя печатать
    одним форматом -- в первом случае лишние нули, во втором пропадёт
    весь смысл числа."""
    if value is None:
        return "—"
    v = float(value)
    av = abs(v)
    if av >= 1000:
        return f"{v:,.2f}".replace(",", " ")
    if av >= 1:
        return f"{v:.4f}".rstrip("0").rstrip(".")
    return f"{v:.6f}".rstrip("0").rstrip(".")


def _format_signal_report(data: dict) -> str:
    """Собирает сообщение из ответа движка. Ничего не додумывает: если поля
    нет, пишет прочерк, а не выдуманное значение."""
    sym = data.get("symbol", "?")
    tf = _TF_LABELS.get(str(data.get("timeframe")), str(data.get("timeframe")))
    conf = data.get("confirmed") or {}
    rt = data.get("realtime") or {}
    votes = data.get("votes") or {}
    bt = data.get("backtest") or {}
    cfg = data.get("config") or {}

    signal = conf.get("signal", "NEUTRAL")
    icon = {"LONG": "🟢", "SHORT": "🔴"}.get(signal, "⚪")
    word = {"LONG": "ЛОНГ", "SHORT": "ШОРТ"}.get(signal, "НЕЙТРАЛЬНО")

    long_v = conf.get("long", 0)
    short_v = conf.get("short", 0)
    neutral_v = conf.get("neutral", 0)
    used = data.get("indicatorsUsed", long_v + short_v + neutral_v)
    score_pct = float(conf.get("score") or 0.0) * 100

    lines = [
        f"{icon} <b>{sym} · ⏱ {tf} — {word}</b>",
        f"Голоса: <b>{long_v}</b> за лонг · <b>{short_v}</b> за шорт · {neutral_v} нейтрально "
        f"(из {used}), перевес {score_pct:+.0f}% при пороге "
        f"{float(cfg.get('threshold', 0.15)) * 100:.0f}%",
        "",
    ]

    if signal == "NEUTRAL":
        lines.append("Перевес голосов меньше порога — уровни не считаю: "
                     "вход без направления это не сделка, а монетка.")
    else:
        entry = conf.get("entry")
        tp = conf.get("tp")
        sl = conf.get("sl")
        risk = abs(float(entry) - float(sl)) if entry and sl else None
        reward = abs(float(tp) - float(entry)) if entry and tp else None
        rr = (reward / risk) if risk else None
        lines += [
            f"Вход:  <code>{_fmt_price(entry)}</code>  (закрытая свеча)",
            f"Тейк:  <code>{_fmt_price(tp)}</code>  ({cfg.get('tpAtr', 2.5)}×ATR)",
            f"Стоп:  <code>{_fmt_price(sl)}</code>  ({cfg.get('slAtr', 1.5)}×ATR)",
            f"ATR(14): {_fmt_price(conf.get('atr'))}" + (f"  ·  R:R ≈ 1:{rr:.1f}" if rr else ""),
        ]

    # 2026-09-26: границы диапазона (max/min за ~300 закрытых свечей) -- тот же
    # способ, что у сторонних групп уровней, чтобы цифры можно было сверить.
    rng = data.get("range") or {}
    if rng.get("high") and rng.get("low"):
        last = conf.get("entry") or (data.get("realtime") or {}).get("entry")
        extra = ""
        if last:
            up = (float(rng["high"]) / float(last) - 1) * 100
            dn = (1 - float(rng["low"]) / float(last)) * 100
            extra = f"  (до верха {up:.2f}% · до низа {dn:.2f}%)"
        lines += ["", f"📏 Диапазон {rng.get('bars', 300)} свечей {tf}: сопротивление <code>{_fmt_price(rng['high'])}</code> · "
                      f"поддержка <code>{_fmt_price(rng['low'])}</code>{extra}"]

    # Кто голосовал -- именно то, что просили: не «сигнал есть», а по каким
    # индикаторам он пришёл.
    def _names(key, limit=12):
        items = votes.get(key) or []
        shown = [v.get("name", v.get("id", "?")) for v in items[:limit]]
        tail = f" и ещё {len(items) - limit}" if len(items) > limit else ""
        return ", ".join(shown) + tail if shown else "—"

    lines += ["", "<b>Кто как проголосовал</b>"]
    if long_v:
        lines.append(f"🟢 За лонг ({long_v}): {_names('long')}")
    if short_v:
        lines.append(f"🔴 За шорт ({short_v}): {_names('short')}")
    if neutral_v:
        lines.append(f"⚪ Молчат ({neutral_v}): {_names('neutral', 8)}")

    # realtime показываем ТОЛЬКО когда он спорит с подтверждённым: иначе это
    # лишняя строка, повторяющая то же самое.
    if rt.get("diverges"):
        rt_word = {"LONG": "лонг", "SHORT": "шорт"}.get(rt.get("signal"), "нейтрально")
        lines += [
            "",
            f"⚠️ Текущая, ещё не закрытая свеча говорит другое: <b>{rt_word}</b> "
            f"({float(rt.get('score') or 0) * 100:+.0f}%). До закрытия свечи это может "
            f"развернуться обратно — уровни выше считаны по закрытой.",
        ]

    # Бэктест этой же связки по той же истории.
    trades = bt.get("trades", 0)
    lines += ["", f"<b>Бэктест этой связки</b> ({data.get('candles', '?')} свечей {tf})"]
    if not trades:
        lines.append("Сделок не набралось — по этой истории связка не дала ни одного входа.")
    else:
        pf = bt.get("profitFactor")
        by = bt.get("byReason") or {}
        lines += [
            f"Сделок: {trades} · winrate {float(bt.get('winRate') or 0):.0f}% · "
            f"итог {float(bt.get('totalPnl') or 0):+.1f}% · средняя {float(bt.get('avgPnl') or 0):+.2f}%",
            f"Profit factor: {pf:.2f}" if isinstance(pf, (int, float)) else "Profit factor: —",
            f"Максимальная просадка: −{float(bt.get('maxDrawdown') or 0):.1f}%",
            f"Выходы: тейк {by.get('TP', 0)} · стоп {by.get('SL', 0)} · по времени {by.get('TIME', 0)}",
        ]
        if float(bt.get("totalPnl") or 0) <= 0:
            lines.append("⚠️ На истории эта связка в минусе. Цифры как есть, без подгонки.")

    lines += [
        "",
        f"<i>Бэктест с комиссией и проскальзыванием ({float(data.get('costPct') or 0.15):.2f}% на сделку). Бэктест — это прошлое, а не обещание. "
        "Решение и ответственность твои.</i>",
    ]
    return "\n".join(lines)


def _tested_coin_reply(telegram, chat_id: str, text: str) -> bool:
    """2026-11-09: /aiidea и /aipick отвечают ПРОВЕРЕННЫМИ стратегиями. Голосование 34 индикаторов отключено:
    тест 3 года, 10 монет — 1h −3369% (PF 0.85, 0/10 монет), 4h −731% (PF 0.93)."""
    try:
        from windows_app import challenge_guard as _cg  # noqa: PLC0415
        parts = (text or "").split()
        sym = (parts[1] if len(parts) > 1 else "").upper()
        if sym and not sym.endswith("USDT"):
            sym += "USDT"
        act = _cg.active_list(60)
        L = [x for x in act if not sym or x["symbol"] == sym]
        V = {"ok": "✅ <b>МОЖНО БРАТЬ</b>", "warn": "🟡 <b>ОСТОРОЖНО</b>", "late": "⚪ <b>НЕ БРАТЬ</b>"}
        NM = {"boost": "BOOST", "wsct": "Турнир", "bybit": "Bybit", "okx": "OKX"}
        head = "ℹ️ Сигналы только по ПРОВЕРЕННЫМ стратегиям (голосование 34 индикаторов отключено — по тесту 3 года в минусе).\n\n"
        if not L:
            msg = head + (f"<b>{sym[:-4]}</b>: сейчас сигнала нет — <b>не входить</b>. Как появится — придёт в тему сигналов."
                          if sym else "Сейчас открытых сигналов нет.")
        else:
            out = []
            for x in L[:8]:
                z = "; ".join(f"{NM.get(k, k)} {v.get('usd', 0):,} $".replace(",", " ") for k, v in (x.get("size") or {}).items()
                              if (k == "okx") == bool(x.get("okx")) and v.get("usd"))
                out.append(f"{V.get(x.get('v'), '')} — {x.get('vt', '')}\n<b>{x['symbol'][:-4]} {'ЛОНГ' if x['side'] == 'LONG' else 'ШОРТ'}</b> · {x.get('name', '')}\n"
                           f"вход {x.get('entry')} · стоп {x.get('sl')} · {'тейк ' + str(x['tp']) if x.get('tp') else 'выход по «ЗАКРОЙ»'}" + (f"\nпозиция: {z}" if z else ""))
            msg = head + "\n\n".join(out)
        try:   # 2026-11-09: «Подбор ИИ» = перебор ПРОВЕРЕННЫХ стратегий на этой монете (strat_pick.json, тест 3 года, обе половины)
            import json as _js  # noqa: PLC0415
            pk = _js.loads((Path(__file__).resolve().parent / "strat_pick.json").read_text(encoding="utf-8"))["coins"]
            if sym and sym in pk:
                rows = [r for r in pk[sym] if r["ok"]][:3]
                msg += f"\n\n🧠 <b>Подбор: лучшие проверенные стратегии на {sym[:-4]}</b> (3 года, плюс в обеих половинах):\n" + (
                    "\n".join(f"{i + 1}. {r['name']} — PF {r['pf']}, {r['n']} сд, итог {r['sum']:+.0f}%, за 180 дн {r['d180']:+.0f}%" for i, r in enumerate(rows))
                    or "ни одна не прошла — по этой монете лучше не торговать")
            elif sym:
                msg += f"\n\n🧠 Подбор: {sym[:-4]} не тестировали (12 монет: BTC ETH SOL XRP DOGE ADA SUI LINK AVAX BNB NEAR HYPE)."
        except Exception:  # noqa: BLE001
            pass
        telegram.send_message(msg, chat_id=chat_id)
    except Exception as exc:  # noqa: BLE001
        telegram.send_message(f"Не удалось получить сигналы: {str(exc)[:150]}", chat_id=chat_id)
    return True


def _handle_aiidea_command(telegram: TelegramClient, chat_id: str, text: str, settings: Settings,
                            state: StateStore) -> None:
    if _tested_coin_reply(telegram, chat_id, text):
        return
    """/aiidea <символ> [таймфрейм] -- сигнал движка VANTORIX по монете.

    2026-09-13, переписано по прямой просьбе владельца: "идея должна выдавать
    сигналы которые мы сейчас тестируем, проводить бэктест и выбирать по каким
    индикаторам приходит сигнал, выдавать стоп тейк и вход".

    Было: свободный текст от языковой модели по краткой сводке OHLCV. Он не
    опирался ни на один индикатор из тех 34, что реально считает терминал и по
    которым копится форвард-тест, и поэтому не мог ни совпасть с «Мозгом», ни
    быть проверен бэктестом. Владелец об этом и сказал ещё в августе -- "толку
    от Веры нет".

    Стало: тот же самый движок, что на экране (см. app/vantorix_signal.py --
    почему через Node, а не через второй порт индикаторов на Python). Ответ
    полностью детерминирован: те же свечи -> тот же вывод, ИИ в этой команде
    больше не участвует и ключ Anthropic ей не нужен.
    """
    parts = text.split()
    if len(parts) < 2:
        telegram.send_message(
            "Формат: <code>/aiidea BTCUSDT</code> или <code>/aiidea BTCUSDT 4h</code>\n"
            "Таймфреймы: 1m, 5m, 15m, 30m, 1h, 4h, 12h, 1d, 1w",
            chat_id=chat_id,
        )
        return

    symbol = parts[1].strip().upper()
    timeframe = _normalize_timeframe(parts[2] if len(parts) > 2 else "")

    telegram.send_message(
        f"⏳ Считаю 34 индикатора и бэктест по {symbol}… это занимает несколько секунд.",
        chat_id=chat_id,
    )

    try:
        data = fetch_signal(symbol, timeframe)
    except SignalError as exc:
        telegram.send_message(f"⚠️ {html_lib.escape(str(exc))}", chat_id=chat_id)
        return
    except Exception as exc:  # noqa: BLE001 -- в чат уходит причина, а не тишина
        telegram.send_message(
            f"⚠️ Не получилось посчитать сигнал: {html_lib.escape(str(exc))}",
            chat_id=chat_id,
        )
        return

    report = _format_signal_report(data)
    conf = data.get("confirmed") or {}
    try:
        rec = signal_journal.add_signal("aiidea", symbol, timeframe, conf.get("signal"), conf.get("entry"),
                                        conf.get("tp"), conf.get("sl"), (data.get("config") or {}).get("maxHold"))
    except Exception as exc:  # noqa: BLE001 -- журнал не должен мешать ответу
        print(f"[SIGNALS] не записан: {exc}", file=sys.stderr)
        rec = None
    if rec:
        report += "\n\n🎯 Сигнал записан: пришлю, чем закончится (тейк или стоп). Точность — /signals"
    telegram.send_message(report, chat_id=chat_id)
    # 2026-09-24: график с входом/тейком/стопом и кнопка «Открыть сделку»
    if conf.get("signal") in ("LONG", "SHORT") and conf.get("entry") and conf.get("tp") and conf.get("sl"):
        _send_signal_chart(telegram, chat_id, symbol, timeframe, conf["signal"], float(conf["entry"]),
                           float(conf["tp"]), float(conf["sl"]), "/aiidea")


AIPICK_MIN_TRADES = 15   # меньше сделок на истории — результат считаем случайностью


def _aipick_best(data: dict) -> tuple[int, dict] | None:
    """Главный вариант подбора: первый (в порядке движка) с достаточным
    числом сделок; если таких нет — None. Его же пишем в журнал сигналов."""
    cands = list(enumerate(data.get("candidates") or [], start=1))
    ok = [(i, c) for i, c in cands if int(c.get("trades", 0) or 0) >= AIPICK_MIN_TRADES]
    # 2026-09-24: движок проверяет варианты на последних 30% истории, которых
    # подбор не видел (robust). Если такое поле есть — берём только проверенные.
    if any("robust" in c for _, c in ok):
        ok = [(i, c) for i, c in ok if c.get("robust")]
    return ok[0] if ok else None


def _format_aipick_report(data: dict) -> str:
    """2026-09-24, переписано по просьбе владельца («не нравится как
    приходит»): вместо таблицы с сокращениями — один главный вариант
    словами (что делать сейчас + как он вёл себя на истории) и до двух
    запасных одной строкой. Варианты с малым числом сделок не
    рекомендуются, а только упоминаются."""
    symbol = data.get("symbol", "?")
    tf_code = str(data.get("timeframe", "60"))
    tf = _TF_LABELS.get(tf_code, tf_code)
    candles = int(data.get("candles") or 0)
    iterations = data.get("iterations", "?")
    candidates = data.get("candidates") or []
    tf_min = {"1": 1, "3": 3, "5": 5, "15": 15, "30": 30, "60": 60, "120": 120, "240": 240,
              "360": 360, "720": 720, "D": 1440, "W": 10080}.get(tf_code, 60)
    days = candles * tf_min / 1440 if candles else 0

    def _px(v):
        return _fmt_price(v)

    def _now_block(c: dict) -> list[str]:
        nw = c.get("now") or {}
        sig = nw.get("signal")
        if sig in ("LONG", "SHORT") and nw.get("tp") is not None and nw.get("entry"):
            entry, tp, sl = float(nw["entry"]), float(nw["tp"]), float(nw["sl"])
            icon = "🟢" if sig == "LONG" else "🔴"
            word = "ЛОНГ" if sig == "LONG" else "ШОРТ"
            return [f"{icon} <b>Сейчас: {word}</b>",
                    f"Вход <code>{_px(entry)}</code>",
                    f"Тейк <code>{_px(tp)}</code> ({(tp - entry) / entry * 100:+.1f}%)",
                    f"Стоп <code>{_px(sl)}</code> ({(sl - entry) / entry * 100:+.1f}%)"]
        if sig:
            return ["⚪ <b>Сейчас сигнала нет</b> — вход не нужен, жди."]
        return ["⚪ Текущий сигнал недоступен (обнови терминал: «⬆ Обновить терминал»)."]

    def _history(c: dict) -> str:
        pf = c.get("profitFactor")
        pf_txt = f"{pf:.1f}" if isinstance(pf, (int, float)) else "—"
        return (f"{int(c.get('trades', 0) or 0)} сделок · {float(c.get('winRate') or 0):.0f}% в плюс · "
                f"в среднем {float(c.get('avgPnl') or 0):+.2f}% · PF {pf_txt} · "
                f"просадка {float(c.get('maxDrawdown') or 0):.1f}%")

    head = f"🧠 <b>Подбор · {symbol} {tf}</b>"
    sub = f"<i>Проверено {iterations} вариантов на истории ≈{days:.0f} дн.</i>" if days else ""
    lines = [head] + ([sub] if sub else [])

    if not candidates:
        lines += ["", "Ни один вариант не дал достаточно сделок. Попробуй другой таймфрейм или монету."]
        return "\n".join(lines)

    best = _aipick_best(data)
    weak = [i for i, c in enumerate(candidates, start=1)
            if int(c.get("trades", 0) or 0) < AIPICK_MIN_TRADES or c.get("robust") is False]

    if best is None:
        lines += ["", f"⚠️ <b>Надёжного варианта нет</b>: ни один не набрал {AIPICK_MIN_TRADES}+ сделок "
                      f"и не удержал прибыль на новых данных (последние 30% истории, которых подбор не видел). "
                      f"Лучше не входить по этой монете или попробовать другой таймфрейм (например 4h)."]
        return "\n".join(lines)

    bi, bc = best
    cfg = bc.get("config") or {}
    lines += ["", f"🏆 <b>Лучший вариант</b>"]
    lines += _now_block(bc)
    oos = bc.get("oos") or {}
    if oos:
        pf = oos.get("profitFactor")
        lines.append(f"✓ Проверен на новых данных: {oos.get('trades')} сд · "
                     f"{float(oos.get('totalPnl') or 0):+.1f}% · PF {pf:.2f}" if isinstance(pf, (int, float))
                     else f"✓ Проверен на новых данных: {oos.get('trades')} сд · {float(oos.get('totalPnl') or 0):+.1f}%")
    lines += [f"История: {_history(bc)}",
              f"<i>Держать не дольше {cfg.get('maxHold', '?')} свечей ({tf}).</i>"]

    others = [(i, c) for i, c in enumerate(candidates, start=1)
              if i != bi and int(c.get("trades", 0) or 0) >= AIPICK_MIN_TRADES and c.get("robust", True)][:2]
    if others:
        lines += ["", "<b>Запасные варианты</b>"]
        for i, c in others:
            nw = c.get("now") or {}
            sig = nw.get("signal")
            now_txt = ({"LONG": "🟢 лонг", "SHORT": "🔴 шорт"}.get(sig, "⚪ без сигнала")
                       + (f" от {_px(nw['entry'])}" if sig in ("LONG", "SHORT") and nw.get("entry") else ""))
            pf = c.get("profitFactor")
            lines.append(f"• {now_txt} · {int(c.get('trades', 0) or 0)} сд · "
                         f"{float(c.get('winRate') or 0):.0f}% в плюс · PF {pf:.1f}" if isinstance(pf, (int, float))
                         else f"• {now_txt} · {int(c.get('trades', 0) or 0)} сд")
    if weak:
        lines += ["", f"<i>Ещё {len(weak)} вар. отброшено: мало сделок или не удержали прибыль на новых данных.</i>"]
    lines += ["<i>Подбор по прошлому, без комиссий — не обещание.</i>"]
    return "\n".join(lines)


def _handle_aipick_command(telegram: TelegramClient, chat_id: str, text: str, settings: Settings,
                            state: StateStore) -> None:
    if _tested_coin_reply(telegram, chat_id, text):
        return
    """/aipick <символ> [таймфрейм] [итераций] -- та же кнопка «Подобрать
    ИИ», что в конструкторе стратегий терминала, но из Telegram.

    2026-09-22: попросили после того, как показали конструктор в панели --
    "надо добавить эту функцию в бота в телеграмм". Ничего нового не
    считается: это тот же searchBestConfigs (strategy.ts) через тот же
    мост app/vantorix_signal.py, что и /aiidea, только новый режим
    "--mode pick" у signalCli.ts вместо режима по умолчанию. Одна и та же
    логика перебора видна и в браузере, и в чате -- разошлись бы они,
    если бы это был отдельный порт на Python, а не общий вызов движка.

    Итераций по умолчанию 240, как и в конструкторе; можно попросить
    больше третьим аргументом, но перебор не бесплатный по времени --
    таймаут на стороне fetch_ai_pick 180 с, при желании сильно большего
    числа итераций команда скорее оборвётся по таймауту, чем досчитает.
    """
    parts = text.split()
    if len(parts) < 2:
        telegram.send_message(
            "Формат: <code>/aipick BTCUSDT</code> или <code>/aipick BTCUSDT 4h</code> "
            "или <code>/aipick BTCUSDT 4h 400</code> (число итераций перебора, по умолчанию 240)\n"
            "Таймфреймы: 1m, 5m, 15m, 30m, 1h, 4h, 12h, 1d, 1w",
            chat_id=chat_id,
        )
        return

    symbol = parts[1].strip().upper()
    timeframe = _normalize_timeframe(parts[2] if len(parts) > 2 else "")
    try:
        iterations = int(parts[3]) if len(parts) > 3 else 240
    except ValueError:
        iterations = 240

    if _AIPICK_BUSY.locked():
        telegram.send_message("⏳ Предыдущий подбор ещё считается — дождись его результата.", chat_id=chat_id)
        return

    progress = telegram.send_message(
        f"⏳ Подбираю {symbol}: {iterations} вариантов, 20–60 с…",
        chat_id=chat_id,
    )
    progress_id = (progress.get("result") or {}).get("message_id")

    # 2026-09-23: перебор идёт в ФОНОВОМ потоке. Раньше он выполнялся прямо
    # в цикле опроса Telegram, и на 20–60 с бот переставал отвечать на
    # любые кнопки и команды ("бот тормозил"). Одновременно разрешён только
    # один подбор (_AIPICK_BUSY), чтобы серия нажатий не загрузила CPU.
    def _worker() -> None:
        with _AIPICK_BUSY:
            try:
                data = fetch_ai_pick(symbol, timeframe, iterations=iterations)
                if "candidates" not in data:
                    raise SignalError(
                        "Движок собран без режима подбора (старый signal.cjs). "
                        "Пересобери его: в папке terminal выполни «npm run build:cli» и перезапусти бота."
                    )
                report = _format_aipick_report(data)
                # в журнал — только главный (надёжный) вариант, как и в сообщении
                best = _aipick_best(data)
                if best:
                    bi, bc = best
                    nw = bc.get("now") or {}
                    try:
                        if signal_journal.add_signal("aipick", symbol, timeframe, nw.get("signal"), nw.get("entry"),
                                                     nw.get("tp"), nw.get("sl"), (bc.get("config") or {}).get("maxHold"),
                                                     note=f"#{bi}"):
                            report += "\n\n🎯 Слежу за этим сигналом — пришлю, чем закончится. Точность: /signals"
                    except Exception as exc:  # noqa: BLE001
                        print(f"[SIGNALS] aipick не записан: {exc}", file=sys.stderr)
                telegram.send_message(report, chat_id=chat_id)
                if best:
                    nw = best[1].get("now") or {}
                    if nw.get("signal") in ("LONG", "SHORT") and nw.get("tp") is not None and nw.get("entry"):
                        _send_signal_chart(telegram, chat_id, symbol, timeframe, nw["signal"], float(nw["entry"]),
                                           float(nw["tp"]), float(nw["sl"]), "/aipick")
            except SignalError as exc:
                _safe_send(telegram, f"⚠️ {html_lib.escape(str(exc))}", chat_id)
            except Exception as exc:  # noqa: BLE001 -- в чат уходит причина, а не тишина
                if "api.telegram.org" in str(exc) or "timed out" in str(exc).lower():
                    _safe_send(telegram, "⚠️ /aipick: сеть не ответила вовремя — повтори через минуту.", chat_id)
                else:
                    _safe_send(telegram, f"⚠️ Не получилось подобрать конфиг: {html_lib.escape(str(exc))}", chat_id)
            finally:
                _try_delete_message(telegram, chat_id, progress_id)

    threading.Thread(target=_worker, name="aipick", daemon=True).start()


_AIPICK_BUSY = threading.Lock()


_BOT_TOKEN_RE = __import__("re").compile(r"bot\d{6,}:[A-Za-z0-9_-]{20,}")


def _mask_secrets(text: str) -> str:
    """2026-09-26: ошибка сети requests содержит URL с токеном бота
    (/bot<id>:<secret>/sendMessage) -- в чат его выводить нельзя."""
    return _BOT_TOKEN_RE.sub("bot***", text or "")


def _safe_send(telegram: TelegramClient, text: str, chat_id: str) -> None:
    text = _mask_secrets(text)
    try:
        telegram.send_message(text, chat_id=chat_id)
    except Exception as exc:  # noqa: BLE001 -- фоновый поток не должен падать молча
        print(f"[AIPICK] couldn't send message: {exc}", file=sys.stderr)


def _handle_aichart_command(telegram: TelegramClient, chat_id: str, text: str, settings: Settings,
                             state: StateStore) -> None:
    """/aichart <symbol> -- 2026-08-26/29, round 18: the user asked for
    Vera to "analyze the chart and mark entry/take/stop with labels, and
    mark the support/resistance zones." Scoped via AskUserQuestion into
    "both at once": this command ALWAYS sends a chart with the bot's own
    REAL, already-computed data (armed detector zones for this symbol,
    plus a real active signal's real entry/stop/take if one exists) as
    the base layer -- exactly the same sources /aiidea and /ideas already
    use, nothing new invented -- PLUS a separately and clearly labeled
    EXPERIMENTAL AI-hypothesis layer on the SAME image, if and only if
    app/ai_assistant.generate_chart_annotation() returns something that
    passes its own strict validation (see that function's docstring).

    This is a brand-new command, deliberately NOT a change to /aiidea's
    existing text-only behavior -- /aiidea and its existing tests are
    completely untouched by this round; a symbol that only wants the
    existing hedged-text idea still gets exactly that from /aiidea, same
    as before. No Telegram button either (same "AI features are
    commands-only" precedent as round 10/17): the symbol argument is
    free-form text a button can't collect.

    Never wired into any trading action -- this is purely visual/advisory,
    exactly like /aiidea. It reads state and calls the exchange's PUBLIC
    kline/price endpoints only; it never touches trading_guard.py,
    trade_executor.py, autopilot.py, or the signal-gate."""
    parts = text.split()
    if len(parts) != 2:
        telegram.send_message("Формат: <code>/aichart BTCUSDT</code>", chat_id=chat_id)
        return
    symbol = parts[1].strip().upper()

    try:
        price = get_last_price(symbol)
    except DataError as exc:
        telegram.send_message(f"Не удалось получить цену {symbol}: {exc}", chat_id=chat_id)
        return

    try:
        df = get_klines(symbol, settings.timeframe, limit=200)
    except DataError as exc:
        telegram.send_message(f"Не удалось получить свечи {symbol}: {exc}", chat_id=chat_id)
        return

    # ---- real, already-computed bot data (base layer) ----
    # 2026-09-06: real_zones/real_signal used to come from the CHoCH+OB+FVG
    # detector's StateStore (all_pending_zones()/latest_active_signal()) --
    # that detector is retired, so this base layer is now always empty and
    # the chart shows only the AI hypothesis layer (if any). render_ai_
    # annotated_chart tolerates empty/None for all of these by design.
    real_zones: list = []
    real_entry = real_stop = real_take = None

    # ---- optional experimental AI hypothesis layer ----
    # 2026-09-06: market_context used to be just the current-price line --
    # no historical price action -- which left the model almost nothing to
    # reason from and is the most likely reason it so often had to answer
    # insufficient_data (user report: "толку от Веры нет"). Now built from
    # the real klines (`df`) already fetched above for the chart itself,
    # via the same `build_market_context` helper /aiidea uses.
    ai_annotation = None
    ai_unavailable_reason = None
    if not resolve_api_key(settings):
        ai_unavailable_reason = "ИИ ещё не настроен (см. /setaikey)"
    else:
        market_context = build_market_context(df, settings.timeframe, price)
        try:
            ai_annotation = generate_chart_annotation(symbol, market_context, price, settings)
        except Exception:
            # generate_chart_annotation's own contract is "never raise, return
            # None on any failure" -- this except is belt-and-suspenders only,
            # so a bug there can NEVER take down /aichart or block the real
            # (already fully computed above) layer from being drawn.
            print(f"[AI] /aichart: unexpected error generating annotation for {symbol}", file=sys.stderr)
            traceback.print_exc()
            ai_annotation = None
        if ai_annotation is None:
            ai_unavailable_reason = "ИИ не дал пригодную гипотезу в этот раз (мало данных или не прошла проверку)"

    try:
        png = chart.render_ai_annotated_chart(
            df=df, symbol_label=symbol.replace("USDT", ""), timeframe=settings.timeframe,
            real_zones=real_zones, real_entry=real_entry, real_stop=real_stop, real_take=real_take,
            ai_annotation=ai_annotation,
        )
    except Exception:
        # The real-zone layer must NEVER be blocked or corrupted by a
        # drawing bug -- but if rendering itself somehow fails, there is
        # nothing left to send; report plainly rather than crash the
        # command handler (and, transitively, the access-poll thread).
        print(f"[AI] /aichart: unexpected error rendering chart for {symbol}", file=sys.stderr)
        traceback.print_exc()
        telegram.send_message(f"⚠️ Не удалось построить график для {symbol}.", chat_id=chat_id)
        return

    # 2026-09-06: this used to claim "реальные зоны/уровни бота" unconditionally,
    # even though real_zones/real_entry/real_stop/real_take above are now ALWAYS
    # empty (the detector that used to populate them is retired) -- so the chart
    # was, in effect, always just a plain candlestick chart plus (maybe) the AI
    # layer, but the caption implied real bot-computed levels were drawn every
    # time. Caption now says what's actually on the image.
    if ai_annotation:
        caption_lines = [f"🖼 <b>{symbol}</b>: экспериментальная ИИ-гипотеза"]
        caption_lines.append(
            "\n⚠️ Фиолетовым/пунктиром на графике -- ЭКСПЕРИМЕНТАЛЬНАЯ гипотеза от ИИ, это НЕ торговый сигнал "
            "и не готовая сделка. ИИ может ошибаться -- решения и ответственность всегда твои."
        )
        if ai_annotation.get("note"):
            caption_lines.append("\n🧪 " + _ai_escape(ai_annotation["note"]))
    else:
        caption_lines = [f"🖼 <b>{symbol}</b>: график (без разметки)"]
        caption_lines.append(f"\n🧪 {ai_unavailable_reason}.")
    telegram.send_photo(png, "\n".join(caption_lines), chat_id=chat_id)


def _display_identity(from_: dict, chat_id: str) -> str:
    """Human-friendly "who is this" string for the owner-facing new-access
    notification (2026-08-23) -- @username if set, else first+last name,
    else just the raw chat_id as a last resort."""
    username = from_.get("username")
    full_name = " ".join(filter(None, [from_.get("first_name"), from_.get("last_name")])).strip()
    if username:
        return f"@{username}" + (f" ({full_name})" if full_name else "")
    return full_name or chat_id


def _handle_access_message(telegram: TelegramClient, access: AccessStore, scan: ScanSettings,
                            settings: Settings, state: StateStore, message: dict) -> None:
    """One incoming text message -- invite-code gate + /newcode + /scan
    commands. Split out of _handle_access_updates (2026-08-23) so the
    caller can wrap it in one try/except; see that bugfix note on
    _handle_scan_callback for why.

    2026-08-23, round 8: gained a `state` (StateStore) parameter so
    /trade's optional signal-gate can look up recently-fired signals (see
    _handle_trade_command) -- everything else in this function is
    unaffected, /trade/tradekey are just two more owner-only branches
    alongside /setkey below."""
    if "text" not in message:
        return
    chat_id = str(message["chat"]["id"])
    text = message["text"].strip()
    from_ = message.get("from", {})
    who = from_.get("username") or from_.get("first_name") or chat_id
    who_display = _display_identity(from_, chat_id)

    # Owner-only, 2026-08-26 round 17: /menu (or "меню") and, for the
    # owner specifically, /start too -- (re)send the persistent
    # reply-keyboard button menu. Placed first among the owner-only
    # branches, before the "already authorized -> stay silent" branch
    # below, for the same reason as OWNER_CODE_COMMANDS: the owner is
    # always already authorized, so without this the owner's own /start
    # would silently do nothing (that early-exit branch further down is
    # what a GUEST's /start hits, prompting for an invite code -- the
    # owner never needs that prompt). This is intentionally a no-op
    # beyond sending the keyboard -- purely so the owner can bring the
    # menu back if they ever dismiss/hide it on their phone.
    if access.is_owner(chat_id) and (text.lower() in OWNER_MENU_COMMANDS or text == "/start"):
        # 2026-09-23: вместо удаления клавиатуры ставим одну кнопку «☰ Меню».
        # Сообщение с ней не удаляется (иначе кнопка может пропасть) и
        # отправляется один раз за запуск бота.
        if chat_id not in _menu_button_sent:
            try:
                telegram.send_message("Кнопка <b>☰ Меню</b> теперь всегда внизу.", chat_id=chat_id,
                                      reply_markup=MENU_BUTTON_KEYBOARD)
                _menu_button_sent.add(chat_id)
            except (TelegramError, requests.exceptions.RequestException) as exc:
                print(f"[MENU] couldn't set menu button (harmless): {exc}", file=sys.stderr)
        if text == BTN_MENU:
            _try_delete_message(telegram, chat_id, message.get("message_id"))
        _send_menu(telegram, chat_id)
        return

    # Owner-only: request a fresh one-time code, from any chat state
    # (owner is always already authorized, so this check must come
    # before the "already authorized -> stay silent" branch below).
    if access.is_owner(chat_id) and text.lower() in OWNER_CODE_COMMANDS:
        _issue_new_code(telegram, access, settings, chat_id)
        return

    # Owner-only: open the scan-universe picker (5 монет / топ-25/50/100).
    if access.is_owner(chat_id) and text.lower() in OWNER_SCAN_COMMANDS:
        telegram.send_message(
            "Что сканировать?", chat_id=chat_id, reply_markup=_scan_menu_keyboard(scan.mode),
        )
        return

    # 2026-11-02: быстрый журнал Hash Hedge — «/hh LINK long -35 заметка», «/неделя», «/состояние».
    if access.is_owner(chat_id) and text.lower().split(" ")[0] in ("/hh", "/сделка", "/неделя", "/week", "/состояние"):
        try:
            from windows_app import challenge_guard as _cg  # noqa: PLC0415
            cmd = text.lower().split(" ")[0]
            if cmd in ("/неделя", "/week"):
                telegram.send_message(_cg.weekly(), chat_id=chat_id)
            elif cmd == "/состояние":
                st = _cg.state()
                telegram.send_message(f"Состояние: <b>{st['title']}</b>\n{st['advice']}\n" + "\n".join("• " + w for w in st["why"]), chat_id=chat_id)
            else:
                t = _cg.parse_cmd(text)
                if not t:
                    telegram.send_message("Формат: <code>/hh LINK long -35 заметка</code> (итог сделки в $, с минусом если убыток)", chat_id=chat_id)
                else:
                    d = requests.post("http://127.0.0.1:8765/api/challenge", json={"add_trade": t}, timeout=15).json()
                    rec = (d.get("trades") or [{}])[0]
                    st = _cg.state(d)
                    msg = (f"✍️ Записал: <b>{rec.get('sym')}</b> {rec.get('side')} <b>{rec.get('pnl', 0):+.0f} $</b>\n"
                           f"{'✅ по сигналу: ' + rec['signal'] if rec.get('signal') else '⚠ без сигнала бота'}\n"
                           f"💰 Баланс: {float(d.get('bal') or 0):,.0f} $\n".replace(",", " ")
                           + "".join("⚠ " + w + "\n" for w in rec.get("warn") or [])
                           + f"Состояние: <b>{st['title']}</b>")
                    telegram.send_message(msg, chat_id=chat_id)
        except Exception as exc:  # noqa: BLE001
            telegram.send_message(f"Журнал: панель не отвечает ({str(exc)[:120]}). Запусти панель и повтори.", chat_id=chat_id)
        return

    # Owner-only: /setkey <exchange> <api_key> <api_secret> [<passphrase>]
    # -- see _handle_setkey_command. Always deletes the message afterward
    # (success or failure) since it may contain a real secret either way.
    if access.is_owner(chat_id) and text.lower().startswith("/setkey"):
        _handle_setkey_command(telegram, chat_id, text)
        _try_delete_message(telegram, chat_id, message.get("message_id"))
        return

    # Owner-only: /tradekey <exchange> <api_key> <api_secret> [<passphrase>]
    # -- see _handle_tradekey_command. Checked with an exact first-word
    # match (not startswith) so it can never be shadowed by /trade below,
    # or vice versa.
    first_word = text.split(None, 1)[0].lower() if text.strip() else ""
    if access.is_owner(chat_id) and first_word == "/tradekey":
        _handle_tradekey_command(telegram, chat_id, text)
        _try_delete_message(telegram, chat_id, message.get("message_id"))
        return

    # Owner-only, 2026-08-24 round 10: /setaikey <api_key> -- see
    # _handle_setaikey_command. Carries a real secret, so (like /setkey/
    # /tradekey above) the message is always deleted afterward.
    if access.is_owner(chat_id) and first_word == "/setaikey":
        _handle_setaikey_command(telegram, chat_id, text)
        _try_delete_message(telegram, chat_id, message.get("message_id"))
        return

    # Owner-only: /trade <exchange> <symbol> <buy|sell> <qty> <leverage>
    # <stop_loss> [<take_profit>] [gate] -- see _handle_trade_command.
    # 2026-08-23, round 8: this one places a REAL order, unlike every
    # other command in this function -- always deletes the message
    # afterward regardless of outcome, same hygiene as /setkey, even
    # though a trade command doesn't carry a secret (keeps the chat clean
    # and matches the established pattern).
    if access.is_owner(chat_id) and first_word == "/trade":
        _handle_trade_command(telegram, chat_id, text, settings, state)
        _try_delete_message(telegram, chat_id, message.get("message_id"))
        return

    # Owner-only, 2026-08-23 round 9 ("Вера" trading-assistant features):
    # /report, /ideas, /autopilot. None of these carry a secret, so
    # (unlike /setkey/tradekey/trade above) the triggering message is left
    # in the chat -- nothing sensitive to clean up.
    #
    # 2026-08-26, round 17: each also now matches the exact text of its
    # persistent-keyboard button label (BTN_REPORT/BTN_IDEAS/etc, see
    # _main_menu_keyboard) -- a button tap arrives as an ordinary text
    # message equal to the button's label, so this is just one more
    # string this same branch matches on. The handler call itself is
    # completely unchanged -- no separate button-only code path.
    if access.is_owner(chat_id) and (first_word == "/report" or text == BTN_REPORT):
        _handle_report_command(telegram, chat_id, settings)
        return

    if access.is_owner(chat_id) and first_word == "/autopilot":
        _handle_autopilot_command(telegram, chat_id, text, settings)
        return

    # 2026-08-26, round 17: "🛡 Автопилот" button tap -- calls the SAME
    # _handle_autopilot_command as a bare "/autopilot" (no argument), which
    # reports status AND (as of this round) attaches the on/off inline
    # keyboard -- see _autopilot_menu_keyboard. The synthetic "/autopilot"
    # text (not the raw button label) is what makes this hit that exact
    # no-argument branch instead of the "unknown argument" error branch.
    if access.is_owner(chat_id) and text == BTN_AUTOPILOT:
        _handle_autopilot_command(telegram, chat_id, "/autopilot", settings)
        return

    # Owner-only, 2026-09-06, user request: /maxdeals -- live cap on how
    # many deals long_strategy15_latuserge_live.py / kc_roc_cci_wt_grid_live.py
    # may hold open at once, editable without restarting either bot. See
    # _handle_maxdeals_command's own docstring. No secret, left in the chat
    # like /autopilot/instanttrade above.
    if access.is_owner(chat_id) and first_word == "/maxdeals":
        _handle_maxdeals_command(telegram, chat_id, text)
        return

    # Owner-only, 2026-08-25 round 14: /instanttrade -- fast kill switch
    # for the local trade-server's instant execution (see
    # _handle_instanttrade_command + app/trade_server.py). No secret, left
    # in the chat like /autopilot above.
    if access.is_owner(chat_id) and first_word == "/instanttrade":
        _handle_instanttrade_command(telegram, chat_id, text, settings)
        return

    # 2026-08-26, round 17: "⚡ Мгновенная торговля" button tap -- same
    # pattern as the "🛡 Автопилот" button above, for _handle_instanttrade_
    # command's status/on-off-inline-keyboard reply.
    if access.is_owner(chat_id) and text == BTN_INSTANTTRADE:
        _handle_instanttrade_command(telegram, chat_id, "/instanttrade", settings)
        return

    # 2026-08-26, round 17: "ℹ️ Другие команды" button -- see
    # _handle_other_commands_button. Purely informational, no state change.
    if access.is_owner(chat_id) and text == BTN_OTHER:
        _handle_other_commands_button(telegram, chat_id)
        return

    # Owner-only, 2026-08-24 round 10 (optional AI layer): /ai <question>
    # and /aiidea <symbol>. Neither carries a secret, so (like /report/
    # /ideas/autopilot above) the triggering message is left in the chat.
    if access.is_owner(chat_id) and first_word == "/ai":
        _handle_ai_command(telegram, chat_id, text, settings, scan, state)
        return

    # 2026-10-05: «мозг трейдера» — память уроков и правил для ИИ
    if access.is_owner(chat_id) and first_word in ("/brain", "/мозг"):
        telegram.send_message(trader_brain.listing()[:3900], chat_id=chat_id)
        return
    if access.is_owner(chat_id) and first_word in ("/learn", "/урок"):
        rest = text.split(None, 1)
        ok = len(rest) > 1 and trader_brain.add_lesson(rest[1], "владелец")
        telegram.send_message("🧠 Запомнил." if ok else "Формат: <code>/learn что запомнить</code>", chat_id=chat_id)
        return
    if access.is_owner(chat_id) and first_word in ("/rule", "/правило"):
        rest = text.split(None, 1)
        if len(rest) > 1:
            trader_brain.add_rule(rest[1]); telegram.send_message("📜 Правило добавлено.", chat_id=chat_id)
        else:
            telegram.send_message("Формат: <code>/rule правило</code>", chat_id=chat_id)
        return
    if access.is_owner(chat_id) and first_word in ("/forget", "/забудь"):
        rest = text.split()
        gone = trader_brain.forget(int(rest[1])) if len(rest) > 1 and rest[1].isdigit() else None
        telegram.send_message(f"Удалил: {_ai_escape(gone)}" if gone else "Формат: <code>/forget номер</code> (номер из /brain)", chat_id=chat_id)
        return
    if access.is_owner(chat_id) and first_word in ("/risk", "/риск"):
        rest = text.split()
        try:
            v = float(rest[1].replace(",", "."))
            if not 1 <= v <= 200:
                raise ValueError
            if len(rest) > 2 and rest[2].lower() in ("да", "yes", "ok"):
                telegram.send_message("✅ " + trader_brain.set_risk(v), chat_id=chat_id)
            else:
                telegram.send_message(f"Поставить риск {v:g} $ на сделку в челлендже? Подтверди: <code>/risk {v:g} да</code>", chat_id=chat_id)
        except (IndexError, ValueError):
            telegram.send_message("Формат: <code>/risk 25</code> (1–200 $)", chat_id=chat_id)
        return
    if access.is_owner(chat_id) and text and not text.startswith("/") and len(text) >= 6:
        # обычный вопрос без команды → ИИ-помощник с памятью (как /ai)
        _handle_ai_command(telegram, chat_id, "/ai " + text, settings, scan, state)
        return

    if access.is_owner(chat_id) and first_word == "/aiidea":
        _handle_aiidea_command(telegram, chat_id, text, settings, state)
        return

    if access.is_owner(chat_id) and first_word == "/aipick":
        _handle_aipick_command(telegram, chat_id, text, settings, state)
        return

    if access.is_owner(chat_id) and first_word in ("/buy", "/sell"):
        _handle_buy_sell_command(telegram, chat_id, text, settings)
        return

    if access.is_owner(chat_id) and first_word == "/chart":
        _handle_chart_command(telegram, chat_id, text)
        return

    if access.is_owner(chat_id) and first_word == "/signals":
        _handle_signals_command(telegram, chat_id, text)
        return

    if access.is_owner(chat_id) and first_word == "/notify":
        telegram.send_message(_notify_text(), chat_id=chat_id, reply_markup=_notify_keyboard())
        return

    # Owner-only, 2026-08-26/29 round 18: /aichart <symbol> -- see
    # _handle_aichart_command's own docstring. Same "no secret, no
    # deletion" treatment as /ai/aiidea above.
    if access.is_owner(chat_id) and first_word == "/aichart":
        _handle_aichart_command(telegram, chat_id, text, settings, state)
        return

    if access.is_authorized(chat_id):
        return  # already in -- no other commands to answer, bot is push-only

    if text == "/start":
        telegram.send_message(
            "Привет! Это приватный бот. Пришли код-приглашение одним сообщением, чтобы получить доступ.",
            chat_id=chat_id,
        )
    elif access.consume_code(text, chat_id):
        access.authorize(chat_id, {"role": "guest", "authorized_via": "invite_code", "username": who})
        _publish_active_code(access, settings)  # code is now used -> site sync should reflect that too
        telegram.send_message("✅ Код верный, доступ открыт. Теперь сюда будут приходить сигналы.", chat_id=chat_id)
        _try_delete_message(telegram, chat_id, message.get("message_id"))
        # 2026-08-23: tell the owner who just joined -- previously this only
        # ever showed up in the console or authorized_users.json, which a
        # background-running bot's owner isn't realistically watching.
        if chat_id != settings.telegram_chat_id:
            telegram.send_message(
                f"👤 Новый доступ по коду <code>{text.strip().upper()}</code>: {who_display} "
                f"(chat_id {chat_id})",
                chat_id=settings.telegram_chat_id,
            )
        print(f"[ACCESS] {who} ({chat_id}) authorized via invite code")
    else:
        telegram.send_message("❌ Неверный или уже использованный код. Попроси новый у владельца бота.", chat_id=chat_id)
        _try_delete_message(telegram, chat_id, message.get("message_id"))


_GROUP_FILE = Path(__file__).resolve().parent / "bt_lab_bots" / "group_guard.json"
_CAPTCHA_SECONDS = 300          # 5 минут на кнопку «Я не бот», иначе — удаление из группы
_NO = {"can_send_messages": False, "can_send_audios": False, "can_send_documents": False, "can_send_photos": False,
       "can_send_videos": False, "can_send_video_notes": False, "can_send_voice_notes": False, "can_send_polls": False,
       "can_send_other_messages": False, "can_add_web_page_previews": False}


def _tg(telegram, method: str, **data):
    import json as _j  # noqa: PLC0415
    data = {k: (_j.dumps(v) if isinstance(v, (dict, list)) else v) for k, v in data.items()}
    try:
        return requests.post(telegram._url(method), data=data, timeout=20).json()  # noqa: SLF001
    except Exception as exc:  # noqa: BLE001
        print(f"[GROUP] {method}: {exc}", file=sys.stderr); return {}


def _guard_load() -> dict:
    import json as _j  # noqa: PLC0415
    try:
        return _j.loads(_GROUP_FILE.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return {"pending": {}, "strikes": {}}


def _guard_save(g: dict) -> None:
    import json as _j  # noqa: PLC0415
    _GROUP_FILE.parent.mkdir(exist_ok=True); _GROUP_FILE.write_text(_j.dumps(g, ensure_ascii=False, indent=1), encoding="utf-8")


def _group_moderate(telegram, settings, message) -> None:
    """2026-10-10. Охрана группы сигналов:
    • новичок → без права писать + приветствие с кнопкой «✅ Я не бот» (5 минут, иначе удаляется из группы);
    • спам (ссылки, @упоминания, пересылки, чужие боты) от всех, кроме владельца → удаляется;
      1-й раз — предупреждение, 2-й — мут на сутки, 3-й — бан навсегда."""
    import time as _t  # noqa: PLC0415
    try:
        chat_id = message["chat"]["id"]; thread = message.get("message_thread_id")
        frm = message.get("from") or {}
        g = _guard_load()
        newbies = message.get("new_chat_members") or []
        if newbies:
            _try_delete_message(telegram, chat_id, message.get("message_id"))     # убираем «X вступил(а)»
            for u in newbies:
                if u.get("is_bot"):
                    continue
                uid = u["id"]; name = (u.get("first_name") or "участник")[:30]
                _tg(telegram, "restrictChatMember", chat_id=chat_id, user_id=uid, permissions=_NO)
                kb = {"inline_keyboard": [[{"text": "✅ Я не бот", "callback_data": f"captcha:{uid}"}]]}
                r = _tg(telegram, "sendMessage", chat_id=chat_id, parse_mode="HTML", reply_markup=kb,
                        **({"message_thread_id": thread} if thread else {}),
                        text=(f"👋 Добро пожаловать, <b>{name}</b>!\n\n"
                              "Это группа сигналов <b>TRADEOS</b>:\n"
                              "📐 Пробой канала — основная стратегия · 🔴 реальные боты · 🧪 бумажные тесты (без денег).\n\n"
                              "⚠️ Сигналы — не финансовый совет. Риск на сделку — не больше 1–2% депозита.\n"
                              "🚫 Ссылки и реклама удаляются, за повтор — бан.\n\n"
                              "Нажмите кнопку в течение 5 минут, чтобы подтвердить, что вы не бот."))
                mid = (r.get("result") or {}).get("message_id")
                g["pending"][f"{chat_id}:{uid}"] = {"t": _t.time(), "msg": mid}
            _guard_save(g); return
        if message.get("left_chat_member"):
            _try_delete_message(telegram, chat_id, message.get("message_id")); return
        if str(frm.get("id")) == str(settings.telegram_chat_id) or message.get("sender_chat"):
            return
        # 2026-11-02: свои/любые боты (сигналы TRADEOS-BOT) — не спам; раньше бот «банил» сам себя
        _bot_id = str(settings.telegram_token).split(":")[0]
        if frm.get("is_bot") or str(frm.get("id")) == _bot_id:
            if any(k.endswith(f":{_bot_id}") for k in g.get("strikes", {})):
                g["strikes"] = {k: v for k, v in g["strikes"].items() if not k.endswith(f":{_bot_id}")}
                _guard_save(g)
            return
        text = (message.get("text") or message.get("caption") or "")
        ents = (message.get("entities") or []) + (message.get("caption_entities") or [])
        spam = (message.get("forward_origin") or message.get("forward_from_chat")
                or any(e.get("type") in ("url", "text_link", "mention") for e in ents)
                or "t.me/" in text or "http" in text.lower())
        if not spam:
            return
        _try_delete_message(telegram, chat_id, message.get("message_id"))
        uid = frm.get("id"); key = f"{chat_id}:{uid}"; n = g["strikes"].get(key, 0) + 1; g["strikes"][key] = n
        name = (frm.get("first_name") or "участник")[:30]
        if n == 1:
            note = f"⚠️ {name}, ссылки и реклама здесь запрещены. Следующий раз — мут на сутки."
        elif n == 2:
            _tg(telegram, "restrictChatMember", chat_id=chat_id, user_id=uid, permissions=_NO, until_date=int(_t.time()) + 86400)
            note = f"🔇 {name} — мут на 24 часа за повторный спам."
        else:
            _tg(telegram, "banChatMember", chat_id=chat_id, user_id=uid)
            note = f"⛔ {name} забанен за спам."
        r = _tg(telegram, "sendMessage", chat_id=chat_id, text=note, **({"message_thread_id": thread} if thread else {}))
        g.setdefault("notes", []).append({"chat": chat_id, "msg": (r.get("result") or {}).get("message_id"), "t": _t.time()})
        _guard_save(g)
        print(f"[GROUP] спам от {frm.get('username') or uid}: удалено, страйк {n}")
    except Exception as exc:  # noqa: BLE001
        print(f"[GROUP] модерация: {exc}", file=sys.stderr)


def _group_captcha_callback(telegram, callback_query) -> None:
    import time as _t  # noqa: PLC0415
    data = callback_query.get("data") or ""; who = (callback_query.get("from") or {}).get("id")
    msg = callback_query.get("message") or {}; chat_id = (msg.get("chat") or {}).get("id")
    try:
        uid = int(data.split(":", 1)[1])
    except Exception:  # noqa: BLE001
        uid = None
    if who != uid:
        _tg(telegram, "answerCallbackQuery", callback_query_id=callback_query["id"], text="Эта кнопка не для вас 🙂"); return
    perms = (_tg(telegram, "getChat", chat_id=chat_id).get("result") or {}).get("permissions") or {"can_send_messages": True}
    _tg(telegram, "restrictChatMember", chat_id=chat_id, user_id=uid, permissions=perms)
    _tg(telegram, "answerCallbackQuery", callback_query_id=callback_query["id"], text="✅ Спасибо! Доступ открыт.")
    _try_delete_message(telegram, chat_id, msg.get("message_id"))
    g = _guard_load(); g["pending"].pop(f"{chat_id}:{uid}", None); _guard_save(g)


def _group_sweep(telegram) -> None:
    """Не нажал «Я не бот» за 5 минут → удаляем из группы (без бана, может зайти снова). Предупреждения стираем через 2 мин."""
    import time as _t  # noqa: PLC0415
    g = _guard_load(); now = _t.time(); changed = False
    for key, p in list(g.get("pending", {}).items()):
        if now - p["t"] > _CAPTCHA_SECONDS:
            chat_id, uid = key.rsplit(":", 1)
            _tg(telegram, "banChatMember", chat_id=chat_id, user_id=uid, until_date=int(now) + 60)
            _tg(telegram, "unbanChatMember", chat_id=chat_id, user_id=uid, only_if_banned=True)
            if p.get("msg"):
                _try_delete_message(telegram, chat_id, p["msg"])
            g["pending"].pop(key); changed = True
    keep = []
    for n in g.get("notes", []):
        if now - n["t"] > 120 and n.get("msg"):
            _try_delete_message(telegram, n["chat"], n["msg"]); changed = True
        else:
            keep.append(n)
    g["notes"] = keep
    if changed:
        _guard_save(g)


def _handle_access_updates(telegram: TelegramClient, access: AccessStore, scan: ScanSettings,
                            settings: Settings, state: StateStore) -> None:
    """One-time invite-code gate (2026-08-22, app/access.py) plus the
    scan-universe picker (same day, app/scan_settings.py). Non-blocking
    (timeout=0): grabs whatever messages/button-presses arrived since the
    last check, processes them, and returns immediately -- called once per
    scan cycle, not a dedicated long-poll loop, so it never stalls the
    market scan.

    2026-08-23 bugfix: every update is now handled inside a try/except --
    a live crash showed an uncaught TelegramError here (from a single
    stale button press) killing the ENTIRE bot process, not just that one
    reply. One bad Telegram call now just gets logged and the loop moves
    on to the next update / next cycle.

    2026-08-23 bugfix round 2: that first fix only caught TelegramError
    (Telegram itself replying "ok": false) -- a live crash showed a raw
    requests.exceptions.ReadTimeout (SSL handshake timed out talking to
    api.telegram.org, a transient network blip, nothing to do with the
    bot's code) propagating straight through uncaught and killing the
    process the same way. Now catches requests.exceptions.RequestException
    too (covers ConnectionError/Timeout/SSLError/etc., the actual more
    common real-world failure mode for a polling loop like this one)."""
    offset = access.last_update_id + 1 if access.last_update_id is not None else None
    try:
        updates = telegram.get_updates(offset=offset, timeout=0)
    except (TelegramError, requests.exceptions.RequestException) as exc:
        print(f"[ACCESS] getUpdates failed: {exc}", file=sys.stderr)
        return

    for update in updates:
        access.set_last_update_id(update["update_id"])
        try:
            callback_query = update.get("callback_query")
            if callback_query is not None:
                # 2026-08-26, round 17: dispatch by callback_data prefix --
                # the scan-mode picker (2026-08-22) was the only inline
                # keyboard this bot had until now; autopilot/instanttrade's
                # new on/off inline keyboards (see _autopilot_menu_keyboard/
                # _instanttrade_menu_keyboard) reuse this same
                # callback_query plumbing, including the update_id advance
                # above (which already happens before this branch, so a
                # callback_query update is never at risk of being silently
                # re-delivered the way an un-advanced offset would cause).
                data = callback_query.get("data") or ""
                if data.startswith("scan:"):
                    _handle_scan_callback(telegram, access, scan, callback_query)
                elif data.startswith("autopilot:"):
                    _handle_autopilot_callback(telegram, access, settings, callback_query)
                elif data.startswith("instanttrade:"):
                    _handle_instanttrade_callback(telegram, access, settings, callback_query)
                elif data.startswith("menu:"):
                    _handle_menu_callback(telegram, access, scan, settings, state, callback_query)
                elif data.startswith("mtrade:"):
                    _handle_mtrade_callback(telegram, access, settings, callback_query)
                elif data.startswith("captcha:"):
                    _group_captcha_callback(telegram, callback_query)
                else:
                    # Unrecognized/malformed callback_data -- there is
                    # nothing to actually do with it, but Telegram still
                    # expects an answerCallbackQuery or the tap leaves an
                    # infinite loading spinner on the sender's phone.
                    try:
                        telegram.answer_callback_query(callback_query["id"])
                    except (TelegramError, requests.exceptions.RequestException) as exc:
                        print(f"[ACCESS] couldn't acknowledge unrecognized callback data {data!r}: {exc}",
                              file=sys.stderr)
                continue

            message = update.get("message")
            if message is not None and (message.get("chat") or {}).get("type") not in (None, "private"):
                # 2026-10-10: группа «TRADEOS Сигналы» и любые другие группы — бот не отвечает «неверный код»,
                # а работает модератором: от чужих (не владелец) удаляет ссылки, пересылки и приглашения.
                _group_moderate(telegram, settings, message)
                continue
            if message is not None:
                _handle_access_message(telegram, access, scan, settings, state, message)
        except (TelegramError, requests.exceptions.RequestException) as exc:
            print(f"[ACCESS] failed to fully handle update {update.get('update_id')}: {exc}", file=sys.stderr)


# 2026-08-23, round 6: /setkey messages carry a plaintext API secret and
# get deleted right after being processed (see _try_delete_message), but
# that only happens once the bot actually notices the message. Until now
# that was tied to the main scan cycle -- _handle_access_updates() was
# only called once per run_once() pass, which sleeps for POLL_SECONDS
# (60s by default, more for a wider scan universe -- see
# SCAN_POLL_FLOORS) plus however long the scan itself takes. The user
# directly flagged this ("долго исчезает" -- "takes a while to
# disappear"). Fix: run the access-gate polling in its own background
# thread, completely decoupled from the market scan, checking every
# ACCESS_POLL_SECONDS instead -- a /setkey message now gets deleted
# within a few seconds instead of up to a minute-plus. run_once() still
# accepts a poll_access flag (defaulting to True) so --once/--test keep
# handling access messages synchronously themselves, since they don't
# start the background thread (see main()).
ACCESS_POLL_SECONDS = 3


def _access_poll_worker(settings: Settings) -> None:
    """Runs forever in a daemon thread started from main() (forever-loop
    mode only, not --once/--test/--dry-run). Re-reads AccessStore/
    ScanSettings/StateStore fresh every pass, same as run_once() always
    did, so it always sees whatever the Mini App, a /setkey command, or
    the main scan loop's own signal-firing last wrote to disk (the
    StateStore read here, round 8, is what lets /trade's optional
    signal-gate see a signal the scan loop just fired). Broad except so
    one bad pass (Telegram network blip, etc.) never kills the thread --
    it's logged and the loop just tries again next pass, same failure
    handling _handle_access_updates() already does for the errors it
    itself doesn't catch."""
    telegram = TelegramClient(settings.telegram_token, settings.telegram_chat_id)
    while True:
        try:
            access = AccessStore(ACCESS_FILE)
            access.ensure_owner_authorized(settings.telegram_chat_id)
            scan = ScanSettings(SCAN_SETTINGS_FILE)
            state = StateStore(STATE_FILE)
            _handle_access_updates(telegram, access, scan, settings, state)
            _group_sweep(telegram)
        except (TelegramError, requests.exceptions.RequestException) as exc:
            print(f"[ACCESS] background poll failed: {exc}", file=sys.stderr)
        except Exception:
            print("[ACCESS] background poll: unexpected error", file=sys.stderr)
            traceback.print_exc()
        time.sleep(ACCESS_POLL_SECONDS)


# 2026-08-23, round 9: how often the breakeven/partial-take pass runs while
# /autopilot is on -- deliberately much shorter than
# HEALTH_PUBLISH_INTERVAL_SECONDS (15 min): a position that just crossed
# +1R should get its stop moved within seconds, not sit exposed for up to
# 15 minutes waiting on the health-publish cycle. One position-list call
# (plus an occasional trading-stop call) every 20s comfortably fits inside
# Bybit's rate limits for a single-account, few-position bot.
AUTOPILOT_POLL_SECONDS = 20


def _follow_pass(telegram, settings) -> None:
    """2026-11-02: сопровождение сделок, открытых по сигналу (Mini App / терминал). Когда бот-источник
    закрыл свою сделку (обратный сигнал, стоп, тейк, по времени) — закрываем реальную позицию reduce-only
    рынком и шлём уведомление. Только Bybit (у модуля есть close_position)."""
    try:
        from windows_app import challenge_guard as _cg  # noqa: PLC0415
        if not _cg.follow_plans():
            return
        module = EXCHANGE_REGISTRY.get("bybit")
        if module is None or not hasattr(module, "close_position"):
            return
        store = TradeKeysStore(TRADE_KEYS_FILE)
        seen = set()
        for c in (store.get_all().get("bybit"), store.get_all_for_strategy("manual").get("bybit")):
            if not c or c.get("api_key") in seen:
                continue
            seen.add(c.get("api_key"))
            try:
                df = module.fetch_open_positions(c["api_key"], c["api_secret"], c.get("passphrase"))
                positions = df.to_dict("records") if df is not None and not df.empty else []
            except Exception as exc:  # noqa: BLE001
                print(f"[FOLLOW] позиции не получены: {exc}", file=sys.stderr)
                continue
            for x in _cg.follow_check(positions):
                side_ru = "ЛОНГ" if x["pside"] in ("long", "buy") else "ШОРТ"
                try:
                    module.close_position(c["api_key"], c["api_secret"], x["symbol"], x["pside"], x["qty"])
                    _cg.follow_done(x["symbol"], True)
                    upnl = x.get("upnl")
                    telegram.send_message(
                        f"🔄 <b>Авто-выход</b>: {x['symbol']} {side_ru} закрыта по рынку.\n"
                        f"Бот «{x['name']}» вышел из своей сделки: {x['why']}"
                        + (f" ({float(x['r']):+.2f}R у бота)" if x.get("r") is not None else "")
                        + (f"\nПримерный итог по позиции: {float(upnl):+.2f} USDT" if upnl is not None else ""),
                        chat_id=settings.telegram_chat_id)
                except Exception as exc:  # noqa: BLE001
                    _cg.follow_done(x["symbol"], False)
                    telegram.send_message(f"⚠️ Авто-выход {x['symbol']} не получился: {exc}\nЗАКРОЙ позицию вручную "
                                          f"(бот «{x['name']}» уже вышел: {x['why']}).", chat_id=settings.telegram_chat_id)
    except Exception as exc:  # noqa: BLE001
        print(f"[FOLLOW] {exc}", file=sys.stderr)


def _autopilot_worker(settings: Settings) -> None:
    """Runs forever in a daemon thread started from main() (forever-loop
    mode only, not --once/--test/--dry-run) -- same pattern as
    _access_poll_worker above. Re-reads AutopilotSettings/TradeKeysStore
    fresh every pass, so /autopilot on|off and /tradekey both take effect
    immediately, no restart needed.

    Fast no-op loop (just sleeps) while AutopilotSettings.is_enabled() is
    False -- the default, and /autopilot on is the ONLY way to change that
    (see _handle_autopilot_command). Once enabled, for every exchange
    module that implements BOTH fetch_open_positions and amend_stop_loss
    (currently Bybit only) AND has a saved TRADE-permission key (see
    app/trade_keys_store.py -- the SAME key /trade uses, deliberately not a
    separate credential, see app/autopilot.py's module docstring):

      1. fetch that exchange's open positions
      2. decide_breakeven_moves() -- for each move returned, call
         amend_stop_loss() and send a MANDATORY Telegram notification (this
         is the one action here that runs with zero per-call confirmation,
         per the user's explicit "Полностью автоматически" answer)
      3. decide_partial_take_advisories() -- ADVISORY ONLY, never touches
         the exchange; sends a Telegram suggestion, deduped via
         PartialTakeAlertState so the same R level doesn't re-alert every
         ~20s pass (see app/autopilot.py's module docstring for why this
         half of the "Вера" request was deliberately narrowed to advisory
         rather than auto-executed, despite the user's answer nominally
         covering it too)

    Both the auto-move and the advisory are gated behind the SAME
    /autopilot toggle, on purpose -- both need the same live position read
    with the same trade key, so a single on/off switch keeps the mental
    model simple ("autopilot" = the bot is proactively watching your open
    positions) rather than adding a second toggle for a feature that never
    writes to the exchange anyway.

    Broad except per exchange (auth error, network blip) so one bad
    exchange never blocks the others or kills the thread; broad except
    around the whole pass too, matching _access_poll_worker's discipline."""
    telegram = TelegramClient(settings.telegram_token, settings.telegram_chat_id)
    while True:
        _follow_pass(telegram, settings)   # 2026-11-02: работает и при выключенном автопилоте
        try:
            autopilot = AutopilotSettings(AUTOPILOT_SETTINGS_FILE)
            if not autopilot.is_enabled():
                time.sleep(AUTOPILOT_POLL_SECONDS)
                continue

            trade_keys = TradeKeysStore(TRADE_KEYS_FILE).get_all()
            partial_state = PartialTakeAlertState(PARTIAL_TAKE_STATE_FILE)

            # 2026-09-24: плюс ключ субаккаунта ручных ордеров терминала (слот
            # "manual"), чтобы безубыток работал и для позиций на нём.
            manual_keys = TradeKeysStore(TRADE_KEYS_FILE).get_all_for_strategy("manual")
            targets = []
            for exch_key, module in EXCHANGE_REGISTRY.items():
                if not (hasattr(module, "fetch_open_positions") and hasattr(module, "amend_stop_loss")):
                    continue
                for c in (trade_keys.get(exch_key), manual_keys.get(exch_key)):
                    if c and all(c.get("api_key") != t[2].get("api_key") for t in targets):
                        targets.append((exch_key, module, c))

            for exch_key, module, creds in targets:

                try:
                    df = module.fetch_open_positions(creds["api_key"], creds["api_secret"], creds.get("passphrase"))
                    positions = df.to_dict("records") if df is not None and not df.empty else []
                except (ExchangeAuthError, DataError) as exc:
                    print(f"[AUTOPILOT] {exch_key}: couldn't fetch positions: {exc}", file=sys.stderr)
                    continue

                _moves = decide_breakeven_moves(positions, settings.autopilot_breakeven_trigger_r)
                try:   # 2026-11-02: БУ только там, где он дал плюс в тесте (план из Mini App/терминала)
                    from windows_app import challenge_guard as _cg  # noqa: PLC0415
                    _moves = _cg.be_filter(_moves, exch_key)   # 2026-11-03: свечи своей биржи (OKX → OKX)
                except Exception as _exc:  # noqa: BLE001
                    print(f"[AUTOPILOT] be_filter: {_exc}", file=sys.stderr)
                for move in _moves:
                    try:
                        module.amend_stop_loss(creds["api_key"], creds["api_secret"], move["symbol"],
                                                move["new_stop_loss"], creds.get("passphrase"),
                                                side=move.get("side"))
                    except Exception as exc:
                        print(f"[AUTOPILOT] {exch_key} {move['symbol']}: amend_stop_loss failed: {exc}",
                              file=sys.stderr)
                        telegram.send_message(
                            f"⚠️ Автопилот: не удалось перевести стоп в безубыток для {move['symbol']} "
                            f"({module.DISPLAY_NAME}) -- ПРОВЕРЬ позицию вручную: {exc}",
                            chat_id=settings.telegram_chat_id,
                        )
                        continue
                    trail_note = ""
                    # 2026-09-26: режим «безубыток + трейлинг». Расстояние трейлинга =
                    # исходный риск (1R), включается сразу (цена уже ≥ +1R), поэтому
                    # трейлинг-стоп никогда не хуже безубытка; стоп в безубытке
                    # остаётся страховкой. Ставится на бирже -- работает и без компьютера.
                    if autopilot.is_trail() and hasattr(module, "set_trailing_stop"):
                        pos = next((p for p in positions if p.get("symbol") == move["symbol"]), {})
                        risk = abs(move["new_stop_loss"] - move["old_stop_loss"])
                        mark = pos.get("mark_price")
                        if risk > 0 and mark and mark == mark:
                            try:
                                module.set_trailing_stop(creds["api_key"], creds["api_secret"], move["symbol"],
                                                         risk, float(mark), side=move.get("side"))
                                trail_note = f"\n↗️ Трейлинг включён: стоп идёт за ценой на {risk:g} (1R)."
                            except Exception as exc:  # noqa: BLE001 -- безубыток уже стоит
                                trail_note = f"\n⚠️ Трейлинг не поставлен ({exc}) — стоп остался в безубытке."
                    if notify_prefs.is_enabled("autopilot") or trail_note.startswith("\n⚠️"):
                      telegram.send_message(
                        f"🤖 Автопилот: стоп по {move['symbol']} ({module.DISPLAY_NAME}) переставлен в безубыток "
                        f"({move['old_stop_loss']:g} → {move['new_stop_loss']:g}), достигнуто "
                        f"+{move['r_achieved']:g}R.{trail_note}",
                        chat_id=settings.telegram_chat_id,
                    )
                    print(f"[AUTOPILOT] {exch_key} {move['symbol']}: stop moved to breakeven "
                          f"({move['old_stop_loss']:g} -> {move['new_stop_loss']:g}), R={move['r_achieved']:g}")

                for adv in decide_partial_take_advisories(positions, settings.autopilot_partial_take_trigger_r):
                    state_key = f"{exch_key}:{adv['symbol']}"
                    if adv["r_achieved"] <= partial_state.last_advised_r(state_key):
                        continue
                    if notify_prefs.is_enabled("autopilot"):
                      telegram.send_message(
                        f"💡 Автопилот (совет, НЕ автодействие): {adv['symbol']} ({module.DISPLAY_NAME}) "
                        f"прошёл +{adv['r_achieved']:g}R, до тейка ещё далеко. Возможно, стоит зафиксировать "
                        f"часть позиции вручную -- бот делает это только по твоей команде, сам не закрывает.",
                        chat_id=settings.telegram_chat_id,
                    )
                    partial_state.set_last_advised_r(state_key, adv["r_achieved"])
        except (TelegramError, requests.exceptions.RequestException) as exc:
            print(f"[AUTOPILOT] background pass failed: {exc}", file=sys.stderr)
        except Exception:
            print("[AUTOPILOT] background pass: unexpected error", file=sys.stderr)
            traceback.print_exc()
        time.sleep(AUTOPILOT_POLL_SECONDS)


# 2026-08-31: automatic daily AI trading-report digest, requested by the
# user after seeing a third-party bot ("ByTrader"/"Вера") send one
# unprompted every day. Every other AI feature in this project (see
# app/ai_assistant.py's module docstring) is deliberately ON-DEMAND ONLY,
# never called from a background loop, purely for API-cost discipline --
# this is the one deliberate exception, and only because the user was
# explicitly told it adds exactly one extra Anthropic API call per day
# (via AskUserQuestion) and chose to add it anyway ("Да, добавь"). Delivery
# time (23:59 UTC) was also the user's own explicit choice, not a default
# guessed here.
DAILY_REPORT_HOUR_UTC = 23
DAILY_REPORT_MINUTE_UTC = 59


def _seconds_until_next_daily_report() -> float:
    """How long _daily_report_worker should sleep before its next send,
    computed fresh each time (rather than a fixed 24h sleep) so the
    schedule self-corrects instead of drifting -- if a pass runs a few
    seconds late (thread scheduling, a slow AI call), the NEXT wakeup is
    still anchored to the wall-clock target (23:59 UTC) rather than to
    "24h after last time actually ran"."""
    now = datetime.now(timezone.utc)
    target = now.replace(hour=DAILY_REPORT_HOUR_UTC, minute=DAILY_REPORT_MINUTE_UTC, second=0, microsecond=0)
    if target <= now:
        target += timedelta(days=1)
    return (target - now).total_seconds()


def _build_daily_report_text(settings: Settings, state: DailyReportState) -> str | None:
    """Builds the Russian-language daily digest text, or None if no
    exchange is configured at all (mirrors build_health()'s "nothing to
    report" case -- the worker just skips sending that day rather than
    spamming an empty report).

    Deliberately does NOT reuse build_health()/compute_health_from_exchange_trades()
    even though both fetch the same fetch_closed_trades()/fetch_open_positions()
    data -- those are scoped to "this week" (created_time-based, matching
    the risk-budget UI) and return a state/streak shape this feature
    doesn't need. This function instead scopes trades by CLOSE time
    (updated_time >= today's UTC midnight) since a daily P&L report should
    reflect what actually closed today, not what happened to have been
    opened today.

    Per configured exchange (same merged settings.exchange_credentials +
    ExchangeKeysStore(EXCHANGE_KEYS_FILE) credential set every other
    health/report feature in this file uses):
      - closed trades updated today: net PnL, win/loss counts, win rate,
        largest single win/loss
      - open positions right now (if the module implements
        fetch_open_positions): count + total unrealized PnL
      - wallet balance right now (if the module implements
        get_wallet_balance -- Bybit only so far, see app/exchanges/bybit.py):
        compared against the balance THIS SAME report captured ~24h ago
        (DailyReportState -- Bybit doesn't expose historical balance, so
        "start of day" is simply "what we snapshotted at the same UTC time
        yesterday"). The very first report for a given exchange has no
        prior snapshot yet, so it shows the current balance with a note
        instead of a meaningless 0%/undefined return, and starts the chain
        from there for tomorrow's report.

    A failure fetching one exchange's data (bad key, network blip) is
    logged and that exchange is simply omitted from the report, same
    "one broken exchange never blanks the others" discipline as
    build_health()."""
    all_credentials = {**settings.exchange_credentials, **ExchangeKeysStore(EXCHANGE_KEYS_FILE).get_all()}
    if not all_credentials:
        return None

    now = datetime.now(timezone.utc)
    day_start = now.replace(hour=0, minute=0, second=0, microsecond=0)

    blocks: list[str] = []
    stats_for_ai: list[str] = []
    any_exchange_reported = False

    for exch_key, creds in all_credentials.items():
        module = EXCHANGE_REGISTRY.get(exch_key)
        if module is None:
            continue

        try:
            df = module.fetch_closed_trades(creds["api_key"], creds["api_secret"], creds.get("passphrase"))
        except Exception as exc:
            print(f"[DAILY-REPORT] {module.DISPLAY_NAME}: couldn't fetch closed trades: {exc}", file=sys.stderr)
            continue

        any_exchange_reported = True
        today = df[df["updated_time"] >= day_start] if df is not None and len(df) else df
        n_today = len(today) if today is not None else 0

        lines = [f"📌 <b>{module.DISPLAY_NAME}</b>"]
        ai_lines = [f"{module.DISPLAY_NAME}:"]

        if n_today == 0:
            lines.append("Сделок за сегодня не закрыто.")
            ai_lines.append("сделок за сегодня не закрыто.")
        else:
            pnl = today["closed_pnl"]
            net_pnl = float(pnl.sum())
            wins = pnl[pnl > 0]
            losses = pnl[pnl <= 0]
            win_rate = (len(wins) / n_today) * 100
            largest_win = float(wins.max()) if len(wins) else 0.0
            largest_loss = float(losses.min()) if len(losses) else 0.0

            lines.append(f"Чистый PnL за сутки: {net_pnl:+.2f} USDT")
            lines.append(f"Сделок: {n_today} (прибыльных: {len(wins)}, убыточных: {len(losses)}, "
                          f"винрейт: {win_rate:.1f}%)")
            lines.append(f"Крупнейший выигрыш: {largest_win:+.2f} USDT, крупнейший проигрыш: {largest_loss:+.2f} USDT")
            ai_lines.append(f"чистый PnL {net_pnl:+.2f} USDT, {n_today} сделок ({len(wins)}W/{len(losses)}L, "
                             f"винрейт {win_rate:.1f}%), крупнейший выигрыш {largest_win:+.2f}, "
                             f"крупнейший проигрыш {largest_loss:+.2f}.")

        open_count = 0
        open_upnl = 0.0
        if hasattr(module, "fetch_open_positions"):
            try:
                open_df = module.fetch_open_positions(creds["api_key"], creds["api_secret"], creds.get("passphrase"))
                if open_df is not None and len(open_df):
                    open_count = len(open_df)
                    open_upnl = float(open_df["unrealized_pnl"].dropna().sum())
            except Exception as exc:
                print(f"[DAILY-REPORT] {module.DISPLAY_NAME}: couldn't fetch open positions: {exc}", file=sys.stderr)
        lines.append(f"Открытых позиций сейчас: {open_count} (нереализованный PnL: {open_upnl:+.2f} USDT)")
        ai_lines.append(f"открытых позиций сейчас: {open_count} (нереализованный PnL: {open_upnl:+.2f} USDT).")

        if hasattr(module, "get_wallet_balance"):
            try:
                balance_now = module.get_wallet_balance(creds["api_key"], creds["api_secret"], creds.get("passphrase"))
                start_balance = state.get_start_balance(exch_key)
                if start_balance and start_balance > 0:
                    day_return_pct = (balance_now - start_balance) / start_balance * 100
                    lines.append(f"Капитал: {start_balance:.2f} → {balance_now:.2f} USDT "
                                 f"(дневная доходность: {day_return_pct:+.2f}%)")
                    ai_lines.append(f"капитал {start_balance:.2f} -> {balance_now:.2f} USDT "
                                    f"(дневная доходность {day_return_pct:+.2f}%).")
                else:
                    lines.append(f"Капитал сейчас: {balance_now:.2f} USDT "
                                 f"(это первый отчёт -- дневная доходность появится со следующего раза).")
                    ai_lines.append(f"капитал сейчас {balance_now:.2f} USDT (первый отчёт, доходности пока нет).")
                state.set_start_balance(exch_key, balance_now)
            except Exception as exc:
                print(f"[DAILY-REPORT] {module.DISPLAY_NAME}: couldn't fetch wallet balance: {exc}", file=sys.stderr)

        blocks.append("\n".join(lines))
        stats_for_ai.append(" ".join(ai_lines))

    if not any_exchange_reported:
        return None

    report_date = now.strftime("%Y-%m-%d")
    report_text = f"📊 <b>Ежедневный торговый отчёт -- {report_date}</b>\n\n" + "\n\n".join(blocks)

    # Same "only attempt AI, only note if it fails" pattern as /report's
    # existing AI paragraph (see explain_report's call site above) --
    # someone without a configured AI key just gets the plain stats above,
    # no nagging.
    try:
        new_lessons = trader_brain.auto_lessons() + trader_brain.learn_from_stats() + trader_brain.learn_from_bots()
        if resolve_api_key(settings):
            from app.ai_assistant import _call_ai as _cai  # noqa: PLC0415
            wk = trader_brain.weekly_review(lambda sm, um: _cai(sm, um, settings, max_tokens=900))
            if wk:
                report_text += "\n\n🔁 <b>Недельная самопроверка памяти:</b>\n" + _ai_escape(wk)
        report_text += "\n\n" + trader_brain._challenge_text().replace("<", "‹")
        if new_lessons:
            report_text += "\n\n📌 <b>Новые уроки в памяти:</b>\n" + "\n".join("• " + _ai_escape(x) for x in new_lessons)
        stats_for_ai.append(trader_brain.context())
    except Exception as exc:  # noqa: BLE001
        print(f"[BRAIN] daily: {exc}", file=sys.stderr)
    if resolve_api_key(settings):
        digest = daily_digest("\n".join(stats_for_ai), settings)
        if digest:
            try:
                trader_brain.lesson_from_digest(digest)
            except Exception:  # noqa: BLE001
                pass
            report_text += "\n\n🧠 <b>Разбор от ИИ:</b>\n" + _ai_escape(digest)
        else:
            report_text += "\n\n⚠️ Разбор от ИИ сейчас недоступен (проверь ключ или попробуй позже)."

    return report_text


def _daily_report_worker(settings: Settings) -> None:
    """Runs forever in a daemon thread started from main() (forever-loop
    mode only) -- same discipline as _access_poll_worker/_autopilot_worker:
    broad exception handling so one bad pass (network blip, AI call
    failure, bad key) never kills the thread, and the schedule always
    self-corrects via _seconds_until_next_daily_report() rather than
    drifting. Re-creates DailyReportState fresh each pass (cheap, tiny
    JSON file) so it always reads/writes the latest snapshot."""
    telegram = TelegramClient(settings.telegram_token, settings.telegram_chat_id)
    while True:
        time.sleep(_seconds_until_next_daily_report())
        try:
            state = DailyReportState(DAILY_REPORT_STATE_FILE)
            report_text = _build_daily_report_text(settings, state)
            if report_text and not notify_prefs.is_enabled("daily"):
                print("[DAILY-REPORT] muted by /notify.")
            elif report_text:
                telegram.send_message(report_text, chat_id=settings.telegram_chat_id)
                print("[DAILY-REPORT] sent daily digest.")
            else:
                print("[DAILY-REPORT] no exchange configured -- skipping today's report.")
        except (TelegramError, requests.exceptions.RequestException) as exc:
            print(f"[DAILY-REPORT] failed to send: {exc}", file=sys.stderr)
        except Exception:
            print("[DAILY-REPORT] unexpected error", file=sys.stderr)
            traceback.print_exc()


def _maybe_check_psycho_alerts(settings: Settings, telegram: TelegramClient | None, health: dict) -> None:
    """2026-08-23, round 9 ("Вера" trading-assistant features): pushes an
    advisory Telegram message when a source's losing-streak or last-trade-
    size crosses a threshold -- see app/psycho_heuristics.py for the exact
    rules and app/psycho_state.py for how repeat-alert spam is avoided.
    Called from _maybe_publish_health right after `health` is computed
    there, so this never triggers its own extra exchange fetch. Runs
    regardless of whether GITHUB_TOKEN is set (unlike the health.json
    publish itself) -- these are pushed messages, not something that needs
    the Mini App/GitHub Pages pipeline at all. Every failure mode here is
    logged and swallowed, same discipline as the rest of this function --
    a broken alert must never take down the scan loop.

    2026-09-22, round 2: telegram.send_message() has no retry/timeout
    handling of its own (plain requests.post(timeout=20)) -- on a flaky
    connection the message can reach Telegram (and the owner's phone)
    just fine while the HTTP response back to THIS process times out or
    the socket resets (ConnectTimeout/ReadTimeout/SSLEOFError, all
    observed live on 2026-09-22). That exception used to propagate out of
    the loop below and skip BOTH set_last_notified_* calls entirely -- so
    the dedup state stayed at its old value even though the alert had
    already gone out, and the SAME threshold-crossing fired again every
    15-minute publish cycle for hours (the exact spam round 9 was
    supposed to fix, just via a different trigger). Send is now wrapped
    in its own try/except so a delivery-confirmation failure can no
    longer roll back the dedup write -- worst case with this change is a
    genuinely-new alert getting swallowed by a real network outage, which
    is far better than an old one repeating forever."""
    if telegram is None:
        return
    try:
        psycho_state = PsychoAlertState(PSYCHO_STATE_FILE)
        for key, h in health.get("sources", {}).items():
            display_name = h.get("display_name", key)
            last_streak = psycho_state.last_notified_streak(key)
            last_ratio = psycho_state.last_notified_ratio(key)
            messages, new_last_streak, new_last_ratio = check_psycho_alerts(
                h, display_name, last_streak, last_ratio)
            for msg in messages:
                if not notify_prefs.is_enabled("psycho"):
                    print(f"[PSYCHO] muted by /notify: {msg.splitlines()[0][:80]}")
                    continue
                try:
                    telegram.send_message(msg, chat_id=settings.telegram_chat_id)
                except Exception as exc:
                    print(f"[PSYCHO] send failed for {key} (dedup state will still be "
                          f"marked notified, so this won't repeat next cycle): {exc}",
                          file=sys.stderr)
            if new_last_streak != last_streak:
                psycho_state.set_last_notified_streak(key, new_last_streak)
            if new_last_ratio != last_ratio:
                psycho_state.set_last_notified_ratio(key, new_last_ratio)
    except Exception:
        print("[PSYCHO] unexpected error checking alerts", file=sys.stderr)
        traceback.print_exc()


def _maybe_publish_position_charts(settings: Settings, health: dict) -> None:
    """2026-08-25, round 16 follow-up: the user pointed out that the
    bot's OWN signal-alert chart already draws entry/SL/TP directly on
    the candles (see app/chart.py's render_signal_card, used for every
    /trade-worthy signal since round 1) and asked why the Торговля tab's
    open-position display can't do the same -- a fair point, since the
    earlier round-16 answer ("TradingView's free embed can't draw lines")
    is true of that specific third-party widget, not of this bot's own
    charting. This renders one PNG per currently-open position (via the
    new app/chart.py render_position_chart()) and publishes it to the
    same GitHub Pages repo health.json already lives in, via the new
    app/github_sync.push_binary_file() -- so the Mini App can just fetch
    a static image URL, same "no live backend needed" pattern as
    health.json/access.json.

    Called from _maybe_publish_health right after `health` is computed
    there (same throttled ~15-min cadence, same reasoning as the
    psycho-alert check above: this never triggers its own extra exchange
    fetch, only a public kline fetch per open position). A position is
    skipped (not charted) if it has no symbol or no entry price -- there
    is nothing meaningful to draw without at least those two. stop_loss/
    take_profit/mark_price are each drawn only if actually present (see
    render_position_chart's own docstring for why nothing is invented to
    force a line to appear). A failure charting or publishing ONE
    position (a bad kline fetch, a GitHub API hiccup) is logged and
    skipped -- it must never block the other positions or the health.json
    publish that follows this call."""
    if not settings.github_token:
        return
    for exch_key, source in health.get("sources", {}).items():
        for pos in source.get("open_positions") or []:
            symbol = pos.get("symbol")
            entry = pos.get("avg_entry_price")
            if not symbol or entry is None:
                continue
            try:
                # 2026-09-24: у OKX символ вида JTO-USDT-SWAP, а свечи берём с
                # Bybit, где та же монета называется JTOUSDT.
                kline_symbol = symbol.upper().replace("-SWAP", "").replace(":USDT", "").replace("-", "").replace("/", "")
                df = get_klines(kline_symbol, "15m", limit=150)
                png = chart.render_position_chart(
                    df=df, symbol_label=kline_symbol.replace("USDT", ""), timeframe="15m",
                    side=pos.get("side") or "buy", entry=entry,
                    stop_loss=pos.get("stop_loss"), take_profit=pos.get("take_profit"),
                    mark_price=pos.get("mark_price"),
                )
                push_binary_file(
                    settings.github_token, settings.github_repo,
                    f"position_charts/{exch_key}_{symbol}.png", png,
                    message=f"chore: update position chart {exch_key}/{symbol} (automated)",
                )
            except (DataError, GitHubSyncError, requests.exceptions.RequestException, OSError) as exc:
                print(f"[POSITION-CHART] {exch_key}/{symbol}: {exc}", file=sys.stderr)
            except Exception:
                print(f"[POSITION-CHART] unexpected error rendering/publishing {exch_key}/{symbol}", file=sys.stderr)
                traceback.print_exc()


def _maybe_publish_health(settings: Settings, telegram: TelegramClient | None = None) -> None:
    """2026-08-23: auto-refresh for the Mini App's "Здоровье" tab. This was
    originally a deliberately MANUAL step (run `python publish_health.py`
    by hand after updating the journal) -- the user asked for it to just
    happen automatically instead, so: this piggybacks on the bot's own
    poll loop -- every HEALTH_PUBLISH_INTERVAL_SECONDS, recompute and
    republish health.json. Still requires GITHUB_TOKEN (site sync).

    2026-08-23, same day, round 2: the user then asked how the bot could
    "see" their trades at all -- until this point every number came from
    hand-typing rows into live_trade_journal.csv, which "automatic
    publish" doesn't automate away. Added a second, genuinely automatic
    source: if any exchange's <PREFIX>_API_KEY/_SECRET(/_PASSPHRASE) are
    set (READ-ONLY keys, see app/exchanges/), publish_health.build_health()
    pulls real closed trades straight from those accounts instead -- no
    manual entry at all. Started Bybit-only, redesigned the same day into
    a multi-exchange pipeline (OKX/Bitget/MEXC/KuCoin/Gate.io alongside
    Bybit) once the user said they trade on several. Falls back to the CSV
    automatically if no exchange is configured, or if every configured
    exchange's fetch fails; build_health() owns that decision now, not
    this function (see its own docstring). This function just calls it,
    stamps a timestamp, and publishes.

    Runs on the FIRST cycle too (module-level _last_health_publish_at
    starts at 0), so a freshly (re)started bot updates the tab right away
    instead of waiting a full interval. Every failure mode here (GitHub
    API error, network blip, unexpected data shape) is logged and
    swallowed -- this must never be able to take down the market-scan loop
    over a side feature.

    2026-08-23, same day, round 4: build_health() no longer returns one
    flat dict -- each source (exchange, or the CSV journal) is reported
    separately under health["sources"] now, since the user found a single
    number blended across several exchanges confusing (see build_health()'s
    own docstring). This function's job doesn't otherwise change; the
    summary line below just walks `sources` instead of reading top-level
    trades_total/state keys that no longer exist.

    2026-08-23, round 9: previously this function's very first check was
    `if not settings.github_token: return`, which meant the psycho-alert
    push below never ran at all unless GitHub Pages sync was configured --
    wrong, since those alerts are plain Telegram messages with nothing to
    do with the site pipeline. Restructured so `health` is always computed
    (still throttled to once per HEALTH_PUBLISH_INTERVAL_SECONDS) and
    _maybe_check_psycho_alerts() always runs on it; the GITHUB_TOKEN check
    now only gates the GitHub push step that follows."""
    global _last_health_publish_at
    now = time.time()
    if now - _last_health_publish_at < HEALTH_PUBLISH_INTERVAL_SECONDS:
        return
    _last_health_publish_at = now

    try:
        health = publish_health.build_health(settings, journal_path=LIVE_JOURNAL_FILE, recent_n=10)
        health["generated_at"] = datetime.now().isoformat(timespec="seconds")
        try:   # 2026-10-28: сигналы ПРОВЕРЕННЫХ стратегий (бумажные боты) — для Mini App, раздел «Сигналы»
            from windows_app import tested_signals as _ts  # noqa: PLC0415
            health["tested_signals"] = _ts.build()
            try:   # 2026-11-09: сигналы с оценкой «можно брать», суммами под счета и правилом «только лонги» — для Mini App
                from windows_app import challenge_guard as _cg2  # noqa: PLC0415
                keep = ("symbol", "side", "name", "entry", "sl", "tp", "since", "v", "vt", "size", "hh", "okx", "dur", "bot")
                health["tested_signals"]["active"] = [{k: x.get(k) for k in keep} for x in _cg2.active_list(40)]
                health["tested_signals"]["pick"] = json.loads((Path(__file__).resolve().parent / "strat_pick.json").read_text(encoding="utf-8"))
            except Exception as _e2:  # noqa: BLE001
                health["tested_signals"]["active_error"] = str(_e2)[:120]
        except Exception as _exc:  # noqa: BLE001
            health["tested_signals"] = {"signals": [], "bots": [], "error": str(_exc)[:120]}
    except Exception:
        print("[HEALTH] unexpected error computing health.json", file=sys.stderr)
        traceback.print_exc()
        return

    _maybe_check_psycho_alerts(settings, telegram, health)
    _maybe_publish_position_charts(settings, health)

    try:   # 2026-11-21: журнал сигналов Mini App — считается и ведётся локально
        # всегда; в GitHub публикуется только при наличии файла-флага
        # signals_log_publish.flag (владелец запретил публикацию без подтверждения).
        from app import signals_log as _sl  # noqa: PLC0415
        _sl.update_and_maybe_publish(settings)
    except Exception:  # noqa: BLE001
        traceback.print_exc()

    if not settings.github_token:
        return
    try:
        push_json_file(settings.github_token, settings.github_repo, "health.json", health,
                        message="Update health.json (auto)")
        summary = ", ".join(
            f"{h.get('display_name', key)}: {h['trades_total']} trades, {h['state']}"
            for key, h in health["sources"].items())
        print(f"[HEALTH] published ({health['mode']}) -- {summary}")
    except (GitHubSyncError, requests.exceptions.RequestException, OSError) as exc:
        print(f"[HEALTH] publish failed: {exc}", file=sys.stderr)
    except Exception:
        print("[HEALTH] unexpected error publishing health.json", file=sys.stderr)
        traceback.print_exc()


def run_once(settings: Settings, dry_run: bool = False, poll_access: bool = True) -> str:
    """One pass of everything this process still does on a timer: the
    access-gate/scan-picker inbox check and the health-tab publish. See
    the module docstring's RETIRED note -- the CHoCH+OB+FVG market scan
    that used to also run here (process_symbol() per watchlist symbol)
    is gone, so this is now a light pass, not a scan.

    Still returns the active scan mode (see app/scan_settings.py) so
    main()'s forever loop can size its sleep interval via
    SCAN_POLL_FLOORS -- /scan itself is kept (vestigial, see module
    docstring), so this stays a real, live value, not a stub.

    poll_access=False (2026-08-23, round 6) lets main()'s forever loop
    skip the access-gate check here, since it now runs it much faster in
    a dedicated background thread instead (see _access_poll_worker) --
    doing it in both places would have two independent readers/writers
    racing on the same access.json file. --once still passes the
    default True since it never starts that thread."""
    state = StateStore(STATE_FILE)
    telegram = None if dry_run else TelegramClient(settings.telegram_token, settings.telegram_chat_id)
    scan = ScanSettings(SCAN_SETTINGS_FILE)
    if telegram is not None:
        access = AccessStore(ACCESS_FILE)
        access.ensure_owner_authorized(settings.telegram_chat_id)
        if poll_access:
            _handle_access_updates(telegram, access, scan, settings, state)

    if not dry_run:
        _maybe_publish_health(settings, telegram)

    return scan.mode


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--once", action="store_true", help="Run a single pass and exit")
    parser.add_argument("--dry-run", action="store_true", help="Don't call Telegram; just run the pass locally")
    args = parser.parse_args()

    # 2026-09-22: без этой защиты две копии бота одновременно дёргали
    # getUpdates, и Telegram выбивал их по очереди —
    # "409 Conflict: terminated by other getUpdates request". В логе
    # windows_app_logs/telegram.log таких ответов набралось больше десятка
    # подряд: бот выглядел упавшим, хотя процесс был жив и просто не мог
    # получить ни одного апдейта. Живые боты (latuserge, kc_roc) эту
    # защиту используют с самого начала, Telegram-бот её не имел.
    # Блокировка файловая: если процесс падает, ОС снимает её сама.
    # --dry-run в Telegram не ходит, ему блокировка не нужна.
    if not args.dry_run:
        single_instance.acquire_or_exit("main")

    settings = Settings.load()
    if not args.dry_run and (not settings.telegram_token or not settings.telegram_chat_id):
        print("TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID not set. Use --dry-run to test without Telegram, "
              "or fill in .env (see .env.example).", file=sys.stderr)
        sys.exit(1)
    if not args.dry_run and not settings.github_token:
        print("[INFO] GITHUB_TOKEN not set in .env -- invite codes still work for the bot itself, "
              "but won't be published for the SMC Radar website to check. See app/github_sync.py / "
              "the miniapp project doc if you want the same code to also unlock the site.", file=sys.stderr)

    if not args.dry_run:
        _register_bot_commands(settings)

    if args.once:
        run_once(settings, args.dry_run)
        return

    scan_mode = ScanSettings(SCAN_SETTINGS_FILE).mode
    print(f"Running on {settings.timeframe} "
          f"(CHoCH+OB+FVG market scan retired 2026-09-06, see module docstring -- this pass now only "
          f"does the access gate + health publish), "
          f"access gate: one-time invite codes (say /newcode in your own chat to generate one), "
          f"scan universe setting: {SCAN_MODE_LABELS[scan_mode]} (vestigial, say /scan in your own chat to change), "
          f"site sync: {'on' if settings.github_token else 'off (GITHUB_TOKEN not set)'}, "
          f"health tab: {'off (GITHUB_TOKEN not set)' if not settings.github_token else ('auto from ' + ', '.join(e.upper() for e in settings.exchange_credentials) + ' (read-only), every ' if settings.exchange_credentials else 'auto from live_trade_journal.csv, every ') + str(HEALTH_PUBLISH_INTERVAL_SECONDS // 60) + 'min'}, "
          f"polling every {settings.poll_seconds}s, "
          f"access-gate messages (/setkey etc.) checked every {ACCESS_POLL_SECONDS}s, "
          f"breakeven-autopilot: {'ON -- ' + str(AUTOPILOT_POLL_SECONDS) + 's checks (say /autopilot off in your own chat to disable)' if AutopilotSettings(AUTOPILOT_SETTINGS_FILE).is_enabled() else 'off (say /autopilot on in your own chat to enable)'}, "
          f"instant trade-server: {'ON, listening on 127.0.0.1:' + str(settings.trade_server_port) + ' (say /instanttrade off in your own chat for the fast kill switch)' if settings.trade_server_enabled else 'off (TRADE_SERVER_ENABLED not set in .env)'}, "
          f"AI features: {'configured (model ' + settings.ai_model + ')' if resolve_api_key(settings) else 'not configured (say /setaikey in your own chat to add a key)'}, "
          f"daily AI report: {DAILY_REPORT_HOUR_UTC:02d}:{DAILY_REPORT_MINUTE_UTC:02d} UTC every day. "
          f"Ctrl+C to stop.")

    if not args.dry_run:
        # 2026-08-23, round 6: dedicated fast poller for /setkey and the
        # rest of the access gate -- see _access_poll_worker's docstring.
        # daemon=True so it never blocks process exit (Ctrl+C).
        threading.Thread(target=_access_poll_worker, args=(settings,), daemon=True, name="access-poll").start()
        # 2026-08-23, round 9 ("Вера"): started unconditionally, same as
        # the access-poll thread above -- _autopilot_worker itself is a
        # fast no-op loop whenever AutopilotSettings.is_enabled() is False
        # (the default), so there's no cost to always running the thread
        # and letting /autopilot on|off control behavior live, no restart.
        threading.Thread(target=_autopilot_worker, args=(settings,), daemon=True, name="autopilot-poll").start()
        # 2026-08-31: automatic daily AI trading-report digest (see
        # _daily_report_worker's own docstring for why this is a
        # deliberate, user-opted-in exception to the "AI is on-demand
        # only" rule). Started unconditionally like the two threads above
        # -- the worker itself just sleeps until 23:59 UTC and is a no-op
        # the rest of the time, so there's no cost to always running it.
        threading.Thread(target=_daily_report_worker, args=(settings,), daemon=True, name="daily-report").start()
        # 2026-09-24: исходы сигналов /aiidea и /aipick (тейк/стоп) — см. app/signal_journal.py
        threading.Thread(target=_signal_tracker_worker, args=(settings,), daemon=True, name="signal-tracker").start()
        # 2026-08-25, round 14: local trade-server for instant execution
        # (see app/trade_server.py). Unlike the two threads above, this
        # one is a no-op unless TRADE_SERVER_ENABLED=true in .env -- when
        # off, it still runs once to publish server_url.json={"url": null}
        # so the Mini App never keeps calling a stale tunnel from an
        # earlier, since-disabled run.
        maybe_start_trade_server(settings)
        # 2026-09-25: «Отправить ордер» из Mini App -> превью с кнопками в чате
        from app import trade_server as _ts_mod  # noqa: PLC0415
        _ts_tg = TelegramClient(settings.telegram_token, settings.telegram_chat_id)
        _ts_mod.PREVIEW_HOOK = lambda params: _send_trade_preview(
            _ts_tg, settings.telegram_chat_id, params, settings, note="из Mini App")

    while True:
        mode = run_once(settings, args.dry_run, poll_access=args.dry_run)
        time.sleep(_effective_poll_seconds(settings.poll_seconds, mode))


if __name__ == "__main__":
    main()
