"""restart_tg.py — 2026-11-02: перезапуск Telegram-бота (bot/main.py) на новом коде.
Находит python-процессы, у которых в командной строке именно bot\\main.py (или «main.py» с папкой бота),
завершает их и запускает заново той же командой в новом окне консоли."""
import json, subprocess, time
from pathlib import Path
BOT = Path(__file__).resolve().parent
_diag = BOT / "diag_run.flag"                 # 2026-11-02: разовая диагностика вместо перезапуска
if _diag.exists():
    _diag.unlink()
    r = subprocess.run([__import__("sys").executable, "-X", "utf8", str(BOT / "diag6.py")], cwd=str(BOT), capture_output=True,
                       text=True, encoding="utf-8", errors="replace", timeout=50)
    print(r.stdout[-3000:], r.stderr[-1500:])
    raise SystemExit(0)
_flag = BOT / "restart_panel.flag"            # 2026-11-02: тем же вызовом можно перезапустить панель
if _flag.exists():
    _flag.unlink()
    _fl = subprocess.CREATE_NO_WINDOW | subprocess.CREATE_NEW_PROCESS_GROUP
    _a = [__import__("sys").executable, "-X", "utf8", str(BOT / "restart_panel.py")]
    try:
        subprocess.Popen(_a, cwd=str(BOT), creationflags=_fl | 0x01000000)   # CREATE_BREAKAWAY_FROM_JOB
    except OSError:
        subprocess.Popen(_a, cwd=str(BOT), creationflags=_fl)
    print("панель перезапускается (restart_panel.py)")
    raise SystemExit(0)
ps = ("Get-CimInstance Win32_Process -Filter \"Name like 'python%'\" | "
      "Select-Object ProcessId,ParentProcessId,CommandLine,ExecutablePath | ConvertTo-Json -Compress")
out = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True).stdout.strip() or "[]"
procs = json.loads(out); procs = procs if isinstance(procs, list) else [procs]
for p in procs:
    print("PY:", p.get("ProcessId"), p.get("CommandLine"))
def is_main(cl):
    cl = (cl or "").replace("/", "\\").lower()
    toks = [t.strip('"') for t in cl.split()]
    return any(t.endswith("\\bot\\main.py") or t == "main.py" for t in toks)
hits = [p for p in procs if is_main(p.get("CommandLine"))]
print("К ПЕРЕЗАПУСКУ:", [(p["ProcessId"], p["CommandLine"]) for p in hits])
venv = BOT / "venv" / "Scripts" / "python.exe"
cmd = hits[0]["CommandLine"] if hits else f'"{venv}" -u main.py'
if not hits:
    print("main.py не был запущен — запускаю")
for p in hits:
    subprocess.run(["taskkill", "/PID", str(p["ProcessId"]), "/F"], capture_output=True)
    print("остановлен", p["ProcessId"])
# 2026-11-07: ngrok — дочерний процесс main.py. После taskkill main.py он оставался «сиротой» с переполненным
# выводом и держал домен → приложение «ПК не отвечает» (ngrok 404). Убиваем все ngrok, новый main.py поднимет свой.
r = subprocess.run(["taskkill", "/IM", "ngrok.exe", "/F", "/T"], capture_output=True, text=True)
print("ngrok:", (r.stdout or r.stderr).strip()[:200])
time.sleep(3)
(BOT / "logs").mkdir(exist_ok=True)
lg = open(BOT / "logs" / "telegram_bot.log", "a", encoding="utf-8", errors="replace")
subprocess.Popen(cmd, cwd=str(BOT), stdout=lg, stderr=subprocess.STDOUT,            # без окна; лог — logs\telegram_bot.log
                 creationflags=subprocess.CREATE_NO_WINDOW | subprocess.CREATE_NEW_PROCESS_GROUP)
print("запущен заново:", cmd)
