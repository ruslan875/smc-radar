# -*- coding: utf-8 -*-
"""Combo OTM (сборки подписчика) на РЕАЛЬНЫХ данных бирж OKX и Bybit: перпы 1h + открытый интерес (nOI).
Запуск: python combo_exchanges.py  (первый раз качает ~3–8 минут, потом из кэша market_cache/exch)
Результат: combo_exchanges_report.txt"""
import os, sys, time, json, glob, urllib.request
import pandas as pd
try: sys.stdout.reconfigure(encoding="utf-8")
except Exception: pass
H = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, H)
from combo_full import run, summarize, load_settings_csv, default_config
CACHE = os.path.join(H, "market_cache", "exch"); os.makedirs(CACHE, exist_ok=True)
START = int(pd.Timestamp("2023-06-01", tz="UTC").timestamp() * 1000)
COINS = ["XRP", "BTC", "ETH", "SOL", "DOGE", "ADA", "LINK", "LTC", "BNB", "AVAX"]

def get(u):
    for k in range(6):
        try:
            return json.loads(urllib.request.urlopen(urllib.request.Request(u, headers={"User-Agent": "Mozilla/5.0"}), timeout=25).read())
        except Exception as e:
            print("  повтор", str(e)[:60]); time.sleep(2 + k * 2)
    return None

def okx_candles(c):
    inst = f"{c}-USDT-SWAP"; rows = []; after = ""
    while True:
        j = get(f"https://www.okx.com/api/v5/market/history-candles?instId={inst}&bar=1H&limit=100" + (f"&after={after}" if after else ""))
        d = (j or {}).get("data") or []
        if not d: break
        rows += [[int(r[0]), *map(float, r[1:6])] for r in d]
        after = d[-1][0]
        if int(after) < START: break
        time.sleep(0.12)
    return rows

def okx_oi(c):
    # OKX отдаёт историю OI 1H только за последние ~30 дней через rubik; дольше — нет. Возьмём что есть.
    j = get(f"https://www.okx.com/api/v5/rubik/stat/contracts/open-interest-volume?ccy={c}&period=1H")
    return [[int(r[0]), float(r[1])] for r in ((j or {}).get("data") or [])]

def bybit_candles(c):
    sym = f"{c}USDT"; rows = []; end = int(time.time() * 1000)
    while end > START:
        j = get(f"https://api.bybit.com/v5/market/kline?category=linear&symbol={sym}&interval=60&limit=1000&end={end}")
        d = ((j or {}).get("result") or {}).get("list") or []
        if not d: break
        rows += [[int(r[0]), *map(float, r[1:6])] for r in d]
        end = int(d[-1][0]) - 1; time.sleep(0.12)
    return rows

def bybit_oi(c):
    sym = f"{c}USDT"; rows = []; end = int(time.time() * 1000)
    while end > START:
        j = get(f"https://api.bybit.com/v5/market/open-interest?category=linear&symbol={sym}&intervalTime=1h&limit=200&endTime={end}")
        d = ((j or {}).get("result") or {}).get("list") or []
        if not d: break
        rows += [[int(r["timestamp"]), float(r["openInterest"])] for r in d]
        end = int(d[-1]["timestamp"]) - 1; time.sleep(0.12)
    return rows

def dataset(ex, c):
    f = os.path.join(CACHE, f"{ex}_{c}_1h.csv")
    if os.path.exists(f) and time.time() - os.path.getmtime(f) < 86400:
        d = pd.read_csv(f, index_col=0, parse_dates=True); return d
    print(f"скачиваю {ex} {c} ...")
    cand = okx_candles(c) if ex == "okx" else bybit_candles(c)
    if not cand: return None
    d = pd.DataFrame(cand, columns=["t", "open", "high", "low", "close", "volume"]).drop_duplicates("t").sort_values("t")
    d.index = pd.to_datetime(d.t, unit="ms"); d = d.drop(columns="t")
    oi = okx_oi(c) if ex == "okx" else bybit_oi(c)
    if oi:
        o = pd.DataFrame(oi, columns=["t", "oi"]).drop_duplicates("t"); o.index = pd.to_datetime(o.t, unit="ms")
        d["oi"] = o["oi"].reindex(d.index)
    d.to_csv(f); return d

def main():
    subs = {}
    for f in sorted(glob.glob(os.path.join(H, "combo_sub*.csv"))):
        subs[os.path.basename(f)] = load_settings_csv(f)[0]
    if not subs: sys.exit("нет CSV настроек (combo_sub1.csv / combo_sub2.csv рядом со скриптом)")
    out = []; p = lambda s: (print(s, flush=True), out.append(s))
    for ex in ("okx", "bybit"):
        ref = dataset(ex, "BTC")
        for c in COINS:
            d = dataset(ex, c)
            if d is None or len(d) < 500: p(f"{ex} {c}: нет данных"); continue
            oi_note = f"OI с {d['oi'].first_valid_index():%Y-%m-%d}" if "oi" in d and d["oi"].notna().any() else "OI нет"
            for nm, cfg in subs.items():
                for s, e in (("2024-01-01", "2026-12-31"), ("2024-01-01", "2025-01-01"), ("2025-01-01", "2026-12-31")):
                    if d.index[0] > pd.Timestamp(s) + pd.Timedelta(days=30): continue
                    tr, dd, fin, st = run(d, cfg, ref, s, e); r = summarize(tr, dd, fin)
                    p(f"{ex:5} {c:5} {nm[:28]:28} {s[:4]}..{e[:4]}  итог {r['net']:+7.1f}%  DD {r['dd']:5.1f}%  сделок {r['trades']:4}  win {r['win']:4.1f}%  PF {r['pf']:.2f}  ({oi_note})")
    open(os.path.join(H, "combo_exchanges_report.txt"), "w", encoding="utf-8").write("\n".join(out))
    print("\nГотово: combo_exchanges_report.txt")

if __name__ == "__main__":
    main()
