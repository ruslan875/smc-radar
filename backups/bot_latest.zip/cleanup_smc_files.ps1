# cleanup_smc_files.ps1
# 2026-09-06: moves files that are only leftovers from the retired
# CHoCH+OrderBlock+FVG detector (main.py no longer uses them - see
# claude/dca-bot-reverse-engineering-2026-09-04.md, the main.py cleanup
# section). Nothing is permanently deleted - files are moved into a
# _to_delete_smc subfolder so you can double check before deleting them
# for real.
#
# Usage: open PowerShell IN THIS FOLDER (smc-signal-bot) and run:
#   .\cleanup_smc_files.ps1
# If it complains about execution policy, run this once first:
#   Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass

$ErrorActionPreference = "Continue"
$dest = Join-Path $PSScriptRoot "_to_delete_smc"
New-Item -ItemType Directory -Force -Path $dest | Out-Null

# Confirmed via "import app.smc" grep - these are genuinely SMC-only
$files = @(
    "backtest.py",
    "market_scanner.py",
    "compare_timeframes.py",
    "exit_variant_sweep.py",
    "stop_buffer_sweep.py",
    "tp_compression_sweep.py",
    "trailing_backtest.py",
    "scan_top_symbols.py",
    "regime_analysis.py",
    "autotrade_settings.json",
    "autotrade_state.json"
)

foreach ($f in $files) {
    $src = Join-Path $PSScriptRoot $f
    if (Test-Path $src) {
        Move-Item -Path $src -Destination $dest -Force
        Write-Host "Moved: $f"
    } else {
        Write-Host "Not found (already deleted/renamed?): $f"
    }
}

# There's a suspicious folder backtest_out_ext - possibly output from
# backtest.py. Not moved automatically (not verified), just flagged.
if (Test-Path (Join-Path $PSScriptRoot "backtest_out_ext")) {
    Write-Host ""
    Write-Host "NOTE: found a folder called backtest_out_ext - looks like it" -ForegroundColor Yellow
    Write-Host "could be old output from backtest.py, but this was not verified." -ForegroundColor Yellow
    Write-Host "Check its contents yourself and move it into $dest manually" -ForegroundColor Yellow
    Write-Host "if you confirm it's old backtest.py output." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "Done. Files were moved to: $dest"
Write-Host "Check that nothing important ended up there, then delete that"
Write-Host "folder yourself for good once you're sure - this script"
Write-Host "deliberately does not delete anything permanently."
