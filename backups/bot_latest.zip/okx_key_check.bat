@echo off
cd /d D:\VANTORIX\bot
venv\Scripts\python.exe okx_key_check.py
