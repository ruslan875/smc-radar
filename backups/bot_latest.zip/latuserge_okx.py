#!/usr/bin/env python3
"""
Live (real-money-capable) executor for "LONG_STRATEGY 15" (latuserge),
validated in long_strategy15_latuserge_backtest.py and, for
liquidation/leverage risk specifically, in
long_strategy15_latuserge_mae_backtest.py -- see
dca-bot-reverse-engineering-2026-09-04.md's "2026-09-05/06: MAE ...
COMPLETE on all 5/5 symbols" section for the numbers this script is acting
on: n=387 across ETH/SOL/ARB/INJ/TIA, 98.2% gross win rate, +0.87% net
avg P&L (Bybit taker+maker fees), all fee scenarios positive.

WHY THIS SCRIPT EXISTS (decided with the user 2026-09-06): the live
CHoCH+Ордерблок+FVG (Smart Money Concept) signal bot in smc-radar-miniapp
was found to be losing money / thin-edge (see
claude/smc-radar-miniapp-2026-08-22.md's 2026-09-04 hotfix note and
claude/smc-bot-backtest-2026-08-17.md). The user decided to STOP trading
that SMC setup live and REPLACE it with latuserge, the most thoroughly
validated strategy in this whole project. kc_roc_cci_wt_grid_live.py is a
COMPLETELY SEPARATE bot/strategy and is explicitly NOT touched by this
change -- it keeps running exactly as before, independently, on its own
watchlist and its own capital.

SAFETY DEFAULT -- READ THIS BEFORE ANYTHING ELSE: without --live, this
script places ZERO real orders. It polls real live Bybit prices and
simulates every fill/exit in software using the SAME entry/grid/exit
decision functions as long_strategy15_latuserge_backtest.py (imported
directly, not reimplemented, for the same reason kc_roc_cci_wt_grid_live.py
gives: for a live-MONEY script, byte-identical decisions to what was
actually split-validated matter more than standalone-ness). Only pass
--live once you've watched dry-run for a while and the logged deals in
--log-csv look sane next to long_strategy15_latuserge_backtest_out*/*.csv.

TWO DESIGN DECISIONS MADE HERE THAT ARE **NOT** PART OF THE VALIDATED
BACKTEST -- READ BEFORE USING --live:

  1. GATED, SEQUENTIAL GRID EXECUTION (engineering necessity, not a
     strategy change). latuserge's 6-order grid is fundamentally
     different from kc_roc_cci_wt_grid's: only ONE leg can fill at a
     time, and each leg (orders 2-6) requires BOTH a price touch (the
     just-closed bar's low reaching that leg's limit price) AND its own
     indicator condition (e.g. order 2 needs ADX(15m) > 40 AND
     CMO(30m) > -90) to be true on that SAME bar -- see GRID /
     order_conditions in the backtest module. This means grid legs CANNOT
     be pre-placed as static resting limit orders the way
     kc_roc_cci_wt_grid_live.py does. Instead, this script actively
     re-evaluates the next pending leg's price-touch + indicator
     condition on every poll cycle (one check per cycle, matching the
     backtest's own one-leg-per-bar granularity exactly -- see
     simulate_symbol() in the backtest module, which likewise only
     advances next_order_idx by at most one step per bar even if a
     single candle's range would technically span multiple grid levels)
     and, only when both are true, fires that leg as a REAL MARKET order
     (not a resting limit) so the fill is immediate and certain. Minor
     known approximation: the leg is sized off its nominal limit price,
     not the live market price it actually fills at -- a small,
     acceptable slippage for position-sizing purposes, same tolerance
     this project already accepts elsewhere.

  2. A REAL PROTECTIVE STOP-LOSS HAS BEEN ADDED. THE BACKTEST HAS NONE.
     long_strategy15_latuserge_backtest.py's simulate_symbol() only ever
     exits on the MRC take-profit signal or (in the CLI-only, "not part
     of the real bot" words of that script's own docstring) a bar-count
     timeout -- there is no stop-loss anywhere in the validated logic.
     Running live with literally zero downside protection would conflict
     with this trader's own standing rule (claude/trader-profile.md:
     "Стоп-лосс - обязателен всегда, без исключений" -- stop-loss is
     mandatory always, no exceptions), so this script adds one. It is
     ASSUMED/NEW, not backtested, and it is deliberately anchored to the
     ORIGINAL base (entry) price rather than to the floating average
     entry price the way kc_roc_cci_wt_grid_live.py's stop is: the grid's
     deepest leg (order 6) sits 65% below base price by design, so a
     stop that re-synced to a *moving* average as legs filled would very
     likely fire long before the grid ever got to deploy its deeper,
     highest-weighted legs (30% and 26.34% of capital) -- defeating the
     whole point of the strategy. --stop-loss-pct (default 75, i.e. 10
     percentage points past the grid's deepest -65% leg) is fixed at
     deal-open time and never moved for the rest of that deal.
     IMPORTANT HONEST CAVEAT: the completed MAE (max adverse excursion)
     backtest found a worst historical case of -74.19% (TIAUSDT,
     2025-xx, see the project doc above) -- i.e. within the validated
     sample, price already came within ~1 percentage point of ANY
     --stop-loss-pct near this default before that specific deal
     recovered and closed at a profit via the normal MRC take-profit.
     Had a stop like this one been active historically, that trade (and
     possibly others) could have been closed at a loss instead of the
     profit the backtest recorded. This is a genuine, disclosed
     trade-off of adding a safety net the backtest never had -- not a
     free improvement. At the user's actual real-money leverage (2-5x,
     per trader-profile.md and the MAE analysis) Bybit's own forced
     liquidation sits well before this stop anyway (liquidation ≈
     100/leverage %, e.g. ≈20% at 5x) -- meaning at ≥5x this stop is
     very unlikely to ever be the thing that actually closes a losing
     deal; the exchange's own liquidation would act first. This script
     prints that comparison explicitly at startup so it's never a silent
     assumption.

Usage:
    python long_strategy15_latuserge_live.py                        # dry-run (paper), 5-symbol watchlist, defaults
    python long_strategy15_latuserge_live.py --live                  # REAL Bybit orders -- read the safety sections above first
    python long_strategy15_latuserge_live.py --symbol SOLUSDT --live --capital-per-deal 100 --leverage 5

Ctrl+C stops the polling loop. It does NOT flatten open positions or
cancel resting orders -- an open deal's exchange-side stop-loss keeps
protecting it either way, but the MRC take-profit exit stops firing until
the script runs again. Restart with the same --state-file to resume
exactly where it left off (state is reconciled against the real exchange
position on every cycle, not blindly trusted from disk).
"""
from __future__ import annotations
# latuserge_okx.py — 2026-11-02: копия для OKX (ордера через okx_bx_adapter.py, сигналы по свечам Bybit 1m).

import argparse
import csv
import json
import sys
import time
import traceback
from dataclasses import dataclass, field, asdict
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

import pandas as pd

from app import state_notices
from app import single_instance
from app.config import BASE_DIR, LATUSERGE_MAX_DEALS_FILE, TRADE_KEYS_FILE
from app.data import DataError, get_klines
from app.live_bot_settings import MaxConcurrentDealsSettings
from app.trade_keys_store import TradeKeysStore
from app.trading_guard import check_leverage
import okx_bx_adapter as bx   # 2026-11-02: OKX-версия — те же вызовы, торгуют на OKX
from app import chart

# Imported, not duplicated -- same rationale kc_roc_cci_wt_grid_live.py
# gives: for a live-MONEY script, the entry/grid/exit DECISION must stay
# byte-identical to what was actually split-validated in the paired
# backtest. Any future fix to compute_indicators()/GRID in the backtest
# applies here automatically instead of silently drifting apart.
from long_strategy15_latuserge_backtest import Params, compute_indicators, fetch_history, GRID

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

import os

# Only the 5 symbols the MAE/liquidation-risk backtest actually covered
# 5/5 (ETH/SOL/ARB/INJ/TIA) -- unlike kc_roc_cci_wt_grid's watchlist,
# latuserge has NOT been validated on HYPEUSDT or any other symbol, so it
# is deliberately not in this default.
DEFAULT_WATCHLIST = ["ETHUSDT", "SOLUSDT", "ARBUSDT", "INJUSDT", "TIAUSDT"]
CATEGORY = "linear"
DEFAULT_STATE_FILE = BASE_DIR / "latuserge_okx_live_state.json"


# 2026-09-24: оба живых бота торгуют на ОДНОМ счёте Bybit и пересекаются по
# монетам (ETH/SOL/ARB/INJ/TIA). Раньше позиция соседнего бота выглядела для
# этого скрипта как «неизвестная» -> тревога в Telegram. Теперь перед тревогой
# сверяемся с файлом состояния соседа: если монету держит он, тихо пропускаем
# (без Telegram). Настоящая неизвестная позиция (ручная сделка, потерянная
# после сброса состояния) по-прежнему вызывает тревогу.
SIBLING_STATE_FILE = BASE_DIR / "_no_sibling_on_okx.json"
SIBLING_LABEL = "KC/ROC гридом"
_sibling_busy_logged: set = set()


def sibling_holds(symbol: str) -> bool:
    try:
        if "--demo" in sys.argv:      # 2026-10-25: на демо проверяем именно одновременную торговлю одной монетой
            return False
        data = json.loads(SIBLING_STATE_FILE.read_text(encoding="utf-8"))
        return bool((data.get(symbol) or {}).get("in_deal"))
    except Exception:
        return False
DEFAULT_LOG_CSV = BASE_DIR / "latuserge_okx_live_trades.csv"

# 2026-09-12: paper mode gets its OWN state/journal files.
#
# WHY THIS EXISTS -- a real incident, not a hypothetical. Until today paper
# and live shared these two files, because neither build_argv() in
# windows_app/process_supervisor.py nor start_latuserge.bat ever passed
# --state-file/--log-csv. On 2026-09-09..11 a live instance (started from
# the panel) and a paper instance (started by double-clicking a .bat, which
# is paper by design) ran at the same time and both wrote here. They
# overwrote each other's state every few seconds: the paper instance kept
# re-asserting two deals the live instance had just closed, the live
# instance kept seeing "Bybit reports no position" for deals it did not
# open, and the shared journal ended up with duplicate rows plus two
# fabricated SL_ASSUMED -75% entries that never happened on the exchange.
#
# Separate files make that class of corruption physically impossible: the
# two modes can now run simultaneously without touching each other's books.
# An explicit --state-file/--log-csv still wins over both defaults.
DEFAULT_PAPER_STATE_FILE = BASE_DIR / "latuserge_okx_paper_state.json"
DEFAULT_PAPER_LOG_CSV = BASE_DIR / "latuserge_okx_paper_trades.csv"


# --------------------------------------------------------------- state --

@dataclass
class DealState:
    in_deal: bool = False
    entry_time: str | None = None            # ISO 8601, UTC
    base_price: float = 0.0
    orders: list = field(default_factory=list)     # [{"price":.., "vol_pct":.., "qty":..}] -- orders 1..next_order_idx-1
    next_order_idx: int = 2                  # next GRID index (1-based) still pending, 2..7 (7 = all 6 filled)
    stop_synced_price: float | None = None   # fixed at deal-open time, anchored to base_price -- see module docstring point 2


class StateFile:
    """Plain-JSON per-symbol deal state -- same house pattern as
    AccessStore/ScanSettings/TradeKeysStore/kc_roc_cci_wt_grid_live.py's
    own StateFile: read whole file, mutate in memory, write whole file
    back after every change so a crash mid-cycle loses at most the
    in-flight step, never earlier history."""

    def __init__(self, path: Path):
        self.path = path
        if path.exists():
            raw = json.loads(path.read_text())
        else:
            raw = {}
        self.deals: dict[str, DealState] = {sym: DealState(**d) for sym, d in raw.items()}

    def save(self) -> None:
        raw = {sym: asdict(d) for sym, d in self.deals.items()}
        self.path.write_text(json.dumps(raw, indent=2, ensure_ascii=False))

    def get(self, symbol: str) -> DealState:
        return self.deals.setdefault(symbol, DealState())


# ---------------------------------------------------------------- sizing --

def round_qty(raw_qty: float, step: float, min_qty: float) -> float:
    if step <= 0:
        return max(raw_qty, min_qty)
    steps = int(raw_qty / step + 1e-9)
    rounded = steps * step
    rounded = round(rounded, 10)  # kill float noise like 0.30000000000000004
    return max(rounded, min_qty)


# -------------------------------------------------------------- logging --

# Same fieldnames as long_strategy15_latuserge_backtest.py's save_csv() on
# purpose -- lets live results be compared directly against
# long_strategy15_latuserge_backtest_out/<symbol>_deals.csv, apples to apples.
CSV_FIELDS = ["symbol", "entry_time", "exit_time", "orders_filled", "filled_pct",
              "avg_entry_price", "exit_price", "reason", "bars_held", "gross_pnl_pct"]


def log_deal(csv_path: Path, symbol: str, entry_time, exit_time, orders_filled: int,
             filled_pct: float, avg_entry_price: float, exit_price: float, reason: str,
             gross_pnl_pct: float) -> None:
    entry_ts = pd.Timestamp(entry_time)
    exit_ts = pd.Timestamp(exit_time)
    bars_held = int((exit_ts - entry_ts).total_seconds() // 60)
    is_new = not csv_path.exists()
    with csv_path.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=CSV_FIELDS)
        if is_new:
            writer.writeheader()
        writer.writerow({
            "symbol": symbol, "entry_time": entry_ts.isoformat(), "exit_time": exit_ts.isoformat(),
            "orders_filled": orders_filled, "filled_pct": filled_pct,
            "avg_entry_price": avg_entry_price, "exit_price": exit_price,
            "reason": reason, "bars_held": bars_held, "gross_pnl_pct": gross_pnl_pct,
        })


# ------------------------------------------------------------- telegram --

# 2026-09-06, user request: latuserge and kc_roc_cci_wt_grid share several
# watchlist symbols (ETH/SOL/ARB/INJ/TIA in both) -- every notify() call
# EXCEPT the deal-open message used to say only "{symbol}: ...", with no way
# to tell which of the two bots a leg-fill/close/warning message about, say,
# ETHUSDT actually came from. Fixed by tagging every message here, not just
# deal-open, with the same STRATEGY_LABEL used for this bot's health.json
# source and /report section (see publish_health.py's
# "Latuserge (LONG_STRATEGY 15)" display_name) -- one consistent name across
# Telegram, /report, and the Mini App's "Здоровье" tab.
STRATEGY_LABEL = "Latuserge OKX"


def make_notifier(enabled: bool, strategy_label: str = STRATEGY_LABEL):
    # 2026-09-06, user request: send the same entry/SL/TP picture the Mini
    # App's "Торговля"/"Здоровье" tabs already show (app/chart.py's
    # render_position_chart(), see main.py's _maybe_publish_position_charts)
    # as a Telegram PHOTO too, right when a deal opens -- the user pointed
    # out the text-only notify() messages have no picture, unlike the Mini
    # App. Attached as `notify.send_photo` on the SAME callable this
    # function already returns, rather than changing this function's
    # signature or adding a second notifier object threaded through every
    # call site -- every existing `notify(...)` call keeps working
    # unchanged, and the (rare) deal-open code path that wants a photo too
    # just also calls `notify.send_photo(png_bytes, caption)`. A no-op
    # version is attached in the disabled/misconfigured branches below too,
    # so calling `.send_photo` is always safe regardless of whether
    # Telegram alerts are actually enabled.
    def _noop(msg: str) -> None:
        return None

    def _noop_photo(photo_bytes: bytes, caption: str) -> None:
        return None

    if not enabled:
        _noop.send_photo = _noop_photo
        return _noop
    token = os.environ.get("TELEGRAM_BOT_TOKEN")
    chat_id = os.environ.get("TELEGRAM_CHAT_ID")
    if not token or not chat_id:
        print("[TELEGRAM] alerts requested but TELEGRAM_BOT_TOKEN/TELEGRAM_CHAT_ID not set -- disabled.")
        _noop.send_photo = _noop_photo
        return _noop
    from app.telegram_client import TelegramClient, TelegramError
    import requests as _requests
    client = TelegramClient(token, chat_id)
    from app import notify_prefs
    _last_allowed = [True]

    def notify(msg: str) -> None:
        # 2026-09-14: было f"[{strategy_label}] {msg}" -- длинный ярлык
        # "[KC/ROC/CCI/WT грид · 🔴 LIVE (реальный ордер)]" лепился В НАЧАЛО
        # каждого сообщения и съедал первую строку, из-за которой в списке
        # чатов и в уведомлении на телефоне не было видно САМОГО главного:
        # монеты и что с ней произошло. Теперь ярлык уходит в конец
        # отдельной строкой курсивом: он нужен, но не важнее события.
        # 2026-09-24: типы уведомлений включаются/выключаются в Telegram
        # (/notify). Фото идёт сразу за текстом — оно следует его решению.
        allowed = notify_prefs.allowed_bot_message(msg) and (
            "paper" not in strategy_label.lower() or notify_prefs.is_enabled("paper"))
        _last_allowed[0] = allowed
        if not allowed:
            print(f"[TELEGRAM] muted ({notify_prefs.classify_bot_message(msg)}): {msg.splitlines()[0][:80]}")
            return
        try:
            client.send_message(f"{msg}\n<i>{strategy_label}</i>")
        except (TelegramError, _requests.exceptions.RequestException) as exc:
            print(f"[TELEGRAM] notify failed (non-fatal): {exc}", file=sys.stderr)

    def notify_photo(photo_bytes: bytes, caption: str) -> None:
        # Подпись под картинкой БЕЗ ярлыка стратегии: картинка идёт сразу за
        # текстовым сообщением, где всё это уже сказано. Раньше получался
        # дубль в две строки под каждым графиком.
        if not _last_allowed[0]:
            return
        try:
            client.send_photo(photo_bytes, caption)
        except (TelegramError, _requests.exceptions.RequestException) as exc:
            print(f"[TELEGRAM] notify_photo failed (non-fatal): {exc}", file=sys.stderr)

    notify.send_photo = notify_photo
    return notify


# ------------------------------------------------------------- backends --

class PaperBackend:
    """Zero real orders -- every "fill" is simulated against the just-
    polled real bar's low/close, IDENTICAL math to
    long_strategy15_latuserge_backtest.py's simulate_symbol(). This is the
    default and the only mode until --live is passed."""
    live = False

    def open_base(self, symbol, qty, stop_price):
        return {"order_id": None}

    def place_leg_market(self, symbol, qty, stop_price):
        return {"order_id": None}

    def close_market(self, symbol, qty):
        pass

    def cancel_all(self, symbol):
        pass

    def get_position(self, symbol):
        return None  # paper mode never consults a real exchange position


class LiveBackend:
    """Places REAL orders on Bybit. Reuses the SAME trade key already
    saved via /tradekey in the main bot (trade_keys.json) -- see
    app/trade_keys_store.py. Same house pattern as
    kc_roc_cci_wt_grid_live.py's LiveBackend."""
    live = True

    def __init__(self, api_key: str, api_secret: str, leverage: int):
        self.api_key = api_key
        self.api_secret = api_secret
        self.leverage = leverage
        self._leverage_set: set[str] = set()

    def _ensure_leverage(self, symbol: str) -> None:
        if symbol in self._leverage_set:
            return
        bx.set_leverage(self.api_key, self.api_secret, symbol, self.leverage)
        self._leverage_set.add(symbol)

    def open_base(self, symbol, qty, stop_price):
        self._ensure_leverage(symbol)
        return bx.place_order(self.api_key, self.api_secret, symbol, "buy", qty, stop_price)

    def place_leg_market(self, symbol, qty, stop_price):
        # A REAL market buy (not a resting limit -- see module docstring
        # point 1 for why latuserge's gated grid can't use resting
        # limits). stop_price is re-affirmed here too, harmless since
        # Bybit's stop-loss is a single value per position and it's the
        # same fixed value set at open_base() -- this deal's stop is
        # never moved, see DealState.stop_synced_price.
        return bx.place_order(self.api_key, self.api_secret, symbol, "buy", qty, stop_price)

    def close_market(self, symbol, qty):
        bx.close_position(self.api_key, self.api_secret, symbol, "buy", qty)

    def cancel_all(self, symbol):
        bx.cancel_all_open_orders(self.api_key, self.api_secret, symbol)

    def get_position(self, symbol) -> dict | None:
        df = bx.fetch_open_positions(self.api_key, self.api_secret)
        if df.empty:
            return None
        row = df[df["symbol"] == symbol]
        if row.empty:
            return None
        r = row.iloc[0]
        return {"qty": float(r["qty"]), "avg_entry_price": float(r["avg_entry_price"])}

    def last_closed_exit(self, symbol: str) -> float | None:
        """Best-effort exit price for a deal that closed OUTSIDE this
        script's own close_market() call (i.e. the native stop-loss
        fired, or the position was closed by hand) -- used only for
        accurate CSV logging, never for a trading decision."""
        try:
            closed = bx.fetch_closed_trades(self.api_key, self.api_secret, lookback_days=2)
        except DataError:
            return None
        rows = closed[closed["symbol"] == symbol]
        if rows.empty:
            return None
        return float(rows.iloc[-1]["avg_exit_price"])


# ---------------------------------------------------------------- core --

_REASON_RU = {
    "TP": "тейк-профит (MRC)",
    "SL": "стоп-лосс",
    "SL_ASSUMED": "стоп-лосс (предположительно, см. лог)",
}


def resolve_io_paths(args) -> None:
    """Picks the state/journal files for THIS run's mode, in place.

    2026-09-12: paper and live keep separate books (see DEFAULT_PAPER_*
    above for the incident that forced this). An explicitly passed
    --state-file/--log-csv always wins -- None just means "caller didn't
    choose, pick the right default for this mode"."""
    if getattr(args, "demo", False):   # 2026-10-25: демо-копия — свои файлы, реальные не трогаем
        args.state_file = args.state_file or str(BASE_DIR / "long_strategy15_latuserge_live_demo_state.json")
        args.log_csv = args.log_csv or str(BASE_DIR / "long_strategy15_latuserge_live_demo_trades.csv")
    if args.state_file is None:
        args.state_file = str(DEFAULT_STATE_FILE if args.live else DEFAULT_PAPER_STATE_FILE)
    if args.log_csv is None:
        args.log_csv = str(DEFAULT_LOG_CSV if args.live else DEFAULT_PAPER_LOG_CSV)


def reset_deal(state: DealState) -> None:
    """Clears a deal from local state. 2026-09-12: extracted from
    finalize_deal() so the "closed, but we could not confirm how" path
    (handle_external_close) resets EXACTLY the same fields -- a second,
    hand-copied reset is how the two paths quietly drift apart."""
    state.in_deal = False
    state.entry_time = None
    state.base_price = 0.0
    state.orders = []
    state.next_order_idx = 2
    state.stop_synced_price = None


def finalize_deal(symbol: str, state: DealState, exit_time, avg_entry: float, exit_price: float,
                   reason: str, filled_pct: float, csv_path: Path, notify) -> None:
    gross = (exit_price - avg_entry) / avg_entry * 100.0
    log_deal(csv_path, symbol, state.entry_time, exit_time, len(state.orders), filled_pct,
              avg_entry, exit_price, reason, gross)
    emoji = "✅" if gross > 0 else "🛑"
    reason_ru = _REASON_RU.get(reason, reason)
    try:
        held_seconds = int((pd.Timestamp(exit_time) - pd.Timestamp(state.entry_time)).total_seconds())
        days, rem = divmod(held_seconds, 86400)
        hours, rem = divmod(rem, 3600)
        minutes, seconds = divmod(rem, 60)
        held_str = (f"{days}д " if days else "") + f"{hours:02d}:{minutes:02d}:{seconds:02d}"
    except Exception:
        held_str = "н/д"
    notify("\n".join([
        f"{emoji} <b>{symbol}</b> — закрыта, {reason_ru}",
        "",
        f"P&L: <b>{gross:+.2f}%</b> (без учёта комиссии)",
        f"Вход {avg_entry:.6g} → выход {exit_price:.6g}",
        f"Ордеров: {len(state.orders)} из {len(GRID)} ({filled_pct:g}% объёма) · {held_str}",
    ]))
    print(f"[{symbol}] deal closed: reason={reason} gross={gross:+.2f}% "
          f"avg_entry={avg_entry:.6g} exit={exit_price:.6g}")
    reset_deal(state)


# 2026-09-12: how many CONSECUTIVE cycles Bybit must report "no position"
# before this script believes a deal really closed on the exchange.
#
# WHY: get_position() returning None used to be treated, on the very first
# occurrence, as proof the deal had closed. It is not proof. An empty
# position list is also what a transient API hiccup, a rate-limit, or a
# network blip looks like from here. On 2026-09-11 that exact
# misinterpretation fired on INJUSDT and TIAUSDT within ONE MINUTE of each
# other and wrote two fabricated -75% losses into the journal for deals the
# exchange had no record of. Requiring N consecutive misses costs at most
# N*--poll-seconds of delay before a genuine external close is journaled
# (the trade is already closed by then either way -- nothing is at risk in
# that window), and it makes a single bad response a non-event.
MISSING_POSITION_STRIKES = 3

# symbol -> consecutive "Bybit reports no position" count. In-memory only:
# deliberately NOT persisted to the state file, because a fresh process
# should re-confirm from scratch rather than inherit a half-finished
# suspicion from a previous run.
_missing_position_streak: dict[str, int] = {}


def note_position_present(symbol: str) -> None:
    """Bybit confirmed the position exists -- forget any pending suspicion."""
    _missing_position_streak.pop(symbol, None)


def note_position_missing(symbol: str) -> int:
    """Bybit reported no position. Returns how many times in a row now."""
    _missing_position_streak[symbol] = _missing_position_streak.get(symbol, 0) + 1
    return _missing_position_streak[symbol]


# 2026-09-12: дедупликация повторяющихся предупреждений в Telegram.
#
# ЗАЧЕМ: часть уведомлений описывает не СОБЫТИЕ, а СОСТОЯНИЕ, которое живёт
# много циклов подряд -- например "сигнал входа есть, но лимит
# одновременных сделок исчерпан". Цикл опроса раз в 60 секунд, поэтому одно
# и то же сообщение улетало владельцу каждую минуту часами. Реальный пример
# из чата: ARBUSDT, 2:07, 2:08, 2:09, 2:11, 2:12, 2:15... -- и так всю ночь.
# Это не просто раздражает: в таком потоке тонут ОДНОРАЗОВЫЕ сообщения,
# ради которых уведомления и нужны (открытие сделки, стоп, рассинхрон).
#
# Правило: сообщение уходит при ПЕРВОМ появлении условия и больше не
# повторяется, пока условие не исчезнет. Как только состояние снялось --
# метка сбрасывается, и следующий случай снова будет замечен. В консоль
# print() по-прежнему пишется каждый цикл: это лог, там повтор полезен.
# 2026-09-13: отметки переехали из памяти процесса в файл (app/state_notices.py).
# Набор в оперативке честно не повторялся ВНУТРИ одного запуска, но у этих
# ботов перезапусков много, и каждый старт заново рассылал все всё ещё
# верные предупреждения. Две стратегии следят за одними монетами, поэтому
# каждое такое событие приходило в чат дважды. Теперь отметка переживает
# перезапуск, а повтор возможен не чаще, чем раз в REMIND_AFTER_SECONDS --
# совсем замолчать про нерешённую проблему тоже нельзя.
_BOT_ID = "latuserge"


def notify_state_once(notify, symbol: str, kind: str, message: str) -> None:
    state_notices.notify_once(notify, _BOT_ID, symbol, kind, message)


def clear_state_notice(symbol: str, kind: str) -> None:
    state_notices.clear(_BOT_ID, symbol, kind)


def handle_external_close(symbol: str, state: DealState, stop_loss_pct: float, backend: LiveBackend,
                           csv_path: Path, notify, now_iso: str) -> None:
    """Live mode only: our local state says a deal is open, and Bybit has now
    reported no position MISSING_POSITION_STRIKES cycles in a row -- usually
    the native stop-loss firing (possibly while this script was offline),
    occasionally a manual close. Journals the real exit price if the exchange
    can still tell us one; never re-derives a trading decision from this.

    2026-09-12: this function no longer INVENTS an exit price. It used to
    fall back to the stop level (base_price * (1 - stop_loss_pct/100)) and
    log that as a real closed trade with reason SL_ASSUMED. With a 75% stop
    that fabricated a -75.00% loss out of nothing -- twice, on deals the
    exchange had never opened. A number we made up is worse than no number:
    it poisons win-rate, profit factor and every P&L total downstream, and
    it is indistinguishable from a real catastrophic loss when you read it
    later. When the exchange cannot confirm HOW the deal ended, we now say
    exactly that, loudly, and journal nothing."""
    total_vol = sum(o.get("vol_pct", 0.0) for o in state.orders) or GRID[0][1]
    weighted = sum(o.get("vol_pct", 0.0) * o.get("price", state.base_price) for o in state.orders)
    avg_entry = (weighted / total_vol) if total_vol else state.base_price
    exit_price = backend.last_closed_exit(symbol)

    if exit_price is None:
        # No position on the exchange AND no closed-trade record for it.
        # We genuinely do not know what happened -- so we say so instead of
        # guessing, and we do NOT touch orders: cancel_all() here could kill
        # a protective stop that is still live on a position we simply
        # failed to read.
        notify("\n".join([
            f"⚠️ {symbol}: позиция пропала с биржи, но подтверждения закрытия НЕТ",
            f"Биржа не вернула ни открытой позиции ({MISSING_POSITION_STRIKES} проверки подряд), "
            f"ни записи о закрытой сделке.",
            f"Сделка снята с локального учёта, но в журнал НЕ записана — "
            f"настоящий результат неизвестен, а выдуманный был бы хуже пустого.",
            f"Цена входа (средняя): {avg_entry:.6g}",
            f"Проверь эту монету на бирже вручную.",
        ]))
        print(f"[{symbol}] external close UNCONFIRMED: no position and no closed-trade record "
              f"after {MISSING_POSITION_STRIKES} consecutive checks -- clearing local deal WITHOUT "
              f"journaling it (avg_entry={avg_entry:.6g}). Orders deliberately NOT cancelled.",
              file=sys.stderr)
        reset_deal(state)
        return

    finalize_deal(symbol, state, now_iso, avg_entry, exit_price, "SL", total_vol, csv_path, notify)
    try:
        backend.cancel_all(symbol)
    except DataError as exc:
        print(f"[{symbol}] warning: cancel_all after external close failed (non-fatal): {exc}", file=sys.stderr)


def process_symbol(symbol: str, df: pd.DataFrame, params: Params, state: DealState, backend,
                    capital_per_deal: float, stop_loss_pct: float, instrument: dict,
                    csv_path: Path, notify, all_deals: dict[str, DealState] | None = None,
                    max_concurrent_deals: int | None = None) -> None:
    ind = compute_indicators(df, params)
    i = len(df) - 1
    if not bool(ind["entry_defined"].iloc[i]):
        return  # not enough history yet for every indicator to be defined
    row = df.iloc[i]
    now_time = row["open_time"]
    now_iso = pd.Timestamp(now_time).isoformat()
    step, min_qty = instrument["qty_step"], instrument["min_order_qty"]

    # ----- not currently in a deal: only decision is whether to open one --
    if not state.in_deal:
        if backend.live:
            # Same safety check as kc_roc_cci_wt_grid_live.py: Bybit is the
            # source of truth. If it reports a position local state doesn't
            # know about (e.g. after a state-file reset), refuse to stack a
            # second deal on top -- wait for a human.
            existing = backend.get_position(symbol)
            if existing is not None and sibling_holds(symbol):
                # позиция соседнего бота на том же счёте -- не тревога
                if symbol not in _sibling_busy_logged:
                    print(f"[{symbol}] занята {SIBLING_LABEL} (позиция соседнего бота на том же счёте) -- "
                          f"новые сделки по этой монете пропускаются, пока он её держит.")
                    _sibling_busy_logged.add(symbol)
                clear_state_notice(symbol, "unknown_position")
                return
            _sibling_busy_logged.discard(symbol)
            if existing is not None:
                print(f"[{symbol}] WARNING: local state says no open deal, but Bybit reports an open "
                      f"position (qty={existing['qty']}, avg_entry={existing['avg_entry_price']}) -- "
                      f"NOT opening a new deal until this is resolved.")
                # состояние, а не событие -- шлём один раз (см. notify_state_once)
                notify_state_once(notify, symbol, "unknown_position",
                                   f"⚠️ {symbol}: на бирже есть открытая позиция, о которой скрипт не знает -- "
                                   f"новые сделки по этой монете приостановлены, проверь вручную.")
                return
            clear_state_notice(symbol, "unknown_position")
        if not bool(ind["entry_signal"].iloc[i]):
            # сигнала нет -- эпизод "лимит исчерпан" закончился, следующий
            # случай снова будет замечен
            clear_state_notice(symbol, "deal_limit")
            return
        if max_concurrent_deals is not None and all_deals is not None:
            open_count = sum(1 for s in all_deals.values() if s.in_deal)
            if open_count >= max_concurrent_deals:
                print(f"[{symbol}] entry signal fired, but max-concurrent-deals ({max_concurrent_deals}) "
                      f"already reached ({open_count} open) -- skipping.")
                notify_state_once(notify, symbol, "deal_limit",
                                   f"⏸ {symbol}: сигнал входа сработал, но лимит одновременных сделок "
                                   f"({max_concurrent_deals}) уже исчерпан -- пропущено. "
                                   f"Повторно об этом не пишу, пока лимит не освободится.")
                return
        clear_state_notice(symbol, "deal_limit")
        price = float(row["close"])
        off0, vol0 = GRID[0]
        qty_base = round_qty(capital_per_deal * vol0 / 100.0 / price, step, min_qty)
        # Fixed at open, anchored to base price -- never re-synced for the
        # rest of this deal. See module docstring point 2 for why.
        stop_price = price * (1 - stop_loss_pct / 100.0)
        backend.open_base(symbol, qty_base, stop_price)
        state.in_deal = True
        state.entry_time = now_iso
        state.base_price = price
        state.orders = [{"price": price, "vol_pct": vol0, "qty": qty_base}]
        state.next_order_idx = 2
        state.stop_synced_price = stop_price
        # 2026-09-14: формат приведён к тому же виду, что и у грид-бота —
        # см. комментарий там. Событие и монета первой строкой жирным,
        # дальше короткие строки с ценой на первом месте.
        lines = [
            f"🟢 <b>{symbol}</b> — сделка открыта",
            "",
            f"Вход: <b>{price:.6g}</b> × {qty_base:g} "
            f"({capital_per_deal * vol0 / 100.0:.2f} USDT, сетка из {len(GRID)})",
            f"Стоп: <b>{stop_price:.6g}</b> (−{stop_loss_pct:g}%, фиксирован на всю сделку)",
            f"Тейк: MRC (5m) + P&L ≥ {params.min_pnl_pct:g}%",
            f"Объём сделки: {capital_per_deal:g} USDT",
        ]
        notify("\n".join(lines))
        print(f"[{symbol}] deal opened @ {price:.6g}, stop @ {stop_price:.6g} (fixed)")
        # 2026-09-06, user request: also send the entry/SL/TP picture as a
        # Telegram photo (same renderer + same 15m/150-bar style as the
        # Mini App's "Торговля"/"Здоровье" tabs, see main.py's
        # _maybe_publish_position_charts) -- a SEPARATE, fresh 15m fetch
        # from this strategy's own 1m `df`, purely for a nicer-looking
        # chart, matching the Mini App feature's own choice. take_profit is
        # intentionally omitted: this bot's take-profit is a dynamic
        # MRC(5m)+P&L condition, not a fixed price, so there is no single
        # line to draw for it (same reasoning render_position_chart's own
        # docstring gives for never inventing a line). Wrapped so a bad
        # kline fetch or a Telegram hiccup here can NEVER block the deal
        # itself, which has already fully opened above.
        try:
            chart_df = get_klines(symbol, "15m", limit=150)
            png = chart.render_position_chart(
                df=chart_df, symbol_label=symbol.replace("USDT", ""), timeframe="15m",
                side="buy", entry=price, stop_loss=stop_price,
            )
            notify.send_photo(png, f"{symbol} · вход {price:.6g}, стоп {stop_price:.6g}")
        except Exception as exc:
            print(f"[{symbol}] warning: couldn't render/send position-open chart (non-fatal): {exc}", file=sys.stderr)
        return

    # ----- already in a deal: consider firing the next pending grid leg --
    if state.next_order_idx <= len(GRID):
        eff_offset, vol_pct = GRID[state.next_order_idx - 1]
        limit_price = state.base_price * (1 - eff_offset / 100.0)
        cond = ind["order_conditions"].get(state.next_order_idx)
        cond_true = bool(cond.iloc[i]) if cond is not None else True
        touched = float(row["low"]) <= limit_price
        if touched and cond_true:
            qty_leg = round_qty(capital_per_deal * vol_pct / 100.0 / limit_price, step, min_qty)
            try:
                backend.place_leg_market(symbol, qty_leg, state.stop_synced_price)
                state.orders.append({"price": limit_price, "vol_pct": vol_pct, "qty": qty_leg})
                leg_usdt = capital_per_deal * vol_pct / 100.0
                notify(f"➕ {symbol}: нога сетки #{state.next_order_idx} исполнена -- "
                       f"{qty_leg:g} @ ~{limit_price:.6g} (-{eff_offset:g}% от базы, "
                       f"{leg_usdt:.2f} USDT, {vol_pct:g}% капитала)")
                print(f"[{symbol}] leg #{state.next_order_idx} filled @ ~{limit_price:.6g}")
                state.next_order_idx += 1
            except DataError as exc:
                print(f"[{symbol}] WARNING: grid leg #{state.next_order_idx} ({vol_pct:g}% @ -{eff_offset:g}%) "
                      f"rejected by the exchange -- will retry next cycle if price/condition still qualify: {exc}",
                      file=sys.stderr)
                notify(f"⚠️ {symbol}: нога сетки #{state.next_order_idx} отклонена биржей, попробуем снова "
                       f"на следующем цикле.")

    # ----- avg entry / filled pct, and stop / TP checks -----------------
    if backend.live:
        pos = backend.get_position(symbol)
        if pos is None:
            # 2026-09-12: one empty answer is NOT proof the deal closed --
            # it is also what an API hiccup looks like. Wait for
            # MISSING_POSITION_STRIKES in a row before acting on it.
            strikes = note_position_missing(symbol)
            if strikes < MISSING_POSITION_STRIKES:
                print(f"[{symbol}] Bybit reports no position ({strikes}/{MISSING_POSITION_STRIKES}) "
                      f"while local state says the deal is open -- not acting yet, re-checking next cycle.",
                      file=sys.stderr)
                return
            handle_external_close(symbol, state, stop_loss_pct, backend, csv_path, notify, now_iso)
            note_position_present(symbol)   # streak consumed, start clean
            return
        note_position_present(symbol)
        avg_entry = pos["avg_entry_price"]
        filled_pct = sum(o.get("vol_pct", 0.0) for o in state.orders)
        # stop_synced_price is fixed at open -- nothing to re-sync here,
        # unlike kc_roc_cci_wt_grid_live.py.
    else:
        total_vol = sum(o["vol_pct"] for o in state.orders)
        avg_entry = sum(o["vol_pct"] * o["price"] for o in state.orders) / total_vol
        filled_pct = total_vol
        if float(row["low"]) <= state.stop_synced_price:
            finalize_deal(symbol, state, now_time, avg_entry, state.stop_synced_price, "SL",
                          filled_pct, csv_path, notify)
            return

    pnl_now = (float(row["close"]) - avg_entry) / avg_entry * 100.0
    if bool(ind["tp_signal"].iloc[i]) and pnl_now >= params.min_pnl_pct:
        if backend.live:
            pos = backend.get_position(symbol)  # re-check right before acting
            if pos is not None:
                backend.close_market(symbol, pos["qty"])
                try:
                    backend.cancel_all(symbol)
                except DataError as exc:
                    print(f"[{symbol}] warning: cancel_all after TP failed (non-fatal): {exc}", file=sys.stderr)
        finalize_deal(symbol, state, now_time, avg_entry, float(row["close"]), "TP", filled_pct, csv_path, notify)


# ----------------------------------------------------------------- cli --

def build_params(args) -> Params:
    return Params(
        cci_length=args.cci_length, cmo_length=args.cmo_length, wr_length=args.wr_length,
        bb_length=args.bb_length, bb_mult=args.bb_mult, atr_length=args.atr_length,
        adx_di_length=args.adx_di_length, adx_smoothing=args.adx_smoothing,
        kc_length=args.kc_length, kc_mult=args.kc_mult,
        cci_order_threshold=args.cci_order_threshold, mrc_length=args.mrc_length,
        min_pnl_pct=args.min_pnl_pct, use_rsi_filter=args.use_rsi_filter, rsi_length=args.rsi_length,
        max_deal_bars=10**9,  # no timeout in live mode -- a deal stays open until SL/TP, period
    )


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--symbol", nargs="+", default=DEFAULT_WATCHLIST)
    parser.add_argument("--demo", action="store_true",
                        help="2026-10-25: ДЕМО-счёт Bybit (нужен BYBIT_TRADE_BASE=api-demo), свой учёт объёма (app/ledger_backend.py), "
                             "свои файлы *_demo_*, ключ из слота bybit_demo. Реальный счёт не трогает.")
    parser.add_argument("--live", action="store_true", help="Place REAL orders on Bybit. Default: dry-run/paper.")
    parser.add_argument("--capital-per-deal", type=float, default=100.0,
                         help="Total NOTIONAL (not margin) per deal in USDT, split across the 6 grid legs "
                              "by GRID's published percentages. NOTE: the smallest leg (base, 6.66%%) needs "
                              "at least ~75 USDT of capital-per-deal to clear Bybit's ~5 USDT minimum order "
                              "value on its own -- default raised to 100 for headroom (see startup warning).")
    parser.add_argument("--leverage", type=int, default=5,
                         help="Default 5x, NOT the blog's 20x -- matches what was actually validated for "
                              "liquidation risk in the MAE backtest (5x -> 3.4%% of deals at risk historically).")
    parser.add_argument("--max-trade-leverage", type=int, default=5, help="Hard cap, same guard as main.py's /trade")
    parser.add_argument("--max-concurrent-deals", type=int, default=2,
                         help="Max deals open at once across ALL tracked symbols -- caps total committed "
                              "capital during a correlated market-wide move. 0 = unlimited.")
    parser.add_argument("--stop-loss-pct", type=float, default=75.0,
                         help="NEW / ASSUMED -- NOT part of the backtested strategy, added because it has no "
                              "stop-loss at all. Fixed relative to the ORIGINAL base (entry) price, past the "
                              "grid's deepest -65%% leg, and never moved for the rest of the deal. See module "
                              "docstring point 2 for the full trade-off (worst observed historical MAE was "
                              "-74.19%%, uncomfortably close to this default).")
    parser.add_argument("--poll-seconds", type=int, default=60)
    parser.add_argument("--lookback-bars", type=int, default=5000,
                         help="1m bars of history fetched each cycle for indicator warmup (~3.5 days by "
                              "default -- more than kc_roc_cci_wt_grid_live.py's 3000 because latuserge's "
                              "slowest indicator is CCI(20) on 1h bars, needing >=1200 minutes of history).")
    # 2026-09-12: default is None on purpose -- it is resolved AFTER parsing
    # (see main()), because the default now depends on --live vs paper. An
    # explicitly passed path still wins in both modes; None just means
    # "caller didn't choose, pick the right default for this mode".
    parser.add_argument("--state-file", default=None,
                         help=f"default: {DEFAULT_STATE_FILE.name} with --live, "
                              f"{DEFAULT_PAPER_STATE_FILE.name} in paper mode")
    parser.add_argument("--log-csv", default=None,
                         help=f"default: {DEFAULT_LOG_CSV.name} with --live, "
                              f"{DEFAULT_PAPER_LOG_CSV.name} in paper mode")
    parser.add_argument("--telegram-alerts", action="store_true", default=True)
    parser.add_argument("--no-telegram-alerts", dest="telegram_alerts", action="store_false")

    parser.add_argument("--cci-length", type=int, default=20, help="ASSUMED, matches the backtest default")
    parser.add_argument("--cmo-length", type=int, default=14, help="ASSUMED, matches the backtest default")
    parser.add_argument("--wr-length", type=int, default=14, help="ASSUMED, matches the backtest default")
    parser.add_argument("--bb-length", type=int, default=20, help="ASSUMED, matches the backtest default")
    parser.add_argument("--bb-mult", type=float, default=2.0, help="ASSUMED, matches the backtest default")
    parser.add_argument("--atr-length", type=int, default=14, help="ASSUMED, matches the backtest default")
    parser.add_argument("--adx-di-length", type=int, default=14, help="ASSUMED, matches the backtest default")
    parser.add_argument("--adx-smoothing", type=int, default=14, help="ASSUMED, matches the backtest default")
    parser.add_argument("--kc-length", type=int, default=20, help="ASSUMED, matches the backtest default")
    parser.add_argument("--kc-mult", type=float, default=2.0, help="ASSUMED, matches the backtest default")
    parser.add_argument("--cci-order-threshold", type=float, default=-100.0, help="ASSUMED, matches the backtest default")
    parser.add_argument("--mrc-length", type=int, default=50, help="APPROXIMATED, matches the backtest default")
    parser.add_argument("--min-pnl-pct", type=float, default=1.0, help="CONFIRMED from blog post, matches the backtest default")
    parser.add_argument("--use-rsi-filter", action="store_true", help="Enable the optional 1m RSI filter (off by default, matches the backtest)")
    parser.add_argument("--rsi-length", type=int, default=14, help="ASSUMED, only used with --use-rsi-filter")

    args = parser.parse_args()

    # 2026-09-13: одна копия на стратегию. 13.09 на машине владельца
    # одновременно жили ЧЕТЫРЕ копии этого скрипта (--live, настоящие
    # ордера): restart_grid_bot.bat старые копии убивает, а запуск
    # "python <скрипт> --live" руками из PowerShell -- нет.
    # В журнале сделок остался след: ARBUSDT, две отдельные сделки с
    # ОДНИМ временем входа 2026-09-08T16:54:00+00:00 -- обе копии
    # увидели один сигнал и обе поставили ордер.
    # Ставится ПОСЛЕ parse_args, чтобы --help работал всегда.
    single_instance.acquire_or_exit("latuserge_okx")   # 2026-10-25: демо-копия — свой замок
    params = build_params(args)
    symbols = [s.upper() for s in args.symbol]

    if args.stop_loss_pct <= GRID[-1][0]:
        print(f"REFUSING TO START: --stop-loss-pct {args.stop_loss_pct:g} is at or inside the grid's own "
              f"deepest leg (-{GRID[-1][0]:g}%) -- the stop would fire before the grid could ever fully "
              f"deploy, which defeats the strategy. Pick something past {GRID[-1][0]:g}.", file=sys.stderr)
        sys.exit(1)

    approx_liq_pct = 100.0 / args.leverage
    print(f"NOTE: at {args.leverage}x leverage, Bybit's own forced liquidation sits at roughly "
          f"-{approx_liq_pct:.1f}% (100/leverage, ignores maintenance margin) -- "
          f"{'BEFORE' if approx_liq_pct < args.stop_loss_pct else 'AFTER'} this script's own "
          f"--stop-loss-pct {args.stop_loss_pct:g}%. "
          + ("Liquidation would very likely close a losing deal before this stop ever gets the chance to."
             if approx_liq_pct < args.stop_loss_pct else
             "This stop would fire before liquidation could -- it is the thing actually protecting you here."))

    # Bybit rejects any order below ~5 USDT notional on its linear USDT
    # perpetuals (retCode=110094) -- same hardcoded floor
    # kc_roc_cci_wt_grid_live.py uses, from the real error seen in
    # production on that bot.
    _MIN_ORDER_VALUE_USDT = 5.0
    for idx, (off, vol) in enumerate(GRID, start=1):
        leg_usdt = args.capital_per_deal * vol / 100.0
        if leg_usdt < _MIN_ORDER_VALUE_USDT:
            min_capital_needed = _MIN_ORDER_VALUE_USDT * 100.0 / vol
            label = "base order" if idx == 1 else f"leg #{idx}"
            print(f"WARNING: {label} ({vol:g}% @ -{off:g}%) is {leg_usdt:.2f} USDT notional at "
                  f"--capital-per-deal {args.capital_per_deal:g} -- below Bybit's ~{_MIN_ORDER_VALUE_USDT:g} "
                  f"USDT minimum order value. This order will be rejected on EVERY deal (retried each cycle, "
                  f"never placed). Raise --capital-per-deal to at least {min_capital_needed:.2f} to let it place.",
                  file=sys.stderr)

    ok, reason = check_leverage(args.leverage, args.max_trade_leverage)
    if not ok:
        print(f"REFUSING TO START: {reason}", file=sys.stderr)
        sys.exit(1)

    resolve_io_paths(args)

    state_file = StateFile(Path(args.state_file))
    csv_path = Path(args.log_csv)
    # 2026-09-06: tag every notify() message with paper/live mode. Before
    # this, PaperBackend and LiveBackend produced BYTE-IDENTICAL Telegram
    # text -- see telegram-notifications-diagnosis-2026-09-06.md, which
    # already documented that notify() fires the same way in both modes.
    # That ambiguity is exactly what made a dry-run "deal opened" message
    # for ARBUSDT look like a real trade to the user, who then checked
    # Bybit and (correctly) found nothing there. The mode tag makes this
    # unambiguous in the message itself, not just in the one-time startup
    # banner below.
    # 2026-09-14: скобки укорочены. Различие paper/live терять нельзя (из-за
    # его отсутствия 06.09 бумажная сделка выглядела как настоящая), но
    # "(симуляция, без реальных денег)" занимало пол-строки в каждом
    # сообщении. Смысл сохранён, длина втрое меньше.
    mode_tag = "🔴 LIVE · реальные ордера" if args.live else "🧪 PAPER · симуляция"
    notify = make_notifier(args.telegram_alerts, strategy_label=f"{STRATEGY_LABEL} · {mode_tag}")

    # 2026-09-06, user request: same live-editable cap as
    # kc_roc_cci_wt_grid_live.py added this same day -- see that script's
    # own comment at the identical spot, and app/live_bot_settings.py, for
    # the full rationale. Seeds the settings file with the CLI value on
    # first run, then re-read fresh every poll cycle below.
    if getattr(args, "demo", False):   # 2026-10-25: на демо свой лимит сделок (без ограничений реала), файл отдельный
        globals()["LATUSERGE_MAX_DEALS_FILE"] = BASE_DIR / "latuserge_demo_max_deals.json"
        MaxConcurrentDealsSettings(BASE_DIR / "latuserge_demo_max_deals.json", default=args.max_concurrent_deals).set(args.max_concurrent_deals)
    globals()["LATUSERGE_MAX_DEALS_FILE"] = BASE_DIR / "latuserge_okx_max_deals.json"   # свой лимит сделок
    if not LATUSERGE_MAX_DEALS_FILE.exists():
        MaxConcurrentDealsSettings(LATUSERGE_MAX_DEALS_FILE, default=args.max_concurrent_deals).set(
            args.max_concurrent_deals)

    if getattr(args, "demo", False):
        print("OKX-версия не поддерживает --demo (Bybit). Без --live — бумага.", file=sys.stderr); sys.exit(1)
    if args.live:
        # 2026-09-06, user request: per-strategy keys -- get_for_strategy()
        # returns this bot's OWN dedicated Bybit key if one was set via
        # /tradekey latuserge bybit ..., otherwise falls back to the shared
        # default key (same key every strategy used before this feature
        # existed), so nothing changes for a user who never sets a
        # dedicated key. See app/trade_keys_store.py's module docstring.
        if args.demo:
            from app.exchanges import bybit as _bxd  # noqa: PLC0415
            if "api-demo" not in _bxd.TRADE_BASE:
                print("REFUSING --demo: BYBIT_TRADE_BASE не указывает на api-demo.bybit.com — запускай через start_demo_bots.bat",
                      file=sys.stderr); sys.exit(1)
            creds = TradeKeysStore(TRADE_KEYS_FILE).get_for_strategy("bybit_demo", "bybit")
        else:
            # OKX: ТОЛЬКО отдельный ключ этой стратегии (общий ключ OKX — счёт другого бота, его не трогаем)
            creds = TradeKeysStore(TRADE_KEYS_FILE)._strategy_keys.get("latuserge", {}).get("okx")  # noqa: SLF001
            if creds:
                bx.PASS = creds.get("passphrase")
                if not bx.PASS:
                    print("REFUSING --live: у ключа OKX нет passphrase", file=sys.stderr); sys.exit(1)
        if creds is None:
            print("REFUSING TO START --live: нет отдельного ключа OKX для Latuserge (/tradekey latuserge okx KEY SECRET PASSPHRASE). "
                  "(set one up via /tradekey bybit ... for the shared default, or "
                  "/tradekey latuserge bybit ... for a key dedicated to this bot).", file=sys.stderr)
            sys.exit(1)
        if args.demo:
            from app.ledger_backend import LedgerBackend  # noqa: PLC0415
            backend = LedgerBackend(creds["api_key"], creds["api_secret"], args.leverage, "LAT",
                                    BASE_DIR / "long_strategy15_latuserge_live_demo_ledger.json")
        else:
            backend = LiveBackend(creds["api_key"], creds["api_secret"], args.leverage)
        print(("*** DEMO MODE -- Bybit DEMO account (api-demo), own-volume ledger, NO real money. " if args.demo else "*** LIVE MODE -- REAL ORDERS on OKX. ") + f"{len(symbols)} symbols, "
              f"{args.capital_per_deal} USDT notional/deal, {args.leverage}x leverage. ***")
    else:
        backend = PaperBackend()
        print(f"Dry-run (paper) mode -- no real orders. {len(symbols)} symbols, "
              f"simulating {args.capital_per_deal} USDT notional/deal.")

    instruments: dict[str, dict] = {}
    for symbol in symbols:
        try:
            instruments[symbol] = bx.get_instrument_info(symbol, category=CATEGORY)
        except DataError as exc:
            print(f"[{symbol}] couldn't fetch instrument info, skipping this symbol: {exc}", file=sys.stderr)

    active_symbols = [s for s in symbols if s in instruments]
    if not active_symbols:
        print("No symbols left after instrument-info lookup -- nothing to do.", file=sys.stderr)
        sys.exit(1)

    # Same qty-floor sanity check kc_roc_cci_wt_grid_live.py added
    # 2026-09-01 after a real incident there: a leg can round UP to the
    # exchange's minimum tradable size and silently trade a bigger
    # notional than intended, on expensive coins especially.
    _QTY_FLOOR_WARN_RATIO = 1.5
    for symbol in active_symbols:
        step, min_qty = instruments[symbol]["qty_step"], instruments[symbol]["min_order_qty"]
        try:
            last_price = bx.get_last_price(symbol, category=CATEGORY)
        except DataError as exc:
            print(f"[{symbol}] couldn't fetch last price for the qty-floor sanity check, skipping it: {exc}",
                  file=sys.stderr)
            continue
        for idx, (off, vol) in enumerate(GRID, start=1):
            leg_price = last_price * (1 - off / 100.0)
            target_usdt = args.capital_per_deal * vol / 100.0
            raw_qty = target_usdt / leg_price
            actual_qty = round_qty(raw_qty, step, min_qty)
            actual_usdt = actual_qty * leg_price
            if target_usdt > 0 and actual_usdt / target_usdt >= _QTY_FLOOR_WARN_RATIO:
                label = "base order" if idx == 1 else f"leg #{idx} @ -{off:g}%"
                print(f"WARNING: [{symbol}] {label} ({vol:g}% of --capital-per-deal {args.capital_per_deal:g} "
                      f"= {target_usdt:.2f} USDT target) rounds up to {actual_qty:g} "
                      f"{symbol.replace('USDT', '')} (~{actual_usdt:.2f} USDT, {actual_usdt / target_usdt:.1f}x "
                      f"the target) -- exchange minimum tradable size for this symbol ({min_qty:g}, step {step:g}) "
                      f"is large relative to this deal's capital. Raise --capital-per-deal (or drop this symbol) "
                      f"if this much real exposure per leg isn't intended.", file=sys.stderr)

    print(f"Tracking: {', '.join(active_symbols)}. Poll every {args.poll_seconds}s. "
          f"State: {args.state_file}  Log: {args.log_csv}  Max concurrent deals: "
          f"{args.max_concurrent_deals:g} (live-editable via /maxdeals in Telegram or by editing "
          f"{LATUSERGE_MAX_DEALS_FILE.name} directly -- takes effect next poll cycle, no restart needed).")

    while True:
        cycle_start = time.time()
        current_max_concurrent = MaxConcurrentDealsSettings.read_live(
            LATUSERGE_MAX_DEALS_FILE, args.max_concurrent_deals)
        for symbol in active_symbols:
            state = state_file.get(symbol)
            try:
                df = fetch_history(symbol, "1m", args.lookback_bars)
                now_utc = datetime.now(timezone.utc)
                df = df[df["open_time"] + pd.Timedelta(minutes=1) <= now_utc].reset_index(drop=True)
                if df.empty:
                    continue
                process_symbol(symbol, df, params, state, backend,
                                args.capital_per_deal, args.stop_loss_pct, instruments[symbol],
                                csv_path, notify, all_deals=state_file.deals,
                                max_concurrent_deals=(current_max_concurrent or None))
            except DataError as exc:
                print(f"[{symbol}] [SKIP this cycle] {exc}", file=sys.stderr)
            except Exception:
                print(f"[{symbol}] unexpected error this cycle (continuing):", file=sys.stderr)
                traceback.print_exc()
            finally:
                state_file.save()
        elapsed = time.time() - cycle_start
        time.sleep(max(1.0, args.poll_seconds - elapsed))


if __name__ == "__main__":
    main()
