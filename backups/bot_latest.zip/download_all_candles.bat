@echo off
cd /d "%~dp0"
echo Download Bybit 1m candles since 2020 for 25 coins (long, can take hours; safe to stop and restart)
venv\Scripts\python.exe -m pip install pyarrow --quiet
venv\Scripts\python.exe download_all_candles.py %*
pause
