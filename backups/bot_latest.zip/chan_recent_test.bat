@echo off
cd /d D:\VANTORIX\bot
venv\Scripts\python.exe chan_recent_test.py
pause
