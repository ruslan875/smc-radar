"""ginarea_trend_all.py — 2026-11-02. Сетка GinArea + фильтр тренда на МНОГИХ монетах — сводка «на скольких монетах в плюсе».

Те же варианты, что в ginarea_trend_test.py (лонг/шорт × без фильтра / EMA200 1h / 4h × шаг 0.05/0.2% × без стопа / SL −5 $).
Размер ордера пересчитан на ~0.87 $ (как 1 SUI), чтобы монеты были сравнимы. Свечи OKX 1m кешируются (повторный запуск — быстро).
Запуск: ginarea_trend_all.bat [дней=180] [монеты через запятую] → bt_lab_bots/ginarea_trend_all.txt
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import pandas as pd

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
from ginarea_sui_test import okx_1m  # noqa: E402
from ginarea_trend_test import gates, run  # noqa: E402
from ginarea_lot import lot  # noqa: E402

COINS = "BTC,ETH,SOL,XRP,DOGE,BNB,ADA,LINK,AVAX,SUI,HYPE,TAO"
LINES = []


def say(s=""):
    print(s, flush=True); LINES.append(s)


def main():
    days = int(sys.argv[1]) if len(sys.argv) > 1 else 180
    coins = [c.strip().upper() for c in (sys.argv[2] if len(sys.argv) > 2 else COINS).split(",") if c.strip()]
    say(f"Сетка GinArea + фильтр тренда · {len(coins)} монет OKX 1m · {days} дн. · ордер ≈0.87 $ · {time.strftime('%Y-%m-%d %H:%M')}")
    table, moves = {}, {}
    for coin in coins:
        say(f"... {coin}")
        try:
            d = okx_1m(coin, days)
        except Exception as exc:  # noqa: BLE001
            say(f"   {coin}: ошибка загрузки {exc}"); continue
        if len(d) < 10000:
            say(f"   {coin}: мало свечей"); continue
        moves[coin] = (d.c.iloc[-1] / d.c.iloc[0] - 1) * 100
        qty = 0.87 / float(d.c.iloc[-1])
        base = dict(n=30, step=0.0005, qty=qty, mult=1.01, qmax=qty * 2, target=0.0025, min_stop=0.0001, max_stop=0.001,
                    tp0=8.0, tp_inc=0.2, sl=None, lot=lot(coin))
        if base["lot"][1] and base["lot"][1] > qty:
            say(f"   {coin}: мин. лот {base['lot'][1]:g} > 0.87 $ — ордер = мин. лот ({base['lot'][1] * float(d.c.iloc[-1]):.2f} $)")
        G = {(s, tf): gates(d, s, tf) for s in ("long", "short") for tf in (None, "1h", "4h")}
        for step in (0.0005, 0.002):
            for sl in (None, -5.0):
                P = {**base, "step": step, "sl": sl}
                for s in ("long", "short"):
                    for tf in (None, "1h", "4h"):
                        r = run(d, G[(s, tf)], s, P)
                        k = f"{'ЛОНГ' if s == 'long' else 'ШОРТ'} {('EMA200 ' + tf) if tf else 'без фильтра':<12} шаг {step * 100:.2f}% {'SL −5' if sl else 'без SL'}"
                        table.setdefault(k, {})[coin] = (r["all"], r["worst"])
                for tf in ("1h", "4h"):
                    a = table[f"ЛОНГ {'EMA200 ' + tf:<12} шаг {step * 100:.2f}% {'SL −5' if sl else 'без SL'}"][coin]
                    b = table[f"ШОРТ {'EMA200 ' + tf:<12} шаг {step * 100:.2f}% {'SL −5' if sl else 'без SL'}"][coin]
                    table.setdefault(f"ОБА  {'EMA200 ' + tf:<12} шаг {step * 100:.2f}% {'SL −5' if sl else 'без SL'}", {})[coin] = (a[0] + b[0], a[1] + b[1])
        say(f"   {coin}: {moves[coin]:+.0f}% за период · готово")
    say(""); say("Движение монет: " + "  ".join(f"{c} {v:+.0f}%" for c, v in moves.items()))
    say(""); say(f"{'вариант':<44} {'в плюсе':>8} {'сумма $':>9} {'средн. $':>9} {'худшая':>8}")
    rows = []
    for k, v in table.items():
        vals = [x[0] for x in v.values()]
        rows.append((sum(1 for x in vals if x > 0) / len(vals), sum(vals), k, len(vals), min(x[1] for x in v.values())))
    rows.sort(key=lambda r: (-r[0], -r[1]))
    for share, tot, k, n, worst in rows:
        say(f"{k:<44} {round(share * n):>3}/{n:<4} {tot:>+9.2f} {tot / n:>+9.2f} {worst:>8.2f}")
    say(""); say("Лучший вариант по монетам:")
    k = rows[0][2]
    say("  " + k + ": " + "  ".join(f"{c} {v[0]:+.1f}" for c, v in table[k].items()))
    say(""); say("Рабочий = в плюсе на большинстве монет И при росте, и при падении цены. Приближение алгоритма GinArea.")
    out = BASE / "bt_lab_bots" / "ginarea_trend_all.txt"
    out.parent.mkdir(exist_ok=True); out.write_text("\n".join(LINES), encoding="utf-8")
    print(f"\nОтчёт: {out}")


if __name__ == "__main__":
    main()
