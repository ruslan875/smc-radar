@echo off
cd /d %~dp0
if exist venv\Scripts\python.exe (venv\Scripts\python.exe channel_test.py) else (python channel_test.py)
