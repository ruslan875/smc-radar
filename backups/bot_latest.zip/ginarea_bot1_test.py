"""ginarea_bot1_test.py — 2026-11-02. Бэктест бота GinArea «Bot #1» (Default grid, LONG, Bybit BTCUSDT) НА ДЕПОЗИТЕ 100 $.

Настройки со скриншотов: 20 ордеров, шаг 1% (сетка ≈ −17%), размер 0.001 BTC (без мультипликатора),
цель 1% от КАЖДОГО ордера (выход по средней ВЫКЛ), Instop 1%, мин. стоп 0.2%, макс. стоп 0.3%,
стоп-лосса/тейка бота нет. Комиссия Bybit taker 0.055%.
Депозит 100 $: считаем ЛИКВИДАЦИЮ — если капитал (100 + закрытая прибыль + плавающий убыток) падает ниже
маржи поддержания 0.5% от позиции, счёт обнуляется (тест для варианта останавливается).
Модель: старт цикла — после отката на Instop от максимума; следующий IN на шаг ниже самого нижнего открытого ордера;
каждый ордер: цена ≥ IN×(1+цель) → стоп-профит, трейлинг. Свечи OKX BTC 1m (кеш общий с прошлыми тестами).
Запуск: ginarea_bot1_test.bat [дней=365] [монета=BTC] → bt_lab_bots/ginarea_bot1_test.txt
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import pandas as pd

BASE = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE))
from ginarea_sui_test import okx_1m  # noqa: E402

LINES = []
DEP = 100.0   # переопределяется 3-м аргументом: ginarea_bot1_test.bat 365 BTC 300,500


def say(s=""):
    print(s, flush=True); LINES.append(s)


def run(d, P, fee=0.00055):
    t, o, h, l, c = (d[k].to_numpy() for k in ("t", "o", "h", "l", "c"))
    lots, total, peak = [], 0.0, h[0]
    R = {"deals": 0, "sl": 0, "liq": None, "worst_eq": DEP, "worst_t": None, "max_lots": 0, "max_notional": 0.0,
         "fees": 0.0, "hang_h": 0.0, "max_lev": 0.0}
    monthly = {}; t0 = None

    def book(x, ts):
        nonlocal total
        total += x; m = pd.to_datetime(ts, unit="ms").strftime("%Y-%m"); monthly[m] = monthly.get(m, 0.0) + x

    for i in range(1, len(c)):
        if not lots:
            peak = max(peak, h[i - 1])
            px = peak * (1 - P["instop"])
            if l[i] > px:
                continue
            px = min(px, o[i]); lots.append({"px": px, "q": P["qty"], "stop": None}); t0 = t[i]
            R["fees"] += px * P["qty"] * fee; book(-px * P["qty"] * fee, t[i])
        while len(lots) < P["n"] and l[i] <= min(x["px"] for x in lots) * (1 - P["step"]):
            px = min(x["px"] for x in lots) * (1 - P["step"]); lots.append({"px": px, "q": P["qty"], "stop": None})
            R["fees"] += px * P["qty"] * fee; book(-px * P["qty"] * fee, t[i])
        qty = sum(x["q"] for x in lots)
        R["max_lots"] = max(R["max_lots"], len(lots)); R["max_notional"] = max(R["max_notional"], qty * c[i])
        un = sum((l[i] - x["px"]) * x["q"] for x in lots)
        eq = DEP + total + un
        R["max_lev"] = max(R["max_lev"], qty * c[i] / max(eq, 1e-9))
        if eq < R["worst_eq"]:
            R["worst_eq"], R["worst_t"] = eq, t[i]
        if eq <= 0.005 * qty * l[i]:                                       # ликвидация
            book(-(DEP + total), t[i]); R["liq"] = t[i]; lots = []; break
        if P.get("sl") is not None and un <= P["sl"]:
            for x in lots:
                R["fees"] += l[i] * x["q"] * fee; book((l[i] - x["px"]) * x["q"] - l[i] * x["q"] * fee, t[i])
            lots = []; R["sl"] += 1; peak = l[i]; continue
        keep = []
        for x in lots:
            trig = x["px"] * (1 + P["target"])
            if x["stop"] is None and h[i] >= trig:
                x["stop"] = trig * (1 - P["min_stop"])
            if x["stop"] is not None:
                x["stop"] = max(x["stop"], h[i] * (1 - P["max_stop"]))
                if l[i] <= x["stop"]:
                    R["fees"] += x["stop"] * x["q"] * fee; book((x["stop"] - x["px"]) * x["q"] - x["stop"] * x["q"] * fee, t[i])
                    R["deals"] += 1; continue
            keep.append(x)
        lots = keep
        if not lots:
            peak = h[i]
            if t0 is not None:
                R["hang_h"] = max(R["hang_h"], (t[i] - t0) / 3_600_000)
    R["open_un"] = sum((c[-1] - x["px"]) * x["q"] for x in lots); R["open_n"] = len(lots)
    if lots and t0 is not None:
        R["hang_h"] = max(R["hang_h"], (t[-1] - t0) / 3_600_000)
    R["total"], R["all"], R["monthly"] = total, total + R["open_un"], monthly
    return R


def rep(name, r):
    say(f"--- {name} · депозит {DEP:.0f} $")
    if r["liq"]:
        say(f"  ⛔ ЛИКВИДАЦИЯ {pd.to_datetime(r['liq'], unit='ms'):%Y-%m-%d} — депозит 100 $ потерян")
    say(f"  ИТОГО {r['all']:+.2f} $ ({r['all'] / DEP * 100:+.0f}% депозита) · закрыто {r['total']:+.2f}, висит {r['open_n']} орд. {r['open_un']:+.2f} · "
        f"сделок {r['deals']} · стопов {r['sl']} · комиссии {r['fees']:.2f} $")
    say(f"  макс. ордеров {r['max_lots']} · позиция до {r['max_notional']:.0f} $ · макс. плечо {r['max_lev']:.1f}x · "
        f"минимум капитала {r['worst_eq']:.0f} $" + (f" ({pd.to_datetime(r['worst_t'], unit='ms'):%Y-%m-%d})" if r["worst_t"] else "")
        + f" · самый долгий цикл {r['hang_h'] / 24:.0f} дн.")
    say("  по месяцам: " + "  ".join(f"{m[2:]} {v:+.1f}" for m, v in sorted(r["monthly"].items())))


def main():
    global DEP
    days = int(sys.argv[1]) if len(sys.argv) > 1 else 365
    coin = (sys.argv[2] if len(sys.argv) > 2 else "BTC").upper()
    deps = [float(x) for x in (sys.argv[3] if len(sys.argv) > 3 else "300,500").split(",")]
    say(f"GinArea «Bot #1» Default grid LONG · OKX {coin} 1m · {days} дн. · Bybit taker 0.055% · {time.strftime('%Y-%m-%d %H:%M')}")
    d = okx_1m(coin, days)
    if len(d) < 10000:
        say("мало свечей"); return
    say(f"{pd.to_datetime(d.t.iloc[0], unit='ms'):%Y-%m-%d} → {pd.to_datetime(d.t.iloc[-1], unit='ms'):%Y-%m-%d} · {coin} "
        f"{d.c.iloc[0]:.0f} → {d.c.iloc[-1]:.0f} ({(d.c.iloc[-1] / d.c.iloc[0] - 1) * 100:+.0f}%) · мин {d.l.min():.0f} макс {d.h.max():.0f}")
    base = dict(n=20, step=0.01, qty=0.001, target=0.01, instop=0.01, min_stop=0.002, max_stop=0.003, sl=None)
    half = len(d) // 2
    for DEP in deps:
        say(""); say("#" * 90); say(f"ДЕПОЗИТ {DEP:.0f} $ · полная сетка 20 × 0.001 ≈ {20 * 0.001 * d.c.iloc[-1]:.0f} $ = {20 * 0.001 * d.c.iloc[-1] / DEP:.1f}x депозита")
        rep("как у тебя: 20 ордеров × 1%", run(d, base))
        rep("20 ордеров × 2% (сетка ≈ −32%)", run(d, {**base, "step": 0.02}))
        rep("10 ордеров × 2%", run(d, {**base, "n": 10, "step": 0.02}))
        rep("5 ордеров × 3%", run(d, {**base, "n": 5, "step": 0.03}))
        rep("10 ордеров × 2% + стоп-лосс бота −" + f"{DEP * 0.3:.0f} $", run(d, {**base, "n": 10, "step": 0.02, "sl": -DEP * 0.3}))
        say("  половины истории (10 ордеров × 2%):")
        rep("  1-я половина", run(d.iloc[:half].reset_index(drop=True), {**base, "n": 10, "step": 0.02}))
        rep("  2-я половина", run(d.iloc[half:].reset_index(drop=True), {**base, "n": 10, "step": 0.02}))
    say(""); say("Приближение алгоритма GinArea (минутные свечи OKX, торговля на Bybit). Сверяй с бэктестом GinArea.")
    out = BASE / "bt_lab_bots" / "ginarea_bot1_test_dep.txt"
    out.parent.mkdir(exist_ok=True); out.write_text("\n".join(LINES), encoding="utf-8")
    print(f"\nОтчёт: {out}")


if __name__ == "__main__":
    main()
