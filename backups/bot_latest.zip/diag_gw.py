import subprocess,os,time
out=subprocess.run("netstat -ano",capture_output=True,text=True,shell=True).stdout
pids={l.split()[-1] for l in out.splitlines() if ":8770 " in l and "LISTENING" in l}
print("8770 pids",pids,"my",os.getpid())
for p in pids:
    print(subprocess.run(f'wmic process where processid={p} get commandline,creationdate',capture_output=True,text=True,shell=True).stdout)
