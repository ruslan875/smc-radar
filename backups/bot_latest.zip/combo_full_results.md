# Combo OTM v3.2 — full Python port: SUB1 / SUB2 backtests

Engine: `combo_full.py` (all 23 filters + Shadow Trade Lock), runner `run_all.py`.
Assumptions: initial capital 500, 50% of equity per trade (qty = equity*50%/close of signal bar), commission 0.055% per fill, market orders fill at next bar open, exits live from the bar after the fill, TradingView intrabar path rule (open->nearer extreme->other extreme->close), gaps fill at open.
Data: Binance spot USDT 1h (not OKX). Indicators are warmed up on full history; entries are allowed only inside the window; a position still open at the window end is closed at the last close.
Reference (author's TradingView screenshot, similar build): +501%, DD 17.9%, 742 trades, 62.3% win, PF 1.83.

| Config | Symbol | Window | Net | Max DD | Trades | Win | PF | Shadow trades |
|---|---|---|---|---|---|---|---|---|
| SUB1 | XRP | 2024-01-01..2026-09-23 | +470.9% | 13.1% | 773 | 58.0% | 1.60 | 131 |
| SUB1 | XRP | 2024-01-01..2025-01-01 | +42.0% | 13.1% | 273 | 53.1% | 1.26 | 51 |
| SUB1 | XRP | 2025-01-01..2026-09-23 | +302.1% | 9.4% | 500 | 60.6% | 1.69 | 80 |
| SUB1 | XRP | 2019-01-01..2024-01-01 | -58.3% | 62.9% | 1252 | 46.5% | 0.90 | 181 |
| SUB1 (shadow lock OFF) | XRP | 2024-01-01..2026-09-23 | +466.7% | 13.1% | 793 | 57.5% | 1.61 | 0 |
| SUB2 | XRP | 2024-01-01..2026-09-23 | +545.0% | 13.1% | 744 | 59.9% | 1.71 | 125 |
| SUB2 | XRP | 2024-01-01..2025-01-01 | +33.9% | 13.1% | 259 | 53.3% | 1.22 | 49 |
| SUB2 | XRP | 2025-01-01..2026-09-23 | +381.5% | 7.5% | 485 | 63.5% | 1.84 | 76 |
| SUB2 | XRP | 2019-01-01..2024-01-01 | -52.5% | 56.3% | 1208 | 47.4% | 0.90 | 176 |
| SUB2 (shadow lock OFF) | XRP | 2024-01-01..2026-09-23 | +509.1% | 13.1% | 767 | 59.1% | 1.67 | 0 |
| SUB1 | BTC | 2024-01-01..2026-09-23 | -38.0% | 41.0% | 417 | 40.5% | 0.80 | 106 |
| SUB1 | ETH | 2024-01-01..2026-09-23 | -34.1% | 43.5% | 742 | 46.0% | 0.91 | 172 |
| SUB1 | SOL | 2024-01-01..2026-09-23 | -10.5% | 28.1% | 952 | 49.2% | 0.98 | 143 |
| SUB1 | DOGE | 2024-01-01..2026-09-23 | +58.4% | 28.4% | 951 | 51.1% | 1.08 | 172 |
| SUB1 | ADA | 2024-01-01..2026-09-23 | +5.7% | 34.2% | 925 | 48.9% | 1.01 | 208 |
| SUB1 | LINK | 2024-01-01..2026-09-23 | -41.1% | 43.6% | 928 | 47.1% | 0.91 | 168 |
| SUB1 | LTC | 2024-01-01..2026-09-23 | -33.9% | 42.3% | 739 | 46.8% | 0.90 | 137 |
| SUB1 | BNB | 2024-01-01..2026-09-23 | -30.4% | 34.9% | 548 | 44.0% | 0.88 | 67 |
| SUB1 | AVAX | 2024-01-01..2026-09-23 | -2.2% | 39.9% | 976 | 49.6% | 1.00 | 160 |
| SUB2 | BTC | 2024-01-01..2026-09-23 | -37.8% | 40.6% | 408 | 43.4% | 0.81 | 99 |
| SUB2 | ETH | 2024-01-01..2026-09-23 | -37.1% | 45.4% | 701 | 46.4% | 0.90 | 164 |
| SUB2 | SOL | 2024-01-01..2026-09-23 | -16.2% | 26.4% | 910 | 48.8% | 0.97 | 142 |
| SUB2 | DOGE | 2024-01-01..2026-09-23 | +56.4% | 27.7% | 915 | 51.5% | 1.09 | 174 |
| SUB2 | ADA | 2024-01-01..2026-09-23 | +7.9% | 27.0% | 888 | 49.4% | 1.01 | 197 |
| SUB2 | LINK | 2024-01-01..2026-09-23 | -26.6% | 38.6% | 881 | 48.5% | 0.94 | 166 |
| SUB2 | LTC | 2024-01-01..2026-09-23 | -38.4% | 45.0% | 703 | 46.8% | 0.88 | 134 |
| SUB2 | BNB | 2024-01-01..2026-09-23 | -26.1% | 38.8% | 518 | 45.6% | 0.89 | 62 |
| SUB2 | AVAX | 2024-01-01..2026-09-23 | +15.6% | 30.7% | 950 | 50.8% | 1.03 | 157 |
| Pine defaults | XRP | 2024-01-01..2026-09-23 | -55.1% | 73.8% | 1633 | 40.7% | 0.93 | 0 |
Note: XRP data starts on 2020-01-06, so the "2019-2023" row covers 2020-01-06..2023-12-31.
Max DD is measured peak (close equity) to trough (intrabar worst for the open position), as % of the peak.

## Approximations and items not ported exactly
- **nOI**: there is no open-interest feed, so `noiPct = na`. Pine passes the filter when it is na (`na(noiPct) or ...`), so the nOI filter never blocks a trade here. On TV/OKX with `XRPUSDT.P_OI` available it would block some trades. This is the largest fidelity gap.
- **Z-Score reference**: Pine uses `COINBASE:BTCUSD` hl2 (the default; "Reference Asset" is not in the CSVs). This port uses Binance BTCUSDT hl2, forward-filled onto the chart bars.
- **Price data**: Binance spot instead of OKX perp, so OHLCV differs slightly. CVD, RVOL, Volume Spike and MFI depend on volume, and volume levels differ between the venues.
- **Pivots**: strict comparison on both sides. Pine's handling of equal highs or lows is unpublished.
- **Dual long+short signal on the same bar**: this port assumes the short wins, because Pine places the Short entry second. This never happened with SUB1 or SUB2. It happened 53 times with the Pine defaults.
- **Order qty**: computed from the signal-bar close with no lot rounding. TradingView rounds qty to the symbol's precision.
- **RVOL**: only the chart-TF case is ported ("1 час" on 1h), which is what both settings files use. A higher TF raises NotImplementedError.
- **Timezone**: bars are in UTC. Both configs trade all hours on all days, so this has no effect.
- **Shadow Trade Lock**: ported line for line. That covers the pending → open-at-next-open flow (only when flat), the high-first heuristic, timer and break-even exits, and the return calculation. It also covers the feed into longStreak/shortStreak (on shadow open), consecutiveLosses and lastLong/ShortLossBar (on shadow loss), and the guard that blocks real entries while a shadow trade is pending or active. In SUB1 and SUB2 only CVD can create shadows, because WaveTrend is inactive and so never fails. Turning the lock off changes results by about 1-7% (see the "shadow lock OFF" rows).
- Not ported: drawing code and the diagnostics table, which do not affect trading.
