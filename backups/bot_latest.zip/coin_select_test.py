"""coin_select_test.py — 2026-10-13. Работает ли «торговать только на монетах, где стратегия была в плюсе»?

Честная проверка без заглядывания вперёд:
  история каждой монеты делится пополам по времени;
  стратегия гоняется ОТДЕЛЬНО на 1-й и на 2-й половине;
  «отобранные» монеты = те, где стратегия была в плюсе на 1-й половине;
  смотрим, что они дали на 2-й половине — по сравнению со ВСЕМИ монетами и с «отброшенными».
Если отбор работает, у отобранных 2-я половина должна быть стабильно лучше, чем у всех.
Стратегии: все из tg_strats_test (6), tg_strats_test2 (8), tg_strats_test3 (7), tg_strats_test4 (31). 12 монет, 1h и 4h.
Результат в % (для стратегий «по сделкам» — сумма % сделок; для сеток/DCA — доходность счёта).
Ничего не торгует. Запуск: coin_select_test.bat → bt_lab_bots/coin_select_test.txt
"""
from __future__ import annotations

import time
from pathlib import Path

import numpy as np

import tg_strats_test as T
import tg_strats_test2 as T2
import tg_strats_test3 as T3
import tg_strats_test4 as T4

OUT = Path(__file__).resolve().parent / "bt_lab_bots" / "coin_select_test.txt"
LINES = []


def say(s=""):
    print(s)
    LINES.append(s)


def half(d, which):
    n = len(d["c"]); m = n // 2
    sl = slice(0, m) if which == 0 else slice(m, n)
    return {k: v[sl] for k, v in d.items()}


def strategies():
    out = []
    for k, f in T.STRATS.items():
        out.append((f"[1] {k}", lambda d, f=f: sum(T.backtest(d, f(d)))))
    for k, f in T2.STRATS.items():
        out.append((f"[2] {k}", lambda d, f=f: sum(T2.backtest(d, f(d)))))
    for k, f in T3.TESTS.items():
        out.append((f"[3] {k}", lambda d, f=f: (f(d) or [1.0])[-1] - 1))
    for k, f in T4.TESTS.items():
        if getattr(f, "skip", None):
            continue
        out.append((f"[4] {k}", lambda d, f=f: (f(d) or [1.0])[-1] - 1))
    return out


def main():
    say(f"Отбор монет по прошлому результату — честная проверка · {time.strftime('%Y-%m-%d %H:%M')}")
    say("Для каждой стратегии: монеты, бывшие в плюсе на 1-й половине → их результат на 2-й половине.")
    strats = strategies()
    summary = []
    for tf, nb in (("60", 12000), ("240", 6000)):
        data = {s: T.klines(s, tf, nb) for s in T.COINS}
        halves = {s: (half(d, 0), half(d, 1)) for s, d in data.items() if len(d["c"]) >= 1600}
        say("")
        say(f"=== {'1h' if tf == '60' else '4h'} ===   (2-я половина, средний % на монету)")
        say(f"  {'стратегия':<34}{'отобр.':>7}{'все':>9}{'отобр.':>9}{'отброш.':>9}  вывод")
        for name, fn in strats:
            r1, r2 = {}, {}
            for s, (a, b) in halves.items():
                try:
                    r1[s] = fn(a); r2[s] = fn(b)
                except Exception:  # noqa: BLE001
                    continue
            if len(r2) < 6:
                continue
            sel = [s for s in r2 if r1[s] > 0]; rej = [s for s in r2 if r1[s] <= 0]
            all_ = np.mean(list(r2.values())) * 100
            s_ = np.mean([r2[s] for s in sel]) * 100 if sel else float("nan")
            j_ = np.mean([r2[s] for s in rej]) * 100 if rej else float("nan")
            if sel:
                summary.append((name, tf, len(sel), s_, all_, j_))
            verdict = ("нет плюсовых монет" if not sel else
                       "отбор помог" if s_ > all_ + 1 and s_ > 0 else
                       "отбор не помог" if s_ <= all_ else "почти без разницы")
            say(f"  {name[:34]:<34}{len(sel):>4}/{len(r2):<3}{all_:>+8.1f}%{s_:>+8.1f}%{j_:>+8.1f}%  {verdict}")
    say("")
    if summary:
        helped = sum(1 for x in summary if x[3] > x[4] + 1)
        hurt = sum(1 for x in summary if x[3] < x[4] - 1)
        pos2 = sum(1 for x in summary if x[3] > 0)
        diff = np.nanmean([x[3] - x[4] for x in summary])
        say(f"ИТОГО по {len(summary)} вариантам (стратегия × ТФ, где были плюсовые монеты):")
        say(f"  отбор помог (лучше всех монет больше чем на 1%): {helped}  ·  навредил: {hurt}  ·  разница в среднем: {diff:+.1f}%")
        say(f"  отобранные монеты в плюсе на 2-й половине: {pos2} из {len(summary)}")
        say("  Если «помог» заметно больше «навредил» и средняя разница положительная — отбор монет работает.")
        say("  Осторожно: многие стратегии похожи (лонг-сетки, DCA) и выбирают одни и те же монеты, поэтому их")
        say("  «голоса» не независимы — одна удачная монета во 2-й половине может дать «помог» сразу двадцати стратегиям.")
    OUT.parent.mkdir(exist_ok=True)
    OUT.write_text("\n".join(LINES), encoding="utf-8")
    print(f"\nОтчёт: {OUT}")


if __name__ == "__main__":
    main()
