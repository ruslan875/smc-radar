@echo off
cd /d D:\VANTORIX\bot
venv\Scripts\python.exe chan_speed_test.py
pause
