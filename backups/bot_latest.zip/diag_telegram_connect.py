"""
diag_telegram_connect.py -- diagnoses why `python main.py`'s Telegram
getUpdates call times out while a browser on the same machine reaches
api.telegram.org fine.

Tests, in order:
  1. DNS resolution for api.telegram.org (both IPv4 and IPv6 addresses).
  2. A raw TCP connect (no TLS, no HTTP) to port 443 on EACH resolved
     address individually, with a short per-address timeout, so we can
     see exactly which address(es)/protocol succeed vs hang.
  3. A normal requests.get(...) call (mirrors what the bot does).
  4. The same requests.get(...) call but forced onto IPv4-only, to check
     whether forcing IPv4 fixes it (a common fix if IPv6 is the culprit).

Run from the project root, with the venv active:
    python diag_telegram_connect.py

(or, without activating venv first: venv\\Scripts\\python.exe diag_telegram_connect.py)
"""
import socket
import time

HOST = "api.telegram.org"
PORT = 443

print(f"=== DNS resolution for {HOST} ===")
try:
    infos = socket.getaddrinfo(HOST, PORT, proto=socket.IPPROTO_TCP)
except Exception as e:
    print(f"DNS resolution FAILED: {e}")
    infos = []

seen = set()
addr_list = []
for family, socktype, proto, canonname, sockaddr in infos:
    ip = sockaddr[0]
    if ip in seen:
        continue
    seen.add(ip)
    fam_name = "IPv6" if family == socket.AF_INET6 else "IPv4"
    addr_list.append((fam_name, family, ip))
    print(f"  {fam_name}: {ip}")

if not addr_list:
    print("No addresses resolved -- DNS itself may be broken/blocked.")

print()
print("=== Raw TCP connect test to each address (5s timeout each) ===")
for fam_name, family, ip in addr_list:
    start = time.time()
    try:
        s = socket.socket(family, socket.SOCK_STREAM)
        s.settimeout(5)
        s.connect((ip, PORT))
        elapsed = time.time() - start
        print(f"  {fam_name} {ip}: OK ({elapsed:.2f}s)")
        s.close()
    except Exception as e:
        elapsed = time.time() - start
        print(f"  {fam_name} {ip}: FAILED after {elapsed:.2f}s -- {e}")

print()
print("=== requests.get() default (whatever Python/urllib3 picks first) ===")
try:
    import requests
except ImportError:
    print("requests not installed in this environment -- skipping")
    requests = None

if requests is not None:
    start = time.time()
    try:
        r = requests.get(f"https://{HOST}", timeout=10)
        elapsed = time.time() - start
        print(f"  default requests.get: OK ({elapsed:.2f}s) status={r.status_code}")
    except Exception as e:
        elapsed = time.time() - start
        print(f"  default requests.get: FAILED after {elapsed:.2f}s -- {e}")

    print()
    print("=== requests.get() forced onto IPv4 only ===")
    try:
        import urllib3.util.connection as urllib3_cn

        original_allowed_gai_family = urllib3_cn.allowed_gai_family

        def force_ipv4():
            return socket.AF_INET

        urllib3_cn.allowed_gai_family = force_ipv4
        start = time.time()
        try:
            r = requests.get(f"https://{HOST}", timeout=10)
            elapsed = time.time() - start
            print(f"  IPv4-forced requests.get: OK ({elapsed:.2f}s) status={r.status_code}")
        except Exception as e:
            elapsed = time.time() - start
            print(f"  IPv4-forced requests.get: FAILED after {elapsed:.2f}s -- {e}")
        finally:
            urllib3_cn.allowed_gai_family = original_allowed_gai_family
    except Exception as e:
        print(f"  Could not run IPv4-forced test: {e}")

print()
print("Done. Paste this whole output back so it can be diagnosed.")
